"""
AgentFlow: Framework-independent AI agent harness configurator.

Install with extras:
    pip install agentflow[workflows]         # LangGraph multi-agent orchestration
    pip install agentflow[deep]              # DeepAgents autonomous agent harnesses
    pip install agentflow[semantic-kernel]   # Microsoft Semantic Kernel
    pip install agentflow[claude-agent-sdk]  # Anthropic Claudio Agent SDK
    pip install agentflow[openai-agents]     # OpenAI Agents SDK
    pip install agentflow[agent-framework]   # Microsoft Agent Framework
    pip install agentflow[adk]               # Google Agent Development Kit (ADK)
    pip install agentflow[adk-extensions]    # Google ADK with LiteLLM-backed providers (OpenAI / Anthropic / Azure / Ollama / vLLM)

Unified entry point::

    import agentflow

    runner = await agentflow.create("agent.yaml")
"""

try:
    from importlib.metadata import version

    __version__ = version("agentflow")
except Exception:
    __version__ = "0.0.0"

# Core exports (framework-independent, always available)
from agentflow.core.factory import create, detect_backend  # noqa: F401

# Telemetry exporter seam — backend-agnostic, works for every backend
# (workflows, deep, sk, cas, oai, adk). Depends only on opentelemetry (a base
# dependency), so it's safe to export eagerly regardless of installed extras.
from agentflow.core.telemetry_seam import register_span_processor  # noqa: F401

# Lazy re-exports from workflows for backward compatibility.
# This avoids pulling in workflows dependencies (langchain, langgraph, a2a, etc.)
# when users only have agentflow[deep] or agentflow[semantic-kernel] installed.
_WORKFLOWS_EXPORTS = {
    "AsyncWorkflowOrchestrator",
    "WorkflowOrchestrator",
    "Plugin",
    "PluginManager",
    "WorkflowContext",
    "MCPServerManager",
    "MCPTransport",
    "MCPServerConfig",
    "MCPToolsReference",
    "MCPToolAlias",
    "MCPConnectionError",
    "MCPToolError",
    "ConnectionStatus",
}

__all__ = [
    "create",
    "detect_backend",
    "register_span_processor",
    "__version__",
    *_WORKFLOWS_EXPORTS,
]


def __getattr__(name: str):
    if name in _WORKFLOWS_EXPORTS:
        from . import workflows
        return getattr(workflows, name)
    raise AttributeError(f"module 'agentflow' has no attribute {name!r}")
