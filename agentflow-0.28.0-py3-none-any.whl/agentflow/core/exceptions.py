"""Typed exceptions raised across the AgentFlow core / backends.

Each class subclasses a stdlib base (``RuntimeError``, ``ValueError``,
etc.) so callers that catch the broad type still match — the typed
classes only add field-level structure for the friendly-error formatter
and any future programmatic handling.
"""

from __future__ import annotations

from typing import Optional


class MissingEnvVarError(RuntimeError):
    """Raised when a YAML config references ``${VAR}`` and ``VAR`` is unset.

    Subclasses ``RuntimeError`` so legacy callers (MAF / OAI / CAS used
    bare ``RuntimeError`` before this class existed) continue to catch.
    """

    def __init__(self, name: str, source: Optional[str] = None):
        self.name = name
        self.source = source  # e.g. the YAML path; not yet wired through
        msg = (
            f"Environment variable {name!r} is referenced in config but "
            f"not set. Export it or add it to your .env file."
        )
        if source:
            msg = f"{msg} (referenced in {source})"
        super().__init__(msg)
