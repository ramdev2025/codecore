"""Shared environment variable resolution utility."""

import os
import re


def resolve_env_vars(value: str) -> str:
    """Resolve ${VAR_NAME} references in a string.

    Args:
        value: String that may contain ${VAR_NAME} patterns.

    Returns:
        String with environment variables resolved.

    Raises:
        ValueError: If a referenced environment variable is not set.
    """

    def _replace(match):
        var = match.group(1)
        val = os.environ.get(var)
        if val is None:
            raise ValueError(
                f"Environment variable '{var}' is not set. "
                f"Please set it before using this configuration."
            )
        return val

    return re.sub(r'\$\{([^}]+)\}', _replace, value)
