"""Shared PostgreSQL connection-pool settings for AgentFlow backends.

Backends that persist to PostgreSQL (``workflows``, ``deep``) must not hold a
single long-lived ``psycopg`` connection. When that connection is closed
underneath the process — a database restart, a failover, a server-side
``idle_session_timeout``, or a cloud load balancer reaping an idle TCP flow —
libpq marks it ``CONNECTION_BAD`` and never clears the flag. psycopg does not
reconnect, so every subsequent operation fails with
``OperationalError: the connection is closed`` until the process restarts.

A pool fixes that in two complementary ways, both enabled by default:

* ``check`` (reactive) validates a connection on checkout, discarding and
  replacing a dead one before the caller sees it.
* ``max_lifetime`` (proactive) retires connections on a timer so they never
  live long enough to be reaped. ``max_idle`` alone is not sufficient — it only
  trims connections *above* ``min_size``, so a pool sitting at ``min_size=1``
  would keep its single connection forever.

This module is the single source of truth for both the tuning defaults and the
per-connection kwargs, so the two backends cannot drift apart or away from
langgraph's own expectations.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional

# Environment variables for pool tuning.
#
# These are honoured wherever a pooled PostgreSQL connection is built — the
# ``workflows`` backend (CLI, ``build_agui``, the Python API, and any direct
# ``PostgresConfig`` construction) and the ``deep`` backend. Backends that open
# a connection per operation (sk / cas / oai / maf / adk) do not pool and
# ignore these.
ENV_POSTGRES_POOL_SIZE = "POSTGRES_POOL_SIZE"
ENV_POSTGRES_POOL_MIN_SIZE = "POSTGRES_POOL_MIN_SIZE"
ENV_POSTGRES_POOL_MAX_LIFETIME = "POSTGRES_POOL_MAX_LIFETIME"
ENV_POSTGRES_POOL_MAX_IDLE = "POSTGRES_POOL_MAX_IDLE"
ENV_POSTGRES_POOL_CHECK = "POSTGRES_POOL_CHECK"
ENV_POSTGRES_POOL_TIMEOUT = "POSTGRES_POOL_TIMEOUT"

_TRUTHY = {"1", "true", "yes", "on"}
_FALSY = {"0", "false", "no", "off"}

# Defaults. Deliberately conservative on size (managed PostgreSQL instances
# often cap total connections) and protective on liveness.
DEFAULT_POOL_SIZE = 5
DEFAULT_MIN_SIZE = 1
DEFAULT_MAX_LIFETIME = 600.0
DEFAULT_MAX_IDLE = 300.0
DEFAULT_CHECK_CONNECTION = True
DEFAULT_CONNECT_TIMEOUT = 30.0


def canonical_connection_kwargs() -> dict[str, Any]:
    """Per-connection kwargs that langgraph's savers require.

    These mirror exactly what langgraph's own ``from_conn_string`` helpers set
    on the connection they open (see ``PostgresSaver.from_conn_string`` and
    ``AsyncPostgresSaver.from_conn_string``). They are not tuning knobs — the
    savers' SQL depends on them, so they must not be changed or omitted.
    """
    from psycopg.rows import dict_row

    return {
        "autocommit": True,
        "prepare_threshold": 0,
        "row_factory": dict_row,
    }


@dataclass(frozen=True)
class PoolSettings:
    """Tuning knobs for a PostgreSQL connection pool."""

    pool_size: int = DEFAULT_POOL_SIZE
    min_size: int = DEFAULT_MIN_SIZE
    max_lifetime: float = DEFAULT_MAX_LIFETIME
    max_idle: float = DEFAULT_MAX_IDLE
    check_connection: bool = DEFAULT_CHECK_CONNECTION
    connect_timeout: float = DEFAULT_CONNECT_TIMEOUT

    def __post_init__(self) -> None:
        if self.min_size > self.pool_size:
            raise ValueError(
                f"min_size ({self.min_size}) cannot exceed pool_size ({self.pool_size})"
            )


def _parse_number(env_name: str, raw: str, parser: type) -> Any:
    try:
        return parser(raw)
    except ValueError:
        expected = "an integer" if parser is int else "a number"
        raise ValueError(f"{env_name} must be {expected}, got: {raw!r}") from None


def _parse_int(env_name: str, raw: str) -> int:
    return _parse_number(env_name, raw, int)


def _parse_float(env_name: str, raw: str) -> float:
    return _parse_number(env_name, raw, float)


def _parse_bool(env_name: str, raw: str) -> bool:
    value = raw.strip().lower()
    if value in _TRUTHY:
        return True
    if value in _FALSY:
        return False
    raise ValueError(
        f"{env_name} must be a boolean (one of {sorted(_TRUTHY | _FALSY)}), got: {raw!r}"
    )


# Field name -> (env var, parser). The single description of which env var
# feeds which pool setting; both PoolSettings and PostgresConfig read it, so
# adding a knob is one entry here rather than two call sites that can drift.
POOL_ENV_FIELDS: tuple[tuple[str, str, Any], ...] = (
    ("pool_size", ENV_POSTGRES_POOL_SIZE, _parse_int),
    ("min_size", ENV_POSTGRES_POOL_MIN_SIZE, _parse_int),
    ("max_lifetime", ENV_POSTGRES_POOL_MAX_LIFETIME, _parse_float),
    ("max_idle", ENV_POSTGRES_POOL_MAX_IDLE, _parse_float),
    ("check_connection", ENV_POSTGRES_POOL_CHECK, _parse_bool),
    ("connect_timeout", ENV_POSTGRES_POOL_TIMEOUT, _parse_float),
)


def pool_overrides_from_env() -> dict[str, Any]:
    """Return ``{field: value}`` for every ``POSTGRES_POOL_*`` var that is set.

    Fields whose env var is unset or empty are omitted, so the caller keeps
    whatever default or explicit value it already had.

    Raises:
        ValueError: If a var is set to a malformed value. Failing loudly at
            startup beats silently falling back to a default the operator did
            not choose.
    """
    overrides: dict[str, Any] = {}
    for field, env_name, parser in POOL_ENV_FIELDS:
        raw = os.environ.get(env_name)
        if raw:
            overrides[field] = parser(env_name, raw)
    return overrides


def pool_settings_from_env(base: Optional[PoolSettings] = None) -> PoolSettings:
    """Build :class:`PoolSettings`, overlaying any ``POSTGRES_POOL_*`` env vars.

    Precedence is explicit (``base``) < env var, with the module defaults
    underneath.

    Args:
        base: Settings to start from. Defaults to the module defaults.

    Raises:
        ValueError: If any env var is set to a malformed value.
    """
    base = base or PoolSettings()
    overrides = pool_overrides_from_env()

    return PoolSettings(
        pool_size=overrides.get("pool_size", base.pool_size),
        min_size=overrides.get("min_size", base.min_size),
        max_lifetime=overrides.get("max_lifetime", base.max_lifetime),
        max_idle=overrides.get("max_idle", base.max_idle),
        check_connection=overrides.get("check_connection", base.check_connection),
        connect_timeout=overrides.get("connect_timeout", base.connect_timeout),
    )


def build_pool_kwargs(conninfo: str, settings: PoolSettings, *, is_async: bool) -> dict[str, Any]:
    """Assemble constructor kwargs for a psycopg ``(Async)ConnectionPool``.

    ``check`` differs between the sync and async pool classes, so the caller
    states which one it is building for.

    The pool is always built with ``open=False``; the caller is responsible for
    opening it (``pool.open()`` / ``await pool.open()``). Passing ``open=True``
    to the constructor is deprecated in psycopg_pool 3.2+.
    """
    if is_async:
        from psycopg_pool import AsyncConnectionPool as _Pool
    else:
        from psycopg_pool import ConnectionPool as _Pool

    return {
        "conninfo": conninfo,
        "min_size": settings.min_size,
        "max_size": settings.pool_size,
        "max_lifetime": settings.max_lifetime,
        "max_idle": settings.max_idle,
        "timeout": settings.connect_timeout,
        "check": _Pool.check_connection if settings.check_connection else None,
        "open": False,
        "kwargs": canonical_connection_kwargs(),
    }


def describe(settings: PoolSettings) -> str:
    """One-line summary for startup logs."""
    return (
        f"min_size={settings.min_size}, max_size={settings.pool_size}, "
        f"max_lifetime={settings.max_lifetime}s, max_idle={settings.max_idle}s, "
        f"check_connection={settings.check_connection}"
    )
