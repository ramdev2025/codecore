"""Azure Monitor / Application Insights span-processor factory.

Bridges AgentFlow's vendor-neutral OTLP telemetry to Azure Application Insights
— and therefore to the **Azure AI Foundry Tracing UI** — which does not ingest
raw OTLP on its public endpoint. ``AzureMonitorTraceExporter`` (connection-string
based) is that translator.

This plugs into the shared, backend-agnostic **exporter seam** (the
``agentflow.span_processors`` entry-point group in
:mod:`agentflow.core.telemetry_seam`), so it works for **every** backend
(workflows, deep, sk, cas, oai, adk). It lives under ``agentflow.core`` — **not**
under any backend package — on purpose: discovering/loading this factory must not
drag in a backend's heavy dependencies (e.g. importing it from a deep-only app
must not require the workflows ``a2a`` stack). It imports only opentelemetry and,
lazily, the Azure SDK.

Installing the ``agentflow[azure-monitor]`` extra is enough — no application code
changes. The processor is attached **additively**, so OTLP export keeps working
alongside Azure (dual-export).

Activation is env-driven (a deployment concern, never YAML):

    APPLICATIONINSIGHTS_CONNECTION_STRING   Azure App Insights connection string.
                                            When unset, this factory is a no-op
                                            and imports nothing Azure-related.
    OTEL_TRACES_ENABLED                     Must be "true" for telemetry at all
                                            (gates the whole substrate upstream).
"""

from __future__ import annotations

import os
from typing import Optional

from opentelemetry.sdk.trace import SpanProcessor
from opentelemetry.sdk.trace.export import BatchSpanProcessor


def make_azure_processor() -> Optional[SpanProcessor]:
    """Entry-point factory for the ``agentflow.span_processors`` seam.

    Returns a ``BatchSpanProcessor`` wrapping an ``AzureMonitorTraceExporter``
    when ``APPLICATIONINSIGHTS_CONNECTION_STRING`` is set; otherwise ``None`` so
    the default (un-configured) path imports nothing Azure-related and behaves
    exactly as before.

    Raises ``ImportError`` — with an actionable hint — when the connection string
    is set but the exporter can't be imported (missing, or a version incompatible
    with the current opentelemetry-sdk). The seam's discovery
    (:func:`agentflow.core.telemetry_seam.discover_entrypoint_processors`) catches
    this, surfaces it as a warning, and skips this processor rather than crashing
    telemetry setup.
    """
    connection_string = os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")
    if not connection_string:
        # No connection string → opt out. Deliberately BEFORE the azure import,
        # so an env without the extra installed is completely unaffected.
        return None

    try:
        from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter
    except ImportError as exc:
        raise ImportError(
            "APPLICATIONINSIGHTS_CONNECTION_STRING is set but the Azure Monitor "
            f"OpenTelemetry exporter could not be imported ({exc}). Either it isn't "
            "installed — `pip install 'agentflow[azure-monitor]'` — or an installed "
            "version is incompatible with the current opentelemetry-sdk (older builds "
            "import LogData from opentelemetry.sdk._logs, removed in SDK 1.44). "
            "Upgrade it: pip install --pre -U 'azure-monitor-opentelemetry-exporter>=1.0.0b56'"
        ) from exc

    return BatchSpanProcessor(
        AzureMonitorTraceExporter(connection_string=connection_string)
    )
