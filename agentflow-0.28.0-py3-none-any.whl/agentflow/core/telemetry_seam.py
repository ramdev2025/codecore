"""Backend-agnostic OpenTelemetry **exporter seam**.

Every backend has its own ``telemetry.py`` that builds a ``TracerProvider`` and
wires its default OTLP exporter. This module is the one piece that is genuinely
framework-independent: it lets *additional* span processors be attached to any
backend's provider — **additively**, alongside the default OTLP export — so
spans can reach several backends at once (dual-export) with no per-backend
wiring.

Two contribution paths:

* **In-process** — :func:`register_span_processor`, called before (or after) a
  backend initializes its provider.
* **Installed package** — a zero-arg factory published under the
  ``agentflow.span_processors`` entry-point group (see
  :func:`discover_entrypoint_processors`). This is how the built-in Azure Monitor
  exporter (``agentflow[azure-monitor]``) attaches with no application code.

Each backend calls :func:`attach_seam_processors` once, right after it builds its
provider. The seam then owns provider tracking + the atexit shutdown safety-net,
so a late :func:`register_span_processor` call reaches already-built providers.

Depends only on ``opentelemetry`` + ``importlib.metadata`` (both base
dependencies), so it is safe to import from any backend regardless of which
extra is installed.
"""

from __future__ import annotations

import atexit
import os
from importlib.metadata import entry_points
from typing import Callable, List, Optional

from opentelemetry.sdk.trace import SpanProcessor, TracerProvider

SPAN_PROCESSOR_ENTRYPOINT_GROUP = "agentflow.span_processors"

# Processors registered in-process, attached to every backend provider.
_registered_processors: List[SpanProcessor] = []
# Providers built by backends, tracked so late registrations reach them and so
# they're flushed/shut down at process exit.
_active_providers: List[TracerProvider] = []
_atexit_registered = False


def register_span_processor(processor: SpanProcessor) -> None:
    """Register an additional span processor with the exporter seam.

    Attached **additively** to every backend's tracer provider — alongside the
    default OTLP exporter — so spans reach multiple backends at once. Register
    before telemetry initializes (the common case: at import of an integration
    package); if providers already exist, the processor is attached to each
    immediately.
    """
    if processor not in _registered_processors:
        _registered_processors.append(processor)
    for provider in _active_providers:
        provider.add_span_processor(processor)


def discover_entrypoint_processors() -> List[SpanProcessor]:
    """Discover span processors contributed by installed packages via the
    ``agentflow.span_processors`` entry-point group.

    Each entry point loads to a zero-arg factory returning a ``SpanProcessor``
    (or ``None`` to opt out — e.g. when its required env config is absent). A
    factory that raises is logged and skipped rather than crashing telemetry
    setup, so a misconfigured optional exporter never takes tracing down.
    """
    found: List[SpanProcessor] = []
    try:
        eps = entry_points(group=SPAN_PROCESSOR_ENTRYPOINT_GROUP)
    except Exception:
        return found
    for ep in eps:
        try:
            obj = ep.load()
            processor = obj() if callable(obj) else obj
            if processor is not None:
                found.append(processor)
        except Exception as e:
            print(f"Warning: failed to load span processor entry point "
                  f"'{getattr(ep, 'name', '?')}': {e}")
    return found


def attach_seam_processors(
    provider: TracerProvider,
    default_factory: Optional[Callable[[], SpanProcessor]] = None,
    default_is_explicit: Optional[bool] = None,
) -> bool:
    """Attach the backend's default sink + all seam processors to ``provider``.

    Seam processors (in-process :func:`register_span_processor` + entry-point
    discovered, e.g. Azure Monitor) are always attached, additively.

    ``default_factory`` builds the backend's **default OTLP** span processor
    (lazily, so it's only constructed if actually used). It is attached UNLESS it
    would be a phantom sink: when the OTLP endpoint is **not explicitly
    configured** and **at least one seam processor is present**, the default is
    skipped — so an Azure-only (seam-only) deployment doesn't spew failed-export
    noise at ``localhost:4317``. When ``default_is_explicit`` is ``None`` it is
    inferred from ``OTEL_EXPORTER_OTLP_ENDPOINT`` being set.

    Also tracks the provider (so a late :func:`register_span_processor` reaches
    it) and installs the atexit shutdown safety-net the first time. Returns
    whether the default OTLP sink was attached.
    """
    global _atexit_registered
    if default_is_explicit is None:
        default_is_explicit = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT") is not None

    seam_processors = [*_registered_processors, *discover_entrypoint_processors()]

    attached_default = False
    if default_factory is not None and (default_is_explicit or not seam_processors):
        provider.add_span_processor(default_factory())
        attached_default = True

    for processor in seam_processors:
        provider.add_span_processor(processor)

    if provider not in _active_providers:
        _active_providers.append(provider)
    if not _atexit_registered:
        atexit.register(_shutdown_all_providers)
        _atexit_registered = True
    return attached_default


def untrack_provider(provider: TracerProvider) -> None:
    """Stop tracking ``provider`` — called when a backend shuts it down itself,
    so the atexit safety-net doesn't shut it down a second time."""
    if provider in _active_providers:
        _active_providers.remove(provider)


def _shutdown_all_providers() -> None:
    """Flush + shut down every tracked provider on process exit."""
    for provider in _active_providers:
        try:
            provider.force_flush(timeout_millis=5000)
        except Exception:
            pass
        try:
            provider.shutdown()
        except Exception:
            pass
    _active_providers.clear()
