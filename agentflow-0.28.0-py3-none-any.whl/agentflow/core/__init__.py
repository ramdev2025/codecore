"""AgentFlow core — shared utilities and unified factory.

Also provides backward-compatible shim for agentflow.workflows.core.*
so that existing code like ``from agentflow.core.config_models import LLMConfig``
continues to work after the v0.10.0 package restructure.
"""
import importlib
import sys

# Core exports (framework-independent)
from agentflow.core.factory import create, detect_backend  # noqa: F401
from agentflow.core.env import resolve_env_vars  # noqa: F401

# Re-export top-level symbols from workflows (best-effort — may fail if not installed)
try:
    from agentflow.workflows.core import *  # noqa: F401,F403
except ImportError:
    pass

# Submodules that should be accessible under the old path
_SUBMODULES = [
    "a2a_client",
    "builder",
    "config_models",
    "constants",
    "helpers",
    "llm_factory",
    "llm_protocol",
    "mcp_client",
    "middleware_factory",
    "orchestrator",
    "persistence_manager",
    "runtime_models",
]

# Register each submodule under the old path in sys.modules
for _name in _SUBMODULES:
    _old_key = f"agentflow.core.{_name}"
    if _old_key not in sys.modules:
        try:
            _mod = importlib.import_module(f"agentflow.workflows.core.{_name}")
            sys.modules[_old_key] = _mod
        except ImportError:
            pass
