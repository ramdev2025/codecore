"""
Unified factory for creating agentflow runners from YAML config.

The factory reads the YAML's ``backend`` field (or detects it heuristically)
and dispatches to the appropriate backend module.  This is the single entry
point for both API users and the CLI.

Usage::

    import agentflow

    # Workflows
    orchestrator = await agentflow.create("workflow.yaml")
    async for event in orchestrator.run(state, config):
        ...

    # Deep
    builder = await agentflow.create("agent.yaml")
    agent = builder.build()
    result = agent.invoke(input_dict, config=config)
"""

from typing import Any, Optional

import yaml

VALID_BACKENDS = {
    "workflows",
    "deep",
    "semantic-kernel",
    "claude-agent-sdk",
    "openai-agents",
    "agent-framework",
    "adk",
}

# Backend name aliases. Each key is accepted on input (YAML ``backend:``
# field or ``--backend`` flag) and normalized to its canonical value
# before dispatch. Keep this map small — every alias is permanent
# user-facing surface.
BACKEND_ALIASES = {
    "deepagents": "deep",   # PyPI package name → short backend name
}


def detect_backend(yaml_path: str, override: Optional[str] = None) -> str:
    """Resolve the backend for a YAML config.

    Priority:

    1. ``override`` parameter (e.g. from CLI ``--backend`` flag).
    2. Top-level ``backend:`` field in the YAML file (**required** when
       no override is given).

    The legacy structural heuristic was removed in v0.20 — every config
    must self-declare its backend. Auto-detection was unreliable in two
    cases: (a) a ``workflows`` standalone agent and a barebones ``deep``
    agent are structurally identical (both just have ``agent:``);
    (b) any future backend that introduces overlapping keys would
    silently mis-route. A required field is unambiguous, fast to write,
    and matches what ``sk`` / ``cas`` / ``oai`` / ``maf`` already
    enforce.

    Aliases (e.g. ``deepagents`` → ``deep``) are normalized to their
    canonical value via :data:`BACKEND_ALIASES` on input — downstream
    code only ever sees a canonical name.

    Args:
        yaml_path: Path to the YAML config file.
        override: Explicit backend override (takes priority).

    Returns:
        Backend identifier string (one of :data:`VALID_BACKENDS`).

    Raises:
        ValueError: If backend is invalid, missing, or the YAML is malformed.
        FileNotFoundError: If the YAML file does not exist.
    """
    if override:
        canonical = BACKEND_ALIASES.get(override, override)
        if canonical not in VALID_BACKENDS:
            raise ValueError(
                f"Unknown backend: {override!r}. "
                f"Valid backends: {', '.join(sorted(VALID_BACKENDS))}"
            )
        return canonical

    with open(yaml_path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ValueError(
            f"Invalid YAML config: expected a mapping, got {type(raw).__name__}"
        )

    if "backend" not in raw:
        raise ValueError(
            f"Missing required 'backend' field in {yaml_path}. "
            f"Add one of:\n"
            f"  backend: workflows         # LangGraph multi-agent\n"
            f"  backend: deep              # DeepAgents long-horizon (alias: deepagents)\n"
            f"  backend: semantic-kernel\n"
            f"  backend: claude-agent-sdk\n"
            f"  backend: openai-agents\n"
            f"  backend: agent-framework   # Microsoft Agent Framework\n"
            f"  backend: adk               # Google Agent Development Kit"
        )

    backend = raw["backend"]
    canonical = BACKEND_ALIASES.get(backend, backend)
    if canonical not in VALID_BACKENDS:
        raise ValueError(
            f"Unknown backend: {backend!r} in {yaml_path}. "
            f"Valid backends: {', '.join(sorted(VALID_BACKENDS))}"
        )
    return canonical


async def create(
    yaml_path: str,
    *,
    backend: Optional[str] = None,
    persistence: Optional[str] = None,
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
    tools_module: Optional[str] = None,
    **kwargs,
) -> Any:
    """Create an agentflow runner from YAML config.

    Reads the YAML's ``backend`` field (or detects it heuristically),
    imports the appropriate backend module, and returns a configured
    runner ready for execution. Thread ID is not a build-time concern —
    pass it per execution via the returned runner's ``.run()``/``.invoke()``
    config.

    Args:
        yaml_path: Path to the YAML config file.
        backend: Explicit backend override (takes priority over YAML).
        persistence: Persistence backend (``"memory"``, ``"sqlite"``,
            ``"postgres"``).
        db_path: SQLite database path.
        connection_string: PostgreSQL connection string.
        tools_module: Python module containing tool definitions (workflows).
        **kwargs: Additional backend-specific arguments.

    Returns:
        Backend-specific runner:

        - **workflows** → ``AsyncWorkflowOrchestrator`` (call ``.run()``
          to execute)
        - **deep** → ``DeepAgentBuilder`` (call ``.build()`` to get agent)
        - **semantic-kernel** → ``SKAgentBuilder`` (future)

    Raises:
        ImportError: If the required backend package is not installed.
        ValueError: If backend cannot be determined.
    """
    resolved_backend = detect_backend(yaml_path, override=backend)

    if resolved_backend == "workflows":
        try:
            from agentflow.workflows import AsyncWorkflowOrchestrator
        except ImportError:
            raise ImportError(
                "Workflows backend requires LangGraph. "
                "Install with: pip install agentflow[workflows]"
            )
        return await AsyncWorkflowOrchestrator.create(
            config_path=yaml_path,
            tools_module=tools_module,
            enable_persistence=persistence != "memory" if persistence else True,
            checkpointer_path=db_path or ".agentflow/checkpoints.db",
            **kwargs,
        )

    elif resolved_backend == "deep":
        try:
            from agentflow.deep import DeepAgentBuilder
            from agentflow.deep.core.persistence import create_checkpointer
        except ImportError:
            raise ImportError(
                "Deep backend requires DeepAgents. "
                "Install with: pip install agentflow[deep]"
            )
        checkpointer = None
        if persistence and persistence != "memory":
            checkpointer = create_checkpointer(
                backend=persistence,
                db_path=db_path,
                connection_string=connection_string,
            )
        return DeepAgentBuilder.from_yaml(
            yaml_path,
            checkpointer=checkpointer,
            **kwargs,
        )

    elif resolved_backend == "semantic-kernel":
        try:
            from agentflow.sk import SKAgentBuilder
        except ImportError:
            raise ImportError(
                "Semantic Kernel backend requires semantic-kernel. "
                "Install with: pip install agentflow[semantic-kernel]"
            )
        return SKAgentBuilder.from_yaml(yaml_path, **kwargs)

    elif resolved_backend == "claude-agent-sdk":
        try:
            from agentflow.cas.core.builder import CasAgentBuilder
        except ImportError:
            raise ImportError(
                "Claude Agent SDK backend requires claude-agent-sdk. "
                "Install with: pip install agentflow[claude-agent-sdk]"
            )
        return CasAgentBuilder.from_yaml(yaml_path, **kwargs)

    elif resolved_backend == "openai-agents":
        try:
            from agentflow.oai.core.builder import OaiAgentBuilder
        except ImportError:
            raise ImportError(
                "OpenAI Agents backend requires openai-agents. "
                "Install with: pip install agentflow[openai-agents]"
            )
        return OaiAgentBuilder.from_yaml(yaml_path, **kwargs)

    elif resolved_backend == "agent-framework":
        try:
            from agentflow.maf.core.builder import MafAgentBuilder
        except ImportError:
            raise ImportError(
                "Microsoft Agent Framework backend requires agent-framework. "
                "Install with: pip install agentflow[agent-framework]"
            )
        return MafAgentBuilder.from_yaml(yaml_path, **kwargs)

    elif resolved_backend == "adk":
        try:
            from agentflow.adk.core.builder import AdkAgentBuilder
        except ImportError:
            raise ImportError(
                "Google ADK backend requires google-adk. "
                "Install with: pip install agentflow[adk]"
            )
        return AdkAgentBuilder.from_yaml(yaml_path, **kwargs)

    else:
        raise ValueError(f"Unknown backend: {resolved_backend!r}")
