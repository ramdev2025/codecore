# AgentFlow Workflows

**YAML-driven multi-agent workflows on [LangGraph](https://www.langchain.com/langgraph).**

The original AgentFlow backend, alongside `deep` (DeepAgents), `sk` (Semantic Kernel), `cas` (Claude Agent SDK), `oai` (OpenAI Agents SDK), and `agent-framework` (Microsoft Agent Framework). Install with `pip install agentflow[workflows]`.

> **Status: stable.** Has been the primary backend through every release; canonical reference for every other backend's persistence / observability / middleware patterns.

---

## What workflows are good for

LangGraph models an agent run as a **graph of nodes** with explicit edges. AgentFlow workflows surface that as a YAML document:

- **Multi-agent orchestration** with explicit handoff control — a router picks the next agent based on the conversation state, not on hidden tool-calling heuristics.
- **Human-in-the-loop** interrupts at any node, with state restoration on resume.
- **Per-node configuration** — each node carries its own LLM, system prompt, tools, and middleware stack.
- **Deterministic replay** — every run lands a checkpoint per superstep, so you can resume from a known state.

If your problem fits "one agent + tools," try `cas`, `oai`, or `agent-framework` first; they're lighter. If it's "agent A → agent B based on classification, then HITL approval, then writeback," workflows is the right fit.

---

## Supported features

| Feature | YAML surface | Notes |
| --- | --- | --- |
| Multi-agent graph | `nodes:` + `orchestrator.workflows:` | Each node is a complete agent (LLM + tools + system prompt) |
| Router agent | implicit | Picks the workflow to run from `orchestrator.workflows:` based on the user query |
| Human-in-the-loop | `interrupts:` on nodes | LangGraph `Command(resume=…)` plumbed through the CLI prompt |
| LLM providers | `llm.provider` | `openai`, `anthropic`, `azure_openai` (RBAC), Bedrock via custom |
| Per-node LLM override | `nodes.<name>.llm` | Mix reasoning + non-reasoning models in one graph |
| Built-in middleware | `middleware:` | `pii_redaction`, `tool_call_limit`, `prompt_caching`, `audit_log`, `cost_tracking`, `latency_tracking` |
| Custom Python plugins | `--tools` flag | Auto-detects `tools/` package or `tools.py` module in cwd |
| MCP servers | `mcp_servers:` | stdio / HTTP transports |
| Persistence | `--persistence` / `AGENTFLOW_PERSISTENCE` | SQLite (default) / Postgres; LangGraph checkpointer schema. Deploy-time concern — not in YAML |
| External A2A agents | `external_agents:` | Speak to remote A2A endpoints as nodes |
| OpenTelemetry tracing | `OTEL_TRACES_ENABLED=true` | Per-node + per-tool spans, `gen_ai.*` semconv |
| AES-GCM encryption at rest | `AGENTFLOW_ENCRYPTION_KEY` | Encrypts checkpointer payloads |
| CLI streaming | tokens / tool calls / thinking blocks | See [`docs/AGENTFLOW_CLI.md`](docs/AGENTFLOW_CLI.md) |
| `--output ndjson` | machine-readable event stream | One JSON event per line; schema in `agentflow.cli.events` |

---

## Minimal example

```yaml
backend: workflows

metadata:
  version: "1.0"
  name: customer-support
  description: Triage to billing or technical specialist

llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}

orchestrator:
  workflows:
    - billing
    - technical

nodes:
  billing:
    system_prompt: |
      You handle billing inquiries. Escalate refunds over $100.
  technical:
    system_prompt: |
      You handle technical questions. Pull up docs when needed.
```

Persistence is configured at deploy time, not in YAML — same agent
runs across dev / staging / prod with different storage backends:

```bash
# Local dev — defaults to SQLite at .agentflow/checkpoints.db
agentflow "your query"

# Custom SQLite path
agentflow --persistence sqlite --db-path /data/checkpoints.db "your query"

# Production — Postgres, configured via env
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
agentflow "your query"
```

Run with the unified CLI:

```bash
agentflow "I was charged twice last month"   # routes to billing
agentflow --interactive                       # REPL mode with /help, /clear, /stats
agentflow --output ndjson "your query" > events.ndjson
```

---

## Documentation

- [`docs/index.md`](docs/index.md) — overview and installation
- [`docs/WORKFLOW_YAML.md`](docs/WORKFLOW_YAML.md) — full YAML reference
- [`docs/AGENTFLOW_CLI.md`](docs/AGENTFLOW_CLI.md) — CLI flags, streaming output, `--output ndjson` schema
- [`docs/PERSISTENCE.md`](docs/PERSISTENCE.md) — checkpointer config, thread resume, `agentflow-threads`
- [`docs/HUMAN_IN_THE_LOOP.md`](docs/HUMAN_IN_THE_LOOP.md) — interrupt patterns
- [`docs/MIDDLEWARE.md`](docs/MIDDLEWARE.md) — built-in middleware tier
- [`docs/PLUGIN_SPECIFICATION.md`](docs/PLUGIN_SPECIFICATION.md) — custom Python tools
- [`docs/MCP.md`](docs/MCP.md) — MCP server integration
- [`docs/EXTERNAL_AGENTS.md`](docs/EXTERNAL_AGENTS.md) — A2A protocol
- [`docs/OBSERVABILITY.md`](docs/OBSERVABILITY.md) — OpenTelemetry tracing
- [`docs/PRODUCTION_FEATURES.md`](docs/PRODUCTION_FEATURES.md) — production deployment notes
- [`docs/tutorials/`](docs/tutorials/) — hands-on walkthroughs

Sibling backends: [`deep/`](../deep/) · [`sk/`](../sk/) · [`cas/`](../cas/) · [`oai/`](../oai/) · [`maf/`](../maf/)

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See the root [LICENSE](../../../LICENSE) for complete terms.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
