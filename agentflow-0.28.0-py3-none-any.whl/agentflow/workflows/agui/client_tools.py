"""Frontend-implemented (client-side) tool stubs for AG-UI.

The agent calls a ``@client_tools``-declared tool like any other tool;
the stub body pauses the run via :func:`langgraph.types.interrupt`. The
AG-UI bridge surfaces the pause as an Interrupt with
``reason: "agentflow:client_tool"`` and the proposed tool call's
``toolCallId`` + args. The browser executes the tool, then resumes the
run by posting a ``role: "tool"`` message in the next ``RunAgentInput``.

Optional ``available_when`` is a ``simpleeval`` expression evaluated by
:class:`agentflow.workflows.availability.WorkflowsAvailabilityMiddleware`
immediately before each model call, using the shared
:func:`agentflow.genui.evaluate_availability` engine. When falsy, the
tool is removed from the bound tools list — the LLM never sees it for
that turn and can't propose it. The stub body therefore doesn't need
to re-check the predicate; if the LLM got far enough to call the tool,
the middleware already let it through.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from langchain_core.tools import StructuredTool
from langgraph.types import interrupt
from pydantic import Field, create_model

if TYPE_CHECKING:
    from agentflow.genui import ClientToolConfig

logger = logging.getLogger(__name__)


_JSON_SCHEMA_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "array": list,
    "object": dict,
}


def _args_schema_from_json_schema(name: str, parameters: dict[str, Any]) -> type:
    """Build a Pydantic args-schema class from a JSON Schema object.

    The LLM uses this schema to decide how to call the tool; we don't need
    runtime validation (the args round-trip to the browser unchanged), so
    a permissive build is fine — every field is optional with type-hint
    sugar derived from the JSON Schema's ``type``.
    """
    props: dict[str, Any] = parameters.get("properties") or {}
    required: set[str] = set(parameters.get("required") or [])
    fields: dict[str, tuple[Any, Any]] = {}
    for prop_name, prop_schema in props.items():
        py_type = _JSON_SCHEMA_TYPE_MAP.get(prop_schema.get("type", "string"), Any)
        if prop_name in required:
            default = Field(..., description=prop_schema.get("description"))
        else:
            default = Field(description=prop_schema.get("description"))
        fields[prop_name] = (py_type, default)
    return create_model(f"{name}Args", **fields)  # type: ignore[call-overload]


def build_client_tool_stub(spec: "ClientToolConfig") -> StructuredTool:
    """Build a ``StructuredTool`` whose body pauses for the AG-UI client.

    The runtime body calls :func:`langgraph.types.interrupt` with a payload
    the AG-UI bridge translates into an Interrupt event. ``available_when``
    is enforced upstream by ``WorkflowsAvailabilityMiddleware`` (auto-attached
    by the workflows orchestrator); by the time we get here, the LLM already
    saw the tool in its bound list and decided to call it.
    """
    args_schema = _args_schema_from_json_schema(spec.name, spec.parameters)
    name = spec.name

    def stub(**kwargs) -> Any:
        return interrupt(
            {
                "type": "agentflow:client_tool",
                "tool_name": name,
                "args": kwargs,
            }
        )

    return StructuredTool.from_function(
        func=stub,
        name=name,
        description=spec.description,
        args_schema=args_schema,
    )


def build_client_tool_stubs(specs: list["ClientToolConfig"]) -> list[StructuredTool]:
    """Convenience: build a stub per declared client tool."""
    return [build_client_tool_stub(s) for s in specs]
