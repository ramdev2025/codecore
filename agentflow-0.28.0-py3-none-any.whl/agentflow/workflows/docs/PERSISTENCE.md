# Persistence in AgentFlow

This guide explains how persistence works in AgentFlow, supporting both SQLite and PostgreSQL backends.

## Overview

AgentFlow provides flexible persistence options to maintain conversation state across interactions:

- **SQLite** (default): File-based persistence, ideal for development and single-instance deployments
- **PostgreSQL**: Scalable persistence for production multi-instance deployments, with support for long-term memory via
  store

The persistence layer uses async/await patterns and requires proper initialization and cleanup.

## Backends

### SQLite (Default)

**What it is:**

- Uses LangGraph's `AsyncSqliteSaver` for lightweight persistence
- Stores state in SQLite database on disk
- State persists across application restarts
- Checkpointer only (store not supported)

**When to use:**

- Development and testing
- Single-instance deployments
- Simple production scenarios with low concurrency
- When you don't need long-term memory (store)

**Characteristics:**

- Zero configuration required
- File-based storage
- Simple file-based persistence

**Dependencies:**

```bash
pip install aiosqlite langgraph-checkpoint-sqlite
```

### PostgreSQL

**What it is:**

- Uses LangGraph's `AsyncPostgresSaver` for checkpointing
- Optionally uses `AsyncPostgresStore` for long-term memory
- Scalable connection pooling
- Full ACID compliance

**When to use:**

- Production multi-instance deployments
- High concurrency scenarios
- When you need long-term memory (store)
- Horizontal scaling requirements

**Characteristics:**

- Scalable connection pooling
- Supports both checkpointer and store
- Environment variable support for secure credentials
- Automatic schema migrations

**Dependencies:**

```bash
pip install agentflow[postgres]
# Or manually:
pip install langgraph-checkpoint-postgres psycopg[binary,pool]
```

## Configuration

Persistence is **infrastructure, not business logic** — the same
`workflow.yaml` should run unchanged in dev, staging, and production.
That means the backend choice (SQLite vs Postgres) belongs in CLI
flags or environment variables, not in the YAML itself.

AgentFlow resolves persistence in this order (highest to lowest):

1. **Programmatic `persistence_config=` parameter** — an explicit
   `PersistenceConfig` passed to `AsyncWorkflowOrchestrator` wins over
   everything.
2. **CLI flags** (`--persistence`, `--db-path`, `--connection-string`).
3. **Environment variables** — the full set below.
4. **Default** — SQLite at `.agentflow/checkpoints.db`.

### The environment contract applies everywhere

Every environment variable on this page is read the same way regardless of
how AgentFlow is started: the `agentflow` CLI, `build_agui`, a direct
`AsyncWorkflowOrchestrator.create(...)`, or any other embedding app. There is
one resolver behind all of them.

This matters if you embed AgentFlow as a library. Before 0.28.0 the CLI had
its own copy of this logic, and apps that never went through it silently
ignored `AGENTFLOW_PERSISTENCE`, `AGENTFLOW_STORE_ENABLED`,
`AGENTFLOW_ENCRYPTION_KEY` and the whole `POSTGRES_POOL_*` family — so a
deployment could set an encryption key and still write checkpoints in the
clear. If you are embedding AgentFlow, upgrade to 0.28.0 and re-check which of
these variables your environment sets, because they now take effect.

> **Deprecated:** a top-level `persistence:` section in `workflow.yaml`
> is no longer consulted. Apps that still ship one will log a
> deprecation warning at startup and fall through to the resolution
> order above. Remove the block from your YAML to silence the warning.

### Option 1: CLI flags (recommended for deployment)

The same YAML runs everywhere — choose the backend at deploy time:

```bash
# Local dev — SQLite (default if nothing is set)
agentflow --yaml workflow.yaml "Hello"

# Local dev — SQLite at a custom path
agentflow --yaml workflow.yaml --db-path /tmp/dev.db "Hello"

# Production — Postgres
agentflow --yaml workflow.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" "Hello"

# Stateless / one-shot runs
agentflow --yaml workflow.yaml --persistence memory "Hello"
```

### Option 2: Environment variables

For containerized deployments where CLI flags are inconvenient, every
persistence setting is reachable through environment variables. CLI
flags win over env vars when both are set; env vars win over the
built-in defaults.

**Selecting env vars** (any one triggers a persistence configuration):

| Variable                       | Value                       | Effect                                                                 |
|--------------------------------|-----------------------------|------------------------------------------------------------------------|
| `AGENTFLOW_PERSISTENCE`        | `memory` / `sqlite` / `postgres` | Choose the backend explicitly. Case-insensitive.                      |
| `POSTGRES_CONNECTION_STRING`   | `postgresql://user:pass@host/db` | Implies `postgres`. Required when the backend is Postgres.            |
| `CHECKPOINTER_DB_PATH`         | `/path/to/checkpoints.db`   | Implies `sqlite`. Sets the SQLite file path.                          |

**Tuning env vars** (only patch the resulting config — set one of the
selectors above first):

| Variable                                  | Value                | Effect                                                       |
|-------------------------------------------|----------------------|--------------------------------------------------------------|
| `POSTGRES_POOL_SIZE`                      | integer (default `5`) | Maximum connections in the pool (`max_size`).                |
| `POSTGRES_POOL_MIN_SIZE`                  | integer (default `1`) | Connections the pool keeps open at all times.                |
| `POSTGRES_POOL_MAX_LIFETIME`              | seconds (default `600`) | Retire and reopen a connection after this long.            |
| `POSTGRES_POOL_MAX_IDLE`                  | seconds (default `300`) | Trim idle connections above `min_size` after this long.    |
| `POSTGRES_POOL_CHECK`                     | bool (default `true`) | Validate each connection as it is handed out.                |
| `POSTGRES_POOL_TIMEOUT`                   | seconds (default `30`) | How long to wait for a free connection.                     |
| `AGENTFLOW_STORE_ENABLED`                 | `1` / `true` / `yes` / `on` | Enable the long-term memory store (Postgres only).           |
| `AGENTFLOW_ENCRYPTION_KEY`    | 16 / 24 / 32-byte key | AES key for at-rest checkpoint encryption (requires pycryptodome). |

**Examples:**

```bash
# Postgres in prod, with pool tuning and store enabled
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="postgresql://user:pass@host/db"
export POSTGRES_POOL_SIZE=20
export AGENTFLOW_STORE_ENABLED=true

# SQLite at a non-default path, with encryption at rest
export AGENTFLOW_PERSISTENCE=sqlite
export CHECKPOINTER_DB_PATH="/data/agentflow/checkpoints.db"
export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -hex 16)"

# Stateless / one-shot — disable persistence entirely
export AGENTFLOW_PERSISTENCE=memory
```

Validation errors (bad backend name, non-integer pool size, missing
Postgres connection string) surface as friendly CLI errors at startup,
before any agent code runs.

### Option 3: Programmatic Configuration

Create a `PersistenceConfig` and pass it to the orchestrator:

```python
from agentflow import AsyncWorkflowOrchestrator
from agentflow.core.config_models import (
    PersistenceConfig,
    PersistenceBackend,
    PostgresConfig,
    SQLiteConfig,
    CheckpointerConfig,
    StoreConfig,
)

# SQLite configuration
sqlite_config = PersistenceConfig(
    backend=PersistenceBackend.SQLITE,
    sqlite=SQLiteConfig(
        db_path=".agentflow/checkpoints.db",
    ),
    checkpointer=CheckpointerConfig(enabled=True),
)

# PostgreSQL configuration
postgres_config = PersistenceConfig(
    backend=PersistenceBackend.POSTGRES,
    postgres=PostgresConfig(
        connection_string="${DATABASE_URL}",
        pool_size=10
    ),
    checkpointer=CheckpointerConfig(enabled=True),
    store=StoreConfig(enabled=True),
)

# Use with orchestrator
orchestrator = await AsyncWorkflowOrchestrator.create(
    config_path="workflow.yaml",
    tools_module="my_tools",
    persistence_config=postgres_config,  # Takes priority over YAML
)
```

### Option 4: Legacy Parameters (Backward Compatible)

For backward compatibility, you can still use the original constructor parameters:

```python
orchestrator = await AsyncWorkflowOrchestrator.create(
    config_path="workflow.yaml",
    tools_module="my_tools",
    enable_persistence=True,
    checkpointer_path=".agentflow/checkpoints.db"
)
```

This creates a SQLite backend with the specified path.

## Configuration Reference

### PersistenceConfig Fields

| Field          | Type                   | Default               | Description                      |
|----------------|------------------------|-----------------------|----------------------------------|
| `backend`      | `sqlite` \| `postgres` | `sqlite`              | Persistence backend type         |
| `sqlite`       | `SQLiteConfig`         | auto-created          | SQLite-specific settings         |
| `postgres`     | `PostgresConfig`       | required for postgres | PostgreSQL-specific settings     |
| `checkpointer` | `CheckpointerConfig`   | enabled               | Checkpointer settings            |
| `store`        | `StoreConfig`          | disabled              | Store settings (PostgreSQL only) |

### SQLiteConfig Fields

| Field     | Type  | Default                     | Description                  |
|-----------|-------|-----------------------------|------------------------------|
| `db_path` | `str` | `.agentflow/checkpoints.db` | Path to SQLite database file |

### PostgresConfig Fields

| Field               | Type  | Default  | Description                  |
|---------------------|-------|----------|------------------------------|
| `connection_string` | `str`   | required | PostgreSQL connection string                                  |
| `pool_size`         | `int`   | `5`      | Maximum connections in the pool (`max_size`)                  |
| `min_size`          | `int`   | `1`      | Connections kept open at all times                            |
| `max_lifetime`      | `float` | `600.0`  | Seconds before a connection is retired and reopened           |
| `max_idle`          | `float` | `300.0`  | Seconds an idle connection above `min_size` is kept           |
| `check_connection`  | `bool`  | `true`   | Validate connections on checkout, replacing dead ones         |
| `connect_timeout`   | `float` | `30.0`   | Seconds to wait for a free connection before `PoolTimeout`    |

### Connection pooling and resilience

The checkpointer and store share a single `psycopg_pool` connection pool, and
each borrows a connection per operation rather than holding one open.

This matters for availability, not just throughput. A single long-lived
connection that gets closed underneath the process — by a database restart, a
failover, a server-side `idle_session_timeout`, or a cloud load balancer
reaping an idle TCP flow — is marked `CONNECTION_BAD` by libpq, and that flag
is never cleared. psycopg does not reconnect, so **every** subsequent agent
turn fails with `OperationalError: the connection is closed` until the process
is restarted. Non-agent routes keep serving normally, which makes it look like
an agent bug rather than a connection one.

Two settings prevent that, both on by default:

- **`check_connection`** (reactive) validates a connection as it is handed out.
  A connection that died while idle is discarded and replaced before your code
  sees it. Costs one round-trip per checkout.
- **`max_lifetime`** (proactive) retires connections on a timer so they never
  live long enough to be reaped. Note that `max_idle` alone does *not* cover
  this: it only trims connections *above* `min_size`, so a pool sitting at
  `min_size: 1` would keep its single connection forever.

Leave both enabled unless you have measured a reason not to. If you disable
`check_connection` for latency, raise `min_size` and lower `max_lifetime` so
the pool still rotates connections regularly.

Sizing note: managed PostgreSQL instances often cap total connections, and
each application replica opens its own pool. Budget `pool_size × replicas`
against that cap.

#### Where pool settings can come from

`PostgresConfig` reads the `POSTGRES_POOL_*` variables itself, so tuning works
from every entry point — the CLI, `build_agui` and other embedding apps, the
`deep` backend, and direct `PostgresConfig(...)` construction. Precedence is
**explicit value > environment variable > default**:

```python
# Environment alone — the usual case for a deployment.
#   POSTGRES_POOL_SIZE=20 POSTGRES_POOL_CHECK=false
PostgresConfig(connection_string=dsn).pool_size          # -> 20

# An explicit value still wins, per field.
PostgresConfig(connection_string=dsn, pool_size=7).pool_size          # -> 7
PostgresConfig(connection_string=dsn, pool_size=7).check_connection   # -> False
```

A malformed value (`POSTGRES_POOL_SIZE=lots`) raises at startup rather than
silently reverting to the default, and the field constraints still apply — an
out-of-range `POSTGRES_POOL_SIZE=999` is rejected, not clamped.

#### Confirming the settings took effect

The effective pool is logged once at startup, at `INFO`:

```
INFO agentflow.workflows.core.persistence_manager: PostgreSQL connection pool
opened (min_size=1, max_size=20, max_lifetime=600.0s, max_idle=300.0s,
check_connection=False)
```

Those are the resolved values, so this is the quickest way to confirm an
environment variable actually landed. AgentFlow's own loggers default to
`WARNING`, so on the CLI pass `-v` (or set `AGENTFLOW_LOG_LEVEL=INFO`) to see
it. Embedding apps that configure logging at `INFO` already get it.

### CheckpointerConfig Fields

| Field     | Type   | Default | Description                     |
|-----------|--------|---------|---------------------------------|
| `enabled` | `bool` | `true`  | Whether to enable checkpointing |

### StoreConfig Fields

| Field     | Type   | Default | Description                               |
|-----------|--------|---------|-------------------------------------------|
| `enabled` | `bool` | `false` | Whether to enable store (PostgreSQL only) |

## Environment Variables

See the env-var section near the top of this file ("Option 2:
Environment variables") for the complete table. The short version:

```bash
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="postgresql://user:password@localhost:5432/agentflow"
```

The runtime picks these up automatically when the matching CLI flag
isn't passed. There's no YAML interpolation step — persistence config
doesn't live in the YAML.

## Usage Patterns

### Pattern 1: Async Factory Method (Recommended)

```python
from agentflow import AsyncWorkflowOrchestrator

# Create orchestrator (reads persistence config from YAML)
orchestrator = await AsyncWorkflowOrchestrator.create(
    config_path="workflow.yaml",
    tools_module="my_tools",
)

# Use the orchestrator
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "Hello"}]},
    config={"configurable": {"thread_id": "user-123"}}
):
    print(event)

# Clean up when done (important!)
await orchestrator.cleanup()
```

### Pattern 2: Async Context Manager (Best Practice)

```python
from agentflow import AsyncWorkflowOrchestrator

async with AsyncWorkflowOrchestrator(
    config_path="workflow.yaml",
    tools_module="my_tools",
) as orchestrator:
    async for event in orchestrator.run(
        state={"messages": [{"role": "user", "content": "Hello"}]},
        config={"configurable": {"thread_id": "user-123"}}
    ):
        print(event)

# Cleanup happens automatically
```

## Thread-Based Isolation

AgentFlow uses **thread IDs** to maintain separate conversation states. Each unique `thread_id` represents an isolated
conversation with its own checkpoint history.

```python
# User 1's conversation
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "My name is Alice"}]},
    config={"configurable": {"thread_id": "user-001"}}
):
    print(event)

# User 2's separate conversation
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "My name is Bob"}]},
    config={"configurable": {"thread_id": "user-002"}}
):
    print(event)

# Resume User 1's conversation (remembers "Alice")
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "What's my name?"}]},
    config={"configurable": {"thread_id": "user-001"}}
):
    print(event)  # Will respond with "Alice"
```

### Thread ID Best Practices

1. **Use unique IDs per user/session**: Generate UUIDs or use user IDs
2. **Be consistent**: Always use the same thread_id to resume a conversation
3. **Consider namespacing**: Use prefixes like `"user-{id}"` or `"session-{uuid}"`

## FastAPI Integration

### With SQLite

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow import AsyncWorkflowOrchestrator

orchestrator = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global orchestrator

    # Startup — persistence defaults to SQLite at .agentflow/checkpoints.db.
    # Override via env vars (POSTGRES_CONNECTION_STRING / CHECKPOINTER_DB_PATH /
    # AGENTFLOW_PERSISTENCE) or pass an explicit PersistenceConfig kwarg.
    orchestrator = await AsyncWorkflowOrchestrator.create(
        config_path="workflow.yaml",
        tools_module="my_tools",
    )
    print("Orchestrator initialized")
    yield

    # Shutdown
    await orchestrator.cleanup()
    print("Orchestrator cleaned up")

app = FastAPI(lifespan=lifespan)
```

### With PostgreSQL

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow import AsyncWorkflowOrchestrator
from agentflow.core.config_models import (
    PersistenceConfig,
    PersistenceBackend,
    PostgresConfig,
    CheckpointerConfig,
    StoreConfig,
)

orchestrator = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global orchestrator

    # Startup - PostgreSQL with checkpointer and store
    persistence_config = PersistenceConfig(
        backend=PersistenceBackend.POSTGRES,
        postgres=PostgresConfig(
            connection_string="${DATABASE_URL}",
            pool_size=20  # Higher pool size for production
        ),
        checkpointer=CheckpointerConfig(enabled=True),
        store=StoreConfig(enabled=True),
    )

    orchestrator = await AsyncWorkflowOrchestrator.create(
        config_path="workflow.yaml",
        tools_module="my_tools",
        persistence_config=persistence_config,
    )
    print("Orchestrator initialized with PostgreSQL")
    yield

    # Shutdown - closes connection pools
    await orchestrator.cleanup()
    print("Orchestrator cleaned up")

app = FastAPI(lifespan=lifespan)
```

## Checkpointer vs Store

AgentFlow supports two types of persistence:

### Checkpointer

- **Purpose**: Saves workflow state at each step
- **Use case**: Conversation continuity, workflow resumption
- **Supported backends**: SQLite, PostgreSQL
- **Enabled by default**: Yes

### Store (PostgreSQL only)

- **Purpose**: Long-term memory across conversations
- **Use case**: User preferences, learned information, cross-session context
- **Supported backends**: PostgreSQL only
- **Enabled by default**: No

```bash
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
export AGENTFLOW_STORE_ENABLED=true        # opt into long-term memory store
agentflow --yaml workflow.yaml "..."
```

## Troubleshooting

### SQLite Issues

#### Database locked

**Symptom:**

```
sqlite3.OperationalError: database is locked
```

**Solution:**

- Ensure you're calling `.cleanup()` or using context manager
- Check that only one process is accessing the database
- Use PostgreSQL for high-concurrency deployments
- Consider using separate database files for different services

#### Dependencies not available

**Symptom:**

```
SQLite dependencies not available
```

**Solution:**

```bash
pip install aiosqlite langgraph-checkpoint-sqlite
```

### PostgreSQL Issues

#### Connection refused

**Symptom:**

```
connection refused
```

**Solution:**

- Verify PostgreSQL is running: `pg_isready`
- Check connection string format
- Verify network connectivity to database host

#### Authentication failed

**Symptom:**

```
password authentication failed
```

**Solution:**

- Verify credentials in connection string
- Check that user has access to the database
- Ensure DATABASE_URL environment variable is set correctly

#### `the connection is closed` on every agent turn

**Symptom:**

```
psycopg.OperationalError: the connection is closed
```

Every agent request fails, typically starting after a period of inactivity or
a database maintenance window, and keeps failing until the process restarts.
Non-agent routes still return 200. The traceback bottoms out in
`AsyncPostgresSaver._cursor()` and fails in milliseconds with no network I/O.

**Cause:** the process is holding a PostgreSQL connection that the server
closed. This was the behaviour before AgentFlow 0.28.0, which held one
connection for the orchestrator's lifetime.

**Solution:**

- Upgrade to AgentFlow 0.28.0 or later, which pools connections and validates
  them on checkout. No configuration change is required — the protections are
  on by default.
- Verify you have not disabled them: `POSTGRES_POOL_CHECK` should be unset or
  truthy, and `POSTGRES_POOL_MAX_LIFETIME` should be comfortably below any
  idle timeout enforced by your database or load balancer.
- If you cannot upgrade immediately, adding libpq keepalives to the connection
  string keeps the socket from going idle:

  ```
  ...?sslmode=require&keepalives=1&keepalives_idle=30&keepalives_interval=10&keepalives_count=5
  ```

  This is config-only and needs no new build, but it only helps when an *idle*
  timeout is what closed the connection. It does nothing for a server restart
  or failover. Treat it as a stopgap, not a fix.

#### Missing dependencies

**Symptom:**

```
PostgreSQL checkpointer requires 'langgraph-checkpoint-postgres' package
```

**Solution:**

```bash
pip install agentflow[postgres]
```

#### Store not supported with SQLite

**Symptom:**

```
Store is not supported with SQLite backend
```

**Solution:**

- Use PostgreSQL backend for store functionality
- Or disable store: `store.enabled: false`

### General Issues

#### Thread ID not persisting state

**Symptom:**
Conversation state is not preserved between calls with the same thread_id.

**Solution:**

- Verify persistence is enabled in configuration
- Check that thread_id is exactly the same between calls
- Verify the database file/connection is accessible
- Check logs for any persistence errors

#### Environment variable not set

**Symptom:**

```
Environment variable 'DATABASE_URL' is not set
```

**Solution:**

```bash
export DATABASE_URL="postgresql://user:pass@localhost:5432/dbname"
```

Or add to `.env` file and use `python-dotenv`.

## Migration Guide

### From YAML `persistence:` to CLI / env (deprecation)

A top-level `persistence:` section in `workflow.yaml` is deprecated.
The orchestrator logs a warning and falls through to CLI / env-based
resolution, so existing apps keep running — but you should remove the
block so the same YAML stays portable across dev / staging / prod.

**Before (deprecated — pinned to one environment):**

```yaml
# workflow.yaml
persistence:
  backend: postgres
  postgres:
    connection_string: "${DATABASE_URL}"
  checkpointer:
    enabled: true
```

**After (portable — same YAML everywhere):**

```yaml
# workflow.yaml — no persistence section
```

Then choose the backend per environment at runtime:

```bash
# dev
agentflow --yaml workflow.yaml "Hello"

# prod
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
agentflow --yaml workflow.yaml "Hello"
# — or —
agentflow --yaml workflow.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" "Hello"
```

### From SQLite to PostgreSQL

1. Install PostgreSQL dependencies:
   ```bash
   pip install agentflow[postgres]
   ```

2. Set up the PostgreSQL database:
   ```bash
   createdb agentflow
   ```

3. Point the app at it via env or CLI — no YAML change required:
   ```bash
   export POSTGRES_CONNECTION_STRING="postgresql://user:pass@localhost:5432/agentflow"
   agentflow --yaml workflow.yaml "Hello"
   ```
   or
   ```bash
   agentflow --yaml workflow.yaml \
     --persistence postgres \
     --connection-string "postgresql://user:pass@localhost:5432/agentflow" \
     "Hello"
   ```

## Additional Resources

- **Source Code**:
    - Persistence Manager: `src/agentflow/core/persistence_manager.py`
    - Config Models: `src/agentflow/core/config_models.py`
    - Orchestrator: `src/agentflow/core/orchestrator.py`

## Summary

| Feature                  | SQLite                         | PostgreSQL                   |
|--------------------------|--------------------------------|------------------------------|
| Checkpointer             | Yes                            | Yes                          |
| Store (long-term memory) | No                             | Yes                          |
| Multi-instance           | Limited                        | Yes                          |
| Setup complexity         | None                           | Requires DB                  |
| Scalability              | Single instance                | Horizontal                   |
| Best for                 | Development, simple production | Production, high concurrency |

**Quick Start:**

```bash
# SQLite (default — zero config, no YAML changes needed)
agentflow --yaml workflow.yaml "..."

# SQLite at a custom path
agentflow --yaml workflow.yaml --persistence sqlite --db-path /data/state.db "..."

# PostgreSQL (scalable)
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
export AGENTFLOW_STORE_ENABLED=true        # opt into long-term memory store
agentflow --yaml workflow.yaml "..."
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
