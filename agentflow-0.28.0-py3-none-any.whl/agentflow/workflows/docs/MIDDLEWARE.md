# AgentFlow Middleware Support

This document describes the LangChain middleware integration for AgentFlow, enabling per-node middleware configuration
via YAML.

## Overview

AgentFlow supports LangChain's middleware system, which provides hooks for intercepting and modifying agent behavior at
the LLM call level. Middleware can:

- Transform state before/after model calls
- Limit model or tool invocations
- Require human approval for specific tools
- Summarize long conversations
- Implement fallback strategies
- Add custom behavior

## Middleware vs AgentFlow Plugins

AgentFlow provides two complementary extension mechanisms: **Middleware** and **Plugins**. Understanding their
differences helps you choose the right approach for your use case.

### Key Differences

| Aspect               | Middleware                             | Plugins                            |
|----------------------|----------------------------------------|------------------------------------|
| **Configuration**    | YAML (per-node)                        | Code/environment (global)          |
| **Scope**            | Per-agent (LLM call level)             | Per-workflow (lifecycle events)    |
| **Modify state**     | Yes - can transform messages and state | No - read-only observation         |
| **Execution point**  | Inside agent loop (around model calls) | Outside agent (workflow lifecycle) |
| **Primary use case** | Behavior modification & control        | Observability & telemetry          |
| **Distribution**     | LangChain packages or custom classes   | AgentFlow plugin packages (.zip)   |

### When to Use Middleware

Use middleware when you need to:

- **Modify agent behavior**: Intercept and transform model requests/responses
- **Control execution**: Limit model calls, require human approval, implement retries
- **Manage context**: Summarize long conversations, filter sensitive data
- **Add fallbacks**: Try alternative models when primary fails

**Example**: Requiring human approval before executing a `refund_order` tool.

```yaml
middleware:
  - type: human_in_the_loop
    human_in_the_loop:
      tools:
        - refund_order
```

### When to Use Plugins

Use plugins when you need to:

- **Observe execution**: Track workflow events without modifying behavior
- **Collect telemetry**: Log metrics, traces, and spans to external systems
- **Monitor performance**: Measure latency, token usage, error rates
- **Audit activity**: Record what happened for compliance/debugging

**Example**: Sending traces to Jaeger for distributed tracing.

```python
from agentflow.plugins import Plugin


class TracingPlugin(Plugin):
    def on_workflow_start(self, context, state):
        self.start_span(context.workflow_name)

    def on_workflow_end(self, context, state, status):
        self.end_span(status)
```

### How They Work Together

Middleware and plugins operate at different layers and complement each other:

```
┌─────────────────────────────────────────────────────────┐
│                    Workflow Execution                    │
│  ┌───────────────────────────────────────────────────┐  │
│  │  Plugin: on_workflow_start()                      │  │
│  │  ┌─────────────────────────────────────────────┐  │  │
│  │  │  Plugin: on_agent_start()                   │  │  │
│  │  │  ┌───────────────────────────────────────┐  │  │  │
│  │  │  │  Middleware: before_model()           │  │  │  │
│  │  │  │  ┌─────────────────────────────────┐  │  │  │  │
│  │  │  │  │       LLM Model Call            │  │  │  │  │
│  │  │  │  └─────────────────────────────────┘  │  │  │  │
│  │  │  │  Middleware: after_model()            │  │  │  │
│  │  │  └───────────────────────────────────────┘  │  │  │
│  │  │  Plugin: on_agent_end()                     │  │  │
│  │  └─────────────────────────────────────────────┘  │  │
│  │  Plugin: on_workflow_end()                        │  │
│  └───────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

A typical production setup might use both:

- **Middleware**: `model_call_limit` to prevent runaway agents, `summarization` to manage context
- **Telemetry**: OpenTelemetry tracing is built in (native, opt-in via `OTEL_TRACES_ENABLED`); use **plugins** for custom metrics/audit/cost

### Summary

| Need                                         | Solution                         |
|----------------------------------------------|----------------------------------|
| Limit model calls to prevent runaway costs   | Middleware (`model_call_limit`)  |
| Track execution time for dashboards          | Plugin (telemetry)               |
| Require human approval for sensitive actions | Middleware (`human_in_the_loop`) |
| Log all tool calls to audit system           | Plugin (logging)                 |
| Summarize long conversations                 | Middleware (`summarization`)     |
| Send traces to Jaeger/Zipkin                 | Plugin (OpenTelemetry)           |

## Built-in Middleware Types

AgentFlow supports the following built-in LangChain middleware types:

| Type                | Description                                    |
|---------------------|------------------------------------------------|
| `summarization`     | Summarize long conversations to reduce context |
| `human_in_the_loop` | Require human approval for specific tools      |
| `model_call_limit`  | Limit the number of model calls                |
| `tool_call_limit`   | Limit the number of tool calls                 |
| `model_fallback`    | Try fallback models on failure                 |
| `tool_retry`        | Retry failed tool calls                        |
| `pii`               | PII detection and handling                     |
| `llm_tool_selector` | LLM-based tool selection                       |

## YAML Configuration

Middleware is configured per-node in the `nodes` section:

```yaml
nodes:
  support_agent:
    description: "Customer support agent"
    system_prompt: "You are a helpful support agent."
    tools:
      - lookup_order
      - create_ticket
    middleware:
      # Summarize long conversations
      - type: summarization
        summarization:
          model: "anthropic:claude-sonnet-4-20250514"
          trigger_messages: 20
          keep_messages: 5

      # Limit runaway agents
      - type: model_call_limit
        model_call_limit:
          run_limit: 15
          exit_behavior: end

      # Human approval for escalation
      - type: human_in_the_loop
        human_in_the_loop:
          interrupt_on:
            escalate_to_manager:
              allowed_decisions: ["approve", "reject"]
```

### Middleware Configuration Structure

Each middleware entry supports:

| Field     | Type    | Required | Description                                  |
|-----------|---------|----------|----------------------------------------------|
| `type`    | string  | Yes*     | Built-in middleware type                     |
| `custom`  | object  | Yes*     | Custom middleware config                     |
| `enabled` | boolean | No       | Whether middleware is active (default: true) |
| `<type>`  | object  | No       | Type-specific configuration                  |

*Either `type` or `custom` must be specified, but not both.

## Built-in Middleware Configuration

See [LangChain Middleware Documentation](https://docs.langchain.com/oss/python/langchain/middleware/built-in) for full
details.

### Summarization

Summarizes conversation history when it becomes too long:

```yaml
- type: summarization
  summarization:
    model: "anthropic:claude-sonnet-4-20250514"  # Required: model for summaries
    trigger_messages: 20      # Trigger after N messages
    trigger_tokens: 4000      # OR trigger after N tokens
    keep_messages: 5          # Keep last N messages after summarization
```

### Model Call Limit

Prevents runaway agents by limiting model invocations:

```yaml
- type: model_call_limit
  model_call_limit:
    run_limit: 15             # Max model calls per invocation
    thread_limit: 100         # Max across all runs in thread (optional)
    exit_behavior: end        # "end" (graceful) or "error" (raise exception)
```

### Tool Call Limit

Limits the number of tool calls an agent can make:

```yaml
- type: tool_call_limit
  tool_call_limit:
    tool_name: null           # Specific tool (null for global)
    run_limit: 10             # Max tool calls per invocation
    exit_behavior: end        # "continue", "end", or "error"
```

### Human-in-the-Loop

Requires human approval before executing specific tools:

```yaml
- type: human_in_the_loop
  human_in_the_loop:
    interrupt_on:
      delete_record:
        allowed_decisions: ["approve", "reject"]
      escalate_to_manager:
        allowed_decisions: ["approve", "edit", "reject"]
      refund_order:
        allowed_decisions: ["approve", "reject"]
```

> **Note: Middleware HITL vs Tool-Based HITL**
>
> AgentFlow provides **two** human-in-the-loop mechanisms that serve different purposes:
>
> | Aspect | Middleware HITL | Tool-Based HITL |
> |--------|-----------------|-----------------|
> | **Trigger** | Automatic (system-enforced) | Agent decides when to call |
> | **Configuration** | YAML middleware config | Custom tools with `interrupt()` |
> | **Use case** | Mandatory approval for dangerous tools | Agent asks when uncertain |
> | **Documentation** | This page | [Human in the Loop Guide](HUMAN_IN_THE_LOOP.md) |
>
> **Middleware HITL** (this feature): The system automatically intercepts calls to configured tools and requires
> approval—the agent has no choice.
>
> **Tool-Based HITL** (existing): The agent explicitly calls `request_human_approval()` when it decides human input is
> needed—the agent has discretion.
>
> **When to use which:**
> - Use **middleware HITL** for mandatory guardrails (e.g., always require approval before `delete_account`)
> - Use **tool-based HITL** for agent judgment calls (e.g., agent asks when confidence is low)
>
> **Avoid combining both** for the same tool, as this would result in double-prompting.

### Model Fallback

Tries fallback models when the primary model fails:

```yaml
- type: model_fallback
  model_fallback:
    fallback_models:
      - gpt-4-turbo
      - gpt-3.5-turbo
```

### Tool Retry

Retries failed tool calls with configurable attempts:

```yaml
- type: tool_retry
  tool_retry:
    max_retries: 3            # Maximum retry attempts
    retry_on:                 # Optional: specific exceptions
      - ConnectionError
      - TimeoutError
```

## Custom Middleware

For advanced use cases, you can specify custom middleware classes:

```yaml
nodes:
  secure_agent:
    description: "Agent with custom security middleware"
    system_prompt: "You are a secure agent."
    middleware:
      - custom:
          class_name: "mycompany.middleware.AuditMiddleware"
          config:
            log_level: "INFO"
            audit_destination: "s3://audit-logs"

      - custom:
          class_name: "mycompany.middleware.ComplianceMiddleware"
          config:
            regulations:
              - GDPR
              - CCPA
```

### Implementing Custom Middleware

Custom middleware must follow the LangChain middleware interface:

```python
# mycompany/middleware.py

class AuditMiddleware:
    """Custom middleware for audit logging."""

    def __init__(self, log_level: str = "INFO", audit_destination: str = None):
        self.log_level = log_level
        self.audit_destination = audit_destination

    async def before_model(self, state, config):
        """Called before each model invocation."""
        # Log the request
        self._log_request(state)
        return state

    async def after_model(self, state, response, config):
        """Called after each model invocation."""
        # Log the response
        self._log_response(response)
        return response

    async def modify_model_request(self, request, config):
        """Modify the model request before sending."""
        # Add audit headers or modify request
        return request
```

## Enabling/Disabling Middleware

Middleware can be temporarily disabled without removing the configuration:

```yaml
middleware:
  - type: summarization
    enabled: false            # Disabled for now
    summarization:
      model: "anthropic:claude-sonnet-4-20250514"
      trigger_messages: 20

  - type: model_call_limit
    enabled: true             # Active (default)
    model_call_limit:
      run_limit: 15
```

## Middleware Ordering

Middleware is applied in the order specified in the YAML configuration. The first middleware in the list is executed
first (outermost), and the last is executed closest to the model call (innermost).

```yaml
middleware:
  # 1. First: Check limits
  - type: model_call_limit
    model_call_limit:
      run_limit: 15

  # 2. Second: Summarize if needed
  - type: summarization
    summarization:
      model: "anthropic:claude-sonnet-4-20250514"
      trigger_messages: 20

  # 3. Third (closest to model): Human approval
  - type: human_in_the_loop
    human_in_the_loop:
      interrupt_on:
        dangerous_action:
          allowed_decisions: ["approve", "reject"]
```

## Complete Example

```yaml
metadata:
  version: "1.0"
  name: "Customer Support Workflow"

llm:
  provider: anthropic
  config:
    model: claude-sonnet-4-20250514

orchestrator:
  workflows:
    - customer_support
  default_response: "I'm sorry, I couldn't understand your request."

workflows:
  customer_support:
    description: "Handle customer inquiries"
    nodes:
      support_agent:
        depends_on: []

nodes:
  support_agent:
    description: "Main support agent with middleware"
    system_prompt: |
      You are a helpful customer support agent.
      Be concise and professional.
    tools:
      - lookup_order
      - create_ticket
      - refund_order
      - escalate_to_manager
    middleware:
      # Prevent runaway conversations
      - type: model_call_limit
        model_call_limit:
          run_limit: 20
          exit_behavior: end

      # Keep context manageable
      - type: summarization
        summarization:
          model: "anthropic:claude-sonnet-4-20250514"
          trigger_messages: 15
          keep_messages: 5

      # Require approval for sensitive operations
      - type: human_in_the_loop
        human_in_the_loop:
          interrupt_on:
            refund_order:
              allowed_decisions: ["approve", "reject"]
            escalate_to_manager:
              allowed_decisions: ["approve", "reject"]

      # Retry on transient failures
      - type: tool_retry
        tool_retry:
          max_retries: 2
```

(Persistence is configured at deploy time, not in YAML — see
[PERSISTENCE.md](PERSISTENCE.md).)

## Troubleshooting

### Middleware Not Loading

If middleware is not being applied:

1. Check that the middleware configuration is under a valid node
2. Verify the middleware type is spelled correctly
3. Ensure `enabled: false` is not set
4. Check the console for import errors

### Custom Middleware Import Errors

For custom middleware:

1. Ensure the module is in the Python path
2. Verify the class name is spelled correctly
3. Check that all required dependencies are installed
4. Validate the constructor accepts the provided config parameters

### Performance Considerations

- Middleware adds overhead to each model call
- Use `trigger_messages` over `trigger_tokens` for summarization (less computation)
- Disable unused middleware in production
- Order middleware from least to most expensive operations

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
