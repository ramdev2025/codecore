# Workflow YAML Configuration Reference

This document provides a complete reference for the `workflow.yaml` configuration file structure in AgentFlow.

## Overview

AgentFlow supports two modes:

- **Standalone agent** — a single agent with tools, defined with the `agent:` keyword
- **Multi-agent workflows** — an orchestrator that routes to specialized workflows, defined with `orchestrator:` + `workflows:`

Both modes share the same infrastructure: LLM providers, MCP servers, middleware,
persistence, telemetry, and streaming.

The workflow.yaml file defines:

- **Metadata** - Information about the configuration file
- **LLM Configuration** - Global, per-workflow, and per-node LLM settings
- **Agent** - Standalone agent configuration (tools, system prompt)
- **Orchestrator** - Multi-agent workflow routing configuration
- **Workflows** - Workflow definitions with node dependencies
- **Nodes** - Agent definitions (local or external A2A)
- **External Agents** - Global settings for A2A external agents
- **MCP Servers** - Model Context Protocol server connections
- **Persistence** - State persistence configuration

## Standalone Agent

The simplest configuration — a single agent with tools:

```yaml
metadata:
  version: "1.0"

llm:
  provider: openai
  config:
    model: "gpt-4o-mini"

agent:
  name: "My Assistant"              # Display name (traces, UI, CLI)
  system_prompt: "You are helpful." # Agent's system prompt
  tools:                            # Local tools from tools_module
    - search
    - calculate
  mcp_tools:                        # MCP server tools (optional)
    - server: data_platform
      tools: "*"
  middleware:                        # Middleware (optional)
    - type: tool_call_limit
      config:
        max_tool_calls: 20
```

No `orchestrator`, `workflows`, or `nodes` sections needed.

### Agent Configuration Fields

| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Display name. Defaults to `"Agent"`. |
| `system_prompt` | string | System prompt for the agent. |
| `tools` | list[string] | Local tool function names from `tools_module`. |
| `mcp_tools` | list | MCP server tool references (same format as node `mcp_tools`). |
| `llm` | object | Agent-specific LLM override (same format as global `llm`). |
| `middleware` | list | Middleware configurations. |

## Multi-Agent Workflows

For complex tasks requiring multiple specialized agents:

```yaml
metadata:
  version: "1.0"

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"
    temperature: 0.7

# Orchestrator configuration
orchestrator:
  name: "My Orchestrator"           # Display name (optional)
  workflows:
    - workflow1
    - workflow2

# Global external agent settings (optional)
external_agents:
  timeout: 30.0
  retry:
    max_attempts: 3
    backoff: 1.0

# Workflow definitions
workflows:
  workflow1:
    description: "Main workflow"
    nodes:
      local_agent:
        depends_on: []
      external_agent:
        depends_on: [local_agent]
        routes:
          router_field: status
          success: END
          default: fallback_agent

# Node definitions (local or external A2A)
nodes:
  # Local agent
  local_agent:
    description: "Local LangChain agent"
    system_prompt: "You are a helpful assistant"
    tools: [tool1, tool2]
    middleware:
      - type: model_call_limit
        model_call_limit:
          run_limit: 15

  # Local agent with custom LLM (e.g., Snowflake Cortex)
  snowflake_agent:
    description: "Query data via Snowflake Cortex"
    llm:
      provider: custom
      class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
      config:
        model: "llama3.1-70b"
    system_prompt: "You are an enterprise data analyst..."

  # External A2A agent
  external_agent:
    description: "External A2A agent"
    endpoint: "https://example.com/a2a"
    auth:
      type: bearer
      token: "${API_TOKEN}"
    timeout: 60
    retry:
      max_attempts: 5

# Persistence is NOT configured in YAML. Choose the backend at deploy
# time via the --persistence CLI flag or AGENTFLOW_PERSISTENCE /
# POSTGRES_CONNECTION_STRING / CHECKPOINTER_DB_PATH env vars. See the
# "Persistence" section below and PERSISTENCE.md for the full surface.
```

## Section Details

### Metadata

Information about the configuration file itself.

```yaml
metadata:
  version: "1.0"                    # Required
  name: "Customer Support Workflow" # Recommended
  description: "Handles customer inquiries and escalations"
  author: "Support Team"
  created: "2025-01-01"
  updated: "2025-01-08"
  tags: ["support", "production"]
  notes: "Includes human-in-the-loop for escalations"
```

**Fields:**

| Field         | Required | Description                         |
|---------------|----------|-------------------------------------|
| `version`     | Yes      | Your workflow version (e.g., "1.0") |
| `name`        | No       | Human-readable configuration name   |
| `description` | No       | Detailed description                |
| `author`      | No       | Author or team name                 |
| `created`     | No       | Creation date (YYYY-MM-DD)          |
| `updated`     | No       | Last update date (YYYY-MM-DD)       |
| `tags`        | No       | List of tags for categorization     |
| `notes`       | No       | Additional notes or comments        |

### LLM Configuration

LLM configuration follows a hierarchy (highest to lowest priority):

1. **Node-level** - Specific to one agent
2. **Workflow-level** - Applies to all nodes in a workflow
3. **Orchestrator-level** - Used for workflow routing
4. **Global-level** - Default for everything

#### Anthropic

```yaml
llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"  # Required
    api_key: "${ANTHROPIC_API_KEY}"    # Optional (reads from env)
    temperature: 0.7                   # Optional: 0.0-2.0
    max_tokens: 4096                   # Optional: Max output tokens
    top_p: 1.0                         # Optional: 0.0-1.0
    max_retries: 2                     # Optional: Retry attempts
    timeout: 60.0                      # Optional: Request timeout (seconds)
```

#### OpenAI

```yaml
llm:
  provider: openai
  config:
    model: "gpt-4o"                    # Required
    api_key: "${OPENAI_API_KEY}"       # Optional (reads from env)
    base_url: "https://..."            # Optional: Custom endpoint
    temperature: 0.7                   # Optional: 0.0-2.0
    max_tokens: 2000                   # Optional: Max output tokens
    top_p: 1.0                         # Optional: 0.0-1.0
    max_retries: 2                     # Optional: Retry attempts
    timeout: 60.0                      # Optional: Request timeout (seconds)
```

#### Azure OpenAI

```yaml
llm:
  provider: azure_openai
  config:
    model: "gpt-4o"                              # Required
    azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"   # Optional (reads from env)
    azure_deployment: "gpt-4o-deployment"        # Optional: Deployment name
    api_version: "2024-02-15-preview"            # Optional: API version
    api_key: "${AZURE_OPENAI_API_KEY}"           # Optional (reads from env)
    azure_identity: true                         # Optional: Use Azure AD auth
    temperature: 0.7
    max_tokens: 2000
```

#### Custom Provider

```yaml
llm:
  provider: custom
  class_name: "langchain_community.chat_models.ChatOllama"  # Required
  config:
    model: "llama2"
    base_url: "http://localhost:11434"
```

#### Environment Variables

All configuration values support environment variable substitution:

```yaml
llm:
  provider: openai
  config:
    model: "${MODEL_NAME}"           # Reads from MODEL_NAME env var
    api_key: "${OPENAI_API_KEY}"     # Reads from OPENAI_API_KEY env var
```

### Orchestrator

Configures workflow routing. The orchestrator is a regular agent node inside the
compiled graph — it classifies user queries and routes to the matching workflow
via conditional edges. Middleware can be applied at the routing level (e.g., PII
redaction, rate limiting).

```yaml
# Minimal — auto-generated routing prompt from workflow descriptions
orchestrator:
  workflows:
    - customer_support
    - technical_support
    - sales_inquiry

# Full — with custom prompt, middleware, and LLM override
orchestrator:
  workflows:
    - customer_support
    - technical_support
    - sales_inquiry
  system_prompt: |                     # Optional: Override auto-generated routing prompt
    You are a query router. Route to the correct workflow.
    Only accept queries about customer support, technical issues, or sales.
  middleware:                          # Optional: Middleware on the router agent
    - type: model_call_limit
      model_call_limit:
        run_limit: 3
  llm:                                 # Optional: LLM for routing decisions
    provider: openai
    config:
      model: "gpt-4o-mini"
      temperature: 0.3
```

**Fields:**

| Field              | Required | Description                                                                                       |
|--------------------|----------|---------------------------------------------------------------------------------------------------|
| `workflows`        | Yes      | List of workflow names to route between                                                           |
| `llm`              | No       | LLM configuration for routing decisions                                                           |
| `system_prompt`    | No       | Custom system prompt for the router agent. If omitted, auto-generated from workflow descriptions. |
| `middleware`       | No       | LangChain middleware applied to the router agent (same syntax as node middleware)                 |
| `default_response` | No       | Deprecated — if no workflow matches, the router responds directly to the user                     |

### Workflows

Define the execution graph for each workflow.

```yaml
workflows:
  customer_support:
    description: "Handles customer inquiries"
    llm:                             # Optional: Override LLM for this workflow
      provider: anthropic
      config:
        model: "claude-sonnet-4-20250514"
    nodes:
      intake_agent:
        depends_on: []               # Entry point (no dependencies)

      classification_agent:
        depends_on: [intake_agent]

      resolution_agent:
        depends_on: [classification_agent]
        routes:                      # Conditional routing
          router_field: status       # Field in tool result to check
          resolved: END              # If status="resolved", end workflow
          escalate: escalation_agent # If status="escalate", go to escalation
          default: END               # Default route

      escalation_agent:
        depends_on: [resolution_agent]
```

**Workflow Fields:**

| Field         | Required | Description                                  |
|---------------|----------|----------------------------------------------|
| `description` | Yes      | Workflow description                         |
| `llm`         | No       | LLM configuration override for this workflow |
| `nodes`       | Yes      | Node definitions with dependencies           |

**Node Reference Fields:**

| Field                 | Required | Description                             |
|-----------------------|----------|-----------------------------------------|
| `depends_on`          | Yes      | List of node names this node depends on |
| `routes`              | No       | Conditional routing configuration       |
| `routes.router_field` | Yes*     | Field name in tool result to check      |
| `routes.<value>`      | No       | Target node for each field value        |
| `routes.default`      | No       | Default target node (can be `END`)      |

### Nodes

AgentFlow supports two types of nodes:

| Type               | Detection            | Use Case                                          |
|--------------------|----------------------|---------------------------------------------------|
| Local agent        | No `endpoint` field  | LangChain agents with tools (can use custom LLMs) |
| External A2A agent | Has `endpoint` field | A2A protocol external agents                      |

#### Local Agents

Standard LangChain agents with tools and system prompts:

```yaml
nodes:
  support_agent:
    description: "Customer support agent"
    system_prompt: |
      You are a customer support specialist.
      Be friendly and professional.
    tools:
      - lookup_order
      - create_ticket
      - refund_order
    llm:                             # Optional: Node-specific LLM
      provider: openai
      config:
        model: "gpt-4o"
        temperature: 0.7
    middleware:                      # Optional: LangChain middleware
      - type: model_call_limit
        model_call_limit:
          run_limit: 15
```

**Local Agent Fields:**

| Field           | Required | Description                                |
|-----------------|----------|--------------------------------------------|
| `description`   | Yes      | Node description                           |
| `system_prompt` | Yes      | System prompt for the agent                |
| `tools`         | No       | List of tool names available to this agent |
| `llm`           | No       | LLM configuration for this specific node   |
| `middleware`    | No       | LangChain middleware configuration         |

#### External A2A Agents

Connect to A2A-compliant external agents:

```yaml
nodes:
  salesforce_agent:
    description: "Salesforce CRM agent"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
    timeout: 30                      # Optional: Request timeout (seconds)
    retry:                           # Optional: Retry configuration
      max_attempts: 3
      backoff: 1.0
      max_backoff: 30.0
```

**External Agent Fields:**

| Field         | Required | Description                              |
|---------------|----------|------------------------------------------|
| `description` | Yes      | Node description                         |
| `endpoint`    | Yes      | A2A endpoint URL                         |
| `auth`        | No       | Authentication configuration             |
| `timeout`     | No       | Request timeout in seconds (default: 30) |
| `retry`       | No       | Retry configuration                      |

**Authentication Types:**

```yaml
# Bearer Token
auth:
  type: bearer
  token: "${TOKEN}"

# API Key
auth:
  type: api_key
  token: "${API_KEY}"
  header_name: "X-API-Key"           # Optional, default: X-API-Key

# Basic Authentication
auth:
  type: basic
  username: "service_account"
  password: "${PASSWORD}"

# OAuth2 Client Credentials
auth:
  type: oauth2_client_credentials
  oauth2:
    token_url: "https://auth.example.com/oauth2/token"
    client_id: "${CLIENT_ID}"
    client_secret: "${CLIENT_SECRET}"
    scopes:
      - "api.read"
      - "api.write"

# Mutual TLS (mTLS)
auth:
  type: mtls
  mtls:
    cert_path: "/etc/certs/client.pem"
    key_path: "/etc/certs/client-key.pem"
    ca_path: "/etc/certs/ca.pem"     # Optional
```

**Retry Configuration:**

| Field          | Default | Description                     |
|----------------|---------|---------------------------------|
| `max_attempts` | 3       | Maximum retry attempts          |
| `backoff`      | 1.0     | Initial backoff delay (seconds) |
| `max_backoff`  | 30.0    | Maximum backoff delay (seconds) |

See [External Agents Guide](EXTERNAL_AGENTS.md) for detailed documentation.

#### Custom LLM Agents

Local agents can use any LangChain-compatible chat model via the custom LLM provider.
This is useful for integrating with platforms like Snowflake Cortex, Google Vertex AI,
AWS Bedrock, or local models via Ollama:

```yaml
nodes:
  # Snowflake Cortex
  snowflake_agent:
    description: "Query enterprise data via Snowflake Cortex"
    llm:
      provider: custom
      class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
      config:
        model: "llama3.1-70b"
        cortex_search_service: "MY_SEARCH_SERVICE"  # Optional
    system_prompt: |
      You are an enterprise data analyst with access to Snowflake.
      Answer questions about sales, inventory, and business metrics.

  # Google Vertex AI
  vertex_agent:
    description: "Agent using Google Vertex AI"
    llm:
      provider: custom
      class_name: "langchain_google_vertexai.ChatVertexAI"
      config:
        model_name: "gemini-pro"
    system_prompt: "You are a helpful assistant..."

  # AWS Bedrock
  bedrock_agent:
    description: "Agent using AWS Bedrock"
    llm:
      provider: custom
      class_name: "langchain_aws.ChatBedrock"
      config:
        model_id: "anthropic.claude-3-sonnet-20240229-v1:0"
        region_name: "us-east-1"
    system_prompt: "You are a helpful assistant..."

  # Ollama (local)
  local_agent:
    description: "Agent using local Ollama model"
    llm:
      provider: custom
      class_name: "langchain_ollama.ChatOllama"
      config:
        model: "llama3.1"
    system_prompt: "You are a helpful assistant..."
```

**Snowflake Cortex Environment Variables:**

ChatSnowflakeCortex reads connection info from environment variables:

```bash
export SNOWFLAKE_USERNAME=your-username   # Note: USERNAME not USER
export SNOWFLAKE_ACCOUNT=your-account
export SNOWFLAKE_DATABASE=your-database
export SNOWFLAKE_SCHEMA=your-schema
export SNOWFLAKE_WAREHOUSE=your-warehouse
export SNOWFLAKE_ROLE=your-role           # Optional
```

**Note:** AgentFlow automatically filters messages for ChatSnowflakeCortex since it
doesn't support ToolMessage types and requires messages to end with a user message.

### Middleware

LangChain middleware can be configured per-node to control agent behavior:

```yaml
nodes:
  my_agent:
    description: "Agent with middleware"
    system_prompt: "You are helpful."
    tools: [search, calculate]
    middleware:
      # Limit model calls
      - type: model_call_limit
        model_call_limit:
          run_limit: 15
          exit_behavior: end           # "end" or "error"

      # Limit tool calls
      - type: tool_call_limit
        tool_call_limit:
          run_limit: 10
          exit_behavior: end

      # Summarize long conversations
      - type: summarization
        summarization:
          model: "anthropic:claude-sonnet-4-20250514"
          trigger_messages: 20
          keep_messages: 5

      # Require human approval for sensitive tools
      - type: human_in_the_loop
        human_in_the_loop:
          interrupt_on:
            delete_record:
              allowed_decisions: ["approve", "reject"]
            refund_order:
              allowed_decisions: ["approve", "reject"]

      # Retry failed tool calls
      - type: tool_retry
        tool_retry:
          max_retries: 3

      # Try fallback models
      - type: model_fallback
        model_fallback:
          fallback_models:
            - gpt-4-turbo
            - gpt-3.5-turbo
```

**Built-in Middleware Types:**

| Type                | Description                               |
|---------------------|-------------------------------------------|
| `model_call_limit`  | Limit the number of model calls           |
| `tool_call_limit`   | Limit the number of tool calls            |
| `summarization`     | Summarize long conversations              |
| `human_in_the_loop` | Require human approval for specific tools |
| `tool_retry`        | Retry failed tool calls                   |
| `model_fallback`    | Try fallback models on failure            |

**Custom Middleware:**

```yaml
middleware:
  - custom:
      class_name: "mycompany.middleware.AuditMiddleware"
      config:
        log_level: "INFO"
        audit_destination: "s3://audit-logs"
```

See [Middleware Guide](MIDDLEWARE.md) for detailed documentation.

### External Agents (Global Settings)

Set default timeout and retry behavior for all external A2A agents:

```yaml
external_agents:
  timeout: 30.0                      # Default timeout (seconds)
  retry:
    max_attempts: 3                  # Default max retry attempts
    backoff: 1.0                     # Default initial backoff (seconds)
    max_backoff: 30.0                # Default max backoff (seconds)
```

Per-agent settings override these global defaults.

### MCP Servers

Configure MCP (Model Context Protocol) server connections for accessing external data and tools.

```yaml
mcp_servers:
  # Local MCP server (stdio transport)
  local-data:
    transport: stdio
    command: "python"
    args: ["-m", "my_mcp_server"]
    env:
      DATABASE_URL: "${DATABASE_URL}"
    timeout: 30.0
    retry:
      max_attempts: 3
      backoff: 1.0
    context: |
      This server provides access to local data sources.
      Use query tool with app_id: "my-app"

  # Remote MCP server (Streamable HTTP)
  cloud-api:
    transport: streamable_http
    url: "https://api.example.com/mcp"
    auth:
      type: bearer
      token: "${API_TOKEN}"
    timeout: 30.0
```

**MCP Server Fields:**

| Field       | Required | Description                                          |
|-------------|----------|------------------------------------------------------|
| `transport` | Yes      | Transport type: `stdio`, `sse`, or `streamable_http` |
| `command`   | Yes*     | Command for stdio transport                          |
| `args`      | No       | Arguments for stdio command                          |
| `url`       | Yes*     | URL for remote transports (sse, streamable_http)     |
| `env`       | No       | Environment variables for stdio subprocess           |
| `auth`      | No       | Authentication configuration                         |
| `timeout`   | No       | Request timeout in seconds (default: 30.0)           |
| `retry`     | No       | Retry configuration                                  |
| `context`   | No       | Domain-specific hints injected into agent prompts    |

**Context Field:**

The `context` field enables auto-documentation of MCP tools. Content is automatically injected into agent system prompts
along with tool schemas discovered from the MCP server:

```yaml
mcp_servers:
  data-platform:
    transport: stdio
    command: "python"
    args: ["-m", "mcp_server"]
    context: |
      **Required Parameters:**
      - app_id: Always use "order-management"

      **Available Data Sources:**
      - customers: Customer records
      - orders: Order transactions
```

This eliminates the need to manually document MCP tool parameters in system prompts.

**Referencing MCP Tools in Nodes:**

```yaml
nodes:
  my_agent:
    description: "Agent using MCP tools"
    system_prompt: "You are a data analyst..."
    mcp_tools:
      - server: local-data
        tools: "*"                    # Use all tools
      - server: cloud-api
        tools: [query, search]        # Specific tools
      - server: cloud-api
        tools:
          - name: query
            alias: query_data         # Rename tool
```

See [MCP Integration Guide](MCP.md) for detailed documentation.

### Persistence (deploy-time, not YAML)

Persistence is configured at deploy time via CLI flags or environment
variables — not in the YAML. The same `workflow.yaml` runs across dev /
staging / prod, and the backend is chosen per environment:

```bash
# Local dev — SQLite default at .agentflow/checkpoints.db
agentflow --yaml workflow.yaml "your query"

# SQLite at a custom path
agentflow --yaml workflow.yaml --persistence sqlite --db-path /data/x.db "..."

# Production — Postgres
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
agentflow --yaml workflow.yaml "..."
```

**Deprecated:** a top-level `persistence:` section in the YAML logs a
deprecation warning at startup and is ignored. See
[PERSISTENCE.md](PERSISTENCE.md) for the full env-var table
(`AGENTFLOW_PERSISTENCE`, `POSTGRES_CONNECTION_STRING`,
`CHECKPOINTER_DB_PATH`, the `POSTGRES_POOL_*` pool-tuning family,
`AGENTFLOW_STORE_ENABLED`, `AGENTFLOW_ENCRYPTION_KEY`).

## Complete Example

Here's a complete example showing all node types working together:

```yaml
metadata:
  version: "1.0"
  name: "Enterprise Support Workflow"
  description: "Multi-platform customer support with local and external agents"
  author: "Support Team"
  tags: ["production", "customer-facing"]

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"
    temperature: 0.7
    max_tokens: 4096

external_agents:
  timeout: 30.0
  retry:
    max_attempts: 3
    backoff: 1.0

orchestrator:
  workflows:
    - customer_support
  llm:
    provider: openai
    config:
      model: "gpt-4o-mini"

workflows:
  customer_support:
    description: "Route and handle customer queries"
    nodes:
      triage_agent:
        routes:
          router_field: "category"
          crm: salesforce_agent
          analytics: snowflake_agent
          billing: stripe_agent
          default: general_agent
      salesforce_agent:
        depends_on: [triage_agent]
      snowflake_agent:
        depends_on: [triage_agent]
      stripe_agent:
        depends_on: [triage_agent]
      general_agent:
        depends_on: [triage_agent]

nodes:
  # Local triage agent
  triage_agent:
    description: "Classifies and routes customer queries"
    system_prompt: |
      You are a customer support triage agent.
      Classify queries into: crm, analytics, billing, or general.
      Use the classify_query tool with your classification.
    tools:
      - classify_query
    middleware:
      - type: model_call_limit
        model_call_limit:
          run_limit: 10

  # External A2A agent: Salesforce
  salesforce_agent:
    description: "Handles CRM operations via Salesforce Einstein"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
    timeout: 45
    retry:
      max_attempts: 3

  # Custom LLM agent: Snowflake Cortex
  snowflake_agent:
    description: "Query enterprise analytics data"
    llm:
      provider: custom
      class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
      config:
        model: "llama3.1-70b"
    system_prompt: |
      You are an enterprise data analyst with access to Snowflake.
      Answer questions about sales, inventory, and business metrics.

  # External A2A agent: Stripe
  stripe_agent:
    description: "Handles billing inquiries via Stripe"
    endpoint: "https://agents.stripe.com/a2a/billing"
    auth:
      type: api_key
      token: "${STRIPE_API_KEY}"
      header_name: "Stripe-API-Key"

  # Local fallback agent
  general_agent:
    description: "Handles general inquiries"
    system_prompt: |
      You are a general customer support agent.
      Help with queries that don't fit specific categories.
    tools:
      - search_knowledge_base
      - create_ticket
    middleware:
      - type: summarization
        summarization:
          model: "anthropic:claude-sonnet-4-20250514"
          trigger_messages: 15
          keep_messages: 5
      - type: human_in_the_loop
        human_in_the_loop:
          interrupt_on:
            escalate_to_manager:
              allowed_decisions: ["approve", "reject"]

# Persistence is NOT configured in YAML — set AGENTFLOW_PERSISTENCE=postgres
# and POSTGRES_CONNECTION_STRING (or use --persistence postgres
# --connection-string "$DATABASE_URL") at deploy time. See PERSISTENCE.md.
```

## Validation Rules

AgentFlow validates your configuration:

1. **Required Fields:**
    - `metadata.version` must be specified
    - `orchestrator.workflows` must list at least one workflow
    - Each workflow must have `description` and `nodes`
    - Each local node must have `description` and `system_prompt`
    - Each external node must have `description` and `endpoint`

2. **Reference Validation:**
    - All workflow nodes must reference defined nodes
    - All `depends_on` entries must reference valid nodes
    - All route targets must reference valid nodes or `END`

3. **Node Type Validation:**
    - External nodes (with `endpoint`) don't need `system_prompt` or `tools`
    - Local nodes require `system_prompt`

4. **LLM Configuration:**
    - Custom providers require `class_name`
    - Named providers use specific config schemas

5. **Type Validation:**
    - `temperature`: 0.0 - 2.0
    - `max_tokens`: > 0
    - `top_p`: 0.0 - 1.0
    - `timeout`: > 0

## Tips

1. **Use Environment Variables:** Store sensitive data like API keys and tokens in environment variables.

2. **LLM Hierarchy:** Use global LLM for defaults, override at workflow/node level for specific needs.

3. **Model Selection:**
    - Use faster/cheaper models (gpt-4o-mini) for simple tasks like routing
    - Use powerful models (claude-sonnet-4-20250514, gpt-4o) for complex reasoning

4. **External Agent Timeouts:** Set appropriate timeouts for external agents based on their expected response times.

5. **Middleware Order:** Apply middleware in order from least to most expensive operations.

6. **Persistence:** Use SQLite for development, PostgreSQL for production with long-term memory.

## See Also

- [Getting Started](AGENTFLOW.md) - Learn AgentFlow basics
- [External Agents](EXTERNAL_AGENTS.md) - A2A protocol integration
- [Middleware](MIDDLEWARE.md) - LangChain middleware configuration
- [Persistence](PERSISTENCE.md) - State persistence options
- [CLI Usage](AGENTFLOW_CLI.md) - Run workflows from command line
- [Human in the Loop](HUMAN_IN_THE_LOOP.md) - Human decision points

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
