# Conditional Routing

## Introduction

This tutorial builds on the [Multi-Agent Workflows](multi-agent-workflows.md) tutorial. Make sure you understand
`orchestrator`, `workflows`, `nodes`, and `depends_on` before continuing.

Here, we'll build a smart document processing system that:

- Classifies documents by type (invoice, contract, report)
- Routes each type to a specialized processor
- Handles errors gracefully with fallback paths
- Chains multiple decision points together

---

## The Anatomy of Conditional Routing

Conditional routing has three key components:

```yaml
workflows:
  my_workflow:
    nodes:
      decision_agent:
        description: "Route queries to the appropriate agent"
        routes:
          router_field: "next_step"     # 1. Which field to check
          option_a: agent_a             # 2. Where to go for each value
          option_b: agent_b
          default: __end__              # 3. Fallback if no match
```

1. `router_field`: The state field that contains the routing decision
2. **Route mappings**: Which agent to call for each value
3. `default`: What to do if the value doesn't match any route (use `__end__` to stop)

---

## Building a Document Processing Pipeline

Let's build a system that intelligently processes different document types.

### Step 1: Create Document Processing Tools

Create `tools.py`:

```python
import json
from langchain_core.tools import tool


@tool
def classify_document(content: str) -> str:
    """
    Classify a document based on its content.
    Returns a JSON string with document_type and confidence.
    """
    content_lower = content.lower()

    # Simple keyword-based classification
    if any(word in content_lower for word in ['invoice', 'payment', 'bill', 'amount due']):
        doc_type = 'invoice'
        confidence = 0.95
    elif any(word in content_lower for word in ['agreement', 'contract', 'terms', 'parties']):
        doc_type = 'contract'
        confidence = 0.90
    elif any(word in content_lower for word in ['report', 'analysis', 'findings', 'conclusion']):
        doc_type = 'report'
        confidence = 0.85
    else:
        doc_type = 'unknown'
        confidence = 0.50

    return json.dumps({
        "document_type": doc_type,
        "confidence": confidence,
        "requires_review": confidence < 0.80
    })


@tool
def process_invoice(content: str) -> str:
    """Extract key information from an invoice."""
    content_lower = content.lower()

    # Determine if verification is needed based on amount or missing info
    amount = 1250.00  # Default amount

    if 'amount' in content_lower:
        # Try to extract amount (simplified)
        if '10000' in content or '15000' in content or '20000' in content:
            amount = 15000.00

    needs_verification = amount > 10000

    result = {
        "invoice_number": "INV-2024-001",
        "amount": amount,
        "due_date": "2024-02-15",
        "status": "Pending Payment",
        "line_items": 3,
        "needs_verification": "true" if needs_verification else "false"
    }

    return json.dumps(result)


@tool
def process_contract(content: str) -> str:
    """Extract key information from a contract."""
    content_lower = content.lower()

    # Determine risk level based on keywords
    if any(word in content_lower for word in ['liability', 'indemnification', 'penalty', 'termination']):
        risk_level = 'high'
    elif any(word in content_lower for word in ['service', 'standard', 'basic']):
        risk_level = 'low'
    else:
        risk_level = 'medium'

    result = {
        "contract_type": "Service Agreement",
        "parties": ["Company A", "Company B"],
        "term_months": 12,
        "obligations_identified": 5,
        "risk_level": risk_level,
        "recommended_actions": "Legal review for clauses 3.2 and 7.1" if risk_level == 'high' else "Standard processing"
    }

    return json.dumps(result)


@tool
def process_report(content: str) -> str:
    """Summarize and extract insights from a report."""
    return """
    Report Analysis Complete:
    - Report Type: Technical Analysis
    - Pages: 15
    - Key Findings: 3 major insights identified
    - Recommendations: 5 actionable items
    - Priority: High
    """


@tool
def manual_review_required(content: str, reason: str) -> str:
    """Flag a document for manual review."""
    return f"""
    Document flagged for manual review.
    Reason: {reason}
    Ticket ID: MR-{hash(content) % 10000}
    Estimated review time: 2-4 hours
    """
```

### Step 2: Design the Workflow with Multiple Decision Points

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Document Processing Workflow"
  description: "Processes documents based on type with conditional approval flows"
  tags: [document-processing, conditional-routing, multi-stage]

workflows:
  document_processing:
    description: "Intelligently process documents based on type"
    nodes:
      # Step 1: Classify the document
      classifier:
        routes:
          router_field: "document_type"
          invoice: invoice_processor
          contract: contract_processor
          report: report_processor
          unknown: manual_reviewer
          default: __end__

      # Step 2: Type-specific processors
      invoice_processor:
        depends_on: [classifier]
        routes:
          router_field: "needs_verification"
          true: quality_checker
          false: finalizer
          default: finalizer

      contract_processor:
        depends_on: [classifier]
        routes:
          router_field: "risk_level"
          high: legal_reviewer
          medium: finalizer
          low: finalizer
          default: finalizer

      report_processor:
        depends_on: [classifier]

      # Step 3: Additional review steps
      quality_checker:
        depends_on: [invoice_processor]

      legal_reviewer:
        depends_on: [contract_processor]

      manual_reviewer:
        depends_on: [classifier]

      # Final step
      finalizer:
        depends_on: [invoice_processor, contract_processor, report_processor, quality_checker, legal_reviewer]

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

orchestrator:
  workflows:
    - document_processing

nodes:
  classifier:
    description: "Classifies documents and routes to appropriate processor"
    tools:
      - classify_document
    system_prompt: |
      You are a document classifier. Analyze the document content and:
      1. Call classify_document to determine the document type
      2. Set the 'document_type' field to: invoice, contract, report, or unknown
      3. If confidence is low, set to 'unknown' for manual review

      Be precise in your classification as it determines the processing path.

  invoice_processor:
    description: "Processes invoices and determines if verification is needed"
    tools:
      - process_invoice
    system_prompt: |
      You are an invoice processing specialist.
      1. Extract all relevant invoice information using process_invoice
      2. Verify if amounts and dates are clear
      3. Set 'needs_verification' to true if:
         - Amount is over $10,000
         - Any information is unclear or missing
      4. Set 'needs_verification' to false otherwise

  contract_processor:
    description: "Analyzes contracts and assesses risk level"
    tools:
      - process_contract
    system_prompt: |
      You are a contract analysis specialist.
      1. Analyze the contract using process_contract
      2. Assess risk level based on:
         - Contract value
         - Unusual clauses
         - Liability terms
      3. Set 'risk_level' to: high, medium, or low

  report_processor:
    description: "Analyzes reports and provides summaries"
    tools:
      - process_report
    system_prompt: |
      You are a report analysis specialist.
      Analyze the report using process_report and provide a summary.

  quality_checker:
    description: "Performs quality assurance checks on processed invoices"
    tools: []
    system_prompt: |
      You are a quality assurance specialist for invoices.
      Review the invoice processing results and verify:
      - All mandatory fields are present
      - Amounts are reasonable
      - No suspicious patterns
      Provide your approval or flag issues.

  legal_reviewer:
    description: "Reviews high-risk contracts for legal issues"
    tools: []
    system_prompt: |
      You are a legal specialist for high-risk contracts.
      Review the contract analysis and:
      - Identify potential legal issues
      - Recommend specific clauses for revision
      - Provide legal risk assessment

  manual_reviewer:
    description: "Handles documents requiring manual classification"
    tools:
      - manual_review_required
    system_prompt: |
      Handle documents that couldn't be automatically classified.
      Use manual_review_required to create a review ticket.

  finalizer:
    description: "Summarizes processing steps and provides final status"
    tools: []
    system_prompt: |
      You are the final step in document processing.
      Provide a summary of all processing steps and final status.
```

### Step 3: Run the Smart Document Processor

Set your API key and run the workflow:

```bash
export OPENAI_API_KEY="your-api-key-here"
```

Try different document types:

```bash
# Process an invoice
agentflow "Process this document:
INVOICE
Invoice #: INV-2024-001
Date: January 15, 2024
Bill To: Acme Corp
Amount Due: \$1,250.00
Due Date: February 15, 2024"

# Process a contract
agentflow "Process this document:
SERVICE AGREEMENT
This agreement is entered into between Company A and Company B.
TERMS: Contract Term: 12 months, Liability Cap: \$100,000, Termination: 30 days notice"

# Process an unknown document type
agentflow "Process this document:
Hey team, just wanted to follow up on our meeting yesterday.
Can we schedule another call for next week?"
```

Or use interactive mode:

```bash
agentflow --interactive
```

---

## Understanding the Workflow Flow

Let's trace what happens when processing each document type:

### Invoice Flow

```
User submits invoice
        |
        v
    classifier (determines: invoice)
        |
        v
    invoice_processor (extracts data, checks amount)
        |
        v
    if amount > $10k: quality_checker -> finalizer
    if amount < $10k: finalizer
```

### Contract Flow

```
User submits contract
        |
        v
    classifier (determines: contract)
        |
        v
    contract_processor (analyzes risk)
        |
        v
    if high risk: legal_reviewer -> finalizer
    if medium/low risk: finalizer
```

### Unknown Document Flow

```
User submits unclear document
        |
        v
    classifier (determines: unknown)
        |
        v
    manual_reviewer (creates ticket)
        |
        v
    END
```

---

## Advanced Pattern: Chained Decisions

Notice how `invoice_processor` can route to either `quality_checker` or `finalizer` based on the invoice amount. This is
**chained routing** - a decision point that depends on the result of a previous step.

---

## Best Practices for Conditional Routing

### 1. Always Provide a Default Route

```yaml
routes:
  router_field: "status"
  approved: processor
  rejected: notifier
  default: __end__  # Handle unexpected values
```

### 2. Use Descriptive Field Names

```yaml
# Bad - unclear
router_field: "type"

# Good - explicit
router_field: "document_type"
router_field: "approval_status"
router_field: "risk_level"
```

### 3. Keep Decision Logic in Agents, Not Tools

```python
# Good - agent decides based on tool output
@tool
def analyze_document(content: str) -> str:
    """Returns analysis data."""
    return json.dumps({"risk": "high", "confidence": 0.95})

# Agent system prompt:
# "Call analyze_document, then set 'risk_level' based on the result"

# Bad - tool tries to set routing
@tool
def analyze_and_route(content: str) -> str:
    """Analyzes AND decides routing."""
    # Tools shouldn't make routing decisions
```

### 4. Use __end__ to Stop the Workflow

```yaml
routes:
  router_field: "action"
  process: processor_agent
  skip: __end__      # Stop workflow immediately
  default: __end__   # Default to stopping if uncertain
```

---

## Debugging Conditional Routes

### Problem: Workflow doesn't route as expected

**Check 1**: Is the field name correct?

```yaml
routes:
  router_field: "document_type"  # Must match exactly
```

Agent must set this exact field name in state.

**Check 2**: Are the route values exact matches?

```yaml
routes:
  router_field: "status"
  approved: next_agent  # Looks for exact string "approved"
```

If agent sets `status: "Approved"` (capital A), it won't match!

**Check 3**: Enable debug logging

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Problem: Agent runs but doesn't route

Make sure the agent is explicitly setting the routing field in its response. The agent needs to understand it should set
that field.

---

## Real-World Use Cases

### 1. Customer Service Escalation

```
Tier 1 Agent -> (if complex) -> Tier 2 Agent -> (if critical) -> Manager
```

### 2. Financial Approval Workflow

```
Requester -> (amount < $1k) -> Auto-approve
             -> (amount $1k-$10k) -> Manager -> Approve/Reject
             -> (amount > $10k) -> Director -> Manager -> Approve/Reject
```

### 3. Content Moderation

```
Classifier -> (safe) -> Publisher
              -> (unsafe) -> Human Reviewer -> Approve/Reject
              -> (unsure) -> Multiple Reviewers -> Consensus
```

### 4. Pharmaceutical Deviation

```
Orchestrator -> (data query) -> Manufacturing Agent -> END
           -> (full investigation) -> Manufacturing -> QA -> MSAT -> Compliance -> Disposition
           -> (compliance only) -> Compliance Agent -> END
```

---

## Conclusion

Now that you understand conditional routing, you can:

- Build complex decision trees with multiple levels
- Create approval workflows with dynamic routing based on rules
- Implement error handling with fallback paths
- Design event-driven systems that adapt to different scenarios

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

