# AgentFlow Plugins

This tutorial guides you through creating, installing, and using AgentFlow plugins. You'll learn the plugin
architecture, build a complete plugin from scratch, and explore the example plugins included with AgentFlow.

---

## Introduction

AgentFlow plugins extend workflow functionality by hooking into lifecycle events. Plugins can:

- **Monitor** workflow execution (metrics, logging, telemetry)
- **Test** workflows (regression testing, validation)
- **Integrate** with external systems (notifications, databases)
- **Customize** behavior (security checks, transformations)

### Installation Modes

AgentFlow supports two installation modes:

| Mode       | Command                                        | Location                     | Use Case                 |
|------------|------------------------------------------------|------------------------------|--------------------------|
| **Local**  | `agentflow-plugins install --local plugin.zip` | Current venv's site-packages | Project-specific plugins |
| **Global** | `agentflow-plugins install plugin.zip`         | `~/.agentflow/plugins`       | Shared across projects   |

---

## Plugin Architecture

### Lifecycle Hooks

Plugins hook into workflow events via the `Plugin` base class:

```python
from agentflow.plugins import Plugin, WorkflowContext


class MyPlugin(Plugin):
    # Workflow lifecycle
    def on_workflow_start(self, context: WorkflowContext, initial_state: dict) -> None: ...

    def on_workflow_end(self, context: WorkflowContext, final_state: dict, status: str) -> None: ...

    # Agent lifecycle
    def on_agent_start(self, context: WorkflowContext, agent_name: str, state: dict) -> None: ...

    def on_agent_end(self, context: WorkflowContext, agent_name: str, result: dict) -> None: ...

    # Tool lifecycle
    def on_tool_call(self, context: WorkflowContext, tool_name: str, inputs: dict) -> None: ...

    def on_tool_result(self, context: WorkflowContext, tool_name: str, result: Any) -> None: ...

    # LLM lifecycle
    def on_llm_start(self, context: WorkflowContext, model: str, messages: list) -> None: ...

    def on_llm_end(self, context: WorkflowContext, model: str, response: dict) -> None: ...

    # Error handling
    def on_error(self, context: WorkflowContext, error: Exception, error_context: dict) -> None: ...
```

### WorkflowContext

The `WorkflowContext` object provides execution metadata:

```python
context.execution_id   # Unique ID for this execution
context.workflow_name  # Name of the workflow
```

### Plugin Discovery

Plugins are discovered via Python entry points:

1. **Entry points** - Declared in `pyproject.toml` under `[project.entry-points."agentflow.plugins"]`
2. **Auto-discovery** - `PluginManager.discover_and_register_plugins()` loads all registered plugins

---

## Creating Your First Plugin

Let's create a simple logging plugin that tracks workflow activity.

### Step 1: Create Project Structure

```bash
mkdir -p plugin-logger/agentflow_plugins/logger
cd plugin-logger
```

Create this directory structure:

```
plugin-logger/
├── pyproject.toml
├── README.md
└── agentflow_plugins/
    └── logger/
        ├── __init__.py
        └── plugin.py
```

### Step 2: Create the Plugin Class

**`agentflow_plugins/logger/plugin.py`:**

```python
"""
Logger Plugin for AgentFlow.

Logs workflow execution events to console with timestamps.
"""
from datetime import datetime
from typing import Any, Dict, List

from agentflow.plugins import Plugin, WorkflowContext


class LoggerPlugin(Plugin):
    """
    Simple logging plugin that tracks workflow execution.

    Configuration:
        prefix (str): Log message prefix (default: "[WORKFLOW]")
        log_tools (bool): Whether to log tool calls (default: True)
        log_llm (bool): Whether to log LLM calls (default: False)
    """

    def __init__(
            self,
            prefix: str = "[WORKFLOW]",
            log_tools: bool = True,
            log_llm: bool = False
    ):
        """
        Initialize the Logger plugin.

        Args:
            prefix: Prefix for all log messages
            log_tools: Whether to log tool calls
            log_llm: Whether to log LLM calls
        """
        self.prefix = prefix
        self.log_tools = log_tools
        self.log_llm = log_llm

    @property
    def name(self) -> str:
        """Return the plugin name."""
        return "LoggerPlugin"

    def _log(self, message: str) -> None:
        """Print a timestamped log message."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"{self.prefix} [{timestamp}] {message}")

    def on_workflow_start(
            self,
            context: WorkflowContext,
            initial_state: Dict[str, Any]
    ) -> None:
        """Called when workflow execution starts."""
        self._log(f"Workflow '{context.workflow_name}' started (ID: {context.execution_id})")

    def on_workflow_end(
            self,
            context: WorkflowContext,
            final_state: Dict[str, Any],
            status: str = "completed"
    ) -> None:
        """Called when workflow execution ends."""
        self._log(f"Workflow '{context.workflow_name}' {status}")

    def on_agent_start(
            self,
            context: WorkflowContext,
            agent_name: str,
            state: Dict[str, Any]
    ) -> None:
        """Called when an agent starts processing."""
        self._log(f"  Agent '{agent_name}' started")

    def on_agent_end(
            self,
            context: WorkflowContext,
            agent_name: str,
            result: Dict[str, Any]
    ) -> None:
        """Called when an agent completes processing."""
        self._log(f"  Agent '{agent_name}' completed")

    def on_tool_call(
            self,
            context: WorkflowContext,
            tool_name: str,
            inputs: Dict[str, Any]
    ) -> None:
        """Called when a tool is invoked."""
        if self.log_tools:
            self._log(f"    Tool '{tool_name}' called")

    def on_tool_result(
            self,
            context: WorkflowContext,
            tool_name: str,
            result: Any
    ) -> None:
        """Called when a tool returns a result."""
        if self.log_tools:
            self._log(f"    Tool '{tool_name}' returned")

    def on_llm_start(
            self,
            context: WorkflowContext,
            model: str,
            messages: List[Dict[str, Any]]
    ) -> None:
        """Called when LLM call starts."""
        if self.log_llm:
            self._log(f"    LLM '{model}' called with {len(messages)} messages")

    def on_llm_end(
            self,
            context: WorkflowContext,
            model: str,
            response: Dict[str, Any]
    ) -> None:
        """Called when LLM call completes."""
        if self.log_llm:
            self._log(f"    LLM '{model}' responded")

    def on_error(
            self,
            context: WorkflowContext,
            error: Exception,
            error_context: Dict[str, Any]
    ) -> None:
        """Called when an error occurs."""
        self._log(f"  ERROR: {type(error).__name__}: {error}")
```

### Step 3: Create Package Init

**`agentflow_plugins/logger/__init__.py`:**

```python
from .plugin import LoggerPlugin

__all__ = ['LoggerPlugin']
```

### Step 4: Create pyproject.toml

**`pyproject.toml`:**

```toml
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "plugin-logger"
version = "1.0.0"
description = "Simple logging plugin for AgentFlow"
readme = "README.md"
requires-python = ">=3.10"

dependencies = []  # No extra dependencies needed

[project.entry-points."agentflow.plugins"]
logger = "agentflow_plugins.logger:LoggerPlugin"

[tool.setuptools]
package-dir = { "" = "." }

[tool.setuptools.packages.find]
where = ["."]
include = ["agentflow_plugins*"]
exclude = ["tests*", "**/__pycache__"]
```

### Step 5: Create README

**`README.md`:**

```markdown
# Logger Plugin

Simple logging plugin for AgentFlow workflows.

## Installation

```bash
agentflow-plugins install --local plugin-logger.zip
```

## Usage

```python
from agentflow_plugins.logger import LoggerPlugin

# Create with custom configuration
plugin = LoggerPlugin(
    prefix="[MY-APP]",
    log_tools=True,
    log_llm=False
)

# Register with orchestrator
orchestrator.plugin_manager.register(plugin)
```

```

### Step 6: Package the Plugin

```bash
cd ..
zip -r plugin-logger.zip plugin-logger/ -x "*.DS_Store" -x "__MACOSX"
```

---

## Plugin Configuration (pyproject.toml)

The `pyproject.toml` file is critical for plugin discovery. Here's a detailed breakdown:

### Required Sections

```toml
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "plugin-myname"           # Must start with "plugin-"
version = "1.0.0"                # Semantic versioning
description = "Plugin description"
requires-python = ">=3.10"

# Entry point for plugin discovery (CRITICAL!)
[project.entry-points."agentflow.plugins"]
myname = "agentflow_plugins.myname:MyNamePlugin"
#  ^                      ^              ^
#  |                      |              |
#  Entry point name       Module path    Class name

[tool.setuptools.packages.find]
where = ["."]
include = ["agentflow_plugins*"]  # Include namespace package
```

### Optional: Dependencies

```toml
[project]
dependencies = [
    "requests>=2.31.0",
    "pyyaml>=6.0.0",
]
```

### Optional: Package Data

Include non-Python files (like YAML configs):

```toml
[tool.setuptools.package-data]
agentflow_plugins = ["*/plugin.yaml", "*/templates/*.html"]
```

---

## Installing Plugins

### Local Installation (Recommended for Development)

Installs to the current virtual environment's site-packages:

```bash
# Install from zip file
agentflow-plugins install --local plugin-logger.zip

# Install from directory
agentflow-plugins install --local ./plugin-logger/

# Force reinstall
agentflow-plugins install --local --force plugin-logger.zip
```

**Advantages:**

- No PYTHONPATH configuration needed
- Project-specific plugin versions
- Works with standard Python tooling (pip, venv)

### Global Installation

Installs to `~/.agentflow/plugins`:

```bash
# Install globally
agentflow-plugins install plugin-logger.zip

# Force reinstall
agentflow-plugins install --force plugin-logger.zip
```

**Note:** Global installation requires setting PYTHONPATH:

```bash
export PYTHONPATH=~/.agentflow/plugins:$PYTHONPATH
```

### Managing Plugins

```bash
# List installed plugins
agentflow-plugins list

# Show plugin info
agentflow-plugins info logger

# Uninstall local plugin
agentflow-plugins uninstall --local logger

# Uninstall global plugin
agentflow-plugins uninstall logger
```

### Example Output

```
$ agentflow-plugins list

Installed AgentFlow plugins:

┏━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━┓
┃ Plugin          ┃ Distribution           ┃ Version ┃ Location ┃
┡━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━┩
│ logger          │ plugin-logger          │ 1.0.0   │ venv     │
│ metrics         │ plugin-metrics         │ 0.1.0   │ venv     │
│ regression_test │ plugin-regression-test │ 0.1.0   │ global   │
└─────────────────┴────────────────────────┴─────────┴──────────┘
```

---

## Using Plugins

### Automatic Discovery

Plugins with entry points are automatically discovered:

```python
from agentflow import AsyncWorkflowOrchestrator

async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="my_tools"
) as orchestrator:
    # Plugins are automatically discovered and registered!
    # Call discover_and_register_plugins() to load them
    orchestrator.plugin_manager.discover_and_register_plugins()

    async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "Hello"}]},
            config={"configurable": {"thread_id": "user-123"}}
    ):
        print(event)
```

### Manual Registration

For custom configuration, register plugins manually:

```python
from agentflow import AsyncWorkflowOrchestrator
from agentflow_plugins.logger import LoggerPlugin
from agentflow_plugins.metrics import MetricsPlugin

async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="my_tools"
) as orchestrator:
    # Create plugins with custom config
    logger = LoggerPlugin(prefix="[MY-APP]", log_tools=True)
    metrics = MetricsPlugin(show_summary=True, track_timing=True)

    # Register plugins
    orchestrator.plugin_manager.register(logger)
    orchestrator.plugin_manager.register(metrics)

    # Run workflow
    async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "Hello"}]},
            config={"configurable": {"thread_id": "user-123"}}
    ):
        print(event)

    # Access plugin data
    print(metrics.get_metrics())
```

### Importing Plugin Utilities

Use `import_from_plugin` to import modules from plugins:

```python
from agentflow.plugins import import_from_plugin

# Import the plugin's main module
logger_module = import_from_plugin('logger')

# Import a specific submodule
testing = import_from_plugin('regression_test', 'testing')

# Access exported functions
run_test_suite = testing.run_test_suite
```

---

## Example Plugins

AgentFlow includes two example plugins demonstrating different use cases.

### plugin-metrics

A metrics tracking plugin that monitors workflow execution.

**Features:**

- Track workflows, agents, tools, and errors
- Optional execution timing
- Real-time metrics display
- Programmatic access to metrics

**Usage:**

```python
from agentflow_plugins.metrics import MetricsPlugin

# Create with timing enabled
metrics = MetricsPlugin(show_summary=True, track_timing=True)
orchestrator.plugin_manager.register(metrics)

# After workflow execution
data = metrics.get_metrics()
print(f"Workflows: {data['workflows']}")
print(f"Agents: {data['agents']}")
print(f"Tools: {data['tools']}")
print(f"Errors: {data['errors']}")

# Reset for next period
metrics.reset_metrics()
```

**Output:**

```
Metrics: Workflow #1 started
  Agent 'DataProcessor' completed in 1.23s
  Agent 'ResponseGenerator' completed in 0.85s
Session Metrics: Workflows: 1 | Agents: 2 | Tools: 3 | Duration: 2.15s
```

### plugin-regression-test

Automated regression testing for AgentFlow workflows.

**Features:**

- Declarative YAML test definitions
- Agent sequence verification
- Tool call tracking
- Rich formatted output
- CI/CD ready with exit codes

**Usage:**

1. **Create test definitions** (`tests/tests.yaml`):

```yaml
tests:
  - name: "Simple Query"
    query: "What does error E404 mean?"
    expected:
      agents: ["DiagnosticAgent"]
      tool_calls: ["error_lookup"]
      status: "completed"

  - name: "Complex Workflow"
    query: "Database timeout with cascading failures"
    expected:
      agents: ["DiagnosticAgent", "AnalysisAgent", "SolutionAgent"]
      tool_calls: ["log_grepper", "dependency_checker", "fix_recommender"]
      status: "completed"
```

2. **Create test runner** (`tests/test_regressions.py`):

```python
import asyncio
from agentflow.plugins import import_from_plugin

# Import testing utilities
testing = import_from_plugin('regression_test', 'testing')
run_test_suite = testing.run_test_suite

# Run tests
coro = run_test_suite(
    workflow_config="workflow.yaml",
    tools_module="tools",
    tests_file="tests/tests.yaml",
    verbose=True,
)

results = asyncio.run(coro)
```

3. **Run tests:**

```bash
python tests/test_regressions.py
```

**Output:**

```
╭─────────────────────────────────────────────────────────────────╮
│              Running 2 Regression Tests                          │
╰─────────────────────────────────────────────────────────────────╯

╭─────────────────────────────────────────────────────────────────╮
│ [1/2] Simple Query                                               │
│ Query: What does error E404 mean?                                │
╰─────────────────────────────────────────────────────────────────╯
PASSED
   Agents: 1
   Tool calls: 1
   Status: completed

╭─────────────────────────────────────────────────────────────────╮
│ [2/2] Complex Workflow                                           │
│ Query: Database timeout with cascading failures                  │
╰─────────────────────────────────────────────────────────────────╯
PASSED
   Agents: 3
   Tool calls: 3
   Status: completed

╔═════════════════════════════════════════════════════════════════╗
║                   ALL TESTS PASSED                            ║
╚═════════════════════════════════════════════════════════════════╝
```

---

## Best Practices

### 1. Error Handling

Never let plugin errors break workflows:

```python
def on_workflow_start(self, context, initial_state):
    try:
        self.do_something()
    except Exception as e:
        print(f"Plugin error (non-fatal): {e}")
        # Don't raise - let workflow continue
```

### 2. Naming Conventions

| Component | Convention      | Example                      |
|-----------|-----------------|------------------------------|
| Package   | `plugin-<name>` | `plugin-slack-notifications` |
| Module    | `<name>`        | `slack_notifications`        |
| Class     | `<Name>Plugin`  | `SlackNotificationsPlugin`   |

### 3. Configuration

Use constructor parameters with sensible defaults:

```python
class MyPlugin(Plugin):
    def __init__(
        self,
        enabled: bool = True,
        verbose: bool = False,
        timeout: int = 30
    ):
        self.enabled = enabled
        self.verbose = verbose
        self.timeout = timeout
```

### 4. Resource Cleanup

Clean up resources when workflows end:

```python
def on_workflow_end(self, context, final_state, status):
    # Close connections, flush buffers, etc.
    if hasattr(self, '_connection'):
        self._connection.close()
```

### 5. Testing

Create unit tests for your plugin:

```python
import pytest
from agentflow.core.runtime_models import WorkflowContext
from agentflow_plugins.myname import MyPlugin


def test_plugin_initialization():
    plugin = MyPlugin(enabled=True)
    assert plugin.name == "MyPlugin"


def test_workflow_tracking():
    plugin = MyPlugin()
    context = WorkflowContext(
        execution_id="test-123",
        workflow_name="test_workflow"
    )

    plugin.on_workflow_start(context, {})
    plugin.on_agent_start(context, "Agent1", {})
    plugin.on_workflow_end(context, {}, "completed")

    # Verify plugin state
    assert plugin.some_counter == 1
```

---

## Troubleshooting

### Plugin Not Found

**Symptom:** `Plugin 'xxx' not found` when listing or using plugins.

**Solutions:**

1. Check entry points in `pyproject.toml`:
   ```toml
   [project.entry-points."agentflow.plugins"]
   myname = "agentflow_plugins.myname:MyPlugin"
   ```

2. For global plugins, ensure PYTHONPATH is set:
   ```bash
   export PYTHONPATH=~/.agentflow/plugins:$PYTHONPATH
   ```

3. Reinstall the plugin:
   ```bash
   agentflow-plugins install --force --local plugin.zip
   ```

### Import Errors

**Symptom:** `ImportError: Could not import 'xxx' from plugin 'yyy'`

**Solutions:**

1. Verify the plugin is installed:
   ```bash
   agentflow-plugins list
   ```

2. Check the import path:
   ```python
   # Correct
   from agentflow.plugins import import_from_plugin
   mod = import_from_plugin('regression_test', 'testing')

   # Not
   mod = import_from_plugin('regression_test', 'run_test_suite')  # Wrong!
   ```

3. Verify the module exists in the plugin package.

### Plugin Not Auto-Discovered

**Symptom:** Plugin is installed but not automatically loaded.

**Solutions:**

1. Call `discover_and_register_plugins()`:
   ```python
   orchestrator.plugin_manager.discover_and_register_plugins()
   ```

2. Check entry point group name (must be `agentflow.plugins`):
   ```toml
   [project.entry-points."agentflow.plugins"]  # Correct
   [project.entry-points."agentflow.plugin"]   # Wrong!
   ```

### Version Conflicts

**Symptom:** Plugin works in one project but not another.

**Solutions:**

1. Use local installation for project-specific versions:
   ```bash
   agentflow-plugins install --local plugin.zip
   ```

2. Check installed versions:
   ```bash
   agentflow-plugins info myname
   ```

---

## Conclusion

Plugins extend AgentFlow's functionality by hooking into workflow lifecycle events. Whether you need monitoring,
testing, or custom integrations, the plugin system provides a clean, maintainable way to add capabilities without
modifying core workflow code.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

