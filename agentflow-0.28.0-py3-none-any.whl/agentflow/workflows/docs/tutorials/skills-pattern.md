# Tutorial 11: Skills Pattern

This tutorial demonstrates how to implement the skills pattern in AgentFlow. Skills are prompt-driven specializations
that agents can activate on-demand to handle specific tasks.

## What Are Skills?

Skills represent specialized capabilities packaged as loadable prompts. Instead of creating multiple agents, a single
agent can dynamically load different "personas" or expertise based on the task at hand.

Common use cases:

- Coding assistants with language-specific skills (Python, SQL, JavaScript)
- Knowledge bases with domain-specific skills (legal, medical, financial)
- Creative tools with format-specific skills (email, report, presentation)

## Project Structure

```
skills_demo/
├── skills/
│   ├── sql_expert.md
│   ├── python_expert.md
│   └── code_reviewer.md
├── tools.py
└── workflow.yaml
```

## Step 1: Create Skill Prompts

Skills are simply prompt files that define specialized behavior.

**skills/sql_expert.md**

```markdown
You are now operating as a SQL Expert. Your capabilities include:

- Writing optimized SQL queries for any database system
- Explaining query execution plans
- Suggesting indexes and performance improvements
- Converting between SQL dialects (PostgreSQL, MySQL, SQLite, etc.)

When writing SQL:
1. Always use parameterized queries to prevent SQL injection
2. Include comments explaining complex joins or subqueries
3. Consider query performance and suggest indexes when relevant
4. Format SQL with proper indentation for readability
```

**skills/python_expert.md**

```markdown
You are now operating as a Python Expert. Your capabilities include:

- Writing idiomatic, PEP-8 compliant Python code
- Using appropriate data structures and algorithms
- Leveraging the standard library effectively
- Applying design patterns where appropriate

When writing Python:
1. Use type hints for function signatures
2. Write docstrings for public functions
3. Prefer list comprehensions over map/filter when readable
4. Handle exceptions specifically, not with bare except
```

**skills/code_reviewer.md**

```markdown
You are now operating as a Code Reviewer. Your review process:

1. Security: Check for vulnerabilities (injection, auth issues, data exposure)
2. Correctness: Verify logic, edge cases, error handling
3. Performance: Identify inefficiencies, unnecessary operations
4. Maintainability: Assess readability, documentation, code organization
5. Testing: Evaluate test coverage and test quality

Provide feedback in this format:
- CRITICAL: Issues that must be fixed
- SUGGESTION: Improvements to consider
- NITPICK: Minor style or preference items
```

## Step 2: Create the Skill Loader Tool

The skill loader is a simple tool that reads prompt files and returns their content. Create a file called `tools.py`:

**tools.py**

```python
"""Skill loader tools for AgentFlow workflows."""

from pathlib import Path
from langchain_core.tools import tool


@tool
def load_skill(skill_name: str) -> str:
    """
    Load a specialized skill prompt by name.

    Available skills: sql_expert, python_expert, code_reviewer

    Args:
        skill_name: Name of the skill to load (without file extension)

    Returns:
        The skill prompt content to augment the agent's behavior
    """
    skills_path = Path("./skills")

    # Try common extensions
    for ext in [".md", ".txt", ""]:
        skill_file = skills_path / f"{skill_name}{ext}"
        if skill_file.exists():
            return skill_file.read_text()

    # List available skills if not found
    available = [f.stem for f in skills_path.glob("*") if f.is_file()]
    return f"Skill '{skill_name}' not found. Available skills: {', '.join(available)}"


@tool
def list_skills() -> str:
    """List all available skills."""
    skills_path = Path("./skills")
    if not skills_path.exists():
        return "Skills directory not found"

    skills = [f.stem for f in skills_path.glob("*") if f.is_file()]
    return f"Available skills: {', '.join(skills)}"
```

## Step 3: Configure the Workflow

**workflow.yaml**

```yaml
metadata:
  version: "1.0"
  name: "Skills Demo"
  description: "Demonstrates the skills pattern with loadable specializations"

llm:
  provider: "openai"
  config:
    model: "gpt-4o-mini"

orchestrator:
  workflows:
    - skills_workflow

workflows:
  skills_workflow:
    description: "Single agent with loadable skills"
    nodes:
      assistant:
        depends_on: []

nodes:
  assistant:
    description: "Assistant that can load specialized skills on demand"
    tools:
      - load_skill
      - list_skills
    system_prompt: |
      You are a helpful assistant with access to specialized skills.

      When a user asks for help with a specific domain (SQL, Python, code review, etc.),
      FIRST load the appropriate skill using the load_skill tool, then apply that
      expertise to help with their request.

      Always load a skill before providing specialized assistance.
      Use list_skills to see what's available if unsure.
```

## Step 4: Run the Workflow

```bash
cd skills_demo
agentflow run workflow.yaml
```

Example interaction:

```
User: Can you help me write a query to find duplicate emails in a users table?

Assistant: [Calls load_skill with skill_name="sql_expert"]

Assistant: Based on my SQL expertise, here is a query to find duplicate emails:

```sql
-- Find duplicate emails with count
SELECT 
    email,
    COUNT(*) as occurrence_count
FROM users
GROUP BY email
HAVING COUNT(*) > 1
ORDER BY occurrence_count DESC;
```

## Hierarchical Skills

You can organize skills hierarchically by using naming conventions:

```
skills/
├── coding/
│   ├── python.md
│   ├── javascript.md
│   └── sql.md
├── writing/
│   ├── email.md
│   ├── report.md
│   └── presentation.md
└── review/
    ├── code.md
    └── document.md
```

Update the tool to support nested paths:

```python
@tool
def load_skill(skill_path: str) -> str:
    """Load a skill by path (e.g., 'coding/python' or 'review/code')."""
    from pathlib import Path
    skill_file = Path("./skills") / f"{skill_path}.md"
    if skill_file.exists():
        return skill_file.read_text()
    return f"Skill '{skill_path}' not found"
```

## Key Takeaways

1. **Skills are just tools** - No framework changes needed, implement as regular Python functions
2. **Prompts as files** - Store specialized prompts in markdown or text files
3. **Agent loads on demand** - The agent decides when to activate a skill based on the task
4. **Composable** - Skills can be combined, nested, or chained as needed
5. **Team-friendly** - Different teams can maintain different skill files independently

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

