# External Agents

## Introduction

Your AgentFlow workflows are powerful, but what if you need to connect to:

- **AWS Bedrock Agents** for specialized AI capabilities
- **Azure AI Agents** for enterprise integrations
- **Salesforce Einstein** for CRM operations
- **ServiceNow** for IT service management
- Any other **A2A-compliant agent**

This is where **External Agents** come in. In this tutorial, you'll learn how to integrate external agents into your
workflows using the Agent2Agent (A2A) Protocol.

---

## What is A2A Protocol?

The [Agent2Agent (A2A) Protocol](https://a2a-protocol.org/) is an open standard for agent-to-agent communication
maintained by the Linux Foundation. AgentFlow acts as an A2A client, allowing your workflows to invoke external
A2A-compliant agents.

---

## Quick Start

External agents are configured purely in YAML. The presence of an `endpoint` field indicates an external agent:

```yaml
nodes:
  # Local agent (standard AgentFlow agent)
  triage_agent:
    description: "Routes customer queries to specialists"
    system_prompt: "You classify queries and route them..."
    tools:
      - classify_query

  # External A2A agent (no system_prompt or tools needed)
  crm_agent:
    description: "Handles CRM operations via Salesforce"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
```

AgentFlow automatically:

1. Detects the external agent by the `endpoint` field
2. Creates a direct A2A client using the official SDK
3. Invokes the external agent without any wrapper overhead

---

## Authentication

AgentFlow supports all A2A protocol authentication schemes.

### No Authentication (Public Agents)

```yaml
nodes:
  weather_agent:
    description: "Public weather service"
    endpoint: "https://weather.example.com/a2a"
```

### Bearer Token

The most common authentication method for cloud services:

```yaml
nodes:
  salesforce_agent:
    description: "Salesforce CRM agent"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
```

### API Key

For services using custom API key headers:

```yaml
nodes:
  internal_agent:
    description: "Internal service agent"
    endpoint: "https://internal.corp.com/a2a"
    auth:
      type: api_key
      token: "${INTERNAL_API_KEY}"
      header_name: "X-Internal-API-Key"  # Optional, defaults to X-API-Key
```

### Basic Authentication

```yaml
nodes:
  legacy_agent:
    description: "Legacy system agent"
    endpoint: "https://legacy.corp.com/a2a"
    auth:
      type: basic
      username: "service_account"
      password: "${LEGACY_PASSWORD}"
```

### OAuth2 Client Credentials

For enterprise services using OAuth2:

```yaml
nodes:
  azure_agent:
    description: "Azure AI agent"
    endpoint: "https://azure-agents.microsoft.com/a2a"
    auth:
      type: oauth2_client_credentials
      oauth2:
        token_url: "https://login.microsoftonline.com/${TENANT_ID}/oauth2/v2.0/token"
        client_id: "${AZURE_CLIENT_ID}"
        client_secret: "${AZURE_CLIENT_SECRET}"
        scopes:
          - "https://cognitiveservices.azure.com/.default"
```

### Mutual TLS (mTLS)

For high-security enterprise environments:

```yaml
nodes:
  banking_agent:
    description: "Banking compliance agent"
    endpoint: "https://secure.bank.com/a2a"
    auth:
      type: mtls
      mtls:
        cert_path: "/etc/certs/client.pem"
        key_path: "/etc/certs/client-key.pem"
        ca_path: "/etc/certs/bank-ca.pem"
```

---

## Timeout and Retry Configuration

External agent calls support configurable timeouts and automatic retries with exponential backoff.

### Global Defaults

Set default timeout and retry behavior for all external agents:

```yaml
external_agents:
  timeout: 30.0  # seconds
  retry:
    max_attempts: 3
    backoff: 1.0           # initial delay in seconds
    max_backoff: 30.0      # maximum delay in seconds
```

### Per-Agent Overrides

Override global defaults for specific agents:

```yaml
nodes:
  # Uses global defaults
  fast_agent:
    description: "Quick response agent"
    endpoint: "https://fast.example.com/a2a"
    auth:
      type: bearer
      token: "${FAST_TOKEN}"

  # Custom timeout for slow agent
  slow_agent:
    description: "Complex processing agent"
    endpoint: "https://slow.example.com/a2a"
    timeout: 120.0  # 2 minutes
    retry:
      max_attempts: 5
      backoff: 2.0
    auth:
      type: bearer
      token: "${SLOW_TOKEN}"
```

### Configuration Reference

| Setting              | Default | Description            |
|----------------------|---------|------------------------|
| `timeout`            | 30.0s   | Request timeout        |
| `retry.max_attempts` | 3       | Maximum retry attempts |
| `retry.backoff`      | 1.0s    | Initial backoff delay  |
| `retry.max_backoff`  | 30.0s   | Maximum backoff delay  |

### Retry Behavior

Retries are triggered for:

- **Timeout errors**: Agent didn't respond in time
- **Connection errors**: Network issues
- **HTTP 5xx errors**: Server-side failures

Non-retryable errors (4xx, authentication failures) fail immediately.

---

## Complete Example

Here's a complete workflow with local and external agents working together.

### Step 1: Create Local Tools

Create `tools.py`:

```python
import json
from langchain_core.tools import tool


@tool
def classify_query(query: str) -> str:
    """
    Classify a customer query into categories: crm, product, billing, or general.
    """
    query_lower = query.lower()

    if any(word in query_lower for word in ['account', 'customer', 'profile', 'contact']):
        category = 'crm'
    elif any(word in query_lower for word in ['product', 'feature', 'how to', 'documentation']):
        category = 'product'
    elif any(word in query_lower for word in ['bill', 'invoice', 'payment', 'charge', 'subscription']):
        category = 'billing'
    else:
        category = 'general'

    return json.dumps({"category": category})


@tool
def search_knowledge_base(query: str) -> str:
    """Search the knowledge base for relevant articles."""
    return f"Found 3 articles related to: {query}"


@tool
def create_ticket(title: str, description: str) -> str:
    """Create a support ticket."""
    ticket_id = f"TICKET-{hash(title) % 10000}"
    return f"Created ticket {ticket_id}: {title}"
```

### Step 2: Create the Workflow

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Customer Support with External Agents"
  description: "Routes queries to specialized external agents"

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

external_agents:
  timeout: 30.0
  retry:
    max_attempts: 3
    backoff: 1.0

orchestrator:
  workflows:
    - customer_support

workflows:
  customer_support:
    description: "Multi-platform customer support"
    nodes:
      triage_agent:
        routes:
          router_field: "category"
          crm: salesforce_agent
          product: product_expert
          billing: billing_agent
          general: general_agent
          default: general_agent
      salesforce_agent:
        depends_on: [triage_agent]
      product_expert:
        depends_on: [triage_agent]
      billing_agent:
        depends_on: [triage_agent]
      general_agent:
        depends_on: [triage_agent]

nodes:
  # Local triage agent
  triage_agent:
    description: "Classifies customer queries"
    system_prompt: |
      You are a customer support triage agent. Analyze the query and call
      the classify_query tool to route to the appropriate specialist.
      Categories: crm, product, billing, general
    tools:
      - classify_query

  # External: Salesforce for CRM
  salesforce_agent:
    description: "Handles customer records and CRM operations"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"

  # External: Product knowledge expert
  product_expert:
    description: "Product knowledge expert"
    endpoint: "https://product-agent.example.com/a2a"
    auth:
      type: bearer
      token: "${PRODUCT_AGENT_TOKEN}"

  # External: Billing system
  billing_agent:
    description: "Handles billing inquiries"
    endpoint: "https://billing.example.com/a2a"
    auth:
      type: api_key
      token: "${BILLING_API_KEY}"
      header_name: "X-Billing-Key"

  # Local fallback agent
  general_agent:
    description: "Handles general inquiries"
    system_prompt: |
      You are a general customer support agent. Help with any queries
      that don't fit into specific categories.
    tools:
      - search_knowledge_base
      - create_ticket
```

### Step 3: Run the Workflow

```bash
# Set your API keys
export OPENAI_API_KEY="your-openai-key"
export SALESFORCE_TOKEN="your-salesforce-token"
export PRODUCT_AGENT_TOKEN="your-product-token"
export BILLING_API_KEY="your-billing-key"

# Run with agentflow
agentflow "I need to update my billing address on my account"
```

---

## Streaming Support

AgentFlow supports streaming responses from external A2A agents. When an external agent declares
`capabilities.streaming: true` in its Agent Card, AgentFlow will stream chunks as they arrive.

### Consuming Streaming Events

```python
async for event in orchestrator.run(state, config, stream_tokens=True):
    if event["type"] == "token":
        print(event["content"], end="", flush=True)
```

If streaming isn't supported, AgentFlow automatically falls back to non-streaming mode.

---

## Multi-turn Conversations

AgentFlow automatically maintains conversation context with external agents across multiple invocations within the same
workflow execution.

### How It Works

```
User Query 1 -> External Agent (new task created, taskId=abc123)
    |
    v
State: { external_agent_tasks: { "salesforce_agent": "abc123" } }
    |
    v
User Query 2 -> External Agent (continues task abc123 with full context)
```

### Requirements

- **Persistence enabled**: Checkpointer must be configured
- **Same thread_id**: Subsequent requests must use the same `thread_id`
- **External agent support**: The agent must support task continuation

---

## Environment Variables

All credential fields support environment variable interpolation:

```yaml
auth:
  type: bearer
  token: "${MY_SECRET_TOKEN}"  # Reads from MY_SECRET_TOKEN env var
```

This keeps secrets out of your YAML files.

---

## Troubleshooting

### Connection Errors

1. Verify the endpoint URL is correct
2. Check that the agent exposes `/.well-known/agent.json`
3. Verify authentication credentials
4. Check network connectivity and firewall rules

### Authentication Failures

| Error            | Cause                                      |
|------------------|--------------------------------------------|
| 401 Unauthorized | Check token/credentials                    |
| 403 Forbidden    | Check scopes/permissions                   |
| OAuth2 errors    | Verify token_url, client_id, client_secret |

---

## Summary

External agents allow your AgentFlow workflows to delegate tasks to agents running on other platforms. By simply adding
an `endpoint` field to a node configuration, you can integrate with:

- AWS Bedrock Agents
- Azure AI Agents
- Salesforce Einstein
- Any A2A-compliant service

The A2A Protocol ensures interoperability, while AgentFlow handles authentication, retries, and streaming automatically.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

