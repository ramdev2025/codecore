# Connecting Agents to Data with MCP

## AgentFlow MCP Integration Guide

---

## Introduction

You've built agents that can reason and use tools, but how do they access your organization's data?

- How do agents query databases, APIs, and file systems?
- How do you expose business data without writing custom tools for each source?
- How do you ensure consistent, secure data access across multiple agents?

This is where the **Model Context Protocol (MCP)** becomes essential. In this tutorial, you'll learn how to connect
AgentFlow agents to the MCP Data Platform, giving your agents access to business data through a standardized protocol.

---

## The Problem: Data Access for AI Agents

Without MCP, connecting agents to data requires:

```python
# Custom tool for each data source
@tool
def query_customers(customer_id: str) -> str:
    # Connect to database
    # Handle authentication
    # Execute query
    # Format results
    # Handle errors
    pass

@tool
def query_invoices(invoice_id: str) -> str:
    # Duplicate connection logic
    # Duplicate error handling
    # Different formatting
    pass
```

This approach is:

- **Repetitive**: Each data source needs custom tool code
- **Inconsistent**: Different tools have different interfaces
- **Hard to maintain**: Schema changes require code updates
- **Insecure**: Each tool manages its own authentication

---

## The Solution: MCP Data Platform

MCP provides a standardized protocol for data access:

```yaml
mcp_servers:
  data-platform:
    transport: stdio
    command: ".venv/bin/python"
    args: ["-m", "mcp_data_platform.server"]
    env:
      REGISTRY_URL: "http://localhost:8080"

nodes:
  my_agent:
    mcp_tools:
      - server: data-platform
        tools: [query, get_schema, list_data_sources]
```

This gives agents **automatic access to all registered data sources** through a consistent interface.

| Feature          | Without MCP             | With MCP                 |
|------------------|-------------------------|--------------------------|
| Data access      | Custom tools per source | Standard query interface |
| Schema discovery | Manual documentation    | Automatic via get_schema |
| Multi-tenancy    | Custom implementation   | Built-in app isolation   |
| Data formats     | Custom per source       | Unified JSON response    |

---

## MCP Architecture Overview

Understanding the architecture helps troubleshoot issues:

```
┌─────────────────────────────────────────────────────────────────┐
│                      AgentFlow CLI                              │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    Workflow Orchestrator                  │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐    │  │
│  │  │   Agent 1   │  │   Agent 2   │  │     Agent N     │    │  │
│  │  │ (mcp_tools) │  │ (mcp_tools) │  │   (mcp_tools)   │    │  │
│  │  └──────┬──────┘  └──────┬──────┘  └────────┬────────┘    │  │
│  └─────────┼────────────────┼──────────────────┼─────────────┘  │
│            │                │                  │                │
│            └────────────────┼──────────────────┘                │
│                             │                                   │
│                    ┌────────▼────────┐                          │
│                    │   MCP Client    │  (stdio transport)       │
│                    └────────┬────────┘                          │
└─────────────────────────────┼───────────────────────────────────┘
                              │
┌─────────────────────────────┼───────────────────────────────────┐
│              MCP Data Platform (mcp_data_platform)              │
│                             │                                   │
│                    ┌────────▼────────┐                          │
│                    │   MCP Server    │  (subprocess)            │
│                    │  python -m mcp_data_platform.server        │
│                    └────────┬────────┘                          │
│                             │ HTTP                              │
│                    ┌────────▼────────┐                          │
│                    │    Registry     │  (service discovery)     │
│                    │  localhost:8080 │                          │
│                    └────────┬────────┘                          │
│                             │ HTTP                              │
│                    ┌────────▼────────┐                          │
│                    │    Data API     │  (data access layer)     │
│                    │  localhost:8000 │                          │
│                    └────────┬────────┘                          │
└─────────────────────────────┼───────────────────────────────────┘
                              │
              ┌───────────────┼───────────────┐
              │               │               │
        ┌─────▼─────┐   ┌─────▼─────┐   ┌─────▼─────┐
        │   JSON    │   │    CSV    │   │  Database │
        │   Files   │   │   Files   │   │   (SQL)   │
        └───────────┘   └───────────┘   └───────────┘
```

**Key Components:**

The **MCP Data Platform** (`mcp_data_platform`) is a consolidated package containing:

1. **MCP Client**: Built into AgentFlow, communicates with MCP Server via stdio
2. **MCP Server**: Gateway that routes requests to Data API servers (`python -m mcp_data_platform.server`)
3. **Registry**: Service discovery - knows which Data APIs serve which apps (`python -m mcp_data_platform.registry`)
4. **Data API**: HTTP server that reads manifest.yaml and exposes data sources (`python -m mcp_data_platform.api`)

---

## Part 1: Prerequisites

### Required Components

Before starting, ensure you have:

1. **AgentFlow v0.9.0+** with MCP support
2. **MCP Data Platform** package (`mcp_data_platform`) - consolidated package containing:
    - MCP Server (gateway)
    - Registry (service discovery)
    - Data API (data access layer)
3. **Azure OpenAI** or other LLM provider configured

### Installation

```bash
# Create virtual environment
python -m venv .venv
source .venv/bin/activate

# Install AgentFlow with MCP support
pip install agentflow[workflows]

# Install MCP Data Platform (consolidated package with Registry, MCP Server, and Data API)
pip install mcp_data_platform-0.1.0-py3-none-any.whl

# Install MCP SDK
pip install mcp>=1.2.0
```

### Directory Structure

```
my-mcp-project/
├── .env                    # Environment variables
├── workflow.yaml           # AgentFlow workflow configuration
├── manifest.yaml           # Data source definitions
├── data/
│   ├── customers.csv       # Sample data files
│   ├── orders.json
│   └── checkpoints.db      # State persistence
└── .venv/                  # Python virtual environment
```

---

## Part 2: Setting Up the Data Sources

### Step 1: Create the Manifest

The `manifest.yaml` defines your application and its data sources. Create `manifest.yaml`:

```yaml
# Application identifier - used in all MCP tool calls
app_id: "order-management"
name: "Order Management System"
description: "Customer orders and inventory data"

# Data source definitions
data_sources:
  customers:
    type: file
    description: "Customer account information"
    config:
      path: "data/customers.csv"
      format: csv

  orders:
    type: file
    description: "Order records with status"
    config:
      path: "data/orders.json"
      format: json

  inventory:
    type: file
    description: "Product inventory levels"
    config:
      path: "data/inventory.csv"
      format: csv
```

**Important:** The `app_id` is required for all MCP tool calls. Agents must pass this value to identify which
application's data to access.

### Step 2: Create Sample Data

Create `data/customers.csv`:

```csv
customer_id,name,email,status,credit_limit
CUST001,Acme Corp,contact@acme.com,active,50000
CUST002,TechStart Inc,info@techstart.io,active,25000
CUST003,Global Services,sales@global.com,suspended,0
```

Create `data/orders.json`:

```json
{
  "records": [
    {
      "order_id": "ORD-001",
      "customer_id": "CUST001",
      "product": "Enterprise License",
      "amount": 15000,
      "status": "completed"
    },
    {
      "order_id": "ORD-002",
      "customer_id": "CUST001",
      "product": "Support Package",
      "amount": 5000,
      "status": "pending"
    },
    {
      "order_id": "ORD-003",
      "customer_id": "CUST002",
      "product": "Starter License",
      "amount": 2500,
      "status": "completed"
    }
  ]
}
```

Create `data/inventory.csv`:

```csv
product_id,name,quantity,reorder_level
PROD001,Enterprise License,unlimited,0
PROD002,Support Package,50,10
PROD003,Starter License,unlimited,0
PROD004,Hardware Kit,25,5
```

---

## Part 3: Configuring the Workflow

### Step 1: Create Environment Configuration

Create `.env` with your LLM credentials:

```bash
# Azure OpenAI Configuration
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_DEPLOYMENT=gpt-4o
OPENAI_API_VERSION=2024-08-01-preview

# For API key authentication (if not using Azure AD)
# AZURE_OPENAI_API_KEY=your-api-key

# OpenTelemetry (optional)
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

### Step 2: Create the Workflow

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Order Management with MCP"
  description: "Multi-agent workflow using MCP Data Platform"
  author: "Your Team"
  tags: ["mcp", "data-platform", "orders"]

llm:
  provider: azure_openai
  config:
    model: "${AZURE_DEPLOYMENT}"
    azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
    api_version: "${OPENAI_API_VERSION}"
    azure_identity: true        # Use Azure AD authentication
    temperature: 0.5
    max_tokens: 2048

# MCP Server Configuration
mcp_servers:
  data-platform:
    transport: stdio
    command: ".venv/bin/python"   # Full path to Python in venv
    args: ["-m", "mcp_data_platform.server"]
    env:
      REGISTRY_URL: "http://localhost:8080"
    timeout: 30.0
    retry:
      max_attempts: 3
      backoff: 1.0
    # Context field for auto-documentation (injected into system prompts)
    context: |
      This server provides access to the order-management application.

      **Required Parameters:**
      - app_id: Always use "order-management"
      - source_id: One of "customers", "orders", or "inventory"

      **Filter Operators:**
      eq, ne, gt, gte, lt, lte, contains, in

orchestrator:
  workflows:
    - "Order Analysis"

workflows:
  "Order Analysis":
    description: "Analyze customer orders and inventory"
    nodes:
      "Data Retriever":
        depends_on: []
      "Order Analyzer":
        depends_on: ["Data Retriever"]

nodes:
  "Data Retriever":
    description: "Retrieves customer and order data via MCP"
    system_prompt: |
      You are a Data Retrieval Agent with access to the MCP Data Platform.

      CRITICAL: You MUST always provide these required parameters for every tool call:
      - app_id: "order-management" (required for ALL tools)
      - source_id: the data source name (required for query and get_schema)

      Available MCP tools:
      - list_data_sources: List available data sources
        Required params: app_id (string)
      - get_schema: Get schema for a data source
        Required params: app_id (string), source_id (string)
      - query: Query data from a source
        Required params: app_id (string), source_id (string)
        Optional: filters (array), sort_by (string), page (int), page_size (int)

      Data sources available: customers, orders, inventory

      Example tool calls:

      List data sources:
      { "app_id": "order-management" }

      Get schema:
      { "app_id": "order-management", "source_id": "customers" }

      Query with filters:
      {
        "app_id": "order-management",
        "source_id": "orders",
        "filters": [{"field": "customer_id", "op": "eq", "value": "CUST001"}]
      }

      Filter operators: eq, ne, gt, gte, lt, lte, contains, in

      Your task:
      1. Query the requested data using MCP tools
      2. Return the data for the next agent to analyze
    mcp_tools:
      - server: data-platform
        tools: [query, list_data_sources, get_schema]

  "Order Analyzer":
    description: "Analyzes order data and generates insights"
    system_prompt: |
      You are an Order Analysis Agent.

      Based on the data provided by the previous agent:
      1. Summarize key metrics (total orders, revenue, etc.)
      2. Identify any issues or anomalies
      3. Provide actionable insights

      Present your analysis in a clear, structured format.
    # No MCP tools - uses LLM reasoning on data from previous agent
```

(Persistence is configured at deploy time via `--persistence` /
`AGENTFLOW_PERSISTENCE` — see [PERSISTENCE.md](../PERSISTENCE.md).)

### Key Configuration Points

**MCP Server Command:**

```yaml
command: ".venv/bin/python"   # Use full path to venv Python
args: ["-m", "mcp_data_platform.server"]
```

The command must be the full path to Python in your virtual environment, not just `python`, because the subprocess
doesn't inherit your shell's PATH.

**Azure AD Authentication:**

```yaml
azure_identity: true
```

For RBAC-based authentication, set `azure_identity: true`. This uses `DefaultAzureCredential` from the Azure SDK.

**Tool Parameter Requirements:**

```yaml
system_prompt: |
  CRITICAL: You MUST always provide these required parameters:
  - app_id: "order-management" (required for ALL tools)
  - source_id: the data source name
```

Always include explicit instructions about required parameters in the system prompt. LLMs may otherwise omit required
fields.

---

## Part 4: Starting the Services

Before running the AgentFlow workflow, you must start the supporting services in separate terminals.

### Step 1: Start the Registry (Terminal 1)

The Registry service handles MCP application discovery:

```bash
# Start the registry on port 8080
.venv/bin/python -m mcp_data_platform.registry --port 8080
```

Or if using containers:

```bash
podman start mcp-registry
```

### Step 2: Start the Data API (Terminal 2)

The Data API reads your manifest.yaml and serves data:

```bash
# Set environment variables
export APP_DIR=.                              # Directory with manifest.yaml
export SERVICE_URL=http://localhost:8000      # URL for registry registration
export REGISTRY_URL=http://localhost:8080     # Registry endpoint

# Start the Data API on port 8000
.venv/bin/python -m mcp_data_platform.api --port 8000
```

You should see output like:

```
INFO:     Started server process
INFO:     Registered with registry: order-management -> http://localhost:8000
INFO:     Uvicorn running on http://127.0.0.1:8000
```

### Step 3: Verify the Setup

Test that the Data API is accessible:

```bash
# Check health
curl http://localhost:8000/health

# List data sources
curl http://localhost:8000/api/v1/order-management/sources
```

---

## Part 5: Running the Workflow

### Using AgentFlow CLI

```bash
# Run the workflow
.venv/bin/agentflow "Show me all orders for customer CUST001"
```

**Expected Output:**

```
╭──────────────────────────────────────────────────────────────────╮
│ AgentFlow CLI                                                    │
│ Run AI workflows from the command line                           │
╰──────────────────────────────────────────────────────────────────╯
Connecting to MCP servers...
  [OK] MCP server 'data-platform': 8 tools available
[OK] Checkpointer enabled
[OK] MCP servers connected: 1

╭───────────────────────────────────╮
│ WORKFLOW: Order Analysis          │
╰───────────────────────────────────╯

[AGENT] Data Retriever thinking...
[AGENT] Data Retriever completed

[TOOL] query
  {
    "records": [
      {
        "order_id": "ORD-001",
        "customer_id": "CUST001",
        "product": "Enterprise License",
        "amount": 15000,
        "status": "completed"
      },
      {
        "order_id": "ORD-002",
        "customer_id": "CUST001",
        "product": "Support Package",
        "amount": 5000,
        "status": "pending"
      }
    ],
    "total_count": 2,
    "page": 1,
    "page_size": 100
  }

[AGENT] Order Analyzer
╭───────────────────────────────────────────────────────────────────╮
│ ## Order Analysis for CUST001 (Acme Corp)                         │
│                                                                   │
│ ### Summary                                                       │
│ - Total Orders: 2                                                 │
│ - Total Revenue: $20,000                                          │
│ - Completed: 1 ($15,000)                                          │
│ - Pending: 1 ($5,000)                                             │
│                                                                   │
│ ### Insights                                                      │
│ - High-value customer with Enterprise License                     │
│ - Pending support package order - follow up recommended           │
╰───────────────────────────────────────────────────────────────────╯
Closing MCP server connections...
  [OK] MCP server 'data-platform' disconnected
```

### Using Python

Create `main.py` for programmatic access:

```python
"""
MCP Integration Demo

Demonstrates AgentFlow with MCP Data Platform integration.

Run with:
    python main.py

Prerequisites:
    - Registry service running on port 8080
    - Data API running on port 8000
    - .env file with Azure OpenAI credentials
"""
import asyncio
from dotenv import load_dotenv
from agentflow import AsyncWorkflowOrchestrator

# Load environment variables
load_dotenv()


async def run_order_query():
    """Query orders through MCP Data Platform."""
    print("=" * 60)
    print("AgentFlow MCP Integration Demo")
    print("=" * 60)

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        enable_persistence=True
    ) as orchestrator:

        # Run workflow
        print("\nQuerying orders for customer CUST001...")

        async for event in orchestrator.run(
            state={"messages": [
                {"role": "user", "content": "Show me all orders for customer CUST001 and analyze them"}
            ]},
            config={"configurable": {"thread_id": "demo-1"}},
            default_workflow="Order Analysis"
        ):
            if event['type'] == 'agent':
                print(f"\n[Agent: {event.get('name', 'Unknown')}]")
                print(event['content'])
            elif event['type'] == 'tool':
                print(f"\n[Tool: {event['name']}]")
                # Truncate long tool responses
                content = event['content']
                if len(content) > 500:
                    print(content[:500] + "...")
                else:
                    print(content)


async def run_schema_discovery():
    """Discover available data sources and schemas."""
    print("\n" + "=" * 60)
    print("Schema Discovery Demo")
    print("=" * 60)

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        enable_persistence=True
    ) as orchestrator:

        async for event in orchestrator.run(
            state={"messages": [
                {"role": "user", "content": "List all available data sources and show me the schema for the customers source"}
            ]},
            config={"configurable": {"thread_id": "demo-schema"}},
            default_workflow="Order Analysis"
        ):
            if event['type'] == 'agent':
                print(f"\n[Agent]: {event['content'][:500]}...")
            elif event['type'] == 'tool':
                print(f"\n[Tool: {event['name']}]: {event['content']}")


async def main():
    """Run all demos."""
    await run_order_query()
    await run_schema_discovery()


if __name__ == "__main__":
    asyncio.run(main())
```

---

## Part 6: Query Filters and Operations

### Filter Operators

MCP Data Platform supports these filter operators:

| Operator   | Description                        | Example                                                           |
|------------|------------------------------------|-------------------------------------------------------------------|
| `eq`       | Equal                              | `{"field": "status", "op": "eq", "value": "active"}`              |
| `ne`       | Not equal                          | `{"field": "status", "op": "ne", "value": "suspended"}`           |
| `gt`       | Greater than                       | `{"field": "amount", "op": "gt", "value": 1000}`                  |
| `gte`      | Greater than or equal              | `{"field": "amount", "op": "gte", "value": 1000}`                 |
| `lt`       | Less than                          | `{"field": "quantity", "op": "lt", "value": 10}`                  |
| `lte`      | Less than or equal                 | `{"field": "quantity", "op": "lte", "value": 10}`                 |
| `contains` | String contains (case-insensitive) | `{"field": "name", "op": "contains", "value": "corp"}`            |
| `in`       | Value in list                      | `{"field": "status", "op": "in", "value": ["active", "pending"]}` |

### Example Queries

**Simple equality filter:**

```json
{
  "app_id": "order-management",
  "source_id": "orders",
  "filters": [{"field": "status", "op": "eq", "value": "pending"}]
}
```

**Multiple filters (AND logic):**

```json
{
  "app_id": "order-management",
  "source_id": "orders",
  "filters": [
    {"field": "customer_id", "op": "eq", "value": "CUST001"},
    {"field": "amount", "op": "gt", "value": 5000}
  ]
}
```

**With pagination:**

```json
{
  "app_id": "order-management",
  "source_id": "customers",
  "page": 1,
  "page_size": 10,
  "sort_by": "name",
  "sort_order": "asc"
}
```

---

## Part 7: Troubleshooting

### Problem: "No such file or directory: 'python'"

**Cause:** The MCP server subprocess can't find Python because it doesn't inherit your shell's PATH.

**Solution:** Use the full path to Python in your virtual environment:

```yaml
mcp_servers:
  data-platform:
    command: ".venv/bin/python"    # Not just "python"
    args: ["-m", "mcp_data_platform.server"]
```

### Problem: "Application not found: order-management"

**Cause:** The MCP server can't discover your application from the Registry.

**Checklist:**

1. Is the Registry service running? `curl http://localhost:8080/health`
2. Is the Data API running? `curl http://localhost:8000/health`
3. Did the Data API register with the Registry? Check Data API logs for "Registered with registry"
4. Is `SERVICE_URL` set correctly when starting Data API?

**Solution:**

```bash
# Start Data API with explicit registration
SERVICE_URL=http://localhost:8000 REGISTRY_URL=http://localhost:8080 \
  .venv/bin/python -m mcp_data_platform.api --port 8000
```

### Problem: "Input validation error: None is not of type 'string'"

**Cause:** LangChain passes `None` for optional parameters, but MCP SDK validates all fields.

**Solution:** This is fixed in AgentFlow v0.9.0+. The MCP client filters out `None` values before calling tools. Ensure
you have the latest version:

```bash
pip install --force-reinstall agentflow[workflows]
```

### Problem: "ValueError: Out of range float values are not JSON compliant: nan"

**Cause:** CSV files with empty cells are read as NaN by pandas, which isn't JSON serializable.

**Solution:** This is fixed in mcp_data_platform v0.1.0+. The file adapter converts NaN to `null`. Ensure you have the
latest version:

```bash
pip install --force-reinstall mcp_data_platform-0.1.0-py3-none-any.whl
```

### Problem: Agent doesn't include app_id in tool calls

**Cause:** The LLM isn't following instructions about required parameters.

**Solution:** Make the instructions more explicit in the system prompt:

```yaml
system_prompt: |
  CRITICAL: You MUST always provide these required parameters for every tool call:
  - app_id: "order-management" (required for ALL tools)
  - source_id: the data source name (required for query and get_schema)

  Example tool call:
  {
    "app_id": "order-management",
    "source_id": "customers"
  }
```

### Problem: MCP connection timeout

**Cause:** Network issues or the MCP server is slow to start.

**Solution:** Increase timeout and retry settings:

```yaml
mcp_servers:
  data-platform:
    timeout: 60.0        # Increase from default 30s
    retry:
      max_attempts: 5    # More retry attempts
      backoff: 2.0       # Longer backoff between retries
```

---

## Part 8: Best Practices

### 1. Always Specify Full Python Path

```yaml
mcp_servers:
  data-platform:
    command: ".venv/bin/python"    # Absolute or relative to project
```

### 2. Include Explicit Tool Instructions

```yaml
system_prompt: |
  CRITICAL: Always include these parameters:
  - app_id: "your-app-id"
  - source_id: "source-name"

  Example:
  { "app_id": "your-app-id", "source_id": "customers" }
```

### 3. Use Azure AD for Production

```yaml
llm:
  config:
    azure_identity: true    # Uses DefaultAzureCredential
```

This is more secure than API keys and works with RBAC.

### 4. Use the Context Field for Auto-Documentation

Instead of repeating tool documentation in every system prompt, use the `context` field on your MCP server
configuration:

```yaml
mcp_servers:
  data-platform:
    transport: stdio
    command: ".venv/bin/python"
    args: ["-m", "mcp_data_platform.server"]
    context: |
      **Required Parameters for ALL tools:**
      - app_id: "order-management"

      **Available Data Sources:**
      - customers: Customer records (fields: customer_id, name, email, status)
      - orders: Order transactions (fields: order_id, customer_id, amount, status)
      - inventory: Product inventory (fields: product_id, name, quantity)
```

This context is automatically injected into agent system prompts along with auto-generated tool documentation from the
MCP schema. Benefits:

- Tool parameter documentation is always up-to-date (read from MCP server)
- Domain-specific hints stay with the server config, not scattered across nodes
- Reduces duplication when multiple agents use the same server

### 4. Enable Persistence for Recovery

Persistence is on by default (SQLite at `.agentflow/checkpoints.db`).
Configure the backend at deploy time:

```bash
# Custom path
agentflow --persistence sqlite --db-path /data/checkpoints.db "..."

# Or via env vars
export CHECKPOINTER_DB_PATH=/data/checkpoints.db
agentflow "..."
```

This allows workflows to resume after failures. See
[PERSISTENCE.md](../PERSISTENCE.md) for the full env-var table.

### 5. Structure Data Sources Logically

```yaml
# manifest.yaml - organize by domain
data_sources:
  # Customer domain
  customers:
    description: "Customer master data"
  customer_contacts:
    description: "Customer contact information"

  # Order domain
  orders:
    description: "Order transactions"
  order_items:
    description: "Line items within orders"
```

### 6. Use Meaningful App IDs

```yaml
# Good - descriptive and consistent
app_id: "order-management"
app_id: "inventory-system"
app_id: "customer-portal"

# Bad - ambiguous or generic
app_id: "app1"
app_id: "data"
app_id: "test"
```

---

## Summary

You now know how to:

- Configure MCP servers in AgentFlow workflows
- Create data source manifests
- Set up the MCP infrastructure (Registry, Data API)
- Query data through MCP tools
- Troubleshoot common issues

### Key Takeaways

| Component  | Purpose                | Port  |
|------------|------------------------|-------|
| Registry   | Service discovery      | 8080  |
| Data API   | Data access layer      | 8000  |
| MCP Server | Gateway (subprocess)   | stdio |
| AgentFlow  | Workflow orchestration | -     |

### Required Parameters

| Tool                | Required Parameters   |
|---------------------|-----------------------|
| `list_data_sources` | `app_id`              |
| `get_schema`        | `app_id`, `source_id` |
| `query`             | `app_id`, `source_id` |

### Architecture Flow

```
User Query -> AgentFlow -> MCP Client -> MCP Server -> Registry -> Data API -> Data
```

---

## Conclusion

MCP (Model Context Protocol) provides a standardized way for your agents to access business data. By configuring MCP
servers in your workflow YAML, you can give agents access to databases, APIs, and file systems through a consistent
interface.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

