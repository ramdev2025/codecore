# FastAPI Integration

## Introduction

You've built powerful multi-agent workflows with AgentFlow, but how do you expose them to users through a web interface?
In this tutorial, you'll learn how to:

- Create a FastAPI backend that runs AgentFlow workflows
- Stream real-time responses via WebSocket
- Handle human-in-the-loop interruptions
- Manage conversation sessions with persistence

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Web Client (React/Vue/etc)              │
└───────────────────────────┬─────────────────────────────────┘
                            │ WebSocket / REST
┌───────────────────────────▼─────────────────────────────────┐
│                        FastAPI App                          │
│  ┌────────────────────────────────────────────────────────┐ │
│  │              AsyncWorkflowOrchestrator                 │ │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐                 │ │
│  │  │ Agent 1 │  │ Agent 2 │  │ Agent N │                 │ │
│  │  └────┬────┘  └────┬────┘  └────┬────┘                 │ │
│  │       └────────────┼────────────┘                      │ │
│  │                    ▼                                   │ │
│  │               Tools Module                             │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## Prerequisites

- Python 3.10 or higher
- AgentFlow installed
- FastAPI and uvicorn

```bash
pip install fastapi uvicorn python-dotenv
```

---

## Part 1: Basic FastAPI Setup

### Project Structure

```
my-fastapi-app/
├── app.py              # FastAPI application
├── settings.py         # Configuration settings
├── workflow.yaml       # AgentFlow workflow definition
├── tools.py            # Tool functions
├── data/
│   └── checkpoints.db  # State persistence
└── .env                # Environment variables
```

### Step 1: Create Settings Module

Create `settings.py`:

```python
import os

# Workflow configuration
CONFIG_PATH = os.getenv("CONFIG_PATH", "workflow.yaml")
TOOLS_MODULE = os.getenv("TOOLS_MODULE", "tools")

# Persistence
PERSISTENCE_ENABLED = os.getenv("PERSISTENCE_ENABLED", "true").lower() == "true"
CHECKPOINTER_PATH = os.getenv("CHECKPOINTER_PATH", ".agentflow/checkpoints.db")

# Logging
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
```

### Step 2: Create the FastAPI Application

Create `app.py`:

```python
import logging
import uuid
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agentflow import AsyncWorkflowOrchestrator

import settings

# Configure logging
logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL))
logger = logging.getLogger(__name__)


# Pydantic models
class WorkflowRequest(BaseModel):
    query: str
    thread_id: Optional[str] = None
    recursion_limit: int = 100


class HealthResponse(BaseModel):
    status: str
    version: str


class ConfigResponse(BaseModel):
    workflows: list[str]
    version: str


# FastAPI lifespan
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown."""
    logger.info("Starting FastAPI application")
    logger.info(f"Workflow config: {settings.CONFIG_PATH}")
    logger.info(f"Persistence: {settings.PERSISTENCE_ENABLED}")
    yield
    logger.info("Shutting down")


# Create FastAPI app
app = FastAPI(
    title="AgentFlow API",
    description="REST and WebSocket API for AgentFlow workflows",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# REST endpoints
@app.get("/api/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(status="healthy", version="1.0.0")


@app.get("/api/config", response_model=ConfigResponse)
async def get_config():
    """Get available workflows."""
    async with AsyncWorkflowOrchestrator(
        config_path=settings.CONFIG_PATH,
        tools_module=settings.TOOLS_MODULE,
        enable_persistence=False
    ) as orchestrator:
        workflows = list(orchestrator.parsed_config.workflows.keys())
        return ConfigResponse(workflows=workflows, version="1.0.0")


# WebSocket endpoint for streaming
@app.websocket("/ws/workflow")
async def workflow_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for running workflows with real-time streaming.

    Client sends: {"query": "...", "thread_id": "...", "recursion_limit": 100}
    Server sends: {"type": "agent|tool|complete|error", ...}
    """
    await websocket.accept()
    logger.info("WebSocket connection established")

    try:
        # Receive request from client
        data = await websocket.receive_json()
        request = WorkflowRequest(**data)

        # Generate thread_id if not provided
        thread_id = request.thread_id or str(uuid.uuid4())
        execution_id = str(uuid.uuid4())

        # Send status message
        await websocket.send_json({
            "type": "status",
            "message": "Starting workflow",
            "thread_id": thread_id,
            "execution_id": execution_id
        })

        # Create orchestrator and run workflow
        async with AsyncWorkflowOrchestrator(
            config_path=settings.CONFIG_PATH,
            tools_module=settings.TOOLS_MODULE,
            enable_persistence=settings.PERSISTENCE_ENABLED,
            checkpointer_path=settings.CHECKPOINTER_PATH,
        ) as orchestrator:

            # Prepare initial state
            initial_state = {
                "messages": [{"role": "user", "content": request.query}]
            }

            # Run configuration
            run_config = {
                "configurable": {"thread_id": thread_id}
            }

            # Stream workflow results
            async for event in orchestrator.run(
                state=initial_state,
                config=run_config,
                recursion_limit=request.recursion_limit,
                stream_tokens=True
            ):
                await websocket.send_json(event)

        # Send completion message
        await websocket.send_json({
            "type": "complete",
            "execution_id": execution_id,
            "thread_id": thread_id
        })

    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception as e:
        logger.error(f"Workflow error: {e}")
        try:
            await websocket.send_json({
                "type": "error",
                "message": str(e)
            })
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### Step 3: Create a Simple Workflow

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Support Assistant"
  description: "Customer support workflow"

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

orchestrator:
  workflows:
    - support

workflows:
  support:
    description: "Handle customer support queries"
    nodes:
      assistant:
        depends_on: []

nodes:
  assistant:
    description: "Customer support assistant"
    tools:
      - search_knowledge_base
      - create_ticket
    system_prompt: |
      You are a helpful customer support assistant.
      Use the available tools to help customers with their questions.
```

Create `tools.py`:

```python
from langchain_core.tools import tool


@tool
def search_knowledge_base(query: str) -> str:
    """Search the knowledge base for relevant articles."""
    # In production, this would query a real knowledge base
    return f"Found 3 articles related to: {query}"


@tool
def create_ticket(title: str, description: str, priority: str = "medium") -> str:
    """Create a support ticket."""
    ticket_id = f"TICKET-{hash(title) % 10000}"
    return f"Created ticket {ticket_id}: {title} (Priority: {priority})"
```

### Step 4: Run the Application

```bash
export OPENAI_API_KEY="your-api-key"
python app.py
```

Access the API at http://localhost:8000 and the docs at http://localhost:8000/docs.

---

## Part 2: WebSocket Message Types

The WebSocket endpoint streams events with different types:

| Type       | Description       | Fields                                 |
|------------|-------------------|----------------------------------------|
| `status`   | Status updates    | `message`, `thread_id`, `execution_id` |
| `agent`    | Agent response    | `name`, `content`                      |
| `tool`     | Tool call result  | `name`, `content`                      |
| `token`    | Streaming token   | `content`                              |
| `complete` | Workflow finished | `execution_id`, `thread_id`            |
| `error`    | Error occurred    | `message`                              |

### Client Example (JavaScript)

```javascript
const ws = new WebSocket('ws://localhost:8000/ws/workflow');

ws.onopen = () => {
  ws.send(JSON.stringify({
    query: "How do I reset my password?",
    thread_id: "user-123"
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);

  switch (data.type) {
    case 'agent':
      console.log(`[${data.name}]: ${data.content}`);
      break;
    case 'tool':
      console.log(`Tool ${data.name}: ${JSON.stringify(data.content)}`);
      break;
    case 'token':
      process.stdout.write(data.content);
      break;
    case 'complete':
      console.log('Workflow completed');
      ws.close();
      break;
    case 'error':
      console.error('Error:', data.message);
      break;
  }
};
```

---

## Part 3: Human-in-the-Loop Support

For workflows that require human approval, handle the `GraphInterrupt` exception.

### Update app.py

Add this import and modify the WebSocket handler:

```python
from langgraph.errors import GraphInterrupt
from langgraph.types import Command


@app.websocket("/ws/workflow")
async def workflow_websocket(websocket: WebSocket):
    await websocket.accept()

    try:
        data = await websocket.receive_json()
        request = WorkflowRequest(**data)
        thread_id = request.thread_id or str(uuid.uuid4())

        async with AsyncWorkflowOrchestrator(
                config_path=settings.CONFIG_PATH,
                tools_module=settings.TOOLS_MODULE,
                enable_persistence=True,
                checkpointer_path=settings.CHECKPOINTER_PATH,
        ) as orchestrator:

            initial_state = {
                "messages": [{"role": "user", "content": request.query}]
            }
            run_config = {"configurable": {"thread_id": thread_id}}

            try:
                async for event in orchestrator.run(
                        state=initial_state,
                        config=run_config,
                        stream_tokens=True
                ):
                    await websocket.send_json(event)

            except GraphInterrupt as interrupt_exc:
                # Workflow paused for human input
                state = await orchestrator.get_state(thread_id)

                # Find interrupt data
                for task in state.get("tasks", []):
                    if hasattr(task, "interrupts") and task.interrupts:
                        for interrupt_data in task.interrupts:
                            await websocket.send_json({
                                "type": "interrupt",
                                "thread_id": thread_id,
                                "interrupt_data": interrupt_data.value,
                                "message": "Workflow paused - awaiting input"
                            })

    except WebSocketDisconnect:
        logger.info("Client disconnected")
    except Exception as e:
        await websocket.send_json({"type": "error", "message": str(e)})


@app.websocket("/ws/workflow/resume/{thread_id}")
async def resume_workflow(websocket: WebSocket, thread_id: str):
    """Resume a paused workflow with human response."""
    await websocket.accept()

    try:
        # Receive human response
        data = await websocket.receive_json()
        human_response = data.get("response", "")

        async with AsyncWorkflowOrchestrator(
                config_path=settings.CONFIG_PATH,
                tools_module=settings.TOOLS_MODULE,
                enable_persistence=True,
                checkpointer_path=settings.CHECKPOINTER_PATH,
        ) as orchestrator:

            run_config = {"configurable": {"thread_id": thread_id}}

            # Resume with human response
            async for event in orchestrator.run(
                    state=None,  # State loaded from checkpoint
                    config=run_config,
                    stream_tokens=True,
                    command=Command(resume=human_response)
            ):
                await websocket.send_json(event)

        await websocket.send_json({
            "type": "complete",
            "thread_id": thread_id
        })

    except Exception as e:
        await websocket.send_json({"type": "error", "message": str(e)})
```

### Human Approval Tool

Add to `tools.py`:

```python
from typing import Literal
from langgraph.types import interrupt


@tool
def request_human_approval(
    question: str,
    context: str,
    action_type: Literal["execute", "modify", "approve", "other"],
    proposed_action: str = ""
) -> str:
    """
    Request human approval before proceeding with an action.

    Args:
        question: The question to ask the human
        context: Context about why approval is needed
        action_type: Type of action requiring approval
        proposed_action: The proposed action if applicable

    Returns:
        The human's response
    """
    approval_request = {
        "question": question,
        "context": context,
        "action_type": action_type,
        "proposed_action": proposed_action
    }

    # This pauses the workflow until human responds
    human_response = interrupt(approval_request)

    return human_response
```

---

## Part 4: Session Management

### List Conversation Threads

Add a REST endpoint to list threads:

```python
@app.get("/api/threads")
async def list_threads():
    """List all conversation threads."""
    async with AsyncWorkflowOrchestrator(
            config_path=settings.CONFIG_PATH,
            tools_module=settings.TOOLS_MODULE,
            enable_persistence=True,
            checkpointer_path=settings.CHECKPOINTER_PATH,
    ) as orchestrator:
        threads = await orchestrator.list_threads()
        return {"threads": threads}


@app.get("/api/threads/{thread_id}/state")
async def get_thread_state(thread_id: str):
    """Get the current state of a thread."""
    async with AsyncWorkflowOrchestrator(
            config_path=settings.CONFIG_PATH,
            tools_module=settings.TOOLS_MODULE,
            enable_persistence=True,
            checkpointer_path=settings.CHECKPOINTER_PATH,
    ) as orchestrator:
        state = await orchestrator.get_state(thread_id)
        if not state:
            raise HTTPException(status_code=404, detail="Thread not found")
        return state
```

---

## Part 5: Production Considerations

### Environment Configuration

Create `.env`:

```bash
# LLM Configuration
OPENAI_API_KEY=your-api-key

# Workflow
CONFIG_PATH=workflow.yaml
TOOLS_MODULE=tools

# Persistence
PERSISTENCE_ENABLED=true
CHECKPOINTER_PATH=.agentflow/checkpoints.db

# Logging
LOG_LEVEL=INFO

# OpenTelemetry (optional)
OTEL_TRACES_ENABLED=false
OTEL_SERVICE_NAME=agentflow-api
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

### CORS Configuration

For production, restrict CORS origins:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://yourdomain.com"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
```

### Running with Uvicorn

```bash
# Development
uvicorn app:app --reload --host 0.0.0.0 --port 8000

# Production (single worker with SQLite)
uvicorn app:app --host 0.0.0.0 --port 8000

# Production (multiple workers - requires PostgreSQL)
uvicorn app:app --host 0.0.0.0 --port 8000 --workers 4
```

### SQLite Worker Limitation

When using SQLite persistence (`aiosqlite`), you must run with a **single worker**. SQLite uses file-based
storage that cannot handle concurrent writes from multiple processes.

With multiple workers:

- Each worker opens separate SQLite connections
- Concurrent writes from multiple workers cause "database is locked" errors

**Recommendations:**

| Deployment                | Workers             | Persistence Backend |
|---------------------------|---------------------|---------------------|
| Development               | 1 (with `--reload`) | SQLite              |
| Production (low traffic)  | 1                   | SQLite              |
| Production (high traffic) | Multiple            | PostgreSQL          |

For multi-worker production deployments, use PostgreSQL:

```python
# settings.py
import os

PERSISTENCE_BACKEND = os.getenv("PERSISTENCE_BACKEND", "sqlite")
DATABASE_URL = os.getenv("DATABASE_URL", "")
CHECKPOINTER_PATH = os.getenv("CHECKPOINTER_PATH", ".agentflow/checkpoints.db")
```

```python
# app.py - modify the orchestrator initialization
from agentflow.core.config_models import (
    PersistenceConfig,
    PersistenceBackend,
    PostgresConfig,
    SQLiteConfig,
    CheckpointerConfig,
    StoreConfig,
)


def get_persistence_config():
    if settings.PERSISTENCE_BACKEND == "postgres":
        return PersistenceConfig(
            backend=PersistenceBackend.POSTGRES,
            postgres=PostgresConfig(
                connection_string=settings.DATABASE_URL,
                pool_size=20
            ),
            checkpointer=CheckpointerConfig(enabled=True),
            store=StoreConfig(enabled=True),
        )
    else:
        return PersistenceConfig(
            backend=PersistenceBackend.SQLITE,
            sqlite=SQLiteConfig(db_path=settings.CHECKPOINTER_PATH),
            checkpointer=CheckpointerConfig(enabled=True),
        )
```

---

## Summary

You now know how to:

- Create a FastAPI backend for AgentFlow workflows
- Stream real-time responses via WebSocket
- Handle human-in-the-loop interruptions
- Manage conversation sessions with persistence
- Configure for production deployment

This architecture supports both REST APIs for simple operations and WebSocket connections for real-time streaming,
making it suitable for building responsive AI-powered web applications.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

