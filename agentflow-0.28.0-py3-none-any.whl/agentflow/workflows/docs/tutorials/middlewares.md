# Controlling Agent Behavior with Middleware

## AgentFlow Middleware Guide

---

## Introduction

You've built agents that work well, but how do you:

- Prevent runaway agents from making too many API calls?
- Require human approval before executing dangerous operations?
- Automatically summarize long conversations to save tokens?
- Retry failed tool calls without changing your agent code?

This is where **middleware** becomes essential. In this tutorial, you'll learn how to configure LangChain middleware
through YAML to add guardrails, controls, and behaviors to your agents without modifying their code.

---

## The Problem: Uncontrolled Agent Behavior

Without middleware, agents have unlimited freedom:

```python
# Agent decides to call 50 tools in a loop
# Agent executes delete_database without approval
# Agent runs up a $500 API bill in one conversation
# Agent crashes when a tool times out
```

You could add these controls to every agent's code, but that's:

- Repetitive and error-prone
- Hard to change across all agents
- Mixing concerns (business logic vs. operational controls)

---

## The Solution: Declarative Middleware

AgentFlow lets you configure middleware in YAML, separate from your agent logic:

```yaml
nodes:
  my_agent:
    middleware:
      - type: model_call_limit
        model_call_limit:
          run_limit: 15
          exit_behavior: end
```

This applies controls **without touching your agent code**.

| Feature            | Without Middleware   | With Middleware         |
|--------------------|----------------------|-------------------------|
| Runaway prevention | Manual code          | YAML config             |
| Human approval     | Custom tools         | Declarative             |
| Token management   | Hope for the best    | Automatic summarization |
| Error recovery     | Try/catch everywhere | Automatic retries       |

---

## Part 1: Understanding Middleware

### What is Middleware?

Middleware wraps around your agent's model calls, intercepting requests and responses:

```
┌─────────────────────────────────────────────┐
│           Agent Execution Loop              │
│  ┌───────────────────────────────────────┐  │
│  │  Middleware 1: model_call_limit       │  │
│  │  ┌─────────────────────────────────┐  │  │
│  │  │  Middleware 2: summarization    │  │  │
│  │  │  ┌───────────────────────────┐  │  │  │
│  │  │  │  Middleware 3: tool_retry │  │  │  │
│  │  │  │  ┌─────────────────────┐  │  │  │  │
│  │  │  │  │    LLM Model Call   │  │  │  │  │
│  │  │  │  └─────────────────────┘  │  │  │  │
│  │  │  └───────────────────────────┘  │  │  │
│  │  └─────────────────────────────────┘  │  │
│  └───────────────────────────────────────┘  │
└─────────────────────────────────────────────┘
```

Each middleware can:

- **Before**: Modify state before the model call
- **After**: Modify response after the model call
- **Intercept**: Block or redirect the call entirely

### Middleware vs Plugins

AgentFlow has two extension mechanisms. Understanding when to use each is important:

| Aspect            | Middleware                   | Plugins                                          |
|-------------------|------------------------------|--------------------------------------------------|
| **Configuration** | YAML (per-node)              | Code/environment (global)                        |
| **Scope**         | Per-agent (LLM call level)   | Per-workflow (lifecycle events)                  |
| **Modify state**  | Yes - can transform messages | No - read-only observation                       |
| **Use case**      | Behavior modification        | Observability & telemetry and regression testing |

**Use middleware when you need to control or modify agent behavior.**
**Use plugins when you need to observe and log agent behavior, implement regression testing, add extra functionalities
that can be imported via plugins.**

---

## Part 2: Built-in Middleware Types

### Model Call Limit

Prevents agents from making excessive API calls:

```yaml
middleware:
  - type: model_call_limit
    model_call_limit:
      run_limit: 15          # Max calls per invocation
      exit_behavior: end     # "end" (graceful) or "error" (raise)
```

**Use case**: Prevent runaway agents and control costs.

### Tool Call Limit

Limits the number of tool invocations:

```yaml
middleware:
  - type: tool_call_limit
    tool_call_limit:
      run_limit: 10          # Max tool calls per invocation
      exit_behavior: end
```

**Use case**: Prevent agents from over-using expensive tools.

### Summarization

Automatically summarizes long conversations to reduce token usage:

```yaml
middleware:
  - type: summarization
    summarization:
      model: "anthropic:claude-sonnet-4-20250514"  # Required
      trigger_messages: 20    # Trigger after 20 messages
      keep_messages: 5        # Keep last 5 messages after summarizing
```

**Use case**: Long-running conversations that would exceed context limits.

### Human-in-the-Loop (Middleware)

Automatically requires human approval for specific tools:

```yaml
middleware:
  - type: human_in_the_loop
    human_in_the_loop:
      interrupt_on:
        delete_record:
          allowed_decisions: ["approve", "reject"]
        refund_order:
          allowed_decisions: ["approve", "reject"]
```

**Use case**: Mandatory approval for dangerous operations.

> **Note**: This is different from tool-based HITL where the agent decides when to ask for approval. Middleware HITL is
**mandatory** - the system enforces it regardless of the agent's decision. See
> the [Human in the Loop tutorial](human-in-the-loop.md) for the tool-based approach.

### Tool Retry

Automatically retries failed tool calls:

```yaml
middleware:
  - type: tool_retry
    tool_retry:
      max_retries: 3
      retry_on:              # Optional: specific exceptions
        - ConnectionError
        - TimeoutError
```

**Use case**: Resilience against transient failures.

### Model Fallback

Tries fallback models when the primary fails:

```yaml
middleware:
  - type: model_fallback
    model_fallback:
      fallback_models:
        - gpt-4-turbo
        - gpt-3.5-turbo
```

**Use case**: High availability for critical agents.

---

## Part 3: Building a Protected Support Agent

Let's build a customer support agent with comprehensive middleware protection.

### Step 1: Create the Tools

Create `tools.py`:

```python
"""
Customer Support Tools with Sensitive Operations

Some tools are safe, others require middleware protection.
"""
import json
from datetime import datetime
from langchain_core.tools import tool


@tool
def lookup_order(order_id: str) -> str:
    """Look up order status by order ID."""
    orders = {
        "ORD-001": {"status": "shipped", "tracking": "TRK-123456", "eta": "2024-02-10"},
        "ORD-002": {"status": "processing", "expected_ship": "2024-02-08"},
        "ORD-003": {"status": "delivered", "delivered_on": "2024-01-30"}
    }
    order = orders.get(order_id, {"status": "not found"})
    return json.dumps(order, indent=2)


@tool
def check_inventory(product: str) -> str:
    """Check product inventory levels."""
    inventory = {
        "laptop": "In Stock (23 units)",
        "mouse": "In Stock (156 units)",
        "keyboard": "Low Stock (5 units)",
        "monitor": "Out of Stock (ETA: Feb 15)"
    }
    return inventory.get(product.lower(), "Product not found")


@tool
def create_support_ticket(issue: str, priority: str = "medium") -> str:
    """Create a support ticket for customer issues."""
    ticket_id = f"SUPP-{hash(issue) % 10000:04d}"
    return json.dumps({
        "ticket_id": ticket_id,
        "priority": priority,
        "status": "created",
        "created_at": datetime.now().isoformat()
    })


@tool
def process_refund(order_id: str, amount: float, reason: str) -> str:
    """
    Process a refund for an order.

    WARNING: This is a sensitive operation that should require approval.
    """
    return json.dumps({
        "refund_id": f"REF-{hash(order_id) % 10000:04d}",
        "order_id": order_id,
        "amount": amount,
        "reason": reason,
        "status": "processed"
    })


@tool
def delete_customer_data(customer_id: str) -> str:
    """
    Delete all customer data (GDPR compliance).

    WARNING: This is an irreversible operation that should require approval.
    """
    return json.dumps({
        "customer_id": customer_id,
        "status": "deleted",
        "deleted_at": datetime.now().isoformat()
    })


@tool
def update_shipping_address(order_id: str, new_address: str) -> str:
    """Update the shipping address for an order."""
    return json.dumps({
        "order_id": order_id,
        "new_address": new_address,
        "status": "updated"
    })
```

### Step 2: Create the Workflow with Middleware

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Protected Customer Support"
  description: "Customer support agent with middleware guardrails"
  tags:
    - customer-support
    - middleware
    - production

llm:
  provider: "anthropic"
  config:
    model: "claude-sonnet-4-20250514"

orchestrator:
  workflows:
    - customer_support

workflows:
  customer_support:
    description: "Customer support with middleware protection"
    nodes:
      support_agent: {}

nodes:
  support_agent:
    description: "Protected support agent with guardrails"
    tools:
      - lookup_order
      - check_inventory
      - create_support_ticket
      - process_refund
      - delete_customer_data
      - update_shipping_address
    system_prompt: |
      You are a helpful customer support agent.

      You have access to various tools:
      - lookup_order: Check order status
      - check_inventory: Check product availability
      - create_support_ticket: Create support tickets
      - process_refund: Process refunds (requires approval)
      - delete_customer_data: Delete customer data (requires approval)
      - update_shipping_address: Update shipping addresses

      Be helpful and use the appropriate tools to assist customers.

    # Middleware stack - applied in order
    middleware:
      # 1. Prevent runaway agent loops
      - type: model_call_limit
        model_call_limit:
          run_limit: 20
          exit_behavior: end

      # 2. Limit tool usage
      - type: tool_call_limit
        tool_call_limit:
          run_limit: 10
          exit_behavior: end

      # 3. Manage long conversations
      - type: summarization
        summarization:
          model: "anthropic:claude-sonnet-4-20250514"
          trigger_messages: 15
          keep_messages: 5

      # 4. Require approval for sensitive operations
      - type: human_in_the_loop
        human_in_the_loop:
          interrupt_on:
            process_refund:
              allowed_decisions: ["approve", "reject"]
            delete_customer_data:
              allowed_decisions: ["approve", "reject"]

      # 5. Retry on transient failures
      - type: tool_retry
        tool_retry:
          max_retries: 2
```

### Step 3: Create the Demo Application

Create `middleware_demo.py`:

```python
"""
Middleware Demo Application

Demonstrates various middleware behaviors:
1. Model call limits
2. Tool call limits
3. Human-in-the-loop for sensitive operations
4. Automatic summarization
5. Tool retry

Run with:
    python middleware_demo.py

Environment:
    Create a .env file with:
    ANTHROPIC_API_KEY=your-api-key
"""
import asyncio
from dotenv import load_dotenv
from agentflow import AsyncWorkflowOrchestrator

# Load environment variables from .env file
load_dotenv()


async def demo_basic_middleware():
    """Demonstrate basic middleware functionality."""
    print("\n" + "=" * 60)
    print("DEMO 1: Basic Middleware Protection")
    print("=" * 60)

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
        enable_persistence=True,
        checkpointer_path="data/middleware_demo.db"
    ) as orchestrator:

        # Normal operation - should work fine
        print("\n[Test 1] Normal order lookup:")
        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "What's the status of order ORD-001?"}]},
            config={"configurable": {"thread_id": "demo-1"}},
            default_workflow="customer_support"
        ):
            if event['type'] == 'agent':
                print(f"[Agent]: {event['content'][:200]}...")
            elif event['type'] == 'tool':
                print(f"[Tool {event['name']}]: {event['content']}")


async def demo_sensitive_operation():
    """Demonstrate human-in-the-loop for sensitive operations."""
    print("\n" + "=" * 60)
    print("DEMO 2: Human-in-the-Loop for Sensitive Operations")
    print("=" * 60)
    print("\nWhen the agent tries to process a refund, middleware will")
    print("intercept and require human approval.\n")

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
        enable_persistence=True,
        checkpointer_path="data/middleware_demo.db"
    ) as orchestrator:

        print("[Test] Requesting a refund (triggers HITL middleware):")
        try:
            async for event in orchestrator.run(
                state={"messages": [{"role": "user", "content": "I need a refund for order ORD-001, the item was damaged. Please process a $50 refund."}]},
                config={"configurable": {"thread_id": "demo-hitl"}},
                default_workflow="customer_support"
            ):
                if event['type'] == 'agent':
                    print(f"[Agent]: {event['content'][:300]}...")
                elif event['type'] == 'tool':
                    print(f"[Tool {event['name']}]: {event['content']}")
                elif event['type'] == 'interrupt':
                    print(f"\n*** MIDDLEWARE INTERRUPT ***")
                    print(f"Human approval required for: {event.get('content', 'sensitive operation')}")
        except Exception as e:
            if "interrupt" in str(e).lower():
                print("\n*** Workflow paused - Human approval required ***")
            else:
                raise


async def demo_call_limits():
    """Demonstrate model call limits."""
    print("\n" + "=" * 60)
    print("DEMO 3: Model Call Limits")
    print("=" * 60)
    print("\nThe middleware will stop the agent after 20 model calls")
    print("to prevent runaway behavior.\n")

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
        enable_persistence=True,
        checkpointer_path="data/middleware_demo.db"
    ) as orchestrator:

        # This request might trigger multiple tool calls
        print("[Test] Complex request that might trigger many calls:")
        call_count = 0
        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "Check the inventory for laptop, mouse, keyboard, and monitor. Then lookup orders ORD-001, ORD-002, and ORD-003."}]},
            config={"configurable": {"thread_id": "demo-limits"}},
            default_workflow="customer_support"
        ):
            if event['type'] == 'agent':
                call_count += 1
                print(f"[Agent call #{call_count}]: {event['content'][:100]}...")
            elif event['type'] == 'tool':
                print(f"[Tool {event['name']}]")

        print(f"\nTotal agent responses: {call_count}")


async def demo_middleware_disabled():
    """Show how to disable middleware for testing."""
    print("\n" + "=" * 60)
    print("DEMO 4: Middleware Can Be Disabled")
    print("=" * 60)
    print("\nIn your YAML, you can disable middleware:")
    print("""
    middleware:
      - type: model_call_limit
        enabled: false  # <-- Disabled for testing
        model_call_limit:
          run_limit: 5
    """)


async def interactive_demo():
    """Interactive chat with middleware protection."""
    print("\n" + "=" * 60)
    print("Interactive Customer Support (with Middleware)")
    print("=" * 60)
    print("Type 'quit' to exit")
    print("\nTry these scenarios:")
    print("  1. 'Check order ORD-001' - Normal operation")
    print("  2. 'Process a $50 refund for ORD-001' - Triggers HITL")
    print("  3. 'Delete my customer data' - Triggers HITL")
    print()

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
        enable_persistence=True,
        checkpointer_path="data/middleware_demo.db"
    ) as orchestrator:

        thread_id = "interactive-demo"

        while True:
            user_input = input("\n[You]: ").strip()

            if user_input.lower() == 'quit':
                print("\nGoodbye!")
                break

            if not user_input:
                continue

            print("[Agent]: ", end="", flush=True)

            try:
                async for event in orchestrator.run(
                    state={"messages": [{"role": "user", "content": user_input}]},
                    config={"configurable": {"thread_id": thread_id}},
                    stream_tokens=True,
                    default_workflow="customer_support"
                ):
                    if event['type'] == 'token':
                        print(event['content'], end="", flush=True)
                    elif event['type'] == 'tool':
                        print(f"\n  [Using tool: {event['name']}]", end="")

                print()  # New line after response

            except Exception as e:
                if "interrupt" in str(e).lower():
                    print("\n\n*** Human approval required for this operation ***")
                    print("In production, this would pause and wait for approval.")
                else:
                    print(f"\nError: {e}")


async def main():
    """Run all demos."""
    print("=" * 60)
    print("AgentFlow Middleware Demo")
    print("=" * 60)

    # Run demos
    await demo_basic_middleware()
    await demo_call_limits()
    await demo_sensitive_operation()
    await demo_middleware_disabled()

    # Uncomment for interactive mode:
    # await interactive_demo()


if __name__ == "__main__":
    asyncio.run(main())
    # Or run interactive mode:
    # asyncio.run(interactive_demo())
```

### Step 4: Run and Test

Create a `.env` file with your API key:

```bash
ANTHROPIC_API_KEY=your-api-key
```

Then run:

```bash
python middleware_demo.py
```

**Expected output:**

```
============================================================
DEMO 1: Basic Middleware Protection
============================================================

[Test 1] Normal order lookup:
[Tool lookup_order]: {
  "status": "shipped",
  "tracking": "TRK-123456",
  "eta": "2024-02-10"
}
[Agent]: Your order ORD-001 has been shipped! You can track it...

============================================================
DEMO 3: Model Call Limits
============================================================

[Test] Complex request that might trigger many calls:
[Tool check_inventory]
[Tool check_inventory]
[Tool check_inventory]
[Tool check_inventory]
[Agent call #1]: I've checked the inventory...
[Tool lookup_order]
[Tool lookup_order]
[Tool lookup_order]
[Agent call #2]: Here are the order statuses...

Total agent responses: 2

============================================================
DEMO 2: Human-in-the-Loop for Sensitive Operations
============================================================

[Test] Requesting a refund (triggers HITL middleware):
[Agent]: I'll process that refund for you...

*** MIDDLEWARE INTERRUPT ***
Human approval required for: process_refund
```

---

## Part 4: Middleware Ordering

Middleware is applied in the order specified in YAML. The order matters:

```yaml
middleware:
  # 1. First: Check limits (outermost)
  - type: model_call_limit
    model_call_limit:
      run_limit: 15

  # 2. Second: Summarize if needed
  - type: summarization
    summarization:
      model: "anthropic:claude-sonnet-4-20250514"
      trigger_messages: 20

  # 3. Third: Human approval (closest to model)
  - type: human_in_the_loop
    human_in_the_loop:
      interrupt_on:
        dangerous_action:
          allowed_decisions: ["approve", "reject"]
```

**Execution flow:**

1. `model_call_limit` checks if we're under the limit
2. `summarization` checks if we need to condense history
3. `human_in_the_loop` checks if the tool needs approval
4. LLM model call happens
5. Results flow back through the middleware in reverse order

---

## Part 5: Custom Middleware

For advanced use cases, you can create custom middleware:

### Creating Custom Middleware

```python
# company_middleware.py

class AuditMiddleware:
    """Custom middleware for audit logging."""

    def __init__(self, log_level: str = "INFO", destination: str = None):
        self.log_level = log_level
        self.destination = destination

    async def before_model(self, state, config):
        """Called before each model call."""
        print(f"[AUDIT] Model call starting, messages: {len(state.get('messages', []))}")
        return state

    async def after_model(self, state, response, config):
        """Called after each model call."""
        print(f"[AUDIT] Model call completed")
        return response
```

### Configuring Custom Middleware in YAML

```yaml
nodes:
  audited_agent:
    middleware:
      # Built-in middleware
      - type: model_call_limit
        model_call_limit:
          run_limit: 10

      # Custom middleware
      - custom:
          class_name: "company_middleware.AuditMiddleware"
          config:
            log_level: "DEBUG"
            destination: "s3://audit-logs"
```

---

## Part 6: Best Practices

### 1. Start with Sensible Defaults

```yaml
middleware:
  # Always have a safety limit
  - type: model_call_limit
    model_call_limit:
      run_limit: 25
      exit_behavior: end

  # Manage context for long conversations
  - type: summarization
    summarization:
      model: "anthropic:claude-sonnet-4-20250514"
      trigger_messages: 30
      keep_messages: 10
```

### 2. Protect Sensitive Operations

```yaml
middleware:
  - type: human_in_the_loop
    human_in_the_loop:
      interrupt_on:
        delete_data:
          allowed_decisions: ["approve", "reject"]
        process_payment:
          allowed_decisions: ["approve", "reject"]
        modify_permissions:
          allowed_decisions: ["approve", "reject"]
```

### 3. Add Resilience

```yaml
middleware:
  - type: tool_retry
    tool_retry:
      max_retries: 3

  - type: model_fallback
    model_fallback:
      fallback_models:
        - gpt-4-turbo
        - gpt-3.5-turbo
```

### 4. Use Meaningful Limits

```yaml
# For customer support (conversational)
middleware:
  - type: model_call_limit
    model_call_limit:
      run_limit: 20  # Generous for multi-turn

# For data processing (task-focused)
middleware:
  - type: model_call_limit
    model_call_limit:
      run_limit: 5   # Strict for single-task
```

### 5. Disable for Testing

```yaml
middleware:
  - type: model_call_limit
    enabled: false  # Disabled during development
    model_call_limit:
      run_limit: 5
```

---

## Part 7: Troubleshooting

### Problem: Middleware Not Applied

**Checklist:**

1. Is middleware under the correct node in YAML?
2. Is the middleware type spelled correctly?
3. Is `enabled: false` accidentally set?
4. Check console for import errors

### Problem: Agent Stops Too Early

**Solution:** Increase the model call limit:

```yaml
middleware:
  - type: model_call_limit
    model_call_limit:
      run_limit: 30  # Increase from default
```

### Problem: Human Approval Not Triggering

**Checklist:**

1. Is the tool name exactly correct in the middleware config?
2. Is the agent actually calling that tool?
3. Is persistence enabled (required for HITL)?

### Problem: Custom Middleware Import Error

**Checklist:**

1. Is the module in the Python path?
2. Is the class name correct?
3. Does the constructor accept the config parameters?

---

## Summary

You now know how to:

- Configure built-in middleware for common guardrails
- Prevent runaway agents with call limits
- Require human approval for sensitive operations
- Manage context with automatic summarization
- Add resilience with retries and fallbacks
- Create custom middleware for specific needs

### Key Takeaways

| Middleware Type     | Use Case                             |
|---------------------|--------------------------------------|
| `model_call_limit`  | Prevent runaway costs                |
| `tool_call_limit`   | Control tool usage                   |
| `summarization`     | Manage long conversations            |
| `human_in_the_loop` | Mandatory approval for dangerous ops |
| `tool_retry`        | Handle transient failures            |
| `model_fallback`    | High availability                    |

### Middleware vs Tool-Based HITL

| Middleware HITL          | Tool-Based HITL           |
|--------------------------|---------------------------|
| System enforces approval | Agent decides when to ask |
| Configure in YAML        | Implement as custom tool  |
| Mandatory                | Discretionary             |

---

## Conclusion

Middleware provides a powerful way to add guardrails and controls to your agents without modifying their core logic. By
configuring middleware in YAML, you can easily adjust behavior, add safety limits, and require human approval for
sensitive operations.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

