# Getting Started with AgentFlow

## Introduction

AgentFlow is an orchestration framework built on top of LangGraph that lets you define AI agent workflows using simple
YAML configuration. It supports two modes:

- **Standalone agents** — a single agent with tools, ideal for chatbots, assistants, and quick prototyping
- **Multi-agent workflows** — multiple specialized agents with routing, sequencing, and parallel execution

This tutorial walks you through both, starting with the simplest approach.

---

## Prerequisites

- Python 3.10 or higher
- Basic understanding of Python
- An OpenAI API key (or any other LLM provider)

---

## Step 1: Install Dependencies

```bash
pip install agentflow[workflows]
pip install langchain-openai  # or langchain-anthropic for Claude
```

Verify installation:

```bash
agentflow --help
```

### Getting Help

AgentFlow includes a built-in documentation server powered by MkDocs:

```bash
# Start the documentation server
agentflow-docs

# Serve on a custom host and port
agentflow-docs --dev-addr 0.0.0.0:8080
```

Once the server is running, open http://localhost:9000 in your browser to browse the full documentation.

---

## Part 1: Standalone Agent

The fastest way to get started — a single agent with tools, no orchestrator or workflows needed.

### Step 2a: Create Your Tools

Create a file called `tools.py`:

```python
from langchain_core.tools import tool


@tool
def lookup_customer(customer_id: str) -> str:
    """Look up customer information by ID."""
    customers = {
        "C001": "John Doe - Premium Plan - Since 2023",
        "C002": "Jane Smith - Basic Plan - Since 2024"
    }
    return customers.get(customer_id, "Customer not found")


@tool
def get_pricing(plan: str) -> str:
    """Get pricing information for a specific plan."""
    pricing = {
        "basic": "$10/month - 10GB storage, email support",
        "premium": "$50/month - 100GB storage, 24/7 phone support",
        "enterprise": "$200/month - Unlimited storage, dedicated account manager"
    }
    return pricing.get(plan.lower(), "Plan not found. Available plans: basic, premium, enterprise")


@tool
def create_ticket(issue: str, priority: str = "medium") -> str:
    """Create a support ticket for technical issues."""
    ticket_id = f"TICKET-{hash(issue) % 10000}"
    return f"Support ticket {ticket_id} created with priority: {priority}"
```

### Step 3a: Define the Agent

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

agent:
  name: "Customer Support"
  system_prompt: |
    You are a customer support agent. You can:
    - Look up customer information by ID
    - Provide pricing details for plans
    - Create support tickets for technical issues

    Be helpful, concise, and professional.
  tools:
    - lookup_customer
    - get_pricing
    - create_ticket
```

That's it — no `orchestrator`, `workflows`, or `nodes` sections needed.

### Step 4a: Run It

```bash
export OPENAI_API_KEY="your-api-key-here"

# One-shot query
agentflow "I'm customer C001 and I can't log into my account"

# Sales query
agentflow "What's the difference between the basic and premium plans?"

# Interactive mode
agentflow --interactive
```

You should see output like:

```
[Customer Support]
I found your account, John Doe. You're on the Premium Plan since 2023.

I'm sorry to hear you're having trouble logging in. Let me create a
support ticket for you.

Support ticket TICKET-4821 created with priority: high

Our technical team will look into this and reach out to you shortly.
In the meantime, you can try resetting your password using the
"Forgot Password" link on the login page.
```

The agent has access to all tools and decides which to call based on the query. For a deeper dive into standalone
agents, including MCP tools and middleware, see the [Standalone Agents](standalone-agent.md) tutorial.

---

## Part 2: Multi-Agent Workflow

When your use case requires specialized agents — each with their own tools and system prompts — you can define a
multi-agent workflow with automatic routing.

### Step 2b: Add a Routing Tool

Add a routing tool to `tools.py`:

```python
import json

@tool
def set_query_type(query_type: str) -> str:
    """Set the query type for routing. Must be either 'technical' or 'sales'."""
    return json.dumps({"query_type": query_type})
```

### Step 3b: Define the Workflow

Replace `workflow.yaml` with:

```yaml
metadata:
  version: "1.0"
  name: "Customer Support Workflow"
  description: "Routes customer queries to specialized agents"

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

orchestrator:
  workflows:
    - customer_support

workflows:
  customer_support:
    description: "Route customer queries to appropriate specialists"
    nodes:
      router:
        routes:
          router_field: "query_type"
          technical: tech_support
          sales: sales_agent
          default: __end__

      tech_support:
        depends_on: [router]

      sales_agent:
        depends_on: [router]

nodes:
  router:
    description: "Routes customer queries to technical support or sales based on query type"
    tools:
      - lookup_customer
      - set_query_type
    system_prompt: |
      You are a customer service router. Analyze the customer's query and determine if it's:
      - 'technical' - for technical issues, bugs, or support requests
      - 'sales' - for pricing, plans, or purchase questions

      IMPORTANT: You MUST call the set_query_type tool with either 'technical' or 'sales' to route the query.

      Steps:
      1. If a customer ID is mentioned, use lookup_customer to get customer info
      2. Analyze the query type
      3. Call set_query_type with either 'technical' or 'sales'

  tech_support:
    description: "Handles technical support queries"
    tools:
      - create_ticket
    system_prompt: |
      You are a technical support specialist. Help customers with technical issues.
      If the issue requires follow-up, create a support ticket using the create_ticket tool.

  sales_agent:
    description: "Handles sales and pricing queries"
    tools:
      - get_pricing
    system_prompt: |
      You are a sales specialist. Help customers with pricing and plan information.
      Use the get_pricing tool to provide accurate pricing details.
```

### Step 4b: Run the Multi-Agent System

```bash
# Technical support query — routes to tech_support
agentflow "Hi, I'm customer C001 and I can't log into my account"

# Sales query — routes to sales_agent
agentflow "What's the difference between the basic and premium plans?"

# Interactive mode
agentflow --interactive
```

You should see output like:

```
[router]
Your query has been routed to the technical team for assistance
with your login issue.

Routing: query_type=technical -> tech_support

[tech_support]
Let me assist you with troubleshooting:

1. **Check Your Credentials** - Ensure correct email/username and password
2. **Password Reset** - Try the "Forgot Password" option
3. **Browser Issues** - Clear cache and cookies, or try a different browser

If none of these steps resolve your issue, I can create a support ticket.
Would you like me to proceed?
```

### What Just Happened?

1. **The Router Agent** analyzed the query and determined it was technical
2. **It set** `query_type: "technical"` in the workflow state
3. **AgentFlow automatically routed** to the `tech_support` agent based on the YAML configuration
4. **The Tech Support Agent** used its tools to help the customer
5. **Only the relevant agent ran** — the sales agent was never invoked

---

## CLI Options

| Option          | Description                                           |
|-----------------|-------------------------------------------------------|
| `--yaml`        | Path to workflow YAML file (default: `workflow.yaml`) |
| `--tools`       | Path to tools module (default: `tools`)               |
| `--interactive` | Run in interactive mode for multiple queries          |
| `--verbose`     | Enable verbose output                                 |
| `--help`        | Show help message                                     |

Example with explicit paths:

```bash
agentflow --yaml my_workflow.yaml --tools my_tools "Your query here"
```

---

## Using the Python API

Both standalone and multi-agent workflows use the same Python API:

```python
import asyncio
from agentflow import AsyncWorkflowOrchestrator


async def main():
    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools"
    ) as orchestrator:
        print("[Agent]: ", end="", flush=True)

        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "What plans do you offer?"}]},
            config={"configurable": {"thread_id": "user-123"}},
            stream_tokens=True  # Enable real-time token streaming
        ):
            if event['type'] == 'token':
                # Print tokens as they arrive (like ChatGPT)
                print(event['content'], end="", flush=True)
            elif event['type'] == 'agent':
                # Final complete message
                print()  # New line after streaming

if __name__ == "__main__":
    asyncio.run(main())
```

**Streaming modes:**

| Mode                  | Description                               | Event Type |
|-----------------------|-------------------------------------------|------------|
| `stream_tokens=True`  | Real-time token streaming (ChatGPT-style) | `token`    |
| `stream_tokens=False` | Complete messages only (default)          | `agent`    |

---

## Standalone vs Multi-Agent

| | Standalone (`agent:`) | Multi-Agent (`orchestrator:` + `workflows:`) |
|---|---|---|
| **YAML** | `agent:` section only | `orchestrator:` + `workflows:` + `nodes:` |
| **Agents** | 1 | N (specialized agents in sequence/parallel) |
| **Tool access** | All tools on one agent | Each agent has specific tools |
| **LLM calls** | Fewer (one agent context) | More (each agent has its own context) |
| **Best for** | Chatbots, assistants, quick prototyping | Complex multi-step analysis, pipelines |
| **Upgrade path** | Add `orchestrator:` + `workflows:` when complexity grows | — |

Start with a standalone agent. Move to multi-agent when you need specialized routing or separation of concerns.

---

## Understanding the Workflow Structure

For multi-agent workflows, the key concept is **separation of concerns**:

| Section        | Purpose                                                   |
|----------------|-----------------------------------------------------------|
| `orchestrator` | Defines the list of workflows available for orchestration |
| `workflows`    | Defines the flow — how agents connect and route           |
| `nodes`        | Defines the behavior — what each agent can do             |

This separation means you can:

- Reuse the same agent in different workflows
- Change routing without modifying agent behavior
- Add new agents without touching existing ones

---

## Common Patterns

### Pattern 1: Sequential Processing

```yaml
workflows:
  data_pipeline:
    nodes:
      collector: {}
      validator:
        depends_on: [collector]
      processor:
        depends_on: [validator]
```

All agents run in sequence: collector -> validator -> processor

### Pattern 2: Conditional Branching

```yaml
workflows:
  approval_flow:
    nodes:
      reviewer:
        routes:
          router_field: "approval_status"
          approved: finalizer
          rejected: notifier
          default: __end__
```

Different paths based on review outcome.

### Pattern 3: Parallel Processing

```yaml
workflows:
  my_pipeline:
    nodes:
      root: {}
      leaf1:
        depends_on: [root]
      leaf2:
        depends_on: [root]
```

Once the root agent is processed, leaf1 and leaf2 run concurrently.

---

## Troubleshooting

**Problem**: "Module 'tools' not found"

- Make sure `tools.py` is in the same directory as `main.py`

**Problem**: Agents not routing correctly

- Check that your router agent is setting the correct field name (e.g., `query_type`)
- Verify the field name matches `router_field` in your YAML

**Problem**: Tools not being called

- Ensure tool names in YAML exactly match function names (case-sensitive)
- Check that tools are properly decorated with `@tool`

---

## Next Steps

- **[Standalone Agents](standalone-agent.md)** — MCP tools, middleware, and more for single agents
- **[Multi-Agent Workflows](multi-agent-workflows.md)** — Execution patterns, dependencies, and per-node config
- **[Conditional Routing](conditional-routing.md)** — Dynamic routing based on agent outputs
- **[State Persistence](state-persistence.md)** — Save and resume conversations
- **[Middlewares](middlewares.md)** — Rate limiting, human-in-the-loop, and guardrails
- **[OpenTelemetry](opentelemetry.md)** — Distributed tracing and observability

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

