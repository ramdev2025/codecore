# Standalone Agents

## Introduction

Not every use case needs multiple agents. Sometimes you just want a single
AI agent with tools — a chatbot, a research assistant, an IT troubleshooter.

AgentFlow supports this with the `agent:` keyword. Define one agent, give it
tools, and run it. No orchestrator, no workflows, no routing overhead.

---

## What You'll Build

A standalone IT troubleshooting agent that has direct access to diagnostic
and remediation tools. It decides which tools to call and in what order based
on the user's query.

---

## Prerequisites

- Python 3.10 or higher
- An LLM provider API key (OpenAI, Azure OpenAI, or Anthropic)
- `pip install agentflow[workflows]`

---

## Step 1: Create a Tool

Create a file `tools.py` with a simple tool:

```python
from langchain_core.tools import tool

@tool
def search_docs(query: str) -> str:
    """Search the documentation for relevant information."""
    # In production, this would search a real knowledge base
    return f"Found 3 results for '{query}': ..."

@tool
def create_ticket(title: str, description: str) -> str:
    """Create a support ticket."""
    return f"Ticket created: {title}"
```

---

## Step 2: Write the YAML

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"

llm:
  provider: openai
  config:
    model: "gpt-4o-mini"

agent:
  name: "Support Assistant"
  system_prompt: |
    You are a helpful support assistant. You can search documentation
    and create support tickets for users.
  tools:
    - search_docs
    - create_ticket
```

That's it. No `orchestrator`, no `workflows`, no `nodes` sections.

---

## Step 3: Run It

### CLI

```bash
agentflow --yaml workflow.yaml "How do I reset my password?"
```

### Python API

```python
import asyncio
from dotenv import load_dotenv
from agentflow import AsyncWorkflowOrchestrator

load_dotenv()

async def main():
    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools"
    ) as agent:
        async for event in agent.run(
            state={"messages": [{"role": "user", "content": "How do I reset my password?"}]},
            config={"configurable": {"thread_id": "user-123"}}
        ):
            if event["type"] == "agent":
                print(event["content"])

asyncio.run(main())
```

---

## Step 4: Add MCP Tools

Standalone agents support MCP servers, just like workflow nodes:

```yaml
metadata:
  version: "1.0"

llm:
  provider: openai
  config:
    model: "gpt-4o-mini"

mcp_servers:
  data_platform:
    command: python
    args: ["-m", "my_mcp_server"]

agent:
  name: "Data Assistant"
  system_prompt: "You are a data assistant with access to the data platform."
  tools:
    - search_docs
  mcp_tools:
    - server: data_platform
      tools: "*"
```

The agent gets both local tools (`search_docs` from `tools.py`) and all tools
from the `data_platform` MCP server.

---

## Step 5: Add Middleware

Middleware works on standalone agents the same as workflow nodes:

```yaml
agent:
  name: "Careful Assistant"
  system_prompt: "You are a helpful assistant."
  tools:
    - search_docs
    - create_ticket
  middleware:
    - type: human_in_the_loop
      config:
        interrupt_message: "The agent wants to create a ticket. Approve?"
    - type: tool_call_limit
      config:
        max_tool_calls: 10
```

---

## Standalone vs Multi-Agent

| | Standalone (`agent:`) | Multi-Agent (`orchestrator:` + `workflows:`) |
|---|---|---|
| **YAML** | `agent:` section only | `orchestrator:` + `workflows:` + `nodes:` |
| **Agents** | 1 | N (specialized agents in sequence/parallel) |
| **Tool access** | All tools on one agent | Each agent has specific tools |
| **LLM calls** | Fewer (one agent context) | More (each agent has its own context) |
| **Best for** | Simple tasks, chatbots, quick triage | Complex multi-step analysis, pipelines |
| **Upgrade path** | Add `orchestrator:` + `workflows:` when complexity grows | — |

### When to Use Standalone

- Quick prototyping — get an agent running in minutes
- Simple Q&A bots with tool access
- Tasks where one agent with all tools is sufficient
- When you want to minimize token usage and latency

### When to Use Multi-Agent Workflows

- Complex tasks requiring different expertise at each step
- When you want structured, repeatable analysis pipelines
- When agents need different system prompts and tool subsets
- When you want agent-level tracing and metrics

---

## Everything Else Works

Standalone agents get the same infrastructure as multi-agent workflows:

- **Persistence** — conversation state saved and resumed
- **Telemetry** — full OpenTelemetry tracing (LLM calls, tool calls, latency)
- **Streaming** — token-by-token streaming in CLI, WebSocket, and Python API
- **MCP** — MCP server tool integration
- **Middleware** — rate limiting, human-in-the-loop, tool limits, etc.
- **FastAPI** — same `app_ui.py` pattern for web UI

---

## Summary

```yaml
# The simplest agentflow YAML — a standalone agent with tools
metadata:
  version: "1.0"

llm:
  provider: openai
  config:
    model: gpt-4o-mini

agent:
  name: "My Agent"
  system_prompt: "You are helpful."
  tools: [my_tool]
```

One section. One agent. All the infrastructure.

When you need multiple specialized agents with structured execution order, see
[Multi-Agent Workflows](multi-agent-workflows.md).

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

