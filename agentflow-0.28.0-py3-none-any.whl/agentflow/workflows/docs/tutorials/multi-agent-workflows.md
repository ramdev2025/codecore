# Multi-Agent Workflows

## Introduction

In the [Standalone Agents](standalone-agent.md) tutorial, you built a single agent with tools. That works well for
simple tasks, but as complexity grows you'll want to split work across multiple specialized agents — each with its own
system prompt, tools, and expertise.

This tutorial teaches you how to define multi-agent workflows using AgentFlow's three-section YAML structure:
`orchestrator`, `workflows`, and `nodes`.

By the end, you'll have a working data pipeline with three agents that execute in sequence, and understand how to
compose agents in parallel and fan-in patterns.

---

## Prerequisites

- Completed the [Getting Started](getting-started.md) tutorial
- Python 3.10 or higher
- An LLM provider API key

---

## Why Multi-Agent?

A standalone agent handles everything in a single context window. This works until:

- **Different steps need different tools** — a classifier shouldn't have access to remediation tools
- **Different steps need different instructions** — a data extractor needs different expertise than a summarizer
- **You want structured pipelines** — step A must complete before step B starts
- **You want parallel execution** — independent analyses run concurrently
- **You want observability** — per-agent latency, token usage, and tracing

Multi-agent workflows solve all of these by decomposing work into focused agents connected by a workflow graph.

---

## The Three-Section Structure

Every multi-agent YAML has three main sections:

```yaml
orchestrator:     # What workflows to run
workflows:        # How agents connect (graph structure)
nodes:            # What each agent does (behavior)
```

| Section        | Purpose                                          |
|----------------|--------------------------------------------------|
| `orchestrator` | Lists which workflows are available for execution |
| `workflows`    | Defines the graph — agent execution order and dependencies |
| `nodes`        | Defines each agent — system prompt, tools, LLM config |

This separation means you can reuse the same agent in different workflows, change execution order without modifying
agent behavior, and add new agents without touching existing ones.

---

## Step 1: Create the Tools

We'll build a data processing pipeline with three stages: collect, validate, and summarize. Create `tools.py`:

```python
import json
from langchain_core.tools import tool


@tool
def fetch_sales_data(region: str) -> str:
    """Fetch sales data for a specific region."""
    data = {
        "north": {"revenue": 150000, "orders": 320, "returns": 12},
        "south": {"revenue": 95000, "orders": 180, "returns": 8},
        "east": {"revenue": 120000, "orders": 250, "returns": 15},
        "west": {"revenue": 200000, "orders": 410, "returns": 5},
    }
    result = data.get(region.lower(), {"error": f"Unknown region: {region}"})
    return json.dumps(result)


@tool
def validate_data(data_json: str) -> str:
    """Validate sales data for completeness and consistency."""
    try:
        data = json.loads(data_json)
        issues = []
        if data.get("revenue", 0) < 0:
            issues.append("Negative revenue detected")
        if data.get("returns", 0) > data.get("orders", 0):
            issues.append("Returns exceed orders")
        return json.dumps({
            "valid": len(issues) == 0,
            "issues": issues,
            "records_checked": len(data),
        })
    except json.JSONDecodeError:
        return json.dumps({"valid": False, "issues": ["Invalid JSON"]})


@tool
def generate_chart_data(metric: str, values: str) -> str:
    """Generate chart-ready data for a given metric."""
    return json.dumps({
        "metric": metric,
        "chart_type": "bar",
        "data_points": values,
        "generated": True,
    })
```

---

## Step 2: Define the Workflow

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Sales Data Pipeline"

llm:
  provider: openai
  config:
    model: "gpt-4o"

orchestrator:
  workflows:
    - sales_pipeline

workflows:
  sales_pipeline:
    description: "Collect, validate, and summarize sales data"
    nodes:
      collector:
        depends_on: []
      validator:
        depends_on: [collector]
      summarizer:
        depends_on: [validator]

nodes:
  collector:
    description: "Collects sales data from all regions"
    tools:
      - fetch_sales_data
    system_prompt: |
      You are a data collection agent. Fetch sales data for all four regions:
      north, south, east, and west. Present the combined results clearly.

  validator:
    description: "Validates the collected data for quality"
    tools:
      - validate_data
    system_prompt: |
      You are a data quality agent. Review the sales data collected by the
      previous agent. Use the validate_data tool to check each region's data.
      Report any issues found.

  summarizer:
    description: "Summarizes the validated data with insights"
    tools:
      - generate_chart_data
    system_prompt: |
      You are a data analyst. Based on the validated sales data, provide:
      1. A summary of total revenue and orders across all regions
      2. The top-performing region
      3. Any concerns flagged during validation
      Use generate_chart_data for the revenue comparison.
```

---

## Step 3: Run It

```bash
export OPENAI_API_KEY="your-api-key-here"

agentflow "Analyze our quarterly sales performance"
```

You should see output from each agent in sequence:

```
[collector]
I've fetched sales data for all four regions:
- North: $150,000 revenue, 320 orders, 12 returns
- South: $95,000 revenue, 180 orders, 8 returns
- East: $120,000 revenue, 250 orders, 15 returns
- West: $200,000 revenue, 410 orders, 5 returns

[validator]
Data validation complete. All four regions passed validation:
- No negative revenue values
- Returns within normal range for all regions
- All required fields present

[summarizer]
Quarterly Sales Summary:
- Total Revenue: $565,000
- Total Orders: 1,160
- Top Region: West ($200,000, 410 orders)
- Lowest Returns: West (5 returns, 1.2% rate)
- Flag: East has the highest return rate (6.0%)
```

Each agent ran in order, building on the previous agent's output.

---

## How It Works

### Execution Order

The `depends_on` field controls execution order:

```yaml
nodes:
  collector:
    depends_on: []          # Runs first (no dependencies)
  validator:
    depends_on: [collector]  # Runs after collector
  summarizer:
    depends_on: [validator]  # Runs after validator
```

AgentFlow builds a directed acyclic graph (DAG) from these dependencies and executes agents in topological order.

### State Sharing

All agents share the same message history. When `collector` finishes, its response is added to the conversation. When
`validator` runs, it sees the collector's output in its context. This is how agents communicate — through the shared
message state.

### The Orchestrator Node

AgentFlow automatically creates a router node that dispatches to agents based on the workflow graph. You don't need to
define it — it's generated from the `orchestrator` and `workflows` sections.

---

## Execution Patterns

### Sequential

Agents run one after another:

```yaml
workflows:
  pipeline:
    nodes:
      step1:
        depends_on: []
      step2:
        depends_on: [step1]
      step3:
        depends_on: [step2]
```

```
step1 -> step2 -> step3
```

### Parallel (Fan-Out)

Agents with the same dependency run concurrently:

```yaml
workflows:
  pipeline:
    nodes:
      coordinator:
        depends_on: []
      analyst_a:
        depends_on: [coordinator]
      analyst_b:
        depends_on: [coordinator]
```

```
coordinator -> analyst_a
            -> analyst_b  (runs concurrently)
```

### Fan-In

Multiple agents feed into a single agent:

```yaml
workflows:
  pipeline:
    nodes:
      coordinator:
        depends_on: []
      analyst_a:
        depends_on: [coordinator]
      analyst_b:
        depends_on: [coordinator]
      merger:
        depends_on: [analyst_a, analyst_b]
```

```
coordinator -> analyst_a ──┐
            -> analyst_b ──┤
                           └-> merger
```

`merger` waits for both `analyst_a` and `analyst_b` to complete before running.

### Diamond

Combine fan-out and fan-in:

```yaml
workflows:
  pipeline:
    nodes:
      splitter:
        depends_on: []
      path_a:
        depends_on: [splitter]
      path_b:
        depends_on: [splitter]
      joiner:
        depends_on: [path_a, path_b]
```

```
splitter -> path_a ──┐
         -> path_b ──┤
                     └-> joiner
```

---

## Per-Node LLM Configuration

Each agent can use a different LLM. The global `llm` section provides the default, and individual nodes can override it:

```yaml
llm:
  provider: openai
  config:
    model: "gpt-4o"

nodes:
  collector:
    description: "Simple data collection"
    llm:
      provider: openai
      config:
        model: "gpt-4o-mini"    # Cheaper model for simple tasks
    tools: [fetch_sales_data]
    system_prompt: "Collect sales data."

  summarizer:
    description: "Complex analysis"
    # Inherits gpt-4o from global config
    tools: [generate_chart_data]
    system_prompt: "Analyze and summarize."
```

---

## Adding Middleware to Nodes

Individual agents can have middleware for limits, retries, and human approval:

```yaml
nodes:
  summarizer:
    description: "Summarizes data"
    tools: [generate_chart_data]
    system_prompt: "Summarize the data."
    middleware:
      - type: model_call_limit
        config:
          max_calls: 5
      - type: tool_call_limit
        config:
          max_calls: 10
```

See the [Middlewares](middlewares.md) tutorial for all available types.

---

## When to Use What

| Scenario | Approach |
|----------|----------|
| Chatbot, Q&A, simple triage | Standalone agent (`agent:`) |
| Multi-step pipeline with distinct roles | Multi-agent workflow |
| Dynamic routing based on classification | Multi-agent + [Conditional Routing](conditional-routing.md) |
| Same agent, different tool subsets per step | Multi-agent workflow |
| Quick prototype, minimal config | Standalone agent |

Start with a standalone agent. When you need specialized steps, structured execution order, or per-agent observability,
move to a multi-agent workflow.

---

## Next Steps

- **[Conditional Routing](conditional-routing.md)** — Add dynamic branching based on agent outputs  
- **[State Persistence](state-persistence.md)** — Save and resume workflow state  
- **[Middlewares](middlewares.md)** — Rate limiting, human-in-the-loop, and guardrails  
- **[MCP Integration](mcp-integration.md)** — Connect agents to MCP server tools  
- **[OpenTelemetry](opentelemetry.md)** — Per-agent tracing and observability  

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
