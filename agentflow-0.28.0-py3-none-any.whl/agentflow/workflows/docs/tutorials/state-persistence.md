# State Persistence

## Introduction

By default, AgentFlow agents have no memory between requests. Each interaction is independent:

```
Request 1: "What's the status of Batch 123?"
Response:  "Batch 123 is in fermentation..."

Request 2: "What about the temperature?"
Response:  "I don't have context about what you're referring to..."
```

State persistence solves this by storing conversation history in a database. AgentFlow supports two persistence
backends:

| Feature                           | SQLite                       | PostgreSQL                   |
|-----------------------------------|------------------------------|------------------------------|
| Checkpointer (conversation state) | Yes                          | Yes                          |
| Store (long-term memory)          | No                           | Yes                          |
| Multi-instance deployment         | Limited                      | Yes                          |
| Setup complexity                  | None                         | Requires database            |
| Best for                          | Development, single instance | Production, high concurrency |

---

## Part 1: SQLite Persistence

SQLite is the default backend, ideal for development and single-instance deployments.

### Installation

SQLite support is included with AgentFlow:

```bash
pip install agentflow[workflows]
```

### Configuration

Persistence is configured at **deploy time**, not in YAML. Your
`workflow.yaml` describes only business logic — the same file ships
unchanged across dev / staging / prod:

```yaml
metadata:
  version: "1.0"
  name: "My Workflow"

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

orchestrator:
  workflows:
    - my_workflow

workflows:
  my_workflow:
    description: "A simple workflow"
    nodes:
      assistant: {}

nodes:
  assistant:
    description: "A helpful assistant"
    system_prompt: "You are a helpful assistant."
```

SQLite is the default — no configuration needed. Override the file
path at run time:

```bash
# Default → .agentflow/checkpoints.db
agentflow --yaml workflow.yaml "Hello"

# Custom path via CLI
agentflow --yaml workflow.yaml --persistence sqlite --db-path /data/state.db "Hello"

# Or via env var
export CHECKPOINTER_DB_PATH=/data/state.db
agentflow --yaml workflow.yaml "Hello"
```

### Using the CLI

Persistence is on by default. The CLI handles thread management:

```bash
# Start interactive mode with persistence
agentflow --interactive

# Each conversation uses a unique thread_id
# The CLI generates one automatically, or you can specify:
agentflow --thread-id "user-alice-123" --interactive
```

### Using the API

For programmatic access with real-time token streaming:

```python
import asyncio
from agentflow import AsyncWorkflowOrchestrator

async def main():
    # Context manager handles cleanup automatically
    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
    ) as orchestrator:
        # Thread ID determines which conversation to continue
        config = {"configurable": {"thread_id": "user-123"}}

        # First message with token streaming
        print("[Agent]: ", end="", flush=True)
        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "My name is Alice"}]},
            config=config,
            stream_tokens=True  # Enable real-time token streaming
        ):
            if event['type'] == 'token':
                print(event['content'], end="", flush=True)
        print()  # New line after streaming

        # Same thread_id = same conversation context
        print("[Agent]: ", end="", flush=True)
        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "What's my name?"}]},
            config=config,
            stream_tokens=True
        ):
            if event['type'] == 'token':
                print(event['content'], end="", flush=True)  # Will respond "Alice"
        print()

if __name__ == "__main__":
    asyncio.run(main())
```

---

## Part 2: PostgreSQL Persistence

PostgreSQL is recommended for production multi-instance deployments. It supports both checkpointing (conversation state)
and long-term memory store.

### Installation

Install PostgreSQL dependencies:

```bash
pip install "agentflow[workflows,postgres]"
```

### PostgreSQL Setup

Using Docker (recommended for testing):

```bash
docker run --name agentflow-postgres \
    -e POSTGRES_PASSWORD=postgres \
    -p 5432:5432 \
    -d postgres:15
```

Create a database:

```bash
psql -U postgres
CREATE DATABASE agentflow;
```

Set the connection string:

```bash
export DATABASE_URL="postgresql://postgres:postgres@localhost:5432/agentflow"
```

### Configuration

PostgreSQL is selected at deploy time. The YAML is identical to the
SQLite case — only the environment differs:

```yaml
metadata:
  version: "1.0"
  name: "My Workflow"

llm:
  provider: "openai"
  config:
    model: "gpt-4o"

orchestrator:
  workflows:
    - my_workflow

workflows:
  my_workflow:
    description: "A workflow with persistence"
    nodes:
      assistant: {}

nodes:
  assistant:
    description: "A helpful assistant with long-term memory"
    system_prompt: "You are a helpful assistant."
```

Pick Postgres at run time:

```bash
# Env-driven (typical for containers)
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
export POSTGRES_POOL_SIZE=10                    # optional, pool max (default 5)
export AGENTFLOW_STORE_ENABLED=true             # enable long-term memory store
agentflow --yaml workflow.yaml "..."

# Or with explicit CLI flags
agentflow --yaml workflow.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" "..."
```

Credentials stay in the environment — never in the YAML.

### Programmatic Configuration

You can also configure persistence programmatically:

```python
from agentflow import AsyncWorkflowOrchestrator
from agentflow.core.config_models import (
    PersistenceConfig,
    PersistenceBackend,
    PostgresConfig,
    CheckpointerConfig,
    StoreConfig,
)

persistence_config = PersistenceConfig(
    backend=PersistenceBackend.POSTGRES,
    postgres=PostgresConfig(
        connection_string="${DATABASE_URL}",
        pool_size=10
    ),
    checkpointer=CheckpointerConfig(enabled=True),
    store=StoreConfig(enabled=True),
)

orchestrator = await AsyncWorkflowOrchestrator.create(
    config_path="workflow.yaml",
    tools_module="my_tools",
    persistence_config=persistence_config,  # Overrides CLI / env / defaults
)
```

---

## Part 3: Long-term Memory Store

PostgreSQL persistence supports a **store** for long-term memory that persists across different conversations.

### Checkpointer vs Store

- **Checkpointer**: Conversation state within a thread (automatic)
- **Store**: Data that persists across threads/conversations (requires explicit tools)

| Use Case                                       | Checkpointer | Store |
|------------------------------------------------|--------------|-------|
| "What did I just ask?"                         | Yes          | -     |
| "My favorite color is blue" (remember forever) | -            | Yes   |
| User preferences                               | -            | Yes   |
| Accumulated knowledge                          | -            | Yes   |

### Using the Store API

The store organizes data by namespaces (like folders) and keys (like files):

```python
from agentflow import AsyncWorkflowOrchestrator

async def example_store_usage():
    orchestrator = await AsyncWorkflowOrchestrator.create(
        config_path="workflow_postgres.yaml",
    )

    # Access the store
    store = orchestrator._persistence_resources.store

    if store is None:
        print("Store not available - check PostgreSQL configuration")
        return

    # Namespace: tuple of strings (like a folder path)
    # Key: unique identifier within the namespace
    user_id = "user-alice-123"
    namespace = ("users", user_id, "preferences")

    # Save data
    await store.aput(
        namespace=namespace,
        key="theme",
        value={"setting": "dark", "updated_at": "2025-01-19"}
    )

    await store.aput(
        namespace=namespace,
        key="language",
        value={"setting": "python", "level": "advanced"}
    )

    # Retrieve data
    theme = await store.aget(namespace=namespace, key="theme")
    if theme:
        print(f"Theme: {theme.value}")  # {"setting": "dark", ...}

    # Search all items in a namespace
    results = await store.asearch(namespace)
    async for item in results:
        print(f"{item.key}: {item.value}")

    await orchestrator.cleanup()
```

### Creating Memory Tools

To let agents use long-term memory, create tools that interact with the store:

```python
from langchain_core.tools import tool

# These would need access to the store instance
# Typically done via dependency injection or global state

@tool
def remember_preference(key: str, value: str, user_id: str) -> str:
    """Remember a user preference for future conversations."""
    # Store the preference (implementation depends on your architecture)
    return f"Remembered {key}={value} for user {user_id}"

@tool
def recall_preference(key: str, user_id: str) -> str:
    """Recall a previously stored user preference."""
    # Retrieve from store
    return f"User {user_id} preference for {key}: ..."
```

---

## Part 4: Thread IDs

Thread IDs isolate conversations. Same thread_id = same conversation context.

### Best Practices

```python
# Good - includes user and context
thread_id = f"user-{user_id}-{date}"
thread_id = f"session-{session_id}"
thread_id = f"order-{order_id}-support"

# Bad - not unique or untraceable
thread_id = "chat"
thread_id = str(uuid.uuid4())  # Can't find conversations later
```

### Multiple Users

```python
# User 1's conversation
config1 = {"configurable": {"thread_id": "user-alice"}}
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "My name is Alice"}]},
    config=config1
):
    pass

# User 2's separate conversation
config2 = {"configurable": {"thread_id": "user-bob"}}
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "My name is Bob"}]},
    config=config2
):
    pass

# Resume User 1's conversation - remembers "Alice"
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "What's my name?"}]},
    config=config1
):
    pass  # Responds "Alice"
```

---

## Part 5: FastAPI Integration

### With SQLite

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow import AsyncWorkflowOrchestrator

orchestrator = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global orchestrator
    orchestrator = await AsyncWorkflowOrchestrator.create(
        config_path="workflow.yaml",
        tools_module="my_tools",
    )
    yield
    await orchestrator.cleanup()

app = FastAPI(lifespan=lifespan)

@app.post("/chat/{user_id}")
async def chat(user_id: str, message: str):
    thread_id = f"user-{user_id}"
    response = ""

    async for event in orchestrator.run(
        state={"messages": [{"role": "user", "content": message}]},
        config={"configurable": {"thread_id": thread_id}}
    ):
        if event['type'] == 'agent':
            response = event.get('content', '')

    return {"response": response}
```

### With PostgreSQL

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow import AsyncWorkflowOrchestrator
from agentflow.core.config_models import (
    PersistenceConfig,
    PersistenceBackend,
    PostgresConfig,
    CheckpointerConfig,
    StoreConfig,
)

orchestrator = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global orchestrator

    persistence_config = PersistenceConfig(
        backend=PersistenceBackend.POSTGRES,
        postgres=PostgresConfig(
            connection_string="${DATABASE_URL}",
            pool_size=20  # Higher pool size for production
        ),
        checkpointer=CheckpointerConfig(enabled=True),
        store=StoreConfig(enabled=True),
    )

    orchestrator = await AsyncWorkflowOrchestrator.create(
        config_path="workflow.yaml",
        tools_module="my_tools",
        persistence_config=persistence_config,
    )
    yield
    await orchestrator.cleanup()

app = FastAPI(lifespan=lifespan)
```

---

## Troubleshooting

### SQLite: "Database is locked"

**Cause**: Multiple processes accessing SQLite simultaneously.

**Solutions**:

- Use a single orchestrator instance
- Ensure proper cleanup with context managers
- Use PostgreSQL for high-concurrency deployments

### PostgreSQL: Connection refused

**Solutions**:

- Verify PostgreSQL is running: `pg_isready`
- Check connection string format
- Verify network connectivity

### PostgreSQL: Missing dependencies

```
PostgreSQL checkpointer requires 'langgraph-checkpoint-postgres' package
```

**Solution**:

```bash
pip install agentflow[postgres]
```

### Store not working with SQLite

```
Store is not supported with SQLite backend
```

**Solution**: Use PostgreSQL for store functionality, or leave the
store disabled (the default for SQLite). The store is enabled via
`AGENTFLOW_STORE_ENABLED=true` and only applies on Postgres.

### Context not preserved

**Checklist**:

1. Is persistence enabled? (default: SQLite at `.agentflow/checkpoints.db`)
2. Is the same `thread_id` used across requests?
3. Is the same database path/connection used (CLI flag or env var)?
4. Is the orchestrator properly initialized?

---

## Configuration Reference

### PersistenceConfig

| Field          | Type                   | Default               | Description                      |
|----------------|------------------------|-----------------------|----------------------------------|
| `backend`      | `sqlite` or `postgres` | `sqlite`              | Persistence backend              |
| `sqlite`       | `SQLiteConfig`         | auto-created          | SQLite settings                  |
| `postgres`     | `PostgresConfig`       | required for postgres | PostgreSQL settings              |
| `checkpointer` | `CheckpointerConfig`   | enabled               | Checkpointer settings            |
| `store`        | `StoreConfig`          | disabled              | Store settings (PostgreSQL only) |

### SQLiteConfig

| Field     | Type  | Default                     | Description        |
|-----------|-------|-----------------------------|--------------------|
| `db_path` | `str` | `.agentflow/checkpoints.db` | Database file path |

### PostgresConfig

| Field               | Type    | Default  | Description                                                |
|---------------------|---------|----------|------------------------------------------------------------|
| `connection_string` | `str`   | required | PostgreSQL connection string                               |
| `pool_size`         | `int`   | `5`      | Maximum connections in the pool                            |
| `min_size`          | `int`   | `1`      | Connections kept open at all times                         |
| `max_lifetime`      | `float` | `600.0`  | Seconds before a connection is retired and reopened        |
| `max_idle`          | `float` | `300.0`  | Seconds an idle connection above `min_size` is kept        |
| `check_connection`  | `bool`  | `true`   | Validate connections on checkout, replacing dead ones      |
| `connect_timeout`   | `float` | `30.0`   | Seconds to wait for a free connection                      |

The checkpointer and store share one pool and borrow a connection per
operation. `check_connection` and `max_lifetime` are what keep the app alive
when the database restarts or a load balancer reaps an idle connection — leave
them on unless you have measured a reason not to. See
[PERSISTENCE.md](../PERSISTENCE.md#connection-pooling-and-resilience).

---

## Summary

| Backend    | When to Use                                                |
|------------|------------------------------------------------------------|
| SQLite     | Development, single instance, simple production            |
| PostgreSQL | Production, multi-instance, when you need long-term memory |

Quick start configurations — same YAML, different deploy-time env:

```bash
# SQLite (development) — nothing to set, just run
agentflow --yaml workflow.yaml "..."

# PostgreSQL (production) — env-driven
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
export AGENTFLOW_STORE_ENABLED=true       # opt into long-term memory store
agentflow --yaml workflow.yaml "..."
```

See [PERSISTENCE.md](../PERSISTENCE.md) for the full env-var
reference (`POSTGRES_POOL_SIZE`, `POSTGRES_POOL_MIN_SIZE`,
`POSTGRES_POOL_MAX_LIFETIME`, `POSTGRES_POOL_CHECK`,
`AGENTFLOW_ENCRYPTION_KEY`, etc.).

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

