# Human-in-the-Loop

## Intelligent Approval Workflows with AgentFlow

---

## Introduction

You've built multi-agent systems that make autonomous decisions. But what happens when:

- A decision requires executive judgment?
- The automated confidence is too low to proceed safely?
- Regulatory compliance requires human oversight?
- High-stakes actions need explicit approval?

This is where **Human-in-the-Loop (HITL)** becomes essential. AgentFlow supports two HITL approaches:

| Approach                           | When to Use               | How It Works                              |
|------------------------------------|---------------------------|-------------------------------------------|
| **Tool-based** (this tutorial)     | Agent decides when to ask | Agent calls `request_human_approval` tool |
| **Middleware-based** (Tutorial 07) | System enforces approval  | Middleware intercepts specific tool calls |

**Tool-based HITL** (covered here) lets the agent intelligently decide when human input is needed based on context,
confidence, or complexity.

**Middleware-based HITL** (covered in Tutorial 07 - Middlewares) automatically requires approval for specific tools
regardless of the agent's decision - useful for mandatory compliance requirements.

**By the end of this tutorial, you'll have a working expense approval system that:**

- Analyzes expenses automatically using AI
- Identifies high-risk decisions requiring approval
- Pauses execution to request human input
- Resumes workflow after receiving approval
- Maintains full audit trail of decisions

---

## What is Tool-Based Human-in-the-Loop?

Tool-based Human-in-the-Loop is an **agent-triggered** pattern where your AI agent autonomously decides when it needs
human input. The workflow pauses, waits for human response, and then continues processing.

**Key Concept:** The agent decides when to ask for help—not your code.

### The HITL Flow

```
Agent processing
    |
    v
Encounters uncertain situation
    |
    v
Calls request_human_approval tool
    |
    v
Workflow PAUSES (state saved)
    |
    v
Human reviews and responds
    |
    v
Workflow RESUMES with human's decision
    |
    v
Agent continues processing
```

---

## Prerequisites

- Python 3.10 or higher
- Completed Tutorial 03 (State Persistence)
- Understanding of async/await in Python
- An OpenAI or Azure OpenAI API key

---

## Step 1: Install Dependencies

```bash
pip install langchain langgraph langgraph-checkpoint-sqlite aiosqlite
pip install langchain-openai  # or langchain-anthropic for Claude
pip install agentflow[workflows]
```

---

## Step 2: Create HITL Tools

The magic of HITL is in the tools. Create `tools.py`:

```python
import json
from langchain_core.tools import tool
from langgraph.types import interrupt


@tool
def request_human_approval(
    question: str,
    context: str,
    action_type: str = "other",
    proposed_action: str = ""
) -> str:
    """
    Request human approval before proceeding with a critical action.

    Use this tool when you need human confirmation before:
    - Executing a proposed plan
    - Modifying a database
    - Making a final decision
    - Any action that requires human oversight

    Args:
        question: The question to ask the human
        context: Background information for decision making
        action_type: Type of action requiring approval
        proposed_action: Description of what you plan to do if approved

    Returns:
        Human's response (approval, rejection, or modified instructions)
    """
    # Create the approval request payload
    approval_request = {
        "type": "human_approval_required",
        "question": question,
        "context": context,
        "action_type": action_type,
        "proposed_action": proposed_action,
    }

    # Use LangGraph's interrupt() to pause execution
    # The value passed to interrupt() will be returned when workflow resumes
    human_response = interrupt(approval_request)

    return human_response


@tool
def request_human_input(
    prompt: str,
    input_type: str = "text",
    choices: list[str] = None
) -> str:
    """
    Request freeform input from a human during workflow execution.

    Use this when you need human to provide information, not just approve/reject.

    Args:
        prompt: What to ask the human
        input_type: Type of input expected (text, choice, or number)
        choices: If input_type is "choice", provide the available options

    Returns:
        Human's input
    """
    input_request = {
        "type": "human_input_required",
        "prompt": prompt,
        "input_type": input_type,
        "choices": choices or [],
    }

    human_input = interrupt(input_request)

    return human_input
```

### The `interrupt()` Function

This is the key to HITL:

- **Pauses** workflow execution by raising a special exception
- **Saves** current state and interrupt data to checkpoint database
- **Returns** human response when workflow resumes with `Command(resume=...)`
- **Transparent** to the agent - it just waits for the "tool" to return
- **Requires** persistence enabled (SQLite or other checkpointer)

---

## Step 3: Add Business Logic Tools

Add these to `tools.py` to support the expense approval workflow:

```python
@tool
def analyze_expense(amount: float, category: str, description: str) -> str:
    """Analyze an expense request and determine risk level"""

    risk_score = 0
    flags = []

    # Amount-based risk
    if amount > 10000:
        risk_score += 3
        flags.append("High amount (>$10,000)")
    elif amount > 5000:
        risk_score += 2
        flags.append("Medium amount ($5,000-$10,000)")

    # Category-based risk
    high_risk_categories = ["travel", "entertainment", "consulting"]
    if category.lower() in high_risk_categories:
        risk_score += 2
        flags.append(f"High-risk category: {category}")

    # Determine risk level
    if risk_score >= 4:
        risk_level = "high"
    elif risk_score >= 2:
        risk_level = "medium"
    else:
        risk_level = "low"

    analysis = {
        "amount": amount,
        "category": category,
        "risk_level": risk_level,
        "risk_score": risk_score,
        "flags": flags,
        "requires_approval": risk_level in ["high", "medium"]
    }

    return json.dumps(analysis, indent=2)


@tool
def lookup_policy(category: str) -> str:
    """Look up company expense policy for a category"""

    policies = {
        "travel": {
            "max_amount": 5000,
            "requires_approval": True,
            "approval_level": "Manager"
        },
        "office supplies": {
            "max_amount": 500,
            "requires_approval": False,
            "approval_level": "Auto-approved"
        },
        "consulting": {
            "max_amount": 10000,
            "requires_approval": True,
            "approval_level": "VP"
        }
    }

    policy = policies.get(category.lower(), {
        "max_amount": 1000,
        "requires_approval": True,
        "approval_level": "Manager"
    })

    return json.dumps(policy, indent=2)


@tool
def process_expense(expense_id: str, decision: str, notes: str = "") -> str:
    """Process an expense after approval decision"""

    result = {
        "expense_id": expense_id,
        "decision": decision,
        "processed_date": "2024-02-15",
        "status": "Approved - Processing payment" if decision.lower() == "approved" else "Rejected",
        "notes": notes
    }

    return json.dumps(result, indent=2)
```

---

## Step 4: Design the Workflow

Create `workflow.yaml`:

```yaml
metadata:
  version: "1.0"
  name: "Expense Approval Workflow with HITL"
  description: "Intelligent expense approval with human oversight"
  tags:
    - expense-management
    - human-in-the-loop
    - approval-workflow

llm:
  provider: "azure_openai"
  deployment: "gpt-4o"

orchestrator:
  workflows:
    - expense_approval

workflows:
  expense_approval:
    description: "Analyze expenses and route to appropriate approval process"
    nodes:
      risk_analyzer:
        routes:
          router_field: "requires_approval"
          "yes": approval_requester
          "no": finalizer
          "true": approval_requester
          "True": approval_requester
          "false": finalizer
          "False": finalizer
          default: __end__

      approval_requester:
        depends_on: [risk_analyzer]

      finalizer:
        depends_on: [risk_analyzer, approval_requester]

nodes:
  risk_analyzer:
    description: "Analyzes expense requests and determines if human approval is needed"
    tools:
      - analyze_expense
      - lookup_policy
    system_prompt: |
      You are an expense risk analysis agent. Your job is to analyze expense requests and determine if they require human approval.

      **Steps:**

      1. **Analyze the expense request:**
         - Use analyze_expense to assess risk level
         - Use lookup_policy to check company policies
         - Consider amount, category, and business justification

      2. **Make a determination:**
         - If risk is HIGH or expense exceeds policy limits: Human approval required
         - If risk is LOW and within policy: Can proceed automatically
         - When in doubt: Human approval required

      3. **Output your analysis:**
         You MUST return a JSON object with:
         ```json
         {
           "requires_approval": "yes" or "no",
           "risk_level": "low" | "medium" | "high",
           "reason": "explanation of why approval is/isn't needed",
           "policy_compliance": "compliant" | "exceeds_limit" | "violation",
           "recommendation": "your recommendation"
         }
         ```

      **When Approval is Required:**
      - High-risk expenses (risk_level: high)
      - Expenses over $5,000
      - Policy violations or exceptions
      - Unusual or suspicious patterns
      - Missing required documentation

      **Important:**
      - Do NOT call request_human_approval - that's handled by a different node
      - Your job is ONLY to analyze and set the requires_approval field
      - Be thorough in your analysis but concise in your output

  approval_requester:
    description: "Requests human approval for high-risk expenses"
    tools:
      - request_human_approval
    system_prompt: |
      You are a human approval coordinator. Your job is to request human approval for expenses that were flagged as requiring approval.

      **Steps:**

      1. **Review the risk analysis** from the previous step in the conversation

      2. **Request human approval ONCE:**
         Call request_human_approval with:
         - A clear question about whether to approve the expense
         - Complete context including the risk analysis and policy information
         - Specific proposed action
         - The implications of approval/rejection

      3. **Process the human response:**
         The request_human_approval tool will return the human's decision.
         - If approved: Acknowledge and prepare to proceed
         - If rejected: Acknowledge and prepare to halt
         - Use the feedback appropriately

      4. **Output the result:**
         Return a JSON object with:
         ```json
         {
           "approval_status": "approved" | "rejected" | "modified",
           "human_response": "the actual response from the human",
           "next_action": "what should happen next"
         }
         ```

      **Important:**
      - Call request_human_approval EXACTLY ONCE
      - After receiving the response, return the result immediately
      - Do NOT call request_human_approval again

  finalizer:
    description: "Provides final summary"
    tools: []
    system_prompt: |
      Provide a clear summary of:
      - The expense request
      - Decision made (approved/rejected/auto-approved)
      - Key details and next steps
      - Expected timeline

      Be professional and friendly.
```

### Understanding the Workflow

1. **risk_analyzer**: Analyzes expense risk and determines if human approval is needed
2. **Routes based on requires_approval**:
    - `yes` (or `true`/`True`): approval_requester (requests human approval)
    - `no` (or `false`/`False`): finalizer (auto-approved)
3. **approval_requester**: Requests human approval and waits for response
4. **finalizer**: Provides final confirmation and summary

---

## Step 5: Build the Application

Create `approval_app.py`:

```python
import asyncio
from agentflow import AsyncWorkflowOrchestrator


class ExpenseApprovalSystem:
    """Manages expense approval workflow with HITL"""

    def __init__(self, orchestrator):
        self.orchestrator = orchestrator

    async def submit_expense(self, amount: float, category: str,
                            description: str):
        """Submit an expense for approval"""

        print(f"\\n{'='*70}")
        print(f"EXPENSE SUBMISSION")
        print(f"{'='*70}")
        print(f"Amount: ${amount:,.2f}")
        print(f"Category: {category}")
        print(f"Description: {description}")
        print(f"{'-'*70}\\n")

        expense_request = f"""
        Please process this expense request:
        - Amount: ${amount:,.2f}
        - Category: {category}
        - Description: {description}
        """

        thread_id = f"expense-{hash(expense_request) % 10000}"

        async for event in self.orchestrator.run(
            state={"messages": [{"role": "user", "content": expense_request}]},
            config={"configurable": {"thread_id": thread_id}},
            stream_tokens=False
        ):
            if event['type'] == 'agent':
                print(f"\\n[{event['name']}]")
                print(event['content'])

            elif event['type'] == 'interrupt':
                # Workflow paused - human input needed!
                await self.handle_interrupt(event, thread_id)

    async def handle_interrupt(self, event, thread_id):
        """Handle human approval requests"""
        interrupt_data = event.get('interrupt_data', [])

        for request in interrupt_data:
            if request.get('type') == 'human_approval_required':
                response = await self.request_approval(request)
                await self.resume_workflow(thread_id, response)

    async def request_approval(self, request):
        """Display approval request and get human response"""

        print(f"\\n{'='*70}")
        print("HUMAN APPROVAL REQUIRED")
        print(f"{'='*70}")
        print(f"\\nQuestion: {request.get('question', '')}")
        print(f"\\nContext:\\n{request.get('context', '')}")
        print(f"\\nProposed Action:\\n{request.get('proposed_action', '')}")
        print(f"\\n{'-'*70}")

        # Get human response
        while True:
            response = input("\\nYour decision (approve/reject): ").strip().lower()

            if response in ['approve', 'approved', 'yes']:
                return "Approved - proceed as proposed"
            elif response in ['reject', 'rejected', 'no']:
                reason = input("Reason for rejection: ").strip()
                return f"Rejected - {reason}"
            else:
                print("Please enter 'approve' or 'reject'")

    async def resume_workflow(self, thread_id, human_response):
        """Resume the workflow with human response"""

        print(f"\\n{'='*70}")
        print("RESUMING WORKFLOW")
        print(f"{'='*70}")
        print(f"Human response: {human_response}\\n")

        config = {"configurable": {"thread_id": thread_id}}

        # Import Command to resume with human response
        from langgraph.types import Command

        # Resume execution with Command via orchestrator.run()
        async for result in self.orchestrator.run(
            Command(resume=human_response),
            config=config,
        ):
            if result.get("type") == "agent":
                content = result.get("content", "")
                if content:
                    print(f"\\n[Resumed]")
                    print(content)

        print(f"\\n{'='*70}")
        print("WORKFLOW COMPLETED")
        print(f"{'='*70}\\n")


async def main():
    """Demo the expense approval system"""

    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
        enable_persistence=True,
        checkpointer_path="data/expenses.db"
    ) as orchestrator:

        system = ExpenseApprovalSystem(orchestrator)

        # Demo 1: Low-risk expense (auto-approved)
        print("\\nDEMO 1: LOW-RISK EXPENSE")
        await system.submit_expense(
            amount=450.00,
            category="office supplies",
            description="Printer paper and supplies"
        )

        await asyncio.sleep(2)

        # Demo 2: High-risk expense (requires approval)
        print("\\n\\nDEMO 2: HIGH-RISK EXPENSE")
        await system.submit_expense(
            amount=12500.00,
            category="consulting",
            description="External consultant for AI strategy"
        )


if __name__ == "__main__":
    asyncio.run(main())
```

---

## Step 6: Run the System

```bash
export OPENAI_API_KEY="your-api-key-here"
python approval_app.py
```

### Expected Output

**Demo 1: Low-Risk Expense (Auto-Approved)**

```
======================================================================
EXPENSE SUBMISSION
======================================================================
Amount: $450.00
Category: office supplies
Description: Printer paper and supplies
----------------------------------------------------------------------

[risk_analyzer]
I've analyzed your office supplies expense request:

Risk Analysis:
- Amount: $450.00
- Category: office supplies (low risk)
- Risk Level: LOW
- Policy: Max $500, auto-approved

Decision: AUTO-APPROVED

Since this expense is within policy limits and low risk, no additional
approval is required.

[finalizer]
Your expense has been automatically approved!

Details:
- Amount: $450.00
- Category: Office Supplies
- Decision: Auto-Approved
- Processing: Payment will be issued within 2 business days

Thank you for following company expense policy!
```

**Demo 2: High-Risk Expense (Requires Approval)**

```
======================================================================
EXPENSE SUBMISSION
======================================================================
Amount: $12,500.00
Category: consulting
Description: External consultant for AI strategy
----------------------------------------------------------------------

[risk_analyzer]
I've analyzed your consulting expense request:

Risk Analysis:
- Amount: $12,500.00
- Category: consulting (high risk)
- Risk Level: HIGH
- Risk Score: 5/5
- Flags:
  - High amount (>$10,000)
  - High-risk category: consulting

Policy Check:
- Max Amount: $10,000
- Exceeds limit by: $2,500
- Requires Approval: VP Level

======================================================================
HUMAN APPROVAL REQUIRED
======================================================================

Question: Should we approve this consulting expense that exceeds policy limits?

Context:
Amount: $12,500.00
Category: Consulting
Policy Limit: $10,000
Overage: $2,500 (25% over limit)
Description: External consultant for AI strategy

Risk Factors:
- High amount exceeding policy
- Consulting services (high-risk category)
- Requires VP approval per policy
- Need business justification

Proposed Action:
Approve this expense with VP sign-off, noting it's for strategic AI
initiative which may justify the exception.

----------------------------------------------------------------------

Your decision (approve/reject): approve

======================================================================
RESUMING WORKFLOW
======================================================================
Human response: Approved - proceed as proposed

[approval_requester]
Human approval received! Processing expense...

Approval Details:
- Decision: Approved by VP
- Human Response: Approved - proceed as proposed
- Amount: $12,500.00
- Status: Moving to final processing

[finalizer]
Summary of Expense Approval:

Request: $12,500.00 consulting expense
Decision: APPROVED (with VP override)
Reason: Strategic AI initiative justifies policy exception

The expense has been processed and payment is scheduled.
Thank you!
```

---

## What Just Happened?

Let's break down the HITL flow:

### 1. Agent Analyzed the Expense

- Used `analyze_expense` tool to assess risk
- Used `lookup_policy` to check company rules
- Determined risk level: HIGH

### 2. Agent Decided Human Approval Needed

- Expense exceeded policy limits
- High-risk category
- Confidence too low for autonomous decision

### 3. Agent Called `request_human_approval`

- Prepared structured approval request
- Provided complete context
- Proposed specific action

### 4. LangGraph's `interrupt()` Paused Workflow

- Execution stopped immediately
- State saved to SQLite checkpointer
- Approval request attached to workflow state
- Workflow enters interrupted state waiting for resume

### 5. Human Reviewed and Approved

- Application checked workflow state for interrupts
- Displayed approval request to human
- Human made decision based on context
- Application prepared to resume with response

### 6. Workflow Resumed with Command

- Application called `Command(resume=human_response)`
- LangGraph resumed workflow from interruption point
- `interrupt()` function returned human's response as tool result
- Agent received response and continued processing
- Completed the expense processing

---

## Understanding the Key Components

### 1. The `interrupt()` Function

```python
human_response = interrupt(approval_request)
```

This single line:

- Pauses workflow execution
- Saves complete state to database
- Waits for human response
- Returns response when workflow resumes
- Completely transparent to the agent

### 2. Handling Interrupts

Interrupts are detected by checking the workflow state:

```python
# Get workflow state
state = await orchestrator.get_state(thread_id)

# Check for interrupts in tasks
for task in state.get("tasks", []):
    if hasattr(task, 'interrupts') and task.interrupts:
        # Extract interrupt data
        for interrupt_obj in task.interrupts:
            interrupt_data = interrupt_obj.value
            # interrupt_data contains the payload from interrupt()
            await handle_approval(interrupt_data)
```

The interrupt data contains the payload you passed to `interrupt()`:

```python
{
    "type": "human_approval_required",
    "question": "Should we approve...",
    "context": "...",
    "proposed_action": "..."
}
```

### 3. Resuming Workflow with Command

The modern approach uses `Command` objects to resume:

```python
from langgraph.types import Command

config = {"configurable": {"thread_id": thread_id}}

# Resume with Command via orchestrator.run()
async for result in orchestrator.run(
    Command(resume=human_response),  # Human's response goes here
    config=config,
):
    if result.get("type") == "agent":
        content = result.get("content", "")
        if content:
        for msg in chunk["messages"]:
            print(msg.content)
```

**Key Points:**

- `Command(resume=value)` tells LangGraph to resume the interrupted workflow
- The value you pass becomes the return value of `interrupt()` in your tool
- The workflow continues from where it was paused
- No need to manually update state or retrieve it

### 4. Alternative: Handling GraphInterrupt Exceptions

In CLI applications, you can catch `GraphInterrupt` exceptions directly:

```python
from langgraph.errors import GraphInterrupt
from langgraph.types import Command

try:
    # Run workflow
    async for event in orchestrator.run(state, config):
        print(event)

except GraphInterrupt as e:
    # Workflow was interrupted - get human input
    print("Workflow paused for human input")

    # Get workflow state to access interrupt data
    state = await orchestrator.get_state(thread_id)

    # Extract interrupt information
    for task in state.get("tasks", []):
        if task.interrupts:
            interrupt_data = task.interrupts[0].value
            print(f"Question: {interrupt_data['question']}")

    # Get human response
    human_response = input("Your response: ")

    # Resume workflow
    async for result in orchestrator.run(
            Command(resume=human_response),
            config=config,
    ):
        # Continue processing...
        pass
```

This approach is useful when:

- Building CLI tools
- You want synchronous control flow
- Direct exception handling fits your architecture

---

## When to Use HITL

### Good Use Cases

1. **High-Stakes Decisions**
    - Financial transactions over threshold
    - Customer refunds
    - Account modifications
    - Data deletions

2. **Low Confidence Situations**
    - Ambiguous input data
    - Edge cases not covered by rules
    - Unusual patterns detected
    - Conflicting information

3. **Regulatory Compliance**
    - Actions requiring documented approval
    - Audit trail requirements
    - Multi-level authorization
    - Legal review needed

4. **Learning Systems**
    - Agent uncertain about decision
    - Need human expertise
    - Building training data
    - Validation of AI decisions

### Don't Use HITL When

- Decisions are routine and low-risk
- Response time is critical (< 1 second)
- 100% automation is required
- Human is rarely available

---

## Best Practices

### 1. Provide Complete Context

**Bad:**

```python
request_human_approval(
    question="Approve this expense?",
    context="It's a lot of money",
    proposed_action="Approve it"
)
```

**Good:**

```python
request_human_approval(
    question="Should we approve this consulting expense that exceeds policy limits?",
    context=f"""
Amount: ${amount:,.2f}
Category: {category}
Policy Limit: ${policy_limit:,.2f}
Overage: ${amount - policy_limit:,.2f} ({overage_percent}%)
Description: {description}

Risk Factors:
- {risk_factor_1}
- {risk_factor_2}

Business Justification:
{justification}
    """,
    proposed_action="Approve with VP sign-off and exception documentation"
)
```

### 2. Set Clear Thresholds

In your agent system prompt:

```
**When to Request Human Approval:**
- Expense amount > $5,000
- Risk level: HIGH
- Policy violations or exceptions
- Confidence < 80%
- Unusual patterns detected
- Missing required documentation
```

### 3. Handle Multiple Interrupts

A workflow can pause multiple times:

```python
async def handle_interrupt(self, event, thread_id):
    """Handle one or more approval requests"""
    interrupt_data = event.get('interrupt_data', [])

    for request in interrupt_data:
        # Handle each approval request
        response = await self.get_human_response(request)
        # Resume after each one
        await self.resume_workflow(thread_id, response)
```

### 4. Implement Timeout Policies

```python
import asyncio

async def request_approval_with_timeout(self, request, timeout=300):
    """Request approval with 5-minute timeout"""
    try:
        return await asyncio.wait_for(
            self.request_approval(request),
            timeout=timeout
        )
    except asyncio.TimeoutError:
        # Auto-reject or escalate
        return "Timeout - escalating to supervisor"
```

### 5. Audit Trail

Log all HITL interactions:

```python
import logging

logger = logging.getLogger(__name__)

async def handle_interrupt(self, event, thread_id):
    logger.info(f"HITL Request - Thread: {thread_id}")
    logger.info(f"Question: {request.get('question')}")

    response = await self.request_approval(request)

    logger.info(f"HITL Response - Thread: {thread_id}")
    logger.info(f"Decision: {response}")
    logger.info(f"Timestamp: {datetime.now()}")
```

---

## Advanced Patterns

### Pattern 1: Confidence-Based Approval

```python
@tool
def analyze_with_confidence(data: str) -> str:
    """Analyze data and return confidence score"""

    # Your analysis logic
    confidence = calculate_confidence(data)

    if confidence < 0.80:
        # Low confidence - request human approval
        human_response = interrupt({
            "type": "human_approval_required",
            "question": "Confidence is low. How should we proceed?",
            "context": f"Confidence: {confidence:.0%}\\nData: {data}",
            "proposed_action": "Proceed with caution"
        })
        return human_response

    # High confidence - proceed automatically
    return auto_process(data)
```

### Pattern 2: Multi-Level Approval

```python
@tool
def request_approval_chain(amount: float, description: str) -> str:
    """Request approval from appropriate level"""

    if amount > 50000:
        # VP approval required
        response = interrupt({
            "type": "human_approval_required",
            "question": "VP approval needed for large expense",
            "context": f"Amount: ${amount:,.2f}\\n{description}",
            "approval_level": "VP"
        })

        if "approved" not in response.lower():
            return response

        # After VP, also need CFO
        response = interrupt({
            "type": "human_approval_required",
            "question": "CFO final approval needed",
            "context": f"VP Approved. Amount: ${amount:,.2f}",
            "approval_level": "CFO"
        })

    elif amount > 10000:
        # Manager approval
        response = interrupt({
            "type": "human_approval_required",
            "question": "Manager approval needed",
            "context": f"Amount: ${amount:,.2f}\\n{description}",
            "approval_level": "Manager"
        })

    return response
```

### Pattern 3: Batch Approval

```python
@tool
def request_batch_approval(items: list) -> str:
    """Request approval for multiple items at once"""

    items_text = "\\n".join([f"- {item}" for item in items])

    response = interrupt({
        "type": "human_approval_required",
        "question": f"Approve all {len(items)} items?",
        "context": f"Items for approval:\\n{items_text}",
        "proposed_action": "Approve entire batch"
    })

    return response
```

---

## Integrating with Web Applications

### FastAPI Example

```python
from fastapi import FastAPI, WebSocket
from agentflow import AsyncWorkflowOrchestrator
from langgraph.types import Command

app = FastAPI()


@app.websocket("/workflow/{thread_id}")
async def workflow_endpoint(websocket: WebSocket, thread_id: str):
    await websocket.accept()

    async with AsyncWorkflowOrchestrator(
            config_path="workflow.yaml",
            tools_module="tools",
            enable_persistence=True,
            checkpointer_path="data/workflows.db"
    ) as orchestrator:

        # Receive user message
        message = await websocket.receive_json()

        # Run workflow
        async for event in orchestrator.run(
                state=message["state"],
                config={"configurable": {"thread_id": thread_id}}
        ):
            await websocket.send_json(event)

        # After workflow completes, check for interrupts
        state = await orchestrator.get_state(thread_id)

        # Check if workflow is interrupted
        for task in state.get("tasks", []):
            if hasattr(task, 'interrupts') and task.interrupts:
                # Extract interrupt data
                interrupt_data = [i.value for i in task.interrupts]

                # Send approval request to frontend
                await websocket.send_json({
                    "type": "approval_needed",
                    "data": interrupt_data
                })

                # Wait for human response
                response = await websocket.receive_json()

                # Resume workflow with Command
                config = {"configurable": {"thread_id": thread_id}}
                async for result in orchestrator.run(
                        Command(resume=response["approval"]),
                        config=config,
                ):
                    await websocket.send_json({
                        "type": "workflow_progress",
                        "data": result
                    })
```

### Frontend Example (React)

```javascript
const ExpenseApprovalUI = ({ threadId }) => {
  const [needsApproval, setNeedsApproval] = useState(false);
  const [approvalRequest, setApprovalRequest] = useState(null);

  useEffect(() => {
    const ws = new WebSocket(`ws://localhost:8000/workflow/${threadId}`);

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);

      if (data.type === 'approval_needed') {
        setNeedsApproval(true);
        setApprovalRequest(data.data[0]);
      }
    };
  }, [threadId]);

  const handleApproval = (decision) => {
    ws.send(JSON.stringify({
      approval: decision
    }));
    setNeedsApproval(false);
  };

  if (needsApproval) {
    return (
      <div className="approval-modal">
        <h2>Approval Required</h2>
        <p>{approvalRequest.question}</p>
        <pre>{approvalRequest.context}</pre>
        <button onClick={() => handleApproval("Approved")}>
          Approve
        </button>
        <button onClick={() => handleApproval("Rejected")}>
          Reject
        </button>
      </div>
    );
  }

  return <div>Workflow running...</div>;
};
```

---

## Troubleshooting

### Problem: Workflow Not Pausing

**Check 1:** Is the tool being called?

Add logging to your tool:

```python
@tool
def request_human_approval(...):
    print("DEBUG: request_human_approval called!")
    approval_request = {...}
    human_response = interrupt(approval_request)
    print(f"DEBUG: Got response: {human_response}")
    return human_response
```

**Check 2:** Is the tool registered in workflow.yaml?

```yaml
nodes:
  your_agent:
    tools:
      - request_human_approval  # Must be here!
```

**Check 3:** Is agent instructed to use the tool?

Update system prompt:

```
When you need approval, you MUST call request_human_approval tool.
```

### Problem: Workflow Won't Resume

**Check:** Are you using Command correctly?

```python
# Correct - Using Command to resume
from langgraph.types import Command

async for result in orchestrator.run(
        Command(resume=human_response),
        config={"configurable": {"thread_id": thread_id}},
):
    process(result)

# Wrong - Old approach (deprecated)
await orchestrator.update_state(
    thread_id=thread_id,
    updated_values={"__interrupt__": ({"value": human_response},)}
)
```

**Check:** Is your workflow name correct?

```python
# Verify workflow exists
available = list(orchestrator.parsed_config.workflows.keys())
if workflow_name not in available:
    print(f"Available workflows: {available}")
```

### Problem: Multiple Interrupts Not Handled

Handle all interrupts from state tasks:

```python
# Get workflow state
state = await orchestrator.get_state(thread_id)

# Check all tasks for interrupts
for task in state.get("tasks", []):
    if hasattr(task, 'interrupts') and task.interrupts:
        for interrupt_obj in task.interrupts:
            # Extract interrupt data
            request = interrupt_obj.value
            # Get human response
            response = await request_approval(request)
            # Resume with Command
            await resume_workflow(thread_id, response)
```

---

## Comparison: AgentFlow HITL vs Alternatives

| Feature           | AgentFlow HITL | LangChain      | LangGraph Manual | Custom Code  |
|-------------------|----------------|----------------|------------------|--------------|
| Agent-Triggered   | Built-in       | Manual         | Complex          | Manual       |
| State Persistence | Automatic      | Manual         | Yes              | Manual       |
| Easy Integration  | Simple API     | Complex        | Complex          | From scratch |
| Resume Workflow   | One line       | Multiple steps | Multiple steps   | Complex      |
| Configuration     | YAML           | Python code    | Python code      | Python code  |

---

## Real-World Use Cases

### 1. Financial Services

**Loan Approval Workflow**

- Analyze applicant credit score
- Request human review for borderline cases
- Manager approves/rejects with notes
- System processes decision

### 2. Healthcare

**Treatment Plan Approval**

- AI suggests treatment plan
- Doctor reviews and approves
- Modifications documented
- Patient notified

### 3. Content Moderation

**Flagged Content Review**

- AI detects potentially harmful content
- Uncertain cases sent to human moderator
- Moderator makes final decision
- Content published or removed

### 4. Manufacturing

**Quality Control**

- Automated inspection detects anomaly
- Human inspector verifies
- Approve continuation or stop production
- Document decision for compliance

---

## Summary

You've learned how to:

- Create HITL tools using `interrupt()`
- Design workflows that pause for human input
- Handle approval requests in your application
- Resume workflows with human responses
- Implement confidence-based approval
- Integrate HITL with web applications
- Build production-ready approval systems

**Key Takeaway:** HITL enables the perfect balance between AI autonomy and human oversight. The agent decides when it
needs help, creating intelligent systems that know their limitations.

---

## Conclusion

You've completed the Human-in-the-Loop tutorial and built an intelligent approval system that knows when to ask for
human help. This is a critical pattern for production AI systems that need to balance automation with human judgment.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

