# OpenTelemetry Integration

## Introduction

You've built multi-agent workflows that work well, but how do you:

- Understand what's happening inside your workflows?
- Track performance across agents and tools?
- Debug issues in production?
- Monitor token usage and LLM latency?

This is where **OpenTelemetry** becomes essential. In this tutorial, you'll learn
how to add distributed tracing to your AgentFlow workflows, giving you complete
visibility into execution flow, performance, and errors — on any observability
platform.

---

## What is OpenTelemetry?

OpenTelemetry (OTEL) is an open-source observability framework for collecting
traces, metrics, and logs. AgentFlow uses OTEL to export traces to any compatible
backend — you choose the platform at deployment time, not in code.

### How AgentFlow Traces Work

AgentFlow uses two tracing layers that work together:

1. **LangSmith OTEL** (automatic) — auto-instruments all LangGraph operations.
   Every LLM call gets a span with model name (`gen_ai.request.model`), token
   counts (`gen_ai.usage.*`), and full prompt/completion content. Tool calls,
   agent nodes, and graph routing are all captured automatically.

2. **AgentFlow native telemetry** (domain-specific) — a first-class subsystem
   (not a plugin) that emits spans for events LangGraph doesn't know about:
   HITL interrupts, A2A external agent calls, and errors.

Both layers export through the same OTEL TracerProvider, so all spans appear in
a single unified trace tree on your chosen backend.

### Trace Hierarchy

A typical workflow trace looks like this:

```
LangGraph (root — full workflow, ~60s)
├── router (query routing node)
│   ├── Orchestrator (agent chain)
│   │   └── model > AzureChatOpenAI (LLM: 148 in / 4 out tokens)
│   └── router (function call result)
├── IT Troubleshooting (workflow subgraph)
│   ├── LangGraph (subgraph execution)
│   │   ├── Initial Diagnostic Agent (20.8s)
│   │   │   ├── model > AzureChatOpenAI (LLM: 1065/69 tokens)
│   │   │   ├── tools > search_error_codes (48ms)
│   │   │   ├── tools > search_system_logs (64ms)
│   │   │   ├── tools > read_system_config (64ms)
│   │   │   └── model > AzureChatOpenAI (LLM: 2896/991 tokens)
│   │   ├── Deep Analysis Agent (20.6s)
│   │   │   ├── model > AzureChatOpenAI (LLM: 5031/83 tokens)
│   │   │   ├── tools > get_service_dependencies, anomaly_detector, risk_assessor
│   │   │   └── model > AzureChatOpenAI (LLM: 6271/1245 tokens)
│   │   └── Solution Agent (12.8s)
│   │       ├── model > AzureChatOpenAI (LLM: 5969/32 tokens)
│   │       ├── tools > fix_recommender
│   │       └── model > AzureChatOpenAI (LLM: 6621/500 tokens)
```

Every `AzureChatOpenAI` span carries:

- `gen_ai.request.model` — the model deployment name
- `gen_ai.system` — the provider (`openai`, `anthropic`, etc.)
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.usage.total_tokens`
- `langsmith.metadata.execution_id` — correlates with the workflow execution
- `langsmith.metadata.lc_agent_name` — which agent made the call

---

## Prerequisites

- Python 3.10 or higher
- Docker or Podman (for running a tracing backend)
- An existing AgentFlow workflow

---

## Part 1: Choose a Backend

AgentFlow exports standard OTLP traces. Pick any backend — the only difference
is the `.env` configuration.

### Option A: Jaeger (simple, gRPC)

```bash
docker run -d --name jaeger \
  -p 16686:16686 \
  -p 4317:4317 \
  jaegertracing/all-in-one:latest
```

```bash
# .env
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

UI: http://localhost:16686

### Option B: Langfuse (LLM-focused, HTTP + auth)

```bash
# See https://langfuse.com/docs/deployment/self-host for self-hosting
# .env
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <base64(public_key:secret_key)>
```

Generate the base64: `echo -n "pk-lf-...:sk-lf-..." | base64`

### Option C: Phoenix by Arize (GenAI-native, HTTP)

```bash
docker run -d --name phoenix -p 6006:6006 -p 4317:4317 arizephoenix/phoenix
```

```bash
# .env
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

UI: http://localhost:6006 — understands `gen_ai.*` attributes natively.

### Option D: Any other OTLP backend

See the [Observability reference](../OBSERVABILITY.md) for Grafana Tempo,
Datadog, New Relic, Honeycomb, and Splunk configurations.

---

## Part 2: Enable Tracing

Create a `.env` file with your chosen backend config:

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

That's all. Native OpenTelemetry tracing is **enabled automatically** when
`OTEL_TRACES_ENABLED=true`. No code changes required.

### Configuration Reference

| Variable                      | Description                | Default                 |
|-------------------------------|----------------------------|-------------------------|
| `OTEL_TRACES_ENABLED`         | Must be `true` to enable   | `false`                 |
| `OTEL_SERVICE_NAME`           | Service name in traces     | `agentflow-workflow`   |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Backend OTLP endpoint      | `http://localhost:4317` |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | `grpc` or `http/protobuf`  | `grpc`                  |
| `OTEL_EXPORTER_OTLP_HEADERS`  | Auth headers (`key=value`) | (none)                  |

---

## Part 3: Run Your Workflow

### CLI

```bash
agentflow "What is the status of order ORD-001?"
```

You'll see in the startup output:

```
OpenTelemetry tracing enabled
  Service: my-workflow
  Endpoint: http://localhost:4317 (grpc)
  LangSmith OTEL: enabled (LLM-level tracing active)
```

### Python API

```python
import asyncio
from dotenv import load_dotenv
from agentflow import AsyncWorkflowOrchestrator

load_dotenv()  # Loads OTEL_* variables from .env

async def main():
    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools"
    ) as orchestrator:
        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "Hello"}]},
            config={"configurable": {"thread_id": "session-123"}}
        ):
            if event['type'] == 'agent':
                print(f"[{event['name']}]: {event['content']}")

asyncio.run(main())
```

Traces are collected automatically — no registration code needed.

---

## Part 4: View Traces

Open your backend's UI and find your service name. You'll see:

- **Full workflow trace tree** with proper parent-child nesting
- **Per-LLM-call detail**: which model, how many tokens in/out, latency
- **Tool executions**: each tool call with input/output and duration
- **Agent handoffs**: when one agent passes to the next

### Key Span Attributes

**LLM spans** (auto-generated by LangSmith OTEL):

| Attribute                          | Example                      |
|------------------------------------|------------------------------|
| `gen_ai.request.model`             | `gpt-4o-mini`                |
| `gen_ai.system`                    | `openai`                     |
| `gen_ai.usage.input_tokens`        | `1065`                       |
| `gen_ai.usage.output_tokens`       | `69`                         |
| `langsmith.metadata.lc_agent_name` | `Initial_Diagnostic_Agent`   |
| `langsmith.metadata.execution_id`  | `97aa4a45-...`               |
| `langsmith.metadata.workflow_name` | `IT Troubleshooting Advisor` |

**Domain-specific spans** (native telemetry):

| Span                   | Attributes                                       |
|------------------------|--------------------------------------------------|
| `hitl.*`               | `hitl.type`, `execution_id`                      |
| `external_agent.*`     | `external_agent.name`, `external_agent.endpoint` |
| `mcp.connect.*`        | `mcp.server_name`, `mcp.tool_count`              |
| `checkpoint.save/load` | `checkpoint.id`, `checkpoint.data_size_bytes`    |
| `workflow.error`       | `error_type`, `error_message`                    |

---

## Part 5: Production Setup

### Docker Compose

```yaml
services:
  jaeger:
    image: jaegertracing/all-in-one:latest
    ports:
      - "16686:16686"
      - "4317:4317"

  my-app:
    build: .
    environment:
      - OTEL_TRACES_ENABLED=true
      - OTEL_SERVICE_NAME=my-workflow
      - OTEL_EXPORTER_OTLP_ENDPOINT=http://jaeger:4317
```

### Environment-Based Configuration

Control tracing per environment:

```bash
# Development — disabled by default
OTEL_TRACES_ENABLED=false

# Staging — send to shared Jaeger
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow-staging
OTEL_EXPORTER_OTLP_ENDPOINT=http://jaeger.staging:4317

# Production — send to your APM platform
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow-prod
OTEL_EXPORTER_OTLP_ENDPOINT=https://otlp.nr-data.net
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=api-key=YOUR_KEY
```

### Sensitive Data

LangSmith OTEL exports full prompt/completion content in `gen_ai.prompt` and
`gen_ai.completion` span attributes. In production, consider:

- Using an OTEL Collector with attribute filtering to redact sensitive fields
- Setting `LANGSMITH_TRACING=false` to disable LangSmith (loses LLM-level spans)
- Checking your backend's data retention and access policies

---

## Troubleshooting

### Traces Not Appearing

1. Check `OTEL_TRACES_ENABLED=true` is set (not `"true"` with quotes in some shells)
2. Look for startup message: `OpenTelemetry tracing enabled`
3. Look for export errors: `Failed to export span batch code: 401` means auth is wrong
4. Verify the backend is running: `curl http://localhost:4317` (gRPC) or `curl http://localhost:16686` (Jaeger UI)

### 401 Unauthorized

Your `OTEL_EXPORTER_OTLP_HEADERS` is missing or has wrong credentials. Check
your backend's API key configuration.

### 405 Method Not Allowed

The endpoint path is wrong. For HTTP backends, set only the base URL in
`OTEL_EXPORTER_OTLP_ENDPOINT` — the SDK appends `/v1/traces` automatically.

### Duplicate `/v1/traces/v1/traces` in Logs

Don't include `/v1/traces` in the endpoint — the HTTP exporter adds it:

```bash
# Wrong:
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006/v1/traces
# Right:
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
```

---

## Summary

- **One env var** (`OTEL_TRACES_ENABLED=true`) enables everything
- **LLM-level detail** (model, tokens, prompts) is automatic via LangSmith OTEL
- **Any OTLP backend** works through `.env` configuration — no code changes
- **The principle**: AgentFlow creates spans, operators choose where they go

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](../LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

