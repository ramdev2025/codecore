# Observability

AgentFlow provides built-in distributed tracing via OpenTelemetry (OTLP). Traces
are exported to any OTLP-compatible backend — choose your platform at deployment
time through environment variables alone.

Observability is a **deployment concern** — enabled via `.env`, not in application
code. When disabled, there is zero overhead.

## Tracing

### Enable Tracing

Add to your `.env`:

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
```

That's it. Run your workflow normally and traces flow to the configured backend.

### How It Works

AgentFlow uses a two-layer tracing architecture:

1. **LangSmith OTEL** (automatic) — auto-instruments all LangGraph operations:
   LLM calls with model name and token usage, tool invocations, agent node
   execution, and graph routing. This is enabled automatically when tracing is on.

2. **AgentFlow native telemetry** (domain-specific) — a first-class subsystem
   (`agentflow.workflows.core.telemetry`, owned by the orchestrator — **not** a
   plugin) that emits spans for events LangGraph doesn't know about:
   human-in-the-loop interrupts, external agent (A2A) calls, and workflow errors.

### What Gets Traced

LangSmith auto-generates a complete trace tree per workflow execution:

```
LangGraph (root span — full workflow execution)
├── router (query routing)
│   └── AzureChatOpenAI (LLM call — model, tokens, latency)
├── IT Troubleshooting (workflow subgraph)
│   ├── Initial Diagnostic Agent
│   │   ├── model > AzureChatOpenAI (LLM call)
│   │   └── tools
│   │       ├── search_error_codes (tool execution)
│   │       ├── search_system_logs
│   │       └── read_system_config
│   ├── Deep Analysis Agent
│   │   ├── model > AzureChatOpenAI (LLM call)
│   │   └── tools > get_service_dependencies, anomaly_detector, risk_assessor
│   └── Solution Agent
│       ├── model > AzureChatOpenAI (LLM call)
│       └── tools > fix_recommender
```

Each LLM span includes:

- `gen_ai.request.model` — model name (e.g., `gpt-4o-mini`)
- `gen_ai.system` — provider (e.g., `openai`)
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.usage.total_tokens`
- `gen_ai.prompt`, `gen_ai.completion` — full serialized I/O

Additionally, the native telemetry subsystem emits standalone spans for:

- `hitl.*` — human-in-the-loop wait time
- `external_agent.*` — A2A protocol calls
- `workflow.error` — orchestrator-level errors

### Backend Configuration

The OTEL SDK reads standard environment variables — no code changes needed per
backend. Set `OTEL_EXPORTER_OTLP_ENDPOINT` and optionally `OTEL_EXPORTER_OTLP_PROTOCOL`
and `OTEL_EXPORTER_OTLP_HEADERS` in your `.env`:

#### Jaeger (gRPC)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

Start Jaeger: `docker run -d -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one:latest`

UI: http://localhost:16686

#### Langfuse (HTTP + auth)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <base64(public_key:secret_key)>
```

Generate the base64 value: `echo -n "pk-lf-...:sk-lf-..." | base64`

#### Phoenix by Arize (HTTP)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

Start Phoenix: `docker run -d -p 6006:6006 -p 4317:4317 arizephoenix/phoenix`

UI: http://localhost:6006

#### Grafana Tempo (gRPC)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://tempo:4317
```

#### Datadog (via Datadog Agent)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

Enable OTLP ingestion in the Datadog Agent (`datadog.yaml`):

```yaml
otlp_config:
  receiver:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
```

#### New Relic (HTTP + API key)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=https://otlp.nr-data.net
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=api-key=YOUR_LICENSE_KEY
```

#### Honeycomb (HTTP + API key)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=https://api.honeycomb.io
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=x-honeycomb-team=YOUR_API_KEY
```

#### Splunk Observability (HTTP + token)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-workflow
OTEL_EXPORTER_OTLP_ENDPOINT=https://ingest.signalfx.com/v2/trace/otlp
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=X-SF-Token=YOUR_ACCESS_TOKEN
```

### Multiple exporters (the exporter seam)

The OTLP exporter above is the default sink. You can attach **additional** span
processors so traces reach several backends at once (dual-export). The default
path is unchanged when nothing is registered.

**In-process** — register before the app initializes (e.g. at startup):

```python
from agentflow.workflows import register_span_processor
from opentelemetry.sdk.trace.export import BatchSpanProcessor

register_span_processor(BatchSpanProcessor(my_exporter))
```

**Via an installed package** — a package can contribute an exporter with no app
code by registering an entry point in the `agentflow.span_processors` group. Each
entry point loads to a zero-arg factory returning a `SpanProcessor` (or `None` to
opt out, e.g. when its config is absent):

```toml
# in the integration package's pyproject.toml
[project.entry-points."agentflow.span_processors"]
my_exporter = "my_pkg:make_processor"
```

### Azure Monitor / Application Insights (Azure AI Foundry)

Azure AI Foundry Observability is OTel GenAI spans landing in **Application
Insights** and rendering in the Foundry **Tracing** tab. App Insights does not
ingest raw OTLP on its public endpoint, so AgentFlow's vendor-neutral OTLP can't
reach it directly — an `AzureMonitorTraceExporter` (connection-string based)
translates for it. AgentFlow ships that exporter as a first-class user of the
seam above: it's built in as the `azure_monitor` entry point and activates only
when you install the extra and set the connection string.

Because the seam is backend-agnostic (it lives in `agentflow.core.telemetry_seam`
and every backend attaches to it), this works for **all OTLP backends** —
`workflows`, `deep`, `sk`, `cas`, `oai`, and `adk` — with no per-app wiring. (The
`maf` backend reaches Foundry through Microsoft Agent Framework's own native
Azure Monitor integration instead.)

```bash
pip install 'agentflow[azure-monitor]'

# .env
OTEL_TRACES_ENABLED=true
APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=https://..."
```

That's all — no code changes. The Azure processor is attached **additively**, so
any OTLP export you've configured (Jaeger, Langfuse, a Collector, …) keeps
working alongside Azure (dual-export). Traces appear in App Insights and, once
that resource is linked to your Foundry project, in the Foundry Tracing tab.

Behavior:

- **Auto-detected** — the exporter attaches only when
  `APPLICATIONINSIGHTS_CONNECTION_STRING` is set (and `OTEL_TRACES_ENABLED=true`).
  With the variable unset, the default path imports nothing Azure-related and is
  byte-for-byte unchanged.
- **No phantom OTLP** — with an Azure connection string set and **no**
  `OTEL_EXPORTER_OTLP_ENDPOINT`, AgentFlow exports to Azure only and skips the
  default OTLP sink — so you get clean logs, not repeated failed exports to
  `localhost:4317`. Set `OTEL_EXPORTER_OTLP_ENDPOINT` as well only if you want to
  **dual-export** to another backend alongside Azure. (When nothing at all is
  configured, the default still points at `localhost:4317` as before.)
- **Clear failure** — if the connection string is set but the extra isn't
  installed, telemetry setup logs an actionable warning
  (`pip install 'agentflow[azure-monitor]'`) and continues with OTLP only,
  rather than crashing.

> **Note:** this lands spans in App Insights. Rich Foundry rendering additionally
> depends on `gen_ai.*` semantic-convention conformance, tracked separately.

> **OpenTelemetry version:** the Azure Monitor exporter (`b56`, the latest) only
> supports the OpenTelemetry **1.43.x** line, so selecting `[azure-monitor]`
> constrains AgentFlow's OTel core to `<1.44` for a self-consistent install.
> Non-Azure installs stay on the latest OTel. Don't hard-pin OpenTelemetry to
> 1.44 in a project that also uses `[azure-monitor]` — the two can't coexist
> until the exporter adds 1.44 support.

### Data considerations (exported content)

The LangSmith → OTel bridge that produces the LLM/tool spans also exports the
**full prompt and completion content** as span attributes (`gen_ai.prompt` /
`gen_ai.completion`) — the entire message history, system prompt, and tool
schemas, often tens of KB per span. Token counts, model, and latency are separate
numeric attributes. Before enabling tracing against a shared or long-retention
backend (including Application Insights / Foundry), consider:

- **Redact at an OTel Collector.** Put a Collector in front of your backend and
  drop or mask the content attributes there (its `attributes` / `redaction`
  processors). This is the recommended approach — it's configuration, not code,
  and it stays correct across LangChain/LangSmith upgrades. AgentFlow
  deliberately ships **no in-process redactor** keyed on bridge attribute names,
  because those names can change upstream and a stale drop-list would silently
  under-redact.
- **Restrict access and retention** on the backend to match the sensitivity of
  the prompts and responses your app handles.
- **Turn tracing off** (leave `OTEL_TRACES_ENABLED` unset) where content must
  never leave the process.

## Structured Logging

Enable JSON-structured log lines for every LLM call and tool invocation:

```yaml
# workflow.yaml
callbacks:
  structured_logging: true
  redact_prompts: false    # Set true to redact prompt content
```

Each log line includes correlation IDs for tracing:

```json
{
  "event": "llm_end",
  "execution_id": "user-123",
  "workflow": "customer_support",
  "run_id": "abc-def",
  "duration_s": 1.234,
  "input_tokens": 150,
  "output_tokens": 85,
  "total_tokens": 235
}
```

These logs integrate with any log aggregation platform (Datadog Logs, CloudWatch,
Elasticsearch, etc.) and correlate with traces via `execution_id`.

## Metrics and Cost Tracking

```yaml
callbacks:
  structured_logging: true
  metrics: true              # Collect per-run metrics
  cost_tracking: 100000      # Token budget (raises BudgetExceededError when exceeded)
```

Metrics are accumulated per run and accessible programmatically:

```python
metrics = orchestrator.get_last_metrics()
# {"llm_calls": 3, "tool_calls": 5, "total_tokens": 1250, ...}

cost = orchestrator.get_last_cost()
# {"total_tokens": 1250, "budget": 100000, "remaining": 98750}
```

The CLI always displays token counts and duration regardless of callback configuration.

## Log Level Control

Set `AGENTFLOW_LOG_LEVEL` in `.env` to control agentflow's logging verbosity:

```bash
AGENTFLOW_LOG_LEVEL=DEBUG    # DEBUG, INFO, WARNING (default), ERROR
```

## Environment Variables Reference

| Variable                         | Description                | Default                 |
|----------------------------------|----------------------------|-------------------------|
| `OTEL_TRACES_ENABLED`            | Enable distributed tracing | `false`                 |
| `OTEL_SERVICE_NAME`              | Service name in traces     | `agentflow-workflow`   |
| `OTEL_EXPORTER_OTLP_ENDPOINT`    | OTLP backend endpoint      | `http://localhost:4317` |
| `OTEL_EXPORTER_OTLP_PROTOCOL`    | `grpc` or `http/protobuf`  | `grpc`                  |
| `OTEL_EXPORTER_OTLP_HEADERS`     | Auth headers (`key=value`) | (none)                  |
| `OTEL_EXPORTER_OTLP_CERTIFICATE` | TLS certificate path       | (none)                  |
| `OTEL_EXPORTER_OTLP_TIMEOUT`     | Export timeout (ms)        | `10000`                 |
| `AGENTFLOW_LOG_LEVEL`            | AgentFlow log verbosity    | `WARNING`               |
