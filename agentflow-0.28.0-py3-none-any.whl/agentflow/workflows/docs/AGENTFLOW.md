# AgentFlow

AgentFlow is a framework-independent, YAML-driven platform for configuring and running AI agent harnesses. The workflows backend uses LangGraph and supports two modes:

- **Standalone agents** — a single agent with tools, ideal for chatbots, assistants, and quick prototyping
- **Multi-agent workflows** — multiple specialized agents with routing, sequencing, and parallel execution

## Key Features

### Core Capabilities

- **LLM-Agnostic**: Works with any LangChain-compatible chat model (OpenAI, Anthropic, Azure, custom)
- **Standalone Agents**: Define a single agent with tools — no orchestrator or workflows needed
- **Workflow Orchestration**: Define complex multi-agent workflows using YAML configuration
- **Conditional Routing**: Dynamic workflow paths based on agent outputs
- **Event Streaming**: Real-time streaming of workflow events and tokens
- **State Persistence**: SQLite for development, PostgreSQL for production

### External Agent Integration

- **A2A Protocol Support**: Connect to A2A-compliant agents (Salesforce, Stripe, AWS Bedrock, etc.)
- **Multi-turn Conversations**: Context preserved across interactions with external agents
- **Authentication Options**: Bearer, API Key, Basic, OAuth2, mTLS, JWT+RSA
- **Native Agent Providers**: Direct integration with external agents, e.g., Snowflake Cortex

### Enterprise Features

- **LangChain Middleware**: Model limits, tool limits, summarization, tool retry
- **Human-in-the-Loop**: Agent-triggered interrupts for human approval
- **Long-term Memory**: Cross-conversation memory with PostgreSQL store
- **Pluggable Architecture**: Extend functionality with custom plugins

## Quick Start: Standalone Agent

The simplest way to get started — a single agent with tools:

### 1. Define Your Agent (`workflow.yaml`)

```yaml
metadata:
  version: "1.0"

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"

agent:
  name: "My Assistant"
  system_prompt: "You are a helpful assistant."
  tools: [search_web]
```

No `orchestrator`, `workflows`, or `nodes` sections needed.

### 2. Create Your Tools

```python
# tools.py
from langchain_core.tools import tool


@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    return f"Search results for: {query}"
```

### 3. Run It

```bash
agentflow "What is the weather today?"
```

Or programmatically:

```python
import asyncio
from agentflow import AsyncWorkflowOrchestrator


async def main():
    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools"
    ) as agent:
        async for event in agent.run(
            state={"messages": [{"role": "user", "content": "Hello!"}]},
            config={"configurable": {"thread_id": "my-session"}}
        ):
            if event['type'] == 'agent':
                print(event['content'])


if __name__ == "__main__":
    asyncio.run(main())
```

Standalone agents support all the same infrastructure: persistence, middleware, MCP tools, telemetry, and streaming.
See the [Standalone Agents tutorial](tutorials/standalone-agent.md) for the full guide.

## Quick Start: Multi-Agent Workflow

When your use case requires multiple specialized agents with routing:

### 1. Define Your Workflow (`workflow.yaml`)

```yaml
metadata:
  version: "1.0"
  name: "My First Workflow"

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"

orchestrator:
  workflows: [main]

workflows:
  main:
    description: "Main workflow"
    nodes:
      assistant:
        depends_on: []

nodes:
  assistant:
    description: "Helpful assistant"
    system_prompt: "You are a helpful assistant."
    tools: [search_web]
```

### 2. Run Your Workflow

**Using async context manager** (recommended):

```python
# main.py
import asyncio
from agentflow import AsyncWorkflowOrchestrator


async def main():
    async with AsyncWorkflowOrchestrator(
        config_path="workflow.yaml",
        tools_module="tools",
        enable_persistence=True,
        checkpointer_path=".agentflow/checkpoints.db"
    ) as orchestrator:
        async for event in orchestrator.run(
            state={"messages": [{"role": "user", "content": "Hello!"}]},
            config={"configurable": {"thread_id": "my-session"}}
        ):
            if event['type'] == 'token':
                print(event['content'], end='', flush=True)
            elif event['type'] == 'agent':
                print(f"\n[{event['name']}]: {event['content']}")


if __name__ == "__main__":
    asyncio.run(main())
```

**Or using async factory method**:

```python
orchestrator = await AsyncWorkflowOrchestrator.create(
    config_path="workflow.yaml",
    tools_module="tools",
    enable_persistence=True
)

# Use orchestrator...
async for event in orchestrator.run(...):
    print(event)

# Cleanup when done
await orchestrator.cleanup()
```

## Architecture

```
              ┌─────────────────┐
              │   Your Client   │
              └────────┬────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │  AsyncWorkflowOrchestrator   │
        │                              │
        │   - Standalone or multi-agent│
        │   - Workflow routing         │
        │   - State management         │
        │   - Event streaming          │
        │   - Middleware pipeline      │
        │   - MCP server management    │
        └───────────────┬──────────────┘
                        │
          ┌─────────────┴─────────────┐
          │                           │
          ▼                           ▼
   ┌─────────────┐         ┌──────────────────┐
   │  Standalone  │         │   Multi-Agent    │
   │   (agent:)   │         │  (orchestrator:  │
   │              │         │   + workflows:)  │
   │ Single agent │         │                  │
   │ with tools   │         │ Router + agents  │
   └──────┬──────┘         └────────┬─────────┘
          │                         │
      ┌───┴────────────────────┬────┴──────────┐
      │              │         │               │
      ▼              ▼         ▼               ▼
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│  Local   │ │   A2A    │ │   MCP    │ │  Native  │
│  Agent   │ │ External │ │  Server  │ │ Provider │
│          │ │  Agent   │ │  Tools   │ │  Agents  │
│LangChain │ │Salesforce│ │ stdio/   │ │          │
│ + Tools  │ │  Stripe  │ │   HTTP   │ │          │
└──────────┘ └──────────┘ └──────────┘ └──────────┘
```

## Node Types

AgentFlow supports multiple types of agent nodes:

### Local Agents

Standard LangChain agents with tools and system prompts:

```yaml
nodes:
  my_agent:
    description: "Local agent"
    system_prompt: "You are helpful."
    tools: [search, calculate]
```

### Local Agents with MCP Tools

Agents that use tools from MCP (Model Context Protocol) servers:

```yaml
nodes:
  data_agent:
    description: "Agent with MCP tools"
    system_prompt: "You have access to data tools."
    mcp_tools:
      - server: data-platform
        tools: [query, list_tables]
```

### External A2A Agents

Connect to A2A-compliant external agents:

```yaml
nodes:
  crm_agent:
    description: "Salesforce CRM agent"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
```

### Custom LLM Agents

Use any LangChain chat model (Snowflake Cortex, Bedrock, Vertex AI, etc.):

```yaml
nodes:
  snowflake_agent:
    description: "Query enterprise data via Snowflake Cortex"
    llm:
      provider: custom
      class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
      config:
        model: "llama3.1-70b"
    system_prompt: |
      You are an enterprise data analyst with access to Snowflake.
      Answer questions about sales, inventory, and business metrics.
```

## Advanced Features

### Conditional Routing

Route workflow execution dynamically based on agent outputs:

```yaml
workflows:
  customer_support:
    description: "Route customer queries"
    nodes:
      router_agent:
        routes:
          router_field: "category"
          technical: technical_agent
          sales: sales_agent
          default: END
      technical_agent:
        depends_on: [router_agent]
      sales_agent:
        depends_on: [router_agent]

nodes:
  router_agent:
    description: "Classifies queries"
    tools: [classify_query]
    system_prompt: |
      Classify the user's query as 'technical' or 'sales'.
      Use the classify_query tool with your classification.
```

### LangChain Middleware

Apply limits, summarization, and controls to your agents:

```yaml
nodes:
  my_agent:
    description: "Agent with limits"
    system_prompt: "You are a helpful assistant."
    tools: [search_web]
    middleware:
      - type: model_call_limit
        config:
          max_calls: 10
      - type: tool_call_limit
        config:
          max_calls: 5
      - type: human_in_the_loop
        config:
          tools: [sensitive_action]
```

See [Middleware Guide](MIDDLEWARE.md) for all middleware types.

### External A2A Agents

Integrate with A2A-compliant external agents:

```yaml
nodes:
  stripe_agent:
    description: "Stripe billing agent"
    endpoint: "https://agents.stripe.com/a2a/billing"
    auth:
      type: api_key
      header: "X-API-Key"
      key: "${STRIPE_API_KEY}"
    timeout: 30
    retry:
      max_attempts: 3
      backoff_factor: 2.0
```

See [External Agents Guide](EXTERNAL_AGENTS.md) for details.

### MCP (Model Context Protocol) Integration

Connect to MCP servers for standardized tool access:

```yaml
# Define MCP servers
mcp_servers:
  data-platform:
    transport: stdio
    command: "python"
    args: ["-m", "my_mcp_server"]
    env:
      DATABASE_URL: "${DATABASE_URL}"

  remote-api:
    transport: streamable_http
    url: "https://api.example.com/mcp"
    auth:
      type: bearer
      token: "${API_TOKEN}"

# Use MCP tools in nodes
nodes:
  analyst:
    description: "Data analyst with MCP tools"
    system_prompt: "You analyze data using available tools."
    mcp_tools:
      - server: data-platform
        tools: [query, list_tables]
      - server: remote-api
        tools:
          - name: analyze
            alias: run_analysis  # Rename tool
```

MCP supports three transports:

- **stdio**: Local subprocess servers
- **sse**: Remote servers with Server-Sent Events
- **streamable_http**: Remote HTTP servers (recommended for production)

See [MCP Integration Guide](MCP.md) for details.

### Custom LLM Integration

Use any LangChain-compatible chat model via the custom provider:

```yaml
nodes:
  snowflake_agent:
    description: "Query data via Snowflake Cortex"
    llm:
      provider: custom
      class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
      config:
        model: "llama3.1-70b"
    system_prompt: "You are an enterprise data analyst..."
```

Set Snowflake credentials via environment variables:
`SNOWFLAKE_USERNAME`, `SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_DATABASE`, etc.

See [Workflow YAML Reference](WORKFLOW_YAML.md) for more custom LLM examples.

### State Persistence

#### SQLite (Development)

```python
async with AsyncWorkflowOrchestrator(
    config_path="workflow.yaml",
    tools_module="tools",
    enable_persistence=True,
    checkpointer_path=".agentflow/checkpoints.db"
) as orchestrator:
    # Conversations persist across restarts
    async for event in orchestrator.run(
        state={"messages": [{"role": "user", "content": "Hello!"}]},
        config={"configurable": {"thread_id": "user-123"}}
    ):
        print(event)
```

#### PostgreSQL (Production)

Configure at deploy time via env vars or CLI flags — not in the YAML:

```bash
pip install "agentflow[postgres]"

# Env-var driven (containerized)
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
export POSTGRES_POOL_SIZE=10
export AGENTFLOW_STORE_ENABLED=true        # opt into long-term memory store
agentflow --yaml workflow.yaml "..."

# Or via CLI flags
agentflow --yaml workflow.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" "..."
```

See [Persistence Guide](PERSISTENCE.md) for the full env-var table
(`AGENTFLOW_ENCRYPTION_KEY` enables at-rest encryption).

### Plugins

Extend AgentFlow with custom plugins:

```python
from agentflow.plugins import Plugin, WorkflowContext


class MetricsPlugin(Plugin):
    def on_workflow_start(self, context: WorkflowContext, initial_state):
        print(f"Workflow {context.workflow_name} started")

    def on_agent_end(self, context: WorkflowContext, agent_name, result):
        print(f"Agent {agent_name} completed")


orchestrator.register_plugin(MetricsPlugin())
```

See [Plugin Specification](PLUGIN_SPECIFICATION.md) for the full API.

### Token Streaming

Stream individual tokens for real-time output:

```python
async for event in orchestrator.run(
    state={"messages": [{"role": "user", "content": "Hello!"}]},
    config={"configurable": {"thread_id": "my-session"}},
    stream_tokens=True
):
    if event['type'] == 'token':
        print(event['content'], end='', flush=True)
    elif event['type'] == 'agent':
        print(f"\n[Agent]: {event['content']}")
```

## LLM Configuration

AgentFlow supports multiple LLM providers with a configuration hierarchy:
Node-level > Workflow-level > Orchestrator-level > Global-level

### Anthropic

```yaml
llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"
    temperature: 0.7
    max_tokens: 4096
```

### OpenAI

```yaml
llm:
  provider: openai
  config:
    model: "gpt-4o"
    temperature: 0.7
    max_tokens: 2000
```

### Azure OpenAI

```yaml
llm:
  provider: azure_openai
  config:
    model: "gpt-4o"
    azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
    azure_deployment: "gpt-4o-deployment"
    api_version: "2024-02-15-preview"
    azure_identity: true  # Use Azure AD authentication
```

### Custom Provider

```yaml
llm:
  provider: custom
  class_name: "langchain_community.chat_models.ChatOllama"
  config:
    model: "llama2"
    base_url: "http://localhost:11434"
```

See [Workflow YAML Reference](WORKFLOW_YAML.md) for complete configuration options.

## CLI Usage

```bash
# One-shot query
agentflow "What is the weather today?"

# Interactive mode
agentflow --interactive

# Custom workflow
agentflow --yaml my_workflow.yaml "Process this request"

# With persistence
agentflow --interactive --thread-id user-123
```

See [CLI Usage](AGENTFLOW_CLI.md) for all options.

## Next Steps

- [Standalone Agents Tutorial](tutorials/standalone-agent.md) - MCP tools, middleware, and more for single agents
- [Getting Started Tutorial](tutorials/getting-started.md) - Full walkthrough of standalone and multi-agent modes
- [Workflow YAML Reference](WORKFLOW_YAML.md) - Complete configuration guide
- [MCP Integration Guide](MCP.md) - Model Context Protocol tools
- [External Agents Guide](EXTERNAL_AGENTS.md) - A2A protocol integration
- [Middleware Guide](MIDDLEWARE.md) - LangChain middleware
- [Persistence Guide](PERSISTENCE.md) - State persistence options
- [Human in the Loop](HUMAN_IN_THE_LOOP.md) - Human approval workflows

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
