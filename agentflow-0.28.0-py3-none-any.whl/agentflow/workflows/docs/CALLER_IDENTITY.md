# Caller Identity (`principal_id`)

*Added in 0.25.0 — workflows backend.*

AgentFlow models **conversation identity** (`thread_id`) as first-class. As of
0.25.0 it also carries an optional **caller identity** — a request-scoped
`principal_id` describing *who* (which persona / user / workspace) a run
executes on behalf of.

The split to keep in mind:

> **AgentFlow carries and persists the identity. Your app resolves and
> authenticates it.**

The framework never inspects credentials, never logs anyone in, and never
enforces who may see what. It just makes sure the identity your app resolved
flows to your tools and is stored with each run.

It is **fully opt-in**. With no resolver configured, everything behaves exactly
as it did before 0.25.0.

---

## What it gives you

`principal_id` rides in LangGraph's existing `configurable` channel (the same
place `thread_id` lives), so one small addition delivers three things at once:

1. **Propagation** — tools read it off the `RunnableConfig` they already receive.
2. **Persistence** — it is written into each checkpoint's `metadata`, so runs
   are filterable by principal (e.g. a principal-scoped thread list).
3. **Observability** — it is exposed to plugins and telemetry via
   `WorkflowContext.principal_id`.

---

## 1. Resolve it — `principal_resolver` on `build_agui`

Give `build_agui` a callback that maps an incoming request to an identity. It
runs once per request/connection and returns a `principal_id` string, or `None`
for anonymous. It may be sync or async.

```python
from agentflow.workflows.agui import build_agui
from starlette.requests import HTTPConnection


def resolve_principal(conn: HTTPConnection) -> str | None:
    # conn is a Starlette Request (POST/SSE) or WebSocket (WS) — both expose
    # .headers / .session / .cookies. Read a VERIFIED claim here.
    return conn.headers.get("x-workspace-id")  # example only


router, lifespan = build_agui(
    yaml_path="workflow.yaml",
    tools_module="tools",
    principal_resolver=resolve_principal,   # omit → anonymous, unchanged behavior
)
```

The resolver is the **trusted** path — it should read a verified session or
identity claim (Azure AD, a signed session cookie, a gateway-injected header),
not an arbitrary client-supplied value. A client-provided value MAY be used as
an *untrusted* fallback only if your app explicitly opts in and treats it as
spoofable.

Async resolvers work too (auth lookups are often async):

```python
async def resolve_principal(conn: HTTPConnection) -> str | None:
    return await my_auth.workspace_for(conn)
```

---

## 2. Read it in a tool — `get_principal`

Tools already receive the `RunnableConfig`. Read the principal from it:

```python
from langchain_core.tools import tool
from langchain_core.runnables import RunnableConfig
from agentflow.workflows import get_principal


@tool
def load_preferences(config: RunnableConfig) -> str:
    """Return the caller's saved preferences."""
    principal = get_principal(config)     # None when not configured
    if principal is None:
        return default_preferences()
    return preferences_for(principal)     # per-workspace / per-user data
```

No extra wiring is needed — LangGraph delivers `config` to tools, and the
`principal_id` is already in its `configurable`.

---

## 3. It persists automatically — principal-scoped thread history

Because AgentFlow copies `principal_id` into each checkpoint's `metadata`, you
can list a *single principal's* threads instead of everyone's. With the
Postgres checkpointer:

```sql
SELECT thread_id, MAX(checkpoint_id) AS latest
FROM checkpoints
WHERE metadata->>'principal_id' = %s      -- the requesting principal
GROUP BY thread_id
ORDER BY latest DESC;
```

This is what powers a ChatGPT-style "previous conversations" sidebar that
correctly isolates one persona/workspace from another. AgentFlow persists the
metadata; querying and filtering it is the app's job.

> **Legacy threads.** Rows created before 0.25.0 have no `principal_id`
> (`metadata->>'principal_id'` is `NULL`). Existing threads still read fine.
> You decide whether null-principal threads are visible to all, hidden, or
> backfilled once.

---

## 4. Plugins and telemetry — `WorkflowContext.principal_id`

The resolved principal is attached to the `WorkflowContext` passed to plugin
hooks (`on_tool_call`, `on_tool_result`, …), so audit and telemetry can tag
each event with the caller:

```python
def on_tool_call(self, context, tool_name, tool_args):
    logger.info("tool=%s principal=%s", tool_name, context.principal_id)
```

Plugins remain observe-only; this is purely additional data.

---

## Using it without AG-UI

The `principal_resolver` is an AG-UI convenience. The underlying mechanism is
not AG-UI-specific: any app calling the orchestrator directly can put the
identity in `configurable` itself, and tools read it the same way.

```python
config = {"configurable": {"thread_id": thread_id, "principal_id": principal}}
async for event in orchestrator.run(state, config=config):
    ...
```

---

## Scope and boundaries

- **No authentication** — the framework never verifies identity; the resolver
  (your code) does.
- **No authorization** — thread-ownership enforcement is app policy. AgentFlow
  gives you the persisted principal to enforce *against*; it does not enforce.
- **No mandatory identity** — absence behaves exactly as before 0.25.0.
- **Workflows backend only** in 0.25.0. Other backends are unchanged.

## Backward compatibility

Additive and opt-in. With no resolver configured, the produced run config is
byte-identical to 0.24.0 (`{"configurable": {"thread_id": ...}}`) — the
`principal_id` key is only ever added when a truthy value was resolved.
