# AgentFlow CLI

This guide shows you how to use the new AgentFlow CLI and programmatic interface.

> **Cross-backend flags** — `--output ndjson`, `--debug`, `--verbose`, `--ascii`, REPL slash commands, the `agentflow-init` and `agentflow-threads` companion commands, and the JSON event schema are documented in `agentflow/cli/CLI_FLAGS.md` (in the source tree). This page covers workflows-specific behaviour only.

## CLI Usage

AgentFlow CLI (`agentflow`) provides a command-line interface for running workflows defined in YAML files.

### Installation

```bash
pip install agentflow[workflows]
```

### Basic Usage

#### One-shot Query

```bash
# Using default workflow.yaml
agentflow "What is the weather today?"

# Specify custom workflow file
agentflow --yaml my_workflow.yaml "Process this request"
```

#### Interactive Mode

```bash
# Run in interactive mode (continuous query loop)
agentflow --interactive

# With custom workflow file
agentflow --yaml workflow.yaml --interactive
```

#### With Thread ID (Conversation Continuity)

```bash
# Use a specific thread ID to continue a conversation
agentflow --thread-id abc123 "Continue our previous discussion"
```

### Command-Line Options

- `query` (optional): User query to process. If not provided, you will be prompted.
- `--yaml YAML_PATH`: Path to workflow YAML file (default: `workflow.yaml`)
- `--tools TOOLS_MODULE`: Python module containing tool definitions (default: auto-detect 'tools')
- `--no-persistence`: Disable state persistence (run in stateless mode)
- `--checkpointer-path PATH`: Path to SQLite database for checkpoints (default: `.agentflow/checkpoints.db`)
- `--thread-id THREAD_ID`: Thread ID for conversation continuity (default: generate new UUID)
- `--recursion-limit RECURSION_LIMIT`: Maximum number of agent steps (default: 100)
- `--interactive`: Run in interactive mode (continuous query loop)

**Note**:

- Workflow definition (business logic) comes from YAML file
- Deployment settings (tools, persistence) are specified via CLI flags or auto-detected
- Tools module is optional - only required if your workflow agents use tools

### Examples

```bash
# Run with defaults (auto-detect tools from 'tools' directory or file)
agentflow "Analyze this data"

# Custom workflow
agentflow --yaml workflows/data_analysis.yaml "Process the sales report"

# Specify custom tools module
agentflow --tools my_tools "Process this request"

# Disable persistence (stateless mode)
agentflow --no-persistence "Quick query"

# Custom checkpoint database path
agentflow --checkpointer-path /path/to/db.sqlite "Analyze data"

# Interactive mode
agentflow --interactive

# With specific thread ID
agentflow --thread-id session-123 "What was the result from earlier?"

# Higher recursion limit for complex workflows
agentflow --recursion-limit 200 "Perform deep analysis"

# All options together
agentflow \
  --yaml workflow.yaml \
  --tools my_tools \
  --checkpointer-path .agentflow/checkpoints.db \
  --thread-id session-123 \
  "Complex query"
```

## Programmatic Usage

The `agentflow_cli` module provides a simple API for running workflows.

### Basic Example

```python
import asyncio

from agentflow.workflows.agentflow_cli import run_workflow
from dotenv import load_dotenv

load_dotenv()


def main():
    while True:
        query = input("QUERY> ")
        asyncio.run(
            run_workflow(
                query,  # User query to process
                config_path='workflow.yaml',  # Path to workflow YAML configuration (workflow definition)
                tools_module='tools',  # Python module containing tool definitions
                enable_persistence=True,  # Enable/disable state persistence
                checkpointer_path='.agentflow/checkpoints.db',  # Path to SQLite database
                thread_id=None,  # Optional thread ID for conversation continuity
                recursion_limit=None,  # Maximum number of agent steps
            )
        )


if __name__ == "__main__":
    main()
```

For run_workflow to work, your project should have:

1. **workflow.yaml**: The YAML file defining your workflow, tools, persistence, and LLM configuration

Example structure:

```
my_project/
├── workflow.yaml      # Contains all configuration (tools_module, persistence, LLM)
├── tools/             # Referenced in workflow.yaml as tools_module: "tools"
│   ├── __init__.py
│   ├── data_tools.py
│   └── api_tools.py
└── main.py
```

Or with a single tools file:

```
my_project/
├── workflow.yaml      # Contains all configuration (tools_module: "tools")
├── tools.py           # Tools module
└── main.py
```

## Error Handling

```python
import asyncio

from agentflow.workflows.agentflow_cli import run_workflow
from dotenv import load_dotenv

load_dotenv()


def main():
    while True:
        query = input("QUERY> ")
        try:
            asyncio.run(
                run_workflow(
                    query,  # User query to process
                    config_path='workflow.yaml',  # Path to workflow YAML configuration
                    tools_module='tools', # Module path for tools
                    thread_id=None,  # Optional thread ID for conversation continuity
                    recursion_limit=None,  # Maximum number of agent steps
                )
            )
        except FileNotFoundError as e:
            print(f"Configuration error: {e}")
        except Exception as e:
            print(f"Workflow error: {e}")


if __name__ == "__main__":
    main()
```

## CLI Output Features

The CLI uses the Rich library for professional output formatting:

- **Colored and formatted output**: Agents, tools, and status messages are visually distinct
- **Tables for structured data**: Tool outputs with multiple fields are displayed as tables
- **Status indicators**: Success/error states are clearly marked with ✓/✗ symbols
- **Progress tracking**: Shows when agents are generating responses
- **Human-in-the-loop prompts**: Clear prompts for required human input
- **Panel formatting**: Important messages are highlighted in bordered panels

## Tips

1. **Auto-detection**: If you don't specify `yaml_path` or `tools_module_path`, the CLI will automatically look for
   `workflow.yaml` and `tools` folder/file in the current directory.

2. **Thread IDs**: Use thread IDs to maintain conversation context across multiple runs.

3. **Interactive Mode**: Use `--interactive` flag for the CLI to keep running and accept multiple queries.

4. **State Persistence**: State is automatically persisted to SQLite, allowing you to resume interrupted workflows.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
