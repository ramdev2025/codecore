# Production Features

This page is a single reference for all production-ready features in AgentFlow. Everything is configurable via
`workflow.yaml` — no custom code required.

## Feature Summary

### Orchestration & Resilience

| Feature                                           | Scope        | YAML Location                        | What It Does                                             | Docs                         |
|---------------------------------------------------|--------------|--------------------------------------|----------------------------------------------------------|------------------------------|
| Multi-LLM Providers                               | Per node     | `llm.provider`                       | OpenAI, Anthropic, Azure OpenAI, and any LangChain model | [YAML Ref](WORKFLOW_YAML.md) |
| Conditional Routing                               | Per workflow | `workflows.*.nodes.*.routes`         | Dynamic workflow paths based on agent decisions          | [YAML Ref](WORKFLOW_YAML.md) |
| [Retry Policy](#retry-policy)                     | Per node     | `nodes.*.retry_policy`               | Retries failed nodes with exponential backoff            | —                            |
| [Rate Limiting](#rate-limiting)                   | Per LLM      | `llm.rate_limit`                     | Throttles LLM API calls (token bucket)                   | —                            |
| [Declarative Interrupts](#declarative-interrupts) | Per workflow | `workflows.*.interrupt_before/after` | Pauses execution before/after specific nodes             | —                            |
| Model Fallback                                    | Per node     | `nodes.*.middleware`                 | Cascading fallback to alternative LLM models             | [Middleware](MIDDLEWARE.md)  |

### Caching & Performance

| Feature                                   | Scope    | YAML Location          | What It Does                       | Docs |
|-------------------------------------------|----------|------------------------|------------------------------------|------|
| [LLM Response Cache](#llm-response-cache) | Per LLM  | `llm.cache`            | Caches identical LLM call results  | —    |
| [Node Cache Policy](#node-cache-policy)   | Per node | `nodes.*.cache_policy` | Caches entire node output with TTL | —    |

### Persistence & State

| Feature                                                 | Scope     | YAML Location                   | What It Does                                     | Docs                          |
|---------------------------------------------------------|-----------|---------------------------------|--------------------------------------------------|-------------------------------|
| SQLite Persistence                                      | Global    | `persistence.backend: sqlite`   | File-based state checkpointing for development   | [Persistence](PERSISTENCE.md) |
| PostgreSQL Persistence                                  | Global    | `persistence.backend: postgres` | Scalable persistence for production              | [Persistence](PERSISTENCE.md) |
| Long-term Memory                                        | Global    | `persistence.store.enabled`     | Cross-conversation memory (PostgreSQL)           | [Persistence](PERSISTENCE.md) |
| [Checkpoint Encryption](#checkpoint-encryption)         | Global    | `persistence.encryption_key`    | AES encrypts checkpoint data at rest             | —                             |
| [Workflow Version Tracking](#workflow-version-tracking) | Automatic | `metadata.version`              | Tags checkpoints with version, warns on mismatch | —                             |

### Observability & Cost Control

| Feature                                   | Scope  | YAML Location                  | What It Does                                                    | Docs                              |
|-------------------------------------------|--------|--------------------------------|-----------------------------------------------------------------|-----------------------------------|
| Distributed Tracing                       | Global | Env vars                       | OpenTelemetry traces to Datadog, Azure Monitor, Grafana, Jaeger | [Observability](OBSERVABILITY.md) |
| [Structured Logging](#structured-logging) | Global | `callbacks.structured_logging` | JSON log lines with correlation IDs                             | —                                 |
| [Metrics Collection](#metrics-collection) | Global | `callbacks.metrics`            | Counts, durations, and token usage per run                      | —                                 |
| [Cost Tracking](#cost-tracking)           | Global | `callbacks.cost_tracking`      | Token budget enforcement per run                                | —                                 |

### Integrations

| Feature             | Scope    | YAML Location        | What It Does                                | Docs                                  |
|---------------------|----------|----------------------|---------------------------------------------|---------------------------------------|
| MCP Servers         | Global   | `mcp_servers`        | Tools from MCP servers (stdio, SSE, HTTP)   | [MCP](MCP.md)                         |
| External A2A Agents | Per node | `nodes.*.endpoint`   | Invoke A2A-compliant cloud agents           | [External Agents](EXTERNAL_AGENTS.md) |
| Human-in-the-Loop   | Per node | `nodes.*.middleware` | Agent-triggered or mandatory approval gates | [HITL](HUMAN_IN_THE_LOOP.md)          |
| Plugin System       | Global   | Code                 | Lifecycle hooks for custom behavior         | [Plugins](PLUGIN_SPECIFICATION.md)    |

### Middleware

| Feature          | Scope    | YAML Location        | What It Does                                  | Docs                        |
|------------------|----------|----------------------|-----------------------------------------------|-----------------------------|
| Model Call Limit | Per node | `nodes.*.middleware` | Cap number of LLM calls per agent             | [Middleware](MIDDLEWARE.md) |
| Tool Call Limit  | Per node | `nodes.*.middleware` | Cap number of tool calls per agent            | [Middleware](MIDDLEWARE.md) |
| Summarization    | Per node | `nodes.*.middleware` | Compress long conversations to manage context | [Middleware](MIDDLEWARE.md) |
| PII Detection    | Per node | `nodes.*.middleware` | Detect and redact sensitive data              | [Middleware](MIDDLEWARE.md) |
| Tool Retry       | Per node | `nodes.*.middleware` | Automatic retry for failed tool calls         | [Middleware](MIDDLEWARE.md) |

---

The sections below document features configured at the top level of `workflow.yaml`. For features with their own
dedicated docs page (linked in the Docs column above), refer to those pages for full details.

---

## Retry Policy

Retries failed node executions with exponential backoff and optional jitter. Applied per node — works for both local
agents and external A2A agents.

```yaml
nodes:
  my_agent:
    description: "Agent with retry"
    system_prompt: "You are a helpful assistant."
    retry_policy:
      max_attempts: 5
      initial_interval: 1.0
      backoff_factor: 2.0
      max_interval: 60.0
      jitter: true
```

| Field              | Type    | Default | Description                                  |
|--------------------|---------|---------|----------------------------------------------|
| `max_attempts`     | `int`   | `3`     | Maximum number of attempts (>= 1)            |
| `initial_interval` | `float` | `0.5`   | Initial retry interval in seconds            |
| `backoff_factor`   | `float` | `2.0`   | Multiplier for exponential backoff           |
| `max_interval`     | `float` | `128.0` | Maximum wait between retries in seconds      |
| `jitter`           | `bool`  | `true`  | Add random jitter to prevent thundering herd |

---

## Rate Limiting

Throttles LLM API calls using a token bucket algorithm. Prevents exceeding provider rate limits. Follows the LLM config
hierarchy (global, orchestrator, workflow, or node level).

```yaml
llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"
  rate_limit:
    requests_per_second: 1.0
    max_bucket_size: 10
```

| Field                   | Type    | Default    | Description                                |
|-------------------------|---------|------------|--------------------------------------------|
| `requests_per_second`   | `float` | *required* | Maximum sustained request rate (> 0)       |
| `check_every_n_seconds` | `float` | `0.1`      | Polling interval for token availability    |
| `max_bucket_size`       | `float` | `10.0`     | Maximum burst size (token bucket capacity) |

> **Note:** Rate limiting fires **after** cache lookup, so cached responses do not consume rate limit tokens.

---

## LLM Response Cache

Caches identical LLM call results in memory. Useful for reducing costs when the same prompts are sent repeatedly (e.g.,
classifier agents, routing decisions).

```yaml
llm:
  provider: openai
  config:
    model: "gpt-4o"
  cache:
    enabled: true
    max_size: 500
```

| Field      | Type   | Default | Description                                                                                   |
|------------|--------|---------|-----------------------------------------------------------------------------------------------|
| `enabled`  | `bool` | `true`  | Enable or disable caching                                                                     |
| `max_size` | `int`  | `None`  | Maximum number of cached responses. `None` = unlimited. Evicts oldest first (FIFO) when full. |

---

## Node Cache Policy

Caches the entire output of a graph node, keyed by input hash. Different from LLM caching — this caches the full node
result (which may include multiple LLM calls and tool invocations).

```yaml
nodes:
  classifier:
    description: "Classify input category"
    system_prompt: "Classify the input into: technical, billing, general."
    cache_policy:
      ttl: 300  # cache for 5 minutes
```

| Field | Type  | Default | Description                                               |
|-------|-------|---------|-----------------------------------------------------------|
| `ttl` | `int` | `None`  | Time-to-live in seconds. `None` = no expiry. Must be > 0. |

> **Tip:** Best suited for deterministic nodes (classifiers, routers) where the same input reliably produces the same
> output.

---

## Checkpoint Encryption

Encrypts checkpoint data at rest using AES encryption. Requires the
`pycryptodome` package. The key is provided via environment variable —
not the YAML — so the same configuration ships across environments
without exposing key material in source.

```bash
pip install pycryptodome

# Generate a key (32 bytes → AES-256)
export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -hex 16)"

# Apply on any persistence backend
agentflow --persistence sqlite --db-path /data/state.db --yaml workflow.yaml "..."
```

The key must be 16, 24, or 32 bytes for AES-128 / AES-192 / AES-256.
Works with both SQLite and PostgreSQL backends. See
[PERSISTENCE.md](PERSISTENCE.md) for the full env-var surface.

---

## Workflow Version Tracking

Automatically tags every checkpoint with the `metadata.version` from your YAML. On resume, if the version has changed
since the checkpoint was saved, a warning is logged.

```yaml
metadata:
  version: "2.1"
  name: "My Workflow"
```

No additional configuration needed — this is always active when `metadata.version` is set.

**Example warning on resume:**

```
WARNING: Workflow version mismatch: checkpoint was saved with v2.0,
current workflow is v2.1. State may be incompatible.
```

---

## Declarative Interrupts

Pauses workflow execution before or after specific nodes. Simpler than middleware-based human-in-the-loop for cases
where you always want to pause at a fixed point. Requires a checkpointer for resume.

```yaml
workflows:
  main:
    interrupt_before: [dangerous_action_agent]
    interrupt_after: [review_agent]
    nodes:
      classifier: {}
      dangerous_action_agent:
        depends_on: [classifier]
      review_agent:
        depends_on: [dangerous_action_agent]
```

| Field              | Type        | Default | Description                              |
|--------------------|-------------|---------|------------------------------------------|
| `interrupt_before` | `list[str]` | `None`  | Node names to pause **before** execution |
| `interrupt_after`  | `list[str]` | `None`  | Node names to pause **after** execution  |

---

## Structured Logging

Emits JSON-structured log lines for every LLM call and tool invocation. Each line includes correlation IDs (
`execution_id`, `workflow_name`, `run_id`) for tracing requests across multi-agent workflows.

```yaml
callbacks:
  structured_logging: true
  redact_prompts: true  # replace prompt content with [REDACTED]
```

| Field                | Type   | Default | Description                         |
|----------------------|--------|---------|-------------------------------------|
| `structured_logging` | `bool` | `false` | Enable JSON-structured logging      |
| `redact_prompts`     | `bool` | `false` | Redact prompt content in log output |

**Example log output:**

```json
{"event": "llm_start", "execution_id": "user-123", "workflow": "support", "run_id": "abc-456", "model": "gpt-4o", "message_count": 3}
{"event": "llm_end", "execution_id": "user-123", "workflow": "support", "run_id": "abc-456", "duration_s": 1.234, "input_tokens": 150, "output_tokens": 42, "total_tokens": 192}
{"event": "tool_start", "execution_id": "user-123", "workflow": "support", "run_id": "def-789", "tool": "search_web"}
{"event": "tool_end", "execution_id": "user-123", "workflow": "support", "run_id": "def-789", "duration_s": 0.567}
```

Logs are emitted to the `agentflow.structured` Python logger. Configure your logging framework to route them to your
preferred destination (stdout, file, ELK, Datadog, etc.).

---

## Metrics Collection

Accumulates runtime metrics (counts, durations, token usage) during a workflow run. Retrieved programmatically after the
run completes.

```yaml
callbacks:
  metrics: true
```

| Field     | Type   | Default | Description               |
|-----------|--------|---------|---------------------------|
| `metrics` | `bool` | `false` | Enable metrics collection |

**Accessing metrics after a run:**

```python
async for event in orchestrator.run(state, config):
    ...

metrics = orchestrator.get_last_metrics()
print(metrics)
# {
#   "execution_id": "user-123",
#   "llm_calls": 4,
#   "llm_errors": 0,
#   "llm_total_duration_s": 3.456,
#   "tool_calls": 2,
#   "tool_errors": 0,
#   "tool_total_duration_s": 1.234,
#   "input_tokens": 520,
#   "output_tokens": 180,
#   "total_tokens": 700,
# }
```

---

## Cost Tracking

Tracks token usage across all LLM calls in a run and enforces an optional budget cap. When the cap is exceeded, the next
LLM call raises `BudgetExceededError` and stops the workflow.

```yaml
callbacks:
  cost_tracking: 500000  # max total tokens per run
```

| Field           | Type  | Default | Description                                |
|-----------------|-------|---------|--------------------------------------------|
| `cost_tracking` | `int` | `None`  | Maximum total tokens per run. Must be > 0. |

**Accessing usage after a run:**

```python
usage = orchestrator.get_last_cost()
print(usage)
# {
#   "llm_calls": 4,
#   "input_tokens": 520,
#   "output_tokens": 180,
#   "total_tokens": 700,
#   "budget": 500000,
#   "remaining": 499300,
# }
```

**Handling budget exceeded:**

```python
from agentflow.workflows.core.callbacks import BudgetExceededError

try:
    async for event in orchestrator.run(state, config):
        ...
except BudgetExceededError as e:
    print(f"Budget exceeded: {e}")
```

---

## Complete Example

A workflow using multiple production features together:

```yaml
metadata:
  version: "1.0"
  name: "Production Workflow"

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"
  rate_limit:
    requests_per_second: 2.0
    max_bucket_size: 10
  cache:
    enabled: true
    max_size: 200

orchestrator:
  workflows: [main]

callbacks:
  structured_logging: true
  redact_prompts: false
  metrics: true
  cost_tracking: 1000000

# Persistence is configured at deploy time, not in YAML:
#   export AGENTFLOW_PERSISTENCE=sqlite        # or postgres / memory
#   export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -hex 16)"
# (or pass --persistence sqlite, etc., on the CLI)

workflows:
  main:
    description: "Customer support workflow"
    interrupt_before: [escalation_agent]
    nodes:
      classifier: {}
      support_agent:
        depends_on: [classifier]
      escalation_agent:
        depends_on: [support_agent]

nodes:
  classifier:
    description: "Classify customer intent"
    system_prompt: "Classify the customer request."
    cache_policy:
      ttl: 300
    retry_policy:
      max_attempts: 3

  support_agent:
    description: "Handle support requests"
    system_prompt: "You are a customer support agent."
    tools: [search_kb, create_ticket]
    retry_policy:
      max_attempts: 2
      initial_interval: 1.0

  escalation_agent:
    description: "Handle escalations"
    system_prompt: "You handle escalated cases."
```

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
