# AgentFlow Plugin Specification

This document defines the standardized structure for AgentFlow plugins distributed as zip files.

## Plugin Package Structure

A valid AgentFlow plugin package must follow this structure:

```
plugin-name.zip
└── plugin-name/
    ├── pyproject.toml          # Required: Plugin metadata
    ├── README.md               # Optional but recommended
    ├── LICENSE                 # Optional but recommended
    ├── requirements.txt        # Optional: Additional dependencies
    └── agentflow_plugins/      # Required: Plugin package
        ├── __init__.py         # Required: Package initializer
        └── plugin_name.py      # Required: Plugin implementation
```

### Example: Metrics Plugin

```
plugin-metrics.zip
└── plugin-metrics/
    ├── pyproject.toml
    ├── README.md
    └── agentflow_plugins/
        ├── __init__.py
        └── metrics.py
```

## Required Files

### 1. `pyproject.toml`

Must contain the following minimum structure:

```toml
[project]
name = "plugin-metrics"
version = "1.0.0"
description = "Workflow execution metrics tracking plugin for AgentFlow"
authors = [
    { name = "Your Name", email = "your.email@example.com" }
]
requires-python = ">=3.10"

[project.optional-dependencies]
# Optional: Additional dependencies your plugin needs
# These will be installed when the plugin is installed

[tool.agentflow.plugin]
# Required: Plugin metadata for AgentFlow
entry_point = "agentflow_plugins.metrics:MetricsPlugin"
type = "telemetry"  # workflow, telemetry, logging, validation, etc.

# Optional: Configuration schema
[tool.agentflow.plugin.config]
show_summary = { type = "boolean", default = true, description = "Display metrics summary after each workflow" }
track_timing = { type = "boolean", default = false, description = "Track execution timing for workflows and agents" }
```

#### Required Fields:

- `project.name` - Plugin package name (must start with `plugin-`)
- `project.version` - Semantic version (e.g., "1.0.0")
- `project.description` - Brief description of what the plugin does
- `project.authors` - List of authors with name and email
- `tool.agentflow.plugin.entry_point` - Path to plugin class (format: `module:ClassName`)
- `tool.agentflow.plugin.type` - Plugin category

#### Optional Fields:

- `project.requires-python` - Python version requirement
- `project.dependencies` - Runtime dependencies
- `tool.agentflow.plugin.config` - Configuration schema for validation
- `project.urls` - Links to documentation, repository, etc.

### 2. `agentflow_plugins/__init__.py`

Must expose the plugin class:

```python
"""
Plugin package initialization.
"""
from .metrics import MetricsPlugin

__all__ = ['MetricsPlugin']
__version__ = '1.0.0'
```

### 3. `agentflow_plugins/plugin_name.py`

Must contain a class that inherits from `agentflow.plugins.Plugin`:

```python
from agentflow.plugins import Plugin, WorkflowContext
from typing import Any, Dict


class MetricsPlugin(Plugin):
    """
    Track workflow execution metrics.

    This plugin demonstrates a practical metrics tracking implementation.
    """

    def __init__(self, show_summary: bool = True):
        """
        Initialize the plugin.

        Args:
            show_summary: Whether to display metrics summary
        """
        self.show_summary = show_summary
        self.total_workflows = 0
        self.total_agents = 0
        self.total_tools = 0

    @property
    def name(self) -> str:
        return "MetricsPlugin"

    def on_workflow_start(
            self,
            context: WorkflowContext,
            initial_state: Dict[str, Any]
    ) -> None:
        """Called when workflow starts."""
        self.total_workflows += 1
        if self.show_summary:
            print(f"📊 Metrics: Workflow #{self.total_workflows} started")

    def on_agent_start(
            self,
            context: WorkflowContext,
            agent_name: str,
            state: Dict[str, Any]
    ) -> None:
        """Called when an agent starts."""
        self.total_agents += 1

    def on_tool_call(
            self,
            context: WorkflowContext,
            tool_name: str,
            inputs: Dict[str, Any]
    ) -> None:
        """Called when a tool is invoked."""
        self.total_tools += 1

    def on_workflow_end(
            self,
            context: WorkflowContext,
            final_state: Dict[str, Any],
            status: str = "completed"
    ) -> None:
        """Called when workflow ends."""
        if self.show_summary:
            print(
                f"📊 Session Metrics: "
                f"Workflows: {self.total_workflows} | "
                f"Agents: {self.total_agents} | "
                f"Tools: {self.total_tools}"
            )
```

## Optional Files

### `README.md`

Should include:

- Plugin description
- Installation instructions
- Configuration options
- Usage examples
- License information

```markdown
# Hello Plugin

A simple demonstration plugin for AgentFlow.

## Installation

```bash
agentflow-plugins install plugin-hello.zip
```

## Configuration

- `greeting` (str): Custom greeting message (default: "Hello")

## Usage

The plugin will print a greeting message when any workflow starts.

```

### `requirements.txt`

Additional dependencies beyond AgentFlow:

```

requests>=2.31.0
pyyaml>=6.0.0

```

### `LICENSE`

Plugin license (e.g., MIT, Apache 2.0, proprietary)

## Plugin Types

Specify the plugin type in `pyproject.toml` under `tool.agentflow.plugin.type`:

- `workflow` - General workflow lifecycle hooks
- `telemetry` - Monitoring and metrics collection
- `logging` - Logging and audit trails
- `validation` - Input/output validation
- `testing` - Testing and quality assurance
- `security` - Security and compliance
- `custom` - Custom functionality

## Validation Rules

A plugin package will be rejected if:

1. Missing required files (`pyproject.toml`, `agentflow_plugins/__init__.py`)
2. Invalid `pyproject.toml` format or missing required fields
3. Entry point doesn't point to a valid Plugin subclass
4. Package name doesn't match directory structure
5. Plugin class doesn't inherit from `agentflow.plugins.Plugin`
6. Python version requirement conflicts with AgentFlow's requirements

## Installation Modes

AgentFlow supports two installation modes:

| Mode | Command | Location | Use Case |
|------|---------|----------|----------|
| **Local** | `agentflow-plugins install --local plugin.zip` | Current venv's site-packages | Project-specific plugins |
| **Global** | `agentflow-plugins install plugin.zip` | `~/.agentflow/plugins` | Shared across all projects |

### Local Installation (Recommended)

Installs to the current virtual environment using standard pip:

```bash
agentflow-plugins install --local plugin-metrics.zip
```

**Advantages:**

- No PYTHONPATH configuration needed
- Project-specific plugin versions
- Works with standard Python tooling (pip, venv)
- Plugins discovered via Python entry points

### Global Installation

Installs to `~/.agentflow/plugins` (shared location):

```bash
agentflow-plugins install plugin-metrics.zip
```

**Note:** Requires setting PYTHONPATH:

```bash
export PYTHONPATH=~/.agentflow/plugins:$PYTHONPATH
```

## Installation Process

When installing a plugin package:

1. **Extract** - Unzip to temporary directory
2. **Validate** - Check structure and `pyproject.toml`
3. **Install Dependencies** - Install any requirements
4. **Copy** - Move to target location (venv site-packages or `~/.agentflow/plugins/`)
5. **Register** - Add to plugin registry via entry points
6. **Verify** - Load and instantiate plugin class

## Best Practices

### Naming Conventions

- **Package name**: `plugin-<descriptive-name>` (lowercase, hyphen-separated)
- **Module name**: `<descriptive_name>` (lowercase, underscore-separated)
- **Class name**: `<DescriptiveName>Plugin` (PascalCase with "Plugin" suffix)

Examples:

- Package: `plugin-slack-notifications`
- Module: `slack_notifications.py`
- Class: `SlackNotificationsPlugin`

### Version Management

Use semantic versioning (MAJOR.MINOR.PATCH):

- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

### Security Considerations

1. **Validate inputs** - Always validate user-provided configuration
2. **Handle secrets** - Use environment variables, never hardcode credentials
3. **Limit permissions** - Request minimum necessary permissions
4. **Error handling** - Wrap operations in try/except to prevent crashes
5. **Dependencies** - Keep dependencies minimal and up-to-date

### Testing Your Plugin

Before distribution, test your plugin:

```python
# test_plugin.py
import pytest
from agentflow.plugins import WorkflowContext
from agentflow_plugins.hello import HelloPlugin


def test_plugin_initialization():
    plugin = HelloPlugin(greeting="Hi")
    assert plugin.name == "HelloPlugin"
    assert plugin.greeting == "Hi"


def test_workflow_start():
    plugin = HelloPlugin()
    context = WorkflowContext(
        execution_id="test-123",
        workflow_name="test_workflow"
    )
    # Should not raise an exception
    plugin.on_workflow_start(context, {})
```

## Example: Complete Plugin Package

Here's a complete example of a notification plugin:

### Directory Structure

```
plugin-notifications.zip
└── plugin-notifications/
    ├── pyproject.toml
    ├── README.md
    ├── LICENSE
    ├── requirements.txt
    └── agentflow_plugins/
        ├── __init__.py
        ├── notifications.py
        └── config.py
```

### `pyproject.toml`

```toml
[project]
name = "plugin-notifications"
version = "1.0.0"
description = "Send notifications when workflows complete"
authors = [
    { name = "Jumpstarter COE Team" }
]
requires-python = ">=3.10"
dependencies = [
    "requests>=2.31.0",
]

[project.urls]
Repository = "https://github.com/accenture/agentflow-plugin-notifications"
Documentation = "https://github.com/accenture/agentflow-plugin-notifications#readme"

[tool.agentflow.plugin]
entry_point = "agentflow_plugins.notifications:NotificationsPlugin"
type = "workflow"

[tool.agentflow.plugin.config]
webhook_url = { type = "string", required = true, description = "Webhook URL for notifications" }
notify_on_error = { type = "boolean", default = true, description = "Send notification on workflow errors" }
notify_on_complete = { type = "boolean", default = false, description = "Send notification on successful completion" }
```

### `agentflow_plugins/__init__.py`

```python
"""Notifications plugin for AgentFlow."""
from .notifications import NotificationsPlugin

__all__ = ['NotificationsPlugin']
__version__ = '1.0.0'
```

### `agentflow_plugins/notifications.py`

```python
"""Notification plugin implementation."""
import os
import requests
from typing import Any, Dict
from agentflow.plugins import Plugin, WorkflowContext


class NotificationsPlugin(Plugin):
    """
    Send notifications via webhook when workflows complete or fail.

    Configuration:
        webhook_url: Webhook URL for sending notifications
        notify_on_error: Send notification on workflow errors (default: True)
        notify_on_complete: Send notification on completion (default: False)
    """

    def __init__(
            self,
            webhook_url: str = None,
            notify_on_error: bool = True,
            notify_on_complete: bool = False
    ):
        self.webhook_url = webhook_url or os.getenv("NOTIFICATION_WEBHOOK_URL")
        self.notify_on_error = notify_on_error
        self.notify_on_complete = notify_on_complete

        if not self.webhook_url:
            raise ValueError("webhook_url must be provided or NOTIFICATION_WEBHOOK_URL must be set")

    @property
    def name(self) -> str:
        return "NotificationsPlugin"

    def on_workflow_end(
            self,
            context: WorkflowContext,
            final_state: Dict[str, Any],
            status: str = "completed"
    ) -> None:
        """Send notification when workflow ends."""
        should_notify = (
                (status == "error" and self.notify_on_error) or
                (status == "completed" and self.notify_on_complete)
        )

        if should_notify:
            self._send_notification(
                workflow_name=context.workflow_name,
                execution_id=context.execution_id,
                status=status
            )

    def on_error(
            self,
            context: WorkflowContext,
            error: Exception,
            error_context: Dict[str, Any]
    ) -> None:
        """Send notification on errors."""
        if self.notify_on_error:
            self._send_notification(
                workflow_name=context.workflow_name,
                execution_id=context.execution_id,
                status="error",
                error_message=str(error)
            )

    def _send_notification(self, **kwargs):
        """Send webhook notification."""
        try:
            response = requests.post(
                self.webhook_url,
                json=kwargs,
                timeout=5
            )
            response.raise_for_status()
        except Exception as e:
            print(f"Failed to send notification: {e}")
```

### `requirements.txt`

```
requests>=2.31.0
```

## CLI Commands

### Install Plugin

```bash
# Local installation (recommended) - installs to current venv
agentflow-plugins install --local plugin-metrics.zip

# Global installation - installs to ~/.agentflow/plugins
agentflow-plugins install plugin-metrics.zip

# Force reinstall
agentflow-plugins install --local --force plugin-metrics.zip
```

### Validate Plugin (without installing)

```bash
agentflow-plugins validate plugin-metrics.zip
```

### List Installed Plugins

```bash
agentflow-plugins list
```

Output shows installation location:

```
┏━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━┓
┃ Plugin          ┃ Distribution           ┃ Version ┃ Location ┃
┡━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━┩
│ metrics         │ plugin-metrics         │ 0.1.0   │ venv     │
│ regression_test │ plugin-regression-test │ 0.1.0   │ global   │
└─────────────────┴────────────────────────┴─────────┴──────────┘
```

### Show Plugin Info

```bash
agentflow-plugins info metrics
```

### Uninstall Plugin

```bash
# Uninstall local plugin (from venv)
agentflow-plugins uninstall --local metrics

# Uninstall global plugin
agentflow-plugins uninstall metrics
```

### Export PYTHONPATH (for global plugins)

```bash
agentflow-plugins export
# Output: export PYTHONPATH=~/.agentflow/plugins:$PYTHONPATH
```

## Validation Output

When validating a plugin, you'll see:

```
✓ Package structure valid
✓ pyproject.toml valid
✓ Entry point found: agentflow_plugins.metrics:MetricsPlugin
✓ Plugin class inherits from Plugin
✓ Required methods present
✓ Dependencies resolvable
⚠ Missing LICENSE (recommended)

Plugin validation passed!
```

## Available Lifecycle Hooks

You only need to implement the hooks you care about. All hooks are optional.

### Core Hooks

| Hook                | When Called             | Common Use Cases                   |
|---------------------|-------------------------|------------------------------------|
| `on_workflow_start` | Workflow begins         | Initialize resources, start timers |
| `on_workflow_end`   | Workflow completes      | Cleanup, metrics reporting         |
| `on_agent_start`    | Agent starts processing | Track agent invocations            |
| `on_agent_end`      | Agent completes         | Log agent results                  |
| `on_tool_call`      | Tool is invoked         | Log tool usage, validate inputs    |
| `on_tool_result`    | Tool returns result     | Cache responses, validate outputs  |
| `on_llm_start`      | LLM call begins         | Track prompts, measure latency     |
| `on_llm_end`        | LLM call completes      | Calculate costs, log responses     |
| `on_error`          | Error occurs            | Log errors, send alerts            |

### MCP Hooks

| Hook                 | When Called             | Common Use Cases                 |
|----------------------|-------------------------|----------------------------------|
| `on_mcp_connect`     | MCP server connects     | Log server discovery, tool count |
| `on_mcp_tool_call`   | MCP tool is invoked     | Track MCP-specific tool usage    |
| `on_mcp_tool_result` | MCP tool returns result | Log results, track errors        |

### Human-in-the-Loop Hooks

| Hook            | When Called             | Common Use Cases                 |
|-----------------|-------------------------|----------------------------------|
| `on_hitl_start` | Waiting for human input | Track wait time, log prompts     |
| `on_hitl_end`   | Human input received    | Log responses, measure wait time |

### External Agent (A2A) Hooks

| Hook                      | When Called              | Common Use Cases                   |
|---------------------------|--------------------------|------------------------------------|
| `on_external_agent_start` | A2A agent call begins    | Track external calls, log messages |
| `on_external_agent_end`   | A2A agent call completes | Log responses, track errors        |

### Checkpoint Hooks

| Hook                 | When Called          | Common Use Cases                 |
|----------------------|----------------------|----------------------------------|
| `on_checkpoint_save` | Checkpoint is saved  | Track persistence, measure size  |
| `on_checkpoint_load` | Checkpoint is loaded | Track recovery, log success/fail |

### Hook Signatures

All hooks receive a `WorkflowContext` object containing execution metadata:

```python
@dataclass
class WorkflowContext:
    execution_id: str  # Unique execution identifier
    workflow_name: str  # Name of the workflow
    metadata: Dict = None  # Optional additional metadata
```

Example hook implementations:

```python
def on_workflow_start(
        self,
        context: WorkflowContext,
        initial_state: Dict[str, Any]
) -> None:
    """
    Called when workflow execution starts.

    Args:
        context: Workflow context with execution metadata
        initial_state: Initial workflow state including messages
    """
    pass


def on_agent_start(
        self,
        context: WorkflowContext,
        agent_name: str,
        state: Dict[str, Any]
) -> None:
    """
    Called when an agent starts processing.

    Args:
        context: Workflow context
        agent_name: Name of the agent being invoked
        state: Current workflow state
    """
    pass


def on_tool_call(
        self,
        context: WorkflowContext,
        tool_name: str,
        inputs: Dict[str, Any]
) -> None:
    """
    Called when a tool is invoked by an agent.

    Args:
        context: Workflow context
        tool_name: Name of the tool
        inputs: Arguments passed to the tool
    """
    pass


def on_tool_result(
        self,
        context: WorkflowContext,
        tool_name: str,
        result: Any
) -> None:
    """
    Called when a tool returns a result.

    Args:
        context: Workflow context
        tool_name: Name of the tool
        result: Result returned by the tool
    """
    pass


def on_mcp_tool_call(
        self,
        context: WorkflowContext,
        server_name: str,
        tool_name: str,
        arguments: Dict[str, Any]
) -> None:
    """
    Called when an MCP tool is invoked.

    Args:
        context: Workflow context
        server_name: Name of the MCP server
        tool_name: Name of the tool
        arguments: Arguments passed to the tool
    """
    pass


def on_hitl_start(
        self,
        context: WorkflowContext,
        interrupt_type: str,
        prompt: str
) -> None:
    """
    Called when waiting for human input begins.

    Args:
        context: Workflow context
        interrupt_type: Type of interrupt (e.g., "approval", "input")
        prompt: The prompt shown to the human
    """
    pass


def on_external_agent_start(
        self,
        context: WorkflowContext,
        agent_name: str,
        endpoint: str,
        message: str
) -> None:
    """
    Called when an external A2A agent call begins.

    Args:
        context: Workflow context
        agent_name: Name of the external agent
        endpoint: The agent's endpoint URL
        message: Message being sent to the agent
    """
    pass
```

## Support and Questions

For questions about plugin development:

- Contact the **Accenture AI & Data, Global Agentic COE** Team.

## Quick Start

For a quick start guide, see the [Plugin Template](PLUGIN_TEMPLATE.md).

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
