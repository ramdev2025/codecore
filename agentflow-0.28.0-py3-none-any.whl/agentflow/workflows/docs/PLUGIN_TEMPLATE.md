# AgentFlow Plugin Quick Start

Quick reference for creating AgentFlow plugins.

**For complete documentation, see [PLUGIN_SPECIFICATION.md](PLUGIN_SPECIFICATION.md)**

## Quick Start Template

### 1. Copy an Example

Start with a working example:

```bash
# Create a new plugin directory
mkdir my-plugin/
cd my-plugin/
```

### 2. Update Metadata

Edit `pyproject.toml`:

```toml
[project]
name = "plugin-myname"              # Change this
version = "1.0.0"
description = "My custom plugin"    # Change this
authors = [{name = "Your Name"}]    # Change this

[tool.agentflow.plugin]
entry_point = "agentflow_plugins.myname:MyNamePlugin"  # Update
type = "telemetry"  # or workflow, logging, validation, etc.
```

### 3. Update Code

Edit `agentflow_plugins/myname.py`:

```python
from agentflow.plugins import Plugin, WorkflowContext
from typing import Any, Dict


class MyNamePlugin(Plugin):
    """Your plugin description."""

    def __init__(self, config_param: str = "default"):
        """Initialize your plugin."""
        self.config_param = config_param

    @property
    def name(self) -> str:
        return "MyNamePlugin"

    # Implement the hooks you need (all optional):

    def on_workflow_start(
            self,
            context: WorkflowContext,
            initial_state: Dict[str, Any]
    ) -> None:
        """Called when workflow starts."""
        print(f"Workflow {context.workflow_name} started!")

    def on_workflow_end(
            self,
            context: WorkflowContext,
            final_state: Dict[str, Any],
            status: str = "completed"
    ) -> None:
        """Called when workflow ends."""
        print(f"Workflow completed with status: {status}")

    def on_agent_start(
            self,
            context: WorkflowContext,
            agent_name: str,
            state: Dict[str, Any]
    ) -> None:
        """Called when an agent starts."""
        pass

    def on_tool_call(
            self,
            context: WorkflowContext,
            tool_name: str,
            inputs: Dict[str, Any]
    ) -> None:
        """Called when a tool is invoked."""
        pass

    def on_error(
            self,
            context: WorkflowContext,
            error: Exception,
            error_context: Dict[str, Any]
    ) -> None:
        """Called when an error occurs."""
        print(f"Error: {error}")
```

### 4. Update Package Init

Edit `agentflow_plugins/__init__.py`:

```python
from .myname import MyNamePlugin

__all__ = ['MyNamePlugin']
__version__ = '1.0.0'
```

### 5. Package and Install

```bash
cd ..
zip -r plugin-myname.zip plugin-myname/

# Validate
agentflow-plugins validate plugin-myname.zip

# Install locally (recommended) - to current venv
agentflow-plugins install --local plugin-myname.zip

# Or install globally - to ~/.agentflow/plugins
agentflow-plugins install plugin-myname.zip
```

## Available Lifecycle Hooks

| Hook                | When Called             | Common Use Cases                   |
|---------------------|-------------------------|------------------------------------|
| `on_workflow_start` | Workflow begins         | Initialize resources, start timers |
| `on_workflow_end`   | Workflow completes      | Cleanup, metrics reporting         |
| `on_agent_start`    | Agent starts processing | Track agent invocations            |
| `on_agent_end`      | Agent completes         | Log agent results                  |
| `on_tool_call`      | Tool is invoked         | Log tool usage, validate inputs    |
| `on_tool_result`    | Tool returns result     | Cache responses, validate outputs  |
| `on_llm_start`      | LLM call begins         | Track prompts, measure latency     |
| `on_llm_end`        | LLM call completes      | Calculate costs, log responses     |
| `on_error`          | Error occurs            | Log errors, send alerts            |

**All hooks are optional** - only implement what you need!

## Plugin Structure

Required structure:

```
plugin-name.zip
└── plugin-name/
    ├── pyproject.toml          # Required: Metadata
    └── agentflow_plugins/      # Required: Code
        ├── __init__.py
        └── plugin_name.py
```

Recommended additions:

```
plugin-name/
├── pyproject.toml
├── README.md                   # Documentation
├── LICENSE                     # License file
├── requirements.txt            # Dependencies
└── agentflow_plugins/
    ├── __init__.py
    └── plugin_name.py
```

## Common Patterns

### Simple Logging

```python
class LoggingPlugin(Plugin):
    def on_workflow_start(self, context, initial_state):
        print(f"📝 Workflow {context.workflow_name} started")

    def on_tool_call(self, context, tool_name, inputs):
        print(f"🔧 Tool called: {tool_name}")
```

### Metrics Tracking

```python
class MetricsPlugin(Plugin):
    def __init__(self):
        self.total_workflows = 0
        self.total_tools = 0

    def on_workflow_start(self, context, initial_state):
        self.total_workflows += 1

    def on_tool_call(self, context, tool_name, inputs):
        self.total_tools += 1

    def on_workflow_end(self, context, final_state, status):
        print(f"📊 Workflows: {self.total_workflows}, Tools: {self.total_tools}")
```

### Error Handling

```python
class ErrorHandlerPlugin(Plugin):
    def on_error(self, context, error, error_context):
        # Log to file
        with open("errors.log", "a") as f:
            f.write(f"{context.workflow_name}: {error}\n")

        # Send notification
        send_alert(f"Error in {context.workflow_name}")
```

## Configuration

Define configuration in `pyproject.toml`:

```toml
[tool.agentflow.plugin.config]
api_key = {type = "string", required = true, description = "API key"}
timeout = {type = "integer", default = 30, description = "Timeout in seconds"}
enabled = {type = "boolean", default = true, description = "Enable plugin"}
```

Use in your plugin:

```python
class MyPlugin(Plugin):
    def __init__(self, api_key: str, timeout: int = 30, enabled: bool = True):
        self.api_key = api_key
        self.timeout = timeout
        self.enabled = enabled
```

## Best Practices

1. **Keep it lightweight** - Plugins run inline with workflows
2. **Handle errors gracefully** - Wrap operations in try/except
3. **Make it configurable** - Accept parameters in `__init__`
4. **Document your plugin** - Add clear docstrings
5. **Test before distributing** - Validate and test thoroughly

## Complete Documentation

For complete specification including:

- Detailed requirements
- Validation rules
- All hook signatures
- Security considerations
- Testing guidelines
- Example plugins

See **[PLUGIN_SPECIFICATION.md](PLUGIN_SPECIFICATION.md)**

## CLI Commands

```bash
# Validate plugin package
agentflow-plugins validate plugin-name.zip

# Install plugin locally (recommended)
agentflow-plugins install --local plugin-name.zip

# Install plugin globally
agentflow-plugins install plugin-name.zip

# List installed plugins (shows location: venv or global)
agentflow-plugins list

# Show plugin info
agentflow-plugins info plugin-name

# Uninstall local plugin
agentflow-plugins uninstall --local plugin-name

# Uninstall global plugin
agentflow-plugins uninstall plugin-name

# Export PYTHONPATH for global plugins
agentflow-plugins export
```

## Reference

- Check [PLUGIN_SPECIFICATION.md](PLUGIN_SPECIFICATION.md) for complete docs

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
