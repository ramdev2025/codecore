# Human-in-the-Loop (HITL) Guide

## Overview

The AgentFlow workflow supports **agent-triggered** human intervention. An agent can dynamically request human approval
or input when it encounters situations requiring human judgment, clarification, or decision-making.

**HITL works by enabling custom tools** that use LangGraph's `interrupt()` function to pause workflow execution and wait
for human input. When an agent calls these tools, the workflow pauses, saves its state, and waits for a human response
before continuing.

## Implementation Setup

### Step 1: Create the HITL Tools

Create a file `tools/human_approval.py` with the following implementation:

```python
"""
Human-in-the-loop tools for requesting human approval during workflow execution.
"""
from typing import Literal
from langchain_core.tools import tool
from langgraph.types import interrupt


@tool
def request_human_approval(
    question: str,
    context: str,
    action_type: Literal["execute_plan", "modify_database", "final_decision", "other"] = "other",
    proposed_action: str = ""
) -> str:
    """
    Request human approval before proceeding with a critical action.

    Use this tool when you need human confirmation before:
    - Executing a proposed plan
    - Modifying a database
    - Making a final decision
    - Any action that requires human oversight

    Args:
        question: The question to ask the human (e.g., "Should I proceed with this action?")
        context: Background information for the human to make an informed decision
        action_type: Type of action requiring approval
        proposed_action: Description of what you plan to do if approved

    Returns:
        Human's response (approval, rejection, or modified instructions)

    Example:
        request_human_approval(
            question="Should I approve this action?",
            context="Details about the current situation...",
            action_type="final_decision",
            proposed_action="Proceed with approval"
        )
    """
    # Create the approval request payload
    approval_request = {
        "type": "human_approval_required",
        "question": question,
        "context": context,
        "action_type": action_type,
        "proposed_action": proposed_action,
    }

    # Use LangGraph's interrupt to pause execution
    # The value passed to interrupt() will be returned when the workflow resumes
    human_response = interrupt(approval_request)

    return human_response


@tool
def request_human_input(
    prompt: str,
    input_type: Literal["text", "choice", "number"] = "text",
    choices: list[str] = None
) -> str:
    """
    Request freeform input from a human during workflow execution.

    Use this when you need human to provide information, not just approve/reject.

    Args:
        prompt: What to ask the human
        input_type: Type of input expected (text, choice, or number)
        choices: If input_type is "choice", provide the available options

    Returns:
        Human's input

    Example:
        request_human_input(
            prompt="What priority level should be assigned?",
            input_type="choice",
            choices=["Low", "Medium", "High"]
        )
    """
    input_request = {
        "type": "human_input_required",
        "prompt": prompt,
        "input_type": input_type,
        "choices": choices or [],
    }

    human_input = interrupt(input_request)

    return human_input
```

### Key Components:

1. **LangGraph's `interrupt()` function**: This is the core mechanism that pauses workflow execution
2. **Structured payload**: The data passed to `interrupt()` contains all information needed by the frontend
3. **LangChain's `@tool` decorator**: Makes these functions available as tools for the agent
4. **Type hints**: Provides clear parameter types for better developer experience

### Step 2: Register Tools in Your Workflow

In your `workflow.yaml`, add the HITL tools to your agent's tool list:

```yaml
nodes:
  Your Agent:
    tools:
      - "request_human_approval"
      - "request_human_input"
      # ... other tools
    system_prompt: |
      You are an intelligent agent that can request human approval when needed.

      **When to Request Human Approval:**
      - Edge cases requiring human judgment
      - High-risk or high-impact actions
      - Situations where automated decision confidence is low (<80%)
      - When business rules don't provide clear guidance
      - Significant compliance or regulatory implications
      - Actions that are difficult or impossible to reverse

      **Guidelines:**
      - Provide clear, concise questions
      - Include all relevant context
      - Explain your proposed action
      - Be specific about what approval you need
```

---

## How It Works

Now that you understand the tools, here's how the HITL flow works in practice:

### 1. **Agent Requests Approval**

When the agent encounters a situation requiring human oversight, it calls one of the HITL tools:

```python
response = request_human_approval(
    question="Should I proceed with this action?",
    context="Relevant information about the current situation and data analyzed.",
    action_type="final_decision",
    proposed_action="The specific action I plan to take if approved"
)
```

### 2. **Workflow Pauses**

Inside the tool, the `interrupt()` function is called:

- Execution pauses immediately
- Current workflow state is saved to checkpoint database
- The approval request payload is sent to the interrupt system
- WebSocket sends `interrupt` event to frontend with the request data

### 3. **Human Reviews & Responds**

The frontend receives the interrupt event and displays:

- **Question**: The agent's specific question
- **Context**: Full background information
- **Proposed Action**: What the agent plans to do
- **Input field**: For the human's response

Human provides a response:

- "Approved" / "Rejected" / "Approved with modifications"
- Or custom instructions/guidance

### 4. **Workflow Resumes**

- Human response is submitted via: `POST /api/workflow/{thread_id}/respond`
- Frontend reconnects via: `WebSocket /ws/workflow/resume/{thread_id}`
- The `interrupt()` function returns the human's response
- Agent receives the response as the tool's return value
- Agent continues processing with the human's decision

**Example of agent handling the response:**

```python
response = request_human_approval(
    question="Should I approve this action?",
    context="...",
    action_type="final_decision",
    proposed_action="Proceed with approval"
)

# Agent processes the human's response
if "approved" in response.lower():
    proceed_with_action()
elif "rejected" in response.lower():
    cancel_action()
else:
    # Handle custom instructions from human
    handle_custom_response(response)
```

---

## Architecture & Components

### System Overview

This HITL implementation assumes you have a **full-stack application** with the following components:

```
┌─────────────┐           ┌──────────────────┐           ┌─────────────┐
│   Frontend  │ ◄───────► │   Backend API    │ ◄───────► │  LangGraph  │
│   (React/   │  HTTPWS   │   (FastAPI/      │           │  Workflow   │
│    Vue/etc) │           │    Flask/etc)    │           │  Engine     │
└─────────────┘           └──────────────────┘           └─────────────┘
                                    │
                                    ▼
                             ┌─────────────┐
                             │  Checkpoint │
                             │   Database  │
                             └─────────────┘
```

### Component Responsibilities

#### 1. **LangGraph Workflow (Provided)**

- Executes agent workflow with tools
- Calls `interrupt()` when HITL tools are invoked
- Saves state to checkpoint database
- Resumes execution when response is provided

#### 2. **HITL Tools (You Implement)**

- `request_human_approval` and `request_human_input` functions
- Located in `tools/human_approval.py`
- Use LangGraph's `interrupt()` function

#### 3. **Backend API (You Implement)**

- Endpoints to check interrupt state
- Endpoints to submit human responses
- WebSocket endpoint for real-time updates
- Manages workflow lifecycle

#### 4. **Frontend UI (You Implement)**

- Displays approval dialogs when workflow interrupts
- Captures human responses
- Communicates with backend via HTTP/WebSocket

### What You Need to Build

The HITL tools (Step 1 in Implementation Setup) provide the mechanism to pause workflows. However, you need to build:

1. **Backend API endpoints** to:
    - Check if a workflow is interrupted
    - Accept human responses
    - Resume workflow execution
    - Stream updates via WebSocket

2. **Frontend components** to:
    - Listen for interrupt events
    - Display approval dialogs
    - Submit responses to the backend

The following sections show example implementations of these components.

---

## Backend API Implementation

You need to implement the following endpoints in your backend (FastAPI example shown below, but any framework works):

### Endpoint 1: Check if Workflow is Interrupted

**Purpose**: Check if a workflow is paused and waiting for human input.

**Implementation** (in your backend API):

```http
GET /api/workflow/{thread_id}/state
```

**Example response:**

```json
{
  "state": {...},
  "is_interrupted": true,
  "interrupt_data": [{
    "type": "human_approval_required",
    "question": "Should I proceed with this action?",
    "context": "...",
    "action_type": "final_decision",
    "proposed_action": "..."
  }]
}
```

**Backend implementation example (FastAPI):**

```python
from fastapi import FastAPI, Depends
from agentflow.core.orchestrator import AsyncWorkflowOrchestrator

app = FastAPI()


# Create orchestrator per-request (don't use global instance for multi-user apps)
async def get_orchestrator() -> AsyncWorkflowOrchestrator:
    """
    Dependency that creates/reuses orchestrator instance.

    For production multi-user apps, you should:
    1. Use a connection pool or singleton pattern with proper locking
    2. Or create orchestrator per-request with shared checkpointer
    """

    # Use async context manager to ensure proper cleanup
    async with AsyncWorkflowOrchestrator(
            config_path="workflow.yaml",
            tools_module="tools",
            enable_persistence=True,
            checkpointer_path=".agentflow/checkpoints.db"
    ) as orchestrator:
        yield orchestrator


@app.get("/api/workflow/{thread_id}/state")
async def get_workflow_state(
        thread_id: str,
        workflow_name: str = None,
        orchestrator: AsyncWorkflowOrchestrator = Depends(get_orchestrator)
):
    """Get current state of a workflow execution."""
    state = await orchestrator.get_state(thread_id)

    # Check if workflow is interrupted (has pending tasks with interrupts)
    is_interrupted = False
    interrupt_data = []

    for task in state.get("tasks", []):
        if task.interrupts:
            is_interrupted = True
            # Extract interrupt data from first interrupt in task
            interrupt_data.append(task.interrupts[0])

    return {
        "state": state["values"],
        "is_interrupted": is_interrupted,
        "interrupt_data": interrupt_data,
        "next": state.get("next"),
        "metadata": state.get("metadata")
    }
```

### Endpoint 2: Submit Human Response

**Purpose**: Submit the human's response to resume the workflow.

**Implementation** (in your backend API):

```http
POST /api/workflow/{thread_id}/respond
Content-Type: application/json

{
  "response": "Approved - proceed as proposed"
}
```

**Backend implementation example (FastAPI):**

```python
from pydantic import BaseModel


class HumanResponse(BaseModel):
    response: str


@app.post("/api/workflow/{thread_id}/respond")
async def submit_response(
        thread_id: str,
        body: HumanResponse,
        workflow_name: str = None,
        orchestrator: AsyncWorkflowOrchestrator = Depends(get_orchestrator)
):
    """
    Submit human response to resume an interrupted workflow.

    The response will be passed back to the interrupt() function
    in the HITL tool, which returns it to the agent.
    """
    # Update workflow state with human's response
    # This updates the Command result that interrupt() returns
    await orchestrator.update_state(
        thread_id=thread_id,
        updated_values={"__interrupt__": ({"value": body.response},)},
    )

    return {"status": "success", "message": "Response submitted"}
```

### Endpoint 3: WebSocket for Resuming Workflow

**Purpose**: Stream workflow updates after human responds.

**Implementation** (in your backend API):

```python
from fastapi import WebSocket, WebSocketDisconnect


@app.websocket("/ws/workflow/resume/{thread_id}")
async def resume_workflow(websocket: WebSocket, thread_id: str, workflow_name: str = None):
    """
    Resume workflow execution and stream events back to client.

    After human submits a response, connect to this WebSocket to continue
    the workflow and receive real-time updates.
    """
    await websocket.accept()

    try:
        # Create orchestrator for this connection
        async with AsyncWorkflowOrchestrator(
                config_path="workflow.yaml",
                tools_module="tools",
                enable_persistence=True,
                checkpointer_path=".agentflow/checkpoints.db"
        ) as orchestrator:
            # Get current state
            state = await orchestrator.get_state(thread_id)

            # Resume workflow execution
            config = {"configurable": {"thread_id": thread_id}}

            async for event in orchestrator.run(
                    state=state["values"],
                    config=config,
                    stream_tokens=False
            ):
                # Stream event to frontend
                await websocket.send_json(event)

                # Check if workflow interrupted again
                current_state = await orchestrator.get_state(thread_id)
                has_interrupts = any(
                    task.interrupts for task in current_state.get("tasks", [])
                )

                if has_interrupts:
                    # Extract interrupt data
                    interrupt_data = []
                    for task in current_state["tasks"]:
                        if task.interrupts:
                            interrupt_data.extend(task.interrupts)

                    await websocket.send_json({
                        "type": "interrupt",
                        "interrupt_data": interrupt_data
                    })
                    break

            # Workflow completed without interrupts
            if not has_interrupts:
                await websocket.send_json({
                    "type": "complete",
                    "final_state": state["values"]
                })

    except WebSocketDisconnect:
        print(f"Client disconnected from workflow {thread_id}")
    except Exception as e:
        await websocket.send_json({
            "type": "error",
            "message": str(e)
        })
    finally:
        await websocket.close()
```

**Important Notes:**

1. **Thread ID**: Each workflow execution must have a unique `thread_id` to track state
2. **Checkpointer**: The SQLite checkpointer persists state across all user sessions
3. **Per-Request Orchestrator**: Creating orchestrator per-request ensures thread-safety
4. **Alternative Pattern**: For high-traffic apps, consider using a singleton with connection pooling

### Multi-User Considerations

**Why not use a global orchestrator instance?**

When your application is deployed to a container and handles multiple concurrent users, you **cannot** use a simple
global orchestrator instance like this:

```python
# ❌ DON'T DO THIS - Won't work properly for multiple users
orchestrator = AsyncWorkflowOrchestrator(...)  # Global instance


@app.get("/api/workflow/{thread_id}/state")
async def get_state(thread_id: str):
    return await orchestrator.get_state(thread_id)  # Race conditions!
```

**Why it doesn't work:**

- Multiple requests access the same orchestrator concurrently
- No guarantee of thread-safety for concurrent operations
- State can get mixed between different user sessions

**Recommended Approaches:**

**Option 1: Dependency Injection (Shown Above)**

```python
# ✅ Create orchestrator per-request with shared checkpointer
async def get_orchestrator():
    async with AsyncWorkflowOrchestrator(...) as orch:
        yield orch


@app.get("/api/workflow/{thread_id}/state")
async def get_state(
        thread_id: str,
        orch: AsyncWorkflowOrchestrator = Depends(get_orchestrator)
):
    return await orch.get_state(thread_id)
```

**Option 2: Application Lifespan with Proper Cleanup**

```python
# Create orchestrator at startup, cleanup at shutdown
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    orch = await AsyncWorkflowOrchestrator.create(...)
    app.state.orchestrator = orch
    yield
    # Shutdown
    await orch.cleanup()


app = FastAPI(lifespan=lifespan)


@app.get("/api/workflow/{thread_id}/state")
async def get_state(thread_id: str, request: Request):
    # Each request uses same orchestrator but different thread_id
    # The checkpointer handles concurrency
    return await request.app.state.orchestrator.get_state(thread_id)
```

**Key Points:**

- The **checkpointer (SQLite database)** handles state isolation between thread_ids
- Each workflow execution is identified by a unique `thread_id`
- The orchestrator can be shared if properly managed, but per-request is simpler
- For production, consider connection pooling and proper resource management

---

## Frontend Implementation

You need to implement UI components that interact with the backend API to handle interrupts.

### Example: React Component

**Location**: In your frontend application (e.g., `src/components/WorkflowApproval.jsx`)

```javascript
import { useState, useEffect } from 'react';

function WorkflowApproval({ threadId }) {
  const [isInterrupted, setIsInterrupted] = useState(false);
  const [interruptData, setInterruptData] = useState(null);
  const [response, setResponse] = useState('');

  // Check for interrupts
  useEffect(() => {
    const checkInterrupt = async () => {
      const res = await fetch(`/api/workflow/${threadId}/state`);
      const data = await res.json();

      if (data.is_interrupted) {
        setIsInterrupted(true);
        setInterruptData(data.interrupt_data[0]);
      }
    };

    checkInterrupt();
  }, [threadId]);

  // Submit response and resume
  const handleSubmit = async () => {
    // Submit response
    await fetch(`/api/workflow/${threadId}/respond`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ response })
    });

    // Connect to WebSocket to resume
    const ws = new WebSocket(`ws://localhost:8000/ws/workflow/resume/${threadId}`);

    ws.onmessage = (event) => {
      const result = JSON.parse(event.data);

      if (result.type === 'interrupt') {
        // Workflow paused again (agent requested more input)
        setInterruptData(result.interrupt_data[0]);
      } else if (result.type === 'complete') {
        // Workflow completed
        setIsInterrupted(false);
        setInterruptData(null);
      }
    };
  };

  if (!isInterrupted) return null;

  return (
    <div className="approval-dialog">
      <h3>{interruptData?.question}</h3>
      <p><strong>Context:</strong> {interruptData?.context}</p>
      <p><strong>Proposed Action:</strong> {interruptData?.proposed_action}</p>

      <textarea
        value={response}
        onChange={(e) => setResponse(e.target.value)}
        placeholder="Enter your response..."
      />

      <button onClick={handleSubmit}>Submit Response</button>
    </div>
  );
}
```

### Example: Vanilla JavaScript

**Location**: In your frontend HTML/JavaScript files

```javascript
// In your frontend JavaScript file (e.g., app.js)

async function checkForInterrupt(threadId) {
  const response = await fetch(`/api/workflow/${threadId}/state`);
  const data = await response.json();

  if (data.is_interrupted) {
    showApprovalDialog(data.interrupt_data[0]);
  }
}

function showApprovalDialog(interruptData) {
  // Show modal/dialog with interrupt data
  const dialog = document.getElementById('approval-dialog');
  dialog.querySelector('.question').textContent = interruptData.question;
  dialog.querySelector('.context').textContent = interruptData.context;
  dialog.querySelector('.proposed-action').textContent = interruptData.proposed_action;
  dialog.style.display = 'block';
}

async function submitResponse(threadId, response) {
  // Submit response
  await fetch(`/api/workflow/${threadId}/respond`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ response })
  });

  // Connect WebSocket to resume workflow
  const ws = new WebSocket(`ws://localhost:8000/ws/workflow/resume/${threadId}`);

  ws.onmessage = (event) => {
    const result = JSON.parse(event.data);

    if (result.type === 'interrupt') {
      // Another approval needed
      showApprovalDialog(result.interrupt_data[0]);
    } else if (result.type === 'complete') {
      // Workflow done
      hideApprovalDialog();
    }
  };
}
```

---

## Tools Reference

The following tools are implemented in `tools/human_approval.py` (see Implementation Setup section above for complete
code).

### `request_human_approval`

Request approval for critical decisions or actions.

**When to use:**

- Before making final decisions on edge cases or ambiguous situations
- When confidence in automated decision is low (<80%)
- For high-risk or high-impact actions
- When business rules don't clearly cover the scenario
- When compliance or regulatory approval is needed

**Parameters:**

- `question` (str): Clear question to ask human
- `context` (str): Background information and relevant data
- `action_type` (str): "execute_plan", "modify_database", "final_decision", "other"
- `proposed_action` (str): What you plan to do if approved

**Returns:** Human's response text

### `request_human_input`

Request freeform input or specific data from human.

**When to use:**

- Need additional information not available in tools
- Need human to choose between multiple valid options
- Need human to provide missing or unclear data
- Require human expertise or domain knowledge

**Parameters:**

- `prompt` (str): What to ask
- `input_type` (str): "text", "choice", or "number"
- `choices` (list): Available options (if input_type="choice")

**Returns:** Human's input

---

## Example Scenarios

### Scenario 1: Edge Case Requiring Judgment

**Agent encounters:**

- Situation that doesn't match standard patterns
- Data is valid but unusual
- Automated rules don't provide clear guidance

**Agent decision:**

```python
response = request_human_approval(
    question="Should I proceed with this action given the unusual circumstances?",
    context="""
    Current Situation:
    - Data point A: Valid ✓
    - Data point B: Pending verification
    - Data point C: Within normal range ✓
    - Anomaly: Pattern doesn't match typical scenarios
    - Risk indicators: Mixed signals

    Confidence level: 75%
    """,
    action_type="final_decision",
    proposed_action="Proceed with conditional approval pending verification of data point B"
)

# Agent continues based on human response
if "approved" in response.lower():
    proceed_with_action()
elif "rejected" in response.lower():
    cancel_action()
else:
    # Use human's specific instructions
    execute_custom_action(response)
```

### Scenario 2: High-Impact Decision

**Agent encounters a high-stakes decision:**

```python
response = request_human_approval(
    question="This action has significant impact - should I proceed?",
    context="""
    Impact Analysis:
    - Affects: 150 records
    - Financial impact: $50,000
    - Risk level: Medium-High
    - Reversibility: Partially reversible

    Validation checks:
    - Rule compliance: 95% match
    - Historical precedent: Limited
    - Stakeholder approval: Pending
    """,
    action_type="execute_plan",
    proposed_action="Execute batch update with rollback capability enabled"
)
```

### Scenario 3: Missing Information

**Agent needs clarification:**

```python
priority = request_human_input(
    prompt="Unable to determine priority level from available data. What priority should be assigned?",
    input_type="choice",
    choices=["Low", "Medium", "High", "Critical"]
)

# Or for open-ended input:
additional_info = request_human_input(
    prompt="Please provide additional context about this situation that may not be in the system:",
    input_type="text"
)
```

### Scenario 4: Choosing Between Valid Options

**Agent has multiple valid approaches:**

```python
approach = request_human_input(
    prompt="Two valid approaches detected. Which should I use?",
    input_type="choice",
    choices=[
        "Approach A: Faster but less thorough",
        "Approach B: Slower but more comprehensive",
        "Hybrid: Combine both approaches"
    ]
)
```

---

## Workflow YAML Configuration

### Basic Configuration

Add HITL tools to your agent configuration in `workflow.yaml`:

```yaml
nodes:
  Your Agent:
    description: "Agent with human-in-the-loop capabilities"
    tools:
      - "request_human_approval"
      - "request_human_input"
      # ... other tools
    system_prompt: |
      You are an intelligent agent that can request human approval when needed.

      **When to Request Human Approval:**
      - Edge cases requiring human judgment
      - High-risk or high-impact actions
      - Situations where automated decision confidence is low (<80%)
      - When business rules don't provide clear guidance
      - Significant compliance or regulatory implications
      - Actions that are difficult or impossible to reverse

      **Guidelines:**
      - Provide clear, concise questions
      - Include all relevant context
      - Explain your proposed action
      - Be specific about what approval you need
```

**Important:** The tool names in the YAML must match the function names in `tools/human_approval.py`.

### Complete Example with HITL

Here's a complete workflow configuration that uses human-in-the-loop:

```yaml
metadata:
  version: "1.0"
  name: "Customer Support with HITL"
  description: "Support workflow with human approval for escalations"

llm:
  provider: openai
  config:
    model: "gpt-4o"
    temperature: 0.7

orchestrator:
  workflows:
    - Customer Support

workflows:
  Customer Support:
    description: "Handle customer inquiries with human oversight"
    nodes:
      Triage Agent:
        depends_on: []

      Resolution Agent:
        depends_on: [Triage Agent]
        routes:
          router_field: requires_approval
          true: Approval Agent
          false: END
          default: END

      Approval Agent:
        depends_on: [Resolution Agent]

nodes:
  Triage Agent:
    description: "Analyzes customer inquiry"
    system_prompt: |
      You are a customer support triage agent.
      Analyze the customer's inquiry and classify it by severity and type.
    tools:
      - analyze_inquiry
      - check_customer_history

  Resolution Agent:
    description: "Provides solutions with HITL for high-risk cases"
    system_prompt: |
      You are a customer support resolution agent.

      For standard cases, provide the solution directly.

      For high-risk or complex cases, use request_human_approval to get human oversight.

      **When to request human approval:**
      - Financial impact > $1000
      - Account modifications
      - Policy exceptions
      - Unusual or unprecedented situations
      - Customer is VIP or high-value

      **How to use the tool:**
      - Provide clear question
      - Include all relevant context
      - Explain your proposed solution
      - Wait for human response before proceeding
    tools:
      - request_human_approval
      - request_human_input
      - apply_solution
      - update_ticket

  Approval Agent:
    description: "Handles post-approval actions"
    system_prompt: |
      Execute actions after receiving human approval.
      Log all approvals for audit purposes.
    tools:
      - execute_approved_action
      - log_approval
```

### Workflow Patterns with HITL

#### Pattern 1: Conditional HITL with Routing

Use conditional routing to request approval only when needed:

```yaml
workflows:
  Risk Assessment:
    description: "Assess risk and seek approval for high-risk cases"
    nodes:
      Assessment Agent:
        depends_on: []
        routes:
          router_field: risk_level
          high: Approval Required
          medium: Review Agent
          low: END

      Approval Required:
        depends_on: [Assessment Agent]

      Review Agent:
        depends_on: [Assessment Agent]

nodes:
  Assessment Agent:
    description: "Analyzes risk level"
    tools:
      - assess_risk
      - calculate_confidence
    system_prompt: |
      Analyze the situation and determine risk level.
      Return risk_level as "high", "medium", or "low" in your tool output.

  Approval Required:
    description: "Requests human approval for high-risk cases"
    tools:
      - request_human_approval
      - log_decision
    system_prompt: |
      This case requires human approval due to high risk.
      Use request_human_approval to get human oversight before proceeding.
```

#### Pattern 2: Sequential HITL Checkpoints

Multiple approval checkpoints in a workflow:

```yaml
workflows:
  Multi-Stage Approval:
    description: "Multiple human approval stages"
    nodes:
      Initial Review:
        depends_on: []

      First Approval:
        depends_on: [Initial Review]

      Processing:
        depends_on: [First Approval]

      Final Approval:
        depends_on: [Processing]

nodes:
  Initial Review:
    description: "Initial analysis"
    tools:
      - analyze_request
      - gather_data

  First Approval:
    description: "First approval checkpoint"
    tools:
      - request_human_approval
    system_prompt: |
      Request approval for the proposed plan before processing.

  Processing:
    description: "Execute approved plan"
    tools:
      - execute_plan
      - monitor_progress

  Final Approval:
    description: "Final approval before completion"
    tools:
      - request_human_approval
      - finalize_action
    system_prompt: |
      Request final approval to confirm successful completion.
```

#### Pattern 3: Fallback to HITL

Use HITL as a fallback when automation fails:

```yaml
nodes:
  Smart Agent:
    description: "Attempts automation with HITL fallback"
    tools:
      - automated_process
      - request_human_input
      - request_human_approval
    system_prompt: |
      Try to handle the request automatically.

      If you encounter any of these situations, request human help:
      - Ambiguous or incomplete data
      - Confidence < 80%
      - Error in automated processing
      - Data validation failures
      - Unexpected edge cases

      Use request_human_input for missing information.
      Use request_human_approval for ambiguous decisions.
```

### Tool Configuration Reference

The HITL tools (`request_human_approval` and `request_human_input`) must be:

1. **Implemented** in your tools module (e.g., `tools/human_approval.py`)
2. **Listed** in the `tools` array of nodes that need HITL capability
3. **Documented** in the system prompt with usage guidelines

Example tools module structure:

```
tools/
├── __init__.py
├── human_approval.py      # HITL tools
├── data_tools.py          # Business logic tools
└── api_tools.py           # External API tools
```

In `tools/__init__.py`, export the HITL tools:

```python
from .human_approval import request_human_approval, request_human_input
from .data_tools import analyze_data, validate_input
from .api_tools import call_external_api

__all__ = [
    'request_human_approval',
    'request_human_input',
    'analyze_data',
    'validate_input',
    'call_external_api',
]
```

### System Prompt Best Practices

When configuring system prompts for HITL-enabled agents:

**DO:**

```yaml
system_prompt: |
  **When to request human approval:**
  - Specific condition 1 (e.g., value > $1000)
  - Specific condition 2 (e.g., confidence < 80%)
  - Specific condition 3 (e.g., policy exception needed)

  **How to use request_human_approval:**
  - question: Be specific and clear
  - context: Include all relevant data
  - proposed_action: Explain what you'll do if approved

  **Example:**
  request_human_approval(
      question="Should I approve this $5000 transaction?",
      context="Customer: John Doe, History: 3 years, Credit: Good",
      proposed_action="Process payment and ship order"
  )
```

**DON'T:**

```yaml
# ❌ Too vague
system_prompt: |
  Request approval when needed.

# ❌ No guidelines
system_prompt: |
  You have access to request_human_approval tool.
```

### Advanced: LLM Configuration for HITL Nodes

You can configure different LLMs for different stages:

```yaml
nodes:
  Fast Triage:
    description: "Quick initial triage"
    llm:
      provider: openai
      config:
        model: "gpt-4o-mini"  # Fast, cheaper model
        temperature: 0.3
    tools:
      - classify_inquiry

  Deep Analysis with HITL:
    description: "Thorough analysis with human oversight"
    llm:
      provider: anthropic
      config:
        model: "claude-sonnet-4.5"  # More capable model
        temperature: 0.7
        max_tokens: 4096
    tools:
      - request_human_approval
      - deep_analysis
      - complex_reasoning
```

### See Also

- **[Workflow YAML Reference](WORKFLOW_YAML.md)** - Complete workflow.yaml documentation
- **[Getting Started](AGENTFLOW.md)** - AgentFlow basics
- **[State Persistence](PERSISTENCE.md)** - How state is saved during HITL pauses

---

## Implementation Checklist

> **Note:** See the [Backend API Implementation](#backend-api-implementation)
> and [Frontend Implementation](#frontend-implementation) sections above for complete code examples.

### Backend Tasks:

- [ ] Implement `GET /api/workflow/{thread_id}/state` endpoint
- [ ] Implement `POST /api/workflow/{thread_id}/respond` endpoint
- [ ] Implement WebSocket endpoint `/ws/workflow/resume/{thread_id}`
- [ ] Set up workflow manager to interact with LangGraph
- [ ] Configure checkpoint database for state persistence

### Frontend Tasks:

- [ ] Listen for `interrupt` events in WebSocket
- [ ] Show approval dialog when interrupt received
- [ ] Display question, context, and proposed action clearly
- [ ] Provide appropriate input field for human response
- [ ] Submit response via `POST /api/workflow/{thread_id}/respond`
- [ ] Reconnect via `WebSocket /ws/workflow/resume/{thread_id}`
- [ ] Handle multiple interrupts (agent can request approval multiple times)
- [ ] Show "Workflow Paused - Awaiting Your Input" status indicator
- [ ] Allow viewing conversation history during pause
- [ ] Display timestamp of when workflow was paused

### Optional Enhancements:

- [ ] Add timeout warnings for long pauses
- [ ] Support for attaching files or additional context with response
- [ ] Email/Slack notifications when approval is needed
- [ ] Admin dashboard to view pending approvals
- [ ] Approval history and audit trail

---

## Testing

### Test 1: Trigger Approval Request

Create a scenario that requires human approval:

```bash
curl -X POST http://localhost:8000/api/workflow \
  -H "Content-Type: application/json" \
  -d '{"query": "Your test query that should trigger HITL"}'
```

### Test 2: Check Interrupt State

```bash
curl http://localhost:8000/api/workflow/{thread_id}/state
```

Expected response should show `is_interrupted: true` with interrupt data.

### Test 3: Submit Response

```bash
curl -X POST http://localhost:8000/api/workflow/{thread_id}/respond \
  -H "Content-Type: application/json" \
  -d '{"response": "Approved - proceed as proposed"}'
```

### Test 4: Resume Workflow

Connect to WebSocket and verify workflow continues from where it paused.

### Test 5: Multiple Interrupts

Test a workflow that requires multiple human approvals to ensure state management works correctly.

---

## Best Practices

### For Agent Developers

1. **Be Specific**: Ask clear, specific questions rather than vague requests
2. **Provide Context**: Include all relevant information for decision-making
3. **Explain Impact**: Clearly state what will happen if approved/rejected
4. **Set Thresholds**: Define confidence thresholds that trigger human review
5. **Handle Responses Gracefully**: Parse human responses flexibly (they may not follow exact format)

### For System Designers

1. **Audit Trail**: Log all HITL interactions for compliance and debugging
2. **Timeouts**: Consider implementing timeout policies for paused workflows
3. **Notifications**: Alert humans when their input is needed
4. **Context Preservation**: Save sufficient state to resume intelligently
5. **Escalation**: Define escalation paths if human doesn't respond

### For Frontend Developers

1. **Clear UI**: Make interrupt dialogs prominent and easy to understand
2. **Rich Context**: Display all relevant information without overwhelming user
3. **Quick Actions**: Provide common response shortcuts (Approve/Reject buttons)
4. **Custom Input**: Always allow freeform text for nuanced responses
5. **History**: Show what happened before and after HITL intervention

---

## Common Patterns

### Pattern 1: Confidence Threshold

```python
confidence = calculate_confidence(data)

if confidence < 0.80:
    response = request_human_approval(
        question=f"Confidence is {confidence:.0%}. Should I proceed?",
        context=f"Analysis details: {analysis_summary}",
        action_type="final_decision",
        proposed_action="Proceed with action"
    )
```

### Pattern 2: Risk-Based Escalation

```python
risk_score = assess_risk(situation)

if risk_score > RISK_THRESHOLD:
    response = request_human_approval(
        question=f"High risk detected (score: {risk_score}). Approve action?",
        context=risk_analysis,
        action_type="execute_plan",
        proposed_action=proposed_action
    )
```

### Pattern 3: Exception Handling

```python
try:
    result = automated_process()
except AmbiguousDataException as e:
    clarification = request_human_input(
        prompt=f"Ambiguous data detected: {e}. Please clarify.",
        input_type="text"
    )
    result = automated_process(clarification)
```

---

## Summary

**To Enable Agent-Triggered HITL in Your Workflow:**

### Setup Checklist:

**Backend:**

- [ ] Create `tools/human_approval.py` with the tool implementations (see Implementation Setup section)
- [ ] Import and register the tools in your workflow runner
- [ ] Add tools to your agent's configuration in `workflow.yaml`
- [ ] Update agent's system prompt with guidelines on when to use HITL
- [ ] Ensure your orchestrator supports LangGraph's `interrupt()` function
- [ ] Implement API endpoints for checking interrupt state and submitting responses
- [ ] Add WebSocket endpoint for resuming workflows

**Frontend:**

- [ ] Listen for `interrupt` events in WebSocket
- [ ] Create approval dialog UI component
- [ ] Display question, context, and proposed action
- [ ] Implement response submission via API
- [ ] Handle workflow resumption after human response
- [ ] Show "Workflow Paused" status indicator
- [ ] Support multiple sequential interrupts

**Testing:**

- [ ] Test with various scenarios (edge cases, high-risk actions)
- [ ] Verify state persistence across interrupts
- [ ] Test multiple interrupts in single workflow
- [ ] Validate audit trail logging
- [ ] Test timeout behavior (if implemented)

**Optional Enhancements:**

- [ ] Add notification system for pending approvals
- [ ] Implement timeout and escalation policies
- [ ] Add support for file attachments in responses
- [ ] Create admin dashboard for reviewing HITL history
- [ ] Add analytics on HITL usage patterns

### Key Points:

✅ **HITL works through custom tools** that use LangGraph's `interrupt()` function  
✅ **Agent autonomously decides** when to request human input  
✅ **Workflow state is preserved** during pauses  
✅ **No code changes needed** in agent logic after setup

The agent will autonomously decide when human input is needed!

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
