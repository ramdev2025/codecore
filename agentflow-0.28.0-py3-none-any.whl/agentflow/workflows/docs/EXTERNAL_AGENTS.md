# External Agents (A2A Integration)

AgentFlow supports invoking external agents via the [Agent2Agent (A2A) Protocol](https://a2a-protocol.org/), an open
standard for agent-to-agent communication maintained by the Linux Foundation.

> **Note**: AgentFlow acts as an **A2A client only**. It can invoke external A2A-compliant agents, but does not expose
> AgentFlow agents as A2A servers.

## Overview

External agents allow your AgentFlow workflows to delegate tasks to agents running on other platforms:

- **AWS Bedrock Agents**
- **Azure AI Agents**
- **Google Vertex AI Agents**
- **Salesforce Einstein**
- **ServiceNow**
- **Any A2A-compliant agent**

## Quick Start

External agents are configured purely in YAML. The presence of an `endpoint` field indicates an external agent:

```yaml
nodes:
  # Local agent (standard AgentFlow agent)
  triage_agent:
    description: "Routes customer queries to specialists"
    system_prompt: "You classify queries and route them..."
    tools:
      - classify_query

  # External A2A agent (no system_prompt or tools needed)
  crm_agent:
    description: "Handles CRM operations via Salesforce"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
```

That's it! AgentFlow automatically:

1. Detects the external agent by the `endpoint` field
2. Creates a direct A2A client using the official SDK
3. Invokes the external agent without any wrapper overhead

## Authentication

AgentFlow supports all A2A protocol authentication schemes:

### No Authentication (Public Agents)

```yaml
nodes:
  weather_agent:
    description: "Public weather service"
    endpoint: "https://weather.example.com/a2a"
```

### Bearer Token

The most common authentication method for cloud services:

```yaml
nodes:
  salesforce_agent:
    description: "Salesforce CRM agent"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
```

### API Key

For services using custom API key headers:

```yaml
nodes:
  internal_agent:
    description: "Internal service agent"
    endpoint: "https://internal.corp.com/a2a"
    auth:
      type: api_key
      token: "${INTERNAL_API_KEY}"
      header_name: "X-Internal-API-Key"  # Optional, defaults to X-API-Key
```

### Basic Authentication

```yaml
nodes:
  legacy_agent:
    description: "Legacy system agent"
    endpoint: "https://legacy.corp.com/a2a"
    auth:
      type: basic
      username: "service_account"
      password: "${LEGACY_PASSWORD}"
```

### OAuth2 Client Credentials

For enterprise services using OAuth2:

```yaml
nodes:
  azure_agent:
    description: "Azure AI agent"
    endpoint: "https://azure-agents.microsoft.com/a2a"
    auth:
      type: oauth2_client_credentials
      oauth2:
        token_url: "https://login.microsoftonline.com/${TENANT_ID}/oauth2/v2.0/token"
        client_id: "${AZURE_CLIENT_ID}"
        client_secret: "${AZURE_CLIENT_SECRET}"
        scopes:
          - "https://cognitiveservices.azure.com/.default"
```

### Mutual TLS (mTLS)

For high-security enterprise environments:

```yaml
nodes:
  banking_agent:
    description: "Banking compliance agent"
    endpoint: "https://secure.bank.com/a2a"
    auth:
      type: mtls
      mtls:
        cert_path: "/etc/certs/client.pem"
        key_path: "/etc/certs/client-key.pem"
        ca_path: "/etc/certs/bank-ca.pem"  # Optional
```

## Timeout and Retry Configuration

External agent calls support configurable timeouts and automatic retries with exponential backoff.

### Global Defaults

Set default timeout and retry behavior for all external agents:

```yaml
external_agents:
  timeout: 30.0  # seconds
  retry:
    max_attempts: 3
    backoff: 1.0           # initial delay in seconds
    max_backoff: 30.0      # maximum delay in seconds
```

### Per-Agent Overrides

Override global defaults for specific agents:

```yaml
nodes:
  # Uses global defaults
  fast_agent:
    description: "Quick response agent"
    endpoint: "https://fast.example.com/a2a"
    auth:
      type: bearer
      token: "${FAST_TOKEN}"

  # Custom timeout for slow agent
  slow_agent:
    description: "Complex processing agent"
    endpoint: "https://slow.example.com/a2a"
    timeout: 120.0  # 2 minutes
    retry:
      max_attempts: 5
      backoff: 2.0
    auth:
      type: bearer
      token: "${SLOW_TOKEN}"
```

### Configuration Reference

| Setting              | Location                          | Default         | Description            |
|----------------------|-----------------------------------|-----------------|------------------------|
| `timeout`            | Global: `external_agents.timeout` | 30.0s           | Request timeout        |
|                      | Per-agent: `nodes.<name>.timeout` | inherits global |                        |
| `retry.max_attempts` | Global/Per-agent                  | 3               | Maximum retry attempts |
| `retry.backoff`      | Global/Per-agent                  | 1.0s            | Initial backoff delay  |
| `retry.max_backoff`  | Global/Per-agent                  | 30.0s           | Maximum backoff delay  |

### Retry Behavior

Retries are triggered for:

- **Timeout errors** - Agent didn't respond in time
- **Connection errors** - Network issues
- **HTTP 5xx errors** - Server-side failures

Non-retryable errors (4xx, authentication failures) fail immediately.

Uses exponential backoff via [tenacity](https://tenacity.readthedocs.io/) with 2x multiplier.

Example with defaults (backoff=1.0, max_backoff=30.0):

- Attempt 1 fails → wait ~1s
- Attempt 2 fails → wait ~2s
- Attempt 3 fails → error raised

## Complete Workflow Example

Here's a complete example showing local and external agents working together:

```yaml
metadata:
  version: "1.0"
  name: "Customer Support with External Agents"

llm:
  provider: "azure_openai"
  config:
    model: "gpt-4o"
    azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"

orchestrator:
  workflows:
    - customer_support

workflows:
  customer_support:
    description: "Multi-platform customer support"
    nodes:
      triage_agent:
        routes:
          router_field: "category"
          crm: salesforce_agent
          product: bedrock_expert
          billing: stripe_agent
          default: general_agent
      salesforce_agent:
        depends_on: [triage_agent]
      bedrock_expert:
        depends_on: [triage_agent]
      stripe_agent:
        depends_on: [triage_agent]
      general_agent:
        depends_on: [triage_agent]

nodes:
  # Local triage agent
  triage_agent:
    description: "Classifies customer queries"
    system_prompt: |
      You are a customer support triage agent. Analyze the query and call
      the classify_query tool to route to the appropriate specialist.
      Categories: crm, product, billing, general
    tools:
      - classify_query

  # External: Salesforce for CRM
  salesforce_agent:
    description: "Handles customer records and CRM operations"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"

  # External: AWS Bedrock for product knowledge
  bedrock_expert:
    description: "Product knowledge expert powered by AWS Bedrock"
    endpoint: "https://bedrock.us-east-1.amazonaws.com/a2a/product-expert"
    auth:
      type: bearer
      token: "${AWS_A2A_TOKEN}"

  # External: Stripe for billing
  stripe_agent:
    description: "Handles billing inquiries and payment issues"
    endpoint: "https://agents.stripe.com/a2a/billing"
    auth:
      type: api_key
      token: "${STRIPE_API_KEY}"
      header_name: "Stripe-API-Key"

  # Local fallback agent
  general_agent:
    description: "Handles general inquiries"
    system_prompt: |
      You are a general customer support agent. Help with any queries
      that don't fit into specific categories.
    tools:
      - search_knowledge_base
      - create_ticket
```

## Environment Variables

All credential fields support environment variable interpolation using `${VAR_NAME}` syntax:

```yaml
auth:
  type: bearer
  token: "${MY_SECRET_TOKEN}"  # Reads from MY_SECRET_TOKEN env var
```

This keeps secrets out of your YAML files.

## How It Works

When AgentFlow encounters a node with an `endpoint`:

1. **Detection**: The presence of `endpoint` marks the node as external
2. **Direct Invocation**: Creates a node that directly calls the external agent (no wrapper LLM needed)
3. **SDK Integration**: Uses the official [a2a-sdk](https://pypi.org/project/a2a-sdk/) for A2A protocol compliance
4. **Response Handling**: Extracts and returns the external agent's response as an AIMessage

The A2A SDK handles:

- Agent card discovery (from `/.well-known/agent.json`)
- Message formatting
- Task lifecycle management

## Streaming Support

AgentFlow supports streaming responses from external A2A agents. When an external agent declares
`capabilities.streaming: true` in its Agent Card, AgentFlow will:

1. **Use SSE streaming**: Stream chunks as they arrive from the external agent
2. **Emit custom events**: Each chunk is emitted as a custom event (`external_agent_stream`)
3. **Real-time updates**: Consumers can display chunks in real-time via `astream_events()`

### Consuming Streaming Events

When using `stream_tokens=True`, external agent chunks appear as `token` events:

```python
async for event in orchestrator.run(state, config, stream_tokens=True):
    if event["type"] == "token":
        print(event["content"], end="", flush=True)
```

When using `stream_tokens=False`, external agent chunks appear as `external_agent_stream` events:

```python
async for event in orchestrator.run(state, config, stream_tokens=False):
    if event["type"] == "external_agent_stream":
        print(f"[{event['name']}] {event['content']}", end="", flush=True)
```

### Fallback Behavior

If an external agent doesn't support streaming (no `capabilities.streaming: true` in Agent Card), AgentFlow
automatically falls back to non-streaming mode and returns the complete response as a single chunk.

## Multi-turn Conversations

AgentFlow automatically maintains conversation context with external agents across multiple invocations within the same
workflow execution. This is achieved by:

1. **Task ID Tracking**: Each external agent's `taskId` is stored in the workflow state
2. **Automatic Context**: Subsequent calls to the same external agent include the `taskId`, allowing the agent to
   maintain conversation history
3. **Per-Thread Isolation**: Different `thread_id` values maintain separate conversation contexts

### How It Works

```
User Query 1 → External Agent (new task created, taskId=abc123)
    ↓
State: { external_agent_tasks: { "salesforce_agent": "abc123" } }
    ↓
User Query 2 → External Agent (continues task abc123 with full context)
```

### Requirements

Multi-turn support requires:

- **Persistence enabled**: The orchestrator must have checkpointer configured to persist task IDs between invocations
- **Same thread_id**: Subsequent requests must use the same `thread_id` in the config
- **External agent support**: The external agent must support task continuation (most A2A-compliant agents do)

### Example

```python
# First interaction - creates new task
async for event in orchestrator.run(
    state={"messages": [HumanMessage(content="What's my account balance?")]},
    config={"configurable": {"thread_id": "user-123"}}
):
    print(event)

# Second interaction - continues the conversation with context
async for event in orchestrator.run(
    state={"messages": [HumanMessage(content="Transfer $100 to savings")]},
    config={"configurable": {"thread_id": "user-123"}}  # Same thread_id
):
    print(event)
# The external agent remembers the account from the first query
```

## Limitations

- **OAuth2 Authorization Code**: Not supported (requires user interaction)

## Troubleshooting

### Connection errors

1. Verify the endpoint URL is correct
2. Check that the agent exposes `/.well-known/agent.json`
3. Verify authentication credentials
4. Check network connectivity and firewall rules

### Authentication failures

- **401 Unauthorized**: Check token/credentials
- **403 Forbidden**: Check scopes/permissions
- **OAuth2 errors**: Verify token_url, client_id, and client_secret

## References

- [A2A Protocol Specification](https://a2a-protocol.org/latest/specification/)
- [a2a-sdk on PyPI](https://pypi.org/project/a2a-sdk/)
- [A2A Python SDK GitHub](  https://github.com/a2aproject/a2a-python)

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.

