# MCP Integration Guide

AgentFlow provides native support for the **Model Context Protocol (MCP)**, enabling agents to use tools provided by MCP
servers without requiring local tool implementations.

## Overview

MCP is an open protocol that standardizes how AI applications connect to external data sources and tools. With
AgentFlow's MCP integration, you can:

- Connect to local MCP servers (subprocess via stdio)
- Connect to remote MCP servers (SSE or Streamable HTTP)
- Use multiple authentication methods
- Mix local tools and MCP tools in the same agent
- Monitor connection health and auto-reconnect

## Quick Start

### 1. Configure MCP Servers

Add MCP server configuration to your `workflow.yaml`:

```yaml
mcp_servers:
  data-platform:
    transport: stdio
    command: "python"
    args: ["-m", "my_mcp_server"]
    env:
      APP_DIR: "."
    context: |
      This server provides access to the order-management application.
      Available data sources: customers, orders, inventory.
      Always use app_id: "order-management" for all tool calls.
```

### 2. Reference MCP Tools in Nodes

```yaml
nodes:
  "Data Agent":
    description: "Query and analyze data"
    system_prompt: "You have access to data tools..."
    mcp_tools:
      - server: data-platform
        tools: [query, list_sources]
```

### 3. Run Your Workflow

```python
from agentflow import AsyncWorkflowOrchestrator

async with AsyncWorkflowOrchestrator.create("workflow.yaml") as orchestrator:
    result = await orchestrator.run("Analyze sales data", thread_id="user-123")
```

## Transport Types

### stdio Transport (Local)

For MCP servers running as local subprocesses:

```yaml
mcp_servers:
  local-server:
    transport: stdio
    command: "python"
    args: ["-m", "mcp_server"]
    env:
      DATABASE_URL: "${DATABASE_URL}"
```

**Use cases:**

- Development and testing
- Servers requiring filesystem access
- Low-latency local tools

### SSE Transport (Remote)

For remote MCP servers using Server-Sent Events:

```yaml
mcp_servers:
  remote-sse:
    transport: sse
    url: "https://mcp.example.com/sse"
    auth:
      type: bearer
      token: "${MCP_TOKEN}"
```

**Use cases:**

- Cloud-hosted MCP servers
- Real-time streaming responses

### Streamable HTTP Transport (Remote - Recommended)

For production remote MCP servers:

```yaml
mcp_servers:
  production-api:
    transport: streamable_http
    url: "https://api.example.com/mcp"
    timeout: 60.0
    auth:
      type: api_key
      token: "${API_KEY}"
```

**Use cases:**

- Production deployments
- High reliability requirements
- mTLS authentication

## Authentication

### Bearer Token

```yaml
auth:
  type: bearer
  token: "${MCP_TOKEN}"
```

### API Key

```yaml
auth:
  type: api_key
  token: "${API_KEY}"
  header_name: "X-Custom-Key"  # Optional, defaults to X-API-Key
```

### Basic Auth

```yaml
auth:
  type: basic
  username: "${MCP_USER}"
  password: "${MCP_PASS}"
```

### OAuth2 Client Credentials

Automatically fetches and caches access tokens:

```yaml
auth:
  type: oauth2_client_credentials
  oauth2:
    token_url: "https://auth.example.com/oauth/token"
    client_id: "${CLIENT_ID}"
    client_secret: "${CLIENT_SECRET}"
    scopes: ["mcp.read", "mcp.write"]
```

### mTLS (Streamable HTTP only)

```yaml
auth:
  type: mtls
  mtls:
    cert_path: "/path/to/client.pem"
    key_path: "/path/to/client-key.pem"
    ca_path: "/path/to/ca.pem"  # Optional
```

## Tool Configuration

### Select All Tools

```yaml
mcp_tools:
  - server: data-platform
    tools: "*"  # Use all available tools
```

### Select Specific Tools

```yaml
mcp_tools:
  - server: data-platform
    tools: [query, search, list_sources]
```

### Tool Aliasing

Rename tools to avoid conflicts or provide clearer names:

```yaml
mcp_tools:
  - server: data-platform
    tools:
      - name: query
        alias: query_data
      - name: search
        alias: search_records
```

### Mixing Local and MCP Tools

```yaml
nodes:
  "Hybrid Agent":
    description: "Uses both local and remote tools"
    system_prompt: "..."
    tools: [local_calculator, local_formatter]  # Local tools
    mcp_tools:
      - server: data-platform
        tools: [query, search]
```

## Environment-Specific Configuration

Override settings per environment:

```yaml
mcp_servers:
  api-server:
    transport: streamable_http
    url: "https://dev.example.com/mcp"  # Default (dev)
    environments:
      staging:
        url: "https://staging.example.com/mcp"
      production:
        url: "https://api.example.com/mcp"
        timeout: 60.0
```

Set `MCP_ENV` environment variable to select the environment:

```bash
export MCP_ENV=production
```

## Health Monitoring

### Check Connection Status

```python
from agentflow import ConnectionStatus

# Get status for one server
status = orchestrator._mcp_manager.get_connection_status("data-platform")
if status == ConnectionStatus.UNHEALTHY:
    print("Server is unhealthy!")

# Get status for all servers
all_status = orchestrator._mcp_manager.get_all_status()
```

### Manual Health Checks

```python
# Check specific server
healthy = await orchestrator._mcp_manager.health_check("data-platform")

# Check all servers
results = await orchestrator._mcp_manager.health_check_all()
```

### Reconnection

```python
# Reconnect specific server
success = await orchestrator._mcp_manager.reconnect("data-platform")

# Reconnect all unhealthy servers
results = await orchestrator._mcp_manager.reconnect_unhealthy()
```

### Automatic Health Monitoring

Start a background task that monitors health and auto-reconnects:

```python
# Start monitoring (checks every 60s, auto-reconnects)
monitor_task = await orchestrator._mcp_manager.start_health_monitor(
    interval_seconds=60.0,
    auto_reconnect=True,
)

# Later: stop monitoring
monitor_task.cancel()
```

### Refresh Tool Definitions

If a server's tools change at runtime:

```python
num_tools = await orchestrator._mcp_manager.refresh_tools("data-platform")
```

## Context Field (Auto-Documentation)

The `context` field allows you to provide domain-specific hints that are automatically injected into agent system
prompts. This eliminates the need to manually document MCP tool parameters in your system prompts.

```yaml
mcp_servers:
  data-platform:
    transport: stdio
    command: "python"
    args: ["-m", "mcp_data_platform.server"]
    context: |
      This server provides access to the order-management application.

      **Required Parameters:**
      - app_id: Always use "order-management"
      - source_id: One of "customers", "orders", or "inventory"

      **Available Data Sources:**
      - customers: Customer account information (fields: customer_id, name, email, status)
      - orders: Order transactions (fields: order_id, customer_id, amount, status)
      - inventory: Product inventory levels (fields: product_id, name, quantity)

      **Tool Usage:**
      - Use `query` for retrieving data with filters
      - Use `list_data_sources` to discover available sources
      - Use `get_schema` to understand field types
```

**How it works:**

1. When you reference MCP tools in a node, AgentFlow automatically generates documentation from the MCP tool schemas
2. The `context` field is prepended to provide domain-specific information not available in the schema
3. This documentation is injected into the agent's system prompt before the `## Available MCP Tools` section

**Benefits:**

- No need to manually document tool parameters in system prompts
- Context stays with the server configuration, not scattered across nodes
- Tool schemas are always up-to-date (read from MCP server at runtime)
- Reduces duplication when multiple agents use the same MCP server

**Example system prompt injection:**

```
[Your system prompt]

## Available MCP Tools

This server provides access to the order-management application.
[Your context content here]

### query
Query data from a source.

**Parameters:**
- `app_id` (string, required): Application identifier
- `source_id` (string, required): Data source to query
- `filters` (array, optional): Filter conditions
...
```

## Retry Configuration

Configure retry behavior for tool calls:

```yaml
mcp_servers:
  data-platform:
    transport: streamable_http
    url: "https://api.example.com/mcp"
    timeout: 30.0
    retry:
      max_attempts: 3
      backoff: 1.0
      max_backoff: 30.0
```

## Plugin Events

MCP operations emit plugin events for observability:

```python
from agentflow import Plugin, WorkflowContext

class MCPObserverPlugin(Plugin):
    def on_mcp_connect(self, context, server_name, tool_count):
        print(f"Connected to {server_name}: {tool_count} tools")

    def on_mcp_tool_call(self, context, server_name, tool_name, arguments):
        print(f"Calling {server_name}.{tool_name}")

    def on_mcp_tool_result(self, context, server_name, tool_name, result, error=None):
        if error:
            print(f"Tool error: {error}")
        else:
            print(f"Tool result: {result[:100]}...")
```

## Connection Status Values

| Status         | Description                      |
|----------------|----------------------------------|
| `DISCONNECTED` | Not connected to server          |
| `CONNECTING`   | Connection in progress           |
| `CONNECTED`    | Connected and healthy            |
| `UNHEALTHY`    | Connection has repeated failures |
| `RECONNECTING` | Attempting to reconnect          |

## Complete Example

```yaml
# workflow.yaml
llm:
  provider: azure_openai
  deployment: gpt-4o
  temperature: 0.5

mcp_servers:
  data-api:
    transport: streamable_http
    url: "https://data.example.com/mcp"
    timeout: 30.0
    auth:
      type: oauth2_client_credentials
      oauth2:
        token_url: "https://auth.example.com/token"
        client_id: "${DATA_API_CLIENT_ID}"
        client_secret: "${DATA_API_CLIENT_SECRET}"
    retry:
      max_attempts: 3

  local-tools:
    transport: stdio
    command: "python"
    args: ["-m", "my_tools"]

orchestrator:
  workflows: [main]
  routing_keys:
    "main": ["data", "analysis", "report"]

workflows:
  main:
    nodes:
      "Data Agent":
        description: "Fetches and analyzes data"
        system_prompt: |
          You are a data analyst with access to the company's data API.
          Use the available tools to query data and provide insights.
        mcp_tools:
          - server: data-api
            tools: [query_sales, query_inventory, get_metrics]
          - server: local-tools
            tools: "*"

    edges:
      "Data Agent": END
    entry_point: "Data Agent"
```

## Troubleshooting

### Connection Fails

1. Check the server URL is correct
2. Verify authentication credentials
3. Check network connectivity
4. Review server logs

### Tools Not Discovered

1. Ensure the MCP server exposes tools via `list_tools()`
2. Check server initialization completed
3. Try `refresh_tools()` to re-discover

### Tool Calls Fail

1. Check tool arguments match the schema
2. Verify server-side implementation
3. Review timeout settings
4. Check retry configuration

### OAuth2 Token Issues

1. Verify token URL is accessible
2. Check client credentials
3. Ensure scopes are correct
4. Token cache may need clearing (restart)

## References

- [MCP Specification](https://spec.modelcontextprotocol.io/)
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [AgentFlow Documentation](./index.md)

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
