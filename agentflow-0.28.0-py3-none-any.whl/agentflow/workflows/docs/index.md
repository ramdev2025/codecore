# AgentFlow Documentation

Welcome to the AgentFlow documentation!

AgentFlow is a framework-independent, YAML-driven platform for configuring and running AI agent harnesses. The workflows
backend uses LangGraph to orchestrate multi-agent workflows with local agents, MCP server tools, external A2A-compliant
agents, and enterprise-grade features like persistence, middleware, and observability.

## Quick Navigation

### Getting Started

- **[Getting Started](AGENTFLOW.md)** - Learn about AgentFlow and its core concepts
- **[Standalone Agents](tutorials/standalone-agent.md)** - Build a single agent with tools
- **[Workflow YAML Reference](WORKFLOW_YAML.md)** - Complete `workflow.yaml` configuration guide
- **[CLI Usage](AGENTFLOW_CLI.md)** - Command-line interface and programmatic API

### Integrations

- **[MCP Integration](MCP.md)** - Use tools from MCP (Model Context Protocol) servers
- **[External Agents (A2A)](EXTERNAL_AGENTS.md)** - Connect to A2A-compliant agents (Salesforce, Stripe, etc.)
- **[Middleware](MIDDLEWARE.md)** - LangChain middleware for limits, summarization, and human-in-the-loop
- **[AG-UI Integration](AG_UI.md)** - Stream typed components, HITL approvals, and client-side tools to a CopilotKit frontend
- **[Workflow YAML Reference](WORKFLOW_YAML.md)** - Custom LLMs (Snowflake Cortex, Bedrock, Vertex AI, etc.)

### Production & Enterprise

- **[Production Features](PRODUCTION_FEATURES.md)** - Rate limiting, caching, retries, cost tracking, encryption, and
  more
- **[State Persistence](PERSISTENCE.md)** - SQLite and PostgreSQL persistence with long-term memory
- **[Human in the Loop](HUMAN_IN_THE_LOOP.md)** - Implement human intervention in your workflows

### Observability

- **[Observability](OBSERVABILITY.md)** - Tracing, structured logging, metrics, and cost tracking (Datadog, Azure
  Monitor, Grafana, Jaeger)

### Extensibility

- **[Plugin Specification](PLUGIN_SPECIFICATION.md)** - Create custom plugins for AgentFlow
- **[Plugin Template](PLUGIN_TEMPLATE.md)** - Quick-start template for plugin development

## Features

### Core Capabilities

- **Declarative Workflows** - Define complex agent workflows in YAML
- **LangGraph Integration** - Built on top of the powerful LangGraph framework
- **Command-Line Interface** - Run workflows from the terminal with `agentflow`
- **Multiple LLM Providers** - OpenAI, Anthropic, Azure OpenAI, and custom models

### External Agent Integration

- **MCP Support** - Use tools from MCP servers (stdio, SSE, Streamable HTTP transports)
- **A2A Protocol Support** - Connect to any A2A-compliant agent
- **Custom LLMs** - Use any LangChain chat model (Snowflake Cortex, Bedrock, Vertex AI, Ollama, etc.)
- **Authentication Options** - Bearer, API Key, Basic, OAuth2, mTLS
- **Multi-turn Conversations** - Context preserved across interactions

### Production & Enterprise

- **State Persistence** - SQLite for development, PostgreSQL for production
- **Long-term Memory** - Cross-conversation memory with PostgreSQL store
- **LangChain Middleware** - Model limits, tool limits, summarization, human-in-the-loop
- **Conditional Routing** - Dynamic workflow paths based on agent decisions
- **Node Retry Policy** - Exponential backoff retries on nodes with jitter
- **Rate Limiting** - Token bucket throttling for LLM API calls
- **Response & Node Caching** - LLM response caching and node output caching with TTL
- **Checkpoint Encryption** - AES encryption for persisted state at rest
- **Cost Tracking** - Token budget enforcement per workflow run
- **Structured Logging** - JSON log output with correlation IDs for observability

### Observability & Extensibility

- **OpenTelemetry Integration** - Distributed tracing and monitoring
- **Metrics Collection** - Per-run counters for LLM calls, tool calls, durations, and token usage
- **Plugin System** - Extend functionality with custom plugins
- **Lifecycle Hooks** - React to workflow, agent, and tool events

## Installation

```bash
pip install agentflow[workflows]
```

### Optional Extras

| Extra       | Description                                   | Install Command                      |
|-------------|-----------------------------------------------|--------------------------------------|
| `workflows` | Multi-agent orchestration (MCP, A2A, OTel)    | `pip install "agentflow[workflows]"` |
| `deep`      | Autonomous agents (deepagents, TUI)           | `pip install "agentflow[deep]"`      |
| `postgres`  | PostgreSQL persistence and long-term memory   | `pip install "agentflow[postgres]"`  |
| `ui`        | AG-UI bridge (FastAPI + SSE + WebSocket)      | `pip install "agentflow[ui]"`        |
| `docs`      | Documentation server (MkDocs)                 | `pip install "agentflow[docs]"`      |
| `snowflake` | Snowflake Cortex provider                     | `pip install "agentflow[snowflake]"` |
| `dev`       | Development tools (pytest, black, ruff, mypy) | `pip install "agentflow[dev]"`       |

Combine extras as needed:

```bash
pip install "agentflow[workflows,postgres]"
```

## Quick Start

### 1. Create an Agent

The simplest way to start — a standalone agent with tools:

```yaml
# workflow.yaml
metadata:
  version: "1.0"

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"

agent:
  name: "My Assistant"
  system_prompt: "You are a helpful assistant."
  tools: [search_web]
```

For multi-agent workflows, use `orchestrator:` + `workflows:` instead. See
[Getting Started](tutorials/getting-started.md) for the full multi-agent tutorial.

### 2. Run from CLI

```bash
# One-shot query
agentflow "What is the weather today?"

# Interactive mode
agentflow --interactive

# Custom workflow
agentflow --yaml my_workflow.yaml "Process this request"
```

### 3. Run Programmatically

```python
from agentflow import AsyncWorkflowOrchestrator

async with AsyncWorkflowOrchestrator(
    config_path="workflow.yaml",
    tools_module="my_tools",
    enable_persistence=True
) as orchestrator:
    async for event in orchestrator.run(
        state={"messages": [{"role": "user", "content": "Hello!"}]},
        config={"configurable": {"thread_id": "user-123"}}
    ):
        print(event)
```

## Node Types

AgentFlow supports multiple types of agent nodes:

### Local Agents

Standard LangChain agents with tools and system prompts:

```yaml
nodes:
  my_agent:
    description: "Local agent"
    system_prompt: "You are helpful."
    tools: [search, calculate]
```

### Local Agents with MCP Tools

Agents that use tools from MCP (Model Context Protocol) servers:

```yaml
mcp_servers:
  data-platform:
    transport: stdio
    command: "python"
    args: ["-m", "my_mcp_server"]

nodes:
  data_agent:
    description: "Agent with MCP tools"
    system_prompt: "You have access to data tools."
    mcp_tools:
      - server: data-platform
        tools: [query, list_tables]
```

Local agents can also use custom LLMs (Snowflake Cortex, Bedrock, Vertex AI, etc.):

```yaml
nodes:
  snowflake_agent:
    description: "Query enterprise data"
    llm:
      provider: custom
      class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
      config:
        model: "llama3.1-70b"
    system_prompt: "You are an enterprise data analyst..."
```

### External A2A Agents

Connect to A2A-compliant external agents:

```yaml
nodes:
  crm_agent:
    description: "Salesforce CRM agent"
    endpoint: "https://einstein.salesforce.com/a2a"
    auth:
      type: bearer
      token: "${SALESFORCE_TOKEN}"
```

## Configuration Reference

See the [Workflow YAML Reference](WORKFLOW_YAML.md) for complete configuration details including:

- LLM configuration hierarchy (global → workflow → node)
- MCP server configuration (transports, authentication, tool selection)
- Custom LLM integration (Snowflake Cortex, Bedrock, Vertex AI, Ollama)
- Conditional routing with `routes`
- Middleware configuration
- Persistence settings (SQLite, PostgreSQL)
- External agent authentication options

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
