"""
This module provides a factory pattern for creating persistence resources
(checkpointer and store) based on configuration, supporting both SQLite
and PostgreSQL backends.
"""

import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .config_models import (
    CheckpointerConfig,
    PersistenceConfig,
    PersistenceBackend,
    SQLiteConfig,
    PostgresConfig,
    StoreConfig,
)
from .constants import DEFAULT_PATH_TO_SQLITE_DB
# Pool helpers, plus the POSTGRES_POOL_* env var names. Those live in
# agentflow.core.pg_pool (shared with the deep backend) and are re-exported
# here so this module stays the one place to look up a persistence env var.
from agentflow.core.pg_pool import (  # noqa: F401  (re-exported)
    ENV_POSTGRES_POOL_CHECK,
    ENV_POSTGRES_POOL_MAX_IDLE,
    ENV_POSTGRES_POOL_MAX_LIFETIME,
    ENV_POSTGRES_POOL_MIN_SIZE,
    ENV_POSTGRES_POOL_SIZE,
    ENV_POSTGRES_POOL_TIMEOUT,
    PoolSettings,
    build_pool_kwargs,
    describe,
)

logger = logging.getLogger(__name__)

# Environment variable names — canonical list of persistence env vars.
#
# Backend-specific values use the bare infrastructure name (no prefix);
# AgentFlow-level toggles use the ``AGENTFLOW_`` prefix.
ENV_POSTGRES_CONNECTION_STRING = "POSTGRES_CONNECTION_STRING"
ENV_CHECKPOINTER_DB_PATH = "CHECKPOINTER_DB_PATH"
ENV_AGENTFLOW_PERSISTENCE = "AGENTFLOW_PERSISTENCE"
ENV_AGENTFLOW_STORE_ENABLED = "AGENTFLOW_STORE_ENABLED"
ENV_AGENTFLOW_ENCRYPTION_KEY = "AGENTFLOW_ENCRYPTION_KEY"

# Re-export for backward compatibility
from agentflow.core.env import resolve_env_vars as _resolve_env_vars


_TRUTHY_ENV_VALUES = {"1", "true", "yes", "on"}
VALID_PERSISTENCE_BACKENDS = {"memory", "sqlite", "postgres"}


def resolve_persistence_config_from_env(
    *,
    persistence: Optional[str] = None,
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
) -> Optional[PersistenceConfig]:
    """Resolve persistence from explicit overrides plus the environment.

    This is the single description of how persistence is configured, shared by
    every entry point: the ``agentflow`` CLI (which supplies its flags as the
    keyword arguments), and embedding apps that go through
    ``AsyncWorkflowOrchestrator`` / ``build_agui`` without passing a config at
    all. Keeping one implementation is deliberate — when the CLI had its own
    copy, apps embedding AgentFlow as a library silently ignored
    ``AGENTFLOW_PERSISTENCE``, ``AGENTFLOW_ENCRYPTION_KEY``,
    ``AGENTFLOW_STORE_ENABLED`` and the ``POSTGRES_POOL_*`` family.

    Precedence is explicit argument > environment variable > default.

    Selecting variables (any one produces a config):
        ``AGENTFLOW_PERSISTENCE``      memory | sqlite | postgres
        ``POSTGRES_CONNECTION_STRING`` implies postgres
        ``CHECKPOINTER_DB_PATH``       implies sqlite
        ``AGENTFLOW_ENCRYPTION_KEY``   implies the default backend, encrypted

    Returns:
        A ``PersistenceConfig``, or ``None`` when neither an argument nor any
        selecting variable is present — letting the caller apply its own
        default. Pool tuning (``POSTGRES_POOL_*``) is applied by
        :class:`PostgresConfig` itself, so it works here and everywhere else.

    Raises:
        ValueError: On an unknown backend name, a postgres backend with no
            connection string, or a malformed pool variable. Callers that want
            a friendlier presentation (the CLI) catch and re-raise.
    """
    env_backend = os.environ.get(ENV_AGENTFLOW_PERSISTENCE)
    env_db_path = os.environ.get(ENV_CHECKPOINTER_DB_PATH)
    env_conn = os.environ.get(ENV_POSTGRES_CONNECTION_STRING)
    env_enc_key = os.environ.get(ENV_AGENTFLOW_ENCRYPTION_KEY)

    if (
        persistence is None
        and db_path is None
        and connection_string is None
        and env_backend is None
        and env_db_path is None
        and env_conn is None
        and env_enc_key is None
    ):
        return None

    backend = persistence or env_backend
    if backend is None:
        backend = "postgres" if (connection_string or env_conn) else "sqlite"
    backend = backend.strip().lower()
    if backend not in VALID_PERSISTENCE_BACKENDS:
        raise ValueError(
            f"Unknown persistence backend: {backend!r}. "
            f"Expected one of: {sorted(VALID_PERSISTENCE_BACKENDS)}."
        )

    encryption_key = env_enc_key

    if backend == "memory":
        return PersistenceConfig(
            checkpointer=CheckpointerConfig(enabled=False),
            store=StoreConfig(enabled=False),
            encryption_key=encryption_key,
        )

    if backend == "postgres":
        conn = connection_string or env_conn
        if not conn:
            raise ValueError(
                "Postgres persistence requires a connection string "
                f"(--connection-string or {ENV_POSTGRES_CONNECTION_STRING})."
            )
        store_env = os.environ.get(ENV_AGENTFLOW_STORE_ENABLED, "")
        return PersistenceConfig(
            backend=PersistenceBackend.POSTGRES,
            # POSTGRES_POOL_* is applied inside PostgresConfig.
            postgres=PostgresConfig(connection_string=conn),
            store=StoreConfig(enabled=store_env.strip().lower() in _TRUTHY_ENV_VALUES),
            encryption_key=encryption_key,
        )

    return PersistenceConfig(
        backend=PersistenceBackend.SQLITE,
        sqlite=SQLiteConfig(db_path=db_path or env_db_path or DEFAULT_PATH_TO_SQLITE_DB),
        encryption_key=encryption_key,
    )


@dataclass
class PersistenceResources:
    """Container for persistence resources."""
    checkpointer: Optional[Any] = None
    store: Optional[Any] = None


def _create_serde(encryption_key: Optional[str] = None):
    """Create a serializer, optionally with AES encryption."""
    if not encryption_key:
        return None
    key = _resolve_env_vars(encryption_key)
    from langgraph.checkpoint.serde.encrypted import EncryptedSerializer
    return EncryptedSerializer.from_pycryptodome_aes(key=key.encode())


class BasePersistenceManager(ABC):
    """Abstract base class for persistence managers."""

    @abstractmethod
    async def setup(self) -> PersistenceResources:
        """
        Set up and return persistence resources.

        Returns:
            PersistenceResources with configured checkpointer and/or store
        """
        pass

    @abstractmethod
    async def cleanup(self) -> None:
        """Clean up persistence resources."""
        pass


class SQLitePersistenceManager(BasePersistenceManager):
    """
    SQLite persistence manager.

    Uses LangGraph's standard AsyncSqliteSaver for checkpointer management.
    Store is not supported with SQLite (will log a warning if enabled).
    """

    def __init__(self, config: SQLiteConfig, checkpointer_enabled: bool = True, store_enabled: bool = False,
                 encryption_key: Optional[str] = None):
        """
        Initialize SQLite persistence manager.

        Args:
            config: SQLite configuration
            checkpointer_enabled: Whether to enable checkpointer
            store_enabled: Whether to enable store (not supported, will warn)
            encryption_key: Optional AES key for checkpoint encryption
        """
        self.config = config
        self.checkpointer_enabled = checkpointer_enabled
        self.store_enabled = store_enabled
        self.encryption_key = encryption_key
        self._checkpointer = None

    async def setup(self) -> PersistenceResources:
        """Set up SQLite persistence resources."""
        import aiosqlite
        from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

        resources = PersistenceResources()

        if self.store_enabled:
            logger.warning(
                "Store is not supported with SQLite backend. "
                "Use PostgreSQL backend for store functionality. "
                "Continuing with checkpointer only."
            )

        if self.checkpointer_enabled:
            # Ensure parent directory exists
            db_path = Path(self.config.db_path)
            db_path.parent.mkdir(parents=True, exist_ok=True)

            # Create serde with optional encryption
            serde = _create_serde(self.encryption_key)

            # Use LangGraph's standard AsyncSqliteSaver directly
            conn = await aiosqlite.connect(str(db_path))
            self._checkpointer = AsyncSqliteSaver(conn, serde=serde)
            await self._checkpointer.setup()
            resources.checkpointer = self._checkpointer

            logger.info(f"SQLite Persistence Enabled:")
            logger.info(f"  Database: {self.config.db_path}")
            if serde:
                logger.info(f"  Encryption: enabled (AES)")
        else:
            logger.info("Persistence disabled (stateless mode)")

        return resources

    async def cleanup(self) -> None:
        """Clean up SQLite persistence resources."""
        if self._checkpointer is not None:
            try:
                if hasattr(self._checkpointer, 'conn') and self._checkpointer.conn is not None:
                    await self._checkpointer.conn.close()
            except Exception as e:
                logger.warning(f"Error closing SQLite connection: {e}")
            self._checkpointer = None


class PostgresPersistenceManager(BasePersistenceManager):
    """
    PostgreSQL persistence manager.

    Uses AsyncPostgresSaver for checkpointer and AsyncPostgresStore for store,
    both served from a single shared ``AsyncConnectionPool``.

    Why a pool and not a single connection
    --------------------------------------
    langgraph's ``from_conn_string`` helpers open exactly one ``AsyncConnection``
    and hold it. When anything closes that connection underneath us — a database
    restart, a failover, a server-side ``idle_session_timeout``, or a cloud load
    balancer reaping an idle TCP flow — libpq marks it ``CONNECTION_BAD`` and
    never clears the flag. psycopg does not reconnect, so every subsequent
    checkpoint operation fails with ``OperationalError: the connection is
    closed`` until the process is restarted.

    A pool removes that failure mode two ways:

    * ``check`` (reactive) validates a connection as it is handed out, so a
      connection that died while idle is discarded and replaced before the
      caller ever sees it.
    * ``max_lifetime`` (proactive) retires connections on a timer so they never
      live long enough to be reaped in the first place.

    Both are on by default and configurable via :class:`PostgresConfig`.
    """

    def __init__(self, config: PostgresConfig, checkpointer_enabled: bool = True, store_enabled: bool = False,
                 encryption_key: Optional[str] = None):
        """
        Initialize PostgreSQL persistence manager.

        Args:
            config: PostgreSQL configuration
            checkpointer_enabled: Whether to enable checkpointer
            store_enabled: Whether to enable store
            encryption_key: Optional AES key for checkpoint encryption
        """
        self.config = config
        self.checkpointer_enabled = checkpointer_enabled
        self.store_enabled = store_enabled
        self.encryption_key = encryption_key
        self._checkpointer = None
        self._store = None
        self._pool = None  # Shared AsyncConnectionPool for checkpointer + store
        self._connection_string = None

    def _pool_settings(self) -> PoolSettings:
        """Project the YAML/CLI PostgresConfig onto shared pool settings."""
        return PoolSettings(
            pool_size=self.config.pool_size,
            min_size=self.config.min_size,
            max_lifetime=self.config.max_lifetime,
            max_idle=self.config.max_idle,
            check_connection=self.config.check_connection,
            connect_timeout=self.config.connect_timeout,
        )

    async def _create_pool(self):
        """Open the shared connection pool used by the checkpointer and store."""
        try:
            from psycopg_pool import AsyncConnectionPool
        except ImportError:
            raise ImportError(
                "PostgreSQL persistence requires the 'psycopg' and 'psycopg_pool' "
                "packages. Install them with: pip install agentflow[postgres]"
            )

        settings = self._pool_settings()
        pool = AsyncConnectionPool(
            **build_pool_kwargs(self._connection_string, settings, is_async=True)
        )
        await pool.open()

        logger.info(f"PostgreSQL connection pool opened ({describe(settings)})")
        return pool

    async def setup(self) -> PersistenceResources:
        """Set up PostgreSQL persistence resources."""
        resources = PersistenceResources()

        # Resolve environment variables in connection string
        self._connection_string = _resolve_env_vars(self.config.connection_string)

        if not self.checkpointer_enabled and not self.store_enabled:
            logger.info("PostgreSQL persistence configured but both checkpointer and store disabled")
            return resources

        # One pool serves both the checkpointer and the store. Each borrows a
        # connection per operation and returns it, so neither holds a
        # long-lived connection that can go stale.
        self._pool = await self._create_pool()

        try:
            if self.checkpointer_enabled:
                try:
                    from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
                except ImportError:
                    raise ImportError(
                        "PostgreSQL checkpointer requires 'langgraph-checkpoint-postgres' package. "
                        "Install it with: pip install agentflow[postgres]"
                    )

                # Create serde with optional encryption
                serde = _create_serde(self.encryption_key)

                self._checkpointer = AsyncPostgresSaver(conn=self._pool, serde=serde)
                await self._checkpointer.setup()
                resources.checkpointer = self._checkpointer

                logger.info("PostgreSQL Checkpointer Enabled")

            if self.store_enabled:
                try:
                    from langgraph.store.postgres.aio import AsyncPostgresStore
                except ImportError:
                    raise ImportError(
                        "PostgreSQL store requires 'langgraph-checkpoint-postgres' package. "
                        "Install it with: pip install agentflow[postgres]"
                    )

                self._store = AsyncPostgresStore(conn=self._pool)
                await self._store.setup()
                resources.store = self._store

                logger.info("PostgreSQL Store Enabled")
        except Exception:
            # Don't leak the pool if either setup() fails.
            await self.cleanup()
            raise

        return resources

    async def cleanup(self) -> None:
        """Close the shared connection pool and release both resources."""
        self._checkpointer = None
        self._store = None

        if self._pool is not None:
            try:
                await self._pool.close()
            except Exception as e:
                logger.warning(f"Error closing PostgreSQL connection pool: {e}")
            self._pool = None


class NoPersistenceManager(BasePersistenceManager):
    """No-op persistence manager for stateless mode."""

    async def setup(self) -> PersistenceResources:
        """Return empty persistence resources."""
        logger.info("Persistence disabled (stateless mode)")
        return PersistenceResources()

    async def cleanup(self) -> None:
        """No-op cleanup."""
        pass


class PersistenceFactory:
    """
    Factory for creating persistence managers.

    Supports creating managers based on:
    1. Explicit PersistenceConfig from YAML
    2. Legacy parameters (enable_persistence, checkpointer_path)
    3. Default SQLite configuration
    """

    @staticmethod
    def create_manager(
            config: Optional[PersistenceConfig] = None,
            enable_persistence: bool = True,
            checkpointer_path: str = DEFAULT_PATH_TO_SQLITE_DB,
    ) -> BasePersistenceManager:
        """
        Create a persistence manager based on configuration.

        Priority:
        1. If config is provided, use it
        2. Otherwise, use legacy parameters to create SQLite manager

        Args:
            config: Optional PersistenceConfig from YAML
            enable_persistence: Legacy parameter - whether to enable persistence
            checkpointer_path: Legacy parameter - path to SQLite database

        Returns:
            Configured BasePersistenceManager instance
        """
        if config is not None:
            # Use explicit configuration from YAML
            return PersistenceFactory._create_from_config(config)
        else:
            # Use legacy parameters (backward compatibility)
            return PersistenceFactory._create_from_legacy(
                enable_persistence=enable_persistence,
                checkpointer_path=checkpointer_path,
            )

    @staticmethod
    def _create_from_config(config: PersistenceConfig) -> BasePersistenceManager:
        """Create manager from PersistenceConfig."""
        checkpointer_enabled = config.checkpointer.enabled
        store_enabled = config.store.enabled

        if not checkpointer_enabled and not store_enabled:
            return NoPersistenceManager()

        if config.backend == PersistenceBackend.POSTGRES:
            return PostgresPersistenceManager(
                config=config.postgres,
                checkpointer_enabled=checkpointer_enabled,
                store_enabled=store_enabled,
                encryption_key=config.encryption_key,
            )
        else:
            # SQLite (default)
            return SQLitePersistenceManager(
                config=config.sqlite,
                checkpointer_enabled=checkpointer_enabled,
                store_enabled=store_enabled,
                encryption_key=config.encryption_key,
            )

    @staticmethod
    def _create_from_legacy(
            enable_persistence: bool,
            checkpointer_path: str,
    ) -> BasePersistenceManager:
        """Create manager when no explicit PersistenceConfig was supplied.

        This is the path embedding apps take — ``build_agui`` and any caller
        of ``AsyncWorkflowOrchestrator`` that doesn't pass
        ``persistence_config=``. It resolves the same environment contract the
        CLI does via :func:`resolve_persistence_config_from_env`, so
        ``AGENTFLOW_PERSISTENCE``, ``AGENTFLOW_ENCRYPTION_KEY``,
        ``AGENTFLOW_STORE_ENABLED`` and the ``POSTGRES_POOL_*`` family are
        honoured here too.
        """
        if not enable_persistence:
            return NoPersistenceManager()

        env_config = resolve_persistence_config_from_env()
        if env_config is not None:
            return PersistenceFactory._create_from_config(env_config)

        # Nothing configured — local SQLite at the caller's path.
        return SQLitePersistenceManager(
            config=SQLiteConfig(db_path=checkpointer_path),
            checkpointer_enabled=True,
            store_enabled=False,
        )
