"""
MCP Client Manager for AgentFlow.

Manages MCP server connections, tool discovery, and tool invocation.
Provides LangChain-compatible tools that invoke MCP server tools.

This module follows the same patterns as a2a_client.py for consistency.

Features:
- Multiple transport support: stdio, SSE, Streamable HTTP
- Authentication: Bearer, API key, Basic, OAuth2, mTLS
- Connection pooling for HTTP transports
- Health checks and automatic reconnection
- Retry logic with exponential backoff
- Tool aliasing and filtering

See: https://spec.modelcontextprotocol.io/
See: https://github.com/modelcontextprotocol/python-sdk
"""
import asyncio
import base64
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Callable

import httpx
from langchain_core.tools import BaseTool, StructuredTool
from mcp import ClientSession, StdioServerParameters
from mcp.client.sse import sse_client
from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamable_http_client
from mcp.types import CallToolResult
from pydantic import BaseModel, Field, create_model
from tenacity import (
    AsyncRetrying,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)

from .config_models import (
    MCPServerConfig,
    MCPTransport,
    MCPToolsReference,
    RetryConfig,
    A2AAuthType,
)


# =============================================================================
# Connection Status
# =============================================================================


class ConnectionStatus(str, Enum):
    """MCP connection status."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    UNHEALTHY = "unhealthy"
    RECONNECTING = "reconnecting"


# =============================================================================
# HTTP Client Pool (Instance-based for session isolation)
# =============================================================================


class HTTPClientPool:
    """
    HTTP client pool for connection reuse within a single MCPServerManager.

    Each MCPServerManager instance has its own HTTPClientPool to ensure
    session isolation in multi-tenant deployments. This avoids issues where
    one user's session cleanup affects another user's connections.

    Features:
    - Connection reuse within a session reduces latency
    - Configurable connection limits per server
    - Proper cleanup when the session ends
    """

    def __init__(self):
        """Initialize an empty client pool."""
        self._clients: Dict[str, httpx.AsyncClient] = {}
        self._lock = asyncio.Lock()

    async def get_client(
            self,
            key: str,
            timeout: float = 30.0,
            mtls_config: Optional[Any] = None,
    ) -> httpx.AsyncClient:
        """
        Get or create a pooled HTTP client.

        Args:
            key: Unique key for this client (e.g., server name)
            timeout: Request timeout in seconds
            mtls_config: Optional mTLS configuration

        Returns:
            httpx.AsyncClient instance for this session
        """
        async with self._lock:
            if key not in self._clients:
                if mtls_config:
                    cert = (
                        os.path.expandvars(mtls_config.cert_path),
                        os.path.expandvars(mtls_config.key_path),
                    )
                    verify = os.path.expandvars(mtls_config.ca_path) if mtls_config.ca_path else True
                    self._clients[key] = httpx.AsyncClient(
                        cert=cert,
                        verify=verify,
                        timeout=httpx.Timeout(timeout),
                        limits=httpx.Limits(max_keepalive_connections=5, max_connections=10),
                    )
                else:
                    self._clients[key] = httpx.AsyncClient(
                        timeout=httpx.Timeout(timeout),
                        limits=httpx.Limits(max_keepalive_connections=5, max_connections=10),
                    )
            return self._clients[key]

    async def close_client(self, key: str) -> None:
        """Close and remove a specific client."""
        async with self._lock:
            if key in self._clients:
                try:
                    await self._clients[key].aclose()
                except Exception:
                    pass
                del self._clients[key]

    async def close_all(self) -> None:
        """Close all pooled clients in this pool."""
        async with self._lock:
            for client in self._clients.values():
                try:
                    await client.aclose()
                except Exception:
                    pass
            self._clients.clear()


# =============================================================================
# OAuth2 Token Cache
# =============================================================================

from cachetools import TTLCache

# TTL-based token cache: max 100 entries, default 1-hour TTL.
# Tokens are evicted automatically when they expire.
_oauth2_token_cache: TTLCache = TTLCache(maxsize=100, ttl=3540)  # 3540s = 59min (60s buffer)


async def _fetch_oauth2_token(
        server_name: str,
        oauth2_config: Any,
        timeout: float = 30.0,
) -> str:
    """
    Fetch OAuth2 token using client credentials flow.

    Caches tokens for reuse until they expire.

    Args:
        server_name: Server name for cache key
        oauth2_config: OAuth2Config with token_url, client_id, client_secret, scopes
        timeout: Request timeout in seconds

    Returns:
        Access token string
    """
    # Check cache first (TTLCache handles expiry automatically)
    if server_name in _oauth2_token_cache:
        return _oauth2_token_cache[server_name]

    # Fetch new token
    async with httpx.AsyncClient(timeout=timeout) as client:
        data = {
            "grant_type": "client_credentials",
            "client_id": os.path.expandvars(oauth2_config.client_id),
            "client_secret": os.path.expandvars(oauth2_config.client_secret),
        }
        if oauth2_config.scopes:
            data["scope"] = " ".join(oauth2_config.scopes)

        response = await client.post(
            os.path.expandvars(oauth2_config.token_url),
            data=data,
        )
        response.raise_for_status()

        result = response.json()
        access_token = result["access_token"]

        _oauth2_token_cache[server_name] = access_token

        return access_token


def _build_httpx_client_for_mtls(
        config: "MCPServerConfig",
        timeout: float = 30.0,
) -> httpx.AsyncClient:
    """
    Build httpx AsyncClient with mTLS (client certificate) configuration.

    Args:
        config: Server config with mtls settings
        timeout: Request timeout

    Returns:
        Configured httpx.AsyncClient with client certificates
    """
    mtls = config.auth.mtls
    cert = (
        os.path.expandvars(mtls.cert_path),
        os.path.expandvars(mtls.key_path),
    )
    verify = os.path.expandvars(mtls.ca_path) if mtls.ca_path else True

    return httpx.AsyncClient(
        cert=cert,
        verify=verify,
        timeout=httpx.Timeout(timeout),
    )


# =============================================================================
# Exceptions
# =============================================================================


class MCPConnectionError(Exception):
    """Raised when MCP server connection fails."""

    def __init__(self, server_name: str, message: str):
        self.server_name = server_name
        super().__init__(f"MCP server '{server_name}': {message}")


class MCPToolError(Exception):
    """Raised when MCP tool invocation fails."""

    def __init__(self, tool_name: str, server_name: str, message: str):
        self.tool_name = tool_name
        self.server_name = server_name
        super().__init__(f"MCP tool '{tool_name}' on '{server_name}': {message}")


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class MCPToolDefinition:
    """Cached tool definition from MCP server."""

    name: str
    description: str
    input_schema: Dict[str, Any]
    server_name: str
    alias: Optional[str] = None

    @property
    def effective_name(self) -> str:
        """Name as seen by the agent."""
        return self.alias or self.name


@dataclass
class MCPConnection:
    """Active connection to an MCP server."""

    server_name: str
    config: MCPServerConfig
    session: ClientSession
    tools: Dict[str, MCPToolDefinition] = field(default_factory=dict)
    status: ConnectionStatus = ConnectionStatus.CONNECTED
    last_health_check: float = field(default_factory=time.time)
    consecutive_failures: int = 0
    _cleanup: Optional[Callable] = None
    _client_ctx: Any = None
    _session_ctx: Any = None

    async def close(self):
        """Close the connection and cleanup resources."""
        self.status = ConnectionStatus.DISCONNECTED
        if self._cleanup:
            try:
                await self._cleanup()
            except Exception as e:
                print(f"  Warning: Error during cleanup for '{self.server_name}': {e}")

    def mark_healthy(self) -> None:
        """Mark connection as healthy after successful operation."""
        self.status = ConnectionStatus.CONNECTED
        self.last_health_check = time.time()
        self.consecutive_failures = 0

    def mark_unhealthy(self) -> None:
        """Mark connection as unhealthy after failed operation."""
        self.consecutive_failures += 1
        if self.consecutive_failures >= 3:
            self.status = ConnectionStatus.UNHEALTHY

    def needs_health_check(self, interval_seconds: float = 60.0) -> bool:
        """Check if connection needs a health check."""
        return time.time() - self.last_health_check > interval_seconds


# =============================================================================
# MCP Server Manager
# =============================================================================


class MCPServerManager:
    """
    Manages MCP server connections and tool discovery.

    Lifecycle:
    1. Initialize with server configs
    2. Call connect_all() to establish connections
    3. Use get_tools_for_node() to get LangChain tools
    4. Call close_all() on cleanup

    Example:
        ```python
        manager = MCPServerManager(server_configs)
        await manager.connect_all()

        tools = manager.get_tools_for_node([
            MCPToolsReference(server="data-platform", tools=["query"])
        ])

        # Use tools with LangChain agent...

        await manager.close_all()
        ```

    Thread Safety:
        Connection management is async and uses locks for thread safety.
        Tool invocation is async and thread-safe.
    """

    def __init__(
            self,
            server_configs: Dict[str, MCPServerConfig],
            environment: Optional[str] = None,
    ):
        """
        Initialize MCP server manager.

        Each MCPServerManager instance has its own HTTP client pool for
        session isolation in multi-tenant deployments.

        Args:
            server_configs: Dict mapping server names to configurations
            environment: Optional environment name for config resolution.
                        Falls back to MCP_ENV environment variable.
        """
        self._server_configs = server_configs
        self._environment = environment or os.environ.get("MCP_ENV")
        self._connections: Dict[str, MCPConnection] = {}
        self._lock = asyncio.Lock()
        self._http_pool = HTTPClientPool()  # Instance-owned, not shared

    async def connect_all(self) -> None:
        """
        Establish connections to all configured MCP servers.

        Discovers tools from each server and caches definitions.

        Raises:
            MCPConnectionError: If any server fails to connect.
        """
        async with self._lock:
            for name, config in self._server_configs.items():
                try:
                    resolved_config = config.resolve_for_environment(self._environment)
                    connection = await self._connect_server(name, resolved_config)
                    self._connections[name] = connection
                    print(f"  MCP server '{name}': {len(connection.tools)} tools available")
                except Exception as e:
                    raise MCPConnectionError(name, str(e)) from e

    async def _connect_server(
            self,
            name: str,
            config: MCPServerConfig,
    ) -> MCPConnection:
        """
        Connect to a single MCP server based on transport type.

        Args:
            name: Server name for logging
            config: Resolved server configuration

        Returns:
            Active connection with discovered tools
        """
        if config.transport == MCPTransport.STDIO:
            return await self._connect_stdio(name, config)
        elif config.transport == MCPTransport.SSE:
            return await self._connect_sse(name, config)
        elif config.transport == MCPTransport.STREAMABLE_HTTP:
            return await self._connect_streamable_http(name, config)
        else:
            raise ValueError(f"Unsupported transport: {config.transport}")

    async def _connect_stdio(
            self,
            name: str,
            config: MCPServerConfig,
    ) -> MCPConnection:
        """Connect to stdio-based MCP server (local subprocess)."""
        # Prepare environment variables with expansion
        env = None
        if config.env:
            env = {k: os.path.expandvars(v) for k, v in config.env.items()}

        server_params = StdioServerParameters(
            command=config.command,
            args=config.args,
            env=env,
        )

        # Create the client context - starts the subprocess
        client_ctx = stdio_client(server_params)
        read, write = await client_ctx.__aenter__()

        # Create session
        session_ctx = ClientSession(read, write)
        session = await session_ctx.__aenter__()

        # Initialize the MCP connection
        await session.initialize()

        # Discover available tools
        tools = await self._discover_tools(name, session)

        # Create cleanup function
        async def cleanup():
            try:
                await session_ctx.__aexit__(None, None, None)
            except Exception:
                pass
            try:
                await client_ctx.__aexit__(None, None, None)
            except Exception:
                pass

        return MCPConnection(
            server_name=name,
            config=config,
            session=session,
            tools=tools,
            _cleanup=cleanup,
            _client_ctx=client_ctx,
            _session_ctx=session_ctx,
        )

    async def _connect_sse(
            self,
            name: str,
            config: MCPServerConfig,
    ) -> MCPConnection:
        """
        Connect to SSE-based MCP server (remote).

        SSE (Server-Sent Events) transport is used for remote MCP servers
        that support the SSE protocol for real-time communication.

        Supports authentication via:
        - Bearer token
        - API key
        - Basic auth
        - OAuth2 client credentials

        Note: mTLS is not supported for SSE transport (use Streamable HTTP instead).

        Args:
            name: Server name for logging
            config: Resolved server configuration with url and optional auth

        Returns:
            Active connection with discovered tools
        """
        if not config.url:
            raise ValueError(f"SSE transport requires 'url' for server '{name}'")

        # Check for unsupported mTLS
        if config.auth and config.auth.type == A2AAuthType.MTLS:
            raise MCPConnectionError(
                name,
                "mTLS authentication is not supported for SSE transport. "
                "Use Streamable HTTP transport with mTLS instead."
            )

        # Build headers with authentication (may fetch OAuth2 token)
        headers = await self._build_auth_headers(name, config)

        # Create the SSE client context
        client_ctx = sse_client(url=config.url, headers=headers)
        read, write = await client_ctx.__aenter__()

        # Create session
        session_ctx = ClientSession(read, write)
        session = await session_ctx.__aenter__()

        # Initialize the MCP connection
        await session.initialize()

        # Discover available tools
        tools = await self._discover_tools(name, session)

        # Create cleanup function
        async def cleanup():
            try:
                await session_ctx.__aexit__(None, None, None)
            except Exception:
                pass
            try:
                await client_ctx.__aexit__(None, None, None)
            except Exception:
                pass

        return MCPConnection(
            server_name=name,
            config=config,
            session=session,
            tools=tools,
            _cleanup=cleanup,
            _client_ctx=client_ctx,
            _session_ctx=session_ctx,
        )

    async def _connect_streamable_http(
            self,
            name: str,
            config: MCPServerConfig,
    ) -> MCPConnection:
        """
        Connect to Streamable HTTP MCP server (remote).

        Streamable HTTP is the recommended transport for production MCP servers,
        superseding SSE for better reliability and broader compatibility.

        Supports authentication via:
        - Bearer token
        - API key
        - Basic auth
        - OAuth2 client credentials
        - mTLS (mutual TLS with client certificates)

        Args:
            name: Server name for logging
            config: Resolved server configuration with url and optional auth

        Returns:
            Active connection with discovered tools
        """
        if not config.url:
            raise ValueError(f"Streamable HTTP transport requires 'url' for server '{name}'")

        # Build headers with authentication (may fetch OAuth2 token)
        headers = await self._build_auth_headers(name, config)

        # Handle mTLS - requires custom httpx client
        http_client = None
        if config.auth and config.auth.type == A2AAuthType.MTLS:
            http_client = _build_httpx_client_for_mtls(config, config.timeout)

        # Create the Streamable HTTP client context
        # Note: mTLS support depends on MCP SDK accepting httpx_client parameter
        if http_client:
            # Try to use custom client if SDK supports it
            try:
                client_ctx = streamable_http_client(
                    url=config.url,
                    headers=headers,
                    httpx_client=http_client,
                )
            except TypeError:
                # SDK doesn't support httpx_client parameter, fall back
                print(f"  Warning: MCP SDK doesn't support custom httpx client for mTLS")
                print(f"    Using headers-only auth. mTLS may not work correctly.")
                await http_client.aclose()
                client_ctx = streamable_http_client(url=config.url, headers=headers)
        else:
            client_ctx = streamable_http_client(url=config.url, headers=headers)

        read, write, _ = await client_ctx.__aenter__()

        # Create session
        session_ctx = ClientSession(read, write)
        session = await session_ctx.__aenter__()

        # Initialize the MCP connection
        await session.initialize()

        # Discover available tools
        tools = await self._discover_tools(name, session)

        # Create cleanup function
        async def cleanup():
            try:
                await session_ctx.__aexit__(None, None, None)
            except Exception:
                pass
            try:
                await client_ctx.__aexit__(None, None, None)
            except Exception:
                pass
            if http_client:
                try:
                    await http_client.aclose()
                except Exception:
                    pass

        return MCPConnection(
            server_name=name,
            config=config,
            session=session,
            tools=tools,
            _cleanup=cleanup,
            _client_ctx=client_ctx,
            _session_ctx=session_ctx,
        )

    async def _build_auth_headers(
            self,
            server_name: str,
            config: MCPServerConfig,
    ) -> Dict[str, str]:
        """
        Build HTTP headers including authentication.

        Supports:
        - Bearer token authentication
        - API key authentication (custom header)
        - Basic authentication (username:password)
        - OAuth2 client credentials flow (fetches token dynamically)

        Note: mTLS is handled separately via custom httpx client.

        Args:
            server_name: Server name (used for OAuth2 token caching)
            config: Server configuration with optional auth settings

        Returns:
            Dict of HTTP headers to include in requests
        """
        headers = dict(config.headers or {})

        if config.auth:
            auth = config.auth
            if auth.type == A2AAuthType.BEARER:
                token = os.path.expandvars(auth.token) if auth.token else ""
                headers["Authorization"] = f"Bearer {token}"

            elif auth.type == A2AAuthType.API_KEY:
                header_name = auth.header_name or "X-API-Key"
                token = os.path.expandvars(auth.token) if auth.token else ""
                headers[header_name] = token

            elif auth.type == A2AAuthType.BASIC:
                username = os.path.expandvars(auth.username) if auth.username else ""
                password = os.path.expandvars(auth.password) if auth.password else ""
                credentials = f"{username}:{password}"
                encoded = base64.b64encode(credentials.encode()).decode()
                headers["Authorization"] = f"Basic {encoded}"

            elif auth.type == A2AAuthType.OAUTH2_CLIENT_CREDENTIALS:
                # Fetch OAuth2 token using client credentials flow
                if auth.oauth2:
                    try:
                        token = await _fetch_oauth2_token(
                            server_name=server_name,
                            oauth2_config=auth.oauth2,
                            timeout=config.timeout,
                        )
                        headers["Authorization"] = f"Bearer {token}"
                    except Exception as e:
                        raise MCPConnectionError(
                            server_name,
                            f"OAuth2 token fetch failed: {e}"
                        )
                else:
                    raise MCPConnectionError(
                        server_name,
                        "OAuth2 authentication requires 'oauth2' config with token_url, client_id, client_secret"
                    )

            elif auth.type == A2AAuthType.MTLS:
                # mTLS is handled at the transport level, not via headers
                # Headers can still be added, but cert config is separate
                pass

        return headers

    async def _discover_tools(
            self,
            server_name: str,
            session: ClientSession,
    ) -> Dict[str, MCPToolDefinition]:
        """
        Discover available tools from MCP server.

        Args:
            server_name: Server name for tool definitions
            session: Active MCP session

        Returns:
            Dict mapping tool names to definitions
        """
        result = await session.list_tools()

        tools: Dict[str, MCPToolDefinition] = {}
        for tool in result.tools:
            tool_def = MCPToolDefinition(
                name=tool.name,
                description=tool.description or f"MCP tool: {tool.name}",
                input_schema=tool.inputSchema if tool.inputSchema else {},
                server_name=server_name,
            )
            tools[tool.name] = tool_def

        return tools

    def get_tools_for_node(
            self,
            mcp_tools_refs: List[MCPToolsReference],
    ) -> List[BaseTool]:
        """
        Get LangChain tools for a node based on MCP tool references.

        Args:
            mcp_tools_refs: List of MCP tool references from node config

        Returns:
            List of LangChain BaseTool instances ready for agent use

        Raises:
            ValueError: If referenced server is not connected
        """
        langchain_tools: List[BaseTool] = []

        for ref in mcp_tools_refs:
            if ref.server not in self._connections:
                raise ValueError(
                    f"MCP server '{ref.server}' not connected. "
                    f"Connected servers: {list(self._connections.keys())}"
                )

            connection = self._connections[ref.server]
            tool_filter = ref.get_tool_filter()
            alias_map = ref.get_alias_map()

            for tool_name, tool_def in connection.tools.items():
                # Apply filter - skip if not in requested tools
                if tool_filter is not None and tool_name not in tool_filter:
                    continue

                # Apply alias if specified
                effective_name = alias_map.get(tool_name, tool_name)

                # Create tool definition with alias
                tool_def_with_alias = MCPToolDefinition(
                    name=tool_def.name,
                    description=tool_def.description,
                    input_schema=tool_def.input_schema,
                    server_name=tool_def.server_name,
                    alias=effective_name if effective_name != tool_name else None,
                )

                # Create LangChain tool
                lc_tool = self._create_langchain_tool(tool_def_with_alias, connection)
                langchain_tools.append(lc_tool)

        return langchain_tools

    def get_tool_documentation(
            self,
            mcp_tools_refs: List[MCPToolsReference],
            format: str = "markdown",
    ) -> str:
        """
        Generate human-readable documentation for MCP tools.

        Creates formatted documentation from cached MCP tool definitions,
        suitable for automatic injection into system prompts. This eliminates
        the need to manually document MCP tools in system prompts.

        The documentation includes:
        - Tool names and descriptions
        - Parameter details (type, required/optional, description)
        - Server context if configured (domain-specific hints)

        Args:
            mcp_tools_refs: List of MCP tool references from node config
            format: Output format:
                - "markdown": Detailed format with headers and parameter lists
                - "compact": Brief single-line format per tool

        Returns:
            Formatted documentation string for system prompt injection

        Raises:
            ValueError: If referenced server is not connected

        Example output (markdown format):
            ### search
            Semantic search for documents.

            **Parameters:**
            - `app_id` (string, required): Application identifier
            - `query` (string, required): Search query
            - `limit` (integer, optional): Maximum results
        """
        docs = []
        contexts = []

        for ref in mcp_tools_refs:
            if ref.server not in self._connections:
                raise ValueError(
                    f"MCP server '{ref.server}' not connected. "
                    f"Connected servers: {list(self._connections.keys())}"
                )

            connection = self._connections[ref.server]
            tool_filter = ref.get_tool_filter()
            alias_map = ref.get_alias_map()

            # Collect server context if configured
            if connection.config.context:
                contexts.append(connection.config.context.strip())

            for tool_name, tool_def in connection.tools.items():
                # Apply filter - skip if not in requested tools
                if tool_filter is not None and tool_name not in tool_filter:
                    continue

                # Apply alias if specified
                effective_name = alias_map.get(tool_name, tool_name)

                # Format tool documentation
                doc = self._format_tool_doc(tool_def, effective_name, format)
                docs.append(doc)

        # Build final output with context first, then tools
        sections = []
        if contexts:
            sections.append("\n\n".join(contexts))
        if docs:
            sections.append("\n\n".join(docs))

        return "\n\n".join(sections)

    def _format_tool_doc(
            self,
            tool_def: MCPToolDefinition,
            effective_name: str,
            format: str,
    ) -> str:
        """
        Format a single tool's documentation.

        Args:
            tool_def: Tool definition from MCP server
            effective_name: Name as seen by the agent (may be aliased)
            format: Output format ("markdown" or "compact")

        Returns:
            Formatted documentation string for this tool
        """
        schema = tool_def.input_schema
        properties = schema.get("properties", {})
        required = set(schema.get("required", []))

        if format == "markdown":
            lines = [
                f"### {effective_name}",
                tool_def.description,
                "",
                "**Parameters:**",
            ]

            if not properties:
                lines.append("- None")
            else:
                for param_name, param_info in properties.items():
                    param_type = param_info.get("type", "any")
                    # Handle union types (e.g., ["string", "null"])
                    if isinstance(param_type, list):
                        param_type = "/".join(t for t in param_type if t != "null")
                    param_desc = param_info.get("description", "")
                    req_marker = "required" if param_name in required else "optional"
                    lines.append(
                        f"- `{param_name}` ({param_type}, {req_marker}): {param_desc}"
                    )

            return "\n".join(lines)

        else:  # compact format
            params = []
            for param_name, param_info in properties.items():
                param_type = param_info.get("type", "any")
                if isinstance(param_type, list):
                    param_type = "/".join(t for t in param_type if t != "null")
                req = "*" if param_name in required else ""
                params.append(f"{param_name}{req}:{param_type}")

            params_str = ", ".join(params) if params else ""
            return f"- {effective_name}({params_str}): {tool_def.description}"

    def _create_langchain_tool(
            self,
            tool_def: MCPToolDefinition,
            connection: MCPConnection,
    ) -> BaseTool:
        """
        Create a LangChain tool that invokes the MCP tool.

        Converts MCP JSON Schema to Pydantic model for LangChain compatibility.

        Args:
            tool_def: Tool definition from MCP server
            connection: Active connection for invocation

        Returns:
            LangChain StructuredTool that calls the MCP server
        """
        # Build Pydantic model from JSON Schema for input validation
        args_model = self._schema_to_pydantic(
            tool_def.effective_name,
            tool_def.input_schema,
        )

        # Capture references for closure
        original_name = tool_def.name
        server_session = connection.session
        server_config = connection.config

        # Create async invoke function
        async def invoke_mcp_tool(**kwargs) -> str:
            """Invoke MCP tool and return result."""
            try:
                # Filter out None values - MCP servers may reject null for optional params
                filtered_kwargs = {k: v for k, v in kwargs.items() if v is not None}
                result = await self._call_tool_with_retry(
                    server_session,
                    server_config,
                    original_name,
                    filtered_kwargs,
                )
                return self._format_tool_result(result)
            except Exception as e:
                # Return error to agent instead of crashing
                return f"Tool error: {type(e).__name__}: {str(e)}"

        # Create StructuredTool with the Pydantic args schema
        return StructuredTool(
            name=tool_def.effective_name,
            description=tool_def.description,
            args_schema=args_model,
            coroutine=invoke_mcp_tool,
        )

    async def _call_tool_with_retry(
            self,
            session: ClientSession,
            config: MCPServerConfig,
            tool_name: str,
            arguments: Dict[str, Any],
    ) -> CallToolResult:
        """
        Call MCP tool with retry logic.

        Args:
            session: MCP client session
            config: Server config for timeout/retry settings
            tool_name: Tool to call
            arguments: Tool arguments

        Returns:
            Tool call result
        """
        retry_config = config.retry or RetryConfig()
        timeout = config.timeout

        async for attempt in AsyncRetrying(
                stop=stop_after_attempt(retry_config.max_attempts),
                wait=wait_exponential(
                    multiplier=retry_config.backoff,
                    max=retry_config.max_backoff,
                ),
                retry=retry_if_exception_type((TimeoutError, ConnectionError, OSError)),
                reraise=True,
        ):
            with attempt:
                # Call with timeout
                result = await asyncio.wait_for(
                    session.call_tool(tool_name, arguments=arguments),
                    timeout=timeout,
                )
                return result

        # Should not reach here due to reraise=True
        raise MCPToolError(tool_name, "unknown", "Retry exhausted")

    def _schema_to_pydantic(
            self,
            tool_name: str,
            json_schema: Dict[str, Any],
    ) -> type[BaseModel]:
        """
        Convert JSON Schema to Pydantic model.

        Handles common JSON Schema patterns used in MCP tools.

        Args:
            tool_name: Tool name for model naming
            json_schema: JSON Schema from MCP tool definition

        Returns:
            Dynamically created Pydantic model class
        """
        properties = json_schema.get("properties", {})
        required = set(json_schema.get("required", []))

        # Build field definitions for Pydantic
        field_definitions: Dict[str, Any] = {}

        for prop_name, prop_schema in properties.items():
            python_type = self._json_type_to_python(prop_schema)
            description = prop_schema.get("description", "")

            if prop_name in required:
                # Required field - use ... as default
                field_definitions[prop_name] = (
                    python_type,
                    Field(..., description=description),
                )
            else:
                # Optional field - use None as default
                field_definitions[prop_name] = (
                    Optional[python_type],
                    Field(default=None, description=description),
                )

        # Create dynamic Pydantic model
        # Sanitize tool name for valid Python class name
        safe_name = tool_name.replace("-", "_").replace(".", "_").replace(" ", "_")
        model_name = f"{safe_name.title().replace('_', '')}Args"

        return create_model(model_name, **field_definitions)

    def _json_type_to_python(self, schema: Dict[str, Any]) -> type:
        """
        Map JSON Schema type to Python type.

        Args:
            schema: JSON Schema property definition

        Returns:
            Corresponding Python type
        """
        json_type = schema.get("type", "string")

        type_map = {
            "string": str,
            "integer": int,
            "number": float,
            "boolean": bool,
            "array": list,
            "object": dict,
            "null": type(None),
        }

        # Handle union types (e.g., ["string", "null"])
        if isinstance(json_type, list):
            # Use first non-null type
            for t in json_type:
                if t != "null":
                    return type_map.get(t, Any)
            return type(None)

        return type_map.get(json_type, Any)

    def _format_tool_result(self, result: CallToolResult) -> str:
        """
        Format MCP tool result for LangChain.

        Extracts text content from MCP response format.

        Args:
            result: Raw MCP tool call result

        Returns:
            Formatted string result for the agent
        """
        if result.isError:
            # Extract error message
            if isinstance(result.content, list):
                error_texts = []
                for item in result.content:
                    if hasattr(item, "text"):
                        error_texts.append(item.text)
                    else:
                        error_texts.append(str(item))
                return f"Error: {' '.join(error_texts)}"
            return f"Error: {result.content}"

        # Extract text content from result
        if isinstance(result.content, list):
            texts = []
            for item in result.content:
                if hasattr(item, "text"):
                    texts.append(item.text)
                elif hasattr(item, "data"):
                    # Binary/blob content
                    texts.append(f"[Binary data: {len(item.data)} bytes]")
                else:
                    texts.append(str(item))
            return "\n".join(texts)

        return str(result.content)

    async def close_all(self) -> None:
        """Close all MCP server connections."""
        async with self._lock:
            for name, connection in self._connections.items():
                try:
                    await connection.close()
                    print(f"  MCP server '{name}' disconnected")
                except Exception as e:
                    print(f"  Warning: Error closing MCP server '{name}': {e}")
            self._connections.clear()

        # Close this instance's HTTP client pool
        await self._http_pool.close_all()

    def get_server_names(self) -> List[str]:
        """Get list of connected server names."""
        return list(self._connections.keys())

    def get_tool_count(self, server_name: str) -> int:
        """Get number of tools available from a server."""
        if server_name not in self._connections:
            return 0
        return len(self._connections[server_name].tools)

    def get_all_tools(self, server_name: str) -> List[str]:
        """Get list of all tool names from a server."""
        if server_name not in self._connections:
            return []
        return list(self._connections[server_name].tools.keys())

    def is_connected(self, server_name: str) -> bool:
        """Check if a server is connected."""
        return server_name in self._connections

    def get_connection_status(self, server_name: str) -> ConnectionStatus:
        """
        Get the connection status for a server.

        Args:
            server_name: Name of the MCP server

        Returns:
            ConnectionStatus enum value
        """
        if server_name not in self._connections:
            return ConnectionStatus.DISCONNECTED
        return self._connections[server_name].status

    def get_all_status(self) -> Dict[str, ConnectionStatus]:
        """
        Get connection status for all servers.

        Returns:
            Dict mapping server names to their connection status
        """
        return {
            name: conn.status
            for name, conn in self._connections.items()
        }

    # =========================================================================
    # Health Checks and Reconnection (Phase 4)
    # =========================================================================

    async def health_check(self, server_name: str) -> bool:
        """
        Perform a health check on a specific server.

        Attempts to list tools from the server to verify connectivity.

        Args:
            server_name: Name of the MCP server to check

        Returns:
            True if server is healthy, False otherwise
        """
        if server_name not in self._connections:
            return False

        connection = self._connections[server_name]

        try:
            # Try to list tools as a ping
            await asyncio.wait_for(
                connection.session.list_tools(),
                timeout=connection.config.timeout,
            )
            connection.mark_healthy()
            return True
        except Exception as e:
            connection.mark_unhealthy()
            print(f"  Warning: Health check failed for '{server_name}': {e}")
            return False

    async def health_check_all(self) -> Dict[str, bool]:
        """
        Perform health checks on all connected servers.

        Returns:
            Dict mapping server names to health status (True=healthy)
        """
        results = {}
        for name in list(self._connections.keys()):
            results[name] = await self.health_check(name)
        return results

    async def reconnect(self, server_name: str) -> bool:
        """
        Attempt to reconnect to a specific server.

        Closes the existing connection (if any) and establishes a new one.

        Args:
            server_name: Name of the MCP server to reconnect

        Returns:
            True if reconnection succeeded, False otherwise
        """
        if server_name not in self._server_configs:
            print(f"  Unknown server '{server_name}'")
            return False

        async with self._lock:
            # Mark as reconnecting
            if server_name in self._connections:
                self._connections[server_name].status = ConnectionStatus.RECONNECTING

            # Close existing connection
            if server_name in self._connections:
                try:
                    await self._connections[server_name].close()
                except Exception:
                    pass
                del self._connections[server_name]

            # Reconnect
            try:
                config = self._server_configs[server_name]
                resolved_config = config.resolve_for_environment(self._environment)
                connection = await self._connect_server(server_name, resolved_config)
                self._connections[server_name] = connection
                print(f"  Reconnected to MCP server '{server_name}': {len(connection.tools)} tools")
                return True
            except Exception as e:
                print(f"  Failed to reconnect to '{server_name}': {e}")
                return False

    async def reconnect_unhealthy(self) -> Dict[str, bool]:
        """
        Attempt to reconnect all unhealthy servers.

        Returns:
            Dict mapping server names to reconnection success status
        """
        results = {}
        for name, connection in list(self._connections.items()):
            if connection.status == ConnectionStatus.UNHEALTHY:
                results[name] = await self.reconnect(name)
        return results

    async def refresh_tools(self, server_name: str) -> int:
        """
        Refresh tool definitions from a server.

        Useful when a server's available tools may have changed.

        Args:
            server_name: Name of the MCP server

        Returns:
            Number of tools discovered, or -1 if failed

        Raises:
            ValueError: If server is not connected
        """
        if server_name not in self._connections:
            raise ValueError(f"Server '{server_name}' is not connected")

        connection = self._connections[server_name]

        try:
            tools = await self._discover_tools(server_name, connection.session)
            connection.tools = tools
            connection.mark_healthy()
            print(f"  Refreshed tools for '{server_name}': {len(tools)} tools")
            return len(tools)
        except Exception as e:
            connection.mark_unhealthy()
            print(f"  Failed to refresh tools for '{server_name}': {e}")
            return -1

    async def ensure_connected(self, server_name: str) -> bool:
        """
        Ensure a server is connected, reconnecting if necessary.

        This is useful before making tool calls to ensure the connection
        is healthy.

        Args:
            server_name: Name of the MCP server

        Returns:
            True if server is connected and healthy, False otherwise
        """
        if server_name not in self._connections:
            return await self.reconnect(server_name) if server_name in self._server_configs else False

        connection = self._connections[server_name]

        # If healthy and recent check, skip
        if connection.status == ConnectionStatus.CONNECTED and not connection.needs_health_check():
            return True

        # Perform health check
        if await self.health_check(server_name):
            return True

        # Try to reconnect if unhealthy
        if connection.status == ConnectionStatus.UNHEALTHY:
            return await self.reconnect(server_name)

        return False

    async def start_health_monitor(
            self,
            interval_seconds: float = 60.0,
            auto_reconnect: bool = True,
    ) -> asyncio.Task:
        """
        Start a background task that monitors server health.

        Args:
            interval_seconds: Time between health checks
            auto_reconnect: Whether to auto-reconnect unhealthy servers

        Returns:
            The background task (can be cancelled to stop monitoring)
        """

        async def monitor_loop():
            while True:
                try:
                    await asyncio.sleep(interval_seconds)

                    # Check all servers
                    for name in list(self._connections.keys()):
                        connection = self._connections.get(name)
                        if connection and connection.needs_health_check(interval_seconds):
                            healthy = await self.health_check(name)

                            if not healthy and auto_reconnect:
                                await self.reconnect(name)

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"  Warning: Health monitor error: {e}")

        task = asyncio.create_task(monitor_loop())
        return task


# Type alias for external use
from typing import Any

Any = Any  # Re-export for type hints
