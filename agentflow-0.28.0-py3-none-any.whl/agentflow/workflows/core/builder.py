import json
from typing import Any, Dict, Callable, Optional, List

from langchain.agents import create_agent
from langchain_core.callbacks import dispatch_custom_event
from langchain_core.messages import AIMessage, ToolMessage
from langgraph.errors import GraphInterrupt
from langgraph.graph import StateGraph, START, END
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import RetryPolicy, CachePolicy

from .a2a_client import invoke_a2a_agent_streaming, DEFAULT_TIMEOUT
from .config_models import MiddlewareConfig, ExternalAgentsConfig, MCPToolsReference, RetryPolicyConfig, \
    NodeCachePolicyConfig
from .helpers import import_tools, sanitize_node_name, prepare_messages_for_agent
from .llm_factory import LLMFactory, LLMConfigResolver
from .mcp_client import MCPServerManager
from .middleware_factory import MiddlewareFactory
from .runtime_models import State


def build_default_routing_prompt(workflow_descriptions: Dict[str, str]) -> str:
    """Generate a system prompt for the router agent from workflow descriptions."""
    workflow_list = "\n".join(
        f"- {name}: {desc}" for name, desc in workflow_descriptions.items()
    )
    return (
        "You are an intelligent query router. Your job is to understand the "
        "user's query and decide whether it is relevant to one of the available "
        "workflows based on the workflow description.\n\n"
        f"Available workflows:\n{workflow_list}\n\n"
        "Rules:\n"
        "1. Only route to a workflow if the user's query is clearly relevant to "
        "that workflow's description.\n"
        "2. If the query matches a workflow, respond with ONLY the exact workflow "
        "name as listed above, nothing else.\n"
        "3. If the query does not match any workflow, do NOT route to a workflow. "
        "Instead, respond directly to the user explaining what topics you can "
        "help with."
    )


def create_orchestrator_router(workflow_names: List[str]) -> Callable:
    """Create a routing function that reads the router agent's AIMessage
    and maps it to a workflow subgraph.

    If the AIMessage contains a known workflow name, route to it.
    Otherwise route to END — the router's own response (already in
    message history) serves as the fallback reply to the user.
    """

    def router(state: State) -> str:
        messages = state.get("messages", [])
        for msg in reversed(messages):
            if isinstance(msg, AIMessage):
                content = msg.content.strip()
                for wf_name in workflow_names:
                    if wf_name.lower() in content.lower():
                        return wf_name
                break
        return END

    return router


async def call_agent(name: str, agent: Any, state: State) -> Dict[str, Any]:
    try:
        result = await agent.ainvoke(state)
    except GraphInterrupt:
        # Don't catch GraphInterrupt - let it bubble up to LangGraph for human-in-the-loop
        raise
    except Exception as e:
        import traceback
        error_details = f"{type(e).__name__}: {str(e)}"
        print(f"Error: Agent '{name}' failed: {error_details}")
        print(f"   Traceback:\n{traceback.format_exc()}")
        return {"messages": [AIMessage(content=f"Error in {name}: {error_details}")]}

    if result is None:
        result = AIMessage(content=f"{name} produced no output.")
    elif isinstance(result, str):
        result = AIMessage(content=result)
    elif isinstance(result, list):
        return {"messages": result}
    elif isinstance(result, dict):
        return result
    elif not isinstance(result, AIMessage):
        result = AIMessage(content=str(result))

    updated_state = {"messages": state.get("messages", []) + [result]}
    return updated_state


def create_router_function(routes_config: Dict[str, Any]) -> Callable:
    """
    Create a routing function for conditional edges.

    Args:
        routes_config: Dict with:
            - router_field: Field name to check in last tool result
            - routes: Dict mapping field values to node names
            - default: Optional default route (defaults to END)

    Returns:
        Function that routes based on state
    """
    router_field = routes_config.get("router_field", "status")
    routes = {k: v for k, v in routes_config.items()
              if k not in ["router_field", "default"]}
    default_route = routes_config.get("default", END)

    def router(state: State) -> str:
        """Route based on last tool result."""
        messages = state.get("messages", [])

        # Find the last tool message
        for msg in reversed(messages):
            if isinstance(msg, ToolMessage):
                try:
                    # Parse tool result
                    content = json.loads(msg.content) if isinstance(msg.content, str) else msg.content

                    # Check if it's a dict with the router field
                    if isinstance(content, dict):
                        # Check if router_field exists directly
                        if router_field in content:
                            field_value = str(content[router_field])
                            route = routes.get(field_value, default_route)
                            print(f"Routing: {router_field}={field_value} → {route}")
                            return route

                        # Check nested structure (e.g., {tool_name: {status: ...}})
                        for key, value in content.items():
                            if isinstance(value, dict) and router_field in value:
                                field_value = str(value[router_field])
                                route = routes.get(field_value, default_route)
                                print(f"Routing: {router_field}={field_value} → {route}")
                                return route

                except (json.JSONDecodeError, TypeError, KeyError) as e:
                    print(f"Router: Could not parse tool result: {e}")
                    continue

        # No matching field found, use default
        print(f"Routing: No {router_field} found, using default → {default_route}")
        return default_route

    return router


def _resolve_retry_policy(node_config: Dict[str, Any]) -> Optional[RetryPolicy]:
    """Convert a node's retry_policy config to a LangGraph RetryPolicy."""
    raw = node_config.get("retry_policy")
    if not raw:
        return None
    rpc = RetryPolicyConfig.model_validate(raw) if isinstance(raw, dict) else raw
    return RetryPolicy(
        initial_interval=rpc.initial_interval,
        backoff_factor=rpc.backoff_factor,
        max_interval=rpc.max_interval,
        max_attempts=rpc.max_attempts,
        jitter=rpc.jitter,
    )


def _resolve_cache_policy(node_config: Dict[str, Any]) -> Optional[CachePolicy]:
    """Convert a node's cache_policy config to a LangGraph CachePolicy."""
    raw = node_config.get("cache_policy")
    if not raw:
        return None
    cpc = NodeCachePolicyConfig.model_validate(raw) if isinstance(raw, dict) else raw
    return CachePolicy(ttl=cpc.ttl)


def build_workflow_graph(
        workflow_name: str,
        nodes: Dict[str, Any],
        node_configs: Dict[str, Dict[str, Any]],
        tools_module: str,
        llm_resolver: LLMConfigResolver,
        checkpointer: Optional[Any] = None,
        store: Optional[Any] = None,
        middleware_configs: Optional[Dict[str, List[MiddlewareConfig]]] = None,
        external_agents_config: Optional[ExternalAgentsConfig] = None,
        mcp_manager: Optional[MCPServerManager] = None,
        llm_registry: Optional[list] = None,
        interrupt_before: Optional[List[str]] = None,
        interrupt_after: Optional[List[str]] = None,
) -> CompiledStateGraph:
    """
    Build workflow graph from configuration.

    Supports:
    - Linear dependencies (depends_on)
    - Conditional routing (routes)
    - State persistence via checkpointer
    - Long-term memory via store (PostgreSQL only)
    - Per-node LLM configuration with hierarchy resolution
    - Per-node middleware configuration
    - External A2A agents with configurable timeout and retry
    - MCP server tools for direct data/service access

    Args:
        workflow_name: Name of the workflow (for LLM config resolution)
        nodes: Node definitions from workflow config
        node_configs: Node configurations (tools, prompts)
        tools_module: Module to import tools from
        llm_resolver: LLM config resolver for per-node LLM creation
        checkpointer: Optional pre-configured checkpointer instance (MemorySaver, SQLiteCheckPointer, etc.)
        store: Optional pre-configured store instance for long-term memory (PostgreSQL only)
        middleware_configs: Optional dict mapping node names to middleware configurations
        external_agents_config: Optional global configuration defaults for external A2A agents
        mcp_manager: Optional MCP server manager for MCP tool access

    Returns:
        Compiled state graph with optional checkpointer and store
    """
    builder = StateGraph(State)

    # First pass: Identify routing targets
    routing_targets = set()  # Nodes that are targets of conditional routing
    nodes_with_routes = {}

    for node_name, node_def in nodes.items():
        if "routes" in node_def:
            nodes_with_routes[node_name] = node_def.get("routes")
            # Collect all destination nodes from this router
            for key, dest in node_def["routes"].items():
                if key not in ["router_field", "default"] and dest != END:
                    routing_targets.add(dest)

    # Second pass: Add all nodes
    entry_nodes = []  # Nodes with no dependencies
    all_dependencies = set()  # All nodes that are depended upon

    for node_name, node_def in nodes.items():
        node_config = node_configs[node_name]

        # Detect node type: A2A external agent or local agent
        is_external = node_config.get("endpoint") is not None

        if is_external:
            # External A2A agent - direct invocation (no wrapper LLM needed)
            endpoint = node_config["endpoint"]
            auth_config = node_config.get("auth", {})

            # Convert Pydantic model to dict if needed
            if hasattr(auth_config, "model_dump"):
                auth_config = auth_config.model_dump(exclude_none=True)

            # Resolve timeout: per-node > global > default
            timeout = node_config.get("timeout")
            if timeout is None and external_agents_config:
                timeout = external_agents_config.timeout
            if timeout is None:
                timeout = DEFAULT_TIMEOUT

            # Resolve retry config: per-node > global > default
            retry_config = node_config.get("retry")
            if retry_config is None and external_agents_config and external_agents_config.retry:
                retry_config = external_agents_config.retry
            # Convert Pydantic model to dict if needed
            if retry_config and hasattr(retry_config, "model_dump"):
                retry_config = retry_config.model_dump(exclude_none=True)

            print(f"  ↗ External agent: {node_name} → {endpoint} (timeout={timeout}s)")

            # Create direct node function that invokes the external A2A agent
            # Supports streaming and multi-turn conversations via task_id tracking
            async def external_agent_node(
                    state: State,
                    _endpoint=endpoint,
                    _auth_config=None,
                    _timeout=timeout,
                    _retry_config=retry_config,
                    _name=node_name
            ) -> Dict[str, Any]:
                """Directly invoke external A2A agent with streaming and multi-turn support."""
                # Extract the last message to send to the external agent
                if _auth_config is None:
                    _auth_config = auth_config
                messages = state.get("messages", [])
                if not messages:
                    return {"messages": [AIMessage(content=f"No input message for {_name}")]}

                last_message = messages[-1]
                if hasattr(last_message, "content"):
                    query = last_message.content
                elif isinstance(last_message, dict):
                    query = last_message.get("content", str(last_message))
                else:
                    query = str(last_message)

                # Get existing task_id for multi-turn conversation continuity
                external_agent_tasks = state.get("external_agent_tasks", {})
                existing_task_id = external_agent_tasks.get(_name)

                try:
                    # Emit external agent start event for telemetry
                    dispatch_custom_event(
                        name="external_agent_start",
                        data={
                            "agent": _name,
                            "endpoint": _endpoint,
                            "message": query
                        }
                    )

                    # Stream response from external agent, emitting custom events for each chunk
                    chunks = []
                    new_task_id = None
                    async for chunk, task_id in invoke_a2a_agent_streaming(
                            endpoint=_endpoint,
                            message=query,
                            auth_config=_auth_config if _auth_config else None,
                            timeout=_timeout,
                            task_id=existing_task_id
                    ):
                        chunks.append(chunk)
                        if task_id:
                            new_task_id = task_id
                        # Emit custom event for streaming - captured by astream_events
                        dispatch_custom_event(
                            name="external_agent_stream",
                            data={
                                "agent": _name,
                                "chunk": chunk
                            }
                        )

                    full_response = "".join(chunks)

                    # Emit external agent end event for telemetry
                    dispatch_custom_event(
                        name="external_agent_end",
                        data={
                            "agent": _name,
                            "endpoint": _endpoint,
                            "response": full_response[:500] if full_response else ""  # Truncate for telemetry
                        }
                    )

                    # Build updated state with new task_id for multi-turn support
                    result: Dict[str, Any] = {
                        "messages": state.get("messages", []) + [AIMessage(content=full_response)]
                    }

                    # Store task_id for future multi-turn conversations
                    if new_task_id:
                        updated_tasks = dict(external_agent_tasks)
                        updated_tasks[_name] = new_task_id
                        result["external_agent_tasks"] = updated_tasks

                    return result
                except Exception as e:
                    error_msg = f"External agent '{_name}' failed: {type(e).__name__}: {str(e)}"
                    print(f"Error: {error_msg}")
                    # Emit external agent end with error for telemetry
                    dispatch_custom_event(
                        name="external_agent_end",
                        data={
                            "agent": _name,
                            "endpoint": _endpoint,
                            "response": "",
                            "error": f"{type(e).__name__}: {str(e)}"
                        }
                    )
                    return {"messages": [AIMessage(content=error_msg)]}

            retry = _resolve_retry_policy(node_config)
            cache = _resolve_cache_policy(node_config)
            builder.add_node(node_name, external_agent_node, retry_policy=retry,
                             cache_policy=cache)  # type: ignore[arg-type]

        else:
            # Local agent - standard processing
            # Resolve LLM config for this node (hierarchy: global → orchestrator → workflow → node)
            llm_config = llm_resolver.resolve_llm_config(
                workflow_name=workflow_name,
                node_name=node_name
            )

            # Create LLM instance for this node
            llm = LLMFactory.create_llm(llm_config)
            if llm_registry is not None:
                llm_registry.append(llm)

            # Collect tools from multiple sources: local tools and MCP tools
            tools = []

            # Local tools from tools_module
            if node_config.get("tools"):
                local_tools = import_tools(node_config["tools"], tools_module)
                tools.extend(local_tools)

            # MCP tools from MCP servers
            mcp_tool_refs = None
            if node_config.get("mcp_tools") and mcp_manager:
                # Parse MCP tool references
                mcp_tool_refs = [
                    MCPToolsReference.model_validate(ref) if isinstance(ref, dict) else ref
                    for ref in node_config["mcp_tools"]
                ]
                mcp_tools = mcp_manager.get_tools_for_node(mcp_tool_refs)
                tools.extend(mcp_tools)

                # Log MCP tool count
                server_names = set(ref.server for ref in mcp_tool_refs)
                print(f"    → {len(mcp_tools)} MCP tools from servers: {', '.join(server_names)}")

            # Convert empty list to None for create_agent compatibility
            if not tools:
                tools = None

            system_prompt = node_config["system_prompt"]

            # Auto-inject MCP tool documentation into system prompt
            if mcp_tool_refs and mcp_manager:
                tool_docs = mcp_manager.get_tool_documentation(mcp_tool_refs)
                if tool_docs:
                    system_prompt = f"{system_prompt}\n\n## Available MCP Tools\n\n{tool_docs}"

            # Sanitize node name for LLM APIs (remove spaces and special characters)
            sanitized_name = sanitize_node_name(node_name)

            # Get middleware for this node
            node_middleware = []
            if middleware_configs and node_name in middleware_configs:
                node_middleware = MiddlewareFactory.create_middleware_list(
                    middleware_configs[node_name],
                    llm_resolver=llm_resolver,
                )

            # Build agent kwargs - always include middleware to avoid None issues
            # in langchain's create_agent (defensive fix for iteration over None)
            agent_kwargs = {
                "model": llm,
                "tools": tools,
                "system_prompt": system_prompt,
                "name": sanitized_name,
                "middleware": node_middleware,  # Always include, even if empty
            }

            # Create agent
            agent = create_agent(**agent_kwargs)  # type: ignore

            async def agent_node(
                    state: State,
                    _agent=agent,
                    _name=node_name,
                    _llm_config=llm_config,
            ):
                prepared_state = dict(state)
                prepared_state["messages"] = prepare_messages_for_agent(
                    state.get("messages", []), _name, llm_config=_llm_config,
                )
                return await call_agent(_name, _agent, prepared_state)

            retry = _resolve_retry_policy(node_config)
            cache = _resolve_cache_policy(node_config)
            builder.add_node(node_name, agent_node, retry_policy=retry, cache_policy=cache)  # type: ignore[arg-type]

        # Track dependencies
        dependencies = node_def.get("depends_on", [])
        if not dependencies:
            entry_nodes.append(node_name)
        else:
            # Track which nodes are depended upon
            all_dependencies.update(dependencies)

    # Third pass: Add edges
    for node_name, node_def in nodes.items():
        # Handle regular dependencies
        dependencies = node_def.get("depends_on", [])

        # Skip regular edges if this node is a routing target
        if node_name not in routing_targets and dependencies:
            # Regular dependencies - only for non-routing-target nodes
            for dep in dependencies:
                builder.add_edge(dep, node_name)

        # Handle conditional routes
        if node_name in nodes_with_routes:
            routes_config = nodes_with_routes[node_name]
            router_func = create_router_function(routes_config)

            # Get all possible destination nodes
            dest_nodes = [v for k, v in routes_config.items()
                          if k not in ["router_field", "default"] and v != END]

            # Add conditional edges
            builder.add_conditional_edges(
                node_name,
                router_func,
                dest_nodes + [routes_config.get("default", END)]
            )

            # Mark these destination nodes as having dependencies
            all_dependencies.update(dest_nodes)

    # Third pass: Connect START and END
    # Connect START to entry nodes
    for entry_node in entry_nodes:
        builder.add_edge(START, entry_node)

    # Connect leaf nodes (nodes not depended upon and without routes) to END
    for node_name in nodes.keys():
        if node_name not in all_dependencies and node_name not in nodes_with_routes:
            builder.add_edge(node_name, END)

    # Build compile kwargs based on provided persistence resources
    compile_kwargs = {}
    if checkpointer is not None:
        compile_kwargs["checkpointer"] = checkpointer
    if store is not None:
        compile_kwargs["store"] = store
    if interrupt_before is not None:
        compile_kwargs["interrupt_before"] = interrupt_before
    if interrupt_after is not None:
        compile_kwargs["interrupt_after"] = interrupt_after

    return builder.compile(**compile_kwargs)
