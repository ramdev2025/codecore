"""
Middleware Factory for AgentFlow.

Provides factory methods for creating LangChain middleware instances
from YAML configuration.

See LangChain middleware documentation:
https://docs.langchain.com/oss/python/langchain/middleware/built-in
"""
import importlib
from typing import List, Any, Optional, Dict

from .config_models import MiddlewareConfig, BuiltinMiddleware


class MiddlewareFactory:
    """
    Factory for creating middleware instances from configuration.

    Supports both built-in LangChain middleware and custom middleware classes.
    """

    # Mapping of built-in middleware types to their LangChain class paths
    BUILTIN_CLASSES = {
        BuiltinMiddleware.SUMMARIZATION: "langchain.agents.middleware.SummarizationMiddleware",
        BuiltinMiddleware.HUMAN_IN_THE_LOOP: "langchain.agents.middleware.HumanInTheLoopMiddleware",
        BuiltinMiddleware.MODEL_CALL_LIMIT: "langchain.agents.middleware.ModelCallLimitMiddleware",
        BuiltinMiddleware.TOOL_CALL_LIMIT: "langchain.agents.middleware.ToolCallLimitMiddleware",
        BuiltinMiddleware.MODEL_FALLBACK: "langchain.agents.middleware.ModelFallbackMiddleware",
        BuiltinMiddleware.PII: "langchain.agents.middleware.PIIMiddleware",
        BuiltinMiddleware.TOOL_RETRY: "langchain.agents.middleware.ToolRetryMiddleware",
        BuiltinMiddleware.LLM_TOOL_SELECTOR: "langchain.agents.middleware.LLMToolSelectorMiddleware",
    }

    @staticmethod
    def create_middleware_list(
            configs: Optional[List[MiddlewareConfig]],
            llm_resolver: Optional[Any] = None,
    ) -> List[Any]:
        """
        Create a list of middleware instances from configurations.

        Args:
            configs: List of middleware configurations. Can be None or empty.
            llm_resolver: Optional LLMConfigResolver for resolving model strings
                to fully-configured LLM instances (inherits credentials, endpoint, etc.).

        Returns:
            List of instantiated middleware objects. Empty list if configs is None/empty
            or all middleware are disabled.
        """
        if not configs:
            return []

        middlewares = []
        for config in configs:
            if config.enabled:
                try:
                    middleware = MiddlewareFactory._create_single(config, llm_resolver=llm_resolver)
                    middlewares.append(middleware)
                except Exception as e:
                    # Log warning but continue with other middleware
                    middleware_type = config.type.value if config.type else config.custom.class_name
                    print(f"Warning: Failed to create middleware '{middleware_type}': {e}")

        return middlewares

    @staticmethod
    def _create_single(config: MiddlewareConfig, llm_resolver: Optional[Any] = None) -> Any:
        """
        Create a single middleware instance from configuration.

        Args:
            config: Middleware configuration specifying either a built-in type or custom class.
            llm_resolver: Optional LLMConfigResolver for resolving model strings.

        Returns:
            Instantiated middleware object.

        Raises:
            ImportError: If the middleware class cannot be imported.
            ValueError: If the configuration is invalid.
        """
        if config.type:
            # Built-in middleware
            class_path = MiddlewareFactory.BUILTIN_CLASSES.get(config.type)
            if not class_path:
                raise ValueError(f"Unknown built-in middleware type: {config.type}")

            # Get type-specific configuration and transform to LangChain API
            type_config = getattr(config, config.type.value, None)
            if type_config:
                raw_params = type_config.model_dump(exclude_none=True)
                params = MiddlewareFactory._transform_params(config.type, raw_params)
            else:
                params = {}

            # For middleware that needs an LLM (e.g. summarization), resolve the
            # model string to a fully-configured LLM instance so it inherits
            # credentials (azure_identity, api_key, endpoint, etc.) from the
            # global LLM configuration.
            if llm_resolver and "model" in params and isinstance(params["model"], str):
                params["model"] = MiddlewareFactory._resolve_model(
                    params["model"], llm_resolver
                )
        else:
            # Custom middleware
            class_path = config.custom.class_name
            params = config.custom.config

        # Import and instantiate the middleware class
        return MiddlewareFactory._import_and_instantiate(class_path, params)

    @staticmethod
    def _transform_params(middleware_type: BuiltinMiddleware, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform YAML config parameters to LangChain middleware API parameters.

        This handles differences between our YAML-friendly config and LangChain's API.

        Args:
            middleware_type: The type of middleware being configured.
            params: Raw parameters from YAML config.

        Returns:
            Transformed parameters matching LangChain middleware constructors.
        """
        if middleware_type == BuiltinMiddleware.SUMMARIZATION:
            # Transform trigger_messages/trigger_tokens to trigger tuple format
            transformed = {"model": params.get("model")}

            if "trigger_messages" in params:
                transformed["trigger"] = ("messages", params["trigger_messages"])
            elif "trigger_tokens" in params:
                transformed["trigger"] = ("tokens", params["trigger_tokens"])

            if "keep_messages" in params:
                transformed["keep"] = ("messages", params["keep_messages"])

            return transformed

        # For other middleware types, params should match the API directly
        return params

    @staticmethod
    def _import_and_instantiate(class_path: str, params: dict) -> Any:
        """
        Import a class by its fully qualified path and instantiate it.

        Args:
            class_path: Fully qualified class path (e.g., 'module.submodule.ClassName').
            params: Parameters to pass to the class constructor.

        Returns:
            Instantiated class object.

        Raises:
            ImportError: If the module or class cannot be imported.
            TypeError: If instantiation fails.
        """
        module_path, class_name = class_path.rsplit('.', 1)
        module = importlib.import_module(module_path)
        cls = getattr(module, class_name)
        return cls(**params)

    @staticmethod
    def _resolve_model(model_string: str, llm_resolver: Any) -> Any:
        """
        Resolve a model string (e.g. ``"azure_openai:gpt-4o"``) to a
        fully-configured LLM instance using the global LLM configuration.

        This ensures the middleware LLM inherits credentials, endpoint,
        and other settings from the workflow's LLM config hierarchy.

        Args:
            model_string: Provider-prefixed model string.
            llm_resolver: ``LLMConfigResolver`` instance.

        Returns:
            An LLM instance ready for use by the middleware.
        """
        from copy import deepcopy
        from .llm_factory import LLMFactory

        # Resolve the base (global) LLM config — inherits credentials etc.
        base_config = llm_resolver.resolve_llm_config()
        config = deepcopy(base_config)

        # Override model name if the middleware specifies one
        if ":" in model_string:
            _, model_name = model_string.split(":", 1)
            if config.config:
                config.config["model"] = model_name

        return LLMFactory.create_llm(config)
