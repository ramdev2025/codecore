import json
import logging
from typing import Any, Dict, List, Optional

from langgraph.errors import GraphInterrupt
from langgraph.types import Command

from .builder import build_workflow_graph, build_default_routing_prompt, create_orchestrator_router
from .callbacks import StructuredLoggingCallbackHandler, MetricsCallbackHandler, CostTrackingCallbackHandler
from .config_models import WorkflowYAMLConfig, PersistenceConfig, MiddlewareConfig
from .constants import DEFAULT_PATH_TO_SQLITE_DB
from .helpers import load_workflow_config
from .llm_factory import LLMFactory, LLMConfigResolver
from .mcp_client import MCPServerManager
from .persistence_manager import PersistenceFactory, BasePersistenceManager, PersistenceResources
from .runtime_models import WorkflowContext
from ..plugins.base import PluginManager
from .telemetry import WorkflowTelemetry


class BaseWorkflowOrchestrator:
    """Base orchestrator class with common routing and configuration logic."""

    def __init__(self, config_path: str):
        """
        Initialize the base workflow orchestrator.
        Args:
            config_path: Path to the workflow configuration YAML file
        """
        self.config_path = config_path

        # Load and parse the YAML config
        raw_config = load_workflow_config(config_path)
        self.parsed_config = WorkflowYAMLConfig.model_validate(raw_config)

        # Keep raw config for backward compatibility
        self.config = raw_config

        # tools_module is set by subclass (AsyncWorkflowOrchestrator)
        # It's not in workflow.yaml anymore (separation of concerns)
        self.tools_module = None

        # Build-time state for ``available_when`` predicate evaluation
        # of ``ui_tools`` (cross-backend parity with MAF / SK / etc.).
        # Per-call dynamic gating layers on top via ``AgentMiddleware``
        # in Phase 3. Subclasses (AsyncWorkflowOrchestrator) override.
        self.build_state: Dict[str, Any] = {}

        # AG-UI client tools are frontend-implemented. They become
        # ``interrupt(...)``-based stubs the LLM can call; the AG-UI
        # router resumes the interrupt with the browser's result. Off by
        # default — CLI / script call-sites never get them in the bound
        # tools list, so the LLM can't issue phantom calls nothing can
        # resume. The AG-UI router flips this to True at create time.
        self.bind_client_tools: bool = False

        # Agent config (resolved from 'agent' or 'orchestrator' keyword)
        agent_config = self.parsed_config.agent

        # Map delegate/workflow names to descriptions
        self.wf2desc: Dict[str, str] = {
            name: wf.description for name, wf in self.parsed_config.delegates.items()
        }

        # Build LLM config resolver
        self.llm_resolver = LLMConfigResolver(
            global_config=self.parsed_config.llm,
            orchestrator_config=agent_config.llm,
            workflow_configs={
                name: wf.llm for name, wf in self.parsed_config.delegates.items()
            },
            node_configs={
                name: node.llm for name, node in self.parsed_config.nodes.items()
            },
        )

        # Extract middleware configs per node
        self.middleware_configs: Dict[str, List[MiddlewareConfig]] = {}
        for node_name, node_config in self.parsed_config.nodes.items():
            if node_config.middleware:
                self.middleware_configs[node_name] = node_config.middleware

        # Store external agents config (global defaults for timeout/retry)
        self.external_agents_config = self.parsed_config.external_agents

        # Create agent's LLM
        agent_llm_config = self.llm_resolver.resolve_llm_config()
        self.llm = LLMFactory.create_llm(agent_llm_config)

        # Track all LLM instances for cleanup (prevents event-loop-closed errors)
        self._llm_instances = [self.llm]

        # Agent display name (for CLI output and tracing)
        default_name = "Orchestrator" if agent_config.has_delegates else "Agent"
        self.orchestrator_name = agent_config.name or default_name

        # Compiled graph (set by _build_graph)
        self.graph = None

        # Instantiate the Plugin Manager
        self._plugin_manager = PluginManager()

        # Discover and register plugins
        self._plugin_manager.discover_and_register_plugins()

        # Native OpenTelemetry subsystem (NOT a plugin). Self-disables unless
        # OTEL_TRACES_ENABLED=true. Owned by the orchestrator, which calls its
        # on_* methods directly at the lifecycle points below.
        self._telemetry = WorkflowTelemetry()

    def _build_graph(
            self,
            checkpointer: Optional[Any] = None,
            store: Optional[Any] = None,
            mcp_manager: Optional[MCPServerManager] = None,
    ):
        """
        Build the compiled graph.

        For standalone agents (no delegates): single agent node with tools.
        For delegating agents: router agent node → workflow subgraph nodes.

        Args:
            checkpointer: Optional pre-configured checkpointer instance
            store: Optional pre-configured store instance for long-term memory
            mcp_manager: Optional MCP server manager for MCP tool access
        """
        agent_config = self.parsed_config.agent

        if agent_config.has_delegates:
            self._build_delegating_agent(agent_config, checkpointer, store, mcp_manager)
        else:
            self._build_standalone_agent(agent_config, checkpointer, store, mcp_manager)

    def _resolve_tools(
        self,
        tool_names,
        mcp_tool_refs,
        mcp_manager,
        ui_tools=None,
        available_when=None,
        client_tools=None,
    ):
        """Resolve tool functions from tools_module, MCP servers, and ``ui_tools``.

        ``ui_tools`` is a :class:`agentflow.genui.UIToolsConfig` declaring a
        module of ``@ui_component``-decorated fetchers; each becomes a
        LangChain ``StructuredTool`` whose return is validated against the
        component's Pydantic class and emitted with the ``__component__``
        marker the workflows AG-UI bridge keys off.

        ``available_when`` is a ``{class_name: predicate}`` map. Predicates
        with build-time-falsy values cause their tools to be excluded
        from the agent's bound list at construction. Per-call dynamic
        gating (workflows-only) is layered separately as an
        ``AgentMiddleware`` in Phase 3.
        """
        from .config_models import MCPToolsReference

        tools = []

        # Local tools from tools_module
        if tool_names and self.tools_module:
            import importlib
            mod = importlib.import_module(self.tools_module)
            for name in tool_names:
                tool_fn = getattr(mod, name, None)
                if tool_fn is None:
                    raise ValueError(
                        f"Tool '{name}' not found in module '{self.tools_module}'"
                    )
                tools.append(tool_fn)

        # MCP tools — pass the full list to get_tools_for_node (same as builder.py)
        if mcp_tool_refs and mcp_manager:
            refs = [
                MCPToolsReference.model_validate(ref) if isinstance(ref, dict) else ref
                for ref in mcp_tool_refs
            ]
            mcp_tools = mcp_manager.get_tools_for_node(refs)
            tools.extend(mcp_tools)

        # Generative-UI components (cross-backend ``ui_tools`` schema).
        if ui_tools is not None:
            from agentflow.genui import filter_by_availability
            from agentflow.workflows.genui import resolve_ui_tools

            ui_resolved = resolve_ui_tools(ui_tools)
            # Build-time gating for parity with other backends. Per-call
            # dynamic gating (workflows-only advantage) layers on top via
            # ``AgentMiddleware`` in Phase 3.
            ui_resolved = filter_by_availability(
                ui_resolved, available_when, self.build_state
            )
            tools.extend(ui_resolved)

        # AG-UI client_tools — frontend-implemented. Each becomes a
        # ``StructuredTool`` whose body pauses the run via
        # :func:`langgraph.types.interrupt`; the AG-UI router resumes
        # the interrupt with the browser's tool result.
        #
        # Gated by ``self.bind_client_tools`` so CLI / script callers
        # don't bind tools nothing can resume. The router flips this on
        # at create time.
        if client_tools and self.bind_client_tools:
            from agentflow.workflows.agui.client_tools import build_client_tool_stubs

            tools.extend(build_client_tool_stubs(client_tools))
        elif client_tools:
            import logging
            logging.getLogger(__name__).info(
                "client_tools declared but bind_client_tools=False — "
                "skipping %d tool(s). The agent will not see them this run.",
                len(client_tools),
            )

        return tools or None

    def _build_standalone_agent(self, agent_config, checkpointer, store, mcp_manager):
        """Build a single-agent graph with tools (no routing, no delegation)."""
        from langchain.agents import create_agent
        from langgraph.graph import StateGraph, START, END
        from .helpers import sanitize_node_name
        from .runtime_models import State
        from .middleware_factory import MiddlewareFactory

        graph = StateGraph(State)

        # Resolve tools
        tools = self._resolve_tools(
            tool_names=agent_config.tools,
            mcp_tool_refs=agent_config.mcp_tools,
            mcp_manager=mcp_manager,
            ui_tools=agent_config.ui_tools,
            available_when=agent_config.available_when,
            client_tools=agent_config.client_tools,
        )

        # Create middleware
        middleware = MiddlewareFactory.create_middleware_list(
            agent_config.middleware,
            llm_resolver=self.llm_resolver,
        )

        # Auto-attach the workflows-only ``available_when`` middleware
        # for per-call dynamic gating. Build-time gating ran in
        # ``_resolve_tools``; this layer re-checks per-turn against
        # live graph state (so e.g. a tool can appear / disappear as
        # ``state.user_role`` changes mid-session).
        from agentflow.workflows.availability import build_availability_middleware

        availability_mw = build_availability_middleware(
            agent_config.available_when, agent_config.client_tools
        )
        if availability_mw is not None:
            middleware = (middleware or []) + [availability_mw]

        # Create the agent
        agent = create_agent(
            model=self.llm,
            tools=tools,
            system_prompt=agent_config.system_prompt or "",
            name=sanitize_node_name(self.orchestrator_name),
            middleware=middleware,
        )

        graph.add_node("agent", agent)
        graph.add_edge(START, "agent")
        graph.add_edge("agent", END)

        # Compile
        compile_kwargs = {}
        if checkpointer is not None:
            compile_kwargs["checkpointer"] = checkpointer
        if store is not None:
            compile_kwargs["store"] = store

        self.graph = graph.compile(**compile_kwargs)

    def _build_delegating_agent(self, agent_config, checkpointer, store, mcp_manager):
        """Build a router agent that delegates to workflow subgraphs."""
        from langchain.agents import create_agent
        from langgraph.graph import StateGraph, START, END
        from .helpers import sanitize_node_name
        from .runtime_models import State
        from .middleware_factory import MiddlewareFactory

        graph = StateGraph(State)

        # --- Router agent node ---
        router_middleware = MiddlewareFactory.create_middleware_list(
            agent_config.middleware,
            llm_resolver=self.llm_resolver,
        )

        # Auto-attach the workflows-only ``available_when`` middleware
        # for per-call dynamic gating (same as the standalone-agent path).
        from agentflow.workflows.availability import build_availability_middleware

        availability_mw = build_availability_middleware(
            agent_config.available_when, agent_config.client_tools
        )
        if availability_mw is not None:
            router_middleware = (router_middleware or []) + [availability_mw]

        router_prompt = agent_config.system_prompt or build_default_routing_prompt(self.wf2desc)

        # Resolve tools for the router (if the agent has its own tools)
        router_tools = self._resolve_tools(
            tool_names=agent_config.tools,
            mcp_tool_refs=agent_config.mcp_tools,
            mcp_manager=mcp_manager,
            ui_tools=agent_config.ui_tools,
            available_when=agent_config.available_when,
            client_tools=agent_config.client_tools,
        )

        router_agent = create_agent(
            model=self.llm,
            tools=router_tools,
            system_prompt=router_prompt,
            name=sanitize_node_name(self.orchestrator_name),
            middleware=router_middleware,
        )

        router_node_name = sanitize_node_name(self.orchestrator_name)
        graph.add_node(router_node_name, router_agent)
        graph.add_edge(START, router_node_name)

        # --- Workflow subgraph nodes ---
        # Use raw config for workflow building (build_workflow_graph expects raw dicts)
        raw_workflows = self.config.get("workflows") or self.config.get("delegates") or {}
        workflow_names = []
        for wf_name, wf_cfg in raw_workflows.items():
            parsed_wf = self.parsed_config.delegates.get(wf_name)
            wf_graph = build_workflow_graph(
                workflow_name=wf_name,
                nodes=wf_cfg["nodes"],
                node_configs=self.config.get("nodes", {}),
                tools_module=self.tools_module,
                llm_resolver=self.llm_resolver,
                checkpointer=None,  # Top-level graph owns the checkpointer
                store=store,
                middleware_configs=self.middleware_configs,
                external_agents_config=self.external_agents_config,
                mcp_manager=mcp_manager,
                llm_registry=self._llm_instances,
                interrupt_before=parsed_wf.interrupt_before if parsed_wf else None,
                interrupt_after=parsed_wf.interrupt_after if parsed_wf else None,
            )
            graph.add_node(wf_name, wf_graph)
            graph.add_edge(wf_name, END)
            workflow_names.append(wf_name)

        # --- Conditional edges: router → workflow based on AIMessage content ---
        router_fn = create_orchestrator_router(workflow_names)
        graph.add_conditional_edges(router_node_name, router_fn)

        # --- Compile ---
        compile_kwargs = {}
        if checkpointer is not None:
            compile_kwargs["checkpointer"] = checkpointer
        if store is not None:
            compile_kwargs["store"] = store

        self.graph = graph.compile(**compile_kwargs)

    @property
    def plugin_manager(self) -> PluginManager:
        return self._plugin_manager


class AsyncWorkflowOrchestrator(BaseWorkflowOrchestrator):
    """Async workflow orchestrator with SQLite and PostgreSQL persistence support."""

    def __init__(
            self,
            config_path: str,
            tools_module: Optional[str] = None,
            enable_persistence: bool = True,
            checkpointer_path: str = DEFAULT_PATH_TO_SQLITE_DB,
            persistence_config: Optional[PersistenceConfig] = None,
            build_state: Optional[Dict[str, Any]] = None,
            bind_client_tools: bool = False,
    ):
        """
        Initialize the async workflow orchestrator.

        Workflow definition comes from workflow.yaml (business logic).
        Deployment settings — including persistence — are provided as
        constructor parameters, CLI flags, or environment variables.
        Configuring persistence inside the YAML is deprecated; a
        ``persistence:`` block will be ignored with a warning so the
        same YAML can run unchanged across dev / staging / prod.

        Configuration priority (highest to lowest):
        1. persistence_config parameter (CLI flags / explicit override)
        2. Legacy parameters (enable_persistence, checkpointer_path),
           which themselves check POSTGRES_CONNECTION_STRING and
           CHECKPOINTER_DB_PATH before falling back to a local SQLite
           default.

        A ``persistence:`` section in workflow.yaml is no longer
        consulted — see ``_resolve_persistence_config`` for details.

        Note: This constructor does not set up async resources. Use one of these patterns:
        1. Factory method: orchestrator = await AsyncWorkflowOrchestrator.create(...)
        2. Context manager: async with AsyncWorkflowOrchestrator(...) as orchestrator:

        Args:
            config_path: Path to the workflow configuration YAML file
            tools_module: Python module path containing tool definitions (optional, only needed if agents use tools)
            enable_persistence: Whether to enable state persistence (default: True, legacy parameter)
            checkpointer_path: Path to SQLite database for checkpoints (default: .agentflow/checkpoints.db, legacy parameter)
            persistence_config: Optional explicit PersistenceConfig override (highest priority)
        """
        super().__init__(config_path)

        # Store deployment settings
        self.tools_module = tools_module
        self.enable_persistence = enable_persistence
        self.checkpointer_path = checkpointer_path
        self._persistence_config_override = persistence_config
        # Build-time state for ``available_when`` predicate evaluation
        # of ``ui_tools``. Build-time gating is parity with other
        # backends; per-call dynamic gating layers on top via
        # ``AgentMiddleware`` in Phase 3 (the workflows-only advantage).
        if build_state is not None:
            self.build_state = build_state

        # Opt-in: the AG-UI router sets this to True when calling
        # ``AsyncWorkflowOrchestrator.create``. Other call sites (CLI,
        # scripts) leave it False so client_tools stay filtered out.
        self.bind_client_tools = bind_client_tools

        # Initialize persistence resources storage
        self._persistence_manager: Optional[BasePersistenceManager] = None
        self._persistence_resources: Optional[PersistenceResources] = None
        self._checkpointer = None  # For backward compatibility

        # Initialize MCP server manager storage
        self._mcp_manager: Optional[MCPServerManager] = None

        # Callback handler references (populated per-run)
        self._last_metrics_handler = None
        self._last_cost_handler = None

    def _resolve_persistence_config(self) -> Optional[PersistenceConfig]:
        """
        Resolve the effective persistence configuration.

        Priority (highest to lowest):
        1. ``persistence_config`` parameter (CLI flags / Python API).
        2. (Deprecated) ``persistence:`` section in the YAML — emits a
           warning and is ignored. Persistence is infrastructure, not
           business logic; configuring it in YAML couples the agent to a
           single environment.
        3. None — falls back to legacy ``enable_persistence`` /
           ``checkpointer_path`` parameters, which themselves check
           env-var fallbacks (``POSTGRES_CONNECTION_STRING``,
           ``CHECKPOINTER_DB_PATH``) before defaulting to local SQLite.

        Returns:
            PersistenceConfig if configured via the explicit override,
            otherwise None to signal legacy / env-var resolution.
        """
        # Priority 1: Explicit override via constructor parameter
        if self._persistence_config_override is not None:
            return self._persistence_config_override

        # Priority 2 (deprecated): YAML persistence section. Warn and ignore.
        if self.parsed_config.persistence is not None:
            logging.getLogger(__name__).warning(
                "The 'persistence:' section in %s is deprecated and will be "
                "ignored. Persistence backend is an infrastructure concern "
                "and must be configured via CLI flags (--persistence / "
                "--db-path / --connection-string) or environment variables "
                "(POSTGRES_CONNECTION_STRING, CHECKPOINTER_DB_PATH). "
                "Remove the 'persistence:' section from your YAML to "
                "silence this warning.",
                self.config_path,
            )

        # Fall through to legacy resolution.
        return None

    async def async_init(self):
        """
        Async initialization for workflows with persistence and MCP servers.

        Supports both SQLite and PostgreSQL backends based on configuration.
        Configuration is resolved from multiple sources with priority:
        1. persistence_config parameter (CLI flags / explicit override)
        2. Legacy parameters (enable_persistence, checkpointer_path),
           with POSTGRES_CONNECTION_STRING / CHECKPOINTER_DB_PATH env-var
           fallbacks before defaulting to a local SQLite file.

        Note: a ``persistence:`` section in workflow.yaml is deprecated.
        It will be ignored with a warning so the same YAML can run
        unchanged across environments.

        Also initializes MCP server connections if configured.

        Returns:
            self for method chaining
        """
        # Resolve persistence configuration
        persistence_config = self._resolve_persistence_config()

        # Create persistence manager using factory
        self._persistence_manager = PersistenceFactory.create_manager(
            config=persistence_config,
            enable_persistence=self.enable_persistence,
            checkpointer_path=self.checkpointer_path,
        )

        # Set up persistence resources
        self._persistence_resources = await self._persistence_manager.setup()

        # Store checkpointer reference for backward compatibility
        self._checkpointer = self._persistence_resources.checkpointer

        # Initialize MCP servers if configured
        if self.parsed_config.mcp_servers:
            print("Connecting to MCP servers...")
            self._mcp_manager = MCPServerManager(
                server_configs=self.parsed_config.mcp_servers,
            )
            await self._mcp_manager.connect_all()

        # Build single compiled graph with router + workflow subgraphs
        self._build_graph(
            checkpointer=self._persistence_resources.checkpointer,
            store=self._persistence_resources.store,
            mcp_manager=self._mcp_manager,
        )

        # Log what was configured
        if self._persistence_resources.checkpointer is not None:
            print(f"Checkpointer enabled")
        if self._persistence_resources.store is not None:
            print(f"Store enabled")
        if self._mcp_manager is not None:
            server_count = len(self._mcp_manager.get_server_names())
            print(f"MCP servers connected: {server_count}")

        return self

    async def __aenter__(self):
        """
        Async context manager entry.

        Usage:
            async with AsyncWorkflowOrchestrator(...) as orchestrator:
                # Use orchestrator with SQLite persistence
                pass
        """
        await self.async_init()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Async context manager exit - cleanup checkpointer.
        """
        await self.cleanup()

    @classmethod
    async def create(
            cls,
            config_path: str,
            tools_module: Optional[str] = None,
            enable_persistence: bool = True,
            checkpointer_path: str = DEFAULT_PATH_TO_SQLITE_DB,
            persistence_config: Optional[PersistenceConfig] = None,
            build_state: Optional[Dict[str, Any]] = None,
            bind_client_tools: bool = False,
    ):
        """
        Async factory method for creating AsyncWorkflowOrchestrator.

        This is the recommended way to initialize the orchestrator in async contexts.

        Workflow definition comes from workflow.yaml (business logic).
        Deployment settings are provided as parameters or via YAML persistence section.

        Configuration priority (highest to lowest):
        1. persistence_config parameter (explicit override)
        2. persistence section in workflow.yaml
        3. Legacy parameters (enable_persistence, checkpointer_path)

        Args:
            config_path: Path to the workflow configuration YAML file
            tools_module: Python module path containing tool definitions (optional, only needed if agents use tools)
            enable_persistence: Whether to enable state persistence (default: True, legacy parameter)
            checkpointer_path: Path to SQLite database for checkpoints (default: .agentflow/checkpoints.db, legacy parameter)
            persistence_config: Optional explicit PersistenceConfig override (highest priority)

        Returns:
            Initialized AsyncWorkflowOrchestrator instance

        Example:
            ```python
            # Create orchestrator with deployment settings (legacy style)
            orchestrator = await AsyncWorkflowOrchestrator.create(
                config_path="workflow.yaml",
                tools_module="my_tools",
                enable_persistence=True,
                checkpointer_path=".agentflow/checkpoints.db"
            )

            # Or with explicit PostgreSQL config
            from agentflow.workflows.core.config_models import (
                PersistenceConfig, PersistenceBackend, PostgresConfig
            )
            orchestrator = await AsyncWorkflowOrchestrator.create(
                config_path="workflow.yaml",
                persistence_config=PersistenceConfig(
                    backend=PersistenceBackend.POSTGRES,
                    postgres=PostgresConfig(connection_string="${DATABASE_URL}")
                )
            )

            # Run workflow
            async for event in orchestrator.run(
                state={"messages": [{"role": "user", "content": "Hello"}]},
                config={"configurable": {"thread_id": "user-123"}}
            ):
                print(event)

            # Clean up when done
            await orchestrator.cleanup()
            ```
        """
        instance = cls(
            config_path=config_path,
            tools_module=tools_module,
            enable_persistence=enable_persistence,
            checkpointer_path=checkpointer_path,
            persistence_config=persistence_config,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )
        await instance.async_init()
        return instance

    async def _close_llm_clients(self):
        """Close underlying HTTP clients in LLM instances to prevent event-loop-closed errors."""
        for llm in self._llm_instances:
            # Try each known SDK client attribute:
            #   ChatAnthropic        → _async_client  (anthropic.AsyncAnthropic)
            #   ChatOpenAI/Azure     → root_async_client  (openai.AsyncOpenAI)
            for attr in ('_async_client', 'root_async_client'):
                try:
                    sdk_client = getattr(llm, attr, None)
                    if sdk_client is not None:
                        close = getattr(sdk_client, 'close', None)
                        if close and callable(close):
                            await close()
                except Exception:
                    pass  # Best-effort; OS cleans up regardless
        self._llm_instances.clear()

    async def cleanup(self):
        """
        Cleanup all resources (LLM clients, MCP connections, persistence, plugins).

        Call this when you're done with the orchestrator to ensure
        proper resource cleanup. Not needed if using async context manager.

        For LLMs: Closes underlying HTTP clients to prevent event-loop-closed errors.
        For MCP: Closes all MCP server connections.
        For SQLite: Releases the shared checkpointer reference (connection is reused).
        For PostgreSQL: Closes connection pools for both checkpointer and store.
        For Plugins: Calls shutdown() on all registered plugins.
        """
        # Close LLM HTTP clients first (must happen while event loop is still open)
        await self._close_llm_clients()

        # Close MCP server connections
        if self._mcp_manager is not None:
            print("Closing MCP server connections...")
            await self._mcp_manager.close_all()
            self._mcp_manager = None

        # Then cleanup persistence resources
        if self._persistence_manager is not None:
            await self._persistence_manager.cleanup()
            self._persistence_manager = None
            self._persistence_resources = None
            self._checkpointer = None

        # Finally, shut down plugins and flush the native OpenTelemetry subsystem.
        if self.plugin_manager is not None:
            self.plugin_manager.shutdown()
        if getattr(self, "_telemetry", None) is not None:
            self._telemetry.shutdown()

    def get_last_metrics(self) -> Optional[Dict[str, Any]]:
        """Return metrics from the most recent run, or None if metrics not enabled."""
        if self._last_metrics_handler:
            return self._last_metrics_handler.get_metrics()
        return None

    def get_last_cost(self) -> Optional[Dict[str, Any]]:
        """Return cost/token usage from the most recent run, or None if cost tracking not enabled."""
        if self._last_cost_handler:
            return self._last_cost_handler.get_usage()
        return None

    def _build_run_config(self, config: Optional[dict], recursion_limit: int, workflow_name: str) -> dict:
        """Build the config dict for graph.astream_events()."""
        run_config = config.copy() if config else {}
        run_config["recursion_limit"] = recursion_limit
        run_config.setdefault("metadata", {})
        run_config["metadata"]["workflow_version"] = self.parsed_config.metadata.version
        run_config["metadata"]["workflow_name"] = workflow_name

        execution_id = run_config.get("configurable", {}).get("thread_id", "default")
        run_config["metadata"]["execution_id"] = execution_id

        # Persist the caller identity with the checkpoint. ``principal_id`` rides
        # in ``configurable`` (propagates to tools for free); copying it into
        # ``metadata`` here guarantees it lands in the checkpointer's metadata
        # column — independent of any LangGraph version's configurable-copying
        # behavior — so runs are filterable by principal (scoped thread history).
        principal_id = run_config.get("configurable", {}).get("principal_id")
        if principal_id:
            run_config["metadata"]["principal_id"] = principal_id

        cb_config = self.parsed_config.callbacks
        handlers = list(run_config.get("callbacks", []) or [])
        self._last_metrics_handler = None
        self._last_cost_handler = None
        if cb_config:
            if cb_config.structured_logging:
                handlers.append(StructuredLoggingCallbackHandler(
                    execution_id=execution_id,
                    workflow_name=workflow_name,
                    redact_prompts=cb_config.redact_prompts,
                ))
            if cb_config.metrics:
                self._last_metrics_handler = MetricsCallbackHandler(execution_id=execution_id)
                handlers.append(self._last_metrics_handler)
            if cb_config.cost_tracking is not None:
                self._last_cost_handler = CostTrackingCallbackHandler(
                    max_total_tokens=cb_config.cost_tracking,
                )
                handlers.append(self._last_cost_handler)
        if handlers:
            run_config["callbacks"] = handlers

        return run_config

    def _map_event(self, event: dict, workflow_name: str, context: WorkflowContext,
                   stream_tokens: bool = False,
                   is_router: bool = False) -> Optional[List[dict]]:
        """Map a LangGraph astream_events v2 event to agentflow yield format.

        Returns a list of dicts to yield, or None if the event should be skipped.
        Fires plugin events as a side effect.

        When is_router=True, plugin events still fire (for tracing) but no
        events are yielded to the CLI — the router's routing decision is
        internal. If the router responds directly to the user (no workflow
        matched), run() handles yielding that separately.
        """
        kind = event["event"]
        metadata = event.get("metadata", {})
        name = event.get("name", "")

        def resolve_agent_name() -> str:
            checkpoint_ns = metadata.get("checkpoint_ns", "")
            if checkpoint_ns and ":" in checkpoint_ns:
                # checkpoint_ns format: "workflow:uuid|node:uuid" for nested nodes
                # Split on | to get segments, take the last segment's name (before :)
                segments = checkpoint_ns.split("|")
                agent = segments[-1].split(":")[0]
            else:
                agent = metadata.get("langgraph_node") or "Agent"
            return agent

        if kind == "on_chat_model_start":
            agent_name = resolve_agent_name()
            self._plugin_manager.emit_agent_start(context, agent_name, {})
            if stream_tokens:
                return [{"type": "agent_start", "workflow": workflow_name,
                         "name": agent_name, "content": ""}]

        elif kind == "on_chat_model_stream":
            if is_router or not stream_tokens:
                return None
            chunk = event.get("data", {}).get("chunk")
            if chunk and hasattr(chunk, "content") and chunk.content:
                return [{"type": "token", "workflow": workflow_name,
                         "name": resolve_agent_name(), "content": chunk.content}]

        elif kind == "on_chat_model_end":
            output = event.get("data", {}).get("output")
            if output and hasattr(output, "content") and output.content:
                agent_name = resolve_agent_name()
                result = {"content": output.content}
                if hasattr(output, "usage_metadata"):
                    result["usage"] = output.usage_metadata
                elif hasattr(output, "response_metadata") and output.response_metadata:
                    response_meta = output.response_metadata
                    if "token_usage" in response_meta:
                        result["usage"] = response_meta["token_usage"]
                    elif "usage" in response_meta:
                        result["usage"] = response_meta["usage"]

                self._plugin_manager.emit_agent_end(context, agent_name, result)

                events = []
                if not is_router:
                    # Yield the agent response content (not for router — its content is just the workflow name)
                    events.append({"type": "agent", "workflow": workflow_name,
                                   "name": agent_name, "content": output.content})
                # Always yield agent_end (carries usage/token metadata for CLI stats)
                agent_end_event = {"type": "agent_end", "workflow": workflow_name,
                                   "name": agent_name, "content": ""}
                if result.get("usage"):
                    agent_end_event["usage"] = result["usage"]
                events.append(agent_end_event)
                return events

        elif kind == "on_tool_start":
            tool_name = name or "Tool"
            inputs = event.get("data", {}).get("input", {})
            self._plugin_manager.emit_tool_call(context, tool_name, inputs)
            return [{"type": "tool_call", "workflow": workflow_name,
                     "name": tool_name, "args": inputs}]

        elif kind == "on_tool_end":
            tool_name = name or "Tool"
            output = event.get("data", {}).get("output", "")
            if hasattr(output, "content"):
                content = output.content
            elif isinstance(output, str):
                try:
                    content = json.loads(output)
                    if isinstance(content, dict) and tool_name in content:
                        content = content[tool_name]
                except (json.JSONDecodeError, TypeError):
                    content = output
            else:
                content = output

            self._plugin_manager.emit_tool_result(context, tool_name, content)
            return [{"type": "tool", "workflow": workflow_name,
                     "name": tool_name, "content": content}]

        elif kind == "on_custom_event":
            data = event.get("data", {})
            if name == "external_agent_stream":
                ext_agent_name = data.get("agent", "ExternalAgent")
                chunk = data.get("chunk", "")
                if chunk:
                    return [{"type": "token", "workflow": workflow_name,
                             "name": ext_agent_name, "content": chunk}]
            elif name == "external_agent_start":
                ext_agent_name = data.get("agent", "ExternalAgent")
                self._plugin_manager.emit_external_agent_start(
                    context, ext_agent_name, data.get("endpoint", ""), data.get("message", ""))
                self._telemetry.on_external_agent_start(
                    context, ext_agent_name, data.get("endpoint", ""), data.get("message", ""))
            elif name == "external_agent_end":
                ext_agent_name = data.get("agent", "ExternalAgent")
                self._plugin_manager.emit_external_agent_end(
                    context, ext_agent_name, data.get("endpoint", ""),
                    data.get("response", ""), data.get("error"))
                self._telemetry.on_external_agent_end(
                    context, ext_agent_name, data.get("endpoint", ""),
                    data.get("response", ""), data.get("error"))

        return None

    async def get_state(self, thread_id: str, workflow_name: str = None):
        """
        Get current state of a workflow execution (useful for interrupted workflows).

        Args:
            thread_id: The thread ID to get state for
            workflow_name: Deprecated — ignored, kept for backward compatibility

        Returns:
            Dictionary with current state, next steps, and metadata

        Raises:
            ValueError: If no checkpointer is configured (persistence disabled)
        """
        if self._checkpointer is None:
            raise ValueError(
                "Cannot get state: no checkpointer configured. "
                "Enable persistence to use state management features."
            )

        config = {"configurable": {"thread_id": thread_id}}
        state_snapshot = await self.graph.aget_state(config)

        # Handle created_at - might be datetime or string
        created_at = None
        if hasattr(state_snapshot, 'created_at') and state_snapshot.created_at:
            if hasattr(state_snapshot.created_at, 'isoformat'):
                created_at = state_snapshot.created_at.isoformat()
            else:
                created_at = str(state_snapshot.created_at)

        return {
            "values": state_snapshot.values,
            "next": state_snapshot.next,
            "tasks": state_snapshot.tasks,
            "metadata": state_snapshot.metadata,
            "created_at": created_at,
            "parent_config": state_snapshot.parent_config,
        }

    async def update_state(
            self,
            thread_id: str,
            updated_values: dict,
            workflow_name: str = None,
            as_node: str = None
    ):
        """
        Update state of an interrupted workflow before resuming.

        Args:
            thread_id: The thread ID to update
            updated_values: New values to merge into state
            workflow_name: Deprecated — ignored, kept for backward compatibility
            as_node: Optional node name to update state as (for simulating node execution)
        """
        config = {"configurable": {"thread_id": thread_id}}
        await self.graph.aupdate_state(config, updated_values, as_node=as_node)

    async def run(
            self,
            state: dict,
            config: dict = None,
            recursion_limit: int = 100,
            stream_tokens: bool = False,
            default_workflow: Optional[str] = None,
    ):
        """
        Run a workflow based on the user query.

        The single compiled graph handles routing (via the router agent node)
        and workflow execution. No separate route() call needed.

        Args:
            state: The initial state with messages OR a Command object for resuming from interrupt
            config: Optional config dict with thread_id and callbacks for persistence
            recursion_limit: Maximum number of tool calls/agent steps (default 100)
            stream_tokens: If True, stream individual tokens. If False, stream complete messages only.
            default_workflow: Optional workflow name hint (kept for backward compatibility)

        Yields:
            Dictionary with keys:
                - type: 'agent' | 'tool' | 'tool_call' | 'token' | 'agent_start' | 'agent_end'
                - workflow: Name of the workflow
                - name: Name of the agent or tool
                - content: The message content, tool result, or token
                - args: Tool arguments (only on 'tool_call' events)
        """
        is_resuming = isinstance(state, Command)
        plugin_state = {} if is_resuming else state

        workflow_name = default_workflow or self.orchestrator_name

        if is_resuming:
            execution_id = config.get("configurable", {}).get("thread_id", "default") if config else "default"
            principal_id = config.get("configurable", {}).get("principal_id") if config else None
            resume_context = WorkflowContext(execution_id=execution_id, workflow_name=workflow_name, principal_id=principal_id)
            self._plugin_manager.emit_hitl_end(
                resume_context,
                interrupt_type="approval",
                response=state.resume if hasattr(state, 'resume') else str(state)
            )
            self._telemetry.on_hitl_end(
                resume_context,
                interrupt_type="approval",
                response=state.resume if hasattr(state, 'resume') else str(state),
            )

        # Build run config (metadata, callbacks, recursion limit)
        run_config = self._build_run_config(config, recursion_limit, workflow_name)
        execution_id = run_config.get("configurable", {}).get("thread_id", "default")
        principal_id = run_config.get("configurable", {}).get("principal_id")
        context = WorkflowContext(execution_id=execution_id, workflow_name=workflow_name, principal_id=principal_id)

        if not is_resuming:
            self._plugin_manager.emit_workflow_start(context, plugin_state)

        # On resume, warn if the workflow version changed since the checkpoint was saved
        current_version = self.parsed_config.metadata.version
        if is_resuming and self._checkpointer is not None:
            try:
                snapshot = await self.graph.aget_state(run_config)
                saved_version = (snapshot.metadata or {}).get("workflow_version")
                if saved_version and saved_version != current_version:
                    logging.getLogger(__name__).warning(
                        f"Workflow version mismatch: checkpoint was saved with v{saved_version}, "
                        f"current workflow is v{current_version}. State may be incompatible."
                    )
            except Exception:
                pass

        # Known workflow names — used to detect when the router enters a workflow subgraph
        known_workflows = set(self.parsed_config.delegates.keys())
        in_router = True  # Suppress router events from CLI until a workflow starts
        router_response = None  # Buffer router's response for no-match fallback

        workflow_status = "completed"
        is_interrupted = False
        try:
            async for event in self.graph.astream_events(state, config=run_config, version="v2"):
                # Detect when the graph enters a workflow subgraph
                if event["event"] == "on_chain_start":
                    node = event.get("metadata", {}).get("langgraph_node")
                    if node and node in known_workflows:
                        in_router = False
                        workflow_name = node
                        context.workflow_name = workflow_name

                # Capture router's response for no-match fallback
                if in_router and event["event"] == "on_chat_model_end":
                    output = event.get("data", {}).get("output")
                    if output and hasattr(output, "content") and output.content:
                        router_response = output.content

                mapped = self._map_event(event, workflow_name, context, stream_tokens,
                                         is_router=in_router)
                if mapped:
                    for item in mapped:
                        yield item

            # If no workflow was matched, the router responded directly to the user
            if in_router and router_response:
                yield {
                    "type": "agent",
                    "workflow": self.orchestrator_name,
                    "name": self.orchestrator_name,
                    "content": router_response,
                }

        except GraphInterrupt:
            is_interrupted = True
            self._plugin_manager.emit_hitl_start(
                context,
                interrupt_type="approval",
                prompt="Workflow interrupted, waiting for human input"
            )
            self._telemetry.on_hitl_start(
                context,
                interrupt_type="approval",
                prompt="Workflow interrupted, waiting for human input",
            )
            raise
        except Exception as e:
            workflow_status = "error"
            self._plugin_manager.emit_error(context, e, {"state": plugin_state})
            self._telemetry.on_error(context, e, {"state": plugin_state})
            raise
        finally:
            if not is_interrupted:
                self._plugin_manager.emit_workflow_end(context, plugin_state, workflow_status)


# Backward compatibility alias
WorkflowOrchestrator = AsyncWorkflowOrchestrator
