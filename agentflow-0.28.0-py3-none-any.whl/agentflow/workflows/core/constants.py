"""
Constants used throughout AgentFlow core.
"""

# Default path for SQLite database checkpointer
DEFAULT_PATH_TO_SQLITE_DB = ".agentflow/checkpoints.db"

# Default tools module name (optional - not all workflows need tools)
DEFAULT_TOOLS_MODULE = "tools"

# Default Orchestrator response
DEFAULT_ORCHESTRATOR_RESPONSE = "Sorry, I'm unable to respond to messages outside the application scope. Please try again with a different message."
