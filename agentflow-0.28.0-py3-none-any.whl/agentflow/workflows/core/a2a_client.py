"""
A2A Client - Thin wrapper around the official a2a-sdk for external agent invocation.

This module provides utilities to invoke external A2A-compliant agents
for seamless integration with AgentFlow workflows.
"""
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any, AsyncGenerator, Tuple

import httpx
from a2a.client import A2ACardResolver, ClientFactory, ClientConfig
from a2a.client.helpers import create_text_message_object
from a2a.types import Task, TaskArtifactUpdateEvent, Message
from tenacity import AsyncRetrying, stop_after_attempt, wait_exponential, retry_if_exception_type

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_BACKOFF = 1.0
DEFAULT_MAX_BACKOFF = 30.0


@dataclass
class A2AResponse:
    """Response from an A2A agent invocation."""
    text: str
    task_id: Optional[str] = None


async def _get_oauth2_token(oauth2_config: Dict[str, Any], timeout: float) -> str:
    """Fetch OAuth2 token using client credentials flow."""
    async with httpx.AsyncClient(timeout=timeout) as client:
        data = {
            "grant_type": "client_credentials",
            "client_id": oauth2_config["client_id"],
            "client_secret": oauth2_config["client_secret"],
        }
        if oauth2_config.get("scopes"):
            data["scope"] = " ".join(oauth2_config["scopes"])

        response = await client.post(oauth2_config["token_url"], data=data)
        response.raise_for_status()
        return response.json()["access_token"]


def _build_httpx_client(
        auth_config: Optional[Dict[str, Any]],
        timeout: float
) -> httpx.AsyncClient:
    """Build httpx AsyncClient with appropriate authentication and timeout configuration."""
    timeout_config = httpx.Timeout(timeout)

    if not auth_config:
        return httpx.AsyncClient(timeout=timeout_config)

    auth_type = auth_config.get("type", "none")

    if auth_type == "none":
        return httpx.AsyncClient(timeout=timeout_config)

    elif auth_type == "bearer":
        token = auth_config["token"]
        headers = {"Authorization": f"Bearer {token}"}
        return httpx.AsyncClient(headers=headers, timeout=timeout_config)

    elif auth_type == "api_key":
        header_name = auth_config.get("header_name") or "X-API-Key"
        headers = {header_name: auth_config["token"]}
        return httpx.AsyncClient(headers=headers, timeout=timeout_config)

    elif auth_type == "basic":
        auth = httpx.BasicAuth(auth_config["username"], auth_config["password"])
        return httpx.AsyncClient(auth=auth, timeout=timeout_config)

    elif auth_type == "mtls":
        mtls = auth_config["mtls"]
        cert = (mtls["cert_path"], mtls["key_path"])
        verify = mtls.get("ca_path", True)
        return httpx.AsyncClient(cert=cert, verify=verify, timeout=timeout_config)

    elif auth_type == "oauth2_client_credentials":
        # Token will be fetched dynamically and added per-request
        return httpx.AsyncClient(timeout=timeout_config)

    else:
        logger.warning(f"Unknown auth type '{auth_type}', using no authentication")
        return httpx.AsyncClient(timeout=timeout_config)


def _extract_text_from_message(msg: Message) -> str:
    """Extract text content from a Message object."""
    texts = []
    if msg.parts:
        for part in msg.parts:
            if hasattr(part, "text") and part.text:
                texts.append(part.text)
    return " ".join(texts) if texts else ""


def _extract_text_from_task(task: Task) -> str:
    """Extract text content from a Task's artifacts."""
    texts = []
    if task.artifacts:
        for artifact in task.artifacts:
            if artifact.parts:
                for part in artifact.parts:
                    if hasattr(part, "text") and part.text:
                        texts.append(part.text)
    return " ".join(texts) if texts else ""


async def _invoke_a2a_agent_impl(
        endpoint: str,
        message: str,
        auth_config: Optional[Dict[str, Any]],
        timeout: float,
        task_id: Optional[str]
) -> A2AResponse:
    """Internal implementation of A2A agent invocation"""
    # Handle OAuth2 - fetch token first
    extra_headers = {}
    if auth_config and auth_config.get("type") == "oauth2_client_credentials":
        token = await _get_oauth2_token(auth_config["oauth2"], timeout)
        extra_headers["Authorization"] = f"Bearer {token}"

    http_client = _build_httpx_client(auth_config, timeout)

    # Add OAuth2 token if fetched
    if extra_headers:
        http_client.headers.update(extra_headers)

    async with http_client:
        # 1. Resolve agent card
        card_resolver = A2ACardResolver(http_client, endpoint)
        agent_card = await card_resolver.get_agent_card()

        # 2. Create client via factory
        config = ClientConfig(
            httpx_client=http_client,
            streaming=False
        )
        factory = ClientFactory(config)
        client = factory.create(agent_card)

        # 3. Create message
        msg = create_text_message_object(content=message)

        # 4. If continuing a conversation, set context_id on message
        if task_id:
            msg.context_id = task_id

        # 5. Send message and collect response
        response_text = ""
        response_task_id = None

        async for event in client.send_message(msg):
            if isinstance(event, tuple):
                task, update = event
                response_task_id = task.id
                text = _extract_text_from_task(task)
                if text:
                    response_text = text
            elif isinstance(event, Message):
                text = _extract_text_from_message(event)
                if text:
                    response_text = text
                if event.context_id:
                    response_task_id = event.context_id

        if response_text:
            return A2AResponse(text=response_text, task_id=response_task_id)

        return A2AResponse(text="No response from agent", task_id=response_task_id)


async def invoke_a2a_agent(
        endpoint: str,
        message: str,
        auth_config: Optional[Dict[str, Any]] = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_config: Optional[Dict[str, Any]] = None,
        task_id: Optional[str] = None
) -> Optional[A2AResponse]:
    """
    Invoke an external A2A agent and return the response.

    Supports multi-turn conversations by passing the task_id from a previous
    response to continue the conversation context.

    Args:
        endpoint: The A2A agent endpoint URL (agent card at /.well-known/agent.json)
        message: The message to send to the agent
        auth_config: Optional authentication configuration dict
        timeout: Request timeout in seconds (default: 30.0)
        retry_config: Optional retry configuration with keys:
            - max_attempts: Maximum retry attempts (default: 3)
            - backoff: Initial backoff delay in seconds (default: 1.0)
            - max_backoff: Maximum backoff delay in seconds (default: 30.0)
        task_id: Optional task ID from previous invocation for multi-turn conversations

    Returns:
        A2AResponse with text and task_id for continuing the conversation

    Raises:
        httpx.HTTPError: If the request fails after all retries
    """
    # Parse retry configuration
    max_attempts = (retry_config or {}).get("max_attempts", DEFAULT_MAX_ATTEMPTS)
    backoff = (retry_config or {}).get("backoff", DEFAULT_BACKOFF)
    max_backoff = (retry_config or {}).get("max_backoff", DEFAULT_MAX_BACKOFF)

    # Use tenacity for retry with exponential backoff
    async for attempt in AsyncRetrying(
            stop=stop_after_attempt(max_attempts),
            wait=wait_exponential(multiplier=backoff, min=backoff, max=max_backoff),
            retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError, httpx.HTTPStatusError)),
            reraise=True
    ):
        with attempt:
            return await _invoke_a2a_agent_impl(
                endpoint=endpoint,
                message=message,
                auth_config=auth_config,
                timeout=timeout,
                task_id=task_id
            )
    return None


async def invoke_a2a_agent_streaming(
        endpoint: str,
        message: str,
        auth_config: Optional[Dict[str, Any]] = None,
        timeout: float = DEFAULT_TIMEOUT,
        task_id: Optional[str] = None
) -> AsyncGenerator[Tuple[str, Optional[str]], None]:
    """
    Invoke an external A2A agent with streaming response.

    Yields (chunk, task_id) tuples as they arrive from the external agent.
    The task_id is included to support multi-turn conversations.
    If the agent doesn't support streaming, falls back to non-streaming
    and yields the complete response as a single chunk.

    Args:
        endpoint: The A2A agent endpoint URL
        message: The message to send to the agent
        auth_config: Optional authentication configuration dict
        timeout: Request timeout in seconds (default: 30.0)
        task_id: Optional task ID from previous invocation for multi-turn conversations

    Yields:
        Tuples of (text_chunk, task_id) - task_id may be None until final chunk

    Raises:
        httpx.HTTPError: If the request fails
    """
    # Handle OAuth2 - fetch token first
    extra_headers = {}
    if auth_config and auth_config.get("type") == "oauth2_client_credentials":
        token = await _get_oauth2_token(auth_config["oauth2"], timeout)
        extra_headers["Authorization"] = f"Bearer {token}"

    http_client = _build_httpx_client(auth_config, timeout)

    # Add OAuth2 token if fetched
    if extra_headers:
        http_client.headers.update(extra_headers)

    async with http_client:
        # 1. Resolve agent card
        card_resolver = A2ACardResolver(http_client, endpoint)
        agent_card = await card_resolver.get_agent_card()

        # Check if agent supports streaming
        supports_streaming = (
                agent_card.capabilities
                and hasattr(agent_card.capabilities, "streaming")
                and agent_card.capabilities.streaming
        )

        # 2. Create client via factory with streaming config
        config = ClientConfig(
            httpx_client=http_client,
            streaming=supports_streaming
        )
        factory = ClientFactory(config)
        client = factory.create(agent_card)

        # 3. Create message
        msg = create_text_message_object(content=message)

        # If continuing a conversation, set context_id
        if task_id:
            msg.context_id = task_id

        # 4. Send message and stream response
        response_task_id = None
        yielded_any = False

        async for event in client.send_message(msg):
            if isinstance(event, tuple):
                task, update = event
                response_task_id = task.id

                # For artifact updates, extract and yield new text
                if isinstance(update, TaskArtifactUpdateEvent) and update.artifact:
                    if update.artifact.parts:
                        for part in update.artifact.parts:
                            if hasattr(part, "text") and part.text:
                                yielded_any = True
                                yield (part.text, response_task_id)

                # Also check task artifacts directly (for final state)
                if task.artifacts:
                    for artifact in task.artifacts:
                        if artifact.parts:
                            for part in artifact.parts:
                                if hasattr(part, "text") and part.text:
                                    if not yielded_any:
                                        yielded_any = True
                                        yield (part.text, response_task_id)

            elif isinstance(event, Message):
                # Direct message response
                if event.context_id:
                    response_task_id = event.context_id
                text = _extract_text_from_message(event)
                if text:
                    yielded_any = True
                    yield (text, response_task_id)

        # If nothing was yielded, fall back to non-streaming
        if not yielded_any:
            logger.debug(
                f"Agent at {endpoint} returned no streaming chunks, "
                "falling back to non-streaming"
            )
            response = await invoke_a2a_agent(
                endpoint=endpoint,
                message=message,
                auth_config=auth_config,
                timeout=timeout,
                task_id=task_id
            )
            yield response.text, response.task_id
