"""
LLM Factory for creating LangChain-compatible LLM instances.

Supports:
- Named providers: azure_openai, openai, anthropic (ergonomic configuration)
- Custom provider: any LangChain model via class import (universal support)
"""

import importlib
from typing import Optional, Dict

from .config_models import LLMConfig, LLMProvider, AnthropicConfig, OpenAIConfig, AzureOpenAIConfig, RateLimitConfig, \
    CacheConfig
from .llm_protocol import LLMProtocol


class LLMFactory:
    """Factory for creating any LangChain-compatible LLM."""

    @staticmethod
    def create_llm(config: LLMConfig) -> LLMProtocol:
        """
        Create LLM instance from configuration.

        Supports:
        - Named providers: azure_openai, openai, anthropic
        - Custom provider: any LangChain model via class import

        Args:
            config: LLM configuration
            azure_identity: Azure AD identity for token provider (optional)

        Returns:
            LLM instance implementing LLMProtocol
        """
        if config.provider == LLMProvider.CUSTOM:
            llm = LLMFactory._create_custom(config.class_name, **config.config)
        elif config.provider == LLMProvider.AZURE_OPENAI:
            llm = LLMFactory._create_azure_openai(**config.config)
        elif config.provider == LLMProvider.OPENAI:
            llm = LLMFactory._create_openai(**config.config)
        elif config.provider == LLMProvider.ANTHROPIC:
            llm = LLMFactory._create_anthropic(**config.config)
        else:
            raise ValueError(f"Unsupported LLM provider: {config.provider}")

        # Apply rate limiter if configured
        if config.rate_limit:
            llm = LLMFactory._apply_rate_limiter(llm, config.rate_limit)

        # Apply cache if configured
        if config.cache and config.cache.enabled:
            llm = LLMFactory._apply_cache(llm, config.cache)

        return llm

    @staticmethod
    def _apply_rate_limiter(llm: LLMProtocol, rate_config: RateLimitConfig) -> LLMProtocol:
        """Apply rate limiting to an LLM instance."""
        from langchain_core.rate_limiters import InMemoryRateLimiter

        rate_limiter = InMemoryRateLimiter(
            requests_per_second=rate_config.requests_per_second,
            check_every_n_seconds=rate_config.check_every_n_seconds,
            max_bucket_size=rate_config.max_bucket_size,
        )
        llm.rate_limiter = rate_limiter  # type: ignore[attr-defined]
        return llm

    @staticmethod
    def _apply_cache(llm: LLMProtocol, cache_config: CacheConfig) -> LLMProtocol:
        """Apply response caching to an LLM instance."""
        from langchain_core.caches import InMemoryCache

        llm.cache = InMemoryCache(maxsize=cache_config.max_size)  # type: ignore[attr-defined]
        return llm

    @staticmethod
    def _create_custom(class_name: str, **kwargs) -> LLMProtocol:
        """
        Create custom LLM by importing specified class.

        Example config:
            provider: "custom"
            class: "langchain_google_genai.ChatGoogleGenerativeAI"
            params:
              model: "gemini-pro"
              google_api_key: "${GOOGLE_API_KEY}"
              temperature: 0.5
        """
        if not class_name:
            raise ValueError("'class' is required for custom provider")

        # Import the class
        try:
            module_path, class_name = class_name.rsplit('.', 1)
            module = importlib.import_module(module_path)
            llm_class = getattr(module, class_name)
        except (ValueError, ImportError, AttributeError) as e:
            raise ValueError(
                f"Failed to import LLM class '{class_name}'. "
                f"Make sure the package is installed and the class path is correct. "
                f"Error: {e}"
            )

        # Create instance with params
        try:
            llm_instance = llm_class(**kwargs)
        except Exception as e:
            raise ValueError(
                f"Failed to instantiate {class_name} with params {kwargs}. "
                f"Error: {e}"
            )

        # Verify it implements the protocol
        if not hasattr(llm_instance, 'ainvoke'):
            raise ValueError(
                f"{class_name} does not implement LLMProtocol "
                f"(missing 'ainvoke' method)"
            )

        return llm_instance

    @staticmethod
    def _create_azure_openai(**kwargs) -> LLMProtocol:
        """Create Azure OpenAI instance (named provider shortcut)."""
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        from langchain_openai import AzureChatOpenAI

        cfg = AzureOpenAIConfig(**kwargs)

        if cfg.azure_identity:
            azure_ad_token_provider = get_bearer_token_provider(
                DefaultAzureCredential(),  # type: ignore
                cfg.azure_oauth_scope
            )
        else:
            azure_ad_token_provider = None

        return AzureChatOpenAI(
            azure_deployment=cfg.deployment_name,
            api_version=cfg.openai_api_version,
            azure_endpoint=cfg.azure_endpoint,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
            top_p=cfg.top_p,
            timeout=cfg.timeout,
            max_retries=cfg.max_retries,
            azure_ad_token_provider=azure_ad_token_provider,
            model=cfg.model_name,
            model_version=cfg.model_version,
        )

    @staticmethod
    def _create_openai(**kwargs) -> LLMProtocol:
        """Create OpenAI instance (named provider shortcut)."""
        from langchain_openai import ChatOpenAI

        cfg = OpenAIConfig(**kwargs)

        return ChatOpenAI(
            model=cfg.model,
            api_key=cfg.api_key,
            base_url=cfg.base_url,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
            top_p=cfg.top_p,
        )

    @staticmethod
    def _create_anthropic(**kwargs) -> LLMProtocol:
        """Create Anthropic instance (named provider shortcut)."""
        from langchain_anthropic import ChatAnthropic

        cfg = AnthropicConfig(**kwargs)
        return ChatAnthropic(
            model_name=cfg.model,
            api_key=cfg.api_key,
            base_url=cfg.base_url,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,  # type: ignore
            timeout=cfg.timeout,
            max_retries=cfg.max_retries,
            top_p=cfg.top_p,
        )


class LLMConfigResolver:
    """Resolves LLM configuration with hierarchy."""

    def __init__(
            self,
            global_config: Optional[LLMConfig],
            orchestrator_config: Optional[LLMConfig],
            workflow_configs: Dict[str, Optional[LLMConfig]],
            node_configs: Dict[str, Optional[LLMConfig]],
    ):
        self.global_config = global_config
        self.orchestrator_config = orchestrator_config
        self.workflow_configs = workflow_configs
        self.node_configs = node_configs

    def resolve_llm_config(
            self,
            workflow_name: Optional[str] = None,
            node_name: Optional[str] = None,
    ) -> LLMConfig:
        """
        Resolve LLM configuration with hierarchy:
        1. Global config (base)
        2. Orchestrator config
        3. Workflow config
        4. Node config (highest priority)

        Note: Custom providers completely override (no partial merge)
        """

        # Start with global config
        config = self.global_config or LLMConfig(
            provider=LLMProvider.AZURE_OPENAI,
            config={"model": "gpt-4o"},
        )

        # Apply orchestrator config
        if self.orchestrator_config:
            config = self.orchestrator_config.merge_with(config)

        # Apply workflow config
        if workflow_name and workflow_name in self.workflow_configs:
            wf_config = self.workflow_configs[workflow_name]
            if wf_config:
                config = wf_config.merge_with(config)

        # Apply node config (highest priority)
        if node_name and node_name in self.node_configs:
            node_config = self.node_configs[node_name]
            if node_config:
                config = node_config.merge_with(config)

        return config
