"""
LangChain callback handlers for structured logging, metrics, and cost tracking.

These handlers are injected into RunnableConfig["callbacks"] and receive events
from all LLM calls, tool invocations, and chain executions within a workflow.
"""

import json
import logging
import time
from typing import Any, Dict, List, Optional
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import LLMResult


class StructuredLoggingCallbackHandler(BaseCallbackHandler):
    """
    Emits JSON-structured log lines for all LLM and tool events.

    Each log line includes correlation IDs (execution_id, thread_id) for
    tracing requests across multi-agent workflows.

    Args:
        execution_id: Unique execution/thread identifier for correlation.
        workflow_name: Name of the current workflow.
        logger_name: Python logger name (default: "agentflow.structured").
        redact_prompts: If True, prompt content is replaced with "[REDACTED]".
    """

    def __init__(
            self,
            execution_id: str = "default",
            workflow_name: str = "",
            logger_name: str = "agentflow.structured",
            redact_prompts: bool = False,
    ):
        self.execution_id = execution_id
        self.workflow_name = workflow_name
        self.redact_prompts = redact_prompts
        self._logger = logging.getLogger(logger_name)
        self._start_times: Dict[UUID, float] = {}

    def _log(self, event: str, data: Dict[str, Any], run_id: UUID) -> None:
        record = {
            "event": event,
            "execution_id": self.execution_id,
            "workflow": self.workflow_name,
            "run_id": str(run_id),
            **data,
        }
        self._logger.info(json.dumps(record, default=str))

    def on_chat_model_start(
            self,
            serialized: Dict[str, Any],
            messages: List[List[BaseMessage]],
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            tags: Optional[List[str]] = None,
            metadata: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
    ) -> None:
        self._start_times[run_id] = time.monotonic()
        model = serialized.get("kwargs", {}).get("model_name") or serialized.get("id", [""])[-1]
        msg_count = sum(len(batch) for batch in messages)
        self._log("llm_start", {
            "model": model,
            "message_count": msg_count,
            "prompt": "[REDACTED]" if self.redact_prompts else None,
        }, run_id)

    def on_llm_end(
            self,
            response: LLMResult,
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            **kwargs: Any,
    ) -> None:
        duration = time.monotonic() - self._start_times.pop(run_id, time.monotonic())
        tokens = _extract_usage(response)
        self._log("llm_end", {
            "duration_s": round(duration, 3),
            **tokens,
        }, run_id)

    def on_llm_error(
            self,
            error: BaseException,
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            **kwargs: Any,
    ) -> None:
        self._start_times.pop(run_id, None)
        self._log("llm_error", {
            "error_type": type(error).__name__,
            "error": str(error),
        }, run_id)

    def on_tool_start(
            self,
            serialized: Dict[str, Any],
            input_str: str,
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            tags: Optional[List[str]] = None,
            metadata: Optional[Dict[str, Any]] = None,
            inputs: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
    ) -> None:
        self._start_times[run_id] = time.monotonic()
        tool_name = serialized.get("name", "unknown")
        self._log("tool_start", {"tool": tool_name}, run_id)

    def on_tool_end(
            self,
            output: Any,
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            **kwargs: Any,
    ) -> None:
        duration = time.monotonic() - self._start_times.pop(run_id, time.monotonic())
        self._log("tool_end", {"duration_s": round(duration, 3)}, run_id)

    def on_tool_error(
            self,
            error: BaseException,
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            **kwargs: Any,
    ) -> None:
        self._start_times.pop(run_id, None)
        self._log("tool_error", {
            "error_type": type(error).__name__,
            "error": str(error),
        }, run_id)


class MetricsCallbackHandler(BaseCallbackHandler):
    """
    Collects runtime metrics (counts, durations, token usage) per workflow run.

    Metrics are accumulated in-memory and can be retrieved via `get_metrics()`.
    Designed to be plugged into external systems (Prometheus, StatsD, etc.)
    by reading the metrics dict after workflow completion.

    Args:
        execution_id: Unique execution/thread identifier.
    """

    def __init__(self, execution_id: str = "default"):
        self.execution_id = execution_id
        self._start_times: Dict[UUID, float] = {}
        self._metrics: Dict[str, Any] = {
            "llm_calls": 0,
            "llm_errors": 0,
            "llm_total_duration_s": 0.0,
            "tool_calls": 0,
            "tool_errors": 0,
            "tool_total_duration_s": 0.0,
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
        }

    def get_metrics(self) -> Dict[str, Any]:
        """Return accumulated metrics for this execution."""
        return {
            "execution_id": self.execution_id,
            **self._metrics,
        }

    def on_chat_model_start(self, serialized, messages, *, run_id, **kwargs):
        self._start_times[run_id] = time.monotonic()

    def on_llm_end(self, response: LLMResult, *, run_id, **kwargs):
        duration = time.monotonic() - self._start_times.pop(run_id, time.monotonic())
        self._metrics["llm_calls"] += 1
        self._metrics["llm_total_duration_s"] = round(
            self._metrics["llm_total_duration_s"] + duration, 3
        )
        tokens = _extract_usage(response)
        self._metrics["input_tokens"] += tokens.get("input_tokens", 0)
        self._metrics["output_tokens"] += tokens.get("output_tokens", 0)
        self._metrics["total_tokens"] += tokens.get("total_tokens", 0)

    def on_llm_error(self, error, *, run_id, **kwargs):
        self._start_times.pop(run_id, None)
        self._metrics["llm_errors"] += 1

    def on_tool_start(self, serialized, input_str, *, run_id, **kwargs):
        self._start_times[run_id] = time.monotonic()

    def on_tool_end(self, output, *, run_id, **kwargs):
        duration = time.monotonic() - self._start_times.pop(run_id, time.monotonic())
        self._metrics["tool_calls"] += 1
        self._metrics["tool_total_duration_s"] = round(
            self._metrics["tool_total_duration_s"] + duration, 3
        )

    def on_tool_error(self, error, *, run_id, **kwargs):
        self._start_times.pop(run_id, None)
        self._metrics["tool_errors"] += 1


class CostTrackingCallbackHandler(BaseCallbackHandler):
    """
    Tracks token usage and enforces an optional budget cap per workflow run.

    When `max_total_tokens` is set and the budget is exceeded, subsequent
    LLM calls will raise a `BudgetExceededError`.

    Args:
        max_total_tokens: Maximum total tokens allowed (None = unlimited).
    """

    def __init__(self, max_total_tokens: Optional[int] = None):
        self.max_total_tokens = max_total_tokens
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.total_tokens: int = 0
        self.llm_calls: int = 0

    def on_chat_model_start(self, serialized, messages, *, run_id, **kwargs):
        if self.max_total_tokens and self.total_tokens >= self.max_total_tokens:
            raise BudgetExceededError(
                f"Token budget exceeded: {self.total_tokens}/{self.max_total_tokens} tokens used."
            )

    def on_llm_end(self, response: LLMResult, *, run_id, **kwargs):
        self.llm_calls += 1
        tokens = _extract_usage(response)
        self.input_tokens += tokens.get("input_tokens", 0)
        self.output_tokens += tokens.get("output_tokens", 0)
        self.total_tokens += tokens.get("total_tokens", 0)

    def get_usage(self) -> Dict[str, Any]:
        """Return current token usage."""
        return {
            "llm_calls": self.llm_calls,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "budget": self.max_total_tokens,
            "remaining": (self.max_total_tokens - self.total_tokens) if self.max_total_tokens else None,
        }


class BudgetExceededError(Exception):
    """Raised when a token budget cap is exceeded."""
    pass


logger = logging.getLogger(__name__)


def _extract_usage(response: LLMResult) -> Dict[str, int]:
    """Extract token usage from an LLMResult via usage_metadata."""
    if response.generations:
        for gen_list in response.generations:
            for gen in gen_list:
                if hasattr(gen, "message") and hasattr(gen.message, "usage_metadata"):
                    meta = gen.message.usage_metadata
                    if meta:
                        return {
                            "input_tokens": meta.get("input_tokens", 0),
                            "output_tokens": meta.get("output_tokens", 0),
                            "total_tokens": meta.get("total_tokens", 0),
                        }

    logger.debug("Token usage not available in LLM response")
    return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
