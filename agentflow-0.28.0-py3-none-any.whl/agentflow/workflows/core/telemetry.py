"""Native OpenTelemetry subsystem for the workflows backend.

OTel is a **first-class, native component** of AgentFlow — not a plugin. This
module owns the tracing substrate (``TracerProvider`` / exporter / span
processor, plus the LangSmith OTel bridge that produces the LLM/tool/agent
trace tree) and emits domain spans for events ``langsmith[otel]`` cannot see:
HITL interrupts, external-agent (A2A) calls, MCP connections, checkpoint
operations, and workflow errors.

It mirrors the other backends' ``telemetry.py`` (``deep``, ``sk``, ``cas``,
``oai``, ``adk``) — telemetry as a plain native module, wired directly by the
orchestrator rather than discovered as a plugin.

Telemetry is a **deployment concern** — enabled via ``OTEL_*`` environment
variables, never via YAML.

Environment variables:
    OTEL_TRACES_ENABLED       Set to "true" to enable (required).
    OTEL_SERVICE_NAME         Service name for spans (default: my-workflow-service).
    OTEL_EXPORTER_OTLP_ENDPOINT / _PROTOCOL   OTLP target (any OTLP backend).
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional, Tuple

from opentelemetry import trace
from opentelemetry.sdk.resources import SERVICE_NAME, SERVICE_VERSION, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from agentflow.core import telemetry_seam as _seam

# The exporter seam (register_span_processor, entry-point discovery, provider
# tracking, atexit shutdown) is backend-agnostic and now lives in
# ``agentflow.core.telemetry_seam``, shared by every backend. ``register_span_processor``
# stays part of the public workflows API (``agentflow.workflows.register_span_processor``),
# re-exported here for backward compatibility.
register_span_processor = _seam.register_span_processor

# Workflows-specific idempotency guard (a second in-process orchestrator reuses
# the provider the first one installed).
_otel_initialized = False


def _create_exporter():
    """Create an OTLP exporter based on ``OTEL_EXPORTER_OTLP_PROTOCOL``.

    With no constructor args the exporter reads all standard ``OTEL_*`` env vars
    (endpoint, headers, certificate, timeout) automatically, so operators can
    target any OTLP-compatible backend (Jaeger, Langfuse, New Relic, Datadog, an
    OTel Collector, …) purely through ``.env`` configuration.
    """
    protocol = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
    if protocol == "http/protobuf":
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    else:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    return OTLPSpanExporter()


def setup_tracing(
    service_name: Optional[str] = None,
    service_version: str = "1.0.0",
) -> Tuple[Optional[trace.Tracer], Optional[TracerProvider]]:
    """Set up the global OTel tracing substrate. Idempotent.

    Returns ``(tracer, provider)`` where ``provider`` is the ``TracerProvider``
    *this call created* (``None`` if tracing is disabled or a provider was already
    set up by an earlier call). Only the creator owns shutdown of a provider.

    The OTLP span processor is the default sink; additional processors
    registered via :func:`register_span_processor` or contributed through the
    ``agentflow.span_processors`` entry-point group are attached additively (the
    exporter seam) so multiple backends can receive spans at once.
    """
    global _otel_initialized

    if os.getenv("OTEL_TRACES_ENABLED", "false").lower() != "true":
        return None, None

    # Ensure LangSmith OTel bridge is on so LLM-level spans (model, token usage)
    # export through our provider. ``setdefault`` lets user-provided values win.
    os.environ.setdefault("LANGSMITH_TRACING", "true")
    os.environ.setdefault("LANGSMITH_OTEL_ENABLED", "true")
    os.environ.setdefault("LANGSMITH_OTEL_ONLY", "true")

    if _otel_initialized:
        # A provider is already installed (e.g. a second orchestrator in-process).
        # Reuse it; we don't own it.
        return trace.get_tracer(__name__), None

    service_name = service_name or os.getenv("OTEL_SERVICE_NAME", "agentflow-workflow")
    resource = Resource.create({SERVICE_NAME: service_name, SERVICE_VERSION: service_version})

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)
    _otel_initialized = True

    # Exporter seam: attach registered + entry-point-discovered processors
    # (e.g. Azure Monitor) additively, alongside the default OTLP sink. The seam
    # skips the default OTLP sink when no endpoint is configured but a seam
    # processor is present (so Azure-only apps don't spam localhost:4317), and
    # owns provider tracking + atexit shutdown so a later register_span_processor()
    # call reaches this provider too.
    otlp_attached = _seam.attach_seam_processors(
        provider,
        default_factory=lambda: BatchSpanProcessor(_create_exporter()),
    )

    print("OpenTelemetry tracing enabled")
    print(f"  Service: {service_name}")
    if otlp_attached:
        protocol = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
        endpoint = os.getenv(
            "OTEL_EXPORTER_OTLP_ENDPOINT",
            "http://localhost:4317" if protocol == "grpc" else "http://localhost:4318",
        )
        print(f"  Endpoint: {endpoint} ({protocol})")
    else:
        print("  Default OTLP sink: skipped (no OTEL_EXPORTER_OTLP_ENDPOINT set)")
    print("  LangSmith OTEL: enabled (LLM-level tracing active)")

    return trace.get_tracer(__name__), provider


class WorkflowTelemetry:
    """Native telemetry subsystem — sets up tracing and emits domain spans.

    Owns the substrate via :func:`setup_tracing` and emits spans for events
    ``langsmith[otel]`` can't see. Provides ``on_*`` methods that the orchestrator
    calls directly at lifecycle points. It is **not** a ``Plugin`` and is not
    discovered/registered — telemetry is native. All ``on_*`` methods are safe
    no-ops when telemetry is disabled (OTel off).
    """

    def __init__(
        self,
        service_name: Optional[str] = None,
        service_version: str = "1.0.0",
        enabled: bool = True,
    ) -> None:
        self.enabled = enabled and os.getenv("OTEL_TRACES_ENABLED", "false").lower() == "true"
        self.tracer: Optional[trace.Tracer] = None
        self._provider: Optional[TracerProvider] = None
        self._shutdown_called = False
        self.hitl_spans: Dict[str, Any] = {}
        self.external_agent_spans: Dict[str, Any] = {}
        if not self.enabled:
            return
        self.tracer, self._provider = setup_tracing(service_name, service_version)

    # ── HITL ─────────────────────────────────────────────────────────────
    def on_hitl_start(self, context, interrupt_type: str, prompt: str) -> None:
        if not self.enabled:
            return
        span = self.tracer.start_span(
            f"hitl.{interrupt_type}",
            attributes={
                "hitl.type": interrupt_type,
                "hitl.prompt_length": len(prompt) if prompt else 0,
                "execution_id": context.execution_id,
            },
        )
        self.hitl_spans[f"{context.execution_id}:{interrupt_type}"] = span

    def on_hitl_end(self, context, interrupt_type: str, response: Any) -> None:
        if not self.enabled:
            return
        span = self.hitl_spans.pop(f"{context.execution_id}:{interrupt_type}", None)
        if span:
            span.set_attribute("hitl.response_type", type(response).__name__)
            if isinstance(response, str):
                span.set_attribute("hitl.response_length", len(response))
            span.end()

    # ── External agent (A2A) ─────────────────────────────────────────────
    def on_external_agent_start(self, context, agent_name: str, endpoint: str, message: str) -> None:
        if not self.enabled:
            return
        span = self.tracer.start_span(
            f"external_agent.{agent_name}",
            attributes={
                "external_agent.name": agent_name,
                "external_agent.endpoint": endpoint,
                "external_agent.message_length": len(message) if message else 0,
                "execution_id": context.execution_id,
            },
        )
        self.external_agent_spans[f"{context.execution_id}:{agent_name}"] = span

    def on_external_agent_end(
        self, context, agent_name: str, endpoint: str, response: str, error: str = None
    ) -> None:
        if not self.enabled:
            return
        span = self.external_agent_spans.pop(f"{context.execution_id}:{agent_name}", None)
        if span:
            if error:
                span.set_attribute("error", True)
                span.set_attribute("error.type", error)
            else:
                span.set_attribute("external_agent.response_length", len(response) if response else 0)
            span.end()

    # ── MCP ──────────────────────────────────────────────────────────────
    def on_mcp_connect(self, context, server_name: str, tool_count: int) -> None:
        if not self.enabled:
            return
        with self.tracer.start_as_current_span(
            f"mcp.connect.{server_name}",
            attributes={
                "mcp.server_name": server_name,
                "mcp.tool_count": tool_count,
                "execution_id": context.execution_id if context else "unknown",
            },
        ):
            pass

    # ── Checkpoints ──────────────────────────────────────────────────────
    def on_checkpoint_save(self, context, checkpoint_id: str, data_size: int) -> None:
        if not self.enabled:
            return
        with self.tracer.start_as_current_span(
            "checkpoint.save",
            attributes={
                "checkpoint.id": checkpoint_id,
                "checkpoint.data_size_bytes": data_size,
                "execution_id": context.execution_id if context else "unknown",
            },
        ):
            pass

    def on_checkpoint_load(self, context, checkpoint_id: str, success: bool) -> None:
        if not self.enabled:
            return
        with self.tracer.start_as_current_span(
            "checkpoint.load",
            attributes={
                "checkpoint.id": checkpoint_id,
                "checkpoint.success": success,
                "execution_id": context.execution_id if context else "unknown",
            },
        ):
            pass

    # ── Errors ───────────────────────────────────────────────────────────
    def on_error(self, context, error: Exception, error_context: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        with self.tracer.start_as_current_span(
            "workflow.error",
            attributes={
                "error": True,
                "error_type": type(error).__name__,
                "error_message": str(error),
                "execution_id": context.execution_id,
            },
        ):
            pass

    # ── Lifecycle ────────────────────────────────────────────────────────
    def shutdown(self) -> None:
        """Flush + shut down this instance's provider (only if it owns one)."""
        if not self.enabled or self._shutdown_called or self._provider is None:
            return
        self._shutdown_called = True
        try:
            self._provider.force_flush(timeout_millis=5000)
            self._provider.shutdown()
            _seam.untrack_provider(self._provider)
        except Exception as e:
            print(f"  Warning: OpenTelemetry shutdown error: {e}")
