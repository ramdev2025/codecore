"""
Data models for AgentFlow.
"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, TypedDict, Annotated

from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages


class State(TypedDict, total=False):
    """State for workflow graph with message history and external agent tracking."""
    messages: Annotated[List[AnyMessage], add_messages]
    # Track task IDs for multi-turn conversations with external A2A agents
    # Maps agent_name -> task_id for continuing conversations
    external_agent_tasks: Dict[str, str]


@dataclass
class WorkflowContext:
    """Context passed to plugin hooks"""
    execution_id: str
    tracking_id: Optional[str] = None
    workflow_name: Optional[str] = None
    # Request-scoped caller identity, when the app supplied one (see
    # ``get_principal``). Optional and defaulted so existing construction
    # sites and plugins are unaffected. AgentFlow carries it; it never
    # authenticates it.
    principal_id: Optional[str] = None
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


def get_principal(config: Optional[Dict[str, Any]]) -> Optional[str]:
    """Return the request-scoped ``principal_id`` from a run config, if present.

    AgentFlow carries the caller's identity in LangGraph's ``configurable``
    channel (the same place ``thread_id`` lives), so tools can read it straight
    off the ``RunnableConfig`` they already receive::

        from agentflow.workflows import get_principal

        @tool
        def my_tool(query: str, config: RunnableConfig) -> str:
            principal = get_principal(config)   # None when not configured
            ...

    Returns ``None`` when no principal was supplied — identical to the
    framework's behavior before principals existed. The framework never
    authenticates this value; resolving and trusting it is the app's job.
    """
    if not config:
        return None
    return config.get("configurable", {}).get("principal_id")
