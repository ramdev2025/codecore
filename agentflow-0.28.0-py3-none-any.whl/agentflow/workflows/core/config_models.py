from enum import Enum
from typing import Optional, Dict, Any, List, Union, Literal, Set

from langchain_core.utils import from_env, secret_from_env
from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic.types import SecretStr

from agentflow.genui import ClientToolConfig, UIToolsConfig
from agentflow.core.pg_pool import (
    DEFAULT_CHECK_CONNECTION,
    DEFAULT_CONNECT_TIMEOUT,
    DEFAULT_MAX_IDLE,
    DEFAULT_MAX_LIFETIME,
    DEFAULT_MIN_SIZE,
    DEFAULT_POOL_SIZE,
    pool_overrides_from_env,
)

from .constants import DEFAULT_PATH_TO_SQLITE_DB, DEFAULT_ORCHESTRATOR_RESPONSE


class WorkflowMetadata(BaseModel):
    """
    Metadata about the workflow configuration.

    This section contains information about the configuration file itself,
    not the runtime configuration.
    """

    version: str = Field(
        ...,
        description="Schema version (e.g., '1.0', '2.0')"
    )
    name: Optional[str] = Field(
        None,
        description="Human-readable name for this configuration"
    )
    description: Optional[str] = Field(
        None,
        description="Detailed description of this workflow configuration"
    )
    author: Optional[str] = Field(
        None,
        description="Author or team responsible for this configuration"
    )
    created: Optional[str] = Field(
        None,
        description="Creation date (ISO format: YYYY-MM-DD)"
    )
    updated: Optional[str] = Field(
        None,
        description="Last update date (ISO format: YYYY-MM-DD)"
    )
    tags: Optional[List[str]] = Field(
        None,
        description="Tags for categorization and search"
    )
    notes: Optional[str] = Field(
        None,
        description="Additional notes or comments"
    )


class LLMProvider(str, Enum):
    """Named providers with ergonomic configuration."""
    AZURE_OPENAI = "azure_openai"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    CUSTOM = "custom"


class AzureOpenAIConfig(BaseModel):
    """Azure OpenAI specific configuration."""
    azure_endpoint: Optional[str] = Field(
        default_factory=from_env("AZURE_OPENAI_ENDPOINT", default=None)
    )
    deployment_name: Optional[str] = Field(
        alias="azure_deployment",
        default_factory=from_env("AZURE_DEPLOYMENT", default=None),
    )
    openai_api_version: Optional[str] = Field(
        alias="api_version",
        default_factory=from_env("OPENAI_API_VERSION", default=None),
    )
    openai_api_key: Optional[SecretStr] = Field(
        alias="api_key",
        default_factory=secret_from_env(
            ["AZURE_OPENAI_API_KEY", "OPENAI_API_KEY"], default=None
        ),
    )
    azure_oauth_scope: str = Field(
        default_factory=from_env("AZURE_OAUTH_SCOPE", default="https://cognitiveservices.azure.com/.default")
    )
    model_version: str = ""
    model_name: Optional[str] = Field(default=None, alias="model")
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    top_p: Optional[float] = Field(default=1.0, ge=0.0, le=1.0)
    azure_identity: Optional[bool] = Field(default=False)
    timeout: Optional[float] = Field(None, gt=0)
    max_retries: Optional[int] = Field(default=2, ge=0)  # Max number of retries if a request fails.


class OpenAIConfig(BaseModel):
    """OpenAI specific configuration."""
    model: str
    api_key: Optional[str] = Field(default_factory=from_env("OPENAI_API_KEY", default=None))
    base_url: Optional[str] = None
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    top_p: Optional[float] = Field(default=1.0, ge=0.0, le=1.0)
    max_retries: Optional[int] = Field(default=2, ge=0)  # Max number of retries if a request fails.
    timeout: Optional[float] = Field(None, gt=0)


class AnthropicConfig(BaseModel):
    """Anthropic specific configuration."""
    model: str
    api_key: Optional[str] = Field(default_factory=from_env("ANTHROPIC_API_KEY", default=None))
    base_url: Optional[str] = None
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    top_p: Optional[float] = Field(None, ge=0.0, le=1.0)
    max_retries: Optional[int] = Field(default=2, ge=0)  # Max number of retries if a request fails.
    timeout: Optional[float] = Field(None, gt=0)


class RateLimitConfig(BaseModel):
    """Rate limit configuration for LLM API calls (maps to LangChain InMemoryRateLimiter)."""
    requests_per_second: float = Field(
        ..., gt=0, description="Maximum sustained request rate"
    )
    check_every_n_seconds: float = Field(
        0.1, gt=0, description="Polling interval for token availability"
    )
    max_bucket_size: float = Field(
        10.0, gt=0, description="Maximum burst size (token bucket capacity)"
    )


class CacheConfig(BaseModel):
    """LLM response cache configuration (maps to LangChain InMemoryCache)."""
    enabled: bool = Field(True, description="Enable or disable caching")
    max_size: Optional[int] = Field(
        None, gt=0, description="Maximum number of cached responses (None = unlimited)"
    )


class LLMConfig(BaseModel):
    """
    LLM configuration supporting any LangChain model.

    Two configuration styles:
    1. Named providers (azure_openai, openai, anthropic) - ergonomic
    2. Custom provider - flexible for any LangChain model
    """

    provider: Optional[LLMProvider] = None
    # For custom provider
    class_name: Optional[str] = None

    config: Dict[str, Any] = Field(default_factory=dict)
    rate_limit: Optional[RateLimitConfig] = Field(
        None, description="Rate limit for LLM API calls"
    )
    cache: Optional[CacheConfig] = Field(
        None, description="Response cache for LLM calls"
    )

    model_config = ConfigDict(populate_by_name=True)

    @model_validator(mode='after')
    def validate_provider_config(self):
        """Validate that required fields are present for each provider."""
        if not self.provider:
            return self

        if self.provider == LLMProvider.CUSTOM:
            if not self.class_name:
                raise ValueError(f"'class_name' is required when provider='{LLMProvider.CUSTOM}'")

        return self

    def merge_with(self, parent: 'LLMConfig') -> 'LLMConfig':
        """Merge with parent config, keeping non-None values."""
        if self.provider == LLMProvider.CUSTOM or parent.provider == LLMProvider.CUSTOM:
            if self.provider == LLMProvider.CUSTOM:
                return self
            else:
                return parent

        config = parent.config or {}
        config.update(self.config or {})

        merged = LLMConfig(
            provider=self.provider or parent.provider,
            config=self.config,
            class_name=self.class_name or parent.class_name,
            rate_limit=self.rate_limit or parent.rate_limit,
            cache=self.cache or parent.cache,
        )
        merged._merged = True
        return merged


class BuiltinMiddleware(str, Enum):
    """Built-in LangChain middleware types."""
    SUMMARIZATION = "summarization"
    HUMAN_IN_THE_LOOP = "human_in_the_loop"
    MODEL_CALL_LIMIT = "model_call_limit"
    TOOL_CALL_LIMIT = "tool_call_limit"
    MODEL_FALLBACK = "model_fallback"
    PII = "pii"
    TOOL_RETRY = "tool_retry"
    LLM_TOOL_SELECTOR = "llm_tool_selector"


class A2AAuthType(str, Enum):
    """Supported A2A authentication types."""
    NONE = "none"
    BEARER = "bearer"
    API_KEY = "api_key"
    BASIC = "basic"
    OAUTH2_CLIENT_CREDENTIALS = "oauth2_client_credentials"
    MTLS = "mtls"


class OAuth2Config(BaseModel):
    """OAuth2 Client Credentials flow configuration."""
    token_url: str = Field(..., description="Token endpoint URL")
    client_id: str = Field(..., description="OAuth2 client ID (supports ${ENV_VAR})")
    client_secret: str = Field(..., description="OAuth2 client secret (supports ${ENV_VAR})")
    scopes: Optional[List[str]] = Field(default=None, description="Requested scopes")


class MTLSConfig(BaseModel):
    """Mutual TLS (client certificate) configuration."""
    cert_path: str = Field(..., description="Path to client certificate (.pem)")
    key_path: str = Field(..., description="Path to client private key (.pem)")
    ca_path: Optional[str] = Field(None, description="Path to CA bundle for server verification")


class ExternalAgentAuthConfig(BaseModel):
    """
    Authentication configuration for external A2A agents.

    Supports all A2A protocol security schemes:
    - none: No authentication (public agents)
    - bearer: Bearer token in Authorization header
    - api_key: API key in custom header
    - basic: HTTP Basic authentication
    - oauth2_client_credentials: OAuth2 client credentials flow
    - mtls: Mutual TLS with client certificates

    Examples:
        Bearer token:
        ```yaml
        auth:
          type: bearer
          token: "${AGENT_TOKEN}"
        ```

        OAuth2 Client Credentials:
        ```yaml
        auth:
          type: oauth2_client_credentials
          oauth2:
            token_url: "https://auth.example.com/oauth/token"
            client_id: "${CLIENT_ID}"
            client_secret: "${CLIENT_SECRET}"
            scopes: ["agent.invoke"]
        ```
    """
    type: A2AAuthType = Field(
        default=A2AAuthType.NONE,
        description="Authentication type"
    )

    # Token-based auth (bearer, api_key)
    token: Optional[str] = Field(
        None,
        description="Token value for bearer or api_key auth (supports ${ENV_VAR})"
    )
    header_name: Optional[str] = Field(
        None,
        description="Custom header name (default: Authorization for bearer, X-API-Key for api_key)"
    )

    # Basic auth
    username: Optional[str] = Field(None, description="Basic auth username")
    password: Optional[str] = Field(
        None,
        description="Basic auth password (supports ${ENV_VAR})"
    )

    # OAuth2 Client Credentials
    oauth2: Optional[OAuth2Config] = Field(None, description="OAuth2 configuration")

    # Mutual TLS
    mtls: Optional[MTLSConfig] = Field(None, description="Mutual TLS configuration")

    @model_validator(mode='after')
    def validate_auth_config(self):
        """Validate that required fields are present for each auth type."""
        if self.type == A2AAuthType.BEARER:
            if not self.token:
                raise ValueError("'token' is required for bearer authentication")
        elif self.type == A2AAuthType.API_KEY:
            if not self.token:
                raise ValueError("'token' is required for api_key authentication")
        elif self.type == A2AAuthType.BASIC:
            if not self.username or not self.password:
                raise ValueError("'username' and 'password' are required for basic authentication")
        elif self.type == A2AAuthType.OAUTH2_CLIENT_CREDENTIALS:
            if not self.oauth2:
                raise ValueError("'oauth2' configuration is required for oauth2_client_credentials")
        elif self.type == A2AAuthType.MTLS:
            if not self.mtls:
                raise ValueError("'mtls' configuration is required for mtls authentication")
        return self


class RetryConfig(BaseModel):
    """
    Retry configuration for external A2A agents.

    Uses tenacity for exponential backoff with 2x multiplier.

    Example:
        ```yaml
        retry:
          max_attempts: 3
          backoff: 1.0
          max_backoff: 30.0
        ```
    """
    max_attempts: int = Field(
        default=3,
        ge=1,
        le=10,
        description="Maximum number of retry attempts"
    )
    backoff: float = Field(
        default=1.0,
        ge=0.1,
        le=60.0,
        description="Initial backoff delay in seconds"
    )
    max_backoff: float = Field(
        default=30.0,
        ge=1.0,
        le=300.0,
        description="Maximum backoff delay in seconds"
    )


class ExternalAgentsConfig(BaseModel):
    """
    Global configuration defaults for external A2A agents.

    These defaults apply to all external agents unless overridden at the node level.

    Example:
        ```yaml
        external_agents:
          timeout: 30.0
          retry:
            max_attempts: 3
            backoff: 1.0
            max_backoff: 30.0
        ```
    """
    timeout: float = Field(
        default=30.0,
        gt=0,
        le=300.0,
        description="Default timeout in seconds for external agent calls"
    )
    retry: RetryConfig = Field(
        default_factory=RetryConfig,
        description="Default retry configuration for external agents"
    )


class SummarizationMiddlewareConfig(BaseModel):
    """
    Configuration for summarization middleware.

    See: https://docs.langchain.com/oss/python/langchain/middleware/built-in
    """
    model: str = Field(
        ...,
        description="Model for generating summaries (e.g., 'anthropic:claude-sonnet-4-20250514')"
    )
    trigger_messages: Optional[int] = Field(
        None,
        description="Trigger summarization after this many messages"
    )
    trigger_tokens: Optional[int] = Field(
        None,
        description="Trigger summarization after this many tokens"
    )
    keep_messages: int = Field(
        default=20,
        ge=1,
        description="Number of recent messages to retain after summarization"
    )


class ModelCallLimitMiddlewareConfig(BaseModel):
    """
    Configuration for model call limit middleware.

    See: https://docs.langchain.com/oss/python/langchain/middleware/built-in
    """
    run_limit: Optional[int] = Field(
        None,
        gt=0,
        description="Maximum model calls per single invocation"
    )
    thread_limit: Optional[int] = Field(
        None,
        gt=0,
        description="Maximum model calls across all runs in a thread"
    )
    exit_behavior: str = Field(
        default="end",
        description="Behavior when limit reached: 'end' or 'error'"
    )

    @model_validator(mode='after')
    def validate_at_least_one_limit(self):
        """At least one of run_limit or thread_limit must be specified."""
        if self.run_limit is None and self.thread_limit is None:
            raise ValueError("At least one of 'run_limit' or 'thread_limit' must be specified")
        return self


class ToolCallLimitMiddlewareConfig(BaseModel):
    """
    Configuration for tool call limit middleware.

    See: https://docs.langchain.com/oss/python/langchain/middleware/built-in
    """
    tool_name: Optional[str] = Field(
        None,
        description="Specific tool to limit (None for global limit)"
    )
    run_limit: Optional[int] = Field(
        None,
        gt=0,
        description="Maximum tool calls per single invocation"
    )
    thread_limit: Optional[int] = Field(
        None,
        gt=0,
        description="Maximum tool calls across all runs in a thread"
    )
    exit_behavior: str = Field(
        default="continue",
        description="Behavior when limit reached: 'continue', 'end', or 'error'"
    )

    @model_validator(mode='after')
    def validate_at_least_one_limit(self):
        """At least one of run_limit or thread_limit must be specified."""
        if self.run_limit is None and self.thread_limit is None:
            raise ValueError("At least one of 'run_limit' or 'thread_limit' must be specified")
        return self


class HumanInTheLoopMiddlewareConfig(BaseModel):
    """
    Configuration for human-in-the-loop middleware.

    See: https://docs.langchain.com/oss/python/langchain/middleware/built-in
    """
    interrupt_on: Dict[str, Dict[str, Any]] = Field(
        ...,
        description="Dict mapping tool names to interrupt config with allowed_decisions"
    )


class ModelFallbackMiddlewareConfig(BaseModel):
    """Configuration for model fallback middleware."""
    fallback_models: List[str] = Field(
        ...,
        min_length=1,
        description="List of fallback model names to try in order"
    )


class ToolRetryMiddlewareConfig(BaseModel):
    """Configuration for tool retry middleware."""
    max_retries: int = Field(
        default=3,
        ge=1,
        description="Maximum number of retry attempts"
    )
    retry_on: Optional[List[str]] = Field(
        None,
        description="Exception types to retry on (None for all)"
    )


class CustomMiddlewareConfig(BaseModel):
    """Configuration for custom middleware."""
    class_name: str = Field(
        ...,
        description="Fully qualified class name (e.g., 'mymodule.MyMiddleware')"
    )
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Configuration parameters to pass to middleware constructor"
    )


class MiddlewareConfig(BaseModel):
    """
    Middleware configuration for a node.

    Supports built-in LangChain middleware types or custom middleware classes.
    Either 'type' (for built-in) or 'custom' (for custom class) must be specified.

    See: https://docs.langchain.com/oss/python/langchain/middleware/built-in

    Examples:
        Built-in middleware:
        ```yaml
        middleware:
          - type: summarization
            summarization:
              model: "anthropic:claude-sonnet-4-20250514"
              trigger_messages: 20
              keep_messages: 5
          - type: model_call_limit
            model_call_limit:
              run_limit: 20
              exit_behavior: end
        ```

        Custom middleware:
        ```yaml
        middleware:
          - custom:
              class_name: "mymodule.AuditMiddleware"
              config:
                log_level: "INFO"
        ```
    """
    type: Optional[BuiltinMiddleware] = Field(
        None,
        description="Built-in middleware type"
    )
    custom: Optional[CustomMiddlewareConfig] = Field(
        None,
        description="Custom middleware configuration"
    )
    enabled: bool = Field(
        default=True,
        description="Whether this middleware is enabled"
    )
    # Type-specific configurations
    summarization: Optional[SummarizationMiddlewareConfig] = None
    model_call_limit: Optional[ModelCallLimitMiddlewareConfig] = None
    tool_call_limit: Optional[ToolCallLimitMiddlewareConfig] = None
    human_in_the_loop: Optional[HumanInTheLoopMiddlewareConfig] = None
    model_fallback: Optional[ModelFallbackMiddlewareConfig] = None
    tool_retry: Optional[ToolRetryMiddlewareConfig] = None

    @model_validator(mode='after')
    def validate_middleware_config(self):
        """Validate that exactly one of type or custom is specified."""
        if self.type is None and self.custom is None:
            raise ValueError("Either 'type' or 'custom' must be specified")
        if self.type is not None and self.custom is not None:
            raise ValueError("Cannot specify both 'type' and 'custom'")
        return self


# =============================================================================
# MCP (Model Context Protocol) Configuration Models
# =============================================================================


class MCPTransport(str, Enum):
    """
    Supported MCP transport types.

    - STDIO: Local MCP servers running as subprocesses
    - SSE: Remote MCP servers using Server-Sent Events
    - STREAMABLE_HTTP: Remote MCP servers using Streamable HTTP (recommended for production)
    """
    STDIO = "stdio"
    SSE = "sse"
    STREAMABLE_HTTP = "streamable_http"


class MCPServerConfig(BaseModel):
    """
    Configuration for a single MCP server.

    Supports multiple transport types:
    - stdio: Local subprocess-based servers
    - sse: Remote SSE-based servers
    - streamable_http: Remote HTTP-based servers (recommended)

    Examples:
        Local stdio server:
        ```yaml
        mcp_servers:
          data-platform:
            transport: stdio
            command: "python"
            args: ["-m", "mcp_server"]
            env:
              APP_DIR: "."
        ```

        Remote SSE server:
        ```yaml
        mcp_servers:
          remote-data:
            transport: sse
            url: "https://mcp.example.com/sse"
            auth:
              type: bearer
              token: "${MCP_TOKEN}"
        ```

        Environment-specific configuration:
        ```yaml
        mcp_servers:
          data-platform:
            transport: stdio
            environments:
              local:
                command: "python"
                args: ["-m", "mcp_server"]
              prod:
                transport: sse
                url: "https://mcp.prod.internal/sse"
        ```
    """
    model_config = ConfigDict(extra="forbid")

    transport: MCPTransport = Field(
        default=MCPTransport.STDIO,
        description="Transport type for MCP communication"
    )

    # Stdio transport configuration
    command: Optional[str] = Field(
        None,
        description="Command to run for stdio transport (e.g., 'python', 'node')"
    )
    args: List[str] = Field(
        default_factory=list,
        description="Command arguments for stdio transport"
    )
    env: Optional[Dict[str, str]] = Field(
        None,
        description="Environment variables for stdio transport (supports ${ENV_VAR})"
    )
    cwd: Optional[str] = Field(
        None,
        description="Working directory for stdio transport"
    )

    # HTTP transport configuration (SSE/Streamable HTTP)
    url: Optional[str] = Field(
        None,
        description="Server URL for SSE or Streamable HTTP transport"
    )
    headers: Optional[Dict[str, str]] = Field(
        None,
        description="Additional HTTP headers for remote servers"
    )

    # Authentication (reuses A2A auth models for consistency)
    auth: Optional[ExternalAgentAuthConfig] = Field(
        None,
        description="Authentication configuration for remote MCP servers"
    )

    # Timeout and retry (consistent with external_agents)
    timeout: float = Field(
        default=30.0,
        gt=0,
        le=300.0,
        description="Timeout in seconds for MCP operations"
    )
    retry: Optional[RetryConfig] = Field(
        None,
        description="Retry configuration for MCP operations"
    )

    # Environment-specific configurations
    environments: Optional[Dict[str, "MCPServerConfig"]] = Field(
        None,
        description="Environment-specific configuration overrides"
    )

    # Context for auto-documentation (injected into system prompts)
    context: Optional[str] = Field(
        None,
        description=(
            "Domain-specific context to include with auto-generated tool documentation. "
            "Use this for information not in the MCP schema, such as required parameter "
            "values, available data sources, or usage hints. This is automatically "
            "injected into agent system prompts along with tool documentation."
        )
    )

    @model_validator(mode="after")
    def validate_transport_config(self) -> "MCPServerConfig":
        """Ensure transport-specific fields are provided."""
        # Skip validation if environments are provided (will be resolved at runtime)
        if self.environments:
            return self

        if self.transport == MCPTransport.STDIO:
            if not self.command:
                raise ValueError(
                    "stdio transport requires 'command' field. "
                    "Example: command: 'python', args: ['-m', 'my_mcp_server']"
                )
        elif self.transport in (MCPTransport.SSE, MCPTransport.STREAMABLE_HTTP):
            if not self.url:
                raise ValueError(
                    f"{self.transport.value} transport requires 'url' field. "
                    f"Example: url: 'https://mcp.example.com/{self.transport.value}'"
                )
        return self

    def resolve_for_environment(self, env_name: Optional[str] = None) -> "MCPServerConfig":
        """
        Resolve configuration for a specific environment.

        Args:
            env_name: Environment name (e.g., 'local', 'dev', 'prod').
                      Uses MCP_ENV environment variable if not provided.

        Returns:
            Resolved configuration with environment-specific overrides applied.

        Priority: environment-specific > base config
        """
        import os

        # Determine environment
        effective_env = env_name or os.environ.get("MCP_ENV")

        if not effective_env or not self.environments:
            return self

        if effective_env not in self.environments:
            return self

        env_config = self.environments[effective_env]

        # Merge: env_config values override base values
        merged_data = self.model_dump(exclude={"environments"}, exclude_none=True)
        env_data = env_config.model_dump(exclude={"environments"}, exclude_none=True)
        merged_data.update(env_data)

        return MCPServerConfig.model_validate(merged_data)


class MCPToolAlias(BaseModel):
    """
    Tool reference with optional alias for renaming.

    Use aliases to:
    - Avoid tool name conflicts across servers
    - Provide more descriptive names for agents
    - Maintain compatibility when server tool names change

    Example:
        ```yaml
        mcp_tools:
          - server: data-platform
            tools:
              - name: query
                alias: query_data  # Agent sees 'query_data'
              - name: search
                alias: semantic_search
        ```
    """
    model_config = ConfigDict(extra="forbid")

    name: str = Field(
        ...,
        description="Original tool name from the MCP server"
    )
    alias: Optional[str] = Field(
        None,
        description="Alternative name visible to the agent (defaults to original name)"
    )


class MCPToolsReference(BaseModel):
    """
    Reference to tools from an MCP server for use in a node.

    Specifies which MCP server to use and which tools to expose to the agent.

    Tool selection options:
    - All tools: tools: "*" or omit the tools field
    - Specific tools: tools: ["tool1", "tool2"]
    - Tools with aliases: tools: [{name: "tool1", alias: "my_tool"}]

    Examples:
        All tools from server:
        ```yaml
        mcp_tools:
          - server: data-platform
            tools: "*"
        ```

        Specific tools:
        ```yaml
        mcp_tools:
          - server: data-platform
            tools: [query, list_data_sources]
        ```

        Tools with aliases:
        ```yaml
        mcp_tools:
          - server: data-platform
            tools:
              - name: query
                alias: query_data
              - search  # No alias, uses original name
        ```
    """
    model_config = ConfigDict(extra="forbid")

    server: str = Field(
        ...,
        description="Name of the MCP server (must match a key in mcp_servers)"
    )
    tools: Union[Literal["*"], List[Union[str, MCPToolAlias]]] = Field(
        default="*",
        description="Tools to expose: '*' for all, or list of tool names/aliases"
    )

    def get_tool_filter(self) -> Optional[Set[str]]:
        """
        Get set of tool names to include.

        Returns:
            Set of tool names to include, or None for all tools.
        """
        if self.tools == "*":
            return None

        tool_names: Set[str] = set()
        for tool in self.tools:
            if isinstance(tool, str):
                tool_names.add(tool)
            else:
                tool_names.add(tool.name)
        return tool_names

    def get_alias_map(self) -> Dict[str, str]:
        """
        Get mapping of original tool names to aliases.

        Returns:
            Dict mapping original names to aliases (only for tools with aliases).
        """
        if self.tools == "*":
            return {}

        aliases: Dict[str, str] = {}
        for tool in self.tools:
            if isinstance(tool, MCPToolAlias) and tool.alias:
                aliases[tool.name] = tool.alias
        return aliases


class RetryPolicyConfig(BaseModel):
    """Retry policy for graph node execution (maps to LangGraph RetryPolicy)."""
    initial_interval: float = Field(
        0.5, gt=0, description="Initial retry interval in seconds"
    )
    backoff_factor: float = Field(
        2.0, gt=0, description="Multiplier for exponential backoff"
    )
    max_interval: float = Field(
        128.0, gt=0, description="Maximum wait between retries in seconds"
    )
    max_attempts: int = Field(
        3, ge=1, description="Maximum number of attempts"
    )
    jitter: bool = Field(
        True, description="Add random jitter to prevent thundering herd"
    )


class NodeCachePolicyConfig(BaseModel):
    """Cache policy for graph node output (maps to LangGraph CachePolicy)."""
    ttl: Optional[int] = Field(
        None, gt=0, description="Time-to-live in seconds for cached node output (None = no expiry)"
    )


class NodeConfig(BaseModel):
    """
    Agent/Node configuration.

    Supports two node types:
    1. Local agents (with system_prompt and tools/mcp_tools)
    2. External A2A agents (with endpoint)

    The node type is inferred from the presence of the endpoint field.

    Local agent example:
        ```yaml
        nodes:
          my_agent:
            description: "Handles customer queries"
            system_prompt: "You are a helpful assistant..."
            tools:
              - search_knowledge_base
        ```

    Local agent with MCP tools:
        ```yaml
        nodes:
          data_agent:
            description: "Query data via MCP"
            system_prompt: "You have access to MCP data tools..."
            mcp_tools:
              - server: data-platform
                tools: [query, list_data_sources]
        ```

    Local agent with custom LLM (e.g., Snowflake Cortex):
        ```yaml
        nodes:
          snowflake_agent:
            description: "Query enterprise data"
            llm:
              provider: custom
              class_name: "langchain_community.chat_models.ChatSnowflakeCortex"
              config:
                model: "llama3.1-70b"
            system_prompt: "You are an enterprise data analyst..."
        ```

    External A2A agent example:
        ```yaml
        nodes:
          external_agent:
            description: "Salesforce CRM agent"
            endpoint: "https://einstein.salesforce.com/a2a"
            auth:
              type: bearer
              token: "${SALESFORCE_TOKEN}"
        ```
    """
    description: str
    tools: Optional[List[str]] = Field(
        None,
        description="Local tool function names to import from tools_module"
    )
    mcp_tools: Optional[List[MCPToolsReference]] = Field(
        None,
        description="MCP server tools to expose to this agent"
    )
    system_prompt: Optional[str] = Field(
        None,
        description="System prompt for local agents (required for local, ignored for external)"
    )
    llm: Optional[LLMConfig] = None
    middleware: Optional[List[MiddlewareConfig]] = Field(
        None,
        description="List of middleware configurations for this node"
    )
    retry_policy: Optional[RetryPolicyConfig] = Field(
        None,
        description="Retry policy for transient failures (exponential backoff with jitter)"
    )
    cache_policy: Optional['NodeCachePolicyConfig'] = Field(
        None,
        description="Cache policy for node output (caches entire node execution result)"
    )

    # External A2A agent fields
    endpoint: Optional[str] = Field(
        None,
        description="A2A agent endpoint URL. Presence indicates this is an external A2A agent."
    )
    auth: Optional[ExternalAgentAuthConfig] = Field(
        None,
        description="Authentication configuration for external A2A agents"
    )
    timeout: Optional[float] = Field(
        None,
        gt=0,
        le=300.0,
        description="Timeout in seconds for external agent calls (overrides global default)"
    )
    retry: Optional[RetryConfig] = Field(
        None,
        description="Retry configuration for external agent (overrides global default)"
    )

    @model_validator(mode='after')
    def validate_node_type(self):
        """Validate node configuration based on type (local vs external)."""
        if self.endpoint:
            # External A2A agent - cannot have local tools or MCP tools
            if self.tools:
                raise ValueError(
                    "External A2A agents (with endpoint) cannot have local tools. "
                    "Remove 'tools' or 'endpoint' from the configuration."
                )
            if self.mcp_tools:
                raise ValueError(
                    "External A2A agents (with endpoint) cannot have MCP tools. "
                    "Remove 'mcp_tools' or 'endpoint' from the configuration."
                )
        else:
            # Local agent - requires system_prompt
            if not self.system_prompt:
                raise ValueError(
                    "Local agents require 'system_prompt'. "
                    "Add a system_prompt, or specify 'endpoint' for A2A agents."
                )
        return self

    def is_external(self) -> bool:
        """Check if this node represents an external A2A agent."""
        return self.endpoint is not None

    def is_local(self) -> bool:
        """Check if this node represents a local agent."""
        return not self.is_external()

    def has_mcp_tools(self) -> bool:
        """Check if this node uses MCP tools."""
        return bool(self.mcp_tools)


class WorkflowConfig(BaseModel):
    """Workflow configuration."""
    description: str
    nodes: Dict[str, Any]
    routes: Optional[Dict[str, Any]] = None
    llm: Optional[LLMConfig] = None
    interrupt_before: Optional[List[str]] = Field(
        None,
        description="Node names to pause BEFORE execution (requires checkpointer for resume)."
    )
    interrupt_after: Optional[List[str]] = Field(
        None,
        description="Node names to pause AFTER execution (requires checkpointer for resume)."
    )


class AgentConfig(BaseModel):
    """
    Agent configuration — standalone or with delegation.

    Standalone agent (no workflows/delegates):
        The agent runs directly with tools and a system prompt.

    Agent with delegation (workflows/delegates set):
        The agent acts as a router, delegating to specialized multi-step
        workflows based on the user's query.
    """
    name: Optional[str] = Field(
        None,
        description="Display name (used in traces, UI events, CLI output). "
                    "Defaults to 'Agent' for standalone, 'Orchestrator' for delegating."
    )
    system_prompt: Optional[str] = Field(
        None,
        description="System prompt for the agent. For delegating agents, "
                    "auto-generated from workflow descriptions if omitted."
    )
    tools: Optional[List[str]] = Field(
        None,
        description="Local tool function names to import from tools_module."
    )
    mcp_tools: Optional[List['MCPToolsReference']] = Field(
        None,
        description="MCP server tools available to this agent."
    )
    delegates: Optional[List[str]] = Field(
        None,
        description="Named delegate workflows this agent can route to."
    )
    workflows: Optional[List[str]] = Field(
        None,
        description="Alias for 'delegates' (backward compatibility)."
    )
    llm: Optional[LLMConfig] = None
    default_response: str = DEFAULT_ORCHESTRATOR_RESPONSE
    middleware: Optional[List['MiddlewareConfig']] = Field(
        None,
        description="Middleware applied to this agent."
    )

    # Cross-backend AG-UI vocabulary. Same schema MAF / SK / CAS / OAI /
    # ADK consume, so a single YAML block works across backends.
    ui_tools: Optional[UIToolsConfig] = Field(
        None,
        description=(
            "Generative-UI components: a module of "
            "``@agentflow.genui.ui_component``-decorated fetchers exposed "
            "as LangChain ``StructuredTool``s. Each fetcher's return is "
            "validated against the declared Pydantic class and emitted "
            "as a typed render event via the workflows AG-UI bridge."
        ),
    )
    client_tools: Optional[List[ClientToolConfig]] = Field(
        None,
        description=(
            "Frontend-implemented tools (only fully enforced on the "
            "workflows backend). Each entry becomes a stub that pauses "
            "the run via ``langgraph.types.interrupt(...)``; the AG-UI "
            "bridge surfaces the pause to the browser, which executes "
            "the tool and posts the result back."
        ),
    )
    available_when: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Predicate gating for ``ui_tools`` / ``client_tools``. Keys "
            "are tool names (component class names for ``ui_tools``, "
            "tool ``name`` field for ``client_tools``). Values are "
            "``simpleeval`` expressions evaluated **per LLM call** "
            "against the current graph state (workflows uses LangChain "
            "``AgentMiddleware.wrap_model_call`` for dynamic gating, "
            "the workflows-only advantage over other backends)."
        ),
    )

    @model_validator(mode='after')
    def resolve_delegates(self):
        """Resolve workflows → delegates alias."""
        if self.delegates and self.workflows:
            raise ValueError(
                "Cannot specify both 'delegates' and 'workflows' in agent config. Use one."
            )
        if self.workflows and not self.delegates:
            self.delegates = self.workflows
        return self

    @property
    def has_delegates(self) -> bool:
        """Whether this agent delegates to workflows."""
        return bool(self.delegates)


# Backward-compatible alias
OrchestratorConfig = AgentConfig


class PersistenceBackend(str, Enum):
    """Persistence backend type."""
    SQLITE = "sqlite"
    POSTGRES = "postgres"


class CheckpointerConfig(BaseModel):
    """Checkpointer configuration."""
    enabled: bool = Field(
        default=True,
        description="Whether to enable state persistence via checkpointer"
    )


class StoreConfig(BaseModel):
    """Store configuration for long-term memory."""
    enabled: bool = Field(
        default=False,
        description="Whether to enable store for long-term memory (PostgreSQL only)"
    )


class SQLiteConfig(BaseModel):
    """SQLite-specific persistence configuration."""
    db_path: str = Field(
        default=DEFAULT_PATH_TO_SQLITE_DB,
        description="Path to SQLite database file for checkpoints"
    )


class PostgresConfig(BaseModel):
    """PostgreSQL-specific persistence configuration.

    Connections are served from a ``psycopg_pool`` connection pool shared by
    the checkpointer and the store. The pool is what keeps a deployment alive
    across a database restart, failover, or an idle connection reaped by a
    cloud load balancer: a dead connection is discarded and replaced instead
    of poisoning every subsequent request.
    """
    connection_string: str = Field(
        ...,
        description="PostgreSQL connection string (supports ${ENV_VAR} syntax)"
    )
    pool_size: int = Field(
        default=DEFAULT_POOL_SIZE,
        ge=1,
        le=100,
        description="Maximum number of connections in the pool (pool max_size)"
    )
    min_size: int = Field(
        default=DEFAULT_MIN_SIZE,
        ge=0,
        le=100,
        description="Number of connections the pool keeps open at all times"
    )
    max_lifetime: float = Field(
        default=DEFAULT_MAX_LIFETIME,
        gt=0,
        description=(
            "Seconds after which a connection is retired and reopened. "
            "Proactively rotates connections before an idle-session timeout "
            "or load balancer can reap them. Note that max_idle alone does "
            "not cover this: it only trims connections above min_size."
        )
    )
    max_idle: float = Field(
        default=DEFAULT_MAX_IDLE,
        gt=0,
        description="Seconds an idle connection above min_size is kept before being closed"
    )
    check_connection: bool = Field(
        default=DEFAULT_CHECK_CONNECTION,
        description=(
            "Validate each connection as it is handed out, discarding and "
            "replacing dead ones. Costs one round-trip per checkout; set "
            "false only if that overhead is measurably a problem."
        )
    )
    connect_timeout: float = Field(
        default=DEFAULT_CONNECT_TIMEOUT,
        gt=0,
        description="Seconds to wait for a free connection before raising PoolTimeout"
    )

    @model_validator(mode="before")
    @classmethod
    def apply_pool_env_overrides(cls, data: Any) -> Any:
        """Fill unset pool fields from ``POSTGRES_POOL_*`` environment variables.

        Precedence is **explicit value > env var > default**. Doing this on the
        model rather than at one call site means pool tuning works from every
        construction site — the CLI, the deep backend, ``build_agui`` and other
        embedding apps that never touch the CLI, and the ``persistence_config=``
        Python API — instead of only the paths that remember to read the
        environment.

        Malformed values raise, surfacing as a validation error at startup
        rather than silently reverting to a default.
        """
        if not isinstance(data, dict):
            return data

        overrides = pool_overrides_from_env()
        if not overrides:
            return data

        # Copy so we never mutate a caller's dict.
        data = dict(data)
        for field, value in overrides.items():
            if data.get(field) is None:
                data[field] = value
        return data

    @model_validator(mode="after")
    def validate_pool_sizes(self) -> "PostgresConfig":
        """min_size cannot exceed the pool maximum."""
        if self.min_size > self.pool_size:
            raise ValueError(
                f"postgres.min_size ({self.min_size}) cannot exceed "
                f"postgres.pool_size ({self.pool_size})"
            )
        return self


class PersistenceConfig(BaseModel):
    """
    Persistence configuration for workflow state.

    Controls how workflow state is persisted across executions,
    enabling conversation continuity and workflow resumption.

    Supports two backends:
    - SQLite (default): File-based persistence, suitable for development and single-instance deployments
    - PostgreSQL: Scalable persistence for production multi-instance deployments

    Examples:
        SQLite (default):
        ```yaml
        persistence:
          backend: sqlite
          sqlite:
            db_path: data/checkpoints.db
          checkpointer:
            enabled: true
        ```

        PostgreSQL:
        ```yaml
        persistence:
          backend: postgres
          postgres:
            connection_string: "${DATABASE_URL}"
            pool_size: 10
          checkpointer:
            enabled: true
          store:
            enabled: true
        ```
    """

    backend: PersistenceBackend = Field(
        default=PersistenceBackend.SQLITE,
        description="Persistence backend type (sqlite or postgres)"
    )
    sqlite: Optional[SQLiteConfig] = Field(
        default=None,
        description="SQLite-specific configuration"
    )
    postgres: Optional[PostgresConfig] = Field(
        default=None,
        description="PostgreSQL-specific configuration"
    )
    checkpointer: CheckpointerConfig = Field(
        default_factory=CheckpointerConfig,
        description="Checkpointer configuration for state persistence"
    )
    store: StoreConfig = Field(
        default_factory=StoreConfig,
        description="Store configuration for long-term memory"
    )
    encryption_key: Optional[str] = Field(
        None,
        description=(
            "AES encryption key for checkpoint data at rest (supports ${ENV_VAR}). "
            "Must be 16, 24, or 32 bytes. Requires pycryptodome package."
        )
    )

    @model_validator(mode='after')
    def validate_backend_config(self):
        """Validate backend configuration consistency."""
        if self.backend == PersistenceBackend.POSTGRES:
            if self.postgres is None:
                raise ValueError(
                    "PostgreSQL configuration required when backend='postgres'. "
                    "Please provide 'postgres.connection_string'."
                )
        elif self.backend == PersistenceBackend.SQLITE:
            # Auto-create SQLite config with defaults if not provided
            if self.sqlite is None:
                self.sqlite = SQLiteConfig()
            # Store is not supported with SQLite
            if self.store.enabled:
                raise ValueError(
                    "Store is not supported with SQLite backend. "
                    "Use PostgreSQL backend for store functionality."
                )
        return self


class CallbacksConfig(BaseModel):
    """Configuration for built-in callback handlers."""
    structured_logging: bool = Field(
        False, description="Enable JSON-structured logging with correlation IDs"
    )
    redact_prompts: bool = Field(
        False, description="Redact prompt content in structured logs"
    )
    metrics: bool = Field(
        False, description="Enable metrics collection (counts, durations, token usage)"
    )
    cost_tracking: Optional[int] = Field(
        None, gt=0, description="Enable cost tracking with a max total token budget (None = track without cap)"
    )


class WorkflowYAMLConfig(BaseModel):
    """
    Root workflow.yaml configuration.

    This is the complete schema for AgentFlow workflow configuration files.
    Contains workflow definition (business logic) and optional persistence settings.

    Example with MCP servers:
        ```yaml
        metadata:
          version: "1.0"
          name: "My Workflow"

        mcp_servers:
          data-platform:
            transport: stdio
            command: "python"
            args: ["-m", "mcp_server"]

        nodes:
          my_agent:
            description: "Query data"
            system_prompt: "You have access to data tools..."
            mcp_tools:
              - server: data-platform
                tools: [query, list_data_sources]
        ```
    """

    metadata: WorkflowMetadata = Field(
        ...,
        description="Metadata about this configuration file"
    )
    llm: Optional[LLMConfig] = Field(
        None,
        description="Global LLM configuration (lowest priority)"
    )
    mcp_servers: Optional[Dict[str, MCPServerConfig]] = Field(
        None,
        description="MCP server configurations for tool access"
    )

    # Primary keyword
    agent: Optional[AgentConfig] = Field(
        None,
        description="Agent configuration (standalone or with delegation)"
    )
    # Legacy alias
    orchestrator: Optional[AgentConfig] = Field(
        None,
        description="Alias for 'agent' (backward compatibility)"
    )

    # Primary keyword (future)
    delegates: Optional[Dict[str, WorkflowConfig]] = Field(
        None,
        description="Delegate workflow definitions"
    )
    # Legacy alias
    workflows: Optional[Dict[str, WorkflowConfig]] = Field(
        None,
        description="Alias for 'delegates' (backward compatibility)"
    )

    nodes: Optional[Dict[str, NodeConfig]] = Field(
        default_factory=dict,
        description="Node (agent) definitions"
    )
    external_agents: Optional[ExternalAgentsConfig] = Field(
        None,
        description="Global defaults for external A2A agents (timeout, retry)"
    )
    persistence: Optional[PersistenceConfig] = Field(
        None,
        description="Persistence configuration for workflow state (optional)"
    )
    callbacks: Optional[CallbacksConfig] = Field(
        None,
        description="Built-in callback handlers for logging, metrics, and cost tracking"
    )

    @model_validator(mode='after')
    def resolve_aliases(self):
        """Resolve keyword aliases: orchestrator→agent, workflows→delegates."""
        # agent vs orchestrator
        if self.agent and self.orchestrator:
            raise ValueError("Cannot specify both 'agent' and 'orchestrator'. Use one.")
        if self.orchestrator and not self.agent:
            self.agent = self.orchestrator
        if not self.agent:
            raise ValueError("Configuration must include an 'agent' (or 'orchestrator') section.")

        # delegates vs workflows
        if self.delegates and self.workflows:
            raise ValueError("Cannot specify both 'delegates' and 'workflows'. Use one.")
        if self.workflows and not self.delegates:
            self.delegates = self.workflows

        # Default empty dicts for standalone agents
        if self.delegates is None:
            self.delegates = {}
        if self.nodes is None:
            self.nodes = {}

        return self

    @model_validator(mode='after')
    def validate_references(self):
        """Validate that workflow nodes reference defined nodes and MCP servers."""
        defined_nodes = set(self.nodes.keys()) if self.nodes else set()
        defined_mcp_servers = set(self.mcp_servers.keys()) if self.mcp_servers else set()

        for wf_name, wf_config in (self.delegates or {}).items():
            workflow_nodes = set(wf_config.nodes.keys())

            # Check that all workflow nodes are defined
            undefined = workflow_nodes - defined_nodes
            if undefined:
                raise ValueError(
                    f"Workflow '{wf_name}' references undefined nodes: {undefined}"
                )

        # Check that all MCP server references in nodes are defined
        for node_name, node_config in (self.nodes or {}).items():
            if node_config.mcp_tools:
                for mcp_ref in node_config.mcp_tools:
                    if mcp_ref.server not in defined_mcp_servers:
                        raise ValueError(
                            f"Node '{node_name}' references undefined MCP server: '{mcp_ref.server}'. "
                            f"Available servers: {list(defined_mcp_servers) or 'none'}"
                        )

        return self

    def get_version(self) -> str:
        """Get schema version."""
        return self.metadata.version

    def get_summary(self) -> str:
        """Get human-readable summary of configuration."""
        lines = [f"Configuration: {self.metadata.name or 'Unnamed'}"]
        if self.metadata.description:
            lines.append(f"Description: {self.metadata.description}")
        lines.append(f"Version: {self.metadata.version}")
        lines.append(f"Workflows: {len(self.delegates)}")
        lines.append(f"Nodes: {len(self.nodes)}")

        if self.metadata.author:
            lines.append(f"Author: {self.metadata.author}")
        if self.metadata.updated:
            lines.append(f"Last Updated: {self.metadata.updated}")

        return "\n".join(lines)
