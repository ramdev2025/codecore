import importlib
import os.path
import re
from pathlib import Path
from typing import Any, Dict, Callable, List, Optional
from typing import Pattern

import yaml


def sanitize_node_name(node_name: str) -> str:
    # Replace spaces with underscores first (optional, but common)
    node_name = node_name.replace(" ", "_")
    # Remove all disallowed characters in one pass
    return re.sub(r'[\s<|\\/>]', '', node_name)


def _load_project_dotenv(yaml_path: str | Path) -> None:
    """Load the project ``.env`` **before** ``${VAR}`` expansion.

    The workflows backend interpolates ``${VAR}`` from ``os.environ`` when
    reading the YAML; without this, ``agentflow "..."`` would require the caller
    to pre-export every variable. The ``deep``, ``sk``, ``cas`` and ``maf``
    backends already load the project ``.env`` — this brings workflows in line.

    Loads the YAML-adjacent ``.env`` first, then the cwd's (if different). A
    bare ``load_dotenv()`` is avoided: on a pip install it walks up from
    ``site-packages`` and can pull an unrelated ancestor ``.env``.
    """
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:
        return
    yaml_dir = Path(yaml_path).resolve().parent
    load_dotenv(yaml_dir / ".env", override=True)
    cwd_dotenv = find_dotenv(usecwd=True)
    if cwd_dotenv and Path(cwd_dotenv).resolve() != (yaml_dir / ".env").resolve():
        load_dotenv(cwd_dotenv, override=True)


def load_workflow_config(path: str | Path) -> Dict[str, Any]:
    _load_project_dotenv(path)  # populate os.environ before ${VAR} expansion
    with open(path, "r", encoding="utf-8") as f:
        raw = os.path.expandvars(f.read())  # replaces ${VAR}
        config = yaml.safe_load(raw)
    return config or {}


def import_tools(tool_names: List[str], tools_module: str | None) -> List[Callable]:
    """
    Import tools from a module.

    Args:
        tool_names: List of tool names to import
        tools_module: Module path to import from (can be None if no tools configured)

    Returns:
        List of imported tool functions
    """
    if tools_module is None:
        # No tools module configured - this is OK if agents don't use tools
        if tool_names:
            raise ValueError(
                f"Workflow requires tools {tool_names} but no tools_module was specified. "
                "Please provide tools_module parameter when creating the orchestrator."
            )
        return []

    module = importlib.import_module(tools_module)
    return [getattr(module, name) for name in tool_names if hasattr(module, name)]


def _extract_last_block(text: str, pattern: str | Pattern[str]) -> Optional[str]:
    matches = re.findall(pattern, text)

    if not matches:
        return None

    return matches[-1].strip()


def extract_last_tagged_block(text: str, start_tag: str, end_tag: str) -> Optional[str]:
    # Escape the tag for use in regex
    re_start_tag = re.escape(start_tag)
    re_end_tag = re.escape(end_tag)

    pattern = re.compile(
        rf"{re_start_tag}(.*?){re_end_tag}",
        re.DOTALL | re.IGNORECASE
    )

    return _extract_last_block(text, pattern)


def extract_last_fenced_block(text: str, info_string: str) -> Optional[str]:
    # Escape info string, e.g., text = """```python x = a + b```""" and info_string = 'python'
    re_info_string = re.escape(info_string)

    pattern = re.compile(
        rf"```{re_info_string}\s*(.*?)```",
        re.DOTALL | re.IGNORECASE
    )

    return _extract_last_block(text, pattern)


# ---------------------------------------------------------------------------
# Message preparation for agent nodes
# ---------------------------------------------------------------------------

def is_snowflake_cortex_llm(llm_config) -> bool:
    """Check if the LLM config is for Snowflake Cortex."""
    if llm_config is None:
        return False
    class_name = getattr(llm_config, 'class_name', None)
    return bool(class_name and 'ChatSnowflakeCortex' in class_name)


def prepare_messages_for_agent(messages: list, node_name: str, llm_config=None) -> list:
    """
    Prepare messages before passing them to an agent node.

    Handles two cases:
    1. Snowflake Cortex: strips everything except the last HumanMessage
       (Cortex doesn't support ToolMessage or multi-turn history).
    2. All other LLMs: ensures the conversation does not end with an
       AIMessage (assistant prefill). Some providers (e.g., Anthropic
       Claude Sonnet 4+) reject requests where the last message has the
       assistant role. In multi-agent workflows this happens naturally
       when Agent A's AIMessage output is still the last message when
       Agent B is invoked. We append a lightweight handoff HumanMessage
       so every provider receives a valid message sequence.

    Args:
        messages: List of LangChain message objects.
        node_name: Name of the target agent node (used in handoff text).
        llm_config: Optional LLM config object for provider-specific handling.

    Returns:
        A (possibly modified) list of messages safe to pass to the agent.
    """
    from langchain_core.messages import AIMessage, HumanMessage

    if not messages:
        return messages

    # Snowflake Cortex: keep only the last HumanMessage
    if is_snowflake_cortex_llm(llm_config):
        for msg in reversed(messages):
            if isinstance(msg, HumanMessage):
                return [msg]
            elif hasattr(msg, 'type') and msg.type == 'human':
                return [msg]
            elif isinstance(msg, dict) and msg.get('role') == 'user':
                return [HumanMessage(content=msg.get('content', ''))]
        return []

    # General: if the last message is an AIMessage, append a handoff
    last = messages[-1]
    is_ai = (
            isinstance(last, AIMessage)
            or (hasattr(last, 'type') and last.type == 'ai')
    )
    if is_ai:
        return list(messages) + [
            HumanMessage(
                content=f"[Handoff to {node_name}] Continue processing the request above."
            )
        ]

    return messages
