"""
LLM Protocol - Defines the interface that LLMs must implement.

This allows AgentFlow to be LLM-agnostic and support any LangChain-compatible chat model.
"""
from typing import Protocol, Any, List, Union, runtime_checkable

from langchain_core.messages import BaseMessage


@runtime_checkable
class LLMProtocol(Protocol):
    """
    Protocol defining the interface for LLMs used in AgentFlow.

    Any LangChain-compatible chat model that implements these methods can be used.
    This includes:
    - AzureChatOpenAI
    - ChatOpenAI
    - ChatAnthropic
    - Any other LangChain chat model

    Example:
        >>> from langchain_openai import ChatOpenAI
        >>> llm = ChatOpenAI(model="gpt-4o")
        >>> # llm now implements LLMProtocol and can be used with AgentFlow
    """

    async def ainvoke(
            self,
            input: Union[str, List[Union[str, tuple]], List[BaseMessage]],
            **kwargs: Any
    ) -> BaseMessage:
        """
        Asynchronously invoke the LLM with a prompt.

        Args:
            input: The input to the LLM. Can be:
                - A string prompt
                - A list of messages (tuples or BaseMessage objects)
            **kwargs: Additional arguments passed to the LLM

        Returns:
            The LLM's response as a BaseMessage
        """
        ...
