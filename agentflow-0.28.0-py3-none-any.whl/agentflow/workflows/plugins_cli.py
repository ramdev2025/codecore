"""
AgentFlow Plugin Manager (pip-based)

Supports two installation modes:
- Global: Installs to ~/.agentflow/plugins (shared across all projects)
- Local: Installs to current venv's site-packages (project-specific)
"""

import argparse
import csv
import importlib.metadata as metadata
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Iterable, Optional, Tuple

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .plugins import PLUGIN_NAMESPACE_PACKAGE

PLUGIN_DIR = Path.home() / ".agentflow" / "plugins"
NAMESPACE = PLUGIN_NAMESPACE_PACKAGE
ENTRYPOINT_GROUP = "agentflow.plugins"

console = Console()


def get_site_packages_dir() -> Path:
    """Get the site-packages directory for the current Python environment."""
    import sysconfig
    return Path(sysconfig.get_paths()["purelib"])


def ensure_plugin_dir() -> None:
    PLUGIN_DIR.mkdir(parents=True, exist_ok=True)


def run_pip(args: Iterable[str], capture_output: bool = False) -> Tuple[int, str, str]:
    """Run pip command and return (returncode, stdout, stderr)."""
    cmd = [sys.executable, "-m", "pip", *args]
    result = subprocess.run(cmd, capture_output=capture_output, text=True)
    stdout = result.stdout if capture_output else ""
    stderr = result.stderr if capture_output else ""
    return result.returncode, stdout, stderr


def run_pip_or_exit(args: Iterable[str]) -> None:
    """Run pip command and exit on failure."""
    returncode, _, _ = run_pip(args)
    if returncode != 0:
        sys.exit(returncode)


def get_distribution_name_from_entry_point(ep_name: str) -> Optional[str]:
    """Return the distribution name for a given entry-point name, if exists."""
    try:
        eps = metadata.entry_points(group=ENTRYPOINT_GROUP)
    except TypeError:
        eps = metadata.entry_points().get(ENTRYPOINT_GROUP, [])

    for ep in eps:
        if ep.name == ep_name:
            return ep.dist.metadata["Name"]
    return None


def get_plugin_location(dist_name: str) -> str:
    """
    Determine if a plugin is installed locally (venv) or globally.

    Returns: 'local', 'global', or 'unknown'
    """
    normalized = dist_name.replace("-", "_")

    # Check global installation
    global_dist_infos = list(PLUGIN_DIR.glob(f"{normalized}-*.dist-info"))
    if global_dist_infos:
        return "global"

    # Check local installation (in site-packages)
    site_packages = get_site_packages_dir()
    local_dist_infos = list(site_packages.glob(f"{normalized}-*.dist-info"))
    if local_dist_infos:
        return "local"

    return "unknown"


def validate_plugin_structure() -> None:
    """ Ensure each plugin installs exactly one subpackage under NAMESPACE """
    root = PLUGIN_DIR / NAMESPACE
    if not root.exists():
        return

    seen = set()
    for item in root.iterdir():
        if item.is_dir():
            if item.name in seen:
                raise RuntimeError(
                    f"Plugin name collision detected: {item.name}"
                )
            seen.add(item.name)

            if not (item / "plugin.yaml").exists():
                console.print(
                    f"[yellow]Warning: Missing plugin.yaml in {item.name}[/yellow]"
                )


def install_plugin(source: str, force: bool, local: bool = False) -> None:
    """
    Install a plugin either locally (venv) or globally.

    Args:
        source: Path to plugin zip/wheel or package name
        force: Force reinstall if already exists
        local: If True, install to current venv; if False, install globally
    """
    if local:
        install_plugin_local(source, force)
    else:
        install_plugin_global(source, force)


def install_plugin_local(source: str, force: bool) -> None:
    """
    Install plugin to current virtual environment's site-packages.

    This makes the plugin available only to the current project/venv.
    Discovery happens via Python entry points.
    """
    console.print(f"[cyan]Installing plugin locally from:[/cyan] {source}")

    args = ["install", source]
    if force:
        args += ["--upgrade", "--force-reinstall"]

    returncode, stdout, stderr = run_pip(args, capture_output=True)

    # Print pip output for visibility
    if stdout:
        print(stdout)
    if stderr:
        print(stderr, file=sys.stderr)

    if returncode != 0:
        console.print("\n[red]Plugin installation failed[/red]")
        sys.exit(returncode)

    # Verify installation by checking entry points
    # Re-import metadata to pick up newly installed package
    import importlib
    importlib.invalidate_caches()

    # Try to find the installed plugin
    try:
        eps = metadata.entry_points(group=ENTRYPOINT_GROUP)
        plugin_names = [ep.name for ep in eps]
        if plugin_names:
            console.print(
                f"\n[green]Plugin installed locally (venv)[/green]"
            )
            console.print(
                f"[dim]Available plugins: {', '.join(plugin_names)}[/dim]"
            )
        else:
            console.print(
                "\n[yellow]Warning: Plugin installed but no entry points found. "
                "Check pyproject.toml has [project.entry-points.\"agentflow.plugins\"][/yellow]"
            )
    except Exception as e:
        console.print(f"\n[yellow]Warning: Could not verify installation: {e}[/yellow]")


def install_plugin_global(source: str, force: bool) -> None:
    """
    Install plugin to ~/.agentflow/plugins (global installation).

    This makes the plugin available to all projects using agentflow.
    Requires PYTHONPATH to be set.
    """
    ensure_plugin_dir()

    console.print(f"[cyan]Installing plugin globally from:[/cyan] {source}")

    # Install to a temporary directory first to avoid namespace package conflicts
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)

        args = ["install", source, "--target", str(temp_path), "--no-deps"]
        if force:
            args += ["--upgrade", "--force-reinstall"]

        returncode, stdout, stderr = run_pip(args, capture_output=True)

        # Print pip output for visibility
        if stdout:
            print(stdout)
        if stderr:
            print(stderr, file=sys.stderr)

        if returncode != 0:
            console.print("\n[red]Plugin installation failed[/red]")
            sys.exit(returncode)

        # Find and copy plugin subdirectories from namespace package
        temp_namespace = temp_path / NAMESPACE
        target_namespace = PLUGIN_DIR / NAMESPACE
        plugins_copied = []

        if temp_namespace.exists() and temp_namespace.is_dir():
            target_namespace.mkdir(parents=True, exist_ok=True)

            for item in temp_namespace.iterdir():
                if item.is_dir() and not item.name.startswith("__"):
                    # Copy plugin subdirectory
                    target_subdir = target_namespace / item.name
                    if target_subdir.exists():
                        if force:
                            shutil.rmtree(target_subdir)
                        else:
                            console.print(
                                f"[yellow]Warning: Plugin '{item.name}' already exists. "
                                f"Use --force to overwrite.[/yellow]"
                            )
                            continue
                    shutil.copytree(item, target_subdir)
                    plugins_copied.append(item.name)

        # Copy .dist-info directories
        dist_info_copied = False
        for item in temp_path.iterdir():
            if item.name.endswith(".dist-info"):
                target_dist_info = PLUGIN_DIR / item.name
                if target_dist_info.exists():
                    shutil.rmtree(target_dist_info)
                shutil.copytree(item, target_dist_info)
                dist_info_copied = True

        # Verify installation
        if not plugins_copied:
            console.print(
                "\n[red]No plugin modules were installed. "
                "Check that the package contains an agentflow_plugins/ subdirectory.[/red]"
            )
            sys.exit(1)

        if not dist_info_copied:
            console.print(
                "\n[yellow]Warning: No .dist-info metadata found. "
                "Plugin may not appear in 'agentflow-plugins list'.[/yellow]"
            )

    validate_plugin_structure()

    console.print(
        f"\n[green]Plugin installed globally: {', '.join(plugins_copied)}[/green]"
    )
    console.print(
        f"\n[dim]Enable plugins with:[/dim]\n"
        f"  export PYTHONPATH={PLUGIN_DIR}:$PYTHONPATH"
    )


def uninstall_plugin(plugin_identifier: str, local: bool = False) -> None:
    """
    Uninstall a plugin.

    Args:
        plugin_identifier: Entry-point name or distribution name
        local: If True, uninstall from venv; if False, uninstall from global
    """
    dist_name = get_distribution_name_from_entry_point(plugin_identifier)
    if dist_name:
        console.print(f"[cyan]Resolved entry-point '{plugin_identifier}' → distribution '{dist_name}'[/cyan]")
    else:
        dist_name = plugin_identifier  # fallback to user-provided name

    if local:
        uninstall_plugin_local(dist_name)
    else:
        # Check if plugin is installed locally first
        location = get_plugin_location(dist_name)
        if location == "local":
            console.print(
                f"[yellow]Plugin '{plugin_identifier}' is installed locally (venv). "
                f"Use --local flag to uninstall.[/yellow]"
            )
            sys.exit(1)
        uninstall_plugin_global(dist_name, plugin_identifier)


def uninstall_plugin_local(dist_name: str) -> None:
    """Uninstall a locally installed plugin using pip."""
    console.print(f"[cyan]Uninstalling plugin from venv:[/cyan] {dist_name}")

    args = ["uninstall", dist_name, "-y"]
    returncode, stdout, stderr = run_pip(args, capture_output=True)

    if stdout:
        print(stdout)
    if stderr:
        print(stderr, file=sys.stderr)

    if returncode != 0:
        console.print(f"\n[red]Failed to uninstall plugin '{dist_name}'[/red]")
        sys.exit(returncode)

    console.print(f"[green]Plugin '{dist_name}' uninstalled from venv[/green]")


def uninstall_plugin_global(dist_name: str, plugin_identifier: str) -> None:
    """Uninstall a globally installed plugin from PLUGIN_DIR."""
    ensure_plugin_dir()

    # Normalize like pip does
    normalized = dist_name.replace("-", "_")

    dist_infos = list(PLUGIN_DIR.glob(f"{normalized}-*.dist-info"))
    if not dist_infos:
        console.print(f"[red]Plugin '{plugin_identifier}' not found in global plugins[/red]")
        sys.exit(1)

    for dist_info in dist_infos:
        record = dist_info / "RECORD"
        if not record.exists():
            continue

        console.print(f"[cyan]Uninstalling plugin from global:[/cyan] {plugin_identifier}")

        with record.open(newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                if not row:
                    continue
                rel_path = row[0]
                if not rel_path:
                    continue
                file_path = PLUGIN_DIR / rel_path
                if file_path.exists():
                    file_path.unlink(missing_ok=True)

        shutil.rmtree(dist_info, ignore_errors=True)

    # Cleanup empty directories
    for path in sorted(PLUGIN_DIR.rglob("*"), reverse=True):
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()

    console.print(f"[green]Plugin '{plugin_identifier}' uninstalled from global[/green]")


def list_plugins() -> None:
    """List all installed AgentFlow plugins with their installation location."""
    ensure_plugin_dir()

    eps = list(metadata.entry_points(group=ENTRYPOINT_GROUP))

    if not eps:
        console.print("[dim]No plugins found.[/dim]")
        console.print(
            "\n[dim]Install plugins with:[/dim]\n"
            "  agentflow-plugins install <source>         # global installation\n"
            "  agentflow-plugins install --local <source> # local (venv) installation"
        )
        return

    console.print("[bold]Installed AgentFlow plugins:[/bold]\n")

    # Create a rich table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Plugin", style="cyan")
    table.add_column("Distribution")
    table.add_column("Version")
    table.add_column("Location", style="dim")

    for ep in eps:
        dist = ep.dist
        dist_name = dist.metadata["Name"]
        location = get_plugin_location(dist_name)
        location_display = "venv" if location == "local" else "global" if location == "global" else "?"
        table.add_row(ep.name, dist_name, dist.version, location_display)

    console.print(table)


def show_plugin_info(plugin_name: str) -> None:
    """Show detailed information about an installed plugin."""
    dist_name = get_distribution_name_from_entry_point(plugin_name)
    if not dist_name:
        console.print(f"[red]Plugin '{plugin_name}' not found[/red]")
        sys.exit(1)

    eps = metadata.entry_points(group=ENTRYPOINT_GROUP)

    for ep in eps:
        if ep.name == plugin_name:
            dist = ep.dist
            location = get_plugin_location(dist.metadata["Name"])
            location_display = "venv (local)" if location == "local" else "~/.agentflow/plugins (global)" if location == "global" else "unknown"
            info = (
                f"Plugin Name: {ep.name}\n"
                f"Distribution: {dist.metadata['Name']}\n"
                f"Version: {dist.version}\n"
                f"Import Path: {ep.value}\n"
                f"Location: {location_display}"
            )
            console.print(Panel(info, title="Plugin Info"))
            return


def export_path() -> None:
    print(f"export PYTHONPATH={PLUGIN_DIR}:$PYTHONPATH")


from agentflow.cli.errors import wrap_cli_main


@wrap_cli_main
def main() -> None:
    parser = argparse.ArgumentParser(
        description="AgentFlow Plugin Manager (pip-based)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  agentflow-plugins install plugin.zip           # Install globally
  agentflow-plugins install --local plugin.zip   # Install to current venv
  agentflow-plugins list                         # Show all plugins
  agentflow-plugins uninstall metrics            # Uninstall global plugin
  agentflow-plugins uninstall --local metrics    # Uninstall from venv
"""
    )

    sub = parser.add_subparsers(dest="command")

    install = sub.add_parser(
        "install",
        help="Install plugin",
        description="Install a plugin globally or locally to the current venv"
    )
    install.add_argument("source", help="Plugin source (zip, wheel, or package name)")
    install.add_argument("--force", "-f", action="store_true", help="Force reinstall")
    install.add_argument(
        "--local", "-l",
        action="store_true",
        help="Install to current venv instead of globally"
    )

    uninstall = sub.add_parser(
        "uninstall",
        help="Uninstall plugin",
        description="Uninstall a plugin from global or local installation"
    )
    uninstall.add_argument(
        "plugin_identifier",
        help="Entry-point name or distribution name"
    )
    uninstall.add_argument(
        "--local", "-l",
        action="store_true",
        help="Uninstall from current venv instead of globally"
    )

    sub.add_parser("list", help="List installed plugins")

    info = sub.add_parser("info", help="Show plugin info")
    info.add_argument("plugin_name")

    sub.add_parser("export", help="Export PYTHONPATH for global plugins")

    args = parser.parse_args()

    if args.command == "install":
        install_plugin(args.source, args.force, args.local)
    elif args.command == "uninstall":
        uninstall_plugin(args.plugin_identifier, args.local)
    elif args.command == "list":
        list_plugins()
    elif args.command == "info":
        show_plugin_info(args.plugin_name)
    elif args.command == "export":
        export_path()
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
