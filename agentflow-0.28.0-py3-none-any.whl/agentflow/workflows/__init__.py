"""
AgentFlow: LangGraph Workflow Orchestrator
"""

try:
    from importlib.metadata import version

    __version__ = version("agentflow")
except Exception:
    __version__ = "0.0.0"

from .core import (
    AsyncWorkflowOrchestrator,
    WorkflowOrchestrator,  # Backward compatibility alias
    get_principal,
    register_span_processor,
    # MCP support
    MCPServerManager,
    MCPTransport,
    MCPServerConfig,
    MCPToolsReference,
    MCPToolAlias,
    MCPConnectionError,
    MCPToolError,
    ConnectionStatus,
)
from .plugins import Plugin, PluginManager, WorkflowContext

__all__ = [
    # Orchestrators
    "AsyncWorkflowOrchestrator",
    "WorkflowOrchestrator",  # Backward compatibility
    # Plugins
    "Plugin",
    "PluginManager",
    "WorkflowContext",
    # Caller identity
    "get_principal",
    # Telemetry exporter seam
    "register_span_processor",
    # MCP support
    "MCPServerManager",
    "MCPTransport",
    "MCPServerConfig",
    "MCPToolsReference",
    "MCPToolAlias",
    "MCPConnectionError",
    "MCPToolError",
    "ConnectionStatus",
    # Version
    "__version__",
]
