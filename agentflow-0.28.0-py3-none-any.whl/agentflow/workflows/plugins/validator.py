"""
Plugin package validation module.

Validates AgentFlow plugin packages against the specification.
"""

import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Dict, List, Tuple, Any

try:
    import tomli as toml  # Python < 3.11
except ImportError:
    import tomllib as toml  # Python >= 3.11


class PluginValidationError(Exception):
    """Raised when plugin validation fails."""
    pass


class PluginValidator:
    """Validates plugin packages against the AgentFlow plugin specification."""

    def __init__(self, plugin_path: str):
        """
        Initialize validator with plugin package path.

        Args:
            plugin_path: Path to plugin zip file
        """
        self.plugin_path = Path(plugin_path)
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.metadata: Dict[str, Any] = {}
        self.temp_dir = None

    def validate(self) -> Tuple[bool, List[str], List[str]]:
        """
        Validate the plugin package.

        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        self.errors = []
        self.warnings = []

        try:
            # Check if file exists
            if not self.plugin_path.exists():
                self.errors.append(f"Plugin file not found: {self.plugin_path}")
                return False, self.errors, self.warnings

            # Check if it's a zip file
            if not zipfile.is_zipfile(self.plugin_path):
                self.errors.append("Plugin file must be a zip archive")
                return False, self.errors, self.warnings

            # Extract to temp directory
            self.temp_dir = tempfile.mkdtemp(prefix="agentflow_plugin_")

            try:
                with zipfile.ZipFile(self.plugin_path, 'r') as zip_ref:
                    zip_ref.extractall(self.temp_dir)

                # Validate structure
                self._validate_structure()

                # Validate pyproject.toml
                if not self.errors:
                    self._validate_pyproject()

                # Validate plugin code
                if not self.errors:
                    self._validate_plugin_code()

                # Check for optional files
                self._check_optional_files()

            finally:
                # Cleanup temp directory
                if self.temp_dir and os.path.exists(self.temp_dir):
                    shutil.rmtree(self.temp_dir)

            return len(self.errors) == 0, self.errors, self.warnings

        except Exception as e:
            self.errors.append(f"Validation error: {str(e)}")
            return False, self.errors, self.warnings

    def _validate_structure(self):
        """Validate plugin package directory structure."""
        # Find the plugin root directory
        entries = os.listdir(self.temp_dir)

        # Should have exactly one directory
        plugin_dirs = [e for e in entries if os.path.isdir(os.path.join(self.temp_dir, e))]

        if len(plugin_dirs) == 0:
            self.errors.append("No plugin directory found in zip file")
            return

        if len(plugin_dirs) > 1:
            self.errors.append(
                f"Multiple directories found in zip: {plugin_dirs}. Should contain only one plugin directory")
            return

        self.plugin_root = os.path.join(self.temp_dir, plugin_dirs[0])

        # Check for required files
        required_files = ['pyproject.toml']
        for required_file in required_files:
            file_path = os.path.join(self.plugin_root, required_file)
            if not os.path.exists(file_path):
                self.errors.append(f"Missing required file: {required_file}")

        # Check for agentflow_plugins directory
        plugins_dir = os.path.join(self.plugin_root, 'agentflow_plugins')
        if not os.path.exists(plugins_dir):
            self.errors.append("Missing required directory: agentflow_plugins/")
            return

        # Check for __init__.py in agentflow_plugins
        init_file = os.path.join(plugins_dir, '__init__.py')
        if not os.path.exists(init_file):
            self.errors.append("Missing required file: agentflow_plugins/__init__.py")

    def _validate_pyproject(self):
        """Validate pyproject.toml content."""
        pyproject_path = os.path.join(self.plugin_root, 'pyproject.toml')

        try:
            with open(pyproject_path, 'rb') as f:
                self.metadata = toml.load(f)
        except Exception as e:
            self.errors.append(f"Invalid pyproject.toml: {e}")
            return

        # Check required fields
        required_fields = {
            ('project', 'name'): 'project.name',
            ('project', 'version'): 'project.version',
            ('project', 'description'): 'project.description',
            ('project', 'authors'): 'project.authors',
        }

        for field_path, field_name in required_fields.items():
            current = self.metadata
            for key in field_path:
                if key not in current:
                    self.errors.append(f"Missing required field in pyproject.toml: {field_name}")
                    break
                current = current[key]

        # Validate plugin name format
        if 'project' in self.metadata and 'name' in self.metadata['project']:
            name = self.metadata['project']['name']
            if not re.match(r'^plugin-[a-z0-9\-]+$', name):
                self.errors.append(
                    f"Invalid plugin name '{name}'. Must start with 'plugin-' and contain only lowercase letters, numbers, and hyphens"
                )

        # Check for AgentFlow plugin configuration
        if 'tool' not in self.metadata or 'agentflow' not in self.metadata.get('tool', {}):
            self.errors.append("Missing [tool.agentflow.plugin] section in pyproject.toml")
            return

        plugin_config = self.metadata.get('tool', {}).get('agentflow', {}).get('plugin', {})

        if 'entry_point' not in plugin_config:
            self.errors.append("Missing tool.agentflow.plugin.entry_point in pyproject.toml")

        if 'type' not in plugin_config:
            self.warnings.append("Missing tool.agentflow.plugin.type (recommended)")

        # Validate entry point format
        if 'entry_point' in plugin_config:
            entry_point = plugin_config['entry_point']
            if ':' not in entry_point:
                self.errors.append(
                    f"Invalid entry_point format: '{entry_point}'. Must be 'module:ClassName'"
                )

        # Validate version format
        if 'project' in self.metadata and 'version' in self.metadata['project']:
            version = self.metadata['project']['version']
            if not re.match(r'^\d+\.\d+\.\d+', version):
                self.warnings.append(
                    f"Version '{version}' doesn't follow semantic versioning (MAJOR.MINOR.PATCH)"
                )

    def _validate_plugin_code(self):
        """Validate that the plugin code is importable and valid."""
        if not self.metadata:
            return

        plugin_config = self.metadata.get('tool', {}).get('agentflow', {}).get('plugin', {})
        entry_point = plugin_config.get('entry_point', '')

        if ':' not in entry_point:
            return  # Already reported as error

        module_path, class_name = entry_point.split(':', 1)

        # Check if module file exists
        module_file = module_path.replace('.', '/') + '.py'
        full_module_path = os.path.join(self.plugin_root, module_file)

        if not os.path.exists(full_module_path):
            self.errors.append(
                f"Entry point module not found: {module_file}"
            )
            return

        # Read the module file to check for class definition
        try:
            with open(full_module_path, 'r') as f:
                content = f.read()

            # Check if class is defined
            class_pattern = rf'class\s+{re.escape(class_name)}\s*\('
            if not re.search(class_pattern, content):
                self.errors.append(
                    f"Plugin class '{class_name}' not found in {module_file}"
                )

            # Check if it inherits from Plugin
            if 'Plugin' not in content or 'from agentflow.workflows.plugins import' not in content:
                self.warnings.append(
                    f"Plugin class may not inherit from agentflow.workflows.plugins.Plugin"
                )

        except Exception as e:
            self.errors.append(f"Error reading plugin module: {e}")

    def _check_optional_files(self):
        """Check for recommended optional files."""
        optional_files = {
            'README.md': 'Documentation',
            'LICENSE': 'License information',
            'requirements.txt': 'Dependencies specification'
        }

        for file_name, description in optional_files.items():
            file_path = os.path.join(self.plugin_root, file_name)
            if not os.path.exists(file_path):
                self.warnings.append(f"Missing {description} ({file_name}) - recommended")

    def get_metadata(self) -> Dict[str, Any]:
        """
        Get plugin metadata from pyproject.toml.

        Returns:
            Dictionary containing plugin metadata
        """
        return self.metadata


def validate_plugin(plugin_path: str, verbose: bool = True) -> bool:
    """
    Validate a plugin package.

    Args:
        plugin_path: Path to plugin zip file
        verbose: Print validation results

    Returns:
        True if valid, False otherwise
    """
    validator = PluginValidator(plugin_path)
    is_valid, errors, warnings = validator.validate()

    if verbose:
        print(f"\nValidating plugin: {plugin_path}")
        print("=" * 60)

        if errors:
            print("\nErrors:")
            for error in errors:
                print(f"  • {error}")

        if warnings:
            print("\nWarnings:")
            for warning in warnings:
                print(f"  • {warning}")

        if is_valid:
            print("\nPlugin validation passed!")

            # Show metadata
            metadata = validator.get_metadata()
            if 'project' in metadata:
                print("\nPlugin Info:")
                print(f"  Name: {metadata['project'].get('name', 'N/A')}")
                print(f"  Version: {metadata['project'].get('version', 'N/A')}")
                print(f"  Description: {metadata['project'].get('description', 'N/A')}")

                if 'tool' in metadata and 'agentflow' in metadata['tool']:
                    plugin_config = metadata['tool']['agentflow'].get('plugin', {})
                    print(f"  Type: {plugin_config.get('type', 'N/A')}")
                    print(f"  Entry Point: {plugin_config.get('entry_point', 'N/A')}")
        else:
            print("\nPlugin validation failed!")

    return is_valid
