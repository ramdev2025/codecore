"""
AgentFlow Plugin System

Provides extensibility for workflow orchestration through plugins.
"""

from .base import Plugin, PluginManager, WorkflowContext, import_from_plugin, PLUGIN_NAMESPACE_PACKAGE

__all__ = [
    "Plugin",
    "PluginManager",
    "WorkflowContext",
    "import_from_plugin",
    "PLUGIN_NAMESPACE_PACKAGE"
]
