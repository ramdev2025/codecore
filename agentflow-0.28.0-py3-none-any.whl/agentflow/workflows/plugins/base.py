"""
Base plugin interfaces and plugin manager.
"""

import importlib.util
import os
import sys
from abc import ABC
from importlib.metadata import entry_points
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from agentflow.workflows.core.runtime_models import WorkflowContext

load_dotenv(override=True)

__all__ = [
    "PLUGIN_DIR",
    "Plugin",
    "PluginManager",
    "WorkflowContext",
    "import_from_plugin",
]

if os.getenv("AGENTFLOW_PLUGIN_DIR"):
    PLUGIN_DIR = Path(os.environ["AGENTFLOW_PLUGIN_DIR"])
else:
    PLUGIN_DIR = Path.home() / ".agentflow" / "plugins"

PLUGIN_DIR.mkdir(parents=True, exist_ok=True)  # create if missing

if PLUGIN_DIR not in sys.path:
    sys.path.insert(0, str(PLUGIN_DIR))

PLUGIN_NAMESPACE_PACKAGE = "agentflow_plugins"


class Plugin(ABC):
    """
    Base plugin interface.

    Plugins can hook into workflow lifecycle events to add custom behavior
    like telemetry, logging, testing, validation, etc.
    """

    @property
    def name(self) -> str:
        """Plugin name for identification"""
        return self.__class__.__name__

    def shutdown(self) -> None:
        """
        Called when the orchestrator is shutting down.

        Override this method to clean up any resources (background threads,
        connections, file handles, etc.) that the plugin may have created.

        This is called after all workflow executions are complete and before
        the process exits.
        """
        pass

    def on_workflow_start(self, context: WorkflowContext, initial_state: dict[str, Any]) -> None:
        """
        Called when workflow execution starts.

        Args:
            context: Workflow context with execution metadata
            initial_state: Initial workflow state
        """
        pass

    def on_workflow_end(self, context: WorkflowContext, final_state: dict[str, Any], status: str = "completed") -> None:
        """
        Called when workflow execution ends.

        Args:
            context: Workflow context with execution metadata
            final_state: Final workflow state
            status: Execution status (completed, error, cancelled)
        """
        pass

    def on_agent_start(self, context: WorkflowContext, agent_name: str, state: dict[str, Any]) -> None:
        """
        Called when an agent starts processing.

        Args:
            context: Workflow context
            agent_name: Name of the agent
            state: Current state
        """
        pass

    def on_agent_end(self, context: WorkflowContext, agent_name: str, result: dict[str, Any]) -> None:
        """
        Called when an agent completes processing.

        Args:
            context: Workflow context
            agent_name: Name of the agent
            result: Agent result
        """
        pass

    def on_tool_call(self, context: WorkflowContext, tool_name: str, inputs: dict[str, Any]) -> None:
        """
        Called when a tool is invoked.

        Args:
            context: Workflow context
            tool_name: Name of the tool
            inputs: Tool inputs
        """
        pass

    def on_tool_result(self, context: WorkflowContext, tool_name: str, result: Any) -> None:
        """
        Called when a tool returns a result.

        Args:
            context: Workflow context
            tool_name: Name of the tool
            result: Tool result
        """
        pass

    def on_error(self, context: WorkflowContext, error: Exception, error_context: dict[str, Any]) -> None:
        """
        Called when an error occurs.

        Args:
            context: Workflow context
            error: The exception that occurred
            error_context: Additional context about the error
        """
        pass

    def on_llm_start(self, context: WorkflowContext, model: str, messages: list[dict[str, Any]]) -> None:
        """
        Called when LLM call starts.

        Args:
            context: Workflow context
            model: Model name
            messages: Input messages
        """
        pass

    def on_llm_end(self, context: WorkflowContext, model: str, response: dict[str, Any]) -> None:
        """
        Called when LLM call completes.

        Args:
            context: Workflow context
            model: Model name
            response: LLM response
        """
        pass

    # =========================================================================
    # MCP (Model Context Protocol) Events
    # =========================================================================

    def on_mcp_connect(self, context: WorkflowContext, server_name: str, tool_count: int) -> None:
        """
        Called when an MCP server connection is established.

        Args:
            context: Workflow context
            server_name: Name of the MCP server
            tool_count: Number of tools discovered from the server
        """
        pass

    def on_mcp_tool_call(
        self, context: WorkflowContext, server_name: str, tool_name: str, arguments: dict[str, Any]
    ) -> None:
        """
        Called before an MCP tool is invoked.

        Args:
            context: Workflow context
            server_name: Name of the MCP server
            tool_name: Name of the tool being called
            arguments: Tool arguments
        """
        pass

    def on_mcp_tool_result(
        self, context: WorkflowContext, server_name: str, tool_name: str, result: str, error: str = None
    ) -> None:
        """
        Called after an MCP tool returns a result.

        Args:
            context: Workflow context
            server_name: Name of the MCP server
            tool_name: Name of the tool
            result: Tool result (may be error message if error is set)
            error: Error type if the tool call failed, None otherwise
        """
        pass

    # =========================================================================
    # Human-in-the-Loop (HITL) Events
    # =========================================================================

    def on_hitl_start(self, context: WorkflowContext, interrupt_type: str, prompt: str) -> None:
        """
        Called when a human-in-the-loop interrupt starts (waiting for human input).

        Args:
            context: Workflow context
            interrupt_type: Type of interrupt (e.g., "approval", "input", "review")
            prompt: The prompt/question shown to the human
        """
        pass

    def on_hitl_end(self, context: WorkflowContext, interrupt_type: str, response: Any) -> None:
        """
        Called when human-in-the-loop input is received.

        Args:
            context: Workflow context
            interrupt_type: Type of interrupt
            response: The human's response
        """
        pass

    # =========================================================================
    # External Agent (A2A) Events
    # =========================================================================

    def on_external_agent_start(self, context: WorkflowContext, agent_name: str, endpoint: str, message: str) -> None:
        """
        Called when an external A2A agent call starts.

        Args:
            context: Workflow context
            agent_name: Name of the external agent
            endpoint: The agent's endpoint URL
            message: Message being sent to the agent
        """
        pass

    def on_external_agent_end(
        self, context: WorkflowContext, agent_name: str, endpoint: str, response: str, error: str = None
    ) -> None:
        """
        Called when an external A2A agent call completes.

        Args:
            context: Workflow context
            agent_name: Name of the external agent
            endpoint: The agent's endpoint URL
            response: The agent's response
            error: Error message if the call failed, None otherwise
        """
        pass

    # =========================================================================
    # Checkpoint Events
    # =========================================================================

    def on_checkpoint_save(self, context: WorkflowContext, checkpoint_id: str, data_size: int) -> None:
        """
        Called when a checkpoint is saved.

        Args:
            context: Workflow context
            checkpoint_id: Unique identifier for the checkpoint
            data_size: Size of checkpoint data in bytes
        """
        pass

    def on_checkpoint_load(self, context: WorkflowContext, checkpoint_id: str, success: bool) -> None:
        """
        Called when a checkpoint is loaded.

        Args:
            context: Workflow context
            checkpoint_id: Unique identifier for the checkpoint
            success: Whether the load was successful
        """
        pass


def import_from_plugin(plugin_name: str, module_path: str = ""):
    """
    Import a module from an installed plugin.

    Supports both globally installed plugins (in PLUGIN_DIR) and locally
    installed plugins (in current venv's site-packages).

    Args:
        plugin_name: plugin subpackage name (e.g., 'regression_test')
        module_path: module path inside plugin (e.g., 'testing.runner')

    Returns:
        Imported module

    Examples:
        # Import entire plugin package
        plugin = import_from_plugin('regression_test')

        # Import specific module
        runner = import_from_plugin('regression_test', 'testing.runner')

        # Import specific function
        mod = import_from_plugin('regression_test', 'testing')
        run_test_suite = mod.run_test_suite
    """
    import importlib

    # Ensure PLUGIN_DIR is in sys.path for global plugins
    if str(PLUGIN_DIR) not in sys.path:
        sys.path.insert(0, str(PLUGIN_DIR))

    # Full import path: <plugin_namespace>.<plugin_name>.<module_path>
    full_module_path = f"{PLUGIN_NAMESPACE_PACKAGE}.{plugin_name}"
    if module_path:
        full_module_path += f".{module_path}"

    try:
        return importlib.import_module(full_module_path)
    except ImportError as e:
        # Provide helpful error message
        raise ImportError(
            f"Could not import '{module_path or plugin_name}' from plugin '{plugin_name}'. "
            f"Make sure the plugin is installed:\n"
            f"  agentflow-plugins install --local <plugin>  # for venv installation\n"
            f"  agentflow-plugins install <plugin>          # for global installation\n"
            f"Original error: {e}"
        )


class PluginManager:
    """Manages plugins and dispatches lifecycle events"""

    def __init__(self):
        self.plugins: list[Plugin] = []

    def register(self, plugin: Plugin) -> None:
        """Register a plugin (prevents duplicate registration of same plugin class)"""
        # Check if a plugin of the same class is already registered
        for existing in self.plugins:
            if type(existing).__name__ == type(plugin).__name__:
                # Plugin of this type already registered, skip
                return
        self.plugins.append(plugin)
        print(f"Registered plugin: {plugin.name}")

    def discover_and_register_plugins(self) -> None:
        """
        Auto-discover and register plugins from entry points and/or a plugin directory.

        This allows plugins to be installed as separate packages and
        automatically discovered without manual registration.
        """

        # Discover plugins registered under the 'agentflow.plugins' entry point group
        discovered = entry_points(group="agentflow.plugins")

        for entry_point in discovered:
            try:
                # Load the plugin class
                plugin_class = entry_point.load()

                # Instantiate and register
                plugin_instance = plugin_class()
                self.register(plugin_instance)

            except Exception as e:
                print(f"Failed to load plugin {entry_point.name}: {e}")

        # Second, load built-in plugins
        self._load_builtin_plugins()

        # Third, discover and load custom plugins
        self._load_custom_plugins()

    def _load_builtin_plugins(self):
        # No built-in plugins are registered here today.
        return

    def _load_custom_plugins(self) -> None:
        """
        Load plugins from a directory.

        Expects Python files or packages in the directory that export a
        Plugin class or have a 'plugin' attribute containing a Plugin instance.
        """
        for item in os.listdir(PLUGIN_DIR):
            item_path = os.path.join(PLUGIN_DIR, item)

            # Handle Python files
            if item.endswith(".py") and not item.startswith("_"):
                module_name = item[:-3]
                try:
                    spec = importlib.util.spec_from_file_location(module_name, item_path)
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)

                        # Try to find and instantiate plugin
                        self._register_plugin_from_module(module, module_name)

                except Exception as e:
                    print(f"Failed to load plugin from {item}: {e}")

            # Handle Python packages (directories with __init__.py)
            elif os.path.isdir(item_path) and os.path.exists(os.path.join(item_path, "__init__.py")):
                try:
                    spec = importlib.util.spec_from_file_location(item, os.path.join(item_path, "__init__.py"))
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)

                        # Try to find and instantiate plugin
                        self._register_plugin_from_module(module, item)

                except Exception as e:
                    print(f"Failed to load plugin from {item}: {e}")

    def _register_plugin_from_module(self, module, module_name: str) -> None:
        """
        Find and register plugin from a loaded module.

        Args:
            module: The loaded Python module
            module_name: Name of the module (for error messages)
        """
        # Look for a 'plugin' attribute (already instantiated)
        if hasattr(module, "plugin") and isinstance(module.plugin, Plugin):
            self.register(module.plugin)
            return

        # Look for Plugin subclasses
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, type) and issubclass(attr, Plugin) and attr is not Plugin:
                try:
                    plugin_instance = attr()
                    self.register(plugin_instance)
                    return
                except Exception as e:
                    print(f"Failed to instantiate plugin {attr_name} from {module_name}: {e}")

        print(f"Warning: No plugin found in module {module_name}")

    def unregister(self, plugin: Plugin) -> None:
        """Unregister a plugin"""
        self.plugins.remove(plugin)
        print(f"Unregistered plugin: {plugin.name}")

    def emit_workflow_start(self, context: WorkflowContext, initial_state: dict[str, Any]) -> None:
        """Emit workflow start event to all plugins"""
        for plugin in self.plugins:
            try:
                plugin.on_workflow_start(context, initial_state)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_workflow_start: {e}")

    def emit_workflow_end(
        self, context: WorkflowContext, final_state: dict[str, Any], status: str = "completed"
    ) -> None:
        """Emit workflow end event to all plugins"""
        for plugin in self.plugins:
            try:
                plugin.on_workflow_end(context, final_state, status)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_workflow_end: {e}")

    def emit_agent_start(self, context: WorkflowContext, agent_name: str, state: dict[str, Any]) -> None:
        """Emit agent start event"""
        for plugin in self.plugins:
            try:
                plugin.on_agent_start(context, agent_name, state)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_agent_start: {e}")

    def emit_agent_end(self, context: WorkflowContext, agent_name: str, result: dict[str, Any]) -> None:
        """Emit agent end event"""
        for plugin in self.plugins:
            try:
                plugin.on_agent_end(context, agent_name, result)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_agent_end: {e}")

    def emit_tool_call(self, context: WorkflowContext, tool_name: str, inputs: dict[str, Any]) -> None:
        """Emit tool call event"""
        for plugin in self.plugins:
            try:
                plugin.on_tool_call(context, tool_name, inputs)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_tool_call: {e}")

    def emit_tool_result(self, context: WorkflowContext, tool_name: str, result: Any) -> None:
        """Emit tool result event"""
        for plugin in self.plugins:
            try:
                plugin.on_tool_result(context, tool_name, result)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_tool_result: {e}")

    def emit_error(self, context: WorkflowContext, error: Exception, error_context: dict[str, Any]) -> None:
        """Emit error event"""
        for plugin in self.plugins:
            try:
                plugin.on_error(context, error, error_context)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_error: {e}")

    def emit_llm_start(self, context: WorkflowContext, model: str, messages: list[dict[str, Any]]) -> None:
        """Emit LLM start event"""
        for plugin in self.plugins:
            try:
                plugin.on_llm_start(context, model, messages)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_llm_start: {e}")

    def emit_llm_end(self, context: WorkflowContext, model: str, response: dict[str, Any]) -> None:
        """Emit LLM end event"""
        for plugin in self.plugins:
            try:
                plugin.on_llm_end(context, model, response)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_llm_end: {e}")

    # =========================================================================
    # MCP (Model Context Protocol) Events
    # =========================================================================

    def emit_mcp_connect(self, context: WorkflowContext, server_name: str, tool_count: int) -> None:
        """Emit MCP server connect event"""
        for plugin in self.plugins:
            try:
                plugin.on_mcp_connect(context, server_name, tool_count)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_mcp_connect: {e}")

    def emit_mcp_tool_call(
        self, context: WorkflowContext, server_name: str, tool_name: str, arguments: dict[str, Any]
    ) -> None:
        """Emit MCP tool call event"""
        for plugin in self.plugins:
            try:
                plugin.on_mcp_tool_call(context, server_name, tool_name, arguments)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_mcp_tool_call: {e}")

    def emit_mcp_tool_result(
        self, context: WorkflowContext, server_name: str, tool_name: str, result: str, error: str = None
    ) -> None:
        """Emit MCP tool result event"""
        for plugin in self.plugins:
            try:
                plugin.on_mcp_tool_result(context, server_name, tool_name, result, error)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_mcp_tool_result: {e}")

    # =========================================================================
    # Human-in-the-Loop (HITL) Events
    # =========================================================================

    def emit_hitl_start(self, context: WorkflowContext, interrupt_type: str, prompt: str) -> None:
        """Emit HITL start event (waiting for human input)"""
        for plugin in self.plugins:
            try:
                plugin.on_hitl_start(context, interrupt_type, prompt)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_hitl_start: {e}")

    def emit_hitl_end(self, context: WorkflowContext, interrupt_type: str, response: Any) -> None:
        """Emit HITL end event (human input received)"""
        for plugin in self.plugins:
            try:
                plugin.on_hitl_end(context, interrupt_type, response)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_hitl_end: {e}")

    # =========================================================================
    # External Agent (A2A) Events
    # =========================================================================

    def emit_external_agent_start(self, context: WorkflowContext, agent_name: str, endpoint: str, message: str) -> None:
        """Emit external agent call start event"""
        for plugin in self.plugins:
            try:
                plugin.on_external_agent_start(context, agent_name, endpoint, message)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_external_agent_start: {e}")

    def emit_external_agent_end(
        self, context: WorkflowContext, agent_name: str, endpoint: str, response: str, error: str = None
    ) -> None:
        """Emit external agent call end event"""
        for plugin in self.plugins:
            try:
                plugin.on_external_agent_end(context, agent_name, endpoint, response, error)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_external_agent_end: {e}")

    # =========================================================================
    # Checkpoint Events
    # =========================================================================

    def emit_checkpoint_save(self, context: WorkflowContext, checkpoint_id: str, data_size: int) -> None:
        """Emit checkpoint save event"""
        for plugin in self.plugins:
            try:
                plugin.on_checkpoint_save(context, checkpoint_id, data_size)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_checkpoint_save: {e}")

    def emit_checkpoint_load(self, context: WorkflowContext, checkpoint_id: str, success: bool) -> None:
        """Emit checkpoint load event"""
        for plugin in self.plugins:
            try:
                plugin.on_checkpoint_load(context, checkpoint_id, success)
            except Exception as e:
                print(f"Error in plugin {plugin.name}.on_checkpoint_load: {e}")

    def shutdown(self) -> None:
        """
        Shutdown all plugins and release their resources.

        This should be called when the orchestrator is shutting down to ensure
        all plugins have a chance to clean up (close connections, flush buffers,
        stop background threads, etc.).
        """
        for plugin in self.plugins:
            try:
                plugin.shutdown()
            except Exception as e:
                print(f"Error shutting down plugin {plugin.name}: {e}")
