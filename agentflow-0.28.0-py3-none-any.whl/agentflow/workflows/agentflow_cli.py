"""
AgentFlow CLI — Run AI workflows from the command line.

Usage:
    agentflow "What is the weather today?"
    agentflow --yaml my_workflow.yaml --tools my_tools "Process this request"
    agentflow --interactive
    agentflow --thread-id abc123 "Continue our conversation"
"""

import asyncio
import logging
import os
import sys
import uuid
from typing import Any

import typer
from dotenv import load_dotenv
from langgraph.errors import GraphInterrupt
from langgraph.types import Command
from pydantic import ValidationError

from agentflow.cli import (
    ExecutionTimer,
    console,
    print_agent_end,
    print_agent_response,
    print_agent_start,
    print_banner,
    print_error,
    print_execution_summary,
    print_info,
    print_interrupt_prompt,
    print_reasoning_marker,
    print_token,
    print_tool_call,
    print_tool_result,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_AGENT_END,
    EVENT_AGENT_START,
    EVENT_COMPLETE,
    EVENT_ERROR,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)
from agentflow.workflows import AsyncWorkflowOrchestrator
from agentflow.workflows.core.config_models import (
    PersistenceConfig,
)
from agentflow.workflows.core.persistence_manager import (
    resolve_persistence_config_from_env,
)


def _persistence_config_from_cli(
    persistence: str | None,
    db_path: str | None,
    connection_string: str | None,
) -> PersistenceConfig | None:
    """Build a PersistenceConfig from CLI flags and environment variables.

    A thin wrapper over
    :func:`agentflow.workflows.core.persistence_manager.resolve_persistence_config_from_env`,
    which embedding apps use too — the CLI only adds its flags as overrides
    and converts errors into friendly ``typer`` messages. See that function
    for the full env-var contract and precedence rules.

    Returns ``None`` when neither CLI flags nor any persistence-selecting
    environment variable is present, letting the caller fall through to the
    SQLite default.
    """
    try:
        return resolve_persistence_config_from_env(
            persistence=persistence,
            db_path=db_path,
            connection_string=connection_string,
        )
    except (ValueError, ValidationError) as exc:
        raise typer.BadParameter(str(exc)) from None


# ---------------------------------------------------------------------------
# Stream renderer — converts orchestrator yield events into terminal output
# ---------------------------------------------------------------------------


class _StreamRenderer:
    """Renders ``orchestrator.run()`` events as token-by-token CLI output.

    Mirrors the maf/oai/cas pattern: stream text inline, show ``▸`` tool
    call lines with args, ``←`` result lines with size + preview, and
    a one-time ``· thinking…`` marker per reasoning streak. The
    Panel-after rendering is suppressed once tokens have started
    flowing so we don't double-print the agent's response.
    """

    def __init__(self) -> None:
        self._streaming_text = False
        # Tracks which agents have streamed text — used to suppress the
        # final agent panel for those (their content already appeared).
        self._streamed_agents: set[str] = set()
        # Tracks reasoning streak per agent so we only print one marker.
        self._reasoning_active: dict[str, bool] = {}

    def render(self, event: dict) -> None:
        etype = event.get("type")
        if etype == "agent_start":
            self._end_text_stream()
            print_agent_start(event.get("name", "agent"))
        elif etype == "agent_end":
            self._end_text_stream()
            usage = event.get("usage")
            tokens = self._extract_tokens(usage)
            print_agent_end(event.get("name", "agent"), tokens=tokens)
        elif etype == "token":
            self._stream_token(event)
        elif etype == "agent":
            self._render_agent(event)
        elif etype == "tool_call":
            self._end_text_stream()
            print_tool_call(event.get("name", "tool"), event.get("args"))
        elif etype == "tool":
            self._end_text_stream()
            print_tool_result(event.get("name", "tool"), event.get("content", ""))
        elif etype == "log":
            self._end_text_stream()
            print_info(f"{event.get('name', '')}: {event.get('content', '')}")
        elif etype == "error":
            self._end_text_stream()
            print_error(event.get("message", "Unknown error"))

    def flush(self) -> None:
        self._end_text_stream()

    # -- Helpers -----------------------------------------------------------

    def _stream_token(self, event: dict) -> None:
        """Stream incremental token content from on_chat_model_stream.

        Content can be a plain string OR a list of langchain anthropic
        content blocks (``{"type": "text" | "thinking" | "tool_use", …}``).
        We emit text inline and surface a single ``thinking…`` marker
        for each reasoning streak.
        """
        agent_name = event.get("name", "agent")
        content = event.get("content", "")
        if isinstance(content, str):
            if content:
                self._stream_text(content)
                self._reasoning_active[agent_name] = False
                self._streamed_agents.add(agent_name)
            return
        if not isinstance(content, list):
            return
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                text = block.get("text", "")
                if text:
                    self._stream_text(text)
                    self._reasoning_active[agent_name] = False
                    self._streamed_agents.add(agent_name)
            elif btype == "thinking":
                if not self._reasoning_active.get(agent_name):
                    self._end_text_stream()
                    print_reasoning_marker()
                    self._reasoning_active[agent_name] = True
            # tool_use deltas are ignored here; the orchestrator emits a
            # separate tool_call event with the full args.

    def _render_agent(self, event: dict) -> None:
        """Render the on_chat_model_end agent message.

        If we already streamed this agent's text token-by-token, the
        panel would duplicate it — suppress and just close the line.
        Otherwise (no stream_tokens, or list-of-blocks containing
        non-text), fall back to the historical panel rendering of any
        text we haven't seen yet.
        """
        name = event.get("name", "agent")
        content = event.get("content", "")
        if name in self._streamed_agents:
            self._end_text_stream()
            return
        if isinstance(content, list):
            text_parts: list[str] = []
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                else:
                    text_parts.append(str(item))
            text = "".join(text_parts).strip()
            if text:
                print_agent_response(name, text)
        elif content and isinstance(content, str) and content.strip():
            print_agent_response(name, content)

    def _stream_text(self, text: str) -> None:
        if not self._streaming_text:
            console.print()  # leading newline so streamed text starts on its own line
            self._streaming_text = True
        print_token(text)

    def _end_text_stream(self) -> None:
        if self._streaming_text:
            console.print()
            self._streaming_text = False

    @staticmethod
    def _extract_tokens(usage: Any) -> int | None:
        if not usage:
            return None
        if isinstance(usage, dict):
            return usage.get("total_tokens", 0) or None
        if hasattr(usage, "total_tokens"):
            return usage.total_tokens or None
        return None


app = typer.Typer(
    name="agentflow",
    help="AgentFlow — Run AI workflows from the command line.",
    add_completion=False,
    rich_markup_mode="rich",
)


# ---------------------------------------------------------------------------
# JSON-event emission — translates orchestrator yield events into the
# stable schema declared in agentflow.cli.events. Called from
# ``run_workflow`` when the user passes ``--output {json,ndjson}``.
# ---------------------------------------------------------------------------


def _emit_workflow_event(sink: JsonSink, result: dict) -> None:
    """Forward a single orchestrator event to a JsonSink as ndjson.

    The orchestrator yields events shaped like
    ``{"type": "agent" | "tool" | "tool_call" | "token" | …, "name": …, …}``.
    We map them onto :data:`agentflow.cli.events.EVENT_TYPES` and
    pass through the structured fields verbatim so downstream
    consumers can rely on the schema.
    """
    etype = result.get("type")
    name = result.get("name")
    workflow = result.get("workflow")
    if etype == "agent_start":
        sink.emit(EVENT_AGENT_START, name=name, workflow=workflow)
    elif etype == "agent_end":
        sink.emit(
            EVENT_AGENT_END,
            name=name,
            workflow=workflow,
            usage=result.get("usage"),
        )
    elif etype == "agent":
        # Final assistant message — only emit when content is non-empty
        # text; the tokens already covered the streamed case.
        content = result.get("content")
        if isinstance(content, str) and content.strip():
            sink.emit(EVENT_TOKEN, name=name, workflow=workflow, content=content)
    elif etype == "token":
        content = result.get("content")
        if isinstance(content, str) and content:
            sink.emit(EVENT_TOKEN, name=name, workflow=workflow, content=content)
        elif isinstance(content, list):
            # Anthropic-style content blocks — emit text fragments and a
            # single ``reasoning`` event for the streak.
            saw_thinking = False
            for block in content:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    text = block.get("text", "")
                    if text:
                        sink.emit(EVENT_TOKEN, name=name, workflow=workflow, content=text)
                elif btype == "thinking":
                    saw_thinking = True
            if saw_thinking:
                sink.emit(EVENT_REASONING, name=name, workflow=workflow)
    elif etype == "tool_call":
        sink.emit(
            EVENT_TOOL_CALL,
            name=name,
            workflow=workflow,
            args=result.get("args"),
        )
    elif etype == "tool":
        sink.emit(
            EVENT_TOOL,
            name=name,
            workflow=workflow,
            content=result.get("content"),
        )
    elif etype == "error":
        sink.emit(EVENT_ERROR, message=result.get("message", ""))
    # ``log`` and other internal types are intentionally omitted from the
    # schema — consumers shouldn't depend on them.


# ---------------------------------------------------------------------------
# Core workflow runner
# ---------------------------------------------------------------------------


async def run_workflow(
    query: str,
    config_path: str = "workflow.yaml",
    tools_module: str | None = None,
    enable_persistence: bool = True,
    checkpointer_path: str = ".agentflow/checkpoints.db",
    thread_id: str | None = None,
    recursion_limit: int | None = None,
    json_sink: JsonSink | None = None,
    persistence_config: PersistenceConfig | None = None,
):
    """Execute a workflow and print results.

    When ``json_sink`` is provided, events are emitted as ndjson to
    that sink and the terminal renderer is suppressed — used by the
    ``--output {json,ndjson}`` mode for machine-readable output.
    """
    # Auto-detect tools_module if not provided
    if tools_module is None:
        if os.path.isdir("tools"):
            tools_module = "tools"
        elif os.path.exists("tools.py"):
            tools_module = "tools"

    run_config = {
        "configurable": {"thread_id": thread_id or str(uuid.uuid4())},
    }

    initial_state = {"messages": [{"role": "user", "content": query}]}

    workflow_name = None
    timer = ExecutionTimer()

    async with AsyncWorkflowOrchestrator(
        config_path=config_path,
        tools_module=tools_module,
        enable_persistence=enable_persistence,
        checkpointer_path=checkpointer_path,
        persistence_config=persistence_config,
    ) as orchestrator:
        # Check if this thread has an interrupted checkpoint to resume from
        run_input = initial_state
        if thread_id and enable_persistence:
            try:
                state_info = await orchestrator.get_state(thread_id)
                if state_info.get("next"):
                    run_input = Command(resume=query)
            except (ValueError, Exception):
                pass

        timer.start()
        run_kwargs: dict = {}
        # Track CLI-level metrics from stream events
        cli_stats = {"llm_calls": 0, "tool_calls": 0, "total_tokens": 0}
        renderer = _StreamRenderer() if json_sink is None else None

        while True:
            try:
                async for result in orchestrator.run(
                    run_input,
                    config=run_config,
                    recursion_limit=recursion_limit,
                    stream_tokens=True,
                    **run_kwargs,
                ):
                    if workflow_name is None and "workflow" in result:
                        workflow_name = result["workflow"]

                    event_type = result.get("type", "unknown")
                    if event_type == "tool":
                        cli_stats["tool_calls"] += 1
                    elif event_type == "agent_end":
                        cli_stats["llm_calls"] += 1
                        usage = result.get("usage")
                        if isinstance(usage, dict):
                            cli_stats["total_tokens"] += usage.get("total_tokens", 0) or 0
                        elif usage and hasattr(usage, "total_tokens"):
                            cli_stats["total_tokens"] += usage.total_tokens or 0

                    if json_sink is not None:
                        _emit_workflow_event(json_sink, result)
                    else:
                        assert renderer is not None  # paired with json_sink check above
                        renderer.render(result)

                if renderer is not None:
                    renderer.flush()

                # Stream finished — emit summary
                metrics = orchestrator.get_last_metrics() or cli_stats
                cost = orchestrator.get_last_cost()
                if json_sink is not None:
                    json_sink.emit(
                        EVENT_STATS,
                        elapsed_s=timer.elapsed(),
                        llm_calls=metrics.get("llm_calls", 0),
                        tool_calls=metrics.get("tool_calls", 0),
                        total_tokens=metrics.get("total_tokens", 0),
                        cost=cost,
                    )
                    json_sink.emit(EVENT_COMPLETE)
                else:
                    print_execution_summary(console, timer.elapsed(), metrics=metrics, cost=cost)
                break

            except GraphInterrupt:
                if renderer is not None:
                    renderer.flush()
                state = await orchestrator.get_state(
                    run_config["configurable"]["thread_id"],
                    workflow_name=workflow_name,
                )

                interrupt_info = None
                tasks = state.get("tasks", ()) or ()
                for task in tasks:
                    if hasattr(task, "interrupts") and task.interrupts:
                        for interrupt_data in task.interrupts:
                            interrupt_info = interrupt_data.value
                            break
                        if interrupt_info is not None:
                            break

                print_interrupt_prompt(interrupt_info)

                user_response = prompt_user()
                if not user_response:
                    user_response = "Please provide more information before proceeding."

                num_actions = 1
                if isinstance(interrupt_info, dict):
                    num_actions = max(len(interrupt_info.get("action_requests", [])), 1)

                if user_response.lower() in ("yes", "proceed", "approve"):
                    decisions = [{"type": "approve"} for _ in range(num_actions)]
                elif user_response.lower() in ("no", "stop", "reject"):
                    decisions = [{"type": "reject", "message": "Rejected by user"} for _ in range(num_actions)]
                else:
                    decisions = [{"type": "reject", "message": user_response} for _ in range(num_actions)]

                console.print()
                print_info("Resuming workflow...")
                console.print()

                run_input = Command(resume={"decisions": decisions})
                run_kwargs = {"default_workflow": workflow_name}


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


@app.command()
def main(
    query: str | None = typer.Argument(
        None,
        help="User query to process. If not provided, you will be prompted.",
    ),
    yaml_path: str | None = typer.Option(
        None,
        "--yaml",
        help="Path to workflow YAML file (default: workflow.yaml).",
    ),
    tools_module: str | None = typer.Option(
        None,
        "--tools",
        help="Python module containing tools (default: auto-detect 'tools').",
    ),
    no_persistence: bool = typer.Option(
        False,
        "--no-persistence",
        help="Disable state persistence (stateless mode).",
    ),
    checkpointer_path: str = typer.Option(
        ".agentflow/checkpoints.db",
        "--checkpointer-path",
        help="Path to SQLite database for checkpoints.",
    ),
    thread_id: str | None = typer.Option(
        None,
        "--thread-id",
        help="Thread ID for conversation continuity.",
    ),
    recursion_limit: int = typer.Option(
        100,
        "--recursion-limit",
        help="Maximum number of agent steps.",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        help="Run in interactive mode (continuous query loop).",
    ),
):
    """Run AI workflows from the command line."""
    load_dotenv(override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(getattr(logging, log_level, logging.WARNING))

    # Auto-detect yaml_path
    if yaml_path is None:
        yaml_path = "workflow.yaml"
        if not os.path.exists(yaml_path):
            print_error("No workflow.yaml found in current directory. Use --yaml to specify.")
            raise typer.Exit(1)

    enable_persistence = not no_persistence

    # Add cwd to path so tools can be imported
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    print_banner("AgentFlow", "Run AI workflows from the command line")

    if interactive:
        init_history()
        repl_state = ReplState(thread_id=thread_id)
        console.print(
            "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, [bold]/quit[/bold] to exit\n"
        )

        while True:
            try:
                q = prompt_user("Query")
                if is_quit_alias(q):
                    console.print("\nGoodbye.")
                    break
                if is_slash_command(q):
                    if dispatch_slash_command(q, repl_state, console) == "quit":
                        console.print("\nGoodbye.")
                        break
                    continue

                asyncio.run(
                    run_workflow(
                        query=q,
                        config_path=yaml_path,
                        tools_module=tools_module,
                        enable_persistence=enable_persistence,
                        checkpointer_path=checkpointer_path,
                        thread_id=thread_id,
                        recursion_limit=recursion_limit,
                    )
                )
            except (KeyboardInterrupt, EOFError):
                console.print("\nGoodbye.")
                break
            except Exception as e:
                from agentflow.cli.errors import friendly_error

                print_error(friendly_error(e))
        cleanup_terminal_state()
    else:
        if not query:
            query = prompt_user("Query")

        # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
        asyncio.run(
            run_workflow(
                query=query,
                config_path=yaml_path,
                tools_module=tools_module,
                enable_persistence=enable_persistence,
                checkpointer_path=checkpointer_path,
                thread_id=thread_id,
                recursion_limit=recursion_limit,
            )
        )


def run_from_router(
    yaml_path: str,
    query: str | None = None,
    tools_module: str | None = None,
    persistence: str | None = None,
    db_path: str | None = None,
    connection_string: str | None = None,
    thread_id: str | None = None,
    interactive: bool = False,
    recursion_limit: int = 100,
    dry_run: bool = False,
    json_output: bool = False,
    output: str = "tty",
):
    """Entry point called by the unified CLI router.

    Translates canonical flags to workflows-internal parameters and
    runs the workflow. ``output`` controls the format: ``tty`` (default)
    uses Rich-rendered terminal output; ``json`` / ``ndjson`` emit one
    JSON event per line on stdout for machine consumption.

    Persistence precedence: if any of ``persistence`` / ``db_path`` /
    ``connection_string`` is set, a ``PersistenceConfig`` is built from
    those flags and passed as an explicit override — it wins over any
    ``persistence:`` section in the YAML. If all three are ``None``, the
    YAML's ``persistence:`` section is used (or legacy SQLite defaults).
    """
    load_dotenv(override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(getattr(logging, log_level, logging.WARNING))

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    # Build a PersistenceConfig override from CLI flags (None if no flag set).
    persistence_config = _persistence_config_from_cli(
        persistence=persistence,
        db_path=db_path,
        connection_string=connection_string,
    )

    # Legacy params (used when no CLI override and no YAML persistence block).
    # When CLI flags ARE set, persistence_config wins and these are ignored.
    enable_persistence = persistence != "memory"
    checkpointer_path = db_path or ".agentflow/checkpoints.db"

    # Dry-run: validate config and print summary
    if dry_run:
        import json as json_mod

        # Construct the orchestrator for its config-validation side effects;
        # any errors propagate to ``wrap_cli_main`` for friendly formatting.
        AsyncWorkflowOrchestrator(
            config_path=yaml_path,
            tools_module=tools_module,
            enable_persistence=False,
        )
        if persistence:
            persistence_label = f"{persistence} (--persistence)"
        elif persistence_config is not None:
            # Env-var derived (no CLI flag but persistence_config is set)
            if not persistence_config.checkpointer.enabled:
                persistence_label = "memory (env)"
            else:
                persistence_label = f"{persistence_config.backend.value} (env)"
        else:
            persistence_label = "default (sqlite)"
        summary = {
            "backend": "workflows",
            "yaml": yaml_path,
            "tools_module": tools_module,
            "persistence": persistence_label,
        }
        if json_output:
            print(json_mod.dumps(summary, indent=2, default=str))
        else:
            print_banner("AgentFlow", "Run AI workflows from the command line")
            from agentflow.cli import print_config_table

            rows = [
                ("Backend", "workflows"),
                ("Config", yaml_path),
                ("Tools", tools_module or "auto-detect"),
                ("Persistence", persistence_label),
            ]
            print_config_table(rows)
            console.print("[bold green]Config is valid.[/bold green]")
        return

    json_sink: JsonSink | None = None
    if is_json_mode(output):
        json_sink = JsonSink(backend="workflows")
    else:
        print_banner("AgentFlow", "Run AI workflows from the command line")

    if interactive:
        if json_sink is None:
            init_history()
            repl_state = ReplState(thread_id=thread_id)
            console.print(
                "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, [bold]/quit[/bold] to exit\n"
            )

        while True:
            try:
                # In JSON mode the loop runs once with the supplied query
                # (or exits) — interactive REPL prompts are not machine-readable.
                if json_sink is not None:
                    q = query or ""
                    if not q:
                        break
                else:
                    q = prompt_user("Query")
                    if is_quit_alias(q):
                        console.print("\nGoodbye.")
                        break
                    if is_slash_command(q):
                        if dispatch_slash_command(q, repl_state, console) == "quit":
                            console.print("\nGoodbye.")
                            break
                        continue

                asyncio.run(
                    run_workflow(
                        query=q,
                        config_path=yaml_path,
                        tools_module=tools_module,
                        enable_persistence=enable_persistence,
                        checkpointer_path=checkpointer_path,
                        thread_id=thread_id,
                        recursion_limit=recursion_limit,
                        json_sink=json_sink,
                        persistence_config=persistence_config,
                    )
                )
                if json_sink is not None:
                    break
            except (KeyboardInterrupt, EOFError):
                if json_sink is None:
                    console.print("\nGoodbye.")
                break
            except Exception as e:
                if json_sink is not None:
                    json_sink.emit(EVENT_ERROR, message=str(e))
                    break
                from agentflow.cli.errors import friendly_error

                print_error(friendly_error(e))
        if json_sink is None:
            cleanup_terminal_state()
    else:
        if not query:
            query = prompt_user("Query")

        # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
        asyncio.run(
            run_workflow(
                query=query,
                config_path=yaml_path,
                tools_module=tools_module,
                enable_persistence=enable_persistence,
                checkpointer_path=checkpointer_path,
                thread_id=thread_id,
                recursion_limit=recursion_limit,
                json_sink=json_sink,
                persistence_config=persistence_config,
            )
        )


if __name__ == "__main__":
    app()
