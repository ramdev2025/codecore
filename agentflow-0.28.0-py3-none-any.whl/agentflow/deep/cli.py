"""
AgentFlow Deep CLI — Run autonomous agents from the command line.

Usage:
    agentflow                                  # Launch TUI (default)
    agentflow --yaml agent.yaml                # Launch TUI with specific config
    agentflow "Your task here"                 # One-shot (plain CLI)
    agentflow --interactive                    # Interactive REPL (plain CLI)
    agentflow --dry-run                        # Validate config

Telemetry is auto-enabled when OTEL_TRACES_ENABLED=true is set in .env or environment.
"""

import json
import os
import sys
import uuid
from contextlib import nullcontext as _nullcontext
from enum import Enum
from typing import Optional

import typer
from dotenv import load_dotenv
from rich.panel import Panel

from agentflow.cli import (
    console,
    print_banner as _print_banner,
    print_error,
    print_config_table,
    print_execution_summary,
    print_reasoning_marker,
    print_tool_call,
    print_tool_result,
    ExecutionTimer,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_COMPLETE,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)

app = typer.Typer(
    name="agentflow",
    help="AgentFlow Deep — Run autonomous agents from the command line.",
    add_completion=False,
    rich_markup_mode="rich",
)


class Persistence(str, Enum):
    memory = "memory"
    sqlite = "sqlite"
    postgres = "postgres"


# ---------------------------------------------------------------------------
# Display helpers (use shared module + deep-specific formatting)
# ---------------------------------------------------------------------------

def print_banner():
    _print_banner("AgentFlow Deep", "Run autonomous agents from the command line")


def print_summary(summary: dict):
    meta = summary.get("metadata", {})
    llm = summary.get("llm", {})

    console.print()
    console.print(Panel(
        f"[bold cyan]{meta.get('name', 'Unnamed Agent')}[/bold cyan]"
        f"\n[dim]{meta.get('description', '')}[/dim]",
        border_style="cyan",
        expand=False,
    ))

    rows = [
        ("Version", meta.get("version", "?")),
        ("LLM", f"{llm.get('provider', '?')} / {llm.get('model', '?')}"),
        ("Checkpointer", "enabled" if summary.get("checkpointer") else "disabled"),
        ("Subagents", "enabled" if summary.get("subagents_enabled") else "disabled"),
    ]

    tools = summary.get("tools", {})
    builtin = tools.get("builtin", [])
    custom = tools.get("custom_count", 0)
    tool_names = [t.rsplit(".", 1)[-1] for t in builtin]
    rows.append(("Tools (builtin)", ", ".join(tool_names) if tool_names else "none"))
    if custom:
        rows.append(("Tools (custom)", str(custom)))

    mw = summary.get("middleware", [])
    rows.append(("Middleware", ", ".join(mw) if mw else "none"))

    subagent_list = summary.get("subagents")
    if subagent_list:
        rows.append(("Subagents", ", ".join(s["name"] for s in subagent_list)))

    skills = summary.get("skills")
    if skills:
        rows.append(("Skills", ", ".join(s["name"] for s in skills)))

    memory = summary.get("memory_sources")
    if memory:
        rows.append(("Memory", ", ".join(memory)))

    mcp = summary.get("mcp_servers")
    if mcp:
        rows.append(("MCP Servers", ", ".join(mcp)))

    print_config_table(rows)


# ---------------------------------------------------------------------------
# Agent construction
# ---------------------------------------------------------------------------

def build_agent(
        yaml_path: str,
        no_checkpointer: bool = False,
        persistence: str = "memory",
        db_path: Optional[str] = None,
        connection_string: Optional[str] = None,
        backend_dir: str = ".",
):
    from agentflow.deep import DeepAgentBuilder
    from agentflow.deep.core.persistence import create_checkpointer

    checkpointer = None
    if not no_checkpointer:
        checkpointer = create_checkpointer(
            backend=persistence,
            db_path=db_path,
            connection_string=connection_string,
        )

    backend = None
    try:
        from deepagents.backends.filesystem import FilesystemBackend
        backend = FilesystemBackend(root_dir=backend_dir, virtual_mode=True)
    except ImportError:
        pass

    return DeepAgentBuilder.from_yaml(
        yaml_path,
        checkpointer=checkpointer,
        backend=backend,
    )


def run_agent(builder, query: str, thread_id: str, telemetry=None):
    from langchain_core.messages import HumanMessage

    agent = builder.build()
    input_dict = {"messages": [HumanMessage(content=query)]}
    config = {"configurable": {"thread_id": thread_id}}

    if telemetry is not None:
        return telemetry.invoke(agent, input_dict, config=config)

    return agent.invoke(input_dict, config=config)


def _format_tool_call(name: str, args: dict) -> None:
    """Print a concise summary of a tool call.

    ``write_todos`` and ``task`` keep their domain-specific rendering
    (planning checklists and subagent dispatches read better that way).
    Everything else routes through the shared ``▸ name(args)`` marker.
    """
    if name == "write_todos":
        todos = args.get("todos", [])
        console.print("[dim]  > planning[/dim]")
        for todo in todos:
            status = todo.get("status", "pending")
            marker = {"completed": "[x]", "in_progress": "[-]"}.get(status, "[ ]")
            # markup=False so Rich doesn't eat ``[x]`` as a style tag;
            # highlight=False so it doesn't bold the bracket pair either.
            console.print(
                f"    {marker} {todo.get('content', '')}",
                markup=False,
                highlight=False,
            )
    elif name == "task":
        task_desc = str(args.get("task", args.get("description", "?")))[:120]
        console.print(f"  [bold blue]> subagent:[/bold blue] {task_desc}")
    else:
        print_tool_call(name, args)


def _extract_messages(node_output: dict) -> list:
    """Safely extract messages from a node output dict."""
    raw = node_output.get("messages", [])
    if isinstance(raw, list):
        return raw
    try:
        return list(raw)
    except TypeError:
        return [raw] if hasattr(raw, "type") else []


def stream_agent(builder, query: str, thread_id: str, telemetry=None, json_sink=None):
    """Stream agent execution with live progress output.

    Args:
        builder: DeepAgentBuilder instance.
        query: Task/query string.
        thread_id: Conversation thread identifier.
        telemetry: Optional DeepAgentTelemetry for creating child spans.
        json_sink: Optional :class:`JsonSink` — when supplied, events are
            emitted as ndjson to that sink instead of (or in addition to)
            the terminal renderer. Terminal output is suppressed when the
            sink is active.
    """
    from langchain_core.messages import HumanMessage

    agent = builder.build()
    input_dict = {"messages": [HumanMessage(content=query)]}
    config = {"configurable": {"thread_id": thread_id}}

    tool_count = 0
    depth = 0
    # Track active subagent spans by namespace tuple
    _subagent_spans: dict = {}
    # Queue of subagent names from task tool calls (FIFO) to match with namespaces
    _pending_subagent_names: list = []
    tracer = telemetry.tracer if telemetry and telemetry.enabled else None

    for namespace, chunk in agent.stream(
            input_dict, config, stream_mode="updates", subgraphs=True,
    ):
        # Track subagent depth for indentation
        depth = len(namespace) if namespace else 0
        indent = "  " * (depth + 1)

        # Create subagent spans — use queued name from task tool call
        if tracer and namespace:
            ns_key = tuple(namespace)
            if ns_key not in _subagent_spans:
                subagent_name = (
                    _pending_subagent_names.pop(0)
                    if _pending_subagent_names
                    else "subagent"
                )
                span = tracer.start_span(
                    f"subagent.{subagent_name}",
                    attributes={"deepagent.subagent": subagent_name, "deepagent.depth": depth},
                )
                _subagent_spans[ns_key] = span

        for node_name, node_output in chunk.items():
            if node_name == "__interrupt__":
                console.print(f"{indent}[bold yellow]Interrupted — waiting for input[/bold yellow]")
                continue

            if not isinstance(node_output, dict) or node_output is None:
                continue

            for msg in _extract_messages(node_output):
                msg_type = getattr(msg, "type", None)
                content = getattr(msg, "content", "")
                tool_calls = getattr(msg, "tool_calls", []) or []

                if msg_type == "ai":
                    # Anthropic-style reasoning blocks: content is a list with
                    # type=thinking entries we surface once as ``· thinking…``.
                    text_for_render = content
                    if isinstance(content, list):
                        text_parts: list[str] = []
                        saw_thinking = False
                        for block in content:
                            if not isinstance(block, dict):
                                text_parts.append(str(block))
                                continue
                            btype = block.get("type")
                            if btype == "text":
                                text_parts.append(block.get("text", ""))
                            elif btype == "thinking":
                                saw_thinking = True
                        if saw_thinking:
                            if json_sink is not None:
                                json_sink.emit(EVENT_REASONING, depth=depth)
                            else:
                                print_reasoning_marker()
                        text_for_render = "".join(text_parts)

                    # Show reasoning/analysis content even if tool calls follow
                    if text_for_render:
                        if json_sink is not None:
                            json_sink.emit(
                                EVENT_TOKEN,
                                name="Subagent" if depth > 0 else "Agent",
                                content=text_for_render,
                                depth=depth,
                            )
                        elif tool_calls:
                            # Intermediate thinking — show as dimmed
                            for line in text_for_render.strip().split("\n"):
                                console.print(f"{indent}[dim]{line}[/dim]")
                        else:
                            # Final response — show in panel
                            label = "Subagent" if depth > 0 else "Agent"
                            color = "blue" if depth > 0 else "green"
                            console.print()
                            console.print(Panel(
                                text_for_render,
                                title=f"[{color}]{label}[/{color}]",
                                border_style=color,
                                expand=False,
                            ))

                    # Show tool calls and create spans
                    for tc in tool_calls:
                        tool_count += 1
                        tc_name = tc.get("name", "?")
                        tc_args = tc.get("args", {})
                        if json_sink is not None:
                            json_sink.emit(
                                EVENT_TOOL_CALL,
                                name=tc_name,
                                args=tc_args,
                                depth=depth,
                            )
                        else:
                            _format_tool_call(tc_name, tc_args)

                        if tc_name == "task":
                            # Queue the subagent name so we can label its namespace span
                            sa_type = tc_args.get("subagent_type", "")
                            if sa_type:
                                _pending_subagent_names.append(sa_type)

                        # NB: we do NOT emit a per-tool span here. The LangSmith
                        # OTel bridge (enabled in DeepAgentTelemetry) already emits
                        # properly-timed tool spans with token usage; a manual span
                        # from this stream position could only be a zero-width
                        # marker (the tool has merely been *requested* here, not
                        # run). Subagent structure is still captured by the
                        # namespace-scoped ``subagent.*`` spans above.

                elif msg_type == "tool" and content:
                    # Surface tool results at every depth.
                    name = getattr(msg, "name", "tool")
                    if json_sink is not None:
                        json_sink.emit(EVENT_TOOL, name=name, content=content, depth=depth)
                    else:
                        print_tool_result(name, content)

    # End any remaining subagent spans
    for span in _subagent_spans.values():
        span.end()

    return tool_count


# ---------------------------------------------------------------------------
# YAML auto-detection
# ---------------------------------------------------------------------------

def resolve_yaml(yaml_path: Optional[str]) -> str:
    if yaml_path is not None:
        return yaml_path
    for candidate in ["workflow.yaml", "agentflow.yaml", "agent.yaml", "agents.yaml"]:
        if os.path.exists(candidate):
            return candidate
    print_error(
        "No agent YAML found. Create one of "
        "workflow.yaml / agentflow.yaml / agent.yaml / agents.yaml, "
        "or use --yaml to specify a path."
    )
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

@app.command()
def main(
        query: Optional[str] = typer.Argument(
            None,
            help="Task for the agent. If omitted, you will be prompted.",
        ),
        yaml_path: Optional[str] = typer.Option(
            None, "--yaml",
            help="Path to agent YAML config.",
        ),
        dry_run: bool = typer.Option(
            False, "--dry-run",
            help="Validate config and print summary without running the agent.",
        ),
        interactive: bool = typer.Option(
            False, "--interactive",
            help="Run in interactive mode (continuous conversation).",
        ),
        no_tui: bool = typer.Option(
            False, "--no-tui",
            help="Disable the TUI and use plain CLI output.",
        ),
        workdir: str = typer.Option(
            ".", "--workdir",
            help="Working directory for the agent's filesystem.",
        ),
        no_checkpointer: bool = typer.Option(
            False, "--no-checkpointer",
            help="Disable state persistence (stateless mode).",
        ),
        thread_id: Optional[str] = typer.Option(
            None, "--thread-id",
            help="Thread ID for conversation continuity.",
        ),
        json_output: bool = typer.Option(
            False, "--json",
            help="Output dry-run summary as JSON.",
        ),
        output: str = typer.Option(
            "tty", "--output",
            help="Output format: tty (default), json, ndjson.",
        ),
        persistence: Persistence = typer.Option(
            Persistence.sqlite, "--persistence",
            help="Checkpointer backend.",
        ),
        db_path: Optional[str] = typer.Option(
            None, "--db-path",
            help="SQLite database path (default: .agentflow/deep_checkpoints.db).",
        ),
        connection_string: Optional[str] = typer.Option(
            None, "--connection-string",
            help="PostgreSQL connection string (supports ${ENV_VAR} syntax).",
        ),
):
    """Run an AgentFlow Deep agent from the command line."""
    load_dotenv(override=True)

    # Configure agentflow log level from environment
    import logging
    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(getattr(logging, log_level, logging.WARNING))

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    yaml_file = resolve_yaml(yaml_path)

    # --- Dry Run ---
    if dry_run:
        # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
        builder = build_agent(
            yaml_file,
            no_checkpointer=no_checkpointer,
            persistence=persistence.value,
            db_path=db_path,
            connection_string=connection_string,
            backend_dir=workdir,
        )
        summary = builder.dry_run()
        if json_output:
            print(json.dumps(summary, indent=2, default=str))
        else:
            print_banner()
            print_summary(summary)
            console.print("[bold green]Config is valid.[/bold green]")
        return

    json_sink: Optional[JsonSink] = JsonSink(backend="deep") if is_json_mode(output) else None

    # JSON mode forces non-TUI / non-interactive behaviour — the TUI is
    # for humans only, and the REPL prompt isn't machine-readable.
    if json_sink is not None:
        no_tui = True
        interactive = False

    # --- TUI Mode (default unless --no-tui, --interactive, or query given) ---
    if not no_tui and not interactive and query is None:
        from agentflow.deep.tui import run_tui
        run_tui(
            yaml_path=yaml_file,
            workdir=workdir,
            persistence=persistence.value,
            db_path=db_path,
            connection_string=connection_string,
            no_checkpointer=no_checkpointer,
            thread_id=thread_id,
        )
        return

    # --- Build agent ---
    if json_sink is None:
        print_banner()
        console.print(f"[dim]Config: {yaml_file}[/dim]")
        console.print(f"[dim]Workdir: {os.path.abspath(workdir)}[/dim]")

    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    builder = build_agent(
        yaml_file,
        no_checkpointer=no_checkpointer,
        persistence=persistence.value,
        db_path=db_path,
        connection_string=connection_string,
        backend_dir=workdir,
    )

    # --- Telemetry (auto-enabled from OTEL_TRACES_ENABLED env var) ---
    telem = None
    from agentflow.deep.core.telemetry import DeepAgentTelemetry
    telem = DeepAgentTelemetry()
    if telem.enabled:
        if json_sink is None:
            console.print("[dim]Telemetry: enabled[/dim]")
    else:
        telem = None

    tid = thread_id or str(uuid.uuid4())
    if json_sink is None:
        console.print(f"[dim]Persistence: {persistence.value}[/dim]")
        console.print(f"[dim]Thread: {tid}[/dim]")
        console.print()

    # --- Interactive Mode ---
    if interactive:
        init_history()
        repl_state = ReplState(thread_id=tid)
        console.print(
            "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, "
            "[bold]/quit[/bold] to exit\n"
        )
        while True:
            try:
                q = prompt_user("Task")
                if is_quit_alias(q):
                    console.print("\nGoodbye.")
                    break
                if not q.strip():
                    continue
                if is_slash_command(q):
                    if dispatch_slash_command(q, repl_state, console) == "quit":
                        console.print("\nGoodbye.")
                        break
                    continue
                console.print()
                timer = ExecutionTimer()
                timer.start()
                with telem.span("deepagent.invoke", query=q, thread_id=tid) if telem else _nullcontext():
                    tool_count = stream_agent(builder, q, tid, telemetry=telem)
                print_execution_summary(console, timer.elapsed(), metrics={"tool_calls": tool_count or 0})
            except (KeyboardInterrupt, EOFError):
                console.print("\nGoodbye.")
                break
            except Exception as e:
                from agentflow.cli.errors import friendly_error
                print_error(friendly_error(e))
        cleanup_terminal_state()
        if telem:
            telem.shutdown()
        return

    # --- One-shot Mode ---
    q = query
    if not q:
        q = prompt_user("Task") if json_sink is None else ""
    if not q and json_sink is not None:
        return

    if json_sink is None:
        console.print()
    timer = ExecutionTimer()
    timer.start()
    try:
        with telem.span("deepagent.invoke", query=q, thread_id=tid) if telem else _nullcontext():
            tool_count = stream_agent(builder, q, tid, telemetry=telem, json_sink=json_sink)
        if json_sink is not None:
            json_sink.emit(EVENT_STATS, elapsed_s=timer.elapsed(), tool_calls=tool_count or 0)
            json_sink.emit(EVENT_COMPLETE)
        else:
            print_execution_summary(console, timer.elapsed(), metrics={"tool_calls": tool_count or 0})
    finally:
        # Shut down telemetry even if the run raises — but let the
        # exception propagate to ``wrap_cli_main`` for friendly formatting.
        if telem:
            telem.shutdown()


def run_from_router(
        yaml_path: str,
        query: Optional[str] = None,
        persistence: Optional[str] = None,
        db_path: Optional[str] = None,
        connection_string: Optional[str] = None,
        thread_id: Optional[str] = None,
        interactive: bool = False,
        workdir: str = ".",
        no_tui: bool = False,
        dry_run: bool = False,
        json_output: bool = False,
        output: str = "tty",
):
    """Entry point called by the unified CLI router.

    Translates canonical flags to deep-internal parameters and runs the agent.

    Persistence precedence: ``--persistence`` flag > ``AGENTFLOW_PERSISTENCE``
    env var > default (sqlite). The bare-name env vars
    ``POSTGRES_CONNECTION_STRING`` / ``CHECKPOINTER_DB_PATH`` continue to
    work as fallbacks for the corresponding values.
    """
    load_dotenv(override=True)

    import logging
    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(getattr(logging, log_level, logging.WARNING))

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    if persistence is None:
        persistence = os.environ.get("AGENTFLOW_PERSISTENCE", "sqlite").strip().lower()

    no_checkpointer = persistence == "memory"

    # Delegate to existing main() logic by calling it directly
    # This reuses ALL existing behavior: TUI, dry-run, interactive, one-shot, telemetry
    main(
        query=query,
        yaml_path=yaml_path,
        dry_run=dry_run,
        interactive=interactive,
        no_tui=no_tui,
        workdir=workdir,
        output=output,
        no_checkpointer=no_checkpointer,
        thread_id=thread_id,
        json_output=json_output,
        persistence=Persistence(persistence),
        db_path=db_path,
        connection_string=connection_string,
    )


if __name__ == "__main__":
    app()
