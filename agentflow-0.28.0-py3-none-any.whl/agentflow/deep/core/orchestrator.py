"""Async orchestrator for the deep AG-UI bridge.

Thin wrapper around the ``CompiledStateGraph`` returned by
``DeepAgentBuilder.build()``. Exposes the surface
:mod:`agentflow.deep.agui.router` needs:

  * :meth:`run` — async generator yielding orchestrator events
    (dicts in the format the AG-UI adapter consumes:
    ``{"type": "agent_start" | "token" | "agent" | "agent_end"
              | "tool_call" | "tool" | "interrupt", ...}``)
  * :meth:`get_state` — returns a ``StateSnapshot`` dict so the
    bridge resilience checks (paused-thread re-surface, silent
    pause at run-end) can detect pending interrupts
  * :meth:`cleanup` — releases MCP / persistence resources via
    the underlying builder

Deep is a single-agent runtime (no router / delegates) so the event
translation is simpler than workflows' equivalent. We only translate
the LangGraph ``astream_events`` v2 events the adapter actually
consumes; the workflows orchestrator's multi-agent layers are
intentionally absent here.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AsyncDeepOrchestrator:
    """Async runtime wrapping a DeepAgents-compiled LangGraph agent."""

    def __init__(
        self,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
        checkpointer: Optional[Any] = None,
        backend: Optional[Any] = None,
    ) -> None:
        from .builder import DeepAgentBuilder
        from .helpers import load_deep_agent_config
        from .config_models import DeepAgentYAMLConfig

        raw = load_deep_agent_config(config_path)
        self.parsed_config = DeepAgentYAMLConfig.model_validate(raw)

        self._builder = DeepAgentBuilder(
            config=self.parsed_config,
            checkpointer=checkpointer,
            backend=backend,
            build_state=build_state or {},
            bind_client_tools=bind_client_tools,
        )
        self._graph: Any = None

    @classmethod
    async def create(
        cls,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
        checkpointer: Optional[Any] = None,
        backend: Optional[Any] = None,
    ) -> "AsyncDeepOrchestrator":
        """Async factory: build the compiled agent so the first ``run`` is hot."""
        inst = cls(
            config_path=config_path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
            checkpointer=checkpointer,
            backend=backend,
        )
        inst._graph = inst._builder.build()
        return inst

    async def cleanup(self) -> None:
        """Release MCP / persistence resources."""
        if self._builder is not None:
            self._builder.close()

    async def get_state(self, thread_id: str) -> dict[str, Any]:
        """Return a state snapshot the AG-UI bridge can inspect.

        Returns ``{"values": dict, "tasks": tuple, "next": tuple}``.
        When no checkpointer is configured, returns empty values + no
        tasks so the bridge's resilience checks treat the thread as
        having no pending interrupts (a fresh-each-time semantics).
        """
        if self._graph is None:
            raise RuntimeError("DeepOrchestrator.create() must be awaited before use.")
        config = {"configurable": {"thread_id": thread_id}}
        try:
            snapshot = await self._graph.aget_state(config)
        except Exception:
            # No checkpointer (or transient failure) — degrade to empty
            # snapshot. The AG-UI bridge handles this case gracefully.
            return {"values": {}, "tasks": (), "next": ()}
        return {
            "values": dict(snapshot.values or {}),
            "tasks": snapshot.tasks,
            "next": snapshot.next,
        }

    async def run(
        self,
        state: Any,
        config: dict,
        stream_tokens: bool = False,
    ):
        """Yield orchestrator events translated from LangGraph's stream.

        ``state`` is either a state-input dict (``{"messages": [...]}``)
        or a ``langgraph.types.Command`` (HITL resume).
        """
        if self._graph is None:
            raise RuntimeError("DeepOrchestrator.create() must be awaited before use.")

        seen_tool_call_ids: set[str] = set()

        async for event in self._graph.astream_events(state, config=config, version="v2"):
            translated = self._map_event(event, stream_tokens, seen_tool_call_ids)
            if translated:
                for ev in translated:
                    yield ev

    def _map_event(
        self,
        event: dict,
        stream_tokens: bool,
        seen_tool_call_ids: set[str],
    ) -> Optional[list[dict]]:
        """Translate one ``astream_events`` v2 event to AG-UI adapter dicts.

        Slim cousin of ``WorkflowOrchestrator._map_event`` — same dict
        shape, simpler because deep has no multi-agent routing.
        """
        kind = event.get("event") or ""
        metadata = event.get("metadata") or {}
        name = metadata.get("langgraph_node") or event.get("name") or "Agent"

        if kind == "on_chat_model_start":
            if stream_tokens:
                return [{"type": "agent_start", "name": name, "content": ""}]

        elif kind == "on_chat_model_stream":
            if not stream_tokens:
                return None
            chunk = (event.get("data") or {}).get("chunk")
            if chunk and getattr(chunk, "content", None):
                return [{"type": "token", "name": name, "content": chunk.content}]

        elif kind == "on_chat_model_end":
            output = (event.get("data") or {}).get("output")
            if output and getattr(output, "content", None):
                result = {"type": "agent", "name": name, "content": output.content}
                usage = getattr(output, "usage_metadata", None)
                if usage:
                    result["usage"] = usage
                return [result]

        elif kind == "on_tool_start":
            tool_input = (event.get("data") or {}).get("input") or {}
            # Args dict — the adapter will JSON-encode this.
            return [{
                "type": "tool_call",
                "name": event.get("name") or name,
                "args": tool_input,
            }]

        elif kind == "on_tool_end":
            output = (event.get("data") or {}).get("output")
            content: Any
            if hasattr(output, "content"):
                content = output.content
            else:
                content = output
            return [{
                "type": "tool",
                "name": event.get("name") or name,
                "content": content,
            }]

        elif kind == "on_chain_end":
            # End of the top-level graph. The adapter expects an
            # ``agent_end`` to close any open assistant message.
            top_level = event.get("name") in ("LangGraph", "agent", "deep_agent")
            if top_level:
                return [{"type": "agent_end", "name": name}]

        return None
