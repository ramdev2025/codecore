import importlib
from typing import Callable, Dict, List

from .config_models import BuiltinTool, CustomToolRef

# Maps YAML builtin tool names to their DeepAgents class paths.
BUILTIN_TOOLS: Dict[str, str] = {
    BuiltinTool.READ_FILE: "langchain_deepagents.tools.ReadFileTool",
    BuiltinTool.WRITE_FILE: "langchain_deepagents.tools.WriteFileTool",
    BuiltinTool.EDIT_FILE: "langchain_deepagents.tools.EditFileTool",
    BuiltinTool.EXECUTE: "langchain_deepagents.tools.ExecuteTool",
    BuiltinTool.WRITE_TODOS: "langchain_deepagents.tools.WriteTodosTool",
}


def resolve_builtin_tools(tool_names: List[str]) -> List[str]:
    """Validate builtin tool names and return their DeepAgents class paths.

    Args:
        tool_names: List of builtin tool name strings (e.g., ["read_file", "execute"]).

    Returns:
        List of fully qualified DeepAgents tool class paths.

    Raises:
        ValueError: If a tool name is not recognized.
    """
    resolved = []
    for name in tool_names:
        if name not in BUILTIN_TOOLS:
            valid = ", ".join(sorted(BUILTIN_TOOLS.keys()))
            raise ValueError(
                f"Unknown builtin tool '{name}'. Valid tools: {valid}"
            )
        resolved.append(BUILTIN_TOOLS[name])
    return resolved


def resolve_custom_tools(custom_refs: List[CustomToolRef]) -> List[Callable]:
    """Import custom tool functions from their module references.

    Args:
        custom_refs: List of CustomToolRef specifying modules and function names.

    Returns:
        List of imported callable tool functions.

    Raises:
        ImportError: If a module cannot be imported.
        AttributeError: If a function is not found in the module.
    """
    tools: List[Callable] = []
    for ref in custom_refs:
        module = importlib.import_module(ref.module)
        for func_name in ref.functions:
            func = getattr(module, func_name)
            tools.append(func)
    return tools
