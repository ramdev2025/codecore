"""
Middleware registry for AgentFlow Deep.

Centralizes extraction of middleware configurations from YAML and transforms
them into parameters for create_deep_agent(). Follows the same factory pattern
as agentflow.workflows.core.middleware_factory.

DeepAgents auto-constructs its middleware stack internally. Our job is to
extract the right parameters from YAML middleware entries and pass them through:

    YAML middleware entry    →  create_deep_agent() parameter
    ─────────────────────────────────────────────────────────
    type: skills             →  skills=["/path/"]
    type: memory             →  memory=["/path/AGENTS.md"]
    type: hitl               →  interrupt_on={...}
    type: todo_list          →  (always enabled by deepagents)
    type: filesystem         →  (always enabled by deepagents)
    type: summarization      →  (always enabled by deepagents)
    type: prompt_caching     →  (always enabled by deepagents)
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Optional

from .config_models import MiddlewareEntry, MiddlewareType
from .skills_loader import resolve_skills_from_config, list_skills

logger = logging.getLogger(__name__)

# Middleware types that deepagents always includes in its stack.
# These don't need explicit parameters — listing them in YAML is declarative.
_ALWAYS_ENABLED = {
    MiddlewareType.TODO_LIST,
    MiddlewareType.FILESYSTEM,
    MiddlewareType.SUMMARIZATION,
    MiddlewareType.PROMPT_CACHING,
}


@dataclass
class MiddlewareParams:
    """Extracted middleware parameters for create_deep_agent().

    These are the parameters that create_deep_agent() uses to configure
    its internal middleware stack.
    """
    skills: Optional[list[str]] = None
    memory: Optional[list[str]] = None
    interrupt_on: Optional[dict[str, Any]] = None
    read_file_cache: bool = True

    # For dry_run reporting
    enabled_types: list[str] = field(default_factory=list)
    skills_detail: list[dict] = field(default_factory=list)


def resolve_middleware(
        entries: Optional[list[MiddlewareEntry]],
) -> MiddlewareParams:
    """Extract create_deep_agent() parameters from YAML middleware entries.

    Processes each middleware entry and extracts the corresponding parameter
    for create_deep_agent(). Entries for always-enabled middleware (todo_list,
    filesystem, summarization, prompt_caching) are acknowledged but don't
    produce additional parameters.

    Args:
        entries: List of middleware entries from YAML config.

    Returns:
        MiddlewareParams with extracted values.
    """
    params = MiddlewareParams()

    if not entries:
        return params

    for entry in entries:
        params.enabled_types.append(entry.type.value)

        if entry.type == MiddlewareType.SKILLS:
            params.skills = resolve_skills_from_config(entry.config)
            if entry.config:
                skills_dir = entry.config.get("skills_dir", ".skills/")
                params.skills_detail = list_skills(skills_dir)

        elif entry.type == MiddlewareType.MEMORY:
            params.memory = _resolve_memory_sources(entry.config)

        elif entry.type == MiddlewareType.HITL:
            if entry.config:
                params.interrupt_on = entry.config.get("interrupt_on")

        elif entry.type == MiddlewareType.FILESYSTEM:
            # Filesystem is auto-enabled by deepagents. Extract optional config.
            if entry.config:
                params.read_file_cache = entry.config.get("read_file_cache", True)
            logger.debug("Middleware '%s' is auto-enabled by deepagents", entry.type.value)

        elif entry.type in _ALWAYS_ENABLED:
            # These are auto-enabled by deepagents. Config is declarative.
            logger.debug("Middleware '%s' is auto-enabled by deepagents", entry.type.value)

        else:
            logger.warning("Unknown middleware type: %s", entry.type.value)

    return params


def _resolve_memory_sources(
        config: Optional[dict],
) -> Optional[list[str]]:
    """Extract memory source paths from middleware config.

    DeepAgents expects AGENTS.md file paths (POSIX format, relative to backend
    root). These files contain markdown with project context that gets injected
    into the system prompt.

    Args:
        config: The config dict from a memory middleware entry.

    Returns:
        List of AGENTS.md paths, or None if none configured.
    """
    if not config:
        return None

    sources = config.get("sources")
    if sources and isinstance(sources, list):
        # Normalize to POSIX paths with leading /
        return [
            s if s.startswith("/") else "/" + s
            for s in sources
        ]

    return None
