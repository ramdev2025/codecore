"""
Persistence factory for DeepAgent checkpointers.

Follows the same pattern as agentflow.workflows.core.persistence_manager but
simplified for sync-only DeepAgent usage (no store, no async).

Checkpointer type is a deployment concern — configured via CLI flags or
builder parameters, NOT in YAML.
"""

import atexit
import logging
import os
from pathlib import Path
from typing import Any, Optional

from agentflow.core.env import resolve_env_vars as _resolve_env_vars
from agentflow.core.pg_pool import (
    build_pool_kwargs,
    describe,
    pool_settings_from_env,
)

logger = logging.getLogger(__name__)

# Environment variable names (shared convention with agentflow workflows)
ENV_POSTGRES_CONNECTION_STRING = "POSTGRES_CONNECTION_STRING"
ENV_CHECKPOINTER_DB_PATH = "CHECKPOINTER_DB_PATH"


def create_checkpointer(
        backend: str = "memory",
        db_path: Optional[str] = None,
        connection_string: Optional[str] = None,
) -> Any:
    """Create a checkpointer instance based on backend type.

    Args:
        backend: One of "memory", "sqlite", "postgres".
        db_path: Path to SQLite database file (required for sqlite backend).
        connection_string: PostgreSQL connection string (required for postgres backend).

    Returns:
        A LangGraph-compatible checkpointer instance.

    Raises:
        ImportError: If required packages are not installed.
        ValueError: If required parameters are missing.
    """
    if backend == "memory":
        return _create_memory_checkpointer()
    elif backend == "sqlite":
        return _create_sqlite_checkpointer(db_path)
    elif backend == "postgres":
        return _create_postgres_checkpointer(connection_string)
    else:
        raise ValueError(
            f"Unknown persistence backend: {backend!r}. "
            f"Supported: memory, sqlite, postgres"
        )


def _create_memory_checkpointer() -> Any:
    """Create an in-memory checkpointer (no persistence across restarts)."""
    from langgraph.checkpoint.memory import MemorySaver

    logger.info("Persistence: in-memory (MemorySaver)")
    return MemorySaver()


def _create_sqlite_checkpointer(db_path: Optional[str] = None) -> Any:
    """Create a SQLite checkpointer for local persistence.

    Args:
        db_path: Path to SQLite database file.
            Defaults to ".agentflow/deep_checkpoints.db".

    Returns:
        A SqliteSaver instance.
    """
    if db_path is None:
        db_path = os.environ.get(ENV_CHECKPOINTER_DB_PATH, ".agentflow/deep_checkpoints.db")

    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
    except ImportError:
        raise ImportError(
            "SQLite checkpointer requires 'langgraph-checkpoint-sqlite'. "
            "Install it with: pip install langgraph-checkpoint-sqlite"
        )

    # Ensure parent directory exists
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    conn = __import__("sqlite3").connect(db_path, check_same_thread=False)
    checkpointer = SqliteSaver(conn)

    logger.info(f"Persistence: SQLite ({db_path})")
    return checkpointer


def _create_postgres_checkpointer(connection_string: Optional[str] = None) -> Any:
    """Create a PostgreSQL checkpointer for production persistence.

    Connections are served from a ``psycopg_pool.ConnectionPool`` rather than a
    single long-lived connection, so a database restart, failover, or reaped
    idle connection does not permanently break the agent. See
    :mod:`agentflow.core.pg_pool` for the reasoning and the tuning env vars.

    Args:
        connection_string: PostgreSQL connection string.
            Supports ${ENV_VAR} syntax for environment variable expansion.

    Returns:
        A PostgresSaver instance (caller must call close() when done).
    """
    if connection_string is None:
        connection_string = os.environ.get(ENV_POSTGRES_CONNECTION_STRING)
    if connection_string is None:
        raise ValueError(
            f"PostgreSQL backend requires a connection string. "
            f"Pass --connection-string or set {ENV_POSTGRES_CONNECTION_STRING} in .env"
        )

    resolved = _resolve_env_vars(connection_string)

    try:
        from langgraph.checkpoint.postgres import PostgresSaver
        from psycopg_pool import ConnectionPool
    except ImportError:
        raise ImportError(
            "PostgreSQL checkpointer requires 'langgraph-checkpoint-postgres' and "
            "'psycopg[pool]'. Install with: pip install agentflow[postgres]"
        )

    settings = pool_settings_from_env()
    pool = ConnectionPool(**build_pool_kwargs(resolved, settings, is_async=False))
    pool.open()

    try:
        checkpointer = PostgresSaver(pool)
        checkpointer.setup()
    except Exception:
        pool.close()
        raise

    # deep's callers (CLI, factory) take a checkpointer and never close it, so
    # close the pool at interpreter exit. Without this, psycopg's pool worker
    # threads outlive the program and it complains on shutdown. Callers that
    # do manage lifecycle can still close ``checkpointer.conn`` themselves —
    # closing twice is a no-op.
    atexit.register(_close_pool_quietly, pool)

    logger.info(f"Persistence: PostgreSQL (pool: {describe(settings)})")
    return checkpointer


def _close_pool_quietly(pool: Any) -> None:
    """Close a connection pool, ignoring errors during interpreter shutdown."""
    try:
        pool.close()
    except Exception:  # pragma: no cover - best effort at exit
        pass
