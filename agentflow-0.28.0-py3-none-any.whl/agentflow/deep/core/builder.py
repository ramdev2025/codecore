import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .config_models import DeepAgentYAMLConfig
from .helpers import load_deep_agent_config
from .llm_factory import LLMFactory
from .middleware_registry import resolve_middleware
from .tool_registry import resolve_builtin_tools, resolve_custom_tools


def _sanitize_agent_name(name: str) -> str:
    """Sanitize agent name for OpenAI API compatibility.

    Azure OpenAI rejects message name fields that contain spaces, angle
    brackets, pipes, backslashes, or slashes. Follows the same pattern as
    agentflow.workflows.core.helpers.sanitize_node_name.
    """
    name = name.replace(" ", "_")
    return re.sub(r'[\s<|\\/>]', '', name)


class DeepAgentBuilder:
    """Builds a DeepAgent from YAML configuration.

    YAML defines business logic (agent, tools, middleware).
    Deployment concerns (persistence, telemetry, backend) are passed as
    constructor parameters, following the same pattern as
    agentflow.workflows.AsyncWorkflowOrchestrator.
    """

    def __init__(
            self,
            config: DeepAgentYAMLConfig,
            checkpointer: Optional[Any] = None,
            backend: Optional[Any] = None,
            build_state: Optional[Dict[str, Any]] = None,
            bind_client_tools: bool = False,
    ):
        """
        Initialize the builder.

        Args:
            config: Validated YAML configuration (business logic only).
            checkpointer: Optional pre-configured checkpointer instance
                (e.g., MemorySaver, AsyncSqliteSaver). None = stateless.
            backend: Optional backend for file storage and execution.
                e.g., FilesystemBackend() for real disk access,
                StateBackend for in-memory (default if None).
            build_state: Deployment state for evaluating ``available_when``
                predicates on ``ui_tools`` at agent-construction time.
                Tools whose predicate is falsy against this state are
                excluded from the bound list permanently. None = empty.
            bind_client_tools: Opt-in for binding ``client_tools`` stubs
                that pause the run via ``langgraph.types.interrupt(...)``.
                Off by default — CLI / script call-sites never bind tools
                nothing can resume. The AG-UI router flips this to True
                at create time.
        """
        self.config = config
        self.checkpointer = checkpointer
        self.backend = backend
        self.build_state: Dict[str, Any] = build_state or {}
        self.bind_client_tools = bind_client_tools

    @classmethod
    def from_yaml(
            cls,
            path: Union[str, Path],
            checkpointer: Optional[Any] = None,
            backend: Optional[Any] = None,
            build_state: Optional[Dict[str, Any]] = None,
            bind_client_tools: bool = False,
    ) -> "DeepAgentBuilder":
        """Load config from YAML file and create builder.

        Args:
            path: Path to the YAML configuration file.
            checkpointer: Optional pre-configured checkpointer instance.
            backend: Optional backend for file storage and execution.
            build_state: Deployment state for ``available_when`` predicates.
            bind_client_tools: Opt-in for binding ``client_tools`` stubs.
        """
        raw = load_deep_agent_config(path)
        config = DeepAgentYAMLConfig.model_validate(raw)
        return cls(
            config,
            checkpointer=checkpointer,
            backend=backend,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    def build(self) -> Any:
        """Build and return a configured DeepAgent.

        Returns a compiled LangGraph StateGraph. Requires deepagents to be installed.
        If mcp_servers are configured, connects to them and adds their tools.

        Raises:
            ImportError: If deepagents is not installed.
        """
        try:
            from deepagents import create_deep_agent
        except ImportError:
            raise ImportError(
                "deepagents is required but not installed. "
                "Install it with: pip install agentflow[deep]"
            )

        model = LLMFactory.create_model(self.config.agent.llm)
        mw_params = resolve_middleware(self.config.middleware)

        # Resolve custom tools (builtins are included by default in deepagents)
        custom_tools: list = []
        if self.config.tools and self.config.tools.custom:
            custom_tools = resolve_custom_tools(self.config.tools.custom)

        # Resolve generative-UI tools (cross-backend ``ui_tools`` schema).
        # Each becomes a LangChain ``StructuredTool`` whose return is
        # validated against the Pydantic component class and stamped
        # with the in-band ``__component__`` marker the deep AG-UI
        # bridge keys off.
        if self.config.agent.ui_tools is not None:
            from agentflow.deep.genui import resolve_ui_tools
            from agentflow.genui import filter_by_availability

            ui_resolved = resolve_ui_tools(self.config.agent.ui_tools)
            # Build-time gating for parity with other backends. Per-call
            # dynamic gating layers on top via ``AgentMiddleware`` in D3.
            ui_resolved = filter_by_availability(
                ui_resolved,
                self.config.agent.available_when,
                self.build_state,
            )
            custom_tools.extend(ui_resolved)

        # Resolve MCP tools
        self._mcp_manager = None
        if self.config.mcp_servers:
            from .mcp import MCPToolManager
            server_configs = {
                name: entry.model_dump(exclude_none=True)
                for name, entry in self.config.mcp_servers.items()
            }
            self._mcp_manager = MCPToolManager(servers=server_configs)
            mcp_tools = self._mcp_manager.connect()
            custom_tools.extend(mcp_tools)

        # Resolve subagents from YAML config
        subagents = None
        if (
                self.config.subagents
                and self.config.subagents.enabled
                and self.config.subagents.agents
        ):
            try:
                from deepagents.middleware.subagents import SubAgent
            except ImportError:
                SubAgent = dict  # fallback — SubAgent is a dict subclass

            subagents = [
                SubAgent(
                    name=spec.name,
                    description=spec.description,
                    system_prompt=spec.system_prompt,
                    **({"model": spec.model} if spec.model else {}),
                )
                for spec in self.config.subagents.agents
            ]

        # Build additional middleware from config
        extra_middleware: list = []
        if mw_params.read_file_cache:
            from .tool_cache_middleware import ReadFileCacheMiddleware
            extra_middleware.append(ReadFileCacheMiddleware(enabled=True))

            # Inject cache middleware into subagents so they don't loop either
            if subagents:
                for spec in subagents:
                    if hasattr(spec, '__setitem__'):  # SubAgent is a TypedDict/dict
                        existing_mw = list(spec.get("middleware", []))
                        existing_mw.append(ReadFileCacheMiddleware(enabled=True))
                        spec["middleware"] = existing_mw

        # Auto-attach per-call ``available_when`` middleware. Build-time
        # gating ran in ``custom_tools`` resolution above; this layer
        # re-checks per-turn against live graph state so a tool can
        # appear / disappear as ``state.X`` changes mid-session.
        from agentflow.deep.availability import build_availability_middleware

        availability_mw = build_availability_middleware(
            self.config.agent.available_when,
            self.config.agent.client_tools if self.bind_client_tools else None,
        )
        if availability_mw is not None:
            extra_middleware.append(availability_mw)

        kwargs: Dict[str, Any] = dict(
            model=model,
            system_prompt=self.config.agent.system_prompt,
            tools=custom_tools or None,
            subagents=subagents,
            skills=mw_params.skills,
            memory=mw_params.memory,
            interrupt_on=mw_params.interrupt_on,
            middleware=extra_middleware or (),
            checkpointer=self.checkpointer,
            name=_sanitize_agent_name(self.config.metadata.name) if self.config.metadata.name else None,
        )
        if self.backend is not None:
            kwargs["backend"] = self.backend

        agent = create_deep_agent(**kwargs)

        return agent

    def close(self):
        """Clean up resources (MCP connections, etc.)."""
        if hasattr(self, '_mcp_manager') and self._mcp_manager is not None:
            self._mcp_manager.close()
            self._mcp_manager = None

    def dry_run(self) -> Dict[str, Any]:
        """Validate config without building agent. Returns a summary dict."""
        builtin_tools: List[str] = []
        custom_count = 0
        if self.config.tools:
            if self.config.tools.builtin:
                names = [t.value for t in self.config.tools.builtin]
                builtin_tools = resolve_builtin_tools(names)
            if self.config.tools.custom:
                custom_count = len(self.config.tools.custom)

        mw_params = resolve_middleware(self.config.middleware)

        return {
            "metadata": {
                "name": self.config.metadata.name,
                "version": self.config.metadata.version,
                "description": self.config.metadata.description,
            },
            "llm": {
                "provider": self.config.agent.llm.provider.value,
                "model": LLMFactory.model_display_string(self.config.agent.llm),
            },
            "tools": {
                "builtin": builtin_tools,
                "custom_count": custom_count,
            },
            "middleware": mw_params.enabled_types,
            "skills": mw_params.skills_detail or None,
            "memory_sources": mw_params.memory,
            "subagents_enabled": (
                self.config.subagents.enabled if self.config.subagents else False
            ),
            "subagents": (
                [{"name": s.name, "description": s.description[:80]}
                 for s in self.config.subagents.agents]
                if self.config.subagents and self.config.subagents.agents else None
            ),
            "checkpointer": self.checkpointer is not None,
            "mcp_servers": (
                list(self.config.mcp_servers.keys())
                if self.config.mcp_servers else None
            ),
        }
