"""
MCP (Model Context Protocol) integration for DeepAgent.

Connects to MCP servers, discovers tools, and converts them to LangChain
BaseTool instances that can be passed to create_deep_agent(tools=[...]).

Supports stdio and SSE transports. Uses the same config format as
agentflow.workflows for consistency.

Usage:
    manager = MCPToolManager(servers={
        "filesystem": {"transport": "stdio", "command": "npx", "args": ["-y", "@mcp/filesystem"]},
    })
    tools = manager.connect()        # sync — blocks until connected
    agent = create_deep_agent(tools=tools, ...)
    # ... use agent ...
    manager.close()                  # cleanup
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class MCPToolManager:
    """Manages MCP server connections and tool discovery for DeepAgent.

    Unlike the workflows MCPServerManager (fully async, health monitoring,
    reconnection), this is a simpler sync-friendly wrapper for single-agent
    use cases.

    Args:
        servers: Dict mapping server names to config dicts. Each config has:
            - transport: "stdio" or "sse" (default: "stdio")
            - command: Command to start the server (stdio only)
            - args: List of args for the command (stdio only)
            - url: URL for SSE server (sse only)
            - env: Optional dict of environment variables for the server
    """

    def __init__(self, servers: Dict[str, Dict[str, Any]]):
        self.servers = servers
        self._tools: List[Any] = []
        self._sessions: List[Any] = []
        self._cleanup_fns: List[Any] = []
        self._connected = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def connect(self) -> List[Any]:
        """Connect to all MCP servers and return LangChain tools.

        Returns:
            List of LangChain BaseTool instances from all connected servers.
        """
        # Create a dedicated loop for the MCP session lifecycle.
        # We keep it alive so close() can reuse it for cleanup.
        self._loop = asyncio.new_event_loop()
        self._tools = self._loop.run_until_complete(self._connect_all())
        self._connected = True
        return self._tools

    def close(self):
        """Disconnect from all MCP servers."""
        if not self._connected:
            return
        if self._loop is not None and not self._loop.is_closed():
            self._loop.run_until_complete(self._close_all())
            self._loop.close()
        self._loop = None
        self._connected = False

    @property
    def tools(self) -> List[Any]:
        """Return discovered tools (empty if not connected)."""
        return self._tools

    @property
    def tool_names(self) -> List[str]:
        """Return names of discovered tools."""
        return [t.name for t in self._tools]

    async def _connect_all(self) -> List[Any]:
        """Connect to all servers and collect tools."""
        all_tools = []

        for name, config in self.servers.items():
            transport = config.get("transport", "stdio")
            try:
                if transport == "stdio":
                    tools = await self._connect_stdio(name, config)
                elif transport == "sse":
                    tools = await self._connect_sse(name, config)
                else:
                    logger.warning(f"MCP server '{name}': unsupported transport '{transport}'")
                    continue

                all_tools.extend(tools)
                logger.info(f"MCP server '{name}': connected, {len(tools)} tools")

            except Exception as e:
                logger.error(f"MCP server '{name}': connection failed — {e}")

        return all_tools

    async def _connect_stdio(self, name: str, config: dict) -> List[Any]:
        """Connect to a stdio MCP server."""
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        command = config.get("command")
        args = config.get("args", [])
        env = config.get("env")

        if not command:
            raise ValueError(f"MCP server '{name}': stdio transport requires 'command'")

        server_params = StdioServerParameters(
            command=command,
            args=args,
            env=env,
        )

        # Enter the stdio_client context manager and track for cleanup
        stdio_cm = stdio_client(server_params)
        try:
            read_stream, write_stream = await stdio_cm.__aenter__()
        except Exception:
            # stdio_client failed to start — no cleanup needed
            raise

        self._cleanup_fns.append(lambda cm=stdio_cm: cm.__aexit__(None, None, None))

        session = ClientSession(read_stream, write_stream)
        try:
            await session.__aenter__()
            await session.initialize()
        except Exception:
            # Session failed — clean up the stdio_client
            await stdio_cm.__aexit__(None, None, None)
            self._cleanup_fns.pop()
            raise

        self._sessions.append(session)
        self._cleanup_fns.append(lambda s=session: s.__aexit__(None, None, None))

        # Discover tools
        tools_result = await session.list_tools()
        return [
            self._mcp_tool_to_langchain(name, tool, session)
            for tool in tools_result.tools
        ]

    async def _connect_sse(self, name: str, config: dict) -> List[Any]:
        """Connect to an SSE MCP server."""
        from mcp import ClientSession
        from mcp.client.sse import sse_client

        url = config.get("url")
        if not url:
            raise ValueError(f"MCP server '{name}': sse transport requires 'url'")

        sse_cm = sse_client(url)
        try:
            read_stream, write_stream = await sse_cm.__aenter__()
        except Exception:
            raise

        self._cleanup_fns.append(lambda cm=sse_cm: cm.__aexit__(None, None, None))

        session = ClientSession(read_stream, write_stream)
        try:
            await session.__aenter__()
            await session.initialize()
        except Exception:
            await sse_cm.__aexit__(None, None, None)
            self._cleanup_fns.pop()
            raise

        self._sessions.append(session)
        self._cleanup_fns.append(lambda s=session: s.__aexit__(None, None, None))

        tools_result = await session.list_tools()
        return [
            self._mcp_tool_to_langchain(name, tool, session)
            for tool in tools_result.tools
        ]

    def _mcp_tool_to_langchain(self, server_name: str, mcp_tool: Any, session: Any) -> Any:
        """Convert an MCP tool to a LangChain StructuredTool."""
        from langchain_core.tools import StructuredTool
        from pydantic import create_model

        # Build Pydantic model from MCP tool's input schema
        schema = mcp_tool.inputSchema or {}
        properties = schema.get("properties", {})
        required = set(schema.get("required", []))

        field_definitions = {}
        for prop_name, prop_schema in properties.items():
            python_type = _json_type_to_python(prop_schema.get("type", "string"))
            description = prop_schema.get("description", "")
            if prop_name in required:
                field_definitions[prop_name] = (python_type, description)
            else:
                field_definitions[prop_name] = (
                    Optional[python_type],
                    None,
                )

        if not field_definitions:
            field_definitions["__dummy__"] = (Optional[str], None)

        model_name = f"MCP_{server_name}_{mcp_tool.name}_Input"
        input_model = create_model(model_name, **field_definitions)

        # Create the tool function — uses the stored loop for async calls
        captured_session = session
        captured_loop = self._loop

        async def _call_tool(**kwargs):
            kwargs.pop("__dummy__", None)
            result = await captured_session.call_tool(captured_tool_name, kwargs)
            if result.content:
                parts = []
                for item in result.content:
                    if hasattr(item, "text"):
                        parts.append(item.text)
                    else:
                        parts.append(str(item))
                return "\n".join(parts)
            return ""

        captured_tool_name = mcp_tool.name

        def sync_call(**kwargs):
            if captured_loop is not None and not captured_loop.is_closed():
                return captured_loop.run_until_complete(_call_tool(**kwargs))
            # Fallback if loop was closed
            return asyncio.run(_call_tool(**kwargs))

        return StructuredTool(
            name=mcp_tool.name,
            description=mcp_tool.description or f"MCP tool from {server_name}",
            func=sync_call,
            args_schema=input_model,
        )

    async def _close_all(self):
        """Close all MCP sessions."""
        for cleanup in reversed(self._cleanup_fns):
            try:
                await cleanup()
            except Exception as e:
                logger.warning(f"MCP cleanup error: {e}")
        self._sessions.clear()
        self._cleanup_fns.clear()
        self._tools.clear()


def _json_type_to_python(json_type: str) -> type:
    """Map JSON Schema type to Python type."""
    mapping = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }
    return mapping.get(json_type, str)


def resolve_mcp_from_config(config: Optional[Dict[str, Any]]) -> Optional[MCPToolManager]:
    """Create MCPToolManager from YAML mcp_servers config section.

    Args:
        config: Dict mapping server names to server configs, e.g.:
            {"filesystem": {"transport": "stdio", "command": "npx", "args": [...]}}

    Returns:
        MCPToolManager instance, or None if config is empty/None.
    """
    if not config:
        return None
    return MCPToolManager(servers=config)
