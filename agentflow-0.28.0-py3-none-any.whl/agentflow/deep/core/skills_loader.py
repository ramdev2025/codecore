"""
Skills discovery and loading for AgentFlow Deep.

Skills are markdown files (SKILL.md) in subdirectories under a skills source path.
DeepAgents expects a list of source directory paths (POSIX format, relative to backend root).

Example directory structure:
    .skills/
        python-testing/
            SKILL.md
        code-review/
            SKILL.md

The skills_dir in YAML config points to the parent directory (.skills/).
This module discovers valid skill directories and returns source paths
for create_deep_agent(skills=[...]).
"""

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def discover_skill_sources(skills_dir: str) -> list[str]:
    """Discover skill source directories under a skills root.

    Scans for subdirectories containing SKILL.md files and returns
    the parent skills_dir as a source path (POSIX format with leading /).

    Args:
        skills_dir: Path to the skills root directory (e.g., ".skills/").

    Returns:
        List of POSIX source paths for create_deep_agent(skills=[...]).
        Returns ["/skills_dir/"] if valid skills are found, empty list otherwise.
    """
    skills_path = Path(skills_dir)
    if not skills_path.exists() or not skills_path.is_dir():
        logger.debug("Skills directory not found: %s", skills_dir)
        return []

    # Check for at least one valid skill (subdirectory with SKILL.md)
    has_skills = any(
        (child / "SKILL.md").exists()
        for child in skills_path.iterdir()
        if child.is_dir()
    )

    if not has_skills:
        logger.debug("No SKILL.md files found under: %s", skills_dir)
        return []

    # Return as POSIX path with leading / (deepagents convention)
    source = "/" + skills_path.as_posix().strip("/") + "/"
    logger.info("Discovered skills source: %s", source)
    return [source]


def list_skills(skills_dir: str) -> list[dict]:
    """List all discovered skills with their metadata.

    Useful for dry_run summaries and CLI output.

    Args:
        skills_dir: Path to the skills root directory.

    Returns:
        List of dicts with skill name and path.
    """
    skills_path = Path(skills_dir)
    if not skills_path.exists() or not skills_path.is_dir():
        return []

    results = []
    for child in sorted(skills_path.iterdir()):
        skill_md = child / "SKILL.md"
        if child.is_dir() and skill_md.exists():
            results.append({
                "name": child.name,
                "path": str(skill_md),
            })

    return results


def resolve_skills_from_config(
        middleware_config: Optional[dict],
) -> Optional[list[str]]:
    """Extract and resolve skill source paths from middleware config.

    Args:
        middleware_config: The config dict from a skills middleware entry.

    Returns:
        List of skill source paths, or None if no skills found.
    """
    if not middleware_config:
        return None

    skills_dir = middleware_config.get("skills_dir", ".skills/")
    sources = discover_skill_sources(skills_dir)
    return sources or None
