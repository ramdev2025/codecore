"""
Constants used throughout AgentFlow Deep.
"""

# Subagent recursion depth limit
DEFAULT_MAX_DEPTH = 3

# Default skills directory
DEFAULT_SKILLS_DIR = ".skills/"
