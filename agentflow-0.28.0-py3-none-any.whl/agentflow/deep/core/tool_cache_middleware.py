"""Middleware that caches read_file tool call results to prevent infinite loops.

When an LLM enters a degenerate state and repeatedly calls read_file with
identical arguments, the agent can get stuck in a loop for hundreds of
iterations. This middleware caches read_file results and returns cached
content on duplicate calls, with escalating responses:

- 2nd call: returns cached content with a ``[DUPLICATE READ]`` warning
- 3rd+ call: returns a terse error with no content to break the loop

This middleware is enabled by default via the ``filesystem`` middleware
YAML config and can be disabled by setting ``read_file_cache: false``.
"""

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from langchain.agents.middleware.types import AgentMiddleware, AgentState
from langchain.tools.tool_node import ToolCallRequest
from langchain_core.messages import ToolMessage
from langgraph.runtime import Runtime
from langgraph.types import Command

logger = logging.getLogger(__name__)

# Default values for read_file arguments (must match deepagents filesystem middleware)
_DEFAULT_READ_OFFSET = 0
_DEFAULT_READ_LIMIT = 100

# After this many duplicate calls, stop returning content entirely
_MAX_DUPLICATE_WITH_CONTENT = 2

# Terse error returned on 3rd+ duplicate — short to avoid filling context
_HARD_STOP_MSG = "BLOCKED: Identical read_file call already served. Content unchanged. Proceed."


class ReadFileCacheMiddleware(AgentMiddleware):
    """Caches read_file results to prevent infinite read loops.

    Tracks ``(file_path, offset, limit)`` tuples. The first call for each
    key executes normally. The second call returns cached content with a
    warning. From the third call onward, returns only a terse error message
    without file content, which reliably breaks the LLM out of the loop.

    The cache is reset at the start of each agent invocation via
    ``before_agent``, so it only deduplicates within a single run.
    When a file is written via ``write_file`` or ``edit_file``, the cache
    entries for that path are invalidated so the next read sees fresh content.

    Args:
        enabled: Whether caching is active. When ``False``, all calls
            pass through to the underlying handler unchanged.
    """

    def __init__(self, *, enabled: bool = True) -> None:
        self._enabled = enabled
        self._cache: dict[tuple[str, int, int], tuple[str | list, int]] = {}

    # -- lifecycle -----------------------------------------------------------

    def before_agent(self, state: AgentState, runtime: Runtime[Any]) -> dict[str, Any] | None:  # noqa: ARG002
        """Reset the cache at the start of each agent invocation."""
        self._cache.clear()
        return None

    # -- helpers -------------------------------------------------------------

    def _cache_key(self, request: ToolCallRequest) -> tuple[str, int, int] | None:
        """Return the cache key for a read_file call, or None for other tools."""
        if not self._enabled or request.tool_call["name"] != "read_file":
            return None
        args = request.tool_call.get("args", {})
        return (
            args.get("file_path", ""),
            args.get("offset", _DEFAULT_READ_OFFSET),
            args.get("limit", _DEFAULT_READ_LIMIT),
        )

    def _invalidate_path(self, file_path: str) -> None:
        """Remove all cache entries for a given file path (after writes)."""
        keys_to_remove = [k for k in self._cache if k[0] == file_path]
        for k in keys_to_remove:
            del self._cache[k]

    def _make_cached_response(
            self, request: ToolCallRequest, cached_content: str | list, call_count: int
    ) -> ToolMessage:
        """Build a ToolMessage for a duplicate read_file call.

        On the 2nd duplicate, returns the cached content with a warning prefix.
        On the 3rd+ duplicate, returns only a terse error to break the loop.
        """
        if call_count > _MAX_DUPLICATE_WITH_CONTENT:
            content: str | list = _HARD_STOP_MSG
        else:
            warning = (
                f"[DUPLICATE READ #{call_count}] You have already read this file "
                f"{call_count} times with the same arguments. The content has not "
                f"changed. Use the information below and proceed with your analysis.\n\n"
            )
            if isinstance(cached_content, list):
                content = [{"type": "text", "text": warning}, *cached_content]
            else:
                content = warning + str(cached_content)

        return ToolMessage(
            content=content,
            tool_call_id=request.tool_call["id"],
            name="read_file",
        )

    def _handle_cache(
            self, request: ToolCallRequest, key: tuple[str, int, int]
    ) -> ToolMessage | None:
        """Check cache and return a response if this is a duplicate call."""
        if key not in self._cache:
            return None

        cached_content, count = self._cache[key]
        count += 1
        self._cache[key] = (cached_content, count)

        if count >= 2:
            logger.warning(
                "read_file called %d times for %s (offset=%d, limit=%d) — returning cached result",
                count, key[0], key[1], key[2],
            )
            return self._make_cached_response(request, cached_content, count)
        return None

    def _store_result(self, key: tuple[str, int, int], result: ToolMessage | Command) -> None:
        """Store the first result for a cache key."""
        if key not in self._cache and isinstance(result, ToolMessage):
            self._cache[key] = (result.content, 1)

    def _check_write_invalidation(self, request: ToolCallRequest) -> None:
        """Invalidate cache if a write_file or edit_file targets a cached path."""
        tool_name = request.tool_call["name"]
        if tool_name in ("write_file", "edit_file"):
            args = request.tool_call.get("args", {})
            file_path = args.get("file_path", "")
            if file_path:
                self._invalidate_path(file_path)

    # -- wrap_tool_call (sync) -----------------------------------------------

    def wrap_tool_call(
            self,
            request: ToolCallRequest,
            handler: Callable[[ToolCallRequest], ToolMessage | Command],
    ) -> ToolMessage | Command:
        """Intercept read_file calls and return cached results on duplicates.

        Also invalidates cache entries when write_file or edit_file targets
        a previously cached path.
        """
        self._check_write_invalidation(request)

        key = self._cache_key(request)
        if key is None:
            return handler(request)

        cached = self._handle_cache(request, key)
        if cached is not None:
            return cached

        result = handler(request)
        self._store_result(key, result)
        return result

    # -- awrap_tool_call (async) ---------------------------------------------

    async def awrap_tool_call(
            self,
            request: ToolCallRequest,
            handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command]],
    ) -> ToolMessage | Command:
        """Async version of wrap_tool_call."""
        self._check_write_invalidation(request)

        key = self._cache_key(request)
        if key is None:
            return await handler(request)

        cached = self._handle_cache(request, key)
        if cached is not None:
            return cached

        result = await handler(request)
        self._store_result(key, result)
        return result
