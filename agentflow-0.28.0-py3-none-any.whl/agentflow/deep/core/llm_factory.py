"""
LLM Factory for creating model instances from YAML config.

Follows the same provider-based pattern as agentflow.workflows.core.llm_factory.
"""

from typing import Any

from .config_models import LLMConfig, LLMProvider


class LLMFactory:
    """Factory for creating LLM instances from deep agent config."""

    @staticmethod
    def create_model(config: LLMConfig) -> Any:
        """Create a model instance or string from LLM configuration.

        For providers needing extra config (Azure endpoint, identity, etc.),
        returns a fully initialized model instance.
        For simple providers, returns a 'provider:model' string that
        deepagents can resolve via init_chat_model.
        """
        if config.provider == LLMProvider.AZURE_OPENAI:
            return LLMFactory._create_azure_openai(**config.config)
        elif config.provider == LLMProvider.OPENAI:
            return LLMFactory._create_openai(**config.config)
        elif config.provider == LLMProvider.ANTHROPIC:
            return LLMFactory._create_anthropic(**config.config)
        elif config.provider == LLMProvider.CUSTOM:
            return LLMFactory._create_custom(**config.config)
        else:
            raise ValueError(f"Unsupported LLM provider: {config.provider}")

    @staticmethod
    def _create_azure_openai(**kwargs) -> Any:
        """Create Azure OpenAI instance."""
        from langchain_openai import AzureChatOpenAI

        use_identity = kwargs.pop("azure_identity", False)
        azure_ad_token_provider = None

        if use_identity:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
            scope = kwargs.pop(
                "azure_oauth_scope",
                "https://cognitiveservices.azure.com/.default",
            )
            azure_ad_token_provider = get_bearer_token_provider(
                DefaultAzureCredential(),
                scope,
            )

        return AzureChatOpenAI(
            azure_deployment=kwargs.get("model"),
            azure_endpoint=kwargs.get("azure_endpoint"),
            openai_api_version=kwargs.get("api_version"),
            openai_api_key=kwargs.get("api_key"),
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
            top_p=kwargs.get("top_p"),
            timeout=kwargs.get("timeout"),
            max_retries=kwargs.get("max_retries", 2),
            azure_ad_token_provider=azure_ad_token_provider,
        )

    @staticmethod
    def _create_openai(**kwargs) -> Any:
        """Create OpenAI instance."""
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            model=kwargs.get("model"),
            api_key=kwargs.get("api_key"),
            base_url=kwargs.get("base_url"),
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
            top_p=kwargs.get("top_p"),
            timeout=kwargs.get("timeout"),
            max_retries=kwargs.get("max_retries", 2),
        )

    @staticmethod
    def _create_anthropic(**kwargs) -> Any:
        """Create Anthropic instance."""
        from langchain_anthropic import ChatAnthropic

        return ChatAnthropic(
            model_name=kwargs.get("model"),
            api_key=kwargs.get("api_key"),
            base_url=kwargs.get("base_url"),
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
            top_p=kwargs.get("top_p"),
            timeout=kwargs.get("timeout"),
            max_retries=kwargs.get("max_retries", 2),
        )

    @staticmethod
    def _create_custom(**kwargs) -> str:
        """For custom providers, return 'provider:model' for deepagents to resolve."""
        model = kwargs.get("model", "")
        provider = kwargs.get("provider", "")
        return f"{provider}:{model}" if provider else model

    @staticmethod
    def model_display_string(config: LLMConfig) -> str:
        """Build a 'provider:model' string for display purposes."""
        return f"{config.provider.value}:{config.config.get('model', '')}"
