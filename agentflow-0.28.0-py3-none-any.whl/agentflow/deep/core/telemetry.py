"""
OpenTelemetry instrumentation for DeepAgent invocations.

Follows the same pattern as agentflow.workflows.core.telemetry
but simplified — no plugin system, just a wrapper around agent.invoke().

Telemetry is a deployment concern — enabled via CLI flags or environment
variables, NOT in YAML.

Usage:
    telemetry = DeepAgentTelemetry(service_name="my-agent")
    result = telemetry.invoke(agent, input_dict, config)

Environment variables (following OpenTelemetry conventions):
    OTEL_TRACES_ENABLED=true          Enable tracing
    OTEL_SERVICE_NAME=my-agent        Service name for spans
    OTEL_EXPORTER_OTLP_ENDPOINT=...   OTLP collector endpoint
"""

import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class DeepAgentTelemetry:
    """OpenTelemetry wrapper for DeepAgent invocations.

    Instruments agent.invoke() calls with OTel spans, capturing:
    - Agent invocation duration
    - Query content (first 200 chars)
    - Thread ID
    - Token usage (if available in response)
    - Errors

    Example:
        telemetry = DeepAgentTelemetry(service_name="coding-agent")
        result = telemetry.invoke(agent, {"messages": [...]}, config)
        telemetry.shutdown()
    """

    def __init__(
            self,
            service_name: Optional[str] = None,
            service_version: str = "1.0.0",
            endpoint: Optional[str] = None,
            enabled: bool = True,
    ):
        """Initialize telemetry.

        Args:
            service_name: Service name for OTel resource.
                Defaults to OTEL_SERVICE_NAME env var or "deepagent".
            service_version: Service version for OTel resource.
            endpoint: OTLP exporter endpoint.
                Defaults to OTEL_EXPORTER_OTLP_ENDPOINT env var or "http://localhost:4317".
            enabled: Whether telemetry is enabled.
                Overridden to False if OTEL_TRACES_ENABLED != "true".
        """
        self.enabled = enabled and os.getenv("OTEL_TRACES_ENABLED", "false").lower() == "true"
        self._provider = None
        self._shutdown_called = False
        self.tracer = None

        if not self.enabled:
            return

        try:
            from opentelemetry import trace
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
            from opentelemetry.sdk.resources import Resource, SERVICE_NAME, SERVICE_VERSION
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import BatchSpanProcessor
        except ImportError:
            logger.warning(
                "OpenTelemetry packages not installed. "
                "Install with: pip install opentelemetry-api opentelemetry-sdk "
                "opentelemetry-exporter-otlp"
            )
            self.enabled = False
            return

        self.service_name = service_name or os.getenv("OTEL_SERVICE_NAME", "deepagent")
        self.service_version = service_version
        self.endpoint = endpoint or os.getenv(
            "OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"
        )

        # Enable the LangSmith → OTel bridge (same as the workflows backend) so
        # DeepAgents' underlying LangGraph/LangChain LLM and tool calls are
        # auto-instrumented into our provider: properly-timed spans carrying
        # ``gen_ai.usage.*`` token counts, which Foundry/App Insights render
        # richly. ``setdefault`` lets user-provided values win.
        os.environ.setdefault("LANGSMITH_TRACING", "true")
        os.environ.setdefault("LANGSMITH_OTEL_ENABLED", "true")
        os.environ.setdefault("LANGSMITH_OTEL_ONLY", "true")

        resource = Resource.create({
            SERVICE_NAME: self.service_name,
            SERVICE_VERSION: self.service_version,
        })

        self._provider = TracerProvider(resource=resource)
        trace.set_tracer_provider(self._provider)

        # Exporter seam: attach registered / entry-point-discovered processors
        # (e.g. Azure Monitor via agentflow[azure-monitor]) additively; skip the
        # default OTLP sink when no endpoint is configured but a seam processor is
        # present, so Azure-only apps don't spam localhost:4317. The seam owns
        # provider tracking + atexit shutdown so late registrations reach it.
        from agentflow.core import telemetry_seam as _seam
        _seam.attach_seam_processors(
            self._provider,
            default_factory=lambda: BatchSpanProcessor(
                OTLPSpanExporter(endpoint=self.endpoint, insecure=True)
            ),
            default_is_explicit=(
                endpoint is not None
                or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT") is not None
            ),
        )

        self.tracer = trace.get_tracer(__name__)
        self._trace = trace

        logger.info(
            f"Telemetry enabled — service={self.service_name}, endpoint={self.endpoint}"
        )

    def span(self, name: str, query: str = "", thread_id: str = "unknown"):
        """Create a telemetry span context manager.

        Use this to wrap any agent execution (invoke or stream).

        Example:
            with telemetry.span("agent.run", query=q, thread_id=tid) as s:
                stream_agent(builder, q, tid)
                s.set_attribute("custom.key", "value")

        Args:
            name: Span name (e.g., "deepagent.invoke").
            query: Task/query text (truncated to 200 chars in span).
            thread_id: Conversation thread identifier.

        Returns:
            A context manager that yields the active span.
        """
        if not self.enabled:
            return _NoOpSpanContext()

        return _TelemetrySpanContext(
            self.tracer, name, query[:200], thread_id,
        )

    def invoke(
            self,
            agent: Any,
            input_dict: Dict[str, Any],
            config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Invoke agent with telemetry instrumentation.

        Wraps agent.invoke() in an OTel span, capturing timing, thread_id,
        query content, and token usage.

        Args:
            agent: Compiled LangGraph agent (CompiledStateGraph).
            input_dict: Input dict with "messages" key.
            config: LangGraph config dict with thread_id etc.

        Returns:
            The agent's result dict.
        """
        if not self.enabled:
            return agent.invoke(input_dict, config=config)

        thread_id = (config or {}).get("configurable", {}).get("thread_id", "unknown")

        query = ""
        messages = input_dict.get("messages", [])
        if messages:
            content = getattr(messages[0], "content", str(messages[0]))
            query = content[:200] if isinstance(content, str) else str(content)[:200]

        with self.span("deepagent.invoke", query=query, thread_id=thread_id) as s:
            result = agent.invoke(input_dict, config=config)

            # Extract token usage from response messages if available
            resp_messages = result.get("messages", [])
            for msg in reversed(resp_messages):
                usage = getattr(msg, "usage_metadata", None)
                if usage and isinstance(usage, dict):
                    s.set_attribute("llm.input_tokens", usage.get("input_tokens", 0))
                    s.set_attribute("llm.output_tokens", usage.get("output_tokens", 0))
                    s.set_attribute("llm.total_tokens", usage.get("total_tokens", 0))
                    break

            return result

    def shutdown(self):
        """Flush pending spans and shut down the tracer provider."""
        if not self.enabled or self._shutdown_called or self._provider is None:
            return

        self._shutdown_called = True
        try:
            self._provider.force_flush(timeout_millis=5000)
            self._provider.shutdown()

            from agentflow.core import telemetry_seam as _seam
            _seam.untrack_provider(self._provider)
        except Exception as e:
            logger.warning(f"Telemetry shutdown error: {e}")


class _TelemetrySpanContext:
    """Context manager that wraps execution in an OTel span."""

    def __init__(self, tracer, name: str, query: str, thread_id: str):
        self._tracer = tracer
        self._name = name
        self._query = query
        self._thread_id = thread_id
        self._span = None
        self._token = None
        self._start = None

    def __enter__(self):
        from opentelemetry import context, trace

        self._span = self._tracer.start_span(
            self._name,
            attributes={
                "deepagent.thread_id": self._thread_id,
                "deepagent.query": self._query,
            },
        )
        self._token = context.attach(trace.set_span_in_context(self._span))
        self._start = time.monotonic()
        return self._span

    def __exit__(self, exc_type, exc_val, exc_tb):
        from opentelemetry import context

        duration = time.monotonic() - self._start
        self._span.set_attribute("deepagent.duration_s", round(duration, 3))

        if exc_type is not None:
            self._span.set_attribute("deepagent.status", "error")
            self._span.set_attribute("error", True)
            self._span.set_attribute("error.type", exc_type.__name__)
            self._span.set_attribute("error.message", str(exc_val)[:500])
        else:
            self._span.set_attribute("deepagent.status", "success")

        self._span.end()
        context.detach(self._token)
        return False


class _NoOpSpanContext:
    """No-op context manager when telemetry is disabled."""

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def set_attribute(self, key, value):
        pass
