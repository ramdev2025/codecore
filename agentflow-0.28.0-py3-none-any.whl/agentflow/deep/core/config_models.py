from enum import Enum
from typing import Optional, Dict, Any, List

from pydantic import BaseModel, Field, model_validator

from agentflow.genui import ClientToolConfig, UIToolsConfig

from .constants import DEFAULT_MAX_DEPTH


class DeepAgentMetadata(BaseModel):
    """Metadata about the deep agent configuration."""

    version: str = Field(
        ...,
        description="Schema version (e.g., '1.0')"
    )
    name: Optional[str] = Field(
        None,
        description="Human-readable name for this agent"
    )
    description: Optional[str] = Field(
        None,
        description="Description of this agent configuration"
    )
    author: Optional[str] = Field(
        None,
        description="Author or team responsible for this configuration"
    )
    tags: Optional[List[str]] = Field(
        None,
        description="Tags for categorization and search"
    )


class LLMProvider(str, Enum):
    """Supported LLM providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    AZURE_OPENAI = "azure_openai"
    CUSTOM = "custom"


class LLMConfig(BaseModel):
    """LLM configuration for the deep agent."""

    provider: LLMProvider = Field(
        ...,
        description="LLM provider name"
    )
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Provider-specific config (model, api_key with ${ENV_VAR}, temperature, max_tokens)"
    )


class AgentConfig(BaseModel):
    """Core agent configuration."""

    system_prompt: str = Field(
        ...,
        description="System prompt defining the agent's behavior"
    )
    llm: LLMConfig = Field(
        ...,
        description="LLM configuration for this agent"
    )
    ui_tools: Optional[UIToolsConfig] = Field(
        default=None,
        description=(
            "Generative-UI components exposed as tools the agent can call. "
            "Each is a Pydantic schema paired with a fetcher (decorated with "
            "``@agentflow.genui.ui_component``); the fetcher's return is "
            "validated against the schema and streamed to the frontend as a "
            "RenderComponent payload. Cross-backend YAML shape — see "
            "``agentflow.genui.UIToolsConfig``."
        ),
    )
    client_tools: Optional[List[ClientToolConfig]] = Field(
        default=None,
        description=(
            "Frontend-implemented tools. Each becomes a ``StructuredTool`` "
            "whose body pauses the run via ``langgraph.types.interrupt(...)``; "
            "the AG-UI bridge surfaces the pause and the browser-side handler "
            "returns the result. Bound to the agent only when the AG-UI "
            "router opts in via ``bind_client_tools=True``."
        ),
    )
    available_when: Optional[Dict[str, str]] = Field(
        default=None,
        description=(
            "Per-tool ``simpleeval`` predicate map ({tool_name: expression}) "
            "evaluated against the current graph state immediately before "
            "each model call. Falsy expressions remove the tool from the "
            "bound list for that turn so the LLM can't propose it."
        ),
    )

    @model_validator(mode='after')
    def validate_system_prompt(self):
        """Ensure system_prompt is not empty."""
        if not self.system_prompt.strip():
            raise ValueError("'system_prompt' must not be empty")
        return self


class BuiltinTool(str, Enum):
    """Built-in DeepAgents tool types."""
    READ_FILE = "read_file"
    WRITE_FILE = "write_file"
    EDIT_FILE = "edit_file"
    EXECUTE = "execute"
    WRITE_TODOS = "write_todos"


class CustomToolRef(BaseModel):
    """Reference to custom tool functions from a Python module."""

    module: str = Field(
        ...,
        description="Python module path (e.g., 'myproject.tools')"
    )
    functions: List[str] = Field(
        ...,
        min_length=1,
        description="Function names to import from the module"
    )


class ToolsConfig(BaseModel):
    """Tools configuration for the deep agent."""

    builtin: Optional[List[BuiltinTool]] = Field(
        None,
        description="List of built-in tools to enable"
    )
    custom: Optional[List[CustomToolRef]] = Field(
        None,
        description="List of custom tool references"
    )


class SubagentSpec(BaseModel):
    """Specification for a subagent that the main agent can delegate to."""

    name: str = Field(
        ...,
        description="Unique identifier for this subagent (used in task tool calls)"
    )
    description: str = Field(
        ...,
        description="What this subagent does — the main agent uses this to decide when to delegate"
    )
    system_prompt: str = Field(
        ...,
        description="Instructions for the subagent"
    )
    model: Optional[str] = Field(
        None,
        description="Override the main agent's model (e.g., 'openai:gpt-4o')"
    )


class SubagentsConfig(BaseModel):
    """Subagent spawning configuration."""

    enabled: bool = Field(
        default=False,
        description="Whether subagent spawning is enabled"
    )
    max_depth: int = Field(
        default=DEFAULT_MAX_DEPTH,
        ge=1,
        le=10,
        description="Maximum subagent recursion depth"
    )
    agents: Optional[List[SubagentSpec]] = Field(
        None,
        description="List of named subagents available for delegation via the task tool"
    )


class MiddlewareType(str, Enum):
    """Built-in middleware types for deep agents."""
    TODO_LIST = "todo_list"
    MEMORY = "memory"
    SKILLS = "skills"
    FILESYSTEM = "filesystem"
    SUMMARIZATION = "summarization"
    PROMPT_CACHING = "prompt_caching"
    HITL = "hitl"


class MiddlewareEntry(BaseModel):
    """A single middleware configuration entry."""

    type: MiddlewareType = Field(
        ...,
        description="Middleware type"
    )
    config: Optional[Dict[str, Any]] = Field(
        None,
        description="Middleware-specific configuration"
    )


class MCPServerEntry(BaseModel):
    """Configuration for a single MCP server."""

    transport: str = Field(
        default="stdio",
        description="Transport type: 'stdio' or 'sse'"
    )
    command: Optional[str] = Field(
        None,
        description="Command to start the server (stdio transport)"
    )
    args: Optional[List[str]] = Field(
        None,
        description="Arguments for the server command (stdio transport)"
    )
    url: Optional[str] = Field(
        None,
        description="URL for the server (sse transport)"
    )
    env: Optional[Dict[str, str]] = Field(
        None,
        description="Environment variables for the server process"
    )


class DeepAgentYAMLConfig(BaseModel):
    """
    Root deep_agent.yaml configuration.

    This is the complete schema for AgentFlow Deep agent configuration files.
    Contains only business logic — persistence and telemetry are deployment
    concerns configured externally via builder parameters.
    """

    metadata: DeepAgentMetadata = Field(
        ...,
        description="Metadata about this configuration"
    )
    agent: AgentConfig = Field(
        ...,
        description="Core agent configuration (system_prompt + LLM)"
    )
    tools: Optional[ToolsConfig] = Field(
        None,
        description="Tools available to the agent"
    )
    subagents: Optional[SubagentsConfig] = Field(
        default_factory=SubagentsConfig,
        description="Subagent spawning configuration"
    )
    middleware: Optional[List[MiddlewareEntry]] = Field(
        None,
        description="Ordered list of middleware to apply"
    )
    mcp_servers: Optional[Dict[str, MCPServerEntry]] = Field(
        None,
        description="MCP servers to connect for additional tools"
    )
