"""
AgentFlow Deep: YAML-driven wrapper for LangChain DeepAgents.

Install: pip install agentflow[deep]
"""

from .core import DeepAgentBuilder, DeepAgentYAMLConfig

__all__ = [
    "DeepAgentBuilder",
    "DeepAgentYAMLConfig",
]
