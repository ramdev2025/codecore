"""AG-UI bridge for the deep (DeepAgents) backend.

Brings the AG-UI HTTP+SSE protocol to autonomous deep agents.
DeepAgents owns its bridge (no published upstream package wraps
LangGraph for AG-UI like Microsoft's ``agent_framework_ag_ui`` does
for MAF), so this sub-package carries the full implementation —
mirroring ``agentflow.workflows.agui`` which carries the same kind
of bridge for the workflows backend.

  * :mod:`events` — Pydantic wire models for AG-UI events
  * :mod:`adapter` — stateful event translator from orchestrator
    events to AG-UI wire events
  * :mod:`client_tools` — ``langgraph.types.interrupt``-based stubs
    for browser-side tools
  * :mod:`router` — FastAPI router + bridge resilience + OTel span
    + ``build_agui`` public entrypoint

The public entrypoint is :func:`build_agui`. Mount the returned
``(router, lifespan)`` into your own FastAPI app::

    from fastapi import FastAPI
    from agentflow.deep.agui import build_agui

    router, lifespan = build_agui(yaml_path="agent.yaml")
    app = FastAPI(lifespan=lifespan)
    app.include_router(router, prefix="/agui")
"""

from .adapter import AGUIAdapter, translate_stream
from .client_tools import build_client_tool_stub, build_client_tool_stubs
from .events import (
    AGUIEvent,
    CustomEvent,
    EventType,
    Interrupt,
    InterruptOutcome,
    RunError,
    RunFinished,
    RunStarted,
    StateDelta,
    StateSnapshot,
    TextMessageContent,
    TextMessageEnd,
    TextMessageStart,
    ToolCallArgs,
    ToolCallEnd,
    ToolCallResult,
    ToolCallStart,
    render_component,
)
from .router import build_agui

__all__ = [
    "AGUIAdapter",
    "AGUIEvent",
    "CustomEvent",
    "EventType",
    "Interrupt",
    "InterruptOutcome",
    "RunError",
    "RunFinished",
    "RunStarted",
    "StateDelta",
    "StateSnapshot",
    "TextMessageContent",
    "TextMessageEnd",
    "TextMessageStart",
    "ToolCallArgs",
    "ToolCallEnd",
    "ToolCallResult",
    "ToolCallStart",
    "build_agui",
    "build_client_tool_stub",
    "build_client_tool_stubs",
    "render_component",
    "translate_stream",
]
