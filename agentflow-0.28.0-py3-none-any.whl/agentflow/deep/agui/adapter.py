"""Deep orchestrator events → AG-UI event stream.

The deep orchestrator yields dicts of the form:

    {"type": "agent_start" | "token" | "agent" | "agent_end"
            | "tool_call" | "tool" | "state" | "interrupt",
     "name": str, "content": Any, "args"?: dict, "usage"?: dict}

This module translates that stream into AG-UI events
(see :mod:`agentflow.deep.agui.events`).

A tool result whose payload carries the ``__component__`` marker
(set by :func:`agentflow.deep.genui.resolve_ui_tools` when wrapping
``@ui_component`` fetchers) is additionally emitted as a
``RenderComponent`` ``CUSTOM`` event so the frontend can render the
typed component.

HITL pauses (``GraphInterrupt`` in LangGraph terms) flow through as a
``RUN_FINISHED`` event whose ``outcome`` carries the
:class:`agentflow.deep.agui.events.InterruptOutcome` payload.

Same translation logic as the workflows backend's adapter; both run
on LangGraph and the upstream event dict shape matches. Kept as a
sibling copy.
"""

from __future__ import annotations

import json
import logging
import uuid
from collections.abc import AsyncIterator
from typing import Any

from .events import (
    AGUIEvent,
    Interrupt,
    InterruptOutcome,
    RunError,
    RunFinished,
    RunStarted,
    StateSnapshot,
    TextMessageContent,
    TextMessageEnd,
    TextMessageStart,
    ToolCallArgs,
    ToolCallEnd,
    ToolCallResult,
    ToolCallStart,
    render_component,
)

logger = logging.getLogger(__name__)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class AGUIAdapter:
    """Stateful translator from deep orchestrator events to AG-UI events.

    One instance per run. Owns the bookkeeping needed to thread
    ``messageId`` / ``toolCallId`` across the start/content/end triples
    AG-UI requires.
    """

    def __init__(self, thread_id: str, run_id: str | None = None) -> None:
        self.thread_id = thread_id
        self.run_id = run_id or _new_id("run")
        self._current_message_id: str | None = None
        self._token_stream_seen: bool = False
        # Pending tool calls — keyed by tool name. We defer emitting
        # TOOL_CALL_START/ARGS/END until the fetcher result is in hand,
        # so we can put the fetcher's full props on the wire as the tool
        # call args. That matches CopilotKit's ``useComponent`` contract,
        # which renders from parsed args (the result field is not piped
        # to the component, by design).
        self._pending_calls: dict[str, dict[str, Any]] = {}
        # Pending HITL interrupts — populated by ``_on_interrupt`` when the
        # orchestrator reports a paused run. ``run_finished`` reads these to
        # populate ``outcome`` on the final RUN_FINISHED frame.
        self._pending_interrupts: list[Interrupt] = []

    # ── Lifecycle ────────────────────────────────────────────────────

    def run_started(self) -> AGUIEvent:
        return RunStarted(threadId=self.thread_id, runId=self.run_id, timestamp=None)

    def run_finished(self) -> AGUIEvent:
        outcome = (
            InterruptOutcome(interrupts=self._pending_interrupts)
            if self._pending_interrupts
            else None
        )
        return RunFinished(
            threadId=self.thread_id, runId=self.run_id, outcome=outcome, timestamp=None
        )

    def run_error(self, message: str, code: str | None = None) -> AGUIEvent:
        return RunError(message=message, code=code, timestamp=None)

    # ── Event translation ────────────────────────────────────────────

    def translate(self, event: dict[str, Any]) -> list[AGUIEvent]:
        """Map one deep orchestrator event dict to zero-or-more AG-UI events."""
        kind = event.get("type")
        if kind == "agent_start":
            return self._on_agent_start()
        if kind == "token":
            return self._on_token(event)
        if kind == "agent":
            return self._on_agent_complete(event)
        if kind == "agent_end":
            return self._on_agent_end()
        if kind == "tool_call":
            return self._on_tool_call(event)
        if kind == "tool":
            return self._on_tool_result(event)
        if kind == "interrupt":
            return self._on_interrupt(event)
        if kind == "state":
            return self._on_state(event)
        return []

    def close_open_message(self) -> list[AGUIEvent]:
        """Emit TEXT_MESSAGE_END for any message left open by the stream.

        The AG-UI spec rejects RUN_FINISHED while a text message is still
        active (CopilotKit raises ``AGUIError: Cannot send 'RUN_FINISHED'
        while text messages are still active``). Call this right before
        RUN_FINISHED so we never produce that violation.
        """
        if self._current_message_id is None:
            return []
        end = TextMessageEnd(messageId=self._current_message_id, timestamp=None)
        self._current_message_id = None
        self._token_stream_seen = False
        return [end]

    # ── Text message ─────────────────────────────────────────────────

    def _on_agent_start(self) -> list[AGUIEvent]:
        # Defer TEXT_MESSAGE_START until we know whether tokens or a single
        # complete message arrive. The first content event opens the message.
        self._current_message_id = None
        self._token_stream_seen = False
        return []

    def _ensure_message_open(self) -> list[AGUIEvent]:
        if self._current_message_id is not None:
            return []
        self._current_message_id = _new_id("msg")
        return [TextMessageStart(messageId=self._current_message_id, role="assistant", timestamp=None)]

    def _on_token(self, event: dict[str, Any]) -> list[AGUIEvent]:
        delta = event.get("content") or ""
        if not delta:
            return []
        self._token_stream_seen = True
        events = self._ensure_message_open()
        events.append(TextMessageContent(messageId=self._current_message_id or "", delta=delta, timestamp=None))
        return events

    def _on_agent_complete(self, event: dict[str, Any]) -> list[AGUIEvent]:
        # Non-streaming path: a single 'agent' event carries the whole response.
        if self._token_stream_seen:
            # Already streamed token-by-token; ignore the duplicate full-content event.
            return []
        content = event.get("content") or ""
        if not content:
            return []
        events = self._ensure_message_open()
        events.append(TextMessageContent(messageId=self._current_message_id or "", delta=content, timestamp=None))
        return events

    def _on_agent_end(self) -> list[AGUIEvent]:
        if self._current_message_id is None:
            return []
        end = TextMessageEnd(messageId=self._current_message_id, timestamp=None)
        self._current_message_id = None
        self._token_stream_seen = False
        return [end]

    # ── Tool calls ───────────────────────────────────────────────────

    def _on_tool_call(self, event: dict[str, Any]) -> list[AGUIEvent]:
        """Defer tool-call events until we have the fetcher result.

        Returning [] here is intentional. ``_on_tool_result`` will emit
        TOOL_CALL_START/ARGS/END/RESULT (and possibly a RenderComponent)
        all at once, with the fetcher's full props as the args delta.
        """
        tool_name = event.get("name") or "tool"
        original_args = event.get("args") or {}
        self._pending_calls[tool_name] = {
            "tool_call_id": _new_id("tc"),
            "original_args": original_args,
        }
        return []

    def _on_tool_result(self, event: dict[str, Any]) -> list[AGUIEvent]:
        tool_name = event.get("name") or "tool"
        content = event.get("content")
        pending = self._pending_calls.pop(tool_name, None)
        if pending is None:
            pending = {"tool_call_id": _new_id("tc"), "original_args": {}}
        tool_call_id = pending["tool_call_id"]
        original_args = pending["original_args"]

        # Decide what shape to put on the wire:
        #   - successful @ui_component → emit START/ARGS(full props)/END +
        #     RenderComponent + RESULT; useComponent's renderer fires with
        #     the full props as its parameters.
        #   - errored ui_tool (handled_tool_error → "[Name failed] ..." str)
        #     → emit a ToolError tool-call so the failure has a visible
        #     slot. The original component name never gets a slot, so no
        #     "GENERATING…" stuck rectangle.
        #   - plain tool (no marker, no failure prefix) → emit normally
        #     with the LLM's original args.

        success_props: dict[str, Any] | None = None
        success_component: str | None = None
        if isinstance(content, dict) and "__component__" in content:
            success_component = content["__component__"]
            success_props = {k: v for k, v in content.items() if k != "__component__"}
        elif isinstance(content, str):
            try:
                parsed = json.loads(content)
                if isinstance(parsed, dict) and "__component__" in parsed:
                    success_component = parsed["__component__"]
                    success_props = {k: v for k, v in parsed.items() if k != "__component__"}
            except (json.JSONDecodeError, TypeError):
                pass

        is_error = (
            success_props is None and isinstance(content, str) and content.startswith("[") and " failed]" in content
        )

        events: list[AGUIEvent] = []

        if success_props is not None and success_component is not None:
            # Emit the tool call with the FULL props in args, so the
            # frontend renderer (which reads args, not result) can render.
            args_json = json.dumps(success_props, default=str)
            events.extend(
                [
                    ToolCallStart(
                        toolCallId=tool_call_id,
                        toolCallName=success_component,
                        parentMessageId=self._current_message_id,
                        timestamp=None,
                    ),
                    ToolCallArgs(toolCallId=tool_call_id, delta=args_json, timestamp=None),
                    ToolCallEnd(toolCallId=tool_call_id, timestamp=None),
                    render_component(
                        component=success_component,
                        props=success_props,
                        tool_call_id=tool_call_id,
                    ),
                ]
            )
            result_payload: Any = success_props
        elif is_error:
            # Replace the failed tool's slot with a ToolError component
            # whose args carry {tool, message}. Frontend can register a
            # useComponent for "ToolError" to render a visible error card.
            err_props = {"tool": tool_name, "message": content}
            err_args_json = json.dumps(err_props)
            events.extend(
                [
                    ToolCallStart(
                        toolCallId=tool_call_id,
                        toolCallName="ToolError",
                        parentMessageId=self._current_message_id,
                        timestamp=None,
                    ),
                    ToolCallArgs(toolCallId=tool_call_id, delta=err_args_json, timestamp=None),
                    ToolCallEnd(toolCallId=tool_call_id, timestamp=None),
                    render_component(
                        component="ToolError",
                        props=err_props,
                        tool_call_id=tool_call_id,
                    ),
                ]
            )
            result_payload = content
        else:
            # Plain tool (no UI render), emit with the LLM's original args.
            if isinstance(original_args, str):
                args_json = original_args
            else:
                args_json = json.dumps(original_args, default=str)
            events.extend(
                [
                    ToolCallStart(
                        toolCallId=tool_call_id,
                        toolCallName=tool_name,
                        parentMessageId=self._current_message_id,
                        timestamp=None,
                    ),
                    ToolCallArgs(toolCallId=tool_call_id, delta=args_json, timestamp=None),
                    ToolCallEnd(toolCallId=tool_call_id, timestamp=None),
                ]
            )
            result_payload = content

        content_str = result_payload if isinstance(result_payload, str) else json.dumps(result_payload, default=str)
        events.append(
            ToolCallResult(
                messageId=_new_id("msg"), toolCallId=tool_call_id, content=content_str, role="tool", timestamp=None
            )
        )
        return events

    # ── Interrupts (human-in-the-loop) ───────────────────────────────

    def _on_interrupt(self, event: dict[str, Any]) -> list[AGUIEvent]:
        """Translate a paused-run envelope into AG-UI events.

        For every interrupt that names a tool currently buffered in
        ``_pending_calls`` (i.e. an ``interrupt_on`` middleware hit), the
        deferred TOOL_CALL_START/ARGS/END is promoted to the wire so the
        interrupt's ``toolCallId`` actually binds to a visible tool call
        per the AG-UI spec. The Interrupt records themselves are stashed
        in ``_pending_interrupts`` and picked up by ``run_finished``.

        Expected envelope:
            {"type": "interrupt", "interrupts": [
                {"id": ..., "reason": ..., "message"?: ...,
                 "tool_name"?: ..., "response_schema"?: ..., "metadata"?: ...},
                ...
            ]}
        """
        out: list[AGUIEvent] = []
        for raw in event.get("interrupts") or []:
            tool_name = raw.get("tool_name")
            tool_call_id: str | None = None
            tool_args: dict[str, Any] | None = None
            if tool_name and tool_name in self._pending_calls:
                # Normal case: agent called the tool this very run, the
                # tool-call event got deferred. Promote that buffered
                # lifecycle so the toolCallId on the Interrupt binds.
                pending = self._pending_calls.pop(tool_name)
                tool_call_id = pending["tool_call_id"]
                tool_args = pending["original_args"]
            elif tool_name:
                # Re-surface case: we're handing back an interrupt the
                # checkpointer recorded on a PRIOR run (e.g. the bridge's
                # paused-thread recovery, or a LangGraph silent pause that
                # our run-end check picked up). There is no buffered
                # ``_pending_calls`` entry to promote — synthesize a
                # tool-call lifecycle from the interrupt's metadata.args
                # so CopilotKit's ``useHumanInTheLoop`` (which binds by
                # toolCallId via the preceding TOOL_CALL_* sequence) still
                # has something to attach to.
                tool_call_id = _new_id("tc")
                meta = raw.get("metadata") or {}
                args = meta.get("args")
                tool_args = args if isinstance(args, dict) else {}
            if tool_call_id is not None:
                out.append(
                    ToolCallStart(
                        toolCallId=tool_call_id,
                        toolCallName=tool_name,
                        parentMessageId=self._current_message_id,
                        timestamp=None,
                    )
                )
                out.append(
                    ToolCallArgs(
                        toolCallId=tool_call_id,
                        delta=json.dumps(tool_args or {}, default=str),
                        timestamp=None,
                    )
                )
                out.append(ToolCallEnd(toolCallId=tool_call_id, timestamp=None))
            self._pending_interrupts.append(
                Interrupt(
                    id=raw.get("id") or _new_id("int"),
                    reason=raw.get("reason") or "confirmation",
                    message=raw.get("message"),
                    toolCallId=tool_call_id,
                    responseSchema=raw.get("response_schema"),
                    metadata=raw.get("metadata"),
                )
            )
        return out

    # ── State sync ───────────────────────────────────────────────────

    def _on_state(self, event: dict[str, Any]) -> list[AGUIEvent]:
        """Translate a state envelope into a STATE_SNAPSHOT event.

        The bridge in ``_RouterState.run`` injects ``{"type": "state",
        "snapshot": ...}`` records before/after meaningful events. We pass
        them through as-is. STATE_DELTA support (RFC 6902 JSON Patch) is
        defined in ``agui_events`` for forward compatibility but is not
        emitted by today's bridge.
        """
        snapshot = event.get("snapshot", {})
        return [StateSnapshot(snapshot=snapshot, timestamp=None)]


async def translate_stream(
    adapter: AGUIAdapter,
    events: AsyncIterator[dict[str, Any]],
) -> AsyncIterator[AGUIEvent]:
    """Async-translate a deep event stream into AG-UI events.

    Yields RunStarted first, then the translated events, then RunFinished.
    On exception yields a final RunError and ends the stream cleanly —
    upstream errors travel over the wire as a ``RUN_ERROR`` AG-UI frame
    per the spec, not as an HTTP-level failure. Re-raising would corrupt
    the SSE response (500'ing the connection mid-stream and depriving
    the client of the very RUN_ERROR event we just emitted).
    """
    yield adapter.run_started()
    try:
        async for ev in events:
            for out in adapter.translate(ev):
                yield out
    except Exception as exc:  # noqa: BLE001 — surfaced as RUN_ERROR
        logger.exception(
            "AG-UI translate_stream surfaced upstream exception as RUN_ERROR"
        )
        for closer in adapter.close_open_message():
            yield closer
        yield adapter.run_error(message=str(exc), code=type(exc).__name__)
        return
    for closer in adapter.close_open_message():
        yield closer
    yield adapter.run_finished()
