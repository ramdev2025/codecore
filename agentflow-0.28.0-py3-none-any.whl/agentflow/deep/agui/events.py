"""AG-UI event Pydantic models — deep-side wire shapes.

Covers the event types the deep AG-UI bridge emits:

  * **Lifecycle**: RUN_STARTED / RUN_FINISHED / RUN_ERROR
  * **Text streaming**: TEXT_MESSAGE_START / TEXT_MESSAGE_CONTENT /
    TEXT_MESSAGE_END
  * **Tool calls**: TOOL_CALL_START / TOOL_CALL_ARGS / TOOL_CALL_END
  * **Tool results**: TOOL_CALL_RESULT
  * **State sync**: STATE_SNAPSHOT / STATE_DELTA
  * **Generative UI**: CUSTOM (used for RenderComponent — props
    payload keyed off the ``__component__`` marker the deep genui
    adapter stamps onto fetcher returns)
  * **HITL**: ``RunFinished.outcome`` carrying ``InterruptOutcome``

Same wire shapes as the workflows backend's AG-UI sub-package (both
run on LangChain + LangGraph). Kept as a sibling copy so the two
backends can evolve independently. MAF uses Microsoft's upstream
``agent_framework_ag_ui`` models (different module, similar intent);
the frontend protocol layer is the same across backends, the
differences are server-side serialization detail.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


class EventType(str, Enum):
    RUN_STARTED = "RUN_STARTED"
    RUN_FINISHED = "RUN_FINISHED"
    RUN_ERROR = "RUN_ERROR"
    TEXT_MESSAGE_START = "TEXT_MESSAGE_START"
    TEXT_MESSAGE_CONTENT = "TEXT_MESSAGE_CONTENT"
    TEXT_MESSAGE_END = "TEXT_MESSAGE_END"
    TOOL_CALL_START = "TOOL_CALL_START"
    TOOL_CALL_ARGS = "TOOL_CALL_ARGS"
    TOOL_CALL_END = "TOOL_CALL_END"
    TOOL_CALL_RESULT = "TOOL_CALL_RESULT"
    STATE_SNAPSHOT = "STATE_SNAPSHOT"
    STATE_DELTA = "STATE_DELTA"
    CUSTOM = "CUSTOM"


class AGUIEvent(BaseModel):
    """Base AG-UI event. Subclasses add fields and pin ``type``."""

    type: EventType
    timestamp: int | None = Field(
        None,
        description="Unix epoch milliseconds. Optional per AG-UI spec.",
    )

    def to_wire(self) -> dict[str, Any]:
        """Serialize to the dict form sent over the wire.

        Uses ``by_alias=True`` so field names follow the AG-UI camelCase
        spec (``threadId``, ``runId``, ``messageId``, ...).
        """
        return self.model_dump(mode="json", exclude_none=True, by_alias=True)


class RunStarted(AGUIEvent):
    type: Literal[EventType.RUN_STARTED] = EventType.RUN_STARTED
    thread_id: str = Field(..., alias="threadId")
    run_id: str = Field(..., alias="runId")

    model_config = {"populate_by_name": True}


class Interrupt(BaseModel):
    """A single pause requesting human input.

    Mirrors the AG-UI spec's Interrupt type. ``reason`` follows the
    spec's taxonomy (``tool_call`` / ``input_required`` / ``confirmation``)
    or a namespaced framework reason (``langgraph:node_interrupt`` etc.).
    """

    id: str
    reason: str
    message: str | None = None
    tool_call_id: str | None = Field(default=None, alias="toolCallId")
    response_schema: dict[str, Any] | None = Field(default=None, alias="responseSchema")
    metadata: dict[str, Any] | None = None

    model_config = {"populate_by_name": True}


class InterruptOutcome(BaseModel):
    """``outcome`` payload carried on a ``RUN_FINISHED`` event when the run
    paused for human input. ``type`` is ``"interrupt"`` per the AG-UI spec."""

    type: Literal["interrupt"] = "interrupt"
    interrupts: list[Interrupt]


class RunFinished(AGUIEvent):
    type: Literal[EventType.RUN_FINISHED] = EventType.RUN_FINISHED
    thread_id: str = Field(..., alias="threadId")
    run_id: str = Field(..., alias="runId")
    # When the run paused for human input the spec carries the interrupt
    # set on ``outcome`` instead of opening a separate event type.
    outcome: InterruptOutcome | None = None

    model_config = {"populate_by_name": True}


class RunError(AGUIEvent):
    type: Literal[EventType.RUN_ERROR] = EventType.RUN_ERROR
    message: str
    code: str | None = None


class TextMessageStart(AGUIEvent):
    type: Literal[EventType.TEXT_MESSAGE_START] = EventType.TEXT_MESSAGE_START
    message_id: str = Field(..., alias="messageId")
    role: str = "assistant"

    model_config = {"populate_by_name": True}


class TextMessageContent(AGUIEvent):
    type: Literal[EventType.TEXT_MESSAGE_CONTENT] = EventType.TEXT_MESSAGE_CONTENT
    message_id: str = Field(..., alias="messageId")
    delta: str

    model_config = {"populate_by_name": True}


class TextMessageEnd(AGUIEvent):
    type: Literal[EventType.TEXT_MESSAGE_END] = EventType.TEXT_MESSAGE_END
    message_id: str = Field(..., alias="messageId")

    model_config = {"populate_by_name": True}


class ToolCallStart(AGUIEvent):
    type: Literal[EventType.TOOL_CALL_START] = EventType.TOOL_CALL_START
    tool_call_id: str = Field(..., alias="toolCallId")
    tool_call_name: str = Field(..., alias="toolCallName")
    parent_message_id: str | None = Field(None, alias="parentMessageId")

    model_config = {"populate_by_name": True}


class ToolCallArgs(AGUIEvent):
    type: Literal[EventType.TOOL_CALL_ARGS] = EventType.TOOL_CALL_ARGS
    tool_call_id: str = Field(..., alias="toolCallId")
    delta: str = Field(..., description="JSON string fragment of the tool args.")

    model_config = {"populate_by_name": True}


class ToolCallEnd(AGUIEvent):
    type: Literal[EventType.TOOL_CALL_END] = EventType.TOOL_CALL_END
    tool_call_id: str = Field(..., alias="toolCallId")

    model_config = {"populate_by_name": True}


class ToolCallResult(AGUIEvent):
    type: Literal[EventType.TOOL_CALL_RESULT] = EventType.TOOL_CALL_RESULT
    message_id: str = Field(..., alias="messageId")
    tool_call_id: str = Field(..., alias="toolCallId")
    content: str = Field(..., description="Tool result as a JSON-encoded string.")
    role: str = "tool"

    model_config = {"populate_by_name": True}


class StateSnapshot(AGUIEvent):
    """Full state snapshot — CopilotKit's ``useCoAgentState`` consumer reads
    these to keep its mirror of the agent's state in sync.

    Emitted at run start (initial state of the thread) and after any
    state-mutating event when the value actually changed.
    """

    type: Literal[EventType.STATE_SNAPSHOT] = EventType.STATE_SNAPSHOT
    snapshot: Any


class StateDelta(AGUIEvent):
    """Incremental state update as an RFC 6902 JSON Patch operation list.

    Not emitted by the current backend (snapshots only). Carried in the
    schema for forward-compat with clients that want to read deltas; the
    spec mandates this is how AG-UI carries incremental state updates.
    """

    type: Literal[EventType.STATE_DELTA] = EventType.STATE_DELTA
    delta: list[dict[str, Any]]


class CustomEvent(AGUIEvent):
    """AG-UI CUSTOM event — used for RenderComponent payloads."""

    type: Literal[EventType.CUSTOM] = EventType.CUSTOM
    name: str
    value: dict[str, Any]


def render_component(component: str, props: dict[str, Any], tool_call_id: str) -> CustomEvent:
    """Build a RenderComponent CUSTOM event with typed props."""
    return CustomEvent(
        name="RenderComponent",
        value={"component": component, "props": props, "toolCallId": tool_call_id},
        timestamp=None,
    )
