"""
AgentFlow Deep — Terminal User Interface.

A Textual-based TUI that shows:
- Agent output with streaming tokens
- Live todo list (updated when the agent calls write_todos)
- Input bar for tasks
- Status bar with config, thread, elapsed time
"""

import time
from contextlib import nullcontext as _nullcontext
from pathlib import Path
from typing import Optional

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, RichLog, Static


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------

class TodoPanel(Static):
    """Displays the agent's todo list."""

    DEFAULT_CSS = """
    TodoPanel {
        width: 1fr;
        height: 1fr;
        border: solid $accent;
        padding: 0 1;
        overflow-y: auto;
    }
    """

    def __init__(self) -> None:
        super().__init__("[dim]No plan yet[/dim]")
        self._todos: list[dict] = []
        self.border_title = "Plan"

    def render(self):
        return self.visual or "No plan yet"

    def update_todos(self, todos: list[dict]) -> None:
        self._todos = todos
        if not self._todos:
            self.update("[dim]No plan yet[/dim]")
            return

        lines = []
        for todo in self._todos:
            status = todo.get("status", "pending")
            content = todo.get("content", "")
            if status == "completed":
                icon, style = "\u2611", "green strike"
            elif status == "in_progress":
                icon, style = "\u25b6", "bold yellow"
            else:
                icon, style = "\u2610", "dim"
            lines.append(f"[{style}]{icon} {content}[/{style}]")

        self.update("\n".join(lines))


class StatusPanel(Static):
    """Displays execution status."""

    DEFAULT_CSS = """
    StatusPanel {
        height: 3;
        border: solid $surface;
        padding: 0 1;
    }
    """

    def __init__(self) -> None:
        super().__init__("IDLE")
        self._config = ""
        self._thread_id = ""
        self._state = "idle"
        self._start_time: Optional[float] = None
        self._tool_calls = 0
        self._messages = 0
        self.border_title = "Status"

    def render(self):
        return self.visual or "IDLE"

    def set_config(self, config: str, thread_id: str) -> None:
        self._config = config
        self._thread_id = thread_id
        self._refresh_content()

    def set_running(self) -> None:
        self._state = "running"
        self._start_time = time.monotonic()
        self._tool_calls = 0
        self._messages = 0
        self._refresh_content()

    def set_done(self) -> None:
        self._state = "done"
        self._refresh_content()

    def increment_tools(self) -> None:
        self._tool_calls += 1
        self._refresh_content()

    def increment_messages(self) -> None:
        self._messages += 1
        self._refresh_content()

    def _refresh_content(self) -> None:
        elapsed = ""
        if self._start_time:
            secs = time.monotonic() - self._start_time
            m, s = divmod(secs, 60)
            elapsed = f"{int(m)}m {s:.0f}s"

        state_style = {"idle": "dim", "running": "bold yellow", "done": "bold green"}
        style = state_style.get(self._state, "dim")

        parts = [f"[{style}]{self._state.upper()}[/{style}]"]
        if elapsed:
            parts.append(elapsed)
        parts.append(f"Tools: {self._tool_calls}")
        parts.append(f"Msgs: {self._messages}")
        if self._config:
            parts.append(f"Config: {self._config}")

        self.update("  |  ".join(parts))


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

class DeepAgentTUI(App):
    """TUI for AgentFlow Deep agents."""

    CSS = """
    #main {
        height: 1fr;
    }
    #left {
        width: 3fr;
    }
    #right {
        width: 1fr;
    }
    #agent-log {
        border: solid $primary;
        height: 1fr;
    }
    #task-input {
        dock: bottom;
    }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit"),
        Binding("ctrl+l", "clear_log", "Clear"),
    ]

    def __init__(
            self,
            yaml_path: str,
            workdir: str = ".",
            persistence: str = "memory",
            db_path: Optional[str] = None,
            connection_string: Optional[str] = None,
            no_checkpointer: bool = False,
            thread_id: Optional[str] = None,
    ) -> None:
        super().__init__()
        self._yaml_path = yaml_path
        self._workdir = workdir
        self._persistence = persistence
        self._db_path = db_path
        self._connection_string = connection_string
        self._no_checkpointer = no_checkpointer

        import uuid
        self._thread_id = thread_id or str(uuid.uuid4())
        self._builder = None
        self._telemetry = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="main"):
            with Vertical(id="left"):
                yield RichLog(id="agent-log", highlight=True, markup=True, wrap=True)
                yield Input(
                    id="task-input",
                    placeholder="Enter task (or 'quit' to exit)...",
                )
            with Vertical(id="right"):
                yield TodoPanel()
                yield StatusPanel()
        yield Footer()

    def on_mount(self) -> None:
        self.title = "AgentFlow Deep"
        self.sub_title = Path(self._yaml_path).name

        log = self.query_one("#agent-log", RichLog)
        log.border_title = "Agent"

        # Build agent
        from agentflow.deep.cli import build_agent
        try:
            self._builder = build_agent(
                self._yaml_path,
                no_checkpointer=self._no_checkpointer,
                persistence=self._persistence,
                db_path=self._db_path,
                connection_string=self._connection_string,
                backend_dir=self._workdir,
            )
        except Exception as e:
            log.write(f"[bold red]Error loading config:[/bold red] {e}")
            return

        # Telemetry (auto-enabled from OTEL_TRACES_ENABLED env var)
        from agentflow.deep.core.telemetry import DeepAgentTelemetry
        telem = DeepAgentTelemetry()
        if telem.enabled:
            self._telemetry = telem

        status = self.query_one(StatusPanel)
        status.set_config(Path(self._yaml_path).name, self._thread_id)

        log.write("[dim]Ready. Enter a task below.[/dim]\n")

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        query = event.value.strip()
        event.input.clear()

        if not query:
            return
        if query.lower() in ("quit", "q", "exit"):
            if self._telemetry:
                self._telemetry.shutdown()
            self.exit()
            return

        log = self.query_one("#agent-log", RichLog)
        log.write(f"\n[bold cyan]>>> {query}[/bold cyan]\n")

        self.run_agent(query)

    @work(thread=True)
    def run_agent(self, query: str) -> None:
        """Run agent in background thread, streaming updates to the TUI."""
        from langchain_core.messages import HumanMessage

        log = self.query_one("#agent-log", RichLog)
        status = self.query_one(StatusPanel)
        todo_panel = self.query_one(TodoPanel)

        self.call_from_thread(status.set_running)

        agent = self._builder.build()
        input_dict = {"messages": [HumanMessage(content=query)]}
        config = {"configurable": {"thread_id": self._thread_id}}

        telem_ctx = (
            self._telemetry.span("deepagent.invoke", query=query, thread_id=self._thread_id)
            if self._telemetry else _nullcontext()
        )

        try:
            with telem_ctx:
                for chunk in agent.stream(input_dict, config, stream_mode="updates"):
                    for node_name, node_output in chunk.items():
                        if node_name == "__interrupt__":
                            self.call_from_thread(
                                log.write,
                                "[bold yellow]Agent interrupted (human-in-the-loop)[/bold yellow]",
                            )
                            continue

                        if node_output is None or not isinstance(node_output, dict):
                            continue

                        raw_msgs = node_output.get("messages", [])
                        if not isinstance(raw_msgs, list):
                            try:
                                raw_msgs = list(raw_msgs)
                            except TypeError:
                                raw_msgs = [raw_msgs] if hasattr(raw_msgs, "type") else []
                        for msg in raw_msgs:
                            msg_type = getattr(msg, "type", None)
                            content = getattr(msg, "content", "")

                            # AI message with content
                            if msg_type == "ai" and content:
                                self.call_from_thread(status.increment_messages)
                                self.call_from_thread(log.write, content)

                            # Detect write_todos in tool calls. Tool spans (with
                            # real timing + token usage) come from the LangSmith
                            # OTel bridge enabled in DeepAgentTelemetry; we no
                            # longer emit zero-width marker spans here.
                            if msg_type == "ai" and hasattr(msg, "tool_calls"):
                                for tc in getattr(msg, "tool_calls", []):
                                    tc_name = tc.get("name", "?")
                                    tc_args = tc.get("args", {})
                                    if tc_name == "write_todos":
                                        todos = tc_args.get("todos", [])
                                        self.call_from_thread(todo_panel.update_todos, todos)
                                    self.call_from_thread(status.increment_tools)

                            # Tool message result
                            if msg_type == "tool" and content:
                                name = getattr(msg, "name", "tool")
                                preview = content[:200]
                                self.call_from_thread(
                                    log.write,
                                    f"[dim]\u2502 {name}: {preview}[/dim]",
                                )

                        # Check for todos in state updates
                        todos = node_output.get("todos")
                        if todos is not None:
                            self.call_from_thread(todo_panel.update_todos, todos)

        except Exception as e:
            self.call_from_thread(
                log.write,
                f"\n[bold red]Error:[/bold red] {e}",
            )
        finally:
            self.call_from_thread(status.set_done)
            self.call_from_thread(log.write, "\n[dim]Done. Enter another task or 'quit'.[/dim]\n")

    def action_clear_log(self) -> None:
        self.query_one("#agent-log", RichLog).clear()


def run_tui(**kwargs) -> None:
    """Entry point for the TUI, called from cli.py."""
    app = DeepAgentTUI(**kwargs)
    app.run()
