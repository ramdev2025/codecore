"""DeepAgents adapter for the cross-backend ``ui_tools`` vocabulary.

Wraps each ``@agentflow.genui.ui_component``-decorated fetcher as a
LangChain ``StructuredTool``. The agent calls the tool; AgentFlow runs
the fetcher, validates the return against the Pydantic component class,
and returns ``dict(props) | {"__component__": ClassName}`` — the
deep AG-UI bridge picks up the marker and emits a typed render
event to the frontend.

Why this is the same code as workflows
--------------------------------------

DeepAgents is built on the same LangChain + LangGraph runtime as
the workflows backend, so the tool primitive (``StructuredTool``)
and the in-band ``__component__`` marker convention apply unchanged.
The two backends keep separate copies of this module to honour the
"sibling modules, minimal coupling" rule — neither imports from the
other. If a third LangGraph-based backend lands, this would be a good
candidate to lift into ``agentflow.genui.langchain_resolver``.

Tool name vs component name
---------------------------

The deep AG-UI bridge does not merge ``RunAgentInput.tools[]`` into
the bound list (CopilotKit's ``useComponent({ name: X })`` doesn't
collide with same-named server tools the way it does on MAF), so deep
keeps the workflows convention of naming the LangChain tool after the
**component class** itself — more readable in traces. The
``_agentflow_component_name`` attribute is set anyway so
``agentflow.genui.filter_by_availability`` can match predicates by
class name uniformly across backends.
"""

from __future__ import annotations

import inspect
import logging
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from agentflow.genui import (
    UIToolsConfig,
    discover_ui_components,
    get_component_class,
)

logger = logging.getLogger(__name__)


def resolve_ui_tools(config: UIToolsConfig | None) -> list[Any]:
    """Build a list of LangChain ``StructuredTool`` instances from a ``UIToolsConfig``.

    Returns an empty list when ``config`` is ``None`` so callers can
    extend their tools list unconditionally.

    Args:
        config: The parsed ``ui_tools:`` YAML block.

    Returns:
        List of ``StructuredTool`` objects ready for the LangChain
        agent's tool list. Each is named after its component class
        and carries a ``_agentflow_component_name`` attribute for the
        shared availability filter.

    Raises:
        ImportError: If ``langchain-core`` isn't available.
        ValueError: If ``config.use`` names an unknown component.
    """
    if config is None:
        return []

    try:
        from langchain_core.tools import StructuredTool  # noqa: F401
    except ImportError as exc:  # pragma: no cover — workflows extra installs this
        raise ImportError(
            "langchain-core is required to resolve ui_tools on the workflows "
            "backend. Install via `pip install agentflow[workflows]`."
        ) from exc

    discovered = discover_ui_components(config.module)
    if config.use is not None:
        missing = sorted(set(config.use) - set(discovered.keys()))
        if missing:
            available = sorted(discovered.keys())
            raise ValueError(
                f"ui_tools.use names component(s) not found in "
                f"{config.module!r}: {missing}. Available: {available}"
            )
        discovered = {n: discovered[n] for n in config.use}

    tools: list[Any] = []
    for class_name, fetcher in discovered.items():
        component_cls = get_component_class(fetcher)
        if component_cls is None:  # pragma: no cover — discover guards this
            raise RuntimeError(f"{fetcher} is not @ui_component-decorated")
        tools.append(_wrap_as_structured_tool(class_name, component_cls, fetcher))
    return tools


def _wrap_as_structured_tool(
    class_name: str,
    component_cls: type[BaseModel],
    fetcher: Callable[..., Any],
) -> Any:
    """Build a LangChain ``StructuredTool`` for one ``@ui_component`` fetcher."""
    from langchain_core.tools import StructuredTool

    description = (fetcher.__doc__ or f"Render the {class_name} component.").strip()
    args_schema = _args_schema_from_signature(fetcher, class_name)
    is_async = inspect.iscoroutinefunction(fetcher)

    def _validate_and_mark(result: Any) -> dict[str, Any]:
        """Validate the fetcher's return and stamp the workflows-side
        ``__component__`` marker. Raises on bad input — the outer wrapper
        catches and converts to a ToolError string for the LLM."""
        if isinstance(result, component_cls):
            instance = result
        elif isinstance(result, dict):
            instance = component_cls(**result)
        else:
            raise TypeError(
                f"@ui_component({class_name}) fetcher must return a {class_name} "
                f"instance or a dict; got {type(result).__name__}."
            )
        payload = instance.model_dump(mode="json")
        payload["__component__"] = class_name
        return payload

    def _format_error(exc: BaseException) -> str:
        """LLM-facing tool error.

        We surface fetcher exceptions as the canonical
        ``[Name failed] Type: msg`` string rather than raising. With
        multiple parallel ``ui_tool`` calls in one turn, a single bad
        fetcher (invalid args, Pydantic validation failure) must not
        abort sibling renders. The LLM sees the error in the tool
        result, can apologize, and continue."""
        return (
            f"[{class_name} failed] {type(exc).__name__}: {exc}. "
            f"If the user asked for this component, apologize briefly and "
            f"move on; other components in this turn may still have rendered."
        )

    if is_async:

        async def coroutine_wrapper(**kwargs: Any) -> Any:
            try:
                return _validate_and_mark(await fetcher(**kwargs))
            except Exception as exc:  # noqa: BLE001 — surfaced to LLM as text
                return _format_error(exc)

        tool = StructuredTool(
            name=class_name,
            description=description,
            args_schema=args_schema,
            coroutine=coroutine_wrapper,
        )
    else:

        def sync_wrapper(**kwargs: Any) -> Any:
            try:
                return _validate_and_mark(fetcher(**kwargs))
            except Exception as exc:  # noqa: BLE001 — surfaced to LLM as text
                return _format_error(exc)

        tool = StructuredTool(
            name=class_name,
            description=description,
            args_schema=args_schema,
            func=sync_wrapper,
        )

    # Tag for ``agentflow.genui.filter_by_availability``. The filter looks
    # up predicates keyed by component class name; setting this attribute
    # keeps the cross-backend resolution uniform.
    tool._agentflow_component_name = class_name  # type: ignore[attr-defined]
    return tool


def _args_schema_from_signature(func: Callable[..., Any], name: str) -> Any:
    """Build a Pydantic args_schema from a fetcher's signature.

    We build this explicitly rather than relying on LangChain's
    introspection of the runtime ``coroutine_wrapper`` / ``sync_wrapper``
    (which lose the original annotations through ``**kwargs``).
    """
    from pydantic import create_model

    fields: dict[str, Any] = {}
    sig = inspect.signature(func)
    for param_name, param in sig.parameters.items():
        if param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue
        annotation: Any = (
            param.annotation if param.annotation is not inspect.Parameter.empty else Any
        )
        default: Any = (
            ... if param.default is inspect.Parameter.empty else param.default
        )
        fields[param_name] = (annotation, default)
    if not fields:
        return create_model(f"{name}Args")
    return create_model(f"{name}Args", **fields)
