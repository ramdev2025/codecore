# Persistence

AgentFlow Deep supports three persistence backends for conversation checkpointing: SQLite (default), PostgreSQL, and
in-memory. Persistence is a **deployment concern** — configured via CLI flags or environment variables, not in the agent
YAML.

## Backends

| Backend    | Use Case                             | CLI Flag                         |
|------------|--------------------------------------|----------------------------------|
| SQLite     | Local development, single-user       | `--persistence sqlite` (default) |
| PostgreSQL | Production, multi-user, shared state | `--persistence postgres`         |
| Memory     | Testing, one-off queries             | `--persistence memory`           |

## Backend selection at deploy time

The persistence backend is chosen with this priority:

1. `--persistence` CLI flag — explicit override at run time.
2. `AGENTFLOW_PERSISTENCE` env var — set the backend without a CLI flag (useful in containers and CI).
3. Default — `sqlite`.

```bash
# Containerized deployment — no CLI flag needed
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="postgresql://user:pass@host/db"
agentflow --yaml agent.yaml "Your task"
```

See [`workflows/PERSISTENCE.md`](../../workflows/docs/PERSISTENCE.md)
for the canonical reference. Deep shares the `POSTGRES_POOL_*`
pool-tuning family with workflows. `AGENTFLOW_STORE_ENABLED` and
`AGENTFLOW_ENCRYPTION_KEY` are workflows-only — deep has no store, and
its checkpointer does not currently apply at-rest encryption.

## SQLite (Default)

SQLite stores checkpoints in a local file. Zero configuration needed.

```bash
# Uses default path: .agentflow/deep_checkpoints.db
agentflow --yaml agent.yaml "Your task"

# Custom path
agentflow --yaml agent.yaml --db-path ./checkpoints/my_agent.db "Your task"
```

The parent directory is created automatically if it doesn't exist.

### Environment Variable

```bash
# .env
CHECKPOINTER_DB_PATH=./data/my_checkpoints.db
```

Priority: `--db-path` flag > `CHECKPOINTER_DB_PATH` env var > default (`.agentflow/deep_checkpoints.db`).

## PostgreSQL

PostgreSQL is recommended for production deployments with multiple users or shared state.

```bash
# Via CLI flag
agentflow --yaml agent.yaml --persistence postgres \
  --connection-string "postgresql://user:pass@localhost/mydb" \
  "Your task"

# Via .env (no --connection-string needed)
agentflow --yaml agent.yaml --persistence postgres "Your task"
```

### Environment Variable

```bash
# .env
POSTGRES_CONNECTION_STRING="postgresql://user:pass@localhost/mydb"
```

Priority: `--connection-string` flag > `POSTGRES_CONNECTION_STRING` env var.

The connection string supports `${ENV_VAR}` syntax:

```bash
--connection-string "postgresql://${DB_USER}:${DB_PASS}@${DB_HOST}/${DB_NAME}"
```

### Setup

PostgreSQL requires additional packages:

```bash
pip install agentflow[postgres]
# Installs: langgraph-checkpoint-postgres, psycopg
```

The checkpointer automatically runs schema migrations on first use (`checkpointer.setup()`).

### Connection pooling

Since 0.28.0 the PostgreSQL checkpointer serves connections from a
`psycopg_pool` pool rather than holding one connection for the process
lifetime. Connections are validated on checkout and retired on a timer, so a
database restart, failover, or reaped idle connection no longer leaves the
agent permanently failing with `OperationalError: the connection is closed`.

The pool is tuned with the same `POSTGRES_POOL_*` variables the workflows
backend uses (see the table below). The defaults are safe; you only need to
touch them to fit a connection cap or a short idle timeout.

## In-Memory

In-memory persistence is useful for testing or one-off queries where you don't need conversation continuity.

```bash
agentflow --yaml agent.yaml --persistence memory "Quick question"
```

State is lost when the process exits.

## Disabling Persistence

To run completely stateless (no checkpointer at all):

```bash
agentflow --yaml agent.yaml --no-checkpointer "One-off task"
```

## Conversation Continuity

Use `--thread-id` to maintain conversation state across runs:

```bash
# First interaction
agentflow --yaml agent.yaml --thread-id session-001 "Read the codebase and summarize"

# Continue the conversation (agent remembers previous context)
agentflow --yaml agent.yaml --thread-id session-001 "Now refactor the auth module"

# Interactive mode with persistent thread
agentflow --yaml agent.yaml --interactive --thread-id session-001
```

Without `--thread-id`, a new UUID is generated for each run.

## Environment Variable Conventions

These environment variables are shared between AgentFlow Deep and AgentFlow Workflows:

| Variable                     | Description                                                   |
|------------------------------|---------------------------------------------------------------|
| `POSTGRES_CONNECTION_STRING` | PostgreSQL connection string                                  |
| `CHECKPOINTER_DB_PATH`       | SQLite database path                                          |
| `POSTGRES_POOL_SIZE`         | Maximum connections in the pool (default `5`)                 |
| `POSTGRES_POOL_MIN_SIZE`     | Connections kept open at all times (default `1`)              |
| `POSTGRES_POOL_MAX_LIFETIME` | Seconds before a connection is retired (default `600`)        |
| `POSTGRES_POOL_MAX_IDLE`     | Seconds an idle connection above `min_size` lives (default `300`) |
| `POSTGRES_POOL_CHECK`        | Validate connections on checkout (default `true`)             |
| `POSTGRES_POOL_TIMEOUT`      | Seconds to wait for a free connection (default `30`)          |

Both products read the same env vars, so a single `.env` file works for both.

## Programmatic Usage

```python
from agentflow.deep import DeepAgentBuilder
from agentflow.deep.core.persistence import create_checkpointer

# SQLite
checkpointer = create_checkpointer(backend="sqlite", db_path="./data/agent.db")

# PostgreSQL
checkpointer = create_checkpointer(
    backend="postgres",
    connection_string="postgresql://user:pass@localhost/db",
)

# Memory
checkpointer = create_checkpointer(backend="memory")

# Build agent with checkpointer
builder = DeepAgentBuilder.from_yaml("agent.yaml", checkpointer=checkpointer)
agent = builder.build()

result = agent.invoke(
    {"messages": [HumanMessage(content="Hello")]},
    config={"configurable": {"thread_id": "session-1"}},
)
```

### `create_checkpointer()` API

```python
def create_checkpointer(
    backend: str = "memory",           # "memory", "sqlite", or "postgres"
    db_path: Optional[str] = None,     # SQLite path (falls back to env var)
    connection_string: Optional[str] = None,  # Postgres URI (falls back to env var)
) -> Any:
```

**Returns**: A LangGraph-compatible checkpointer instance (`MemorySaver`, `SqliteSaver`, or `PostgresSaver`).

**Raises**:

- `ValueError` if backend is unknown or postgres has no connection string
- `ImportError` if required packages are missing
