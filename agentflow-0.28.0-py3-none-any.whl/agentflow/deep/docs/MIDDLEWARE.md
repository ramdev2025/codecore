# Middleware

Middleware configures agent capabilities — memory injection, skills, human-in-the-loop interrupts, and internal
optimizations. Middleware is declared in YAML and resolved at build time into `create_deep_agent()` parameters.

## Overview

```yaml
middleware:
  - type: todo_list          # Planning with todo lists
  - type: memory             # Project context injection
    config:
      sources:
        - ".deepagents/AGENTS.md"
  - type: skills             # Reusable skill templates
    config:
      skills_dir: ".skills/"
  - type: filesystem         # File system access
  - type: summarization      # Context window management
  - type: prompt_caching     # Reduce API costs
  - type: hitl               # Human-in-the-loop
    config:
      interrupt_on:
        tools: ["execute", "write_file"]
```

## Middleware Types

### `todo_list`

Enables the `write_todos` tool for planning. The agent can create, update, and track a todo list during execution.

```yaml
- type: todo_list
```

**Auto-enabled** by deepagents — listing it is declarative.

### `memory`

Injects markdown files into the agent's system prompt as project context.

```yaml
- type: memory
  config:
    sources:
      - ".deepagents/AGENTS.md"
      - ".deepagents/CODING_STANDARDS.md"
```

| Config    | Type         | Description                                            |
|-----------|--------------|--------------------------------------------------------|
| `sources` | list[string] | Paths to markdown files (relative to the backend root) |

The memory files are read at agent build time and their contents are appended to the system prompt. This is how you give
the agent persistent project knowledge.

**Example `.deepagents/AGENTS.md`:**

```markdown
# Project: My Web App

## Tech Stack
- Python 3.12, FastAPI, SQLAlchemy, PostgreSQL

## Conventions
- API routes in `src/api/`
- Models in `src/models/`
- Always write tests for new features
- Use Pydantic for validation

## Known Issues
- The auth middleware has a race condition under load (tracked in JIRA-123)
```

### `skills`

Loads reusable skill templates from SKILL.md files.

```yaml
- type: skills
  config:
    skills_dir: ".skills/"
```

| Config       | Type   | Default    | Description                       |
|--------------|--------|------------|-----------------------------------|
| `skills_dir` | string | `.skills/` | Path to the skills root directory |

See [Skills](SKILLS.md) for details on creating and using skills.

### `filesystem`

Enables file system access for the agent.

```yaml
- type: filesystem
  config:
    read_file_cache: true   # default: true
```

**Auto-enabled** by deepagents.

| Config            | Type | Default | Description                                                                                                                                                                                                                                                                                                                                                  |
|-------------------|------|---------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `read_file_cache` | bool | `true`  | Cache `read_file` results to prevent infinite loops when the LLM repeatedly reads the same file with identical arguments. On the second and subsequent duplicate call, the cached content is returned with a `[DUPLICATE READ]` warning that nudges the LLM to proceed. The cache is reset at the start of each agent invocation. Set to `false` to disable. |

### `summarization`

Enables context window summarization — when the conversation exceeds the context window, older messages are summarized
to make room.

```yaml
- type: summarization
```

**Auto-enabled** by deepagents.

### `prompt_caching`

Enables prompt caching to reduce API costs on repeated prompts.

```yaml
- type: prompt_caching
```

**Auto-enabled** by deepagents.

### `hitl` (Human-in-the-Loop)

Pauses agent execution before specific tool calls and waits for human approval.

```yaml
- type: hitl
  config:
    interrupt_on:
      tools:
        - execute
        - write_file
```

| Config               | Type         | Description                           |
|----------------------|--------------|---------------------------------------|
| `interrupt_on`       | dict         | Conditions for interrupting execution |
| `interrupt_on.tools` | list[string] | Tool names that require approval      |

When the agent calls a tool listed in `interrupt_on.tools`, execution pauses and the CLI/TUI prompts for approval. This
is useful for dangerous operations like file writes or command execution.

## How Middleware Maps to `create_deep_agent()`

Middleware entries in YAML are resolved by the middleware registry into parameters for the deepagents
`create_deep_agent()` function:

| YAML Middleware        | `create_deep_agent()` Parameter |
|------------------------|---------------------------------|
| `type: skills`         | `skills=["/path/"]`             |
| `type: memory`         | `memory=["/path/AGENTS.md"]`    |
| `type: hitl`           | `interrupt_on={...}`            |
| `type: todo_list`      | Always enabled by deepagents    |
| `type: filesystem`     | Always enabled by deepagents    |
| `type: summarization`  | Always enabled by deepagents    |
| `type: prompt_caching` | Always enabled by deepagents    |

Auto-enabled types don't need explicit config — they're always part of the deepagents middleware stack. Listing them in
YAML serves as documentation of what's active.

## Programmatic Access

```python
from agentflow.deep.core.middleware_registry import resolve_middleware
from agentflow.deep.core.config_models import MiddlewareEntry, MiddlewareType

entries = [
    MiddlewareEntry(type=MiddlewareType.MEMORY, config={"sources": [".deepagents/AGENTS.md"]}),
    MiddlewareEntry(type=MiddlewareType.SKILLS, config={"skills_dir": ".skills/"}),
]

params = resolve_middleware(entries)
# params.skills = ["/skills/"]
# params.memory = ["/.deepagents/AGENTS.md"]
# params.enabled_types = ["memory", "skills"]
```
