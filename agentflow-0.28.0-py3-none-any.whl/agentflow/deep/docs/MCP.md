# MCP Integration

AgentFlow Deep can connect to MCP (Model Context Protocol) servers to give agents access to external tools — file
systems, databases, APIs, and more.

## How It Works

1. MCP servers are declared in the YAML config under `mcp_servers`.
2. At build time, the builder connects to each server and discovers its tools.
3. MCP tools are converted to LangChain `StructuredTool` instances and added to the agent's tool set.
4. The agent can call MCP tools just like built-in tools.

## YAML Configuration

```yaml
mcp_servers:
  filesystem:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/dir"]

  github:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"

  web_search:
    transport: sse
    url: "http://localhost:3001/sse"
```

## Transport Types

### stdio

The MCP server runs as a subprocess. Communication happens over stdin/stdout.

```yaml
mcp_servers:
  my_server:
    transport: stdio
    command: npx                    # Command to start the server
    args: ["-y", "@mcp/server"]    # Arguments
    env:                            # Optional environment variables
      API_KEY: "${MY_API_KEY}"
```

| Field     | Required | Description                                  |
|-----------|----------|----------------------------------------------|
| `command` | Yes      | Command to start the server process          |
| `args`    | No       | List of arguments for the command            |
| `env`     | No       | Environment variables for the server process |

### sse

The MCP server is already running and exposes an SSE endpoint.

```yaml
mcp_servers:
  my_server:
    transport: sse
    url: "http://localhost:3001/sse"
```

| Field | Required | Description             |
|-------|----------|-------------------------|
| `url` | Yes      | URL of the SSE endpoint |

## Available MCP Servers

Common open-source MCP servers that work with AgentFlow Deep:

| Server       | Package                                     | Description                     |
|--------------|---------------------------------------------|---------------------------------|
| Filesystem   | `@modelcontextprotocol/server-filesystem`   | Read/write files in a directory |
| GitHub       | `@modelcontextprotocol/server-github`       | Issues, PRs, repos              |
| Brave Search | `@modelcontextprotocol/server-brave-search` | Web search                      |
| PostgreSQL   | `@modelcontextprotocol/server-postgres`     | Query databases                 |
| Slack        | `@modelcontextprotocol/server-slack`        | Send/read messages              |

Install with: `npx -y @modelcontextprotocol/server-<name>`

## Tool Discovery

When the builder connects to an MCP server, it calls `list_tools()` to discover available tools. Each MCP tool is
converted to a LangChain `StructuredTool` with:

- **Name**: The MCP tool name
- **Description**: The MCP tool description
- **Input schema**: Converted from JSON Schema to a Pydantic model

The conversion handles string, integer, number, boolean, array, and object types.

## Example: Agent with GitHub Access

```yaml
metadata:
  version: "1.0"
  name: "GitHub Agent"
  description: "Agent with GitHub integration"

agent:
  system_prompt: |
    You can interact with GitHub repositories using your tools.
    Create issues, review PRs, and search code.
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"

tools:
  builtin:
    - read_file
    - write_file
    - execute

mcp_servers:
  github:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"
```

## Lifecycle

MCP connections are managed by `MCPToolManager`:

1. **Connect**: Called during `builder.build()`. Connects to all servers, discovers tools.
2. **Use**: The agent uses MCP tools during execution.
3. **Close**: Called during `builder.close()`. Disconnects from all servers.

The `agentflow` CLI handles lifecycle automatically. For programmatic usage:

```python
builder = DeepAgentBuilder.from_yaml("agent.yaml")
agent = builder.build()     # Connects to MCP servers
# ... use agent ...
builder.close()             # Disconnects MCP servers
```

## Dry Run

`agentflow --dry-run` lists connected MCP servers without starting them:

```
  MCP Servers   github, filesystem
```

## Troubleshooting

**Server not connecting:**

- Check that the command is installed: `npx -y @modelcontextprotocol/server-<name> --help`
- Check environment variables are set correctly
- Check server logs (stderr output from stdio servers)

**Tools not appearing:**

- Verify the server exposes tools via `list_tools()`
- Check for import errors in the MCP SDK: `pip install mcp>=1.2.0`
