# AgentFlow Deep

**YAML-driven autonomous agents — the deep backend for AgentFlow, powered by DeepAgents.**

AgentFlow Deep (`agentflow`) lets you define autonomous agents in YAML — system prompts, tools, subagents,
middleware, and MCP servers — then run them from the command line with built-in persistence, telemetry, and a terminal
UI.

## What It Does

- **YAML = business logic.** Define your agent's personality, tools, and subagents in a single YAML file. Deployment
  concerns (persistence, telemetry) are configured externally via CLI flags or environment variables.
- **Autonomous execution.** Agents can read/write files, execute commands, plan with todo lists, delegate to subagents,
  and connect to external tools via MCP.
- **Built-in persistence.** SQLite (default), PostgreSQL, or in-memory checkpointing for conversation continuity.
- **OpenTelemetry tracing.** Auto-enabled from environment variables. View traces in Jaeger with nested spans for
  subagents and tool calls.
- **Terminal UI.** Rich TUI with todo panel, status panel, and streaming output. Or use plain CLI / interactive REPL.

## Quick Example

```yaml
# agent.yaml
metadata:
  version: "1.0"
  name: "My Agent"
  description: "A helpful coding assistant"

agent:
  system_prompt: |
    You are an expert Python developer.
    Use the todo list to track multi-step tasks.
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"

tools:
  builtin:
    - read_file
    - write_file
    - execute
    - write_todos
```

```bash
# One-shot task
agentflow --yaml agent.yaml "Refactor the database module to use connection pooling"

# Interactive conversation
agentflow --yaml agent.yaml --interactive

# Launch TUI
agentflow --yaml agent.yaml

# Validate config (no LLM calls)
agentflow --yaml agent.yaml --dry-run
```

## Architecture

```
┌────────────────────────────────────┐
│  agent.yaml (business logic)       │
│  - system_prompt, tools, subagents │
│  - middleware, mcp_servers         │
└──────────────┬─────────────────────┘
               │
     DeepAgentBuilder.from_yaml()
               │
               ▼
┌────────────────────────────────────┐
│  DeepAgentBuilder                  │
│  + checkpointer (deployment)       │
│  + backend (deployment)            │
│  → build() → LangGraph StateGraph  │
└──────────────┬─────────────────────┘
               │
               ▼
┌────────────────────────────────────┐
│  agentflow CLI / TUI               │
│  - stream_agent() with live output │
│  - telemetry spans (OTel)          │
│  - persistence (SQLite/Postgres)   │
└────────────────────────────────────┘
```

## Next Steps

- [Getting Started](GETTING_STARTED.md) — install, configure, and run your first agent
- [YAML Reference](YAML_REFERENCE.md) — complete schema for agent.yaml
- [CLI Reference](CLI_REFERENCE.md) — all command-line options
- [Subagents](SUBAGENTS.md) — delegate tasks to specialized subagents
- [Persistence](PERSISTENCE.md) — SQLite, PostgreSQL, and conversation continuity
- [Observability](TELEMETRY.md) — Tracing with Datadog, Azure Monitor, Grafana, Jaeger
