# LLM Providers

AgentFlow Deep supports multiple LLM providers. The provider is configured in the YAML `agent.llm` section.

## Supported Providers

| Provider     | Value          | Package                                            |
|--------------|----------------|----------------------------------------------------|
| OpenAI       | `openai`       | `langchain-openai` (included in `agentflow[deep]`) |
| Azure OpenAI | `azure_openai` | `langchain-openai` (included in `agentflow[deep]`) |
| Anthropic    | `anthropic`    | `langchain-anthropic` (install separately)         |
| Custom       | `custom`       | Varies                                             |

## OpenAI

```yaml
agent:
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"
      temperature: 0.0
      max_tokens: 16384
```

### Configuration

| Key           | Type   | Required | Description                                      |
|---------------|--------|----------|--------------------------------------------------|
| `model`       | string | Yes      | Model name (e.g., `gpt-4o`, `gpt-4o-mini`)       |
| `api_key`     | string | Yes      | OpenAI API key                                   |
| `base_url`    | string | No       | Custom base URL (for proxies or compatible APIs) |
| `temperature` | float  | No       | Sampling temperature (0.0-2.0)                   |
| `max_tokens`  | int    | No       | Maximum output tokens                            |
| `top_p`       | float  | No       | Nucleus sampling parameter                       |
| `timeout`     | int    | No       | Request timeout in seconds                       |
| `max_retries` | int    | No       | Maximum retries on failure (default: 2)          |

## Azure OpenAI

```yaml
agent:
  llm:
    provider: azure_openai
    config:
      model: "${AZURE_DEPLOYMENT}"
      azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
      api_version: "${OPENAI_API_VERSION}"
      azure_identity: true
      temperature: 0.0
      max_tokens: 16384
```

### Configuration

| Key                 | Type   | Required | Description                                                           |
|---------------------|--------|----------|-----------------------------------------------------------------------|
| `model`             | string | Yes      | Azure deployment name                                                 |
| `azure_endpoint`    | string | Yes      | Azure OpenAI endpoint URL                                             |
| `api_version`       | string | Yes      | API version (e.g., `2024-12-01-preview`)                              |
| `azure_identity`    | bool   | No       | Use Azure Managed Identity (DefaultAzureCredential)                   |
| `api_key`           | string | No       | API key (alternative to azure_identity)                               |
| `azure_oauth_scope` | string | No       | OAuth scope (default: `https://cognitiveservices.azure.com/.default`) |
| `temperature`       | float  | No       | Sampling temperature                                                  |
| `max_tokens`        | int    | No       | Maximum output tokens                                                 |
| `top_p`             | float  | No       | Nucleus sampling parameter                                            |
| `timeout`           | int    | No       | Request timeout in seconds                                            |
| `max_retries`       | int    | No       | Maximum retries (default: 2)                                          |

### Authentication

**API Key:**

```yaml
config:
  api_key: "${AZURE_OPENAI_API_KEY}"
```

**Managed Identity (recommended for production):**

```yaml
config:
  azure_identity: true
```

Uses `DefaultAzureCredential` from the `azure-identity` package (included in `agentflow[deep]`). Works with:

- Azure Managed Identity
- Azure CLI (`az login`)
- Environment variables (`AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, `AZURE_CLIENT_SECRET`)
- Visual Studio Code credentials

## Anthropic

```yaml
agent:
  llm:
    provider: anthropic
    config:
      model: claude-sonnet-4-20250514
      api_key: "${ANTHROPIC_API_KEY}"
      temperature: 0.0
      max_tokens: 16384
```

Requires: `pip install langchain-anthropic`

### Configuration

| Key           | Type   | Required | Description                                                                |
|---------------|--------|----------|----------------------------------------------------------------------------|
| `model`       | string | Yes      | Model name (e.g., `claude-sonnet-4-20250514`, `claude-haiku-4-5-20251001`) |
| `api_key`     | string | Yes      | Anthropic API key                                                          |
| `base_url`    | string | No       | Custom base URL                                                            |
| `temperature` | float  | No       | Sampling temperature                                                       |
| `max_tokens`  | int    | No       | Maximum output tokens                                                      |
| `top_p`       | float  | No       | Nucleus sampling parameter                                                 |
| `timeout`     | int    | No       | Request timeout in seconds                                                 |
| `max_retries` | int    | No       | Maximum retries (default: 2)                                               |

## Custom Provider

For providers not directly supported, use the `custom` provider. It returns a `provider:model` string that deepagents
resolves via `init_chat_model`.

```yaml
agent:
  llm:
    provider: custom
    config:
      provider: "google_genai"
      model: "gemini-2.0-flash"
```

This passes `"google_genai:gemini-2.0-flash"` to deepagents, which uses LangChain's `init_chat_model()` to resolve it.

## Environment Variable Expansion

All config values support `${ENV_VAR}` syntax:

```yaml
config:
  model: "${AZURE_DEPLOYMENT}"
  azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
  api_key: "${OPENAI_API_KEY}"
```

Variables are resolved from:

1. `.env` in the YAML file's directory
2. `.env` in the current working directory
3. System environment variables

## Programmatic Usage

```python
from agentflow.deep.core.config_models import LLMConfig, LLMProvider
from agentflow.deep.core.llm_factory import LLMFactory

# Create model from config
config = LLMConfig(
    provider=LLMProvider.OPENAI,
    config={"model": "gpt-4o", "api_key": "sk-..."},
)
model = LLMFactory.create_model(config)

# Display string for logging
display = LLMFactory.model_display_string(config)
# "openai:gpt-4o"
```
