# Custom Tools

Beyond built-in tools and MCP servers, you can add custom Python tools to your agent.

## YAML Configuration

```yaml
tools:
  builtin:
    - read_file
    - write_file
    - execute
  custom:
    - module: myproject.tools
      functions:
        - search_database
        - call_api
    - module: myproject.analytics
      functions:
        - run_query
```

| Field       | Type         | Description                                                        |
|-------------|--------------|--------------------------------------------------------------------|
| `module`    | string       | Python module path (must be importable from the working directory) |
| `functions` | list[string] | Function names to import and register as tools                     |

## Creating Custom Tools

Custom tools must be LangChain-compatible. The simplest way is the `@tool` decorator:

```python
# myproject/tools.py
from langchain_core.tools import tool

@tool
def search_database(query: str, limit: int = 10) -> str:
    """Search the database for relevant records.

    Args:
        query: Search query string.
        limit: Maximum number of results to return.
    """
    # Your implementation
    results = db.search(query, limit=limit)
    return "\n".join(str(r) for r in results)


@tool
def call_api(endpoint: str, method: str = "GET") -> str:
    """Call an external API endpoint.

    Args:
        endpoint: API endpoint URL.
        method: HTTP method (GET, POST, etc.).
    """
    import requests
    response = requests.request(method, endpoint)
    return response.text
```

### Key requirements:

1. **Docstring**: The tool's description shown to the LLM. Be specific about what it does and when to use it.
2. **Type hints**: Parameters must have type annotations. The LLM uses these to provide correct arguments.
3. **Return string**: Tools should return strings. The LLM reads the output as text.

## Using StructuredTool

For more control over the schema, use `StructuredTool`:

```python
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

class SearchInput(BaseModel):
    query: str = Field(description="Search query")
    filters: dict = Field(default_factory=dict, description="Optional filters")
    limit: int = Field(default=10, description="Max results")

def search_impl(query: str, filters: dict = None, limit: int = 10) -> str:
    # Implementation
    return "results"

search_tool = StructuredTool(
    name="search_database",
    description="Search the database with optional filters",
    func=search_impl,
    args_schema=SearchInput,
)
```

## Module Resolution

The `agentflow` CLI automatically adds the current working directory to `sys.path`. Your custom module must be
importable:

```
my-project/
├── agent.yaml
├── myproject/
│   ├── __init__.py
│   └── tools.py      # Contains search_database, call_api
└── .env
```

With `--workdir`, the working directory is also added:

```bash
agentflow --yaml agent.yaml --workdir ./src "Use custom tools"
```

## Built-in Tools Reference

| Tool          | Class Path                                  | Description              |
|---------------|---------------------------------------------|--------------------------|
| `read_file`   | `langchain_deepagents.tools.ReadFileTool`   | Read file contents       |
| `write_file`  | `langchain_deepagents.tools.WriteFileTool`  | Write/create files       |
| `edit_file`   | `langchain_deepagents.tools.EditFileTool`   | Patch-style file editing |
| `execute`     | `langchain_deepagents.tools.ExecuteTool`    | Execute shell commands   |
| `write_todos` | `langchain_deepagents.tools.WriteTodosTool` | Create/update todo lists |

These are included by default in deepagents. Listing them explicitly in `tools.builtin` is optional and serves as
documentation.
