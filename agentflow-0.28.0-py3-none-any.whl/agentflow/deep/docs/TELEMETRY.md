# Observability

AgentFlow Deep instruments agent execution with OpenTelemetry spans. Traces are
exported via OTLP to any compatible backend — Jaeger, Langfuse, Phoenix, Grafana
Tempo, Datadog, New Relic, Splunk, Honeycomb, and others.

Observability is a **deployment concern** — enabled via environment variables, not
in the agent YAML. When disabled, there is zero overhead.

## Quick Start

Add to your `.env`:

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-agent
```

Run your agent normally — traces flow to the configured backend.

## Backend Configuration

The OTEL SDK reads standard environment variables. Set `OTEL_EXPORTER_OTLP_ENDPOINT`
and optionally `OTEL_EXPORTER_OTLP_PROTOCOL` and `OTEL_EXPORTER_OTLP_HEADERS` to
target your chosen platform:

### Jaeger (gRPC)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

Start Jaeger: `docker run -d -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one:latest`
UI: http://localhost:16686

### Langfuse (HTTP + auth)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <base64(public_key:secret_key)>
```

### Phoenix by Arize (HTTP)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

Start Phoenix: `docker run -d -p 6006:6006 -p 4317:4317 arizephoenix/phoenix`

### Grafana Tempo (gRPC)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://tempo:4317
```

### Datadog (via Datadog Agent)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

### New Relic (HTTP + API key)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=https://otlp.nr-data.net
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=api-key=YOUR_LICENSE_KEY
```

### Honeycomb (HTTP + API key)

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=https://api.honeycomb.io
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=x-honeycomb-team=YOUR_API_KEY
```

## Environment Variables

| Variable                      | Description                     | Default                 |
|-------------------------------|---------------------------------|-------------------------|
| `OTEL_TRACES_ENABLED`         | Set to `true` to enable tracing | `false`                 |
| `OTEL_SERVICE_NAME`           | Service name shown in traces    | `deepagent`             |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | OTLP backend endpoint           | `http://localhost:4317` |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | `grpc` or `http/protobuf`       | `grpc`                  |
| `OTEL_EXPORTER_OTLP_HEADERS`  | Auth headers (`key=value`)      | (none)                  |

Telemetry is auto-enabled when `OTEL_TRACES_ENABLED=true`. No CLI flag needed.

## Azure Monitor / Application Insights (Azure AI Foundry)

Deep uses the shared, backend-agnostic **exporter seam**
(`agentflow.core.telemetry_seam`), so the built-in Azure Monitor exporter works
here exactly as it does for the workflows backend. Application Insights can't
ingest raw OTLP, so an `AzureMonitorTraceExporter` translates for it; installing
the extra and setting the connection string attaches it automatically —
**additively**, alongside any OTLP export (dual-export).

```bash
pip install 'agentflow[azure-monitor]'

# .env
OTEL_TRACES_ENABLED=true
APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=https://..."
```

No code changes: with the connection string unset, nothing Azure-related is
imported and the default path is unchanged. Spans appear in App Insights and, once
that resource is linked to a Foundry project, in the Foundry Tracing tab. (Rich
`gen_ai.*` rendering is a separate conformance effort.)

For an **Azure-only** deployment you don't need `OTEL_EXPORTER_OTLP_ENDPOINT` —
when it's unset and Azure is configured, the default OTLP sink is skipped, so you
won't see failed exports to `localhost:4317`. Set it only to **dual-export** to
another backend alongside Azure.

You can also attach any span processor in-process via
`agentflow.register_span_processor(...)`.

## What Gets Traced

Two layers work together, exactly like the workflows backend:

1. **LangSmith → OTel bridge (automatic).** DeepAgents runs on LangGraph, so
   enabling telemetry auto-instruments every LLM and tool call. Each model call
   gets a span carrying `gen_ai.request.model` and token usage
   (`gen_ai.usage.input_tokens` / `output_tokens` / `total_tokens`); each tool
   call gets a **properly-timed** span. No code changes.
2. **AgentFlow deep spans (structural).** Spans for what the bridge can't see:
   the top-level invocation and the subagent-delegation hierarchy.

### Top-Level Span

Each agent invocation creates a `deepagent.invoke` span:

| Attribute              | Description                               |
|------------------------|-------------------------------------------|
| `deepagent.thread_id`  | Conversation thread identifier            |
| `deepagent.query`      | Task given to the agent (first 200 chars) |
| `deepagent.duration_s` | Wall-clock execution time                 |
| `deepagent.status`     | `success` or `error`                      |

> Per-call token usage lives on the bridge's `gen_ai.usage.*` LLM spans. (The
> programmatic `DeepAgentTelemetry.invoke()` API additionally rolls up
> `llm.input_tokens` / `output_tokens` / `total_tokens` onto this span.)

### LLM & Tool Spans

Emitted by the bridge, with real durations and token usage:

| Span (example)   | Key attributes                                             |
|------------------|------------------------------------------------------------|
| model call       | `gen_ai.request.model`, `gen_ai.usage.*`                   |
| `read_file`      | tool name + I/O (timed)                                    |
| `write_file`     | tool name + I/O (timed)                                    |

> Earlier versions emitted zero-width `tool.*` / `task.*` marker spans
> reconstructed from the output stream (they always showed **duration 0**, since
> a tool had only been *requested* at that point). Those are gone — the bridge
> now provides real, timed tool spans instead.

### Subagent Spans

When the agent delegates to subagents, AgentFlow adds nested **structural** spans
with real durations that the bridge doesn't label:

```
deepagent.invoke
  ├── ChatAnthropic             # LLM span (gen_ai.usage.* tokens)
  ├── task                      # tool span (bridge, timed)
  │   └── subagent.researcher   # deep structural span
  │       ├── read_file         # tool span (bridge, timed)
  │       └── ChatAnthropic
  └── write_file                # tool span (bridge, timed)
```

Subagent spans include:

- `deepagent.subagent` — the subagent name (from `subagent_type`)
- `deepagent.depth` — nesting depth (0 = main agent)

## Trace Structure

A typical trace looks like:

```
Service: pharma-crisis-agent

deepagent.invoke [268.5s]
├── ChatAnthropic [3.1s]                gen_ai.usage.total_tokens=2,314
├── read_file [0.1s]                    data_room/alert.md
├── write_todos [0.05s]                 Planning: 4 items
├── subagent.impact_tracer [243.0s]     structural (deep)
│   ├── ChatAnthropic [5.2s]            gen_ai.usage.total_tokens=8,102
│   ├── read_file [0.1s]
│   └── read_file [0.1s]
├── subagent.supplier_analyst [243.0s]
│   ├── ChatAnthropic [4.8s]
│   └── read_file [0.1s]
└── write_file [0.1s]                   output/report.md
```

Tool and model spans (with timing + `gen_ai.usage.*` tokens) come from the
LangSmith bridge; `subagent.*` spans are AgentFlow's structural overlay.

## Data considerations

Deep enables the LangSmith → OTel bridge, which exports the **full prompt and
completion content** (`gen_ai.prompt` / `gen_ai.completion`) alongside the token
counts — the entire message history, system prompt, and tool schemas, often tens
of KB per span. Before pointing telemetry at a shared or long-retention backend
(including Application Insights / Foundry):

- **Redact at an OTel Collector** (its `attributes` / `redaction` processors) —
  the recommended path. It's configuration, not code, and it survives
  LangChain/LangSmith upgrades. AgentFlow intentionally ships **no in-process
  redactor** keyed on bridge attribute names, since those names can drift
  upstream and a stale drop-list would silently under-redact.
- **Restrict access and retention** to match your data's sensitivity, or leave
  `OTEL_TRACES_ENABLED` unset where content must not leave the process.

## Programmatic Usage

```python
from agentflow.deep.core.telemetry import DeepAgentTelemetry

# Initialize (reads env vars automatically)
telemetry = DeepAgentTelemetry()

# Option 1: Wrap with span context manager
with telemetry.span("deepagent.invoke", query="My task", thread_id="t-1") as span:
    # Stream or invoke agent here
    span.set_attribute("custom.key", "value")

# Option 2: Use invoke wrapper
result = telemetry.invoke(agent, {"messages": [...]}, config=config)

# Cleanup
telemetry.shutdown()
```

### `DeepAgentTelemetry` API

```python
class DeepAgentTelemetry:
    def __init__(
        self,
        service_name: str = None,      # Default: OTEL_SERVICE_NAME or "deepagent"
        service_version: str = "1.0.0",
        enabled: bool = True,           # Overridden by OTEL_TRACES_ENABLED
    ): ...

    def span(self, name, query="", thread_id="unknown"):
        """Context manager that wraps execution in an OTel span."""

    def invoke(self, agent, input_dict, config=None):
        """Invoke agent with automatic span + token tracking."""

    def shutdown(self):
        """Flush pending spans and shut down."""
```

### Properties

| Property       | Type   | Description                                      |
|----------------|--------|--------------------------------------------------|
| `enabled`      | bool   | Whether telemetry is active                      |
| `tracer`       | Tracer | OTel tracer instance (for creating manual spans) |
| `service_name` | str    | Configured service name                          |

## Architecture

```
┌──────────────────────┐     OTLP (gRPC      ┌───────────────────┐
│  agentflow CLI       │     or HTTP)         │  Any OTLP backend │
│  DeepAgentTelemetry  │ ──────────────────►  │  Jaeger, Langfuse,│
│  ├── TracerProvider  │                      │  Phoenix, Tempo,  │
│  ├── OTLPSpanExporter│                      │  Datadog, etc.    │
│  └── BatchProcessor  │                      └───────────────────┘
└──────────────────────┘
```

The telemetry module creates:

1. A `TracerProvider` with the service name as an OTel `Resource`
2. An `OTLPSpanExporter` configured by standard OTEL env vars (protocol, endpoint, headers)
3. A `BatchSpanProcessor` for efficient export
4. Context propagation so child spans nest correctly

## Log Level Control

Set `AGENTFLOW_LOG_LEVEL` in `.env` to control logging verbosity:

```bash
AGENTFLOW_LOG_LEVEL=DEBUG    # DEBUG, INFO, WARNING (default), ERROR
```

## Troubleshooting

**No traces appearing:**

1. Check `OTEL_TRACES_ENABLED=true` is in `.env`
2. Check the backend is running and accepting OTLP on the configured endpoint
3. Check the CLI output shows `Telemetry: enabled`
4. Look for `Failed to export span batch` errors — usually means wrong endpoint or auth

**401 Unauthorized:**

Your `OTEL_EXPORTER_OTLP_HEADERS` is missing or has wrong credentials.

**Service name is wrong:**

Set `OTEL_SERVICE_NAME` in `.env`. The default is `deepagent`.
