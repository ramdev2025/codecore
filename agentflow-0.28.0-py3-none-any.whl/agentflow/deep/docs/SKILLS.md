# Skills

Skills are reusable prompt templates stored as markdown files. They let the agent apply consistent patterns for repeated
tasks like testing, code review, or documentation.

## Directory Structure

```
.skills/
├── python-testing/
│   └── SKILL.md
├── code-review/
│   └── SKILL.md
└── documentation/
    └── SKILL.md
```

Each skill is a subdirectory under the skills root containing a `SKILL.md` file. The directory name becomes the skill
name.

## YAML Configuration

```yaml
middleware:
  - type: skills
    config:
      skills_dir: ".skills/"    # Default
```

The skills middleware scans the directory for subdirectories containing `SKILL.md` files and passes the source path to
`create_deep_agent(skills=[...])`.

## Creating a Skill

A skill is a `SKILL.md` file with instructions the agent can follow:

```markdown
# Python Testing

## When to Use
When writing or updating pytest tests for Python code.

## Instructions
1. Read the source file to understand the functions and classes
2. Create a test file in the `tests/` directory with the `test_` prefix
3. Write tests using pytest conventions:
   - Use `@pytest.fixture` for shared setup
   - Use `@pytest.mark.parametrize` for multiple inputs
   - Test edge cases: empty input, None, large values
   - Test error conditions with `pytest.raises`
4. Run the tests with `pytest -v` to verify they pass

## Template
```python
import pytest
from module_under_test import function_to_test

class TestFunctionName:
    def test_basic_case(self):
        result = function_to_test(normal_input)
        assert result == expected

    def test_edge_case(self):
        result = function_to_test(edge_input)
        assert result == expected

    def test_error_case(self):
        with pytest.raises(ValueError):
            function_to_test(invalid_input)
```

```

## How the Agent Uses Skills

When skills are configured, the agent can reference them during execution. DeepAgents injects skill definitions into the agent's context, allowing it to:

1. Recognize when a task matches a skill pattern
2. Follow the skill's instructions for consistent output
3. Apply the skill's templates and conventions

## Skill Discovery

The skills loader (`resolve_skills_from_config`) discovers skills by:

1. Scanning subdirectories under `skills_dir`
2. Checking each subdirectory for a `SKILL.md` file
3. Returning source paths in POSIX format with leading `/`

## Dry Run

`agentflow --dry-run` lists discovered skills:

```

Skills python-testing, code-review, documentation

```

## Programmatic Access

```python
from agentflow.deep.core.skills_loader import discover_skill_sources, list_skills

# Discover skill source paths
sources = discover_skill_sources(".skills/")
# ["/skills/"]

# List individual skills
skills = list_skills(".skills/")
# [{"name": "python-testing", "path": ".skills/python-testing/SKILL.md"}, ...]
```
