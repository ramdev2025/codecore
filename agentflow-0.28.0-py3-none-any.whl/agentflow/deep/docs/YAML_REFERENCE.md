# YAML Reference

Complete schema reference for AgentFlow Deep agent configuration files.

The YAML file defines **business logic only** — the agent's identity, tools, subagents, middleware, and MCP servers.
Deployment concerns (persistence, telemetry) are configured via CLI flags or environment variables.

## Top-Level Structure

```yaml
metadata:       # Required — version, name, description
agent:          # Required — system_prompt + LLM config
tools:          # Optional — built-in and custom tools
subagents:      # Optional — subagent delegation
middleware:     # Optional — memory, skills, HITL, etc.
mcp_servers:    # Optional — MCP server connections
```

## `metadata`

Agent metadata for identification and organization.

```yaml
metadata:
  version: "1.0"               # Required — schema version
  name: "My Agent"             # Optional — human-readable name
  description: "Does X and Y"  # Optional — description
  author: "team-name"          # Optional — author
  tags: # Optional — categorization tags
    - coding
    - python
```

| Field         | Type         | Required | Description                    |
|---------------|--------------|----------|--------------------------------|
| `version`     | string       | Yes      | Schema version (e.g., `"1.0"`) |
| `name`        | string       | No       | Human-readable agent name      |
| `description` | string       | No       | What this agent does           |
| `author`      | string       | No       | Author or team                 |
| `tags`        | list[string] | No       | Tags for categorization        |

## `agent`

Core agent configuration — the system prompt and LLM settings.

```yaml
agent:
  system_prompt: |
    You are an expert Python developer.
    Follow best practices and write clean code.
  llm:
    provider: azure_openai
    config:
      model: "${AZURE_DEPLOYMENT}"
      azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
      api_version: "${OPENAI_API_VERSION}"
      azure_identity: true
      temperature: 0.0
      max_tokens: 16384
```

| Field           | Type   | Required | Description                                                        |
|-----------------|--------|----------|--------------------------------------------------------------------|
| `system_prompt` | string | Yes      | Instructions defining the agent's behavior (must not be empty)     |
| `llm`           | object | Yes      | LLM provider and configuration                                     |
| `llm.provider`  | enum   | Yes      | One of: `openai`, `azure_openai`, `anthropic`, `custom`            |
| `llm.config`    | dict   | Yes      | Provider-specific settings (see [LLM Providers](LLM_PROVIDERS.md)) |

### Environment Variable Expansion

All string values in the YAML support `${ENV_VAR}` syntax. Variables are resolved from:

1. The `.env` file in the YAML file's directory
2. The `.env` file in the current working directory
3. System environment variables

```yaml
config:
  model: "${AZURE_DEPLOYMENT}"          # Expanded at load time
  azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
  api_key: "${OPENAI_API_KEY}"
```

## `tools`

Tools available to the agent. DeepAgents includes its standard tools by default; this section lets you explicitly list
built-in tools or add custom ones.

```yaml
tools:
  builtin:
    - read_file
    - write_file
    - edit_file
    - execute
    - write_todos
  custom:
    - module: myproject.tools
      functions:
        - search_database
        - call_api
```

### Built-in Tools

| Tool          | Description                            |
|---------------|----------------------------------------|
| `read_file`   | Read file contents                     |
| `write_file`  | Write/create files                     |
| `edit_file`   | Edit existing files (patch-style)      |
| `execute`     | Execute shell commands                 |
| `write_todos` | Create/update a todo list for planning |

### Custom Tools

Custom tools are Python functions imported from your modules. They must be LangChain-compatible tools (decorated with
`@tool` or subclassing `BaseTool`).

```yaml
tools:
  custom:
    - module: myproject.tools
      functions:
        - search_database
        - call_api
```

```python
# myproject/tools.py
from langchain_core.tools import tool


@tool
def search_database(query: str) -> str:
    """Search the database for relevant records."""
    # Your implementation
    return results
```

The module must be importable from the working directory. The `agentflow` CLI adds `cwd` to `sys.path`
automatically.

## `subagents`

Configure subagent delegation. When enabled, the main agent gets a `task` tool that lets it spawn specialized subagents.

```yaml
subagents:
  enabled: true
  max_depth: 2
  agents:
    - name: researcher
      description: "Researches topics by reading files and searching"
      system_prompt: |
        You are a research analyst. Read the provided files,
        extract key information, and summarize findings.
    - name: test_writer
      description: "Writes comprehensive pytest tests"
      system_prompt: |
        You write pytest tests. Use fixtures, parametrize,
        and aim for high coverage.
      model: "openai:gpt-4o-mini"  # Optional: override model
```

| Field       | Type | Default | Description                    |
|-------------|------|---------|--------------------------------|
| `enabled`   | bool | `false` | Enable subagent spawning       |
| `max_depth` | int  | `3`     | Maximum recursion depth (1-10) |
| `agents`    | list | `null`  | Named subagent specifications  |

### Subagent Specification

| Field           | Type   | Required | Description                                                      |
|-----------------|--------|----------|------------------------------------------------------------------|
| `name`          | string | Yes      | Unique identifier (used in `task` tool calls)                    |
| `description`   | string | Yes      | What this subagent does (used by the agent to decide delegation) |
| `system_prompt` | string | Yes      | Instructions for the subagent                                    |
| `model`         | string | No       | Override the main agent's model (e.g., `"openai:gpt-4o-mini"`)   |

See [Subagents](SUBAGENTS.md) for detailed usage patterns.

## `middleware`

Ordered list of middleware to apply. Middleware configures agent capabilities like memory, skills, and
human-in-the-loop.

```yaml
middleware:
  - type: todo_list
  - type: memory
    config:
      sources:
        - ".deepagents/AGENTS.md"
  - type: skills
    config:
      skills_dir: ".skills/"
  - type: filesystem
  - type: summarization
  - type: prompt_caching
  - type: hitl
    config:
      interrupt_on:
        tools: [ "write_file", "execute" ]
```

### Middleware Types

| Type             | Config                  | Description                                                                                   |
|------------------|-------------------------|-----------------------------------------------------------------------------------------------|
| `todo_list`      | None                    | Todo list for planning (auto-enabled by deepagents)                                           |
| `memory`         | `sources: [path, ...]`  | Inject markdown files into system prompt                                                      |
| `skills`         | `skills_dir: path`      | Load skill definitions from SKILL.md files                                                    |
| `filesystem`     | `read_file_cache: bool` | File system access (auto-enabled by deepagents). Cache prevents read loops (default: `true`). |
| `summarization`  | None                    | Context summarization (auto-enabled by deepagents)                                            |
| `prompt_caching` | None                    | Prompt caching (auto-enabled by deepagents)                                                   |
| `hitl`           | `interrupt_on: {...}`   | Human-in-the-loop — pause before specific tools                                               |

Auto-enabled types (`todo_list`, `filesystem`, `summarization`, `prompt_caching`) are always active in deepagents.
Listing them in YAML is declarative documentation — they don't need config.

See [Middleware](MIDDLEWARE.md) for detailed configuration.

## `mcp_servers`

Connect to MCP (Model Context Protocol) servers for additional tools.

```yaml
mcp_servers:
  filesystem:
    transport: stdio
    command: npx
    args: [ "-y", "@modelcontextprotocol/server-filesystem", "/path/to/dir" ]
  web_search:
    transport: sse
    url: "http://localhost:3001/sse"
  github:
    transport: stdio
    command: npx
    args: [ "-y", "@modelcontextprotocol/server-github" ]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"
```

### Server Configuration

| Field       | Type         | Default   | Description                                  |
|-------------|--------------|-----------|----------------------------------------------|
| `transport` | string       | `"stdio"` | Transport type: `stdio` or `sse`             |
| `command`   | string       | —         | Command to start the server (stdio only)     |
| `args`      | list[string] | —         | Arguments for the command (stdio only)       |
| `url`       | string       | —         | Server URL (sse only)                        |
| `env`       | dict         | —         | Environment variables for the server process |

See [MCP Integration](MCP.md) for details.

## Complete Example

```yaml
metadata:
  version: "1.0"
  name: "Full-Featured Agent"
  description: "Production-ready autonomous agent with all features"
  tags: [ coding, python ]

agent:
  system_prompt: |
    You are an expert Python developer working on a production codebase.
    Follow best practices: type hints, tests, clear documentation.
    Use the todo list to track multi-step tasks.
    Leverage your skills library for repeated patterns.
  llm:
    provider: azure_openai
    config:
      model: "${AZURE_DEPLOYMENT}"
      azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
      api_version: "${OPENAI_API_VERSION}"
      azure_identity: true
      temperature: 0.0
      max_tokens: 16384

tools:
  builtin:
    - read_file
    - write_file
    - edit_file
    - execute
    - write_todos

subagents:
  enabled: true
  max_depth: 2
  agents:
    - name: test_writer
      description: "Writes pytest tests for Python code"
      system_prompt: |
        You are a testing specialist. Write comprehensive pytest tests.
    - name: reviewer
      description: "Reviews code for quality and security"
      system_prompt: |
        You are a senior code reviewer. Check for bugs and security issues.

middleware:
  - type: todo_list
  - type: memory
    config:
      sources:
        - ".deepagents/AGENTS.md"
  - type: skills
    config:
      skills_dir: ".skills/"
  - type: filesystem
  - type: summarization
  - type: prompt_caching

mcp_servers:
  github:
    transport: stdio
    command: npx
    args: [ "-y", "@modelcontextprotocol/server-github" ]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"
```
