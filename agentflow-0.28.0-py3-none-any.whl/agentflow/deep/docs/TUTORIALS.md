# AgentFlow Deep Tutorials

A hands-on guide to building autonomous agents with AgentFlow Deep.

---

## Table of Contents

1. [Getting Started](#1-getting-started)
2. [Subagent Delegation](#2-subagent-delegation)
3. [Persistence & Conversation Continuity](#3-persistence--conversation-continuity)
4. [OpenTelemetry Tracing](#4-opentelemetry-tracing)
5. [Memory & Skills](#5-memory--skills)
6. [MCP Integration](#6-mcp-integration)
7. [Custom Tools](#7-custom-tools)

---

# 1. Getting Started

## Introduction

In this tutorial, you'll create an autonomous coding agent that can read files, write code, execute commands, and plan
multi-step tasks — all configured in a single YAML file.

By the end, you'll have:

- A working agent running from the command line
- Familiarity with the YAML config structure
- An agent that can interact with your filesystem

---

## What is AgentFlow Deep?

AgentFlow Deep is a YAML-driven framework for building autonomous agents. It wraps the DeepAgents library and LangGraph
to provide:

- **YAML = business logic.** Define the agent's identity, tools, and subagents in YAML. Deployment concerns (
  persistence, telemetry) stay external.
- **Autonomous execution.** Agents plan with todo lists, read/write files, run commands, and delegate to subagents.
- **Built-in CLI and TUI.** Run agents from the terminal with live streaming output.

---

## Prerequisites

- Python 3.11 or higher
- An LLM API key (OpenAI or Azure OpenAI)

---

## Step 1: Install

```bash
pip install agentflow[deep]
```

Verify:

```bash
agentflow --help
```

### Getting Help

AgentFlow Deep includes a documentation server:

```bash
agentflow docs

# Custom port
agentflow docs --dev-addr 0.0.0.0:8080
```

Open http://localhost:9100 to browse the full documentation.

---

## Step 2: Create Your Project

Create a directory with two files:

```
my-agent/
├── agent.yaml
└── .env
```

### `.env`

=== "OpenAI"

    ```
    OPENAI_API_KEY=sk-...
    ```

=== "Azure OpenAI"

    ```
    AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
    AZURE_DEPLOYMENT=your-deployment-name
    OPENAI_API_VERSION=2024-12-01-preview
    ```

### `agent.yaml`

```yaml
metadata:
  version: "1.0"
  name: "Coding Assistant"
  description: "An autonomous agent that can read, write, and execute code"

agent:
  system_prompt: |
    You are a helpful coding assistant. You can read and write files,
    execute shell commands, and plan multi-step work using todo lists.
    Always explain what you're doing before taking action.
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"
      temperature: 0.0

tools:
  builtin:
    - read_file
    - write_file
    - execute
    - write_todos
```

The `${OPENAI_API_KEY}` syntax expands environment variables from `.env` automatically.

---

## Step 3: Validate

Before making any LLM calls, validate the config:

```bash
agentflow --yaml agent.yaml --dry-run
```

You'll see a summary of your agent's configuration — LLM provider, tools, middleware — confirming everything is wired
correctly.

---

## Step 4: Run

### One-shot task

```bash
agentflow --yaml agent.yaml "Create a Python function that checks if a number is prime, save it to prime.py, and test it"
```

The agent will:

1. Plan the task (using `write_todos`)
2. Write `prime.py` (using `write_file`)
3. Run tests (using `execute`)
4. Report results

### Interactive REPL

```bash
agentflow --yaml agent.yaml --interactive
```

Type tasks at the prompt. The agent remembers the conversation. Type `quit` to exit.

### TUI (Terminal UI)

```bash
agentflow --yaml agent.yaml
```

Launches a rich terminal interface with panels for agent output, todo list, and status.

---

## What's Happening Under the Hood

1. `agentflow` loads `.env`, parses `agent.yaml`, and validates the config with Pydantic
2. A SQLite checkpointer is created at `.agentflow/deep_checkpoints.db` (default)
3. The `DeepAgentBuilder` creates an LLM instance, resolves tools, and compiles a LangGraph StateGraph
4. The agent streams execution — you see tool calls and responses in real time

---

# 2. Subagent Delegation

## Introduction

A single agent can get overwhelmed by complex tasks. Subagents let the main agent delegate specialized work to child
agents, each with their own system prompt and context window.

In this tutorial, you'll build an agent that delegates code analysis to a researcher and test writing to a specialist.

---

## Step 1: Define Subagents in YAML

```yaml
metadata:
  version: "1.0"
  name: "Team Lead Agent"
  description: "Delegates to specialist subagents"

agent:
  system_prompt: |
    You are a senior developer leading a small team. You can delegate tasks
    to your specialists:
    - Use the researcher for reading and analyzing code
    - Use the test_writer for creating tests

    Read the user's request, break it into subtasks, and delegate
    appropriately. Synthesize the results into a final response.
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"
      temperature: 0.0

tools:
  builtin:
    - read_file
    - write_file
    - execute
    - write_todos

subagents:
  enabled: true
  max_depth: 2
  agents:
    - name: researcher
      description: >
        Code analyst that reads source files, traces dependencies,
        and summarizes architecture. Use for understanding code.
      system_prompt: |
        You are a code analyst. Read the requested files, understand
        the architecture, and provide a structured summary including:
        - Key classes and functions
        - Dependencies between modules
        - Patterns and conventions used

    - name: test_writer
      description: >
        Testing specialist that writes comprehensive pytest tests.
        Use when tests need to be created or updated.
      system_prompt: |
        You write pytest tests. For each module:
        1. Read the source to understand the interface
        2. Write tests covering happy paths, edge cases, and errors
        3. Use fixtures and parametrize where appropriate
        4. Save tests to the tests/ directory
```

---

## Step 2: Run

```bash
agentflow --yaml agent.yaml "Analyze src/utils.py and write comprehensive tests for it"
```

The main agent will:

1. Delegate analysis to the `researcher` subagent
2. Receive the analysis summary
3. Delegate test writing to the `test_writer` subagent
4. Synthesize results and report back

In the terminal output, you'll see subagent activity indented:

```
>>> Analyze src/utils.py and write comprehensive tests for it

  Planning:
    ☐ Analyze src/utils.py with researcher
    ☐ Write tests with test_writer
  Subagent: Analyze the code in src/utils.py
    Reading: src/utils.py

  ┌─ Subagent ─────────────────────────────────────┐
  │ src/utils.py contains 3 functions: ...         │
  └────────────────────────────────────────────────┘

  Subagent: Write pytest tests for src/utils.py
    Writing: tests/test_utils.py

┌─ Agent ──────────────────────────────────────────┐
│ Analysis complete. Created tests/test_utils.py   │
│ with 12 test cases covering ...                  │
└──────────────────────────────────────────────────┘
```

---

## Key Points

- **`name`** — unique identifier the agent uses in `task(subagent_type="researcher")`
- **`description`** — the main agent reads this to decide when to delegate. Be specific.
- **`system_prompt`** — self-contained instructions. Subagents don't see the main agent's prompt.
- **`model`** — optional override. Use cheaper models for simple subtasks:

```yaml
    - name: summarizer
      description: "Summarizes long documents"
      system_prompt: "..."
      model: "openai:gpt-4o-mini"
```

---

# 3. Persistence & Conversation Continuity

## Introduction

Persistence lets the agent remember previous conversations. You can stop a session, come back later, and resume where
you left off.

---

## SQLite (Default)

SQLite persistence works out of the box. No configuration needed:

```bash
# First session
agentflow --yaml agent.yaml --thread-id project-001 "Read the codebase and summarize the architecture"

# Later — resume the same conversation
agentflow --yaml agent.yaml --thread-id project-001 "Now refactor the auth module based on your analysis"
```

The agent remembers its previous analysis because both runs share the same `--thread-id`.

Checkpoints are stored at `.agentflow/deep_checkpoints.db` by default. Customize with:

```bash
agentflow --yaml agent.yaml --db-path ./checkpoints/my-agent.db "Your task"
```

Or via `.env`:

```
CHECKPOINTER_DB_PATH=./checkpoints/my-agent.db
```

---

## PostgreSQL

For production or multi-user setups:

```bash
pip install agentflow[postgres]
```

Add to `.env`:

```
POSTGRES_CONNECTION_STRING=postgresql://user:pass@localhost/mydb
```

Then:

```bash
agentflow --yaml agent.yaml --persistence postgres --thread-id session-001 "Your task"
```

The schema is created automatically on first use.

---

## In-Memory / Stateless

For one-off tasks where you don't need persistence:

```bash
# In-memory (state exists during the session only)
agentflow --yaml agent.yaml --persistence memory "Quick question"

# No checkpointer at all
agentflow --yaml agent.yaml --no-checkpointer "One-off task"
```

---

## Interactive Mode with Persistence

Combine `--interactive` with `--thread-id` for persistent conversations:

```bash
agentflow --yaml agent.yaml --interactive --thread-id my-project

# Session 1:
Task: Read the codebase structure
# ...agent analyzes files...

Task: quit

# Session 2 (days later):
agentflow --yaml agent.yaml --interactive --thread-id my-project
Task: Based on your earlier analysis, add error handling to the API routes
# Agent remembers the codebase analysis from session 1
```

---

# 4. OpenTelemetry Tracing

## Introduction

Telemetry lets you visualize agent execution as a trace — see every tool call, subagent delegation, and timing in a
flame graph. Traces export to any OTLP-compatible backend (Jaeger, Langfuse, Phoenix, Grafana Tempo, Datadog, New Relic,
etc.).

---

## Step 1: Start a Tracing Backend

Pick any OTLP backend. Examples:

```bash
# Jaeger (gRPC)
docker run -d --name jaeger -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one:latest

# Phoenix by Arize (HTTP — GenAI-native UI)
docker run -d --name phoenix -p 6006:6006 -p 4317:4317 arizephoenix/phoenix
```

---

## Step 2: Enable Telemetry

Add to `.env`:

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

That's it — no YAML changes, no CLI flags. Telemetry is auto-enabled when `OTEL_TRACES_ENABLED=true`.

For HTTP backends (Langfuse, Phoenix, New Relic), add protocol and auth:

```bash
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <credentials>
```

See [TELEMETRY.md](docs/TELEMETRY.md) for all backend configurations.

---

## Step 3: Run and View Traces

```bash
agentflow --yaml agent.yaml "Analyze src/ and write a summary to output/analysis.md"
```

Open your backend's UI (Jaeger: http://localhost:16686, Phoenix: http://localhost:6006), select your service, and find
traces.

Each trace shows a hierarchy:

```
deepagent.invoke [12.4s]
  ├── tool.read_file [0.1s]        file: src/main.py
  ├── tool.write_todos [0.05s]     Planning: 3 items
  ├── task.researcher [6.2s]       Analyze source code
  │   └── subagent.researcher [6.0s]
  │       ├── tool.read_file [0.1s]
  │       ├── tool.read_file [0.1s]
  │       └── tool.read_file [0.1s]
  ├── tool.write_todos [0.05s]     Updated plan
  └── tool.write_file [0.1s]       file: output/analysis.md
```

### Span Attributes

Click any span to see attributes:

- `deepagent.thread_id` — conversation thread
- `deepagent.query` — the task (first 200 chars)
- `deepagent.duration_s` — execution time
- `deepagent.subagent` — subagent name (on task/subagent spans)
- `deepagent.file` — file path (on file tool spans)

---

# 5. Memory & Skills

## Introduction

Memory injects project context into the agent's system prompt. Skills provide reusable templates for repeated tasks.
Together, they make the agent aware of your project's conventions.

---

## Memory

Create `.deepagents/AGENTS.md` in your project:

```markdown
# Project: E-Commerce API

## Tech Stack
- Python 3.12, FastAPI, SQLAlchemy 2.0
- PostgreSQL 16, Redis for caching
- pytest + httpx for testing

## Code Conventions
- All routes in `src/api/routes/`
- Models in `src/models/`
- Business logic in `src/services/`
- Always use Pydantic v2 for validation
- Type hints on all public functions

## Active Work
- Migrating from sync to async database access
- Adding OpenAPI schema validation
```

Reference it in YAML:

```yaml
middleware:
  - type: memory
    config:
      sources:
        - ".deepagents/AGENTS.md"
```

Now every interaction — the agent knows your tech stack, conventions, and current priorities. It won't suggest Flask
patterns in a FastAPI project or sync code during an async migration.

---

## Skills

Create reusable templates under `.skills/`:

```
.skills/
├── api-endpoint/
│   └── SKILL.md
└── pytest/
    └── SKILL.md
```

**`.skills/pytest/SKILL.md`:**

```markdown
# Pytest Testing

## When to Use
When writing or updating tests for Python modules.

## Instructions
1. Read the source file to understand the public interface
2. Create a test file in `tests/` matching the module name
3. Follow these patterns:
   - `@pytest.fixture` for shared setup (db sessions, test clients)
   - `@pytest.mark.parametrize` for input variations
   - `pytest.raises` for error cases
   - `httpx.AsyncClient` for API endpoint tests
4. Run `pytest -v` to verify
```

Reference in YAML:

```yaml
middleware:
  - type: memory
    config:
      sources:
        - ".deepagents/AGENTS.md"
  - type: skills
    config:
      skills_dir: ".skills/"
```

The agent can now apply consistent patterns when writing tests, creating endpoints, etc.

---

# 6. MCP Integration

## Introduction

MCP (Model Context Protocol) lets agents connect to external tool servers — giving them access to GitHub, databases, web
search, and more without writing custom code.

---

## Step 1: Add MCP Servers to YAML

```yaml
mcp_servers:
  filesystem:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]

  github:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"
```

---

## Step 2: Run

```bash
agentflow --yaml agent.yaml "List all open issues in our repo and create a summary"
```

The agent now has access to GitHub tools (list issues, create PRs, search code) alongside its built-in tools. MCP tools
appear in `--dry-run` output:

```bash
agentflow --yaml agent.yaml --dry-run
# ...
#   MCP Servers   filesystem, github
```

---

## Transport Types

**stdio** — server runs as a subprocess:

```yaml
my_server:
  transport: stdio
  command: npx
  args: ["-y", "@modelcontextprotocol/server-postgres"]
  env:
    DATABASE_URL: "${DATABASE_URL}"
```

**sse** — server already running at a URL:

```yaml
my_server:
  transport: sse
  url: "http://localhost:3001/sse"
```

---

## Common MCP Servers

| Package                                     | What It Does                    |
|---------------------------------------------|---------------------------------|
| `@modelcontextprotocol/server-filesystem`   | Read/write files in a directory |
| `@modelcontextprotocol/server-github`       | GitHub issues, PRs, repos       |
| `@modelcontextprotocol/server-brave-search` | Web search via Brave            |
| `@modelcontextprotocol/server-postgres`     | Query PostgreSQL databases      |
| `@modelcontextprotocol/server-slack`        | Slack messages and channels     |

---

# 7. Custom Tools

## Introduction

When built-in tools and MCP servers aren't enough, write custom Python tools. This tutorial shows how to add a database
search tool and a notification tool.

---

## Step 1: Create Tool Functions

Create `tools.py` in your project:

```python
from langchain_core.tools import tool

@tool
def search_tickets(query: str, status: str = "open") -> str:
    """Search support tickets by keyword and status.

    Args:
        query: Search keywords.
        status: Ticket status filter — open, closed, or all.
    """
    # In production, this would query your ticket system
    tickets = [
        {"id": "T-101", "title": "Login timeout", "status": "open"},
        {"id": "T-102", "title": "Payment failed", "status": "open"},
        {"id": "T-103", "title": "Login CSS broken", "status": "closed"},
    ]
    filtered = [t for t in tickets if status == "all" or t["status"] == status]
    matches = [t for t in filtered if query.lower() in t["title"].lower()]
    if not matches:
        return "No tickets found."
    return "\n".join(f"{t['id']}: {t['title']} ({t['status']})" for t in matches)


@tool
def send_notification(channel: str, message: str) -> str:
    """Send a notification to a team channel.

    Args:
        channel: Channel name (e.g., engineering, support).
        message: Notification message text.
    """
    # In production, this would call Slack/Teams/etc.
    return f"Notification sent to #{channel}: {message}"
```

**Key requirements:**

- Use the `@tool` decorator from `langchain_core.tools`
- Add **type hints** — the LLM uses these to provide correct arguments
- Write a **clear docstring** — this is what the LLM sees as the tool description
- **Return a string** — the LLM reads tool output as text

---

## Step 2: Reference in YAML

```yaml
metadata:
  version: "1.0"
  name: "Support Agent"
  description: "Agent with custom ticket search and notification tools"

agent:
  system_prompt: |
    You are a support team assistant. You can search tickets
    and send notifications to team channels.
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"

tools:
  builtin:
    - read_file
    - execute
  custom:
    - module: tools
      functions:
        - search_tickets
        - send_notification
```

---

## Step 3: Run

```bash
agentflow --yaml agent.yaml "Find all open login-related tickets and notify the engineering channel"
```

The agent uses `search_tickets` to find matches, then `send_notification` to alert the team.

---

## Module Resolution

The `agentflow` CLI adds the current working directory to `sys.path`, so `tools` resolves to `./tools.py`. For
packages:

```
my-project/
├── agent.yaml
├── mypackage/
│   ├── __init__.py
│   └── tools.py
└── .env
```

```yaml
tools:
  custom:
    - module: mypackage.tools
      functions:
        - search_tickets
```

---

# What's Next

- Read the [YAML Reference](docs/YAML_REFERENCE.md) for every configuration option
- Read the [CLI Reference](docs/CLI_REFERENCE.md) for all command-line flags
- Browse the full docs with `agentflow docs`
