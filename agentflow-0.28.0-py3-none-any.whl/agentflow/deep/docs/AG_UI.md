# AG-UI Integration Guide

AgentFlow ships a native integration with the [**AG-UI protocol**](https://docs.ag-ui.com/) — the open event-protocol for streaming agent runs to a frontend in real time. Pair it with [CopilotKit](https://copilotkit.ai) (or any AG-UI client) and your agent's tool calls become typed React components in the user's UI as they happen.

## What this enables

Picture a sales analyst typing *"how did we do last month by region, and flag anything off-target."* Behind the scenes, the agent picks two tools — one to fetch the regional figures, one to draw a chart — and writes a short commentary. With AG-UI carrying the conversation, the analyst sees a chart card pop up as a skeleton the instant the chart tool starts, the agent's commentary streams in word by word above it, the skeleton fills with real numbers as the data tool returns, and when the agent notices the Midwest is under target it pauses with a small "Flag Midwest for review?" approval card.

Tools say *what* the agent can do; AG-UI defines *how* the work flows between agent and UI in real time — placeholders, streaming text and props, two-way approvals, reconnection — so the same frontend can talk to any agent framework that speaks the protocol.

## Overview

The integration has two halves:

1. **`@ui_component` — a decorator on the backend** that pairs a Pydantic *component schema* with a *fetcher function*. The fetcher IS the tool the agent calls; the schema declares the props the React component on the other side expects. AgentFlow validates each return value against the schema before it ever reaches the wire.
2. **`build_agui` — a FastAPI router + lifespan** that exposes the agent over AG-UI's HTTP+SSE and WebSocket transports, plus a `/components` endpoint serving the JSON Schema registry so the frontend can introspect what's renderable.

Install from the AgentFlow wheel with the `deep` and `ui` extras (AgentFlow is not published to PyPI; install directly from the wheel file your team distributes):

```bash
pip install "./agentflow-<version>-py3-none-any.whl[deep,ui]"
```

In a `requirements.txt`:

```text
./agentflow-<version>-py3-none-any.whl[deep,ui]
```

The `[ui]` extra pulls `fastapi[standard]` and `websockets`; `[deep]` pulls the DeepAgents + LangChain / LangGraph runtime.

## Quick Start

### 1. Declare components in Python

```python
# components.py
from pydantic import BaseModel
from agentflow.genui import ui_component


class WeatherCard(BaseModel):
    """Props the React WeatherCard expects."""
    city: str
    temperature_f: float
    condition: str  # "sunny" | "cloudy" | "rain"


@ui_component(WeatherCard)
def weather_card(city: str) -> WeatherCard:
    """Look up current conditions for ``city`` and render a weather card."""
    # ... fetch from your weather API ...
    return WeatherCard(city=city, temperature_f=72.3, condition="sunny")
```

The function `weather_card` is now both a tool the agent can call AND a guarantee that a `WeatherCard`-shaped payload reaches the frontend.

### 2. Reference them in workflow.yaml

```yaml
metadata:
  version: "1.0"
  name: weather-copilot

llm:
  provider: openai
  config:
    model: gpt-4o

agent:
  name: assistant
  system_prompt: "Use the weather tools to answer questions."
  ui_tools:
    module: components
    use: [WeatherCard]
```

The `ui_tools` block tells AgentFlow which module to discover `@ui_component`-decorated functions in and (optionally) which ones to expose for this agent.

### 3. Mount the router

```python
# app.py
from fastapi import FastAPI
from agentflow.deep.agui import build_agui

router, lifespan = build_agui(yaml_path="workflow.yaml")

app = FastAPI(lifespan=lifespan)
app.include_router(router, prefix="/agui")
```

That's the entire backend. AgentFlow owns:

- The agent runtime (LangGraph under the hood, declared in `workflow.yaml`)
- Component-schema validation on every tool return
- The AG-UI event stream (`POST /agui/`)
- The convenience WebSocket (`WS /agui/{thread_id}`)
- The component-schema registry (`GET /agui/components`)

Run it with any ASGI server:

```bash
uvicorn app:app --port 8000
```

## The `@ui_component` Pattern

`@ui_component(ClassName)` turns a function into a tool. Two things happen on registration:

1. **The function's name becomes the tool name** the LLM sees.
2. **The Pydantic class becomes the contract** — the return value is validated, and on success the AG-UI event carries the validated props.

```python
class PositionDetail(BaseModel):
    symbol: str
    name: str
    shares: int
    price: float
    sparkline: list[float]


@ui_component(PositionDetail)
def position_detail(symbol: str) -> PositionDetail:
    """Detailed view of a single holding — price, shares, 30-day sparkline.
    Use for 'tell me about NVDA' / 'deep dive on Lilly'."""
    ...
```

The function's docstring becomes the tool description the LLM uses to decide when to call it. Argument types become the LLM's parameter schema.

### Error handling

If the fetcher raises an exception, AgentFlow catches it, packages the error as a `ToolError` component, and continues the run. The frontend can register a renderer for `ToolError` and show a clean error card in the slot it was waiting on — the whole run does not abort.

```python
@ui_component(PositionDetail)
def position_detail(symbol: str) -> PositionDetail:
    sym = symbol.upper()
    for p in POSITIONS:
        if p["symbol"] == sym:
            return PositionDetail(**p)
    raise ValueError(f"Position {sym} not held in fund.")
```

A user query like "tell me about TSLA" (not held) results in a `ToolError` component carrying `{tool: "PositionDetail", message: "ValueError: Position TSLA not held in fund."}`.

## The `ui_tools:` YAML block

```yaml
agent:
  ui_tools:
    module: my_app.components       # Python module to discover @ui_component decorators in
    use: [Card, WeatherCard]        # Optional whitelist; omit to expose all discovered components
```

- **`module`** — required. Any importable Python module. AgentFlow walks its members and registers every function decorated with `@ui_component`.
- **`use`** — optional. A list of component class names. When set, only those components are exposed to the agent. Useful when one module ships many components but a particular agent should only see a subset.

## The Router API

`build_agui(yaml_path, tools_module=None)` returns a `(router, lifespan)` pair. Wire both into your FastAPI app:

```python
router, lifespan = build_agui(yaml_path="workflow.yaml")
app = FastAPI(lifespan=lifespan)
app.include_router(router, prefix="/agui")
```

The lifespan brings the orchestrator up at app startup and tears it down on shutdown. **Endpoints raise `RuntimeError` if called before the lifespan has run** — this is intentional so that a deployment which forgets to pass `lifespan=lifespan` to `FastAPI(...)` fails loudly instead of silently leaking orchestrator state.

### Endpoints

| Endpoint | Purpose |
| --- | --- |
| `POST /` | AG-UI HTTP+SSE transport. Body is a `RunAgentInput` (`threadId`, `runId`, `messages`); response is `text/event-stream` with one AG-UI event per SSE `data:` frame. This is what CopilotKit's `HttpAgent` (and any AG-UI client) speaks. |
| `WS /{thread_id}` | Bidirectional convenience WebSocket. Client frames are `{type: 'user_message', content: str}`; server frames are AG-UI events as JSON. |
| `GET /components` | JSON Schema for every component exposed by `ui_tools` — used by the frontend to discover renderable props. |
| `GET /info` | CopilotKit-compatible runtime info ping. Lets CopilotKit's auto-discovery succeed during cold start. |
| `GET /health` | Liveness probe. Doesn't require the lifespan to have started. |

### `tools_module`

Plain (non-UI) tools that nodes reference in their `tools:` block come from this module. Apps that only use `ui_tools` don't need it.

```python
router, lifespan = build_agui(
    yaml_path="workflow.yaml",
    tools_module="my_app.tools",
)
```

## Production Wiring

The minimal example above is enough for local development. For real deployments, layer on CORS, auth, and your chosen ASGI server.

### CORS

If your frontend is served on a different origin (Vite on `:3004`, FastAPI on `:8000`), open CORS before mounting the router:

```python
from fastapi.middleware.cors import CORSMiddleware

router, lifespan = build_agui(yaml_path="workflow.yaml")
app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://app.example.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router, prefix="/agui")
```

### Authentication

AgentFlow does not bake in an auth model — bring your own FastAPI dependency.

**HTTP endpoints**: attach a dependency at mount time so every route under the router runs through your auth check:

```python
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

bearer = HTTPBearer(auto_error=False)


async def verify_jwt(creds: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if creds is None or not _valid(creds.credentials):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    return creds.credentials


app.include_router(
    router,
    prefix="/agui",
    dependencies=[Depends(verify_jwt)],
)
```

`/info` and `/health` will also be protected — that's almost certainly what you want.

**WebSocket endpoint**: WebSocket dependencies have a different shape; the idiom is a pre-accept check on a token query parameter or subprotocol:

```python
from fastapi import WebSocket, WebSocketException, status


@app.middleware("http")
async def ws_token_gate(websocket: WebSocket, call_next):
    if websocket.url.path.startswith("/agui/") and websocket.scope["type"] == "websocket":
        token = websocket.query_params.get("token")
        if not _valid(token):
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
    return await call_next(websocket)
```

For higher-stakes deployments, gate at the load balancer / API gateway instead of in application code.

### Choosing an ASGI server

AgentFlow does not ship a server. Run the app under whatever your team prefers — uvicorn, hypercorn, daphne, granian. The standard recipe:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --workers 4
```

For production hardening (graceful shutdown, signal handling, healthchecks, structured logging) follow your ASGI server's docs — those are deployment concerns, not framework concerns.

## Human in the Loop

When an agent should pause for user approval before a tool runs, configure the deep backend's `HumanInTheLoopMiddleware` and the AG-UI bridge will surface the pause as a native interrupt on the wire.

### Pause: configure tool-level interrupts

```yaml
agent:
  name: portfolio_copilot
  system_prompt: "Help the analyst manage the fund."
  ui_tools:
    module: my_app.components
    use: [PortfolioOverview, Trade]
  middleware:
    - type: human_in_the_loop
      human_in_the_loop:
        interrupt_on:
          Trade:                         # tool name (component class name)
            allowed_decisions: [approve, reject]
```

When the agent calls `Trade(...)`, the middleware pauses the run before executing the fetcher.

### Wire shape on the server side

The bridge ends the SSE stream with a `RUN_FINISHED` event whose `outcome` carries the interrupt set (per the [AG-UI Interrupts spec](https://docs.ag-ui.com/concepts/interrupts)):

```json
{
  "type": "RUN_FINISHED",
  "threadId": "thread_abc",
  "runId": "run_1",
  "outcome": {
    "type": "interrupt",
    "interrupts": [
      {
        "id": "int_8a3f...",
        "reason": "tool_call",
        "toolCallId": "tc_d51e...",
        "message": "Approve trade?",
        "responseSchema": {"enum": ["approve", "reject"]}
      }
    ]
  }
}
```

The bridge also promotes the paused tool call's `TOOL_CALL_START / TOOL_CALL_ARGS / TOOL_CALL_END` events onto the wire **before** the `RUN_FINISHED` frame, with the LLM's proposed arguments on `TOOL_CALL_ARGS`. The interrupt's `toolCallId` is bound to that same tool call so a frontend rendering by call-id can light up the approval card inside the slot.

### Resume

Two resume channels are accepted on `POST /` — the canonical AG-UI `resume[]` array and the `role:"tool"` message format that CopilotKit (and several other AG-UI clients) actually emit. The bridge reads the paused interrupt's shape on the next POST and packages the resume accordingly.

**Path 1 — canonical `resume[]`:** the client sends an explicit resume array. The server maps each entry to a LangChain Decision:

| AG-UI resume entry | LangChain decision |
| --- | --- |
| `{status: "resolved", payload: {type: "approve"}}` | `{"type": "approve"}` |
| `{status: "resolved", payload: {type: "reject", message: "..."}}` | `{"type": "reject", "message": "..."}` |
| `{status: "resolved", payload: {type: "edit", edited_action: {name, args}}}` | `{"type": "edit", "edited_action": {...}}` |
| `{status: "resolved", payload: {type: "respond", message: "..."}}` | `{"type": "respond", "message": "..."}` |
| `{status: "cancelled"}` | `{"type": "reject", "message": "User cancelled."}` |

```json
{
  "threadId": "thread_abc",
  "resume": [
    {"interruptId": "int_8a3f...", "status": "resolved", "payload": {"type": "approve"}}
  ]
}
```

**Path 2 — `role:"tool"` message** (the path CopilotKit takes today): when the user clicks `respond(...)` on a `useHumanInTheLoop` card, CopilotKit packages the decision as a tool result and posts it through the normal messages array:

```json
{
  "threadId": "thread_abc",
  "messages": [
    {"role": "tool", "toolCallId": "tc_y", "content": "{\"type\": \"approve\"}"}
  ]
}
```

The bridge peeks at the paused state. If the interrupt is a `HITLRequest` (the shape LangChain's `HumanInTheLoopMiddleware` produces), it parses the tool message content as a Decision JSON and wraps as `Command(resume={"decisions": [<decision>]})`. Otherwise it treats the content as a plain client-tool result.

**Batched tool calls.** When the LLM emits N calls to the same HITL-gated tool in one turn, LangChain queues N `ActionRequest`s and demands N decisions on resume. CopilotKit's `useHumanInTheLoop` only renders one approval card per tool name and only stores one resolve promise — so the browser can only express one decision. The bridge **replicates the single decision across all N tool calls**: approve approves all, reject rejects all. Per-tool granularity would require CopilotKit to render one card per `toolCallId`, which it doesn't today.

Mixing both resume channels in one body (a `resume[]` AND a `role:"tool"` message) returns 400 — they're different paths and shouldn't be combined.

### CopilotKit frontend snippet

```tsx
useHumanInTheLoop({
  name: "Trade",
  parameters: z.object({ symbol: z.string(), qty: z.number() }),
  render: ({ status, args, respond }) => {
    if (status !== "executing" || !respond) return <div>Preparing…</div>;
    return (
      <ApprovalCard
        label={`Trade ${args.symbol} × ${args.qty}`}
        onApprove={() => respond({ type: "approve" })}
        onReject={() => respond({ type: "reject", message: "User rejected." })}
      />
    );
  },
});
```

CopilotKit reads the proposed arguments from `args` (populated by the promoted `TOOL_CALL_ARGS` event the bridge emits before pausing), renders the approval card, and on `respond(...)` posts a `role:"tool"` message with the decision serialized as the message content.

### Persistence across reconnects

The pause lives in the LangGraph checkpointer. A user can refresh the browser and the next POST on the same `threadId` picks up the same paused state.

### Bridge resilience around interrupts

Live testing surfaced two corner cases that the bridge now handles automatically:

- **LangGraph silent pause.** Sometimes LangGraph finalizes an interrupt into checkpointer state *without* re-raising `GraphInterrupt` to the caller (e.g. when the interrupt fires inside a tool-bound branch the runner catches internally). The agent run would complete from the orchestrator's POV with no content events, and the bridge would otherwise emit the empty-response fallback while the user's actual approval card sat hidden in the checkpointer. After every clean run the bridge re-reads state; if a pending interrupt is present, it surfaces that instead of the fallback.

- **Re-surfacing a stale pause.** If the frontend missed a previous run's interrupt outcome (e.g. user reloaded mid-stream), the next fresh POST on the same `threadId` lands on a thread LangGraph considers still paused — and LangGraph would silently no-op the new input. The bridge detects this on the inbound POST (state has a pending interrupt and the body isn't a resume) and re-emits the interrupt envelope so the frontend gets another chance to render the approval card. The synthesized `TOOL_CALL_*` lifecycle carries the proposed args from the checkpointer's `ActionRequest.args` so CopilotKit's `useHumanInTheLoop` (which binds by `toolCallId`) still has something to attach to.

## Frontend-Defined Tools

Some tools belong in the browser — confirming a destructive action with a modal, opening a URL in a new tab, reading from `localStorage`, calling a third-party SDK that ships only as a JS bundle. AgentFlow lets you declare these in YAML; the agent calls them like any normal tool; the browser executes them; the result flows back as a regular tool result.

### Declare in YAML

```yaml
agent:
  name: portfolio_copilot
  system_prompt: "Help the analyst manage the fund."
  client_tools:
    - name: confirmDelete
      description: "Ask the user to confirm a delete operation."
      parameters:
        type: object
        properties:
          target: {type: string, description: "What to delete"}
        required: [target]

    - name: escalate
      description: "Escalate the issue to a human supervisor."
      parameters:
        type: object
        properties: {}
        required: []
      available_when: "state.user_role == 'admin'"
```

Each entry mirrors the AG-UI `Tool` shape (`name`, `description`, `parameters` as JSON Schema). Optional `available_when` is described below.

### What happens at runtime

When the agent picks `confirmDelete`:

1. AgentFlow emits the standard tool-call lifecycle on the wire: `TOOL_CALL_START` → `TOOL_CALL_ARGS` (with the LLM's proposed args) → `TOOL_CALL_END`.
2. The run pauses via `langgraph.interrupt(...)`.
3. The bridge surfaces the pause as `RUN_FINISHED` with `outcome.type: "interrupt"`, carrying an `Interrupt` of `reason: "agentflow:client_tool"`, the matching `toolCallId`, and the args in `metadata.args`.
4. CopilotKit's `useCopilotAction` runs the registered handler in the browser.
5. The browser delivers the result by posting the next `RunAgentInput` with a `role: "tool"` message:

```json
{
  "threadId": "t-1",
  "messages": [
    {"role": "tool", "toolCallId": "tc_abc", "content": "true"}
  ]
}
```

6. AgentFlow builds `Command(resume=<content>)` so `interrupt(...)` returns the content string; the stub returns it; the LLM sees a normal tool result and continues.

### Frontend handler

```tsx
import { useCopilotAction } from "@copilotkit/react-core";

useCopilotAction({
  name: "confirmDelete",
  description: "Ask the user to confirm a delete.",
  parameters: [{ name: "target", type: "string", required: true }],
  handler: ({ target }) => window.confirm(`Delete ${target}?`) ? "true" : "false",
});
```

The `name` must match the YAML declaration. CopilotKit hooks the rest of the protocol up automatically — handler runs after the pause, result posted on the next request.

### `available_when` — filter tools from the LLM by state

The `available_when` field on `ClientToolConfig` accepts a [`simpleeval`](https://pypi.org/project/simpleeval/) expression evaluated against the current graph state **immediately before each model call**. When the expression is falsy, the tool is removed from the bound tools list for that turn — the LLM literally doesn't see it and can't propose it. The next turn re-evaluates, so the tool can come and go as state changes.

Enforcement is by `DeepAvailabilityMiddleware` in `agentflow.deep.availability`. The middleware hooks LangChain's `wrap_model_call` and is auto-attached by the deep orchestrator whenever `available_when` is declared (on `ui_tools` or `client_tools`) — no YAML knob, no opt-in required. The same middleware enforces `available_when` for generative-UI components, so a single layer handles both.

**Expression environment.** One name is bound: `state`, a dotted-access wrapper over the graph state dict. Examples:

```yaml
client_tools:
  - name: escalate
    description: Escalate to a manager.
    parameters: { type: object, properties: {}, required: [] }
    available_when: "state.user_role == 'manager'"

  - name: enableTradeMode
    description: Enable order entry.
    parameters: { type: object, properties: {}, required: [] }
    available_when: "state.session.kyc_complete and state.market_hours"
```

**Fail-closed.** An exception during evaluation (typo, missing key, broken expression) hides the tool — the LLM doesn't get it. This is intentional: a `available_when` bug must not accidentally surface a privileged tool.

**Zero overhead when unused.** If no client tool declares `available_when`, the middleware factory returns `None` and the agent runs with no extra middleware on the hot path.

### Limitations

- **YAML-declared only in v1.** AG-UI's spec uses `RunAgentInput.tools[]` for per-request tool publication. Honoring that needs the orchestrator to support per-request agent rebuilding (planned, out of scope for this release). With YAML-declared tools, every frontend instance sees the same tool set.
- **One client tool call per pause** for the client-tool round-trip. If the agent picks two client tools in a single LLM turn, only one resumes cleanly; the other times out. (HITL approvals batched on the same tool are handled — see "Batched tool calls" above.)
- **No mixing with HITL approval on the same paused thread.** A thread is paused for an approval or a client-tool result, not both. Combining `resume[]` and a `role:"tool"` message in one POST is a 400.

## State Synchronization

When your workflow keeps arbitrary application state in the LangGraph graph (a counter, a flag, a step index — anything beyond the chat history), AG-UI delivers it to the frontend as `STATE_SNAPSHOT` events. CopilotKit's `useCoAgentState` hook reads from these so a React component can render the agent's live state.

### What the bridge emits

- **One `STATE_SNAPSHOT` at the start of each run** with the graph state as the agent begins this turn. If the thread has no checkpoint yet (first turn ever), this snapshot is the empty state.
- **An additional `STATE_SNAPSHOT` whenever a tool result or agent message produces a state change.** The bridge calls `aget_state` after those events, compares the result to the last snapshot it sent, and only emits if something actually changed. Token-streaming events don't trigger a re-check (they don't mutate graph state).
- The `messages` key is **always stripped** from the snapshot — chat history flows over the wire as `TEXT_MESSAGE_*` / `TOOL_CALL_*` events already, and duplicating it on every snapshot inflates the stream.

### Wire shape

```json
{"type": "STATE_SNAPSHOT", "snapshot": {"approved": true, "step": 3}}
```

### Frontend consumption

```tsx
import { useCoAgentState } from "@copilotkit/react-core";

function Approvals() {
  const { state } = useCoAgentState<{ approved: boolean; step: number }>();
  return (
    <div>
      Step {state.step} — {state.approved ? "approved" : "pending"}
    </div>
  );
}
```

### Persistence dependency

State sync depends on the LangGraph checkpointer being on (it's how the bridge reads the current state). If you've disabled persistence, `STATE_SNAPSHOT` events simply don't fire and the rest of AG-UI keeps working — there's no error.

### `STATE_DELTA`

The AG-UI spec also defines `STATE_DELTA` events carrying RFC 6902 JSON Patch operations for incremental updates. The Pydantic model is in `agui_events.py` for forward compatibility, but the current bridge emits snapshots only. If the wire-size of frequent full snapshots becomes a problem, delta support can be added without a wire-format change — the schema is already there.

## Error Handling and Fallbacks

The bridge translates several failure shapes into wire frames the frontend can render without crashing the chat.

### Upstream exceptions become `RUN_ERROR`, not HTTP 500

When the orchestrator's `astream_events` raises — Azure content-filter `BadRequestError`, LangChain validation error, anything — the bridge logs the traceback server-side and emits a `RUN_ERROR` event as the final frame on the SSE stream. The HTTP response ends normally. The frontend sees a clean error message instead of a connection that 500'd mid-stream and dropped any events the server already sent.

```json
{"type": "RUN_ERROR", "message": "Error code: 400 - {...content_filter...}", "code": "BadRequestError"}
```

### Empty LLM responses get a synthetic fallback

LLMs sometimes return empty completions — content-filter soft-blocks (Azure returning an empty response instead of a 400), over-cautious model behavior, agent loop terminating without a final response. The bridge detects "the run completed cleanly and produced no `token` / `agent` / `tool_call` / `tool` events" and emits a fallback assistant message so the frontend never renders a blank assistant turn:

> *I wasn't able to generate a response for that. Could you rephrase your question or try again?*

This kicks in only when the run truly produced no content AND no pending interrupt is in state — if the LLM called a HITL tool but LangGraph silently recorded the pause (see "Bridge resilience around interrupts" above), the bridge surfaces the interrupt instead of the fallback.

## Observability

### `agui.run` OTel span

Every `POST /` wraps its SSE generator in a single OpenTelemetry span named `agui.run`. LangChain's auto-emitted `chat <model>`, `execute_tool <function>`, and `invoke_agent <name>` spans nest under it via Python's contextvars, so a single trace covers the full turn: POST receipt → orchestrator run → LLM calls → tool execution → SSE emission. Open one span in Jaeger / Tempo / Datadog / Phoenix and you see the whole story for a turn.

Attributes set on the span:

| Attribute | Source | Description |
| --- | --- | --- |
| `agui.thread_id` | request body `threadId` | The LangGraph checkpoint key — ties together multi-turn conversations. |
| `agui.run_id` | request body `runId` | Per-run identifier the client supplies (or `""` if omitted). |
| `agui.kind` | bridge-derived | One of `user_message`, `resume[]`, `client_tool_result`. Lets you query "all HITL resumes" across many runs. |
| `agui.messages_count` | request body `messages` | Number of messages in the inbound transcript — proxy for conversation length. |
| `agui.events_emitted` | populated in the span's `finally` | Number of AG-UI events the server wrote on the SSE stream. |

On exception the span records the error via `record_exception` and sets `Status(ERROR)`. The wrap is a no-op when no OTel provider is configured (the tracer falls back to OTel's default no-op), so this is free for users who haven't opted into telemetry.

Enable by setting:
```
OTEL_TRACES_ENABLED=true
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

### Tracing gaps to be aware of

The current build covers server-side spans only. A few things are not yet traced and may matter depending on the use case:

- **Browser-side `useFrontendTool` handler execution.** When the agent calls `openSecFiling`, the server-side stub up to `interrupt()` gets an `execute_tool` span. The actual `window.open(...)` runs in the browser; no OTel emission from there unless you wire `@opentelemetry/sdk-trace-web` yourself.
- **Cross-turn trace correlation.** A HITL pause produces two separate traces — one for the turn that paused, one for the resume — tied together by `agui.thread_id` (as an attribute) but not by a shared `trace_id`. Propagating the W3C `traceparent` header on the resume would close this; out of scope for v1.
- **Per-event sub-spans.** No spans for individual emitted events (`TOOL_CALL_START`, `STATE_SNAPSHOT`, etc.). All emissions are aggregated into the parent `agui.run` span's `agui.events_emitted` count.

### Plugin lifecycle events (separate from OTel)

Independent of OTel, the deep orchestrator emits structured lifecycle events to its plugin system:

```
emit_workflow_start / emit_workflow_end
emit_tool_start    / emit_tool_end
emit_hitl_start    / emit_hitl_end
emit_external_agent_start / emit_external_agent_end
emit_error
```

These flow through `PluginManager` to whatever plugins are installed (cost-tracking, audit-log, custom). Good place to hang compliance audit writers that need a structured record of "every tool the agent called, who approved it, when" without depending on OTel infrastructure.

## Resumability — Threads and Checkpoints

Every AG-UI request carries a `threadId`. AgentFlow uses it as the LangGraph checkpoint key, so the entire mechanism builds on one rule:

> **Two requests with the same `threadId` operate on the same conversation. The checkpointer persists state between them.**

That single rule is what makes pause-and-resume, multi-turn memory, and reconnection work — they're all just "another request with the same thread id."

### What survives a disconnect

| Event | Outcome |
| --- | --- |
| Client closes the SSE stream mid-run | The orchestrator keeps running on the server. State is checkpointed as nodes complete. The next request on the same `threadId` sees the latest checkpoint. |
| Client refreshes the browser tab while paused on a HITL approval | New POST with the same `threadId` and a `resume[]` finishes the pause. The pause itself was persisted in the checkpointer. |
| Client refreshes mid-execution of a client tool | The pause for the client tool is persisted. The browser's *intent* to call the tool is lost (the JS handler is gone), but resuming with a tool-role message on the same `threadId` still works. |
| Server restarts mid-run | If the checkpointer is durable (file-backed SQLite, Postgres), the next request on the same `threadId` resumes from the most recent checkpoint. With in-memory persistence (default for dev), state is lost. |

### What doesn't survive

- **In-flight token streaming** — text the client missed between disconnect and reconnect is not replayed. The next request starts fresh from the checkpointed state.
- **The current SSE response** — when the client disconnects, the SSE stream is gone. The server-side run continues writing checkpoints, but the events from "now" until the natural end of the run are not surfaced again. The frontend needs to issue a new request to see what happened.
- **Wall-clock time** — interrupts don't have a server-enforced TTL today. If the spec's `expiresAt` is set on an Interrupt, it's surfaced to the client; the server doesn't garbage-collect paused threads on its own.

### Recommended persistence setup

```yaml
persistence:
  backend: sqlite           # file-backed SQLite — survives process restarts
  db_path: ./checkpoints.db
```

For production, use the `[postgres]` extra and a Postgres backend so the checkpointer survives container restarts and works across multiple replicas.

```bash
pip install "./agentflow-<version>-py3-none-any.whl[deep,ui,postgres]"
```

```yaml
persistence:
  backend: postgres
  connection_string: "${POSTGRES_URL}"
```

### Round-trip example

The full pause/resume cycle on a single thread:

```
# Turn 1 — trigger an approval
POST /agui/
{"threadId": "t-1", "messages": [{"role": "user", "content": "delete thread-7"}]}

→ ... TOOL_CALL_* lifecycle for confirmDelete ...
→ RUN_FINISHED with outcome.type=interrupt,
    interrupts=[{id: "int_x", reason: "agentflow:client_tool",
                 toolCallId: "tc_y", metadata.args: {target: "thread-7"}}]
```

Browser shows the modal, user clicks Confirm:

```
# Turn 2 — same threadId
POST /agui/
{"threadId": "t-1",
 "messages": [{"role": "tool", "toolCallId": "tc_y", "content": "true"}]}

→ ... agent continues from the checkpoint ...
→ RUN_FINISHED (no outcome — run completed)
```

The `threadId` is the only thing tying turn 1 and turn 2 together. No session ids, no run ids, no other state on the request — the checkpointer handles everything.

## Frontend Integration (CopilotKit)

[CopilotKit](https://copilotkit.ai) is the most popular AG-UI React client. A minimal setup pointing at your `build_agui` mount:

```tsx
import { CopilotKitProvider, useCopilotChat } from "@copilotkit/react-core";
import { HttpAgent } from "@ag-ui/client";

const AGUI_BASE = "http://localhost:8000/agui";
const portfolioAgent = new HttpAgent({ url: AGUI_BASE + "/" });

export default function App() {
  return (
    <CopilotKitProvider
      runtimeUrl={AGUI_BASE}
      selfManagedAgents={{ default: portfolioAgent }}
    >
      <Chat />
    </CopilotKitProvider>
  );
}
```

Register a renderer per component class — CopilotKit reads from the tool-call args (which AgentFlow populates with your full validated props), so the renderer receives a fully-typed Pydantic-shaped object:

```tsx
import { useComponent } from "@copilotkit/react-core";
import { z } from "zod";

useComponent({
  name: "WeatherCard",
  schema: z.object({
    city: z.string(),
    temperature_f: z.number(),
    condition: z.string(),
  }),
  render: ({ args }) => (
    <div className="weather-card">
      <h3>{args.city}</h3>
      <p>{args.temperature_f}°F, {args.condition}</p>
    </div>
  ),
});

useComponent({
  name: "ToolError",
  schema: z.object({ tool: z.string(), message: z.string() }),
  render: ({ args }) => (
    <div className="error">⚠️ {args.tool}: {args.message}</div>
  ),
});
```

The frontend Zod schema and the backend Pydantic class describe the same contract — keep them in sync and the entire flow is end-to-end typed.

## References

- [AG-UI protocol specification](https://docs.ag-ui.com/)
- [CopilotKit documentation](https://docs.copilotkit.ai/)
- [AgentFlow Documentation](./index.md)

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
