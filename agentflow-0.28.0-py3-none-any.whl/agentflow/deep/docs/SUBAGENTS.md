# Subagents

Subagents let the main agent delegate specialized tasks to child agents. Each subagent has its own system prompt,
context window, and tool access. The main agent decides when and how to delegate based on subagent descriptions.

## How It Works

1. You define named subagents in YAML with `name`, `description`, and `system_prompt`.
2. The builder creates `SubAgent` objects and passes them to `create_deep_agent(subagents=[...])`.
3. DeepAgents adds a `task` tool to the main agent. When calling it, the agent specifies `subagent_type` (matching a
   name) and a `description` of what to do.
4. The subagent runs autonomously with its own system prompt, then returns results to the main agent.
5. The main agent incorporates the results and continues.

```
Main Agent
  │
  ├─ task(subagent_type="researcher", description="Find all API endpoints")
  │     └─ Subagent: researcher
  │          └─ reads files, returns summary
  │
  ├─ task(subagent_type="test_writer", description="Write tests for auth module")
  │     └─ Subagent: test_writer
  │          └─ writes test files, returns confirmation
  │
  └─ Synthesizes results, writes final output
```

## YAML Configuration

```yaml
subagents:
  enabled: true
  max_depth: 2
  agents:
    - name: researcher
      description: >
        Research analyst that reads files, traces dependencies,
        and summarizes findings. Use for investigation tasks.
      system_prompt: |
        You are a research analyst. Read the provided files,
        extract key information, cross-reference data across
        multiple sources, and provide a structured summary.

    - name: test_writer
      description: >
        Testing specialist that writes comprehensive pytest tests.
        Use when tests need to be created or updated.
      system_prompt: |
        You write pytest tests. Use fixtures, parametrize for
        edge cases, and aim for high branch coverage. Follow
        the project's existing test patterns.
      model: "openai:gpt-4o-mini"  # Optional: cheaper model for tests

    - name: code_reviewer
      description: >
        Senior code reviewer that checks for bugs, security issues,
        and style violations.
      system_prompt: |
        You are a senior code reviewer. Analyze the code for:
        - Bugs and logic errors
        - Security vulnerabilities (OWASP top 10)
        - Performance issues
        - Style and readability
        Provide specific, actionable feedback.
```

## Configuration Fields

| Field       | Type | Default | Description                                                                                                                  |
|-------------|------|---------|------------------------------------------------------------------------------------------------------------------------------|
| `enabled`   | bool | `false` | Enable subagent spawning                                                                                                     |
| `max_depth` | int  | `3`     | Maximum recursion depth (1-10). Depth 1 = main agent can spawn subagents. Depth 2 = subagents can spawn their own subagents. |
| `agents`    | list | `null`  | Named subagent specifications                                                                                                |

### Per-Subagent Fields

| Field           | Type   | Required | Description                                                                                                      |
|-----------------|--------|----------|------------------------------------------------------------------------------------------------------------------|
| `name`          | string | Yes      | Unique identifier. The main agent uses this in `task(subagent_type="name")`.                                     |
| `description`   | string | Yes      | What this subagent does. The main agent reads this to decide when to delegate. Write it as guidance for the LLM. |
| `system_prompt` | string | Yes      | Full instructions for the subagent. Include specific file paths, patterns, or rules.                             |
| `model`         | string | No       | Override model. Use for cost optimization (e.g., cheaper model for simple tasks).                                |

## Writing Good Subagent Descriptions

The `description` field is how the main agent decides whether to delegate. Make it specific about:

- **What** the subagent does (not just its name)
- **When** to use it (what kind of tasks)
- **What it returns** (summary, files, structured data)

```yaml
# Good — specific about capability and when to use
description: >
  Supply chain graph analyst that traces dependencies through
  CSV data files. Use when you need to map relationships between
  APIs, formulations, products, and markets.

# Bad — too vague
description: "Analyzes data"
```

## Writing Good System Prompts

Subagent system prompts should be **self-contained** — the subagent doesn't see the main agent's system prompt or
conversation history. Include:

- Role and expertise
- Specific files or data sources to use
- Output format expectations
- Constraints or rules

```yaml
system_prompt: |
  You are a supply chain graph analyst at MedCore Pharmaceuticals.

  DATA SOURCES:
  - data_room/supply_chain/api_to_formulation_map.csv
  - data_room/supply_chain/formulation_to_product_map.csv
  - data_room/supply_chain/product_to_market_map.csv

  YOUR PROCESS:
  1. Read the relevant CSV files
  2. Trace the full dependency graph from API to market
  3. Identify all affected nodes

  OUTPUT:
  Return a structured summary with counts and specific product IDs.
```

## Model Overrides

Use the `model` field to run subagents on different (usually cheaper) models:

```yaml
agents:
  - name: summarizer
    description: "Summarizes long documents"
    system_prompt: "..."
    model: "openai:gpt-4o-mini"  # Cheaper for summarization

  - name: architect
    description: "Designs system architecture"
    system_prompt: "..."
    # No model override — uses the main agent's model
```

## Subagents Without Named Agents

You can enable subagents without pre-defining them:

```yaml
subagents:
  enabled: true
  max_depth: 2
```

In this case, the main agent can still use the `task` tool to spawn generic subagents, but without specialized system
prompts. Named agents are recommended for better results.

## Telemetry

When telemetry is enabled, subagent invocations appear as nested spans in Jaeger:

```
deepagent.invoke (main agent)
  ├─ task.researcher
  │   └─ subagent.researcher
  │       ├─ tool.read_file
  │       └─ tool.read_file
  ├─ task.test_writer
  │   └─ subagent.test_writer
  │       └─ tool.write_file
  └─ tool.write_file
```

Each span includes:

- `deepagent.subagent` — the subagent name
- `deepagent.task` — the task description (first 200 chars)
- `deepagent.depth` — nesting depth

See [Telemetry](TELEMETRY.md) for setup instructions.

## Programmatic Usage

```python
from agentflow.deep import DeepAgentBuilder

builder = DeepAgentBuilder.from_yaml("agent.yaml", checkpointer=checkpointer)
agent = builder.build()

# The agent now has a `task` tool for subagent delegation
result = agent.invoke(
    {"messages": [HumanMessage(content="Analyze the codebase and write tests")]},
    config={"configurable": {"thread_id": "session-1"}},
)
```
