# CLI Reference

The `agentflow` command runs AgentFlow Deep agents from the command line.

> **Cross-backend flags** — `--output ndjson`, `--debug`, `--verbose`, `--ascii`, REPL slash commands, the `agentflow-init` and `agentflow-threads` companion commands, and the JSON event schema are documented in `agentflow/cli/CLI_FLAGS.md` (in the source tree). This page covers Deep-specific behaviour only.

## Installation

```bash
pip install agentflow[deep]
```

This installs the `agentflow` command globally.

## Synopsis

```bash
agentflow [OPTIONS] [QUERY]
```

## Arguments

| Argument | Required | Description                                                                                                     |
|----------|----------|-----------------------------------------------------------------------------------------------------------------|
| `QUERY`  | No       | Task for the agent. If omitted with `--interactive`, starts a REPL. If omitted without flags, launches the TUI. |

## Options

### Agent Configuration

| Flag             | Type   | Default     | Description                                                                                                               |
|------------------|--------|-------------|---------------------------------------------------------------------------------------------------------------------------|
| `--yaml PATH`    | string | Auto-detect | Path to agent YAML config. Auto-detects `agent.yaml`, `coding_agent.yaml`, or `deep_agent.yaml` in the current directory. |
| `--workdir PATH` | string | `.`         | Working directory for the agent's filesystem operations.                                                                  |
| `--dry-run`      | flag   | —           | Validate config and print summary without running the agent. No LLM calls.                                                |

### Execution Modes

| Flag                   | Description                                                                           |
|------------------------|---------------------------------------------------------------------------------------|
| *(no flags, no query)* | Launch the **TUI** — terminal UI with todo panel, status panel, and streaming output. |
| `QUERY` (positional)   | **One-shot mode** — run the query and exit. Plain CLI output with streaming.          |
| `--interactive`        | **Interactive REPL** — continuous conversation. Type `quit` or `exit` to stop.        |
| `--no-tui`             | Disable TUI even when no query is given. Falls back to interactive mode.              |

### Persistence

| Flag                      | Type   | Default                          | Description                                                                                                  |
|---------------------------|--------|----------------------------------|--------------------------------------------------------------------------------------------------------------|
| `--persistence TYPE`      | enum   | `sqlite`                         | Checkpointer backend: `memory`, `sqlite`, or `postgres`.                                                     |
| `--db-path PATH`          | string | `.agentflow/deep_checkpoints.db` | SQLite database file path. Also reads `CHECKPOINTER_DB_PATH` env var.                                        |
| `--connection-string STR` | string | —                                | PostgreSQL connection string. Supports `${ENV_VAR}` syntax. Also reads `POSTGRES_CONNECTION_STRING` env var. |
| `--no-checkpointer`       | flag   | —                                | Disable persistence entirely (stateless mode).                                                               |
| `--thread-id ID`          | string | auto-generated UUID              | Thread ID for conversation continuity. Use the same ID to resume a conversation.                             |

### Output

| Flag     | Type | Default | Description                                             |
|----------|------|---------|---------------------------------------------------------|
| `--json` | flag | —       | Output dry-run summary as JSON (only with `--dry-run`). |

## Usage Examples

### One-Shot Tasks

```bash
# Run a single task
agentflow --yaml agent.yaml "Refactor the database module to use connection pooling"

# With custom working directory
agentflow --yaml agent.yaml --workdir ./src "Add type hints to all public functions"
```

### Interactive Mode

```bash
# Start interactive conversation
agentflow --yaml agent.yaml --interactive

# Resume a previous conversation
agentflow --yaml agent.yaml --interactive --thread-id my-session-001
```

### TUI Mode

```bash
# Launch TUI (default)
agentflow --yaml agent.yaml

# TUI with specific persistence
agentflow --yaml agent.yaml --persistence postgres
```

### Validation

```bash
# Validate config (no LLM calls, no cost)
agentflow --yaml agent.yaml --dry-run

# JSON output for scripting
agentflow --yaml agent.yaml --dry-run --json
```

### Persistence

```bash
# SQLite (default)
agentflow --yaml agent.yaml "Analyze the codebase"

# Custom SQLite path
agentflow --yaml agent.yaml --db-path .agentflow/deep_checkpoints.db "Analyze the codebase"

# PostgreSQL via flag
agentflow --yaml agent.yaml --persistence postgres \
  --connection-string "postgresql://user:pass@localhost/db" \
  "Analyze the codebase"

# PostgreSQL via .env (set POSTGRES_CONNECTION_STRING)
agentflow --yaml agent.yaml --persistence postgres "Analyze the codebase"

# In-memory (no persistence)
agentflow --yaml agent.yaml --persistence memory "Quick one-off query"

# Disable persistence entirely
agentflow --yaml agent.yaml --no-checkpointer "Quick one-off query"
```

## Environment Variables

These are read from `.env` or the system environment:

### LLM Configuration

| Variable                | Description                  |
|-------------------------|------------------------------|
| `OPENAI_API_KEY`        | OpenAI API key               |
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI endpoint URL    |
| `AZURE_DEPLOYMENT`      | Azure OpenAI deployment name |
| `OPENAI_API_VERSION`    | Azure OpenAI API version     |
| `ANTHROPIC_API_KEY`     | Anthropic API key            |

### Persistence

| Variable                     | Description                                                               |
|------------------------------|---------------------------------------------------------------------------|
| `POSTGRES_CONNECTION_STRING` | PostgreSQL connection string (used when `--connection-string` is omitted) |
| `CHECKPOINTER_DB_PATH`       | SQLite database path (used when `--db-path` is omitted)                   |

### Telemetry

| Variable                      | Description                     | Default                 |
|-------------------------------|---------------------------------|-------------------------|
| `OTEL_TRACES_ENABLED`         | Set to `true` to enable tracing | `false`                 |
| `OTEL_SERVICE_NAME`           | Service name in Jaeger/OTel     | `deepagent`             |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | OTLP collector endpoint         | `http://localhost:4317` |

Telemetry is auto-enabled when `OTEL_TRACES_ENABLED=true` is set. No CLI flag needed. See [Telemetry](TELEMETRY.md) for
details.

## YAML Auto-Detection

When `--yaml` is not specified, `agentflow` searches the current directory for:

1. `agent.yaml`
2. `coding_agent.yaml`
3. `deep_agent.yaml`

If none is found, an error is displayed.

## Dry Run Output

`--dry-run` validates the YAML and prints a summary:

```
╭──────────────────────────────────────────────────╮
│ AgentFlow Deep                                   │
│ Run autonomous agents from the command line      │
╰──────────────────────────────────────────────────╯

╭──────────────────────────────────────────────────╮
│ My Agent                                         │
│ A helpful coding assistant                       │
╰──────────────────────────────────────────────────╯

  Version       1.0
  LLM           azure_openai / gpt-4o
  Checkpointer  enabled
  Subagents     enabled
  Tools (builtin)  read_file, write_file, execute, write_todos
  Middleware    todo_list, memory, filesystem, summarization
  Subagents     test_writer, reviewer
  Memory        .deepagents/AGENTS.md

Config is valid.
```

## Documentation Server

Serve these docs locally:

```bash
agentflow docs                                # http://localhost:9100
agentflow docs --dev-addr 0.0.0.0:8080        # Custom address
```

MkDocs requires the docs extra: `pip install agentflow[docs]`.
