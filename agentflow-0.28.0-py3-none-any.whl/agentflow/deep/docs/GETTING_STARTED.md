# Getting Started

This guide walks you through installing AgentFlow Deep, creating an agent YAML config, and running your first agent.

## Prerequisites

- Python 3.11+
- An LLM API key (OpenAI, Azure OpenAI, or Anthropic)

## Installation

```bash
pip install agentflow[deep]
```

This installs the `agentflow` CLI command and all required dependencies (deepagents, langchain-openai, typer,
textual, etc.).

### Optional extras

```bash
# PostgreSQL persistence
pip install agentflow[postgres]
```

## Project Setup

Create a project directory with an agent YAML file and a `.env` for credentials:

```
my-project/
├── agent.yaml          # Agent configuration
├── .env                # API keys and settings
└── .deepagents/
    └── AGENTS.md       # Optional: project context for the agent
```

### 1. Create `.env`

=== "OpenAI"

    ```bash
    OPENAI_API_KEY="sk-..."
    ```

=== "Azure OpenAI"

    ```bash
    AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
    AZURE_DEPLOYMENT="your-deployment-name"
    OPENAI_API_VERSION="2024-12-01-preview"
    ```

=== "Anthropic"

    ```bash
    ANTHROPIC_API_KEY="sk-ant-..."
    ```

### 2. Create `agent.yaml`

```yaml
metadata:
  version: "1.0"
  name: "My First Agent"
  description: "A helpful coding assistant"

agent:
  system_prompt: |
    You are a helpful software engineer. You can read and write files,
    execute commands, and plan work using todo lists.
  llm:
    provider: openai
    config:
      model: gpt-4o
      api_key: "${OPENAI_API_KEY}"
      temperature: 0.0

tools:
  builtin:
    - read_file
    - write_file
    - execute
    - write_todos
```

Environment variables in `${...}` syntax are automatically expanded from `.env`.

### 3. Run

```bash
# Validate config (no LLM calls, no cost)
agentflow --yaml agent.yaml --dry-run

# One-shot task
agentflow --yaml agent.yaml "List all Python files in this directory and summarize what each one does"

# Interactive REPL
agentflow --yaml agent.yaml --interactive

# TUI (default when no query is given)
agentflow --yaml agent.yaml
```

## What Happens When You Run `agentflow`

1. **Loads `.env`** from the YAML file's directory and the current working directory.
2. **Parses `agent.yaml`** and validates against the schema (Pydantic).
3. **Creates a checkpointer** — SQLite by default at `.agentflow/deep_checkpoints.db`.
4. **Builds the agent** — creates an LLM instance, resolves middleware/tools/subagents, and compiles a LangGraph
   StateGraph.
5. **Streams execution** — the agent processes your query, calling tools and delegating to subagents as needed. Output
   streams to the terminal in real time.

## Adding Project Context (Memory)

Create `.deepagents/AGENTS.md` with project-specific context that gets injected into the agent's system prompt:

```markdown
# Project: My Web App

## Tech Stack
- Python 3.12, FastAPI, SQLAlchemy
- PostgreSQL 16, Redis
- pytest for testing

## Conventions
- All API routes in `src/api/`
- Models in `src/models/`
- Always write tests for new features
```

Reference it in your YAML:

```yaml
middleware:
  - type: memory
    config:
      sources:
        - ".deepagents/AGENTS.md"
```

## Adding Subagents

Subagents let the main agent delegate specialized tasks:

```yaml
subagents:
  enabled: true
  max_depth: 2
  agents:
    - name: test_writer
      description: "Writes pytest tests for Python code"
      system_prompt: |
        You are a testing specialist. Write comprehensive pytest tests
        with good coverage. Use fixtures and parametrize where appropriate.
    - name: code_reviewer
      description: "Reviews code for quality, security, and best practices"
      system_prompt: |
        You are a senior code reviewer. Check for bugs, security issues,
        performance problems, and style violations.
```

The main agent decides when to delegate based on the `description` field. Each subagent gets its own context and can use
the same tools as the main agent.

## Next Steps

- [YAML Reference](YAML_REFERENCE.md) — full schema with all options
- [CLI Reference](CLI_REFERENCE.md) — all command-line flags
- [Subagents](SUBAGENTS.md) — multi-agent coordination patterns
- [Persistence](PERSISTENCE.md) — conversation continuity with SQLite or PostgreSQL
- [Telemetry](TELEMETRY.md) — trace agent execution in Jaeger
