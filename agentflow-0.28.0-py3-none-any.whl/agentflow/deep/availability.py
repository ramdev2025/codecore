"""LangChain middleware for **per-call dynamic** ``available_when`` gating.

LangGraph-based advantage: LangChain's ``AgentMiddleware.wrap_model_call``
hook fires immediately before the LLM call, lets the middleware mutate
``request.tools``, and propagates ``request.state`` so predicates can
evaluate against the *current* graph state — not the build-time
snapshot. The LLM only sees tools whose predicates evaluate truthy
for that specific turn.

Build-time gating already runs in
:meth:`agentflow.deep.core.builder.DeepAgentBuilder.build` via the
cross-backend :func:`agentflow.genui.filter_by_availability`. This
middleware layers on top: tools that pass the build-time filter (or
weren't gated at all) are re-checked per-turn against live state.

Cross-backend contrast
----------------------

MAF and SK can do build-time gating but not clean per-call hide-from-
list — their middleware composition doesn't expose state-aware tool
filtering at the right layer. The LangGraph-based backends
(``workflows``, ``deep``) are the only ones where the full pattern
works natively. This middleware is the deep proof.

Auto-attachment
---------------

The builder auto-attaches this middleware when any predicate exists —
either as the top-level ``AgentConfig.available_when`` map or inline
on a ``ClientToolConfig.available_when`` field. No new YAML knob; the
YAML declaration drives both build-time and per-call paths.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from langchain.agents.middleware import AgentMiddleware

from agentflow.genui.predicates import evaluate_availability

if TYPE_CHECKING:
    from langchain.agents.middleware import ModelRequest, ModelResponse

    from agentflow.genui import ClientToolConfig

logger = logging.getLogger(__name__)


class DeepAvailabilityMiddleware(AgentMiddleware):
    """Filters tools from each model call by per-tool predicates.

    Holds a ``{tool_name: predicate_expression}`` map keyed by the
    LLM-facing tool name. Workflows uses the component class name as
    the tool name for ``ui_tools`` (Phase 2 commit), so the same key
    that the YAML's ``available_when`` map uses lines up directly
    with what the middleware sees on ``request.tools``.

    On each model call:

      1. Resolve the current state (dict, Pydantic, or plain object)
         to a plain dict via :meth:`_coerce_state`.
      2. For every tool whose name has a predicate, evaluate it
         against that dict via the shared sandboxed evaluator. Tools
         with falsy predicates are dropped from ``request.tools``.
      3. Tools without a predicate pass through unchanged — predicates
         only target ones explicitly named.

    Fail-closed semantics: predicate evaluation errors hide the tool
    (the shared evaluator returns ``False`` and logs a WARNING).
    """

    def __init__(self, predicates: dict[str, str]) -> None:
        super().__init__()
        if not predicates:
            raise ValueError(
                "DeepAvailabilityMiddleware requires at least one "
                "predicate; instantiate only when tools declare "
                "``available_when``."
            )
        self._predicates: dict[str, str] = dict(predicates)

    @property
    def name(self) -> str:
        return "DeepAvailabilityMiddleware"

    # ── Hook implementations ────────────────────────────────────────────

    def wrap_model_call(
        self,
        request: "ModelRequest",
        handler: Callable[["ModelRequest"], "ModelResponse"],
    ) -> "ModelResponse":
        request.tools = self._filter(request.tools, request.state)
        return handler(request)

    async def awrap_model_call(
        self,
        request: "ModelRequest",
        handler: Callable[["ModelRequest"], Any],
    ) -> Any:
        request.tools = self._filter(request.tools, request.state)
        return await handler(request)

    # ── Internals ───────────────────────────────────────────────────────

    def _filter(self, tools: list, state: Any) -> list:
        if not tools:
            return tools

        state_dict = self._coerce_state(state)
        filtered: list = []
        for tool in tools:
            name = self._tool_name(tool)
            predicate = self._predicates.get(name) if name else None
            if predicate is None:
                filtered.append(tool)
                continue
            if evaluate_availability(predicate, state_dict):
                filtered.append(tool)
            else:
                logger.debug(
                    "available_when filtered tool %r (predicate=%r)",
                    name,
                    predicate,
                )
        return filtered

    @staticmethod
    def _tool_name(tool: Any) -> str | None:
        """Extract the tool name from either shape ``request.tools`` carries.

        LangChain passes tools as ``BaseTool`` instances (``.name``) or
        pre-rendered OpenAI function specs
        (``{"type": "function", "function": {"name": ...}}``).
        """
        name = getattr(tool, "name", None)
        if isinstance(name, str):
            return name
        if isinstance(tool, dict):
            fn = tool.get("function") if isinstance(tool.get("function"), dict) else None
            if fn and isinstance(fn.get("name"), str):
                return fn["name"]
            if isinstance(tool.get("name"), str):
                return tool["name"]
        return None

    @staticmethod
    def _coerce_state(state: Any) -> dict[str, Any]:
        """Normalize agent state to a plain dict.

        LangChain may pass a ``dict``, a Pydantic-flavored state
        object, or a custom class depending on how the agent was
        built. The shared evaluator wants dict-like semantics, so we
        unwrap up front.
        """
        if isinstance(state, dict):
            return state
        if hasattr(state, "model_dump"):
            try:
                return state.model_dump()  # type: ignore[no-any-return]
            except Exception:
                pass
        if hasattr(state, "__dict__"):
            return dict(state.__dict__)
        return {}


def build_availability_middleware(
    available_when: dict[str, str] | None,
    client_tools: "list[ClientToolConfig] | None" = None,
) -> DeepAvailabilityMiddleware | None:
    """Construct the middleware from YAML inputs.

    Merges two sources of predicates:

      * ``available_when`` — the top-level cross-backend map on
        ``AgentConfig``. Keys are tool names (component class names
        for ``ui_tools``; tool ``name`` field for ``client_tools``).

      * ``client_tools`` — per-entry ``available_when`` field on each
        ``ClientToolConfig``. A compact form for declaring gating
        alongside the tool itself.

    When both name the same tool, the top-level ``available_when``
    map wins (explicit override). Returns ``None`` if no predicates
    are declared anywhere — callers should skip attaching the
    middleware in that case to keep the model-call hot path zero-
    overhead for agents that don't use the feature.
    """
    predicates: dict[str, str] = {}

    # Per-ClientToolConfig predicates first (lower priority).
    if client_tools:
        for spec in client_tools:
            pred = getattr(spec, "available_when", None)
            if pred:
                predicates[spec.name] = pred

    # Top-level cross-backend map (higher priority — overrides above).
    if available_when:
        predicates.update(available_when)

    if not predicates:
        return None
    return DeepAvailabilityMiddleware(predicates)
