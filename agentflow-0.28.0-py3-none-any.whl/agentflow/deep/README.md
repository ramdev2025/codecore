# AgentFlow Deep

**YAML-driven autonomous agents on [DeepAgents](https://github.com/langchain-ai/deepagents).**

Second backend of AgentFlow, alongside `workflows` (LangGraph), `sk` (Semantic Kernel), `cas` (Claude Agent SDK), `oai` (OpenAI Agents SDK), and `agent-framework` (Microsoft Agent Framework). Install with `pip install agentflow[deep]` (or `pip install agentflow[deepagents]` — same closure).

> **Status: stable.** Powers long-horizon coding / research agents that plan via `write_todos` and decompose with subagents.

---

## When to reach for deep

DeepAgents is the framework for agents that **plan** and **delegate**:

- **Planning loop** — the agent maintains a TODO list and ticks items off as it goes (`write_todos` is a built-in tool).
- **Subagents** — the main agent dispatches a `task` to a specialist subagent (researcher, coder, reviewer); each subagent has its own system prompt and tool list.
- **File-system context** — built-in `read_file` / `write_file` / `edit_file` tools backed by a virtual filesystem (or your real workdir via `--workdir`).
- **TUI by default** — `agentflow` with no query opens a Textual-based TUI; `--no-tui` falls back to the same streaming CLI as the other backends.

If your problem is "answer one question," reach for `cas`, `oai`, or `agent-framework`. If it's "plan and execute a multi-step task with files," deep is the right fit.

---

## Supported features

| Feature | YAML surface | Notes |
| --- | --- | --- |
| Main agent + subagents | `agent:` + `subagents:` | Each subagent is its own complete agent definition |
| Built-in tools | always available | `write_todos` (planning), `read_file`, `write_file`, `edit_file`, `task` (subagent dispatch) |
| Custom Python plugins | `tools:` | `@tool`-decorated modules; subagent-scoped tool lists are supported |
| LLM providers | `agent.llm.provider` | `anthropic`, `openai`, `azure_openai` (RBAC) |
| Skills | `skills:` | Reusable behavioural fragments referenced from `agent.system_prompt` |
| Memory sources | `memory_sources:` | Document stores plumbed in as RAG context |
| MCP servers | `mcp_servers:` | stdio / HTTP transports; subagent-scoped MCP available |
| Persistence | `--persistence` / `AGENTFLOW_PERSISTENCE` | LangGraph checkpointer (SQLite / Postgres). Deploy-time concern — not in YAML |
| Filesystem backend | `--workdir` | Virtual or real filesystem rooted at the chosen directory |
| TUI | default with no query | Textual app; type `quit` or Ctrl-C to exit |
| OpenTelemetry tracing | `OTEL_TRACES_ENABLED=true` | Per-tool + per-subagent spans, `gen_ai.*` semconv |
| AES-GCM encryption at rest | `AGENTFLOW_ENCRYPTION_KEY` | Same convention as other backends |
| CLI streaming | tokens / tool calls / planning checklists | See [`docs/CLI_REFERENCE.md`](docs/CLI_REFERENCE.md) |
| `--output ndjson` | machine-readable event stream | One JSON event per line; schema in `agentflow.cli.events` |

---

## Minimal example

```yaml
backend: deep

metadata:
  version: "1.0"
  name: research-agent

agent:
  system_prompt: |
    You are a research assistant. Plan with write_todos, then dispatch
    specialised subagents for each step.
  llm:
    provider: anthropic
    config:
      model: claude-sonnet-4-20250514
      api_key: ${ANTHROPIC_API_KEY}

subagents:
  - name: researcher
    description: "Looks up facts and summarises sources."
    system_prompt: |
      Use web tools and the project filesystem. Cite sources.
  - name: writer
    description: "Drafts the final report."
    system_prompt: |
      Use the researcher's notes from the filesystem. Concise prose.

middleware:
  - type: prompt_caching
```

Persistence is configured at deploy time, not in YAML — `deep`
defaults to SQLite at `.agentflow/deep_checkpoints.db`. Override via
the unified CLI or env vars:

```bash
# Custom SQLite path
agentflow --persistence sqlite --db-path /data/deep.db "your task"

# Postgres for multi-instance deployments
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
agentflow "your task"
```

Run with the unified CLI:

```bash
agentflow "investigate why the build is slow"          # opens the TUI
agentflow --no-tui "investigate why the build is slow"  # plain streaming output
agentflow --workdir ./project --interactive             # REPL with shared filesystem
agentflow --output ndjson "your task" > events.ndjson
```

---

## Documentation

- [`docs/index.md`](docs/index.md) — overview and installation
- [`docs/GETTING_STARTED.md`](docs/GETTING_STARTED.md) — first agent walkthrough
- [`docs/YAML_REFERENCE.md`](docs/YAML_REFERENCE.md) — full YAML reference
- [`docs/CLI_REFERENCE.md`](docs/CLI_REFERENCE.md) — CLI flags, streaming output, `--output ndjson` schema
- [`docs/SUBAGENTS.md`](docs/SUBAGENTS.md) — subagent dispatch patterns
- [`docs/CUSTOM_TOOLS.md`](docs/CUSTOM_TOOLS.md) — `@tool`-decorated Python plugins
- [`docs/SKILLS.md`](docs/SKILLS.md) — reusable behaviour fragments
- [`docs/PERSISTENCE.md`](docs/PERSISTENCE.md) — checkpointer config, thread resume, `agentflow-threads`
- [`docs/MCP.md`](docs/MCP.md) — MCP server integration
- [`docs/MIDDLEWARE.md`](docs/MIDDLEWARE.md) — middleware tier (prompt caching, etc.)
- [`docs/LLM_PROVIDERS.md`](docs/LLM_PROVIDERS.md) — Anthropic / OpenAI / Azure setup
- [`docs/TELEMETRY.md`](docs/TELEMETRY.md) — OpenTelemetry tracing
- [`docs/TUTORIALS.md`](docs/TUTORIALS.md) — hands-on walkthroughs

Sibling backends: [`workflows/`](../workflows/) · [`sk/`](../sk/) · [`cas/`](../cas/) · [`oai/`](../oai/) · [`maf/`](../maf/)

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See the root [LICENSE](../../../LICENSE) for complete terms.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
