"""MAF adapter for the cross-backend ``ui_tools`` vocabulary.

Takes a :class:`agentflow.genui.UIToolsConfig` (declared in YAML as
``agent.ui_tools``), scans the referenced module for
``@ui_component``-decorated fetchers, and returns a list of MAF
``FunctionTool`` instances. Each wrapped tool, when invoked, calls the
original fetcher and returns the result as
``agent_framework_ag_ui.state_update(...)`` — Microsoft's helper that
splits the LLM-side ``text`` from the frontend-side ``tool_result``.

The frontend (CopilotKit) keys off the ``tool_result.component`` field
and renders the matching React component with the rest of the dict as
props. This is the MAF-shaped equivalent of the workflows backend's
``__component__`` marker pattern — same intent, different wire shape
because Microsoft's bridge has a richer primitive.

Why no per-call state field
---------------------------

``state_update`` also supports merging into AG-UI shared state via its
``state=...`` parameter. That's intentionally not used here: ``ui_tools``
in the cross-backend YAML expresses *rendering*, not state mutation.
Apps that want to drive ``useCoAgentState`` should add explicit state-
mutating tools, not piggyback on render fetchers (where the semantics
would be ambiguous).
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
import logging
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from agentflow.genui import UIToolsConfig, discover_ui_components, get_component_class

logger = logging.getLogger(__name__)


def resolve_ui_tools(config: UIToolsConfig | None) -> list[Any]:
    """Build a list of MAF ``FunctionTool`` instances from a ``UIToolsConfig``.

    Returns an empty list when ``config`` is ``None`` so callers can
    unconditionally extend their tool list with the result.

    Args:
        config: The parsed ``ui_tools:`` YAML block. ``None`` is treated
            as "no ui_tools declared" — empty list returned.

    Returns:
        List of MAF ``FunctionTool`` objects ready to attach to an agent.

    Raises:
        ImportError: If ``agent_framework`` or ``agent_framework_ag_ui``
            isn't installed. These are MAF-stack deps; user got here by
            declaring ``ui_tools`` on a MAF agent so the error message
            points at the install path.
        ValueError: If ``config.use`` names a component the module
            doesn't expose (typo-safe — fail at construction, not at
            first call).
    """
    if config is None:
        return []

    discovered = discover_ui_components(config.module)
    if config.use is not None:
        missing = sorted(set(config.use) - set(discovered.keys()))
        if missing:
            available = sorted(discovered.keys())
            raise ValueError(
                f"ui_tools.use names component(s) not found in "
                f"{config.module!r}: {missing}. Available: {available}"
            )
        discovered = {n: discovered[n] for n in config.use}

    return [_wrap_for_maf(name, fetcher) for name, fetcher in discovered.items()]


def _wrap_for_maf(component_name: str, fetcher: Callable[..., Any]) -> Any:
    """Wrap a ``@ui_component`` fetcher as a MAF ``FunctionTool``.

    The wrapper preserves the fetcher's signature (so MAF's tool
    introspection generates the correct schema for the LLM), validates
    the return against the declared Pydantic class, and returns a
    ``state_update(text=..., tool_result={"component": name, **props})``.

    Both sync and async fetchers are supported; ``inspect.iscoroutinefunction``
    decides which wrapper to build.

    Tool name vs component name
    ---------------------------

    The tool is named after the **fetcher function** (``fetcher.__name__``),
    not the component class. This matters when the AG-UI client (CopilotKit
    v2) advertises its own components as frontend tools via
    ``useComponent({ name: "X" })`` — those land in ``RunAgentInput.tools``
    and get merged with the server tools by Microsoft's bridge.

    If the server tool were also named ``X`` (the class name), the merge
    would raise ``ValueError("Duplicate tool name 'X'")``. Separating the
    two namespaces — tool name = ``get_portfolio_overview`` (verb), component
    name = ``PortfolioOverview`` (noun) — avoids the conflict. The
    ``tool_result.component`` field still carries the class name so the
    frontend's ``useComponent`` registry can dispatch the render.
    """
    component_cls = get_component_class(fetcher)
    if component_cls is None:  # pragma: no cover — discover_ui_components guards
        raise RuntimeError(f"{fetcher} is not @ui_component-decorated")

    # Lazy imports — agent_framework deps don't load until the wrapper is
    # actually built (matters when this module gets parsed in a test env
    # that doesn't have the [agent-framework] extra).
    from agent_framework import tool as af_tool
    from agent_framework_ag_ui import state_update

    tool_name = fetcher.__name__
    description = (fetcher.__doc__ or f"Render the {component_name} component.").strip()

    is_async = asyncio.iscoroutinefunction(fetcher)

    if is_async:

        @af_tool(name=tool_name, description=description)
        @functools.wraps(fetcher)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            result = await fetcher(*args, **kwargs)
            return _to_state_update(component_name, component_cls, result, state_update)

        # Restore the original signature so MAF's schema introspection sees
        # the fetcher's typed parameters, not (*args, **kwargs).
        async_wrapper.__signature__ = inspect.signature(fetcher)  # type: ignore[attr-defined]
        # Tag with the component class name so the availability filter
        # in ``agentflow.maf.availability`` can map predicates (keyed by
        # class name) to tools (named after the fetcher function).
        async_wrapper._agentflow_component_name = component_name  # type: ignore[attr-defined]
        return async_wrapper

    @af_tool(name=tool_name, description=description)
    @functools.wraps(fetcher)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        result = fetcher(*args, **kwargs)
        return _to_state_update(component_name, component_cls, result, state_update)

    sync_wrapper.__signature__ = inspect.signature(fetcher)  # type: ignore[attr-defined]
    sync_wrapper._agentflow_component_name = component_name  # type: ignore[attr-defined]
    return sync_wrapper


def _to_state_update(
    component_name: str,
    component_cls: type[BaseModel],
    result: Any,
    state_update: Callable[..., Any],
) -> Any:
    """Validate the fetcher's return and wrap it as a ``state_update`` payload.

    Accepts either a ``component_cls`` instance or a dict (validated against
    the class). Anything else fails closed with a ToolError-style message —
    the LLM sees the error string and can re-plan or apologise.
    """
    if isinstance(result, component_cls):
        instance = result
    elif isinstance(result, dict):
        try:
            instance = component_cls.model_validate(result)
        except Exception as exc:
            return f"[{component_name} failed] dict didn't validate: {exc}"
    else:
        return (
            f"[{component_name} failed] fetcher must return a {component_name} "
            f"instance or a dict, got {type(result).__name__}"
        )

    props = instance.model_dump()
    return state_update(
        # The LLM sees the props as JSON — same level of detail it'd get
        # from the workflows backend's ``__component__``-marked dict.
        # Keeps follow-up reasoning informed.
        text=json.dumps(props),
        # The frontend gets a clean structured payload with the component
        # name for CopilotKit's useComponent / similar registries to key
        # off. Microsoft's bridge emits this verbatim as the AG-UI
        # ``ToolCallResultEvent.content``.
        tool_result={"component": component_name, **props},
    )
