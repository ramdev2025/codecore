"""AG-UI harness for the Microsoft Agent Framework backend.

AgentFlow's job here is **configuration**, not bridging. Microsoft ships
its own AG-UI bridge (``agent-framework-ag-ui``) that handles the wire
protocol, event translation, the HITL approval registry, state
synchronization, and SSE framing. AgentFlow's contribution is the YAML
side: load the workflow definition, build the MAF agent (with its tools,
middleware filters, and persistence already wired by the existing MAF
builder), and hand the configured agent to the upstream bridge.

Usage::

    from fastapi import FastAPI
    from agentflow.maf.agui import build_agui

    app = FastAPI()
    build_agui(app, yaml_path="workflow.yaml", path="/agui")

After the call, the app serves the AG-UI protocol at ``/agui`` and a
CopilotKit-compatible frontend can connect directly.

What this module deliberately does NOT do:

* It does not implement AG-UI's wire protocol or any of its event types.
  Those live in ``agent-framework-ag-ui``.
* It does not own HITL state. The upstream bridge maintains a pending-
  approval registry; AgentFlow's role ends at agent construction.
* It does not run an ASGI server. The caller owns the FastAPI app and
  whatever process serves it.

This is the harness-configurator pattern: AgentFlow translates YAML into
a framework-native agent, the framework's own AG-UI integration carries
the protocol.
"""

from __future__ import annotations

import json
from contextvars import ContextVar
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

    from fastapi import FastAPI
    from fastapi.params import Depends


_EVENT_SHAPE_FIX_APPLIED = False

# Inbound thread id captured by ``_CaptureThreadIdASGIMiddleware`` from the
# request body. The encoder patch reads this contextvar and restores it onto
# RUN_STARTED / RUN_FINISHED events whose ``thread_id`` Microsoft's bridge
# replaces with the OpenAI Responses ``conversation_id`` (breaks CopilotKit's
# thread binding — see :func:`_apply_event_shape_fix`).
_INBOUND_THREAD_ID: ContextVar[str | None] = ContextVar(
    "agentflow_maf_agui_inbound_thread_id", default=None
)


def _merge_consecutive_assistant_tool_calls(
    messages: list[dict],
) -> list[dict] | None:
    """Merge consecutive ``role:"assistant"`` messages whose only payload is
    ``toolCalls`` into a single assistant message.

    CopilotKit emits one assistant message per parallel tool call instead
    of one message with N tool calls in its ``toolCalls`` array. Microsoft's
    bridge tracks pending tool ids per-message and overwrites instead of
    unioning, so the resulting OpenAI Responses input has unpaired
    ``function_call`` items and the API returns 400. Pre-merging here
    matches what OpenAI's Responses API actually expects.

    Returns the merged list, or ``None`` if no merging was needed (so the
    caller can skip re-serializing the body).
    """
    if not messages or not isinstance(messages, list):
        return None

    merged: list[dict] = []
    merged_anything = False
    for msg in messages:
        if not isinstance(msg, dict):
            merged.append(msg)
            continue
        is_assistant_tool_only = (
            msg.get("role") == "assistant"
            and msg.get("toolCalls")
            and not (msg.get("content") or "").strip()
        )
        if (
            is_assistant_tool_only
            and merged
            and isinstance(merged[-1], dict)
            and merged[-1].get("role") == "assistant"
            and merged[-1].get("toolCalls")
            and not (merged[-1].get("content") or "").strip()
        ):
            # Extend the previous assistant message's toolCalls with this
            # one's. Existing fields like ``id`` / ``parentMessageId`` are
            # preserved from the first message in the run (the bridge
            # doesn't key on them for tool-output pairing).
            prev_tool_calls = list(merged[-1].get("toolCalls") or [])
            prev_tool_calls.extend(msg.get("toolCalls") or [])
            merged[-1] = {**merged[-1], "toolCalls": prev_tool_calls}
            merged_anything = True
            continue
        merged.append(msg)
    return merged if merged_anything else None


class _CaptureThreadIdASGIMiddleware:
    """ASGI middleware that peeks the inbound ``threadId`` and sets a
    contextvar the encoder patch can read.

    Uses pure ASGI (not Starlette's ``BaseHTTPMiddleware``) so the
    contextvar set here is visible to the downstream streaming response
    — ``BaseHTTPMiddleware`` runs the response generator in a separate
    task and contextvars don't propagate across the task boundary.
    """

    def __init__(self, app: Any, path: str) -> None:
        self.app = app
        # Match both the exact mount path and its trailing-slash variant.
        # CopilotKit's ``HttpAgent`` posts to ``<base>/`` (trailing slash),
        # while curl / Postman typically hit the bare path. If we only
        # matched one, the other would bypass the merge + thread-id capture
        # — and the bypassed shape is exactly what triggers OpenAI's
        # ``400: No tool output found for function call X``.
        bare = path.rstrip("/")
        self._paths = {bare, bare + "/"}

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if (
            scope.get("type") != "http"
            or scope.get("method") != "POST"
            or scope.get("path") not in self._paths
        ):
            await self.app(scope, receive, send)
            return

        # Buffer the full body so we can both peek it and replay it
        # to the downstream handler.
        chunks: list[bytes] = []
        more_body = True
        while more_body:
            msg = await receive()
            chunks.append(msg.get("body", b""))
            more_body = msg.get("more_body", False)
        body = b"".join(chunks)

        try:
            data = json.loads(body)
            tid = data.get("threadId") or data.get("thread_id")
            if isinstance(tid, str) and tid:
                _INBOUND_THREAD_ID.set(tid)
            # Merge consecutive assistant-tool-call messages. CopilotKit
            # splits parallel tool calls into N separate assistant
            # messages (one tool_call per message); Microsoft's bridge
            # then OVERWRITES its ``pending_tool_call_ids`` set on each
            # assistant message instead of unioning, so when the matching
            # tool results arrive only the LAST id is recognized and the
            # earlier tool messages are silently dropped. OpenAI then
            # returns ``400: No tool output found for function call X``
            # because the sanitized history has N function_calls but
            # only one function_call_output. Pre-merging the splits
            # makes the bridge sanitizer track all the ids correctly.
            merged = _merge_consecutive_assistant_tool_calls(data.get("messages") or [])
            if merged is not None:
                data["messages"] = merged
                body = json.dumps(data).encode("utf-8")
                # Rewrite Content-Length to match the new body size —
                # otherwise downstream HTTP frameworks reading the
                # header (rather than the body stream) will under-read
                # or hang.
                new_len = str(len(body)).encode("ascii")
                scope["headers"] = [
                    (name, new_len) if name.lower() == b"content-length" else (name, value)
                    for name, value in scope.get("headers") or []
                ]
        except Exception:
            pass  # malformed body — let the downstream handler return the 400/422

        replayed = False

        async def replay_receive() -> dict:
            nonlocal replayed
            if not replayed:
                replayed = True
                return {"type": "http.request", "body": body, "more_body": False}
            # After the body's been delivered once, defer to the real
            # receive — the streaming handler reads it to detect client
            # disconnects. Returning a synthetic ``http.disconnect`` here
            # would abort the SSE stream as soon as the handler started.
            return await receive()

        await self.app(scope, replay_receive, send)


def _apply_event_shape_fix() -> None:
    """Patch the AG-UI event encoder for CopilotKit-v2 compatibility.

    Microsoft's bridge (``agent_framework_ag_ui``) and CopilotKit v2's
    ``CopilotChat`` disagree on assistant-message lifecycle in five
    places — each one strands the LLM's commentary in a tool-using turn:

      * **Two TEXT_MESSAGE pairs per tool-using turn.** The bridge
        opens ``TEXT_MESSAGE_START`` unconditionally at the start of
        every LLM call. A turn whose only output was tool calls
        produces an *empty* ``TEXT_MESSAGE`` pair (no content
        between START and END); the follow-up commentary opens a
        second ``TEXT_MESSAGE`` pair. CopilotKit renders the first
        pair as the assistant bubble (with the tool calls / typed
        components inside) and silently drops the second pair's
        text content.

      * **MESSAGES_SNAPSHOT id mismatch.** The bridge emits a final
        ``MessagesSnapshotEvent`` whose ``messageId``s do not match
        what was streamed in ``TEXT_MESSAGE_*`` events. CopilotKit
        reconciles to the snapshot and discards the streamed
        commentary as orphaned.

      * **TOOL_CALL_START.parentMessageId mismatch.** The bridge sets
        ``parent_message_id`` on tool calls to the responses-API
        message id that *would* have led the assistant turn — but
        the actual assistant message id (the one streaming the
        post-tool commentary) is different. CopilotKit can't bind
        the tool calls to a turn it never saw, so the commentary
        never gets rendered and the chat input disappears (the run
        looks unresolved). Clearing the field lets CopilotKit bind
        the tools to whichever assistant message *does* arrive.

    Workflows' own custom AG-UI adapter avoids all three — it defers
    ``TEXT_MESSAGE_START`` until first content, never emits
    ``MESSAGES_SNAPSHOT``, and only sets ``parentMessageId`` when an
    assistant message is already open. This patch replicates that
    wire shape on top of Microsoft's bridge so the same CopilotKit
    frontend renders correctly with either backend.

    The patch is idempotent (only applied once per process) and global
    on ``ag_ui.encoder.EventEncoder`` — every per-request encoder
    instance inherits the new behavior via its own ``_pending_start``
    instance attribute.

    To skip the patch (e.g. when wiring a different AG-UI client that
    already handles the upstream shape correctly), pass
    ``apply_event_shape_fix=False`` to :func:`build_agui`.

    TODO: remove when either Microsoft's bridge stops emitting empty
    ``TEXT_MESSAGE`` pairs or CopilotKit starts rendering multi-message
    assistant turns.
    """
    global _EVENT_SHAPE_FIX_APPLIED
    if _EVENT_SHAPE_FIX_APPLIED:
        return

    import ag_ui.encoder as _agui_encoder

    _orig_encode = _agui_encoder.EventEncoder.encode

    def _encode_lazy_start(self, event):
        et_attr = getattr(event, "type", None)
        et = str(et_attr).rsplit(".", 1)[-1] if et_attr is not None else None

        # Drop snapshot — its messageIds don't align with streamed events.
        if et == "MESSAGES_SNAPSHOT":
            return ""

        if et == "TEXT_MESSAGE_START":
            # Buffer; don't emit until content arrives.
            self._pending_start = event
            return ""

        if et == "TEXT_MESSAGE_CONTENT":
            prefix = ""
            pending = getattr(self, "_pending_start", None)
            if pending is not None:
                prefix = _orig_encode(self, pending)
                self._pending_start = None
            return prefix + _orig_encode(self, event)

        if et == "TEXT_MESSAGE_END":
            if getattr(self, "_pending_start", None) is not None:
                # No content was emitted — drop the empty lifecycle entirely.
                self._pending_start = None
                return ""
            return _orig_encode(self, event)

        if et == "TOOL_CALL_START":
            tc_id = getattr(event, "tool_call_id", None)
            # Defensive lifecycle dedupe. Microsoft's bridge can emit
            # the full START/ARGS/END/RESULT trio twice for the same
            # ``tool_call_id`` on multi-LLM-turn runs (the agent loops,
            # the bridge re-emits the same call's lifecycle the second
            # time around). CopilotKit v2 strictly enforces a single
            # ``{START → END}`` per id and aborts the run with either::
            #
            #     AGUIError: Cannot send 'TOOL_CALL_START' event:
            #     A tool call with ID 'X' is already in progress.
            #
            #   or, if we drop the duplicate START but let the
            #   duplicate END through::
            #
            #     AGUIError: Cannot send 'TOOL_CALL_END' event:
            #     No active tool call found with ID 'X'.
            #
            # Track per-encoder-instance (each request gets a fresh
            # encoder, so this can't bleed across requests) both the
            # currently-open ids and ids that have already completed.
            # Drop START for any id we've already seen open or closed;
            # drop ARGS/END for any id whose START wasn't emitted.
            open_ids = getattr(self, "_open_tool_call_ids", None)
            if open_ids is None:
                open_ids = set()
                self._open_tool_call_ids = open_ids
            completed_ids = getattr(self, "_completed_tool_call_ids", None)
            if completed_ids is None:
                completed_ids = set()
                self._completed_tool_call_ids = completed_ids
            if tc_id and (tc_id in open_ids or tc_id in completed_ids):
                return ""
            if tc_id:
                open_ids.add(tc_id)
            # Strip ``parent_message_id`` from TOOL_CALL_START. Microsoft's
            # bridge sets it to the responses-API message id that *would*
            # have led the assistant turn — but the actual assistant
            # message CopilotKit eventually receives (the post-tool
            # commentary) carries a different id. The mismatch leaves
            # CopilotKit unable to bind the tool calls to the assistant's
            # turn. Clearing it lets CopilotKit bind the tools to
            # whichever assistant message *does* arrive.
            if getattr(event, "parent_message_id", None) is not None:
                event = event.model_copy(update={"parent_message_id": None})
            return _orig_encode(self, event)

        if et == "TOOL_CALL_ARGS":
            # Only emit ARGS for a tool call whose START we let through —
            # otherwise CopilotKit sees args for an unknown id (since we
            # may have suppressed a duplicate START upstream).
            tc_id = getattr(event, "tool_call_id", None)
            open_ids = getattr(self, "_open_tool_call_ids", None)
            if not open_ids or tc_id not in open_ids:
                return ""
            return _orig_encode(self, event)

        if et == "TOOL_CALL_END":
            # Only emit END when there's a matching open START. Microsoft's
            # bridge emits the full START/ARGS/END trio twice on multi-turn
            # runs; we drop the second START up above, and the second END
            # has to go with it — otherwise CopilotKit errors with:
            #
            #     AGUIError: Cannot send 'TOOL_CALL_END' event:
            #     No active tool call found with ID 'X'.
            tc_id = getattr(event, "tool_call_id", None)
            open_ids = getattr(self, "_open_tool_call_ids", None)
            completed_ids = getattr(self, "_completed_tool_call_ids", None)
            if not open_ids or tc_id not in open_ids:
                return ""
            open_ids.discard(tc_id)
            if completed_ids is not None and tc_id:
                completed_ids.add(tc_id)
            return _orig_encode(self, event)

        if et == "TOOL_CALL_RESULT":
            # Only emit RESULT once per tool_call_id. The bridge can
            # re-emit on multi-turn replay and CopilotKit may render a
            # duplicate card or trip its lifecycle validator.
            tc_id = getattr(event, "tool_call_id", None)
            emitted_results = getattr(self, "_emitted_result_ids", None)
            if emitted_results is None:
                emitted_results = set()
                self._emitted_result_ids = emitted_results
            if tc_id and tc_id in emitted_results:
                return ""
            if tc_id:
                emitted_results.add(tc_id)
            return _orig_encode(self, event)

        if et in ("RUN_STARTED", "RUN_FINISHED"):
            # Restore the inbound ``thread_id``. Microsoft's bridge
            # (``_agent_run.py`` :func:`_run_agent`) replaces the
            # user-supplied ``thread_id`` with the OpenAI Responses
            # ``conversation_id`` once the first update streams in. That
            # breaks every AG-UI client that expects the server to echo
            # back the threadId it sent — CopilotKit can't bind the
            # streaming events to its thread store, so the assistant
            # commentary never lands in the chat surface and the input
            # box never re-enables (the run looks unresolved).
            inbound = _INBOUND_THREAD_ID.get()
            if inbound and getattr(event, "thread_id", None) != inbound:
                event = event.model_copy(update={"thread_id": inbound})
            return _orig_encode(self, event)

        return _orig_encode(self, event)

    _agui_encoder.EventEncoder.encode = _encode_lazy_start
    _EVENT_SHAPE_FIX_APPLIED = True


def build_agui(
    app: FastAPI,
    yaml_path: str,
    *,
    path: str = "/",
    state_schema: Any | None = None,
    predict_state_config: dict[str, dict[str, str]] | None = None,
    default_state: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    dependencies: Sequence[Depends] | None = None,
    apply_event_shape_fix: bool = True,
    build_state: dict[str, Any] | None = None,
) -> None:
    """Mount a YAML-defined MAF agent as an AG-UI endpoint on a FastAPI app.

    Loads ``yaml_path``, builds the MAF agent (or workflow) via the existing
    :class:`agentflow.maf.core.builder.MafAgentBuilder`, and hands the result
    to Microsoft's ``add_agent_framework_fastapi_endpoint``. After this call,
    the FastAPI app serves AG-UI at ``path``.

    Args:
        app: The FastAPI application to mount on. The caller owns the app
            and its lifecycle.
        yaml_path: Path to the workflow.yaml declaring the MAF agent.
        path: Endpoint path. Defaults to ``"/"``; pass something like
            ``"/agui"`` when mounting alongside other routes.
        state_schema: Optional state schema for shared state with the
            frontend. Accepts a dict or a Pydantic model class. See the
            upstream package's documentation for the supported shapes.
        predict_state_config: Optional predictive state update config.
            ``{"state_key": {"tool": "tool_name", "tool_argument": "arg"}}``.
        default_state: Optional initial state to seed when the client does
            not provide state keys.
        tags: OpenAPI tags for endpoint categorization. Defaults to
            ``["AG-UI"]`` upstream.
        dependencies: FastAPI dependencies for auth / rate-limiting / etc.
            Run before the endpoint handler.
        apply_event_shape_fix: Whether to apply the AG-UI event-encoder
            patch that aligns Microsoft's bridge wire shape with CopilotKit
            v2's chat-rendering assumptions (defers ``TEXT_MESSAGE_START``
            until first content, drops the trailing ``MESSAGES_SNAPSHOT``).
            Default ``True`` — nearly every AG-UI consumer wants this.
            Set ``False`` only when wiring a client that handles the
            upstream shape correctly on its own. See
            :func:`_apply_event_shape_fix` for the gory detail.
        build_state: Deployment state for evaluating ``available_when``
            predicates at agent-construction time. Tools whose
            predicate is falsy against this state are excluded from the
            agent's bound tool list permanently — the LLM never sees
            them. ``None`` (default) is treated as an empty dict; any
            ``state.X``-style predicate evaluates to ``False``, so all
            gated tools are hidden. Typical usage::

                build_agui(
                    app, "workflow.yaml",
                    build_state={"user_role": os.environ.get("USER_ROLE", "analyst")},
                )

    Raises:
        ImportError: If ``agent-framework-ag-ui`` is not installed. Install
            with ``pip install agentflow[agent-framework]`` (which now
            pulls the bridge as a transitive dep).
    """
    try:
        from agent_framework_ag_ui import add_agent_framework_fastapi_endpoint
    except ImportError as exc:  # pragma: no cover — covered by import-error test path
        raise ImportError(
            "agent-framework-ag-ui is required to serve AG-UI from the MAF "
            "backend. Install via `pip install agentflow[agent-framework]`."
        ) from exc

    if apply_event_shape_fix:
        _apply_event_shape_fix()

    from .core.builder import MafAgentBuilder

    builder = MafAgentBuilder.from_yaml(yaml_path, build_state=build_state)
    runner = builder.build()

    # Either mode of the MafRunner satisfies the upstream's accepted union:
    # ``SupportsAgentRun | AgentFrameworkAgent | Workflow | AgentFrameworkWorkflow``.
    # The agent-mode ``starting_agent`` is a real MAF Agent (which is a
    # ``SupportsAgentRun``); workflow-mode ``workflow`` is a MAF Workflow.
    target: Any
    if runner.mode == "agent":
        if runner.starting_agent is None:
            raise RuntimeError(
                f"MafRunner from {yaml_path!r} reports agent mode but "
                "starting_agent is None — check the YAML defines an agent."
            )
        target = runner.starting_agent
    else:
        if runner.workflow is None:
            raise RuntimeError(
                f"MafRunner from {yaml_path!r} reports workflow mode but "
                "workflow is None — check the YAML defines a workflow."
            )
        target = runner.workflow

    add_agent_framework_fastapi_endpoint(
        app,
        target,
        path=path,
        state_schema=state_schema,
        predict_state_config=predict_state_config,
        default_state=default_state,
        tags=tags,
        dependencies=dependencies,
    )

    # Peel the inbound ``threadId`` off the request body so the encoder
    # patch can restore it onto RUN_STARTED / RUN_FINISHED. Skipped when
    # ``apply_event_shape_fix`` is off — the encoder patch is what
    # actually does the substitution; the middleware alone is a no-op.
    if apply_event_shape_fix:
        app.add_middleware(_CaptureThreadIdASGIMiddleware, path=path)
