"""Compile cross-backend guards / optimizers / observers into MAF middleware.

The cross-backend vocabulary (``guards:`` / ``optimizers:`` / ``observers:``)
is identical to SK / CAS / OAI. On MAF each entry compiles to one of three
middleware instances (:class:`AgentMiddleware` / :class:`ChatMiddleware` /
:class:`FunctionMiddleware`) that the builder attaches to the right layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional

from agentflow.maf.core.config_models import (
    GuardConfig,
    GuardType,
    ObserverConfig,
    ObserverType,
    OptimizerConfig,
    OptimizerType,
)
from agentflow.maf.filters import builtin


@dataclass
class CompiledMiddleware:
    """Bundle of MAF middleware instances produced by the compiler."""

    # Agent-level — wraps whole agent.run()
    agent_mw: List[Any] = field(default_factory=list)
    # Chat-level — wraps each LLM call
    chat_mw: List[Any] = field(default_factory=list)
    # Function-level — wraps each tool invocation
    function_mw: List[Any] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------


def compile_guards(
    guards: Optional[List[GuardConfig]], out: CompiledMiddleware
) -> None:
    if not guards:
        return
    for g in guards:
        cfg = g.config or {}

        if g.module and g.function:
            # Custom guard — user supplies a middleware class via
            # {module: ..., class_name: ...}  OR a predicate callable via
            # {module: ..., function: ...}. We accept the latter shape here
            # and wrap it as ChatMiddleware that runs before each LLM call.
            fn = builtin._resolve_callable(g.module, g.function)
            out.chat_mw.append(_wrap_predicate_as_chat_mw(fn))
            continue

        if g.type == GuardType.PII:
            out.chat_mw.append(
                builtin.make_pii_chat_middleware(patterns=cfg.get("patterns"))
            )
        elif g.type == GuardType.TOOL_CALL_LIMIT:
            out.function_mw.append(
                builtin.make_tool_call_limit_middleware(
                    max_calls=cfg.get("max_calls", 50)
                )
            )
        elif g.type == GuardType.MODEL_CALL_LIMIT:
            out.chat_mw.append(
                builtin.make_model_call_limit_middleware(
                    max_calls=cfg.get("max_calls", 100)
                )
            )
        elif g.type in (GuardType.INPUT_VALIDATION, GuardType.CONTENT_FILTER):
            raise ValueError(
                f"Guard type {g.type.value!r} requires 'module:' + 'function:' "
                f"— declare a custom predicate."
            )
        else:  # pragma: no cover — schema enforces enum
            raise ValueError(f"Unknown guard type: {g.type!r}")


# ---------------------------------------------------------------------------
# Optimizers
# ---------------------------------------------------------------------------


def compile_optimizers(
    optimizers: Optional[List[OptimizerConfig]], out: CompiledMiddleware
) -> None:
    if not optimizers:
        return
    for o in optimizers:
        cfg = o.config or {}
        if o.module and o.function:
            fn = builtin._resolve_callable(o.module, o.function)
            out.function_mw.append(_wrap_callable_as_function_mw(fn))
            continue

        if o.type == OptimizerType.TOOL_RETRY:
            out.function_mw.append(
                builtin.make_tool_retry_middleware(
                    max_retries=cfg.get("max_retries", 2),
                    initial_backoff_ms=cfg.get("initial_backoff_ms", 500),
                )
            )
        elif o.type == OptimizerType.SUMMARIZATION:
            # MAF has native ``CompactionStrategy`` options on Agent;
            # summarization-as-middleware is a no-op log entry so the
            # intent is visible in the compiled middleware list.
            out.agent_mw.append(_noop_agent_mw("summarization"))
        elif o.type == OptimizerType.PROMPT_CACHING:
            # Prompt caching is controlled via ``ModelSettings.prompt_cache_retention``
            # — already surfaced through the model_settings schema. No middleware.
            continue
        else:  # pragma: no cover
            raise ValueError(f"Unknown optimizer type: {o.type!r}")


# ---------------------------------------------------------------------------
# Observers
# ---------------------------------------------------------------------------


def compile_observers(
    observers: Optional[List[ObserverConfig]], out: CompiledMiddleware
) -> None:
    if not observers:
        return
    for obs in observers:
        cfg = obs.config or {}

        if obs.module and obs.function:
            fn = builtin._resolve_callable(obs.module, obs.function)
            out.function_mw.append(_wrap_callable_as_function_mw(fn))
            continue

        if obs.type == ObserverType.AUDIT_LOG:
            out.function_mw.append(builtin.make_audit_log_middleware())
        elif obs.type == ObserverType.COST_TRACKING:
            out.agent_mw.append(
                builtin.make_cost_tracking_middleware(
                    budget_limit=cfg.get("budget_limit")
                )
            )
        elif obs.type == ObserverType.LATENCY_TRACKING:
            out.function_mw.append(builtin.make_latency_tracking_middleware())
        else:  # pragma: no cover
            raise ValueError(f"Unknown observer type: {obs.type!r}")


# ---------------------------------------------------------------------------
# Top-level entry point
# ---------------------------------------------------------------------------


def compile_filters(
    guards: Optional[List[GuardConfig]] = None,
    optimizers: Optional[List[OptimizerConfig]] = None,
    observers: Optional[List[ObserverConfig]] = None,
) -> CompiledMiddleware:
    out = CompiledMiddleware()
    compile_guards(guards, out)
    compile_optimizers(optimizers, out)
    compile_observers(observers, out)
    return out


# ---------------------------------------------------------------------------
# Helpers for wrapping user-provided callables
# ---------------------------------------------------------------------------


def _wrap_callable_as_function_mw(fn: Any) -> Any:
    """Wrap a user function as ``FunctionMiddleware``.

    User function signature: ``async fn(tool_name, arguments, result)``.
    Called after the tool completes — exceptions are swallowed so buggy
    observers don't break the agent.
    """
    from agent_framework import FunctionMiddleware

    class _Wrapped(FunctionMiddleware):
        async def process(self, context, call_next):
            await call_next()
            try:
                tool_name = getattr(
                    getattr(context, "function", None), "name", "<unknown>"
                )
                args = getattr(context, "arguments", None)
                result = getattr(context, "result", None)
                maybe = fn(tool_name, args, result)
                if hasattr(maybe, "__await__"):
                    await maybe
            except Exception:
                pass

    return _Wrapped()


def _wrap_predicate_as_chat_mw(fn: Any) -> Any:
    """Wrap a user predicate as ``ChatMiddleware``.

    User predicate signature: ``async fn(messages) -> bool`` (True = trip).
    When True, the chat call is terminated.
    """
    from agent_framework import ChatMiddleware, MiddlewareTermination

    class _Wrapped(ChatMiddleware):
        async def process(self, context, call_next):
            tripped = fn(context.messages)
            if hasattr(tripped, "__await__"):
                tripped = await tripped
            if tripped:
                raise MiddlewareTermination("Custom guard tripped.")
            await call_next()

    return _Wrapped()


def _noop_agent_mw(label: str) -> Any:
    from agent_framework import AgentMiddleware

    class _Noop(AgentMiddleware):
        async def process(self, context, call_next):
            await call_next()

    _Noop.__name__ = f"_Noop_{label}"
    return _Noop()
