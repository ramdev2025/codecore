"""Built-in guard / optimizer / observer middleware for MAF.

Each factory returns a MAF middleware class instance
(``AgentMiddleware`` / ``ChatMiddleware`` / ``FunctionMiddleware``) that
will run for the corresponding lifecycle event when attached to an
``Agent`` or chat client.

OTel: MAF already emits ``invoke_agent`` / ``chat`` / ``execute_tool``
spans via its native instrumentation when ``configure_otel_providers()``
is called. Our observers add supplementary spans where we provide value
beyond MAF's defaults (e.g. a budget-check span on ``cost_tracking``).
"""

from __future__ import annotations

import logging
import re
import time
from collections import defaultdict
from typing import Any, Callable, Dict, List, Optional


# ---------------------------------------------------------------------------
# Loggers
# ---------------------------------------------------------------------------

_audit_log = logging.getLogger("agentflow.maf.audit")
_cost_log = logging.getLogger("agentflow.maf.cost")
_latency_log = logging.getLogger("agentflow.maf.latency")


def _tracer():
    from opentelemetry import trace

    return trace.get_tracer("agentflow.maf")


# ---------------------------------------------------------------------------
# GUARDS
# ---------------------------------------------------------------------------


def make_pii_chat_middleware(patterns: Optional[List[str]] = None):
    """Chat middleware that trips when PII matches in the input messages.

    MAF's ``ChatContext`` exposes the outgoing messages pre-LLM. We inspect
    them and raise a ``MiddlewareTermination`` when PII is found, which MAF
    propagates as an aborted chat.
    """
    from agent_framework import ChatMiddleware, MiddlewareTermination

    named = {
        "email": r"[\w\.-]+@[\w\.-]+",
        "phone": r"\b(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "credit_card": r"\b(?:\d[ -]*?){13,16}\b",
    }
    patterns = patterns or ["email", "phone", "ssn", "credit_card"]
    compiled = [re.compile(named.get(p, p)) for p in patterns]

    class _PiiGuard(ChatMiddleware):
        async def process(self, context, call_next):
            text = _messages_text(context.messages)
            matched = [p.pattern for p in compiled if p.search(text)]
            if matched:
                _audit_log.warning("pii_guard tripped: matched=%s", matched)
                raise MiddlewareTermination(
                    f"PII guard tripped (patterns: {matched}). "
                    "Request halted before LLM call."
                )
            await call_next()

    return _PiiGuard()


def make_tool_call_limit_middleware(max_calls: int = 50):
    """Function middleware counter — raises past ``max_calls``."""
    from agent_framework import FunctionMiddleware, MiddlewareTermination

    counter = {"n": 0}

    class _ToolLimit(FunctionMiddleware):
        async def process(self, context, call_next):
            counter["n"] += 1
            if counter["n"] > max_calls:
                raise MiddlewareTermination(
                    f"tool_call_limit reached ({max_calls}); agent stopped."
                )
            await call_next()

    return _ToolLimit()


def make_model_call_limit_middleware(max_calls: int = 100):
    """Chat middleware counter — raises past ``max_calls`` LLM invocations."""
    from agent_framework import ChatMiddleware, MiddlewareTermination

    counter = {"n": 0}

    class _ModelLimit(ChatMiddleware):
        async def process(self, context, call_next):
            counter["n"] += 1
            if counter["n"] > max_calls:
                raise MiddlewareTermination(
                    f"model_call_limit reached ({max_calls})."
                )
            await call_next()

    return _ModelLimit()


# ---------------------------------------------------------------------------
# OPTIMIZERS
# ---------------------------------------------------------------------------


def make_tool_retry_middleware(
    max_retries: int = 2,
    initial_backoff_ms: int = 500,
):
    """Function middleware that retries failed tool calls with exponential backoff."""
    from agent_framework import FunctionMiddleware

    import asyncio

    counters: Dict[str, int] = defaultdict(int)

    class _ToolRetry(FunctionMiddleware):
        async def process(self, context, call_next):
            tool_name = getattr(
                getattr(context, "function", None), "name", "<unknown>"
            )
            last_exc: Optional[Exception] = None
            for attempt in range(max_retries + 1):
                try:
                    await call_next()
                    return
                except Exception as exc:
                    last_exc = exc
                    counters[tool_name] += 1
                    if attempt == max_retries:
                        _audit_log.warning(
                            "tool_retry exhausted for %s after %d attempts",
                            tool_name, max_retries,
                        )
                        raise
                    delay = (initial_backoff_ms * (2 ** attempt)) / 1000.0
                    _audit_log.info(
                        "tool_retry %s attempt %d/%d failed (%s); retrying in %.2fs",
                        tool_name, attempt + 1, max_retries, exc, delay,
                    )
                    await asyncio.sleep(delay)
            if last_exc is not None:  # pragma: no cover — defensive
                raise last_exc

    return _ToolRetry()


# ---------------------------------------------------------------------------
# OBSERVERS
# ---------------------------------------------------------------------------


def make_audit_log_middleware():
    """Function middleware that logs every tool call + emits a supplementary
    ``agentflow.tool.audit`` span with tool input/output.

    MAF already emits ``execute_tool <name>`` spans natively; this observer
    adds argument + result logging that MAF's span doesn't include by default.
    """
    from agent_framework import FunctionMiddleware

    class _AuditLog(FunctionMiddleware):
        async def process(self, context, call_next):
            fn = getattr(context, "function", None)
            tool_name = getattr(fn, "name", type(fn).__name__ if fn else "<unknown>")
            args = getattr(context, "arguments", None)

            _audit_log.info(
                "tool_call_start tool=%s args=%s", tool_name, _truncate(args)
            )
            try:
                span_cm = _tracer().start_as_current_span(
                    f"agentflow.tool.audit {tool_name}",
                    attributes={
                        "agentflow.tool.name": tool_name,
                        "agentflow.tool.args": _truncate(args),
                    },
                )
            except Exception:
                span_cm = None

            if span_cm is not None:
                with span_cm as span:
                    await call_next()
                    result = getattr(context, "result", None)
                    try:
                        span.set_attribute(
                            "agentflow.tool.result", _truncate(result)
                        )
                    except Exception:
                        pass
                    _audit_log.info(
                        "tool_call_end tool=%s result=%s",
                        tool_name, _truncate(result),
                    )
            else:  # pragma: no cover
                await call_next()

    return _AuditLog()


def make_cost_tracking_middleware(budget_limit: Optional[float] = None):
    """Agent middleware that accumulates ``UsageDetails`` and enforces a budget.

    MAF auto-emits per-call usage. We roll it up across the whole run and
    raise when ``budget_limit`` is reached (approximated via a cost-per-K
    heuristic — the default ``$0.002 / 1K total_tokens`` matches a rough
    mid-tier model rate and can be overridden via config).
    """
    from agent_framework import AgentMiddleware, MiddlewareTermination

    totals = {"input": 0, "output": 0, "total": 0, "estimated_cost_usd": 0.0}
    cost_per_1k = 0.002  # rough default; can be provider-specific later

    class _CostTracking(AgentMiddleware):
        async def process(self, context, call_next):
            await call_next()
            # Attempt to read accumulated usage from the finished response
            result = getattr(context, "result", None)
            usage = _collect_usage(result)
            if usage:
                totals["input"] += usage.get("input_token_count", 0) or 0
                totals["output"] += usage.get("output_token_count", 0) or 0
                totals["total"] += usage.get("total_token_count", 0) or 0
                totals["estimated_cost_usd"] = (
                    totals["total"] / 1000.0
                ) * cost_per_1k
                _cost_log.info(
                    "usage input=%d output=%d total=%d est_cost=$%.4f",
                    totals["input"], totals["output"], totals["total"],
                    totals["estimated_cost_usd"],
                )
                try:
                    with _tracer().start_as_current_span(
                        "agentflow.cost_tracking",
                        attributes={
                            "gen_ai.usage.input_tokens": totals["input"],
                            "gen_ai.usage.output_tokens": totals["output"],
                            "gen_ai.usage.total_tokens": totals["total"],
                            "agentflow.estimated_cost_usd": totals["estimated_cost_usd"],
                        },
                    ):
                        pass
                except Exception:
                    pass
                if budget_limit is not None and totals["estimated_cost_usd"] > budget_limit:
                    raise MiddlewareTermination(
                        f"Budget exceeded: ~${totals['estimated_cost_usd']:.2f} > "
                        f"${budget_limit:.2f}"
                    )

    return _CostTracking()


def make_latency_tracking_middleware():
    """Function middleware that logs per-tool latency.

    MAF emits ``agent_framework.function.invocation.duration`` as a metric
    already; this observer adds a log record so aggregators without metrics
    still see the timings.
    """
    from agent_framework import FunctionMiddleware

    class _Latency(FunctionMiddleware):
        async def process(self, context, call_next):
            fn = getattr(context, "function", None)
            tool_name = getattr(fn, "name", type(fn).__name__ if fn else "<unknown>")
            start = time.perf_counter()
            try:
                await call_next()
            finally:
                elapsed_ms = (time.perf_counter() - start) * 1000
                _latency_log.info(
                    "tool_latency tool=%s elapsed_ms=%.2f",
                    tool_name, elapsed_ms,
                )

    return _Latency()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _messages_text(messages: Any) -> str:
    """Best-effort text flatten over a list of MAF ``Message`` objects."""
    if messages is None:
        return ""
    if isinstance(messages, str):
        return messages
    if isinstance(messages, list):
        parts: List[str] = []
        for m in messages:
            text = getattr(m, "text", None)
            if callable(text):
                try:
                    parts.append(text())
                    continue
                except Exception:
                    pass
            if isinstance(text, str):
                parts.append(text)
                continue
            content = getattr(m, "content", None)
            if isinstance(content, str):
                parts.append(content)
        return "\n".join(parts)
    return repr(messages)


def _collect_usage(response: Any) -> Optional[Dict[str, int]]:
    """Extract ``UsageDetails``-like fields from any MAF response shape."""
    if response is None:
        return None
    # Preferred: response.usage_details (TypedDict)
    usage = getattr(response, "usage_details", None)
    if usage is not None:
        return dict(usage) if isinstance(usage, dict) else None
    # Alternate: response.usage (older shape)
    usage = getattr(response, "usage", None)
    if usage is not None and isinstance(usage, dict):
        return dict(usage)
    return None


def _truncate(value: Any, max_len: int = 2000) -> str:
    s = repr(value) if not isinstance(value, str) else value
    return s if len(s) <= max_len else s[: max_len - 12] + "...[trunc]"


def _resolve_callable(module_path: str, function_name: str) -> Callable[..., Any]:
    """Import ``module_path`` and return ``function_name`` attribute."""
    import importlib

    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Filter module {module_path!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"Filter function {function_name!r} not found in {module_path!r}"
        )
    return fn
