"""Cross-backend portable filter tier for the MAF backend.

``guards:`` / ``optimizers:`` / ``observers:`` declared in YAML compile
down to MAF's three middleware interfaces:

- :class:`AgentMiddleware` — wraps the whole agent invocation
- :class:`ChatMiddleware` — wraps each LLM call
- :class:`FunctionMiddleware` — wraps each tool/function call

All middleware types implement one method: ``process(context, call_next)``.
We emit our own OTel spans from these where MAF's native spans don't
cover the concern (e.g. ``cost_tracking`` adds a running budget check;
MAF emits usage tokens but doesn't enforce caps).

The enum vocabulary matches SK / CAS / OAI so YAML migrates mechanically.
"""
