"""OpenTelemetry setup for the MAF backend.

**MAF's distinguishing advantage over other backends: native ``gen_ai.*``
OTel instrumentation.** The framework auto-emits:

- ``invoke_agent <name>`` — top-level per invocation (with
  ``gen_ai.usage.input_tokens`` / ``output_tokens``)
- ``chat <model>`` — LLM call (per turn)
- ``execute_tool <function>`` — tool invocation

Plus metrics:

- ``gen_ai.client.operation.duration`` (histogram, seconds)
- ``gen_ai.client.token.usage`` (histogram, tokens)
- ``agent_framework.function.invocation.duration`` (histogram, seconds)

So unlike CAS / OAI where we set up a ``TracerProvider`` ourselves, on
MAF we just call :func:`agent_framework.observability.configure_otel_providers`
when ``OTEL_TRACES_ENABLED=true``. It reads standard ``OTEL_EXPORTER_OTLP_*``
env vars, installs the provider, and wires MAF's instrumentation.

Our ``setup_tracing()`` stays opt-in for consistency with the other
backends and also sets ``ENABLE_INSTRUMENTATION=true`` so MAF emits even
when an existing OTel provider is already installed.
"""

from __future__ import annotations

import os
from typing import Optional

_initialized = False


def setup_tracing(service_name: Optional[str] = None) -> bool:
    """Install MAF's OTel instrumentation when ``OTEL_TRACES_ENABLED=true``.

    Returns True if tracing was enabled. Idempotent — subsequent calls in
    the same process are no-ops.
    """
    global _initialized
    if _initialized:
        return True

    if os.getenv("OTEL_TRACES_ENABLED", "false").lower() != "true":
        return False

    try:
        from agent_framework.observability import configure_otel_providers
    except ImportError:  # pragma: no cover
        print(
            "OTEL_TRACES_ENABLED=true but agent-framework is not installed. "
            "Install with: pip install agentflow[agent-framework]"
        )
        return False

    resolved_service_name = service_name or os.getenv(
        "OTEL_SERVICE_NAME", "agentflow"
    )
    # Explicit assignment — when setup_tracing() is called with
    # ``service_name=<arg>`` the arg wins over any stale env value.
    os.environ["OTEL_SERVICE_NAME"] = resolved_service_name
    # Make sure MAF's instrumentation paths are on even if a third-party
    # SDK (Azure Monitor / Langfuse) already installed a TracerProvider.
    os.environ["ENABLE_INSTRUMENTATION"] = "true"

    protocol = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
    endpoint = os.getenv(
        "OTEL_EXPORTER_OTLP_ENDPOINT",
        "http://localhost:4317" if protocol == "grpc" else "http://localhost:4318",
    )

    # Honor the standard OTEL_*_EXPORTER=none env vars.
    # MAF's ``configure_otel_providers()`` ignores them by default and
    # always installs a metrics reader, which spams
    # "Failed to export metrics ... UNIMPLEMENTED" on Jaeger-only
    # endpoints. We intercept that by constructing our own filtered
    # exporters list when any signal is disabled.
    metrics_off = os.getenv("OTEL_METRICS_EXPORTER", "").lower() == "none"
    logs_off = os.getenv("OTEL_LOGS_EXPORTER", "").lower() == "none"
    traces_off = os.getenv("OTEL_TRACES_EXPORTER", "").lower() == "none"

    if metrics_off or logs_off or traces_off:
        # MAF's ``_get_exporters_from_env()`` runs first and creates an
        # exporter per signal whenever ``OTEL_EXPORTER_OTLP_ENDPOINT`` is
        # set. To suppress a signal we have to temporarily hide the env
        # vars that drive that construction, pass our own filtered list
        # explicitly, then restore the env for anything else reading it.
        with _otel_env_without_endpoint():
            exporters = _build_filtered_exporters(
                endpoint=endpoint,
                protocol=protocol,
                include_traces=not traces_off,
                include_metrics=not metrics_off,
                include_logs=not logs_off,
            )
            configure_otel_providers(exporters=exporters)
    else:
        configure_otel_providers()

    print("OpenTelemetry tracing enabled (MAF-native)")
    print(f"  Service: {resolved_service_name}")
    print(f"  Endpoint: {endpoint} ({protocol})")
    signals = []
    if not traces_off:
        signals.append("traces")
    if not metrics_off:
        signals.append("metrics")
    if not logs_off:
        signals.append("logs")
    print(f"  Signals enabled: {', '.join(signals) or '(none)'}")
    print(
        "  MAF auto-emits: invoke_agent / chat / execute_tool + "
        "gen_ai.client.{operation.duration,token.usage} metrics"
    )

    _initialized = True
    return True


from contextlib import contextmanager


@contextmanager
def _otel_env_without_endpoint():
    """Temporarily remove env vars that would trigger MAF's env-based exporter
    construction for signals we want to omit. Restored on exit."""
    keys = [
        "OTEL_EXPORTER_OTLP_ENDPOINT",
        "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT",
        "OTEL_EXPORTER_OTLP_METRICS_ENDPOINT",
        "OTEL_EXPORTER_OTLP_LOGS_ENDPOINT",
    ]
    saved = {k: os.environ.pop(k, None) for k in keys}
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v


def _build_filtered_exporters(
    endpoint: str,
    protocol: str,
    include_traces: bool,
    include_metrics: bool,
    include_logs: bool,
) -> list:
    """Build the OTLP exporter subset corresponding to enabled signals.

    MAF's ``configure_otel_providers()`` takes an ``exporters=`` list and
    only installs readers/providers for exporters that are present. By
    omitting the :class:`MetricExporter` we stop the periodic metrics
    export — no more Jaeger ``UNIMPLEMENTED`` spam when the collector
    doesn't accept metrics.
    """
    exporters: list = []
    if protocol == "grpc":
        if include_traces:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                OTLPSpanExporter,
            )
            exporters.append(OTLPSpanExporter(endpoint=endpoint, insecure=True))
        if include_metrics:
            from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
                OTLPMetricExporter,
            )
            exporters.append(OTLPMetricExporter(endpoint=endpoint, insecure=True))
        if include_logs:
            from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
                OTLPLogExporter,
            )
            exporters.append(OTLPLogExporter(endpoint=endpoint, insecure=True))
    else:  # http/protobuf
        if include_traces:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                OTLPSpanExporter,
            )
            exporters.append(
                OTLPSpanExporter(endpoint=f"{endpoint.rstrip('/')}/v1/traces")
            )
        if include_metrics:
            from opentelemetry.exporter.otlp.proto.http.metric_exporter import (
                OTLPMetricExporter,
            )
            exporters.append(
                OTLPMetricExporter(endpoint=f"{endpoint.rstrip('/')}/v1/metrics")
            )
        if include_logs:
            from opentelemetry.exporter.otlp.proto.http._log_exporter import (
                OTLPLogExporter,
            )
            exporters.append(
                OTLPLogExporter(endpoint=f"{endpoint.rstrip('/')}/v1/logs")
            )
    return exporters
