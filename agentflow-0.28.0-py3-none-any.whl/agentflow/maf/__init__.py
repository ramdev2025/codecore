"""AgentFlow MAF — Microsoft Agent Framework backend."""

from __future__ import annotations

import os


def _check_agent_framework_init_integrity() -> None:
    """Detect Microsoft's broken agent-framework-azure-ai-search==0.0.0a1.

    That alpha package ships a zero-byte ``agent_framework/__init__.py``
    that masks the real 11269-byte file from ``agent-framework-core`` when
    pip resolves the two sibling namespace packages in the wrong order.
    Symptom in user code: ``ImportError: cannot import name 'Agent' from
    'agent_framework'``.

    Our ``[agent-framework]`` extra pins the sibling package forward to a
    version that doesn't ship an ``__init__.py`` at all (proper PEP 420
    namespace), which fixes fresh installs. This check catches envs that
    are already poisoned (reinstalled from an old ``pip freeze``, etc.)
    and tells the user exactly how to repair them.
    """
    try:
        import agent_framework
    except Exception:
        return  # Not installed; builder will raise its own clearer error

    init_file = getattr(agent_framework, "__file__", None)
    if not init_file:
        return  # Pure namespace package — nothing to check
    try:
        if os.path.getsize(init_file) == 0:
            raise RuntimeError(
                "agent_framework/__init__.py is zero bytes — the "
                "agent-framework-azure-ai-search==0.0.0a1 alpha package "
                "overwrote agent-framework-core's real init. Repair the "
                "venv by running these two commands in order (sequential "
                "install is required — combined --force-reinstall can "
                "leave the file missing on some pip versions):\n"
                "    pip install --no-cache-dir --upgrade "
                "'agent-framework-azure-ai-search>=1.0.0b251204'\n"
                "    pip uninstall -y agent-framework-core && "
                "pip install --no-cache-dir 'agent-framework-core==1.1.1'"
            )
    except OSError:
        return


_check_agent_framework_init_integrity()
