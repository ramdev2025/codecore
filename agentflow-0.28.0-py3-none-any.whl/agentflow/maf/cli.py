"""AgentFlow MAF CLI — run Microsoft Agent Framework agents from the unified
``agentflow`` command.

The CLI router dispatches ``backend: agent-framework`` to
``run_from_router`` in this module. It translates canonical flags into
MAF-specific objects and streams output to the console.

Two modes (discriminated by the built :class:`MafRunner.mode`):

- **Agent mode** — ``Agent.run(..., stream=True)`` yields
  ``AgentResponseUpdate`` chunks. Text deltas stream inline, tool calls
  render as ``▸ ToolName(…)``.
- **Workflow mode** — ``Workflow.run(..., stream=True)`` yields
  ``WorkflowEvent`` instances. Executor invocations / superstep boundaries
  / final outputs render as structured lines.

Persistence (``--persistence``, ``--db-path``, ``--thread-id``) bridges
``thread_id → AgentSession.session_id`` via :class:`MafPersistenceManager`.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any, Optional

from agentflow.cli import (
    ExecutionTimer,
    console,
    print_banner,
    print_config_table,
    print_error,
    print_execution_summary,
    print_info,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_AGENT_SWITCH,
    EVENT_COMPLETE,
    EVENT_ERROR,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)


def run_from_router(
    yaml_path: str,
    query: Optional[str] = None,
    persistence: Optional[str] = None,
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
    thread_id: Optional[str] = None,
    interactive: bool = False,
    dry_run: bool = False,
    json_output: bool = False,
    output: str = "tty",
    **_ignored: Any,
):
    """Entry point called by the unified CLI router.

    Cross-backend flags that don't apply to MAF (``workdir``, ``no_tui``,
    ``tools_module``, ``recursion_limit``) are absorbed via ``**_ignored``.

    Persistence precedence: ``--persistence`` flag > ``AGENTFLOW_PERSISTENCE``
    env var > default (sqlite).
    """
    from dotenv import find_dotenv, load_dotenv

    env_path = find_dotenv(usecwd=True)
    if env_path:
        load_dotenv(env_path, override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(
        getattr(logging, log_level, logging.WARNING)
    )

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    if persistence is None:
        persistence = os.environ.get("AGENTFLOW_PERSISTENCE", "sqlite").strip().lower()

    if dry_run:
        _run_dry(yaml_path, json_output=json_output)
        return

    json_sink: Optional[JsonSink] = JsonSink(backend="agent-framework") if is_json_mode(output) else None
    if json_sink is None:
        print_banner(
            "AgentFlow MAF",
            "Run Microsoft Agent Framework agents from the command line",
        )

    # MAF has its own native OTel instrumentation via configure_otel_providers;
    # our setup_tracing() just toggles it on when OTEL_TRACES_ENABLED=true.
    from agentflow.maf.telemetry import setup_tracing

    setup_tracing()

    try:
        from agentflow.maf.core.builder import MafAgentBuilder
    except ImportError:
        print_error(
            "agent-framework is required but not installed. "
            "Install with: pip install agentflow[agent-framework]"
        )
        raise SystemExit(1)

    builder = MafAgentBuilder.from_yaml(yaml_path)
    runner = builder.build()

    pm = _build_persistence(persistence, db_path, connection_string)
    tid = thread_id or str(uuid.uuid4())
    if json_sink is None:
        _print_run_header(yaml_path, persistence, tid, runner.mode)

    # Only agent mode has a usable AgentSession (workflow mode uses MAF's
    # own checkpoint_storage configured in the YAML).
    maf_session = None
    if runner.mode == "agent" and pm is not None and persistence != "memory":
        session_id = pm.get_or_create_session_id(tid)
        maf_session = runner.starting_agent.create_session(session_id=session_id)

    if interactive and json_sink is None:
        _run_interactive(runner, pm, tid, maf_session)
    else:
        if not query:
            query = prompt_user("Query") if json_sink is None else ""
        if not query:
            return
        _run_one_shot(runner, query, pm, tid, maf_session, json_sink=json_sink)


# ---------------------------------------------------------------------------
# Dry-run
# ---------------------------------------------------------------------------


def _run_dry(yaml_path: str, json_output: bool = False) -> None:
    try:
        from agentflow.maf.core.builder import MafAgentBuilder
    except ImportError:
        print_error(
            "agent-framework is required but not installed. "
            "Install with: pip install agentflow[agent-framework]"
        )
        raise SystemExit(1)

    # Let exceptions propagate — ``wrap_cli_main`` formats them via
    # ``friendly_error`` so users see human messages rather than a raw
    # pydantic / SDK dump.
    builder = MafAgentBuilder.from_yaml(yaml_path)
    summary = builder.dry_run()

    if json_output:
        print(json.dumps(summary, indent=2, default=str))
        return

    print_banner(
        "AgentFlow MAF",
        "Run Microsoft Agent Framework agents from the command line",
    )
    llm_summary = summary.get("llm") or {}
    client_opts = llm_summary.get("client_options") or {}

    rows = [
        ("Backend", "agent-framework"),
        ("Mode", summary["mode"]),
        ("Config", yaml_path),
        ("Name", summary["metadata"].get("name") or "-"),
        ("Provider", llm_summary.get("provider") or "-"),
        ("Model", client_opts.get("model") or "-"),
    ]

    if summary["mode"] == "agent":
        agents = summary["agents"]
        main = agents.get("<main>", {})
        rows.append(("Agent", main.get("name") or "<main>"))
        rows.append(("Tools", str(main.get("tool_count", 0))))
        aux_names = [k for k in agents if k != "<main>"]
        if aux_names:
            rows.append(("Auxiliary agents", ", ".join(aux_names)))
    else:
        wf = summary["workflow"] or {}
        rows.append(("Start executor", wf.get("start_executor") or "-"))
        rows.append(("Max iterations", str(wf.get("max_iterations", "-"))))
        rows.append(("Executors", ", ".join(wf.get("executors") or [])))
        edge_kinds = [e["kind"] for e in (wf.get("edges") or [])]
        rows.append(("Edges", ", ".join(edge_kinds) or "-"))
        if wf.get("checkpoint"):
            rows.append(("Checkpoint", wf["checkpoint"]))

    if summary.get("guards"):
        rows.append(("Guards", ", ".join(summary["guards"])))
    if summary.get("optimizers"):
        rows.append(("Optimizers", ", ".join(summary["optimizers"])))
    if summary.get("observers"):
        rows.append(("Observers", ", ".join(summary["observers"])))
    if summary.get("mcp_servers"):
        rows.append(("MCP servers", ", ".join(summary["mcp_servers"])))
    if summary.get("middleware_count"):
        rows.append(("Middleware", str(summary["middleware_count"])))

    print_config_table(rows)
    console.print("[bold green]Config is valid.[/bold green]")


# ---------------------------------------------------------------------------
# One-shot + interactive
# ---------------------------------------------------------------------------


def _run_one_shot(
    runner: Any,
    query: str,
    pm: Optional[Any],
    thread_id: str,
    maf_session: Optional[Any],
    json_sink: Optional[JsonSink] = None,
) -> None:
    if json_sink is None:
        console.print()
    timer = ExecutionTimer()
    timer.start()
    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    asyncio.run(_drive_query(runner, query, pm, thread_id, maf_session, json_sink=json_sink))
    if json_sink is not None:
        json_sink.emit(EVENT_STATS, elapsed_s=timer.elapsed())
        json_sink.emit(EVENT_COMPLETE)
    else:
        print_execution_summary(console, timer.elapsed())


def _run_interactive(
    runner: Any,
    pm: Optional[Any],
    thread_id: str,
    maf_session: Optional[Any],
) -> None:
    init_history()
    repl_state = ReplState(thread_id=thread_id)
    console.print(
        "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, "
        "[bold]/quit[/bold] to exit\n"
    )
    while True:
        try:
            q = prompt_user("Query")
            if is_quit_alias(q):
                console.print("\nGoodbye.")
                break
            if not q.strip():
                continue
            if is_slash_command(q):
                if dispatch_slash_command(q, repl_state, console) == "quit":
                    console.print("\nGoodbye.")
                    break
                continue

            console.print()
            timer = ExecutionTimer()
            timer.start()
            asyncio.run(_drive_query(runner, q, pm, thread_id, maf_session))
            print_execution_summary(console, timer.elapsed())
        except (KeyboardInterrupt, EOFError):
            console.print("\nGoodbye.")
            break
        except Exception as e:
            # Per-turn isolation — REPL keeps running. Use the same
            # friendly format as the one-shot path.
            from agentflow.cli.errors import friendly_error
            print_error(friendly_error(e))
    cleanup_terminal_state()


# ---------------------------------------------------------------------------
# Stream driver
# ---------------------------------------------------------------------------


async def _drive_query(
    runner: Any,
    query_text: str,
    pm: Optional[Any],
    thread_id: str,
    maf_session: Optional[Any],
    json_sink: Optional[JsonSink] = None,
) -> None:
    """Stream a query through the MAF runner, rendering events live.

    Wraps the invocation in an ``agentflow.maf.run`` root span (MAF's own
    ``invoke_agent`` / ``chat`` / ``execute_tool`` spans nest under it).

    When ``json_sink`` is provided, agent updates and workflow events are
    translated into the shared ndjson schema and emitted to that sink
    instead of the Rich-rendered terminal output.
    """
    from opentelemetry import trace

    tracer = trace.get_tracer("agentflow.maf")
    renderer = _StreamRenderer(console, mode=runner.mode) if json_sink is None else None

    with tracer.start_as_current_span(
        "agentflow.maf.run",
        attributes={
            "agentflow.backend": "agent-framework",
            "agentflow.mode": runner.mode,
            "agentflow.thread_id": thread_id,
            "agentflow.query_length": len(query_text),
        },
    ):
        if runner.mode == "agent":
            stream_kwargs = {"stream": True}
            if maf_session is not None:
                stream_kwargs["session"] = maf_session
            stream = runner.starting_agent.run(query_text, **stream_kwargs)
            current_author: Optional[str] = None
            async for update in stream:
                if json_sink is not None:
                    current_author = _emit_maf_agent_update(
                        json_sink, update, current_author,
                    )
                else:
                    renderer.render_agent_update(update)
        else:
            await _drive_workflow_with_tool_taps(
                runner, query_text, renderer, json_sink=json_sink,
            )

        if renderer is not None:
            renderer.flush()

    if pm is not None:
        pm.bump_turns(thread_id)


async def _drive_workflow_with_tool_taps(
    runner: Any,
    query_text: str,
    renderer: Optional["_StreamRenderer"],
    json_sink: Optional[JsonSink] = None,
) -> None:
    """Iterate the workflow stream and drain tool-tap events between yields.

    Agents inside a workflow run their tool invocations in their own
    pipeline; those don't surface as ``WorkflowEvent``s. We attached a
    ``FunctionMiddleware`` tap to each agent at build time that publishes
    ``call`` / ``result`` / ``error`` dicts to
    ``runner.tool_event_queue``. The middleware runs *inside* the
    workflow's own asyncio context, so when a tool finishes, the queue
    has new events and the workflow yields control shortly after. We
    drain the queue at every yield boundary — that surfaces tool events
    in real order without spawning extra tasks.

    Why no ``asyncio.create_task`` here: an earlier version raced the
    workflow stream against ``tool_queue.get()`` via separate tasks. That
    fragmented the OpenTelemetry context — MAF's
    ``_run_workflow_with_tracing`` opens spans on the workflow task and
    detaches them on the parent task, triggering ``Failed to detach
    context`` errors at run end. Sequential iteration keeps every span's
    attach/detach in one context.
    """
    from agentflow.maf.core.workflow_tap import drain_ready

    tool_queue = runner.tool_event_queue
    workflow_stream = runner.workflow.run(query_text, stream=True)

    async for event in workflow_stream:
        if tool_queue is not None:
            for tool_event in drain_ready(tool_queue):
                if json_sink is not None:
                    _emit_maf_tool_event(json_sink, tool_event)
                else:
                    renderer.render_tool_event(tool_event)
        if json_sink is not None:
            _emit_maf_workflow_event(json_sink, event)
        else:
            renderer.render_workflow_event(event)

    # Final drain — tool events that landed after the last workflow yield
    if tool_queue is not None:
        for tool_event in drain_ready(tool_queue):
            renderer.render_tool_event(tool_event)


# ---------------------------------------------------------------------------
# Stream renderer — one class, two modes
# ---------------------------------------------------------------------------


class _StreamRenderer:
    """Turns MAF stream events into human-readable terminal output.

    Agent mode — handles ``AgentResponseUpdate``:
    - ``update.contents`` is a list of :class:`~agent_framework.Content` items,
      each with a ``type`` discriminator. We render each type separately:
        * ``text`` → streamed inline
        * ``text_reasoning`` → ``· thinking…`` (shown once per streak)
        * ``function_call`` → ``▸ name(short-args)``
        * ``function_result`` → ``← tool result · N chars``
        * ``mcp_server_tool_call`` / ``mcp_server_tool_result`` — same shape
        * ``search_tool_call`` / ``search_tool_result`` — same shape
        * ``error`` → red error marker
    - ``update.author_name`` changes announce agent switches:
      ``→ agent: <name>``

    Workflow mode — handles ``WorkflowEvent``:
    - ``superstep_started`` → ``┌── superstep N``
    - ``executor_invoked`` → ``  ▶ <executor_id>``
    - ``executor_completed`` → ``  ✓ <executor_id>``
    - ``output`` → inline text
    - ``failed`` / ``warning`` → visible markers
    """

    _MAX_ARG_CHARS = 110

    # Content type → CLI marker kind. Lets us dispatch consistently
    # across the function / mcp / search / code_interpreter / etc. families.
    _CALL_TYPES = {
        "function_call",
        "mcp_server_tool_call",
        "search_tool_call",
        "code_interpreter_tool_call",
        "image_generation_tool_call",
        "shell_tool_call",
    }
    _RESULT_TYPES = {
        "function_call": "function_result",
        "mcp_server_tool_call": "mcp_server_tool_result",
        "search_tool_call": "search_tool_result",
        "code_interpreter_tool_call": "code_interpreter_tool_result",
        "image_generation_tool_call": "image_generation_tool_result",
        "shell_tool_call": "shell_tool_result",
    }
    _RESULT_TYPE_SET = set(_RESULT_TYPES.values())

    def __init__(self, output, mode: str):
        self._out = output
        self._mode = mode
        self._streaming_text = False
        self._reasoning_active = False
        self._printed_call_ids: set[str] = set()
        # call_id → {"name": str, "args": str | dict, "ctype": str}
        # Buffers streamed function_call deltas so we can print the full
        # args when the call completes (either by matching result or by
        # flush). Without buffering, the first delta is printed and it's
        # usually just ``{"`` (start of the JSON).
        self._pending_calls: dict[str, dict] = {}
        self._current_author: Optional[str] = None

    def flush(self) -> None:
        self._flush_pending_calls()
        self._end_text_stream()

    # -- Agent mode --------------------------------------------------------

    def render_agent_update(self, update: Any) -> None:
        try:
            author = getattr(update, "author_name", None)
            if author and author != self._current_author:
                self._end_text_stream()
                self._reasoning_active = False
                if self._current_author is not None:
                    # Only show the switch marker; first author is implicit
                    # (it's just "the agent started talking").
                    self._out.print(
                        f"[bold green]→[/bold green] agent: [bold]{author}[/bold]",
                        highlight=False,
                    )
                self._current_author = author

            contents = getattr(update, "contents", None) or []
            for content in contents:
                self._render_content(content)

            # Fallback for providers that set top-level .text without
            # populating contents (rare, but observed with some SDK paths).
            if not contents:
                text = getattr(update, "text", None)
                if isinstance(text, str) and text:
                    self._stream_text(text)
        except Exception as e:  # pragma: no cover
            self._out.print(f"[dim red](renderer error: {e})[/dim red]")

    def _render_content(self, content: Any) -> None:
        ctype = getattr(content, "type", None)

        if ctype == "text":
            text = getattr(content, "text", None) or ""
            if text:
                if self._reasoning_active:
                    self._reasoning_active = False
                self._stream_text(text)
            return

        if ctype == "text_reasoning":
            if not self._reasoning_active:
                self._end_text_stream()
                self._out.print("[dim italic]· thinking…[/dim italic]")
                self._reasoning_active = True
            return

        if ctype in self._CALL_TYPES:
            self._accumulate_call(content, ctype)
            return

        if ctype in self._RESULT_TYPE_SET:
            # Flush the matching call (with full buffered args) before
            # showing its result, so ▸ and ← appear in the right order
            # with complete information.
            call_id = getattr(content, "call_id", None) or getattr(content, "id", None)
            if call_id:
                self._flush_pending_call(call_id)
            self._end_text_stream()
            self._reasoning_active = False
            exc = getattr(content, "exception", None)
            if exc:
                self._out.print(
                    f"  [red]← tool error ·[/red] {exc}",
                    highlight=False,
                )
                return
            result = getattr(content, "result", None)
            if result is None:
                result = getattr(content, "output", None)
            length = _result_length(result)
            self._emit_result_block(
                result, length, indent="  ", label_prefix="tool "
            )
            return

        if ctype == "error":
            self._end_text_stream()
            self._reasoning_active = False
            msg = getattr(content, "message", None) or "(unknown error)"
            code = getattr(content, "error_code", None)
            prefix = f"[{code}] " if code else ""
            self._out.print(
                f"[red]✗ {prefix}{msg}[/red]",
                highlight=False,
            )
            return

        # usage, hosted_file, hosted_vector_store, approval events etc. —
        # not worth rendering line-by-line; they surface in telemetry and
        # in the final response.

    def _accumulate_call(self, content: Any, ctype: str) -> None:
        """Buffer a streamed tool-call content; print once args look complete.

        MAF fragments function_call arguments across many deltas sharing a
        call_id. We accumulate the string pieces and emit ``▸ name(args)``
        as soon as the accumulated arguments parse as complete JSON (or
        look structurally balanced), then on any subsequent delta with
        the same call_id we simply stop appending. A fallback flush
        happens when the matching function_result arrives or on stream
        end.
        """
        call_id = getattr(content, "call_id", None) or getattr(content, "id", None)
        if call_id and call_id in self._printed_call_ids:
            return

        name = (
            getattr(content, "name", None)
            or getattr(content, "tool_name", None)
            or ctype.replace("_tool_call", "")
        )
        args = getattr(content, "arguments", None)

        # Without a call_id we can't deduplicate — print immediately.
        if not call_id:
            self._emit_call(name, args)
            return

        pending = self._pending_calls.get(call_id)
        if pending is None:
            pending = {"name": name, "args": args, "ctype": ctype}
            self._pending_calls[call_id] = pending
        else:
            if name and not pending.get("name"):
                pending["name"] = name
            pending["args"] = _merge_args(pending.get("args"), args)

        if _args_look_complete(pending["args"]):
            self._flush_pending_call(call_id)

    def _flush_pending_call(self, call_id: str) -> None:
        pending = self._pending_calls.pop(call_id, None)
        if pending is None or call_id in self._printed_call_ids:
            return
        self._printed_call_ids.add(call_id)
        self._emit_call(pending.get("name") or "<tool>", pending.get("args"))

    def _flush_pending_calls(self) -> None:
        for call_id in list(self._pending_calls.keys()):
            self._flush_pending_call(call_id)

    def _emit_call(self, name: str, args: Any) -> None:
        self._end_text_stream()
        self._reasoning_active = False
        short = _short_args(args, self._MAX_ARG_CHARS)
        self._out.print(
            f"[cyan]▸[/cyan] {name}({short})",
            highlight=False,
            markup=True,
        )

    def _stream_text(self, text: str) -> None:
        if not self._streaming_text:
            self._out.print()
            self._streaming_text = True
        self._out.print(text, end="", highlight=False, markup=False)

    def _emit_result_block(
        self,
        result: Any,
        length: int,
        *,
        indent: str = "  ",
        label_prefix: str = "",
    ) -> None:
        """Render a tool/executor result line plus an optional JSON body.

        UX contract:

        - Always emit ``← {prefix}result · N chars`` as the header.
        - If the result is a dict/list (or a JSON string that parses) AND
          the pretty-printed form fits the budget (≤ 2000 chars / 24
          lines), append it as an indented multi-line JSON block —
          mirroring the UI's collapsed ``<details>`` panel. The
          one-line preview is omitted in this case to avoid showing the
          same content twice.
        - Otherwise (prose / huge JSON), append the one-line preview to
          the header so the user still sees what came back.
        """
        body = _pretty_json_block(result, max_chars=2000, max_lines=24)
        header = f"{indent}[dim]← {label_prefix}result · {length} chars[/dim]"
        if body is None:
            preview = _result_preview(result, limit=240)
            if preview:
                header = f"{header} [dim]·[/dim] {preview}"
            self._out.print(header, highlight=False, markup=True)
            return

        self._out.print(header, highlight=False, markup=True)
        block_indent = indent + "  "
        indented = "\n".join(block_indent + line for line in body.splitlines())
        self._out.print(
            f"[dim]{indented}[/dim]",
            highlight=False,
            markup=True,
        )

    # -- Workflow mode -----------------------------------------------------

    def render_tool_event(self, event: dict) -> None:
        """Render a ``{'kind': ..., 'agent': ..., 'name': ...}`` tap event.

        Used in workflow mode to surface tool invocations that happen
        *inside* an ``AgentExecutor`` — otherwise they'd be completely
        invisible between the executor's ``▶`` and ``✓`` lifecycle
        markers. Output is indented two spaces more than the executor
        lifecycle so the nesting is visually obvious.
        """
        try:
            kind = event.get("kind")
            agent = event.get("agent", "?")
            name = event.get("name", "<tool>")
            if kind == "call":
                args = event.get("arguments")
                short = _short_args(args, self._MAX_ARG_CHARS)
                self._out.print(
                    f"    [cyan]▸[/cyan] [dim]{agent}[/dim] · {name}({short})",
                    highlight=False,
                    markup=True,
                )
            elif kind == "result":
                result = event.get("result")
                length = _result_length(result)
                self._emit_result_block(
                    result,
                    length,
                    indent="    ",
                    label_prefix=f"{agent} · {name} ",
                )
            elif kind == "error":
                exc = event.get("exception") or "(unknown)"
                self._out.print(
                    f"    [red]← {agent} · {name} error ·[/red] {exc}",
                    highlight=False,
                    markup=True,
                )
        except Exception as e:  # pragma: no cover
            self._out.print(f"[dim red](tool-event render error: {e})[/dim red]")

    def render_workflow_event(self, event: Any) -> None:
        """Render a :class:`~agent_framework.WorkflowEvent`.

        The unified event class uses ``event.type`` as a discriminator
        (same ``WorkflowEventType`` literal as the SDK). ``executor_id``,
        ``iteration``, ``state``, ``details``, ``data`` are the real
        fields; ``source_executor_id`` is a property that RAISES on
        non-``request_info`` events — never touch it with ``getattr``
        default.
        """
        try:
            etype = getattr(event, "type", None)
            executor_id = getattr(event, "executor_id", None) or ""

            if etype == "superstep_started":
                self._end_text_stream()
                step = getattr(event, "iteration", None)
                label = f"superstep {step}" if step is not None else "superstep"
                self._out.print(f"[bold cyan]┌──[/bold cyan] {label}")
            elif etype == "superstep_completed":
                self._end_text_stream()
                self._out.print(f"[bold cyan]└──[/bold cyan] superstep complete")
            elif etype == "executor_invoked":
                self._end_text_stream()
                self._out.print(
                    f"  [blue]▶[/blue] {executor_id}",
                    highlight=False,
                )
            elif etype == "executor_completed":
                self._end_text_stream()
                self._out.print(
                    f"  [green]✓[/green] {executor_id}",
                    highlight=False,
                )
            elif etype == "executor_failed":
                self._end_text_stream()
                details = getattr(event, "details", None)
                reason = _coerce_text(details) if details else ""
                self._out.print(
                    f"  [red]✗[/red] {executor_id}: {reason}",
                    highlight=False,
                )
            elif etype == "failed":
                self._end_text_stream()
                details = getattr(event, "details", None)
                reason = _coerce_text(details) if details else ""
                self._out.print(
                    f"[red]✗ workflow failed:[/red] {reason}",
                    highlight=False,
                )
            elif etype == "warning":
                self._end_text_stream()
                msg = _coerce_text(getattr(event, "data", None))
                self._out.print(f"  [yellow]⚠ {msg}[/yellow]")
            elif etype == "error":
                self._end_text_stream()
                msg = _coerce_text(getattr(event, "data", None))
                self._out.print(f"  [red]✗ {msg}[/red]", highlight=False)
            elif etype == "output":
                # Final executor output — stream its text inline like agent text.
                text = _coerce_text(getattr(event, "data", None))
                if text:
                    self._stream_text(text)
            elif etype == "data":
                # Per-executor data emission. Only render if it has usable text.
                text = _coerce_text(getattr(event, "data", None))
                if text and executor_id:
                    self._end_text_stream()
                    self._out.print(
                        f"  [dim]· {executor_id}:[/dim] {text[:200]}"
                        + ("…" if len(text) > 200 else ""),
                        highlight=False,
                    )
            # started / status / request_info / handoff_sent / group_chat
            # / magentic_orchestrator — not surfaced in v1. They emit under
            # native gen_ai spans for telemetry consumers.
        except Exception as e:  # pragma: no cover
            self._out.print(f"[dim red](renderer error: {e})[/dim red]")

    def _end_text_stream(self) -> None:
        if self._streaming_text:
            self._out.print()
            self._streaming_text = False


def _emit_maf_agent_update(
        sink: JsonSink,
        update: Any,
        current_author: Optional[str],
) -> Optional[str]:
    """Translate one MAF agent update into ndjson events.

    Returns the new ``current_author`` so the caller can track agent
    switches across updates. Mirrors :meth:`_StreamRenderer.render_agent_update`:
    text → ``token``, function_call → ``tool_call``, function_result →
    ``tool``, text_reasoning → ``reasoning``, error → ``error``.
    """
    author = getattr(update, "author_name", None)
    if author and author != current_author:
        if current_author is not None:
            sink.emit(EVENT_AGENT_SWITCH, name=author)
        current_author = author

    contents = getattr(update, "contents", None) or []
    if not contents:
        text = getattr(update, "text", None)
        if isinstance(text, str) and text:
            sink.emit(EVENT_TOKEN, content=text)
        return current_author

    for content in contents:
        ctype = getattr(content, "type", None)
        if ctype == "text":
            text = getattr(content, "text", None) or ""
            if text:
                sink.emit(EVENT_TOKEN, content=text)
        elif ctype == "text_reasoning":
            sink.emit(EVENT_REASONING)
        elif ctype in (
            "function_call", "mcp_server_tool_call", "search_tool_call",
            "code_interpreter_tool_call", "image_generation_tool_call",
            "shell_tool_call",
        ):
            name = (
                getattr(content, "name", None)
                or getattr(content, "tool_name", None)
                or ctype.replace("_tool_call", "").replace("function_call", "function")
            )
            sink.emit(
                EVENT_TOOL_CALL,
                name=name,
                args=getattr(content, "arguments", None),
                call_id=getattr(content, "call_id", None) or getattr(content, "id", None),
                kind=ctype,
            )
        elif ctype in (
            "function_result", "mcp_server_tool_result", "search_tool_result",
            "code_interpreter_tool_result", "image_generation_tool_result",
            "shell_tool_result",
        ):
            sink.emit(
                EVENT_TOOL,
                name=getattr(content, "tool_name", None) or "tool",
                content=getattr(content, "result", None) or getattr(content, "output", None),
                call_id=getattr(content, "call_id", None) or getattr(content, "id", None),
                exception=getattr(content, "exception", None),
                kind=ctype,
            )
        elif ctype == "error":
            sink.emit(
                EVENT_ERROR,
                message=getattr(content, "message", "") or "(unknown error)",
                error_code=getattr(content, "error_code", None),
            )
    return current_author


def _emit_maf_tool_event(sink: JsonSink, event: dict) -> None:
    """Translate one workflow-mode tool-tap event to ndjson."""
    kind = event.get("kind")
    name = event.get("name", "<tool>")
    agent = event.get("agent")
    if kind == "call":
        sink.emit(
            EVENT_TOOL_CALL,
            name=name,
            args=event.get("arguments"),
            agent=agent,
        )
    elif kind == "result":
        sink.emit(
            EVENT_TOOL,
            name=name,
            content=event.get("result"),
            agent=agent,
        )
    elif kind == "error":
        sink.emit(
            EVENT_ERROR,
            message=str(event.get("exception") or "(unknown)"),
            tool=name,
            agent=agent,
        )


def _emit_maf_workflow_event(sink: JsonSink, event: Any) -> None:
    """Translate one MAF ``WorkflowEvent`` to ndjson.

    The workflow-event vocabulary doesn't map 1:1 to the shared schema
    (no executor primitives in the schema), so we emit them as
    ``status`` events with ``kind`` set to the original type — useful
    for dashboards that want to show progress, ignorable for consumers
    that only care about tokens/tools.
    """
    etype = getattr(event, "type", None)
    if etype is None:
        return
    if etype == "output":
        text = _coerce_text(getattr(event, "data", None))
        if text:
            sink.emit(EVENT_TOKEN, content=text)
        return
    if etype in ("failed", "executor_failed"):
        details = _coerce_text(getattr(event, "details", None))
        sink.emit(EVENT_ERROR, message=details or etype)
        return
    # Lifecycle markers — surface as `status` events with the original
    # kind so consumers can build progress views without locking in the
    # full vocabulary.
    from agentflow.cli.events import EVENT_STATUS
    sink.emit(
        EVENT_STATUS,
        kind=etype,
        executor_id=getattr(event, "executor_id", None) or "",
        iteration=getattr(event, "iteration", None),
    )


def _coerce_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    text = getattr(value, "text", None)
    if callable(text):
        try:
            return text() or ""
        except Exception:
            pass
    if isinstance(text, str):
        return text
    return repr(value)


def _merge_args(existing: Any, incoming: Any) -> Any:
    """Append streamed argument deltas.

    MAF emits tool-call arguments as JSON string fragments. For the
    common string-delta case we concatenate; for dicts we prefer the
    incoming one (it's the server's accumulated view); if types mismatch
    we keep whichever has more information.
    """
    if incoming is None:
        return existing
    if existing is None:
        return incoming
    if isinstance(existing, str) and isinstance(incoming, str):
        # Some providers resend the full JSON on every delta; detect and
        # avoid doubling it.
        if incoming.startswith(existing):
            return incoming
        if existing.endswith(incoming):
            return existing
        return existing + incoming
    if isinstance(incoming, dict):
        return incoming
    return incoming if incoming else existing


def _args_look_complete(args: Any) -> bool:
    """Heuristic: can we usefully render these args now?

    - dicts are always complete
    - JSON strings that parse cleanly are complete
    - empty / partial strings are not
    """
    if args is None:
        return False
    if isinstance(args, dict):
        return True
    if isinstance(args, str):
        s = args.strip()
        if not s:
            return False
        try:
            json.loads(s)
            return True
        except Exception:
            return False
    return True


def _short_args(args: Any, limit: int) -> str:
    """Best-effort compact rendering of tool-call arguments."""
    if args is None:
        return ""
    if isinstance(args, str):
        s = args.strip()
        # If it's a parseable JSON object, render key=value pairs for readability.
        if s.startswith("{") and s.endswith("}"):
            try:
                parsed = json.loads(s)
                if isinstance(parsed, dict):
                    return _short_args(parsed, limit)
            except Exception:
                pass
        if len(s) <= limit:
            return s
        return s[: limit - 1] + "…"
    if isinstance(args, dict):
        pairs: list[str] = []
        total = 0
        for k, v in args.items():
            frag = f"{k}={v!r}"
            if total + len(frag) > limit and pairs:
                pairs.append("…")
                break
            pairs.append(frag)
            total += len(frag) + 2  # ", " separator
        return ", ".join(pairs)
    s = repr(args)
    if len(s) <= limit:
        return s
    return s[: limit - 1] + "…"


def _result_length(result: Any) -> int:
    if result is None:
        return 0
    if isinstance(result, str):
        return len(result)
    if isinstance(result, (list, dict)):
        try:
            return len(json.dumps(result, default=str))
        except Exception:
            return len(repr(result))
    return len(repr(result))


def _pretty_json_block(
    result: Any,
    *,
    max_chars: int = 2000,
    max_lines: int = 24,
) -> Optional[str]:
    """Return an indented JSON pretty-print if the result is structured
    AND fits in the given budget; otherwise return ``None``.

    Recursively unwraps nested JSON strings — common when tool returns
    are serialized through the chat protocol as ``[{"text": "{json}"}]``
    or ``["{json}"]`` envelopes. Without this the user sees a wall of
    ``\\"`` escaped JSON inside a list, which defeats the purpose of
    pretty-printing.
    """
    if result is None:
        return None

    parsed = _unwrap_json(result)
    if not isinstance(parsed, (dict, list)):
        return None

    try:
        pretty = json.dumps(parsed, indent=2, ensure_ascii=False, default=str)
    except Exception:
        return None

    if len(pretty) > max_chars:
        return None
    if pretty.count("\n") + 1 > max_lines:
        return None
    return pretty


def _unwrap_json(value: Any, _depth: int = 0) -> Any:
    """Walk a value and replace any JSON-string children with their parsed
    form. Caps recursion at depth 4 to avoid runaway parsing on
    pathological inputs.
    """
    if _depth > 4:
        return value
    if isinstance(value, str):
        s = value.strip()
        if (s.startswith("{") and s.endswith("}")) or (
            s.startswith("[") and s.endswith("]")
        ):
            try:
                return _unwrap_json(json.loads(s), _depth + 1)
            except Exception:
                return value
        return value
    if isinstance(value, list):
        # Common envelope: ``[json_string]`` — unwrap to the inner value.
        if len(value) == 1:
            return _unwrap_json(value[0], _depth + 1)
        return [_unwrap_json(v, _depth + 1) for v in value]
    if isinstance(value, dict):
        return {k: _unwrap_json(v, _depth + 1) for k, v in value.items()}
    return value


def _result_preview(result: Any, limit: int = 240) -> str:
    """One-line human-readable preview of a tool result — same contract as
    the WebSocket ``preview`` field so CLI and UI show equivalent info."""
    if result is None:
        return ""
    if isinstance(result, str):
        s = result.strip()
    else:
        try:
            s = json.dumps(result, default=str, ensure_ascii=False)
        except Exception:
            s = repr(result)
    # Collapse whitespace for a clean single-line preview
    s = " ".join(s.split())
    if len(s) <= limit:
        return s
    return s[: limit - 1] + "…"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_persistence(
    backend: str,
    db_path: Optional[str],
    connection_string: Optional[str],
) -> Optional[Any]:
    try:
        from agentflow.maf.persistence import create_persistence_manager
    except ImportError:
        return None
    return create_persistence_manager(
        backend=backend,
        db_path=db_path,
        connection_string=connection_string,
    )


def _print_run_header(
    yaml_path: str,
    persistence: str,
    thread_id: str,
    mode: str,
) -> None:
    print_info(f"Config: {yaml_path}")
    print_info(f"Mode: {mode}")
    print_info(f"Persistence: {persistence}")
    print_info(f"Thread: {thread_id}")
    console.print()
