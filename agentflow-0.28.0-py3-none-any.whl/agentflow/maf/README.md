# AgentFlow MAF

**YAML-driven agents and workflows on the [Microsoft Agent Framework](https://learn.microsoft.com/en-us/agent-framework/overview/).**

Sixth backend of AgentFlow, alongside `workflows` (LangGraph), `deep` (DeepAgents), `sk` (Semantic Kernel), `cas` (Claude Agent SDK), and `oai` (OpenAI Agents SDK). Install with `pip install agentflow[agent-framework]`.

> **Status: in development, targeting v0.19.0.** This README documents the Phase 1 research spec and target design. Implementation follows the 8-phase `.claude/skills/add-backend/SKILL.md` process.

---

## Two modes, one backend

MAF has two distinct execution models, both exposed under `backend: agent-framework`:

1. **Agent mode** — one `Agent(client, instructions, tools)` invocation. Multi-agent composition is via `agent.as_tool()` (any agent can be exposed as a tool to another).
2. **Workflow mode** — explicit `WorkflowBuilder` graph with Pregel BSP superstep execution; supports chain / direct / fan-out / fan-in / switch-case topologies.

The schema discriminates on presence of `agent:` (singular) vs `workflow:`.

---

## Supported features (v1 target)

| Feature | YAML surface | Notes |
| --- | --- | --- |
| Single-agent mode | `agent: { ... }` | `Agent(client, instructions, tools)`; session-aware |
| Agent-as-tool composition | `agent.tools[].agent: <name>` | Exposes another agent as a callable tool |
| Workflow mode (graph) | `workflow: { executors:, edges: }` | Pregel BSP superstep execution |
| Workflow topologies | `edges[].kind: direct / chain / fan_out / fan_in / switch_case` | Maps to `add_edge` / `add_chain` / `add_fan_out_edges` / `add_fan_in_edges` / `add_switch_case_edge_group` |
| LLM providers | `llm.provider` | `openai`, `azure_openai`, `foundry`, `anthropic`, `bedrock`, `custom` |
| Unified OpenAI/Azure client | single `OpenAIChatClient` with `azure_endpoint` branch | No separate `AzureOpenAIChatClient` — differs from OAI backend |
| Azure RBAC | `llm.config.azure_identity: true` | `DefaultAzureCredential` + `get_bearer_token_provider` |
| Foundry-hosted tools | `tools.builtin: [web_search, file_search, code_interpreter, hosted_mcp]` | `FoundryHostedToolType` via `FoundryChatClient` |
| Custom Python plugins | `plugins[]` | `@tool`-decorated modules with optional `functions:` filter |
| MCP (3 transports) | `mcp_servers:` | stdio / HTTP / **WebSocket** (new vs other backends) |
| Sessions | `--thread-id` bridged to `AgentSession` | Service-managed (Foundry/Responses) OR client-managed (Chat Completions) |
| Workflow checkpoints | `persistence.backend: file` | `FileCheckpointStorage(base_path=...)` — MAF-native schema |
| Middleware hooks | `middleware:` + cross-backend `observers:` | `AgentMiddleware` / `ChatMiddleware` / `FunctionMiddleware` |
| OpenTelemetry tracing | `OTEL_TRACES_ENABLED=true` | **MAF auto-emits `gen_ai.*` spans** via `configure_otel_providers()` — no manual span code |
| Cross-backend `guards:` / `optimizers:` / `observers:` | same top-level keys | Compile to `AgentMiddleware` / `FunctionMiddleware` |
| Cross-backend persistence | SQLite / PostgreSQL / memory | Same interface — stores the thread-id binding |
| AES-GCM encryption at rest | `AGENTFLOW_ENCRYPTION_KEY` | Same convention as other backends |

---

## Not supported (SDK or provider limitations)

| Gap | Workaround |
| --- | --- |
| Declarative YAML (MAF's own `agent_framework_declarative`) | Still beta at 1.0.0b. We use the Python API directly and surface our own YAML — same pattern as every other backend. |
| `agent_framework_declarative`'s PowerFx expressions | Not surfaced; use standard `${VAR}` env interpolation instead. |
| Workflow-level human-in-the-loop (`RequestInfoEvent`) | v1 skips HITL; surfaces in v2 under `human_in_loop:` |
| Sync API | SDK is async-only; `agentflow.create()` returns an async builder. |
| `fan_in` → plain `AgentExecutor` sink | MAF's validator requires a sink that accepts `list[AgentExecutorResponse]`. Use a `FunctionExecutor` as the fan-in sink (via `executor.function: {module, function}` in YAML) that aggregates the responses. Direct agent-to-agent fan_in fails `validate_workflow_graph` at build time. |

---

## Key design decisions

### 1. Mode discrimination, not mode enum

Instead of a `mode: agent | workflow` field, the schema **structurally discriminates**:

- Presence of `agent:` (singular) → agent mode
- Presence of `workflow:` → workflow mode
- Exactly one required; cross-validator enforces

> **Consequence:** the YAML shape *is* the mode — no redundant enum to keep in sync. Matches how SK splits `agent:` vs `agents:` + `orchestration:`.

### 2. Agent-as-tool composition, not peer-graph handoffs

MAF's idiomatic composition is `agent.as_tool()` — one agent calls another by invoking it as a tool. This is subtly different from OAI's native handoff (which transfers conversation ownership). We surface agent-as-tool directly in the tools list:

```yaml
agent:
  tools:
    - { agent: billing }        # compose billing agent as a tool
    - { agent: technical }
```

> **Consequence:** users compose without learning a second primitive. No need for a `handoffs:` block because MAF's delegation model *is* tool-calling.

### 3. Workflow graph edges, not nested blocks

MAF's `WorkflowBuilder` is fluent (`.add_edge`, `.add_chain`, `.add_fan_in_edges`, `.add_switch_case_edge_group`). We surface as a flat list of edge-group records, each with a `kind:` discriminator:

```yaml
workflow:
  start_executor: triage
  max_iterations: 100
  executors:
    triage: { agent: triage }
    billing: { agent: billing }
    support: { agent: support }
  edges:
    - { kind: switch_case, source: triage, cases: [...] }
    - { kind: fan_in, sources: [billing, support], target: summarizer }
```

> **Consequence:** every topology composes; the builder pass renders each edge-record into the corresponding `WorkflowBuilder` method call.

### 4. One client class for OpenAI + Azure OpenAI

Unlike OAI (two different client classes), MAF's `OpenAIChatClient` handles both. Our `service_factory.apply_llm_config()` branches on the `provider:` field and routes to the same constructor with different kwargs:

- `provider: openai` → `OpenAIChatClient(model=..., api_key=..., base_url=...)`
- `provider: azure_openai` → `OpenAIChatClient(model=..., azure_endpoint=..., api_version=..., credential=...)`

> **Consequence:** no `azure_deployment:` → `model` bridge like OAI. The Azure deployment name *is* the `model` value when using Azure endpoint.

### 5. Native OTel — call the framework, don't emit manually

MAF auto-emits `gen_ai.*` semconv spans:

- `invoke_agent <name>` with `gen_ai.usage.input_tokens` / `output_tokens`
- `chat <model>` per LLM call
- `execute_tool <function>` per tool invocation

Plus metrics: `gen_ai.client.operation.duration`, `gen_ai.client.token.usage`, `agent_framework.function.invocation.duration`.

Our `agentflow.maf.telemetry.setup_tracing()` calls `configure_otel_providers()` (MAF-native, reads `OTEL_*` env vars automatically) instead of rolling our own `TracerProvider`. We add **one** span — the `agentflow.maf.run` root wrapper — so the trace is keyed by `thread_id`.

> **Consequence:** less code, better native integration, no duplicate spans. OAI / CAS lessons about `include_usage=True` don't apply — MAF handles this internally.

### 6. Session bridge, not ChatHistory serialization

Like OAI and CAS, MAF owns the conversation:

- **Service-managed** (Foundry, OpenAI Responses API) → `AgentSession.service_session_id` is the remote thread id
- **Client-managed** (OpenAI Chat Completions, Anthropic) → `AgentSession.state` holds local history

Our `MafPersistenceManager` stores a `thread_id → AgentSession.session_id` binding table (same shape as CAS/OAI) plus audit metadata.

> **Consequence:** `--thread-id` works the same way across all six backends. `AGENTFLOW_ENCRYPTION_KEY` protects the binding table.

### 7. Middleware, not compiled-to-hooks

MAF exposes three middleware interfaces (`AgentMiddleware`, `ChatMiddleware`, `FunctionMiddleware`), each with a single `process(context, call_next)` method. Our `guards:` / `optimizers:` / `observers:` compile to specific middleware layers:

- `pii`, `model_call_limit`, custom guardrails → `ChatMiddleware` (runs before LLM call; `MiddlewareTermination` aborts the request)
- `tool_call_limit`, `tool_retry`, `audit_log`, `latency_tracking`, custom tool observers → `FunctionMiddleware`
- `cost_tracking` (with `budget_limit` enforcement) → `AgentMiddleware` (wraps the whole invocation to see the final `UsageDetails`)
- `prompt_caching` → **no middleware** — patches `ModelSettings.prompt_cache_retention` directly

> **Consequence:** the cross-backend portable tier works here with one middleware dispatch path. No separate hook system like CAS. Counter-based guards use `MiddlewareTermination` (the SDK's intentional-stop exception) which propagates cleanly.

### 8. WebSocket MCP is available — first AgentFlow backend to surface it

MAF adds `MCPWebsocketTool` alongside stdio + HTTP. Our schema lists `transport: websocket` as a valid value.

> **Consequence:** users migrating to MAF from other backends gain WebSocket MCP for free.

### 9. Closest cousin: OAI + workflows hybrid

- Agent mode internals ≈ **OAI** (single client, tools list, session) → copy `oai/core/service_factory.py`, `oai/core/plugin_registry.py`, `oai/persistence.py`
- Workflow graph ≈ **workflows** (LangGraph) → copy LangGraph node/edge shape, adapt to MAF's edge-group API

> **Consequence:** we re-use proven patterns. The builder has two code paths that don't cross.

---

## Provider matrix

| YAML `provider:` | MAF class | Auth |
| --- | --- | --- |
| `openai` | `OpenAIChatClient(api_key, base_url)` | API key |
| `azure_openai` | `OpenAIChatClient(azure_endpoint, api_version, credential)` | API key OR Azure RBAC |
| `foundry` | `FoundryChatClient(project_endpoint, credential)` | Azure RBAC (DefaultAzureCredential) |
| `anthropic` | `AnthropicClient(api_key, model)` | API key |
| `bedrock` | `BedrockChatClient(model, ...)` | AWS creds |
| `custom` | user pre-configures | — |

---

## Example — agent mode

```yaml
backend: agent-framework

metadata:
  version: "1.0"
  name: customer-support

llm:
  provider: azure_openai
  config:
    model: csdep-gpt-4o
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true

agent:
  name: orchestrator
  instructions: |
    Route questions to the right specialist agent.
  tools:
    - { agent: billing }              # agent-as-tool composition
    - { agent: technical }
  model_settings:
    temperature: 0.2
    parallel_tool_calls: false

agents:                                # auxiliary agents used as tools
  billing:
    instructions: "Handle billing inquiries."
    plugins:
      - { name: orders, module: myapp.billing_tools }
  technical:
    instructions: "Handle technical support."
    plugins:
      - { name: kb, module: myapp.kb_tools }

guards:
  - { type: pii }
  - { type: tool_call_limit, config: {max_calls: 50} }

observers:
  - { type: audit_log }
  - { type: cost_tracking, config: {budget_limit: 5.00} }
  - { type: latency_tracking }

mcp_servers:
  live-data:
    transport: websocket               # NEW — not available on other backends
    url: wss://mcp.internal/stream
    headers: { Authorization: "Bearer ${MCP_TOKEN}" }
```

## Example — workflow mode

```yaml
backend: agent-framework

metadata: { version: "1.0", name: pharma-investigation }

llm:
  provider: openai
  config: { model: gpt-4o, api_key: ${OPENAI_API_KEY} }

workflow:
  start_executor: triage
  max_iterations: 50
  executors:
    triage: { agent: triage_agent }
    manufacturing: { agent: manufacturing_agent }
    qa: { agent: qa_agent }
    regulatory: { agent: regulatory_agent }
    summarizer: { agent: summary_agent }
  edges:
    - kind: switch_case
      source: triage
      cases:
        - { when: "category == 'manufacturing'", target: manufacturing }
        - { when: "category == 'qa'", target: qa }
      default: regulatory
    - kind: fan_in
      sources: [manufacturing, qa, regulatory]
      target: summarizer

agents:
  triage_agent:
    instructions: "Classify the investigation type."
  manufacturing_agent:
    instructions: "Pull historian data."
  qa_agent:
    instructions: "Classify severity."
  regulatory_agent:
    instructions: "Check GxP compliance."
  summary_agent:
    instructions: "Compile the final disposition."
```

---

## Known issues

### `ImportError: cannot import name 'Agent' from 'agent_framework'`

Caused by the broken alpha package `agent-framework-azure-ai-search==0.0.0a1`, which ships a zero-byte `agent_framework/__init__.py` that masks `agent-framework-core`'s real 11269-byte init when pip resolves the two sibling namespace packages in an unfortunate order (common after any `pip install --force-reinstall` cycle, or reinstalling from a `pip freeze` dump that pins the alpha).

**Fix** — run these two commands in order (sequential install is required; a combined `--force-reinstall --no-deps` over both packages can leave the `__init__.py` missing on some pip versions):

```bash
pip install --no-cache-dir --upgrade 'agent-framework-azure-ai-search>=1.0.0b251204'
pip uninstall -y agent-framework-core && pip install --no-cache-dir 'agent-framework-core==1.1.1'
```

Newer versions of the sibling package are proper PEP 420 namespace packages and don't ship an `__init__.py` at all, so once the alpha is replaced the collision disappears permanently.

**Fresh installs of `agentflow[agent-framework]` are safe.** Our extra requires only `agent-framework>=1.1.0`, whose transitive closure is just `agent-framework-core` — the broken alpha is never pulled in. (We did try pinning `agent-framework-azure-ai-search>=1.0.0b251204` forward, but newer versions of that sibling transitively require pre-release `azure-search-documents>=11.7.0b2`, which makes the install fail without `--prerelease=allow`. So the forward-pin is worse than no pin.)

The poisoning only happens when a user reinstalls from an old `pip freeze` dump that pinned `0.0.0a1`, or after `pip install agent-framework-core[all]` at some point. `agentflow.maf.__init__` detects the zero-byte file on import and raises `RuntimeError` with the exact two-command fix shown above.

## Further reading

- [Microsoft Agent Framework Overview](https://learn.microsoft.com/en-us/agent-framework/overview/?pivots=programming-language-python)
- [WorkflowBuilder & edges](https://learn.microsoft.com/en-us/agent-framework/workflows/edges)
- [Sessions](https://learn.microsoft.com/en-us/agent-framework/agents/conversations/session)
- [Observability](https://learn.microsoft.com/en-us/agent-framework/agents/observability)
- [GitHub: microsoft/agent-framework](https://github.com/microsoft/agent-framework)
- Sibling backend READMEs: [`workflows/`](../workflows/), [`deep/`](../deep/), [`sk/`](../sk/), [`cas/`](../cas/), [`oai/`](../oai/)

## License

This project is governed by the Accenture Internal Open-source Agreement. See the root [LICENSE](../../../LICENSE) for complete terms.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
