"""Resolve :class:`MiddlewareRef` entries into MAF middleware instances.

MAF exposes three middleware interfaces (``AgentMiddleware``,
``ChatMiddleware``, ``FunctionMiddleware``) each with a single
``process(context, call_next)`` method. User classes must subclass the
appropriate one — we just import the class by ref and instantiate it with
no arguments (the standard MAF convention).
"""

from __future__ import annotations

import importlib
from typing import Any, List

from agentflow.maf.core.config_models import MiddlewareKind, MiddlewareRef


def resolve_middleware(refs: List[MiddlewareRef] | None) -> List[Any]:
    """Return a list of instantiated middleware objects.

    The builder passes the list to ``Agent(middleware=[...])`` (or the
    client's ``middleware=`` kwarg).
    """
    if not refs:
        return []
    out: List[Any] = []
    for ref in refs:
        cls = _load_class(ref.module, ref.class_name)
        out.append(cls())
    return out


def partition_by_kind(
    refs: List[MiddlewareRef] | None,
) -> "dict[MiddlewareKind, List[MiddlewareRef]]":
    """Group middleware refs by ``kind`` for provider-specific dispatch."""
    buckets: "dict[MiddlewareKind, List[MiddlewareRef]]" = {k: [] for k in MiddlewareKind}
    if not refs:
        return buckets
    for r in refs:
        buckets[r.kind].append(r)
    return buckets


def _load_class(module_path: str, class_name: str) -> type:
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Middleware module {module_path!r} could not be imported: {exc}"
        ) from exc
    cls = getattr(mod, class_name, None)
    if cls is None:
        raise AttributeError(
            f"Middleware class {class_name!r} not found in {module_path!r}"
        )
    return cls
