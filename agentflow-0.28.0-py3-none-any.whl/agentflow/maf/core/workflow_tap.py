"""Workflow-mode tool-event tap.

MAF's workflow stream only emits executor-lifecycle events
(``executor_invoked`` / ``_completed`` / ``_failed`` etc.). Tool calls
inside an ``AgentExecutor`` happen in the agent's internal run and don't
bubble up to the outer stream, so the user sees ``▶ triage`` / ``✓ triage``
without any indication of what tools ran.

This module attaches a :class:`WorkflowToolTap` — a thin
``FunctionMiddleware`` — to every agent a workflow uses. The tap
publishes a ``{"kind": ..., "agent": ..., "name": ..., ...}`` dict to
an ``asyncio.Queue`` before (``call``) and after (``result`` or
``error``) each tool invocation. The runner exposes that queue so the
CLI / UI renderers can merge it with the workflow stream and interleave
tool markers between executor lifecycle events.

The tap is a no-op outside workflow mode — agent-mode builds use the
native :class:`AgentResponseUpdate` content-stream instead, which
already surfaces ``function_call`` / ``function_result`` directly.
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional

try:
    from agent_framework import FunctionMiddleware as _FunctionMiddleware
except ImportError:  # pragma: no cover — handled at import time
    _FunctionMiddleware = object  # type: ignore[assignment,misc]


class WorkflowToolTap(_FunctionMiddleware):  # type: ignore[misc,valid-type]
    """``FunctionMiddleware`` subclass that publishes tool events.

    One instance per agent (each closing over the agent's name) so the
    consumer can attribute each event to its executor.

    **Must inherit from ``FunctionMiddleware``** — MAF's ``Agent`` sorts
    the ``middleware`` list by ``isinstance`` checks to decide whether a
    handler goes on the chat pipeline, the function pipeline, or the
    agent pipeline. A duck-typed object with a ``process()`` method is
    silently dropped.

    The tap holds a reference to an ``asyncio.Queue``. MAF deep-copies
    ``default_options`` on every run, and although we don't put the tap
    there anymore, agent-scoped state still gets copied in places;
    overriding ``__deepcopy__`` to return ``self`` keeps every copy
    sharing the same queue (so all copies publish to one consumer)
    and sidesteps the ``cannot pickle '_asyncio.Future'`` crash that
    plain copy of the Queue would trigger.
    """

    def __init__(self, queue: "asyncio.Queue[dict]", agent_name: str):
        # FunctionMiddleware's ABC has no required constructor args, so
        # we don't call super().__init__() — its __init__ is a no-op.
        self._queue = queue
        self._agent = agent_name

    def __deepcopy__(self, memo):  # noqa: D401 — short override
        return self

    def __copy__(self):
        return self

    async def process(self, context: Any, call_next: Any) -> None:
        fn = getattr(context, "function", None)
        name = (
            getattr(fn, "name", None)
            or getattr(context, "function_name", None)
            or "<tool>"
        )
        arguments = _normalize_arguments(getattr(context, "arguments", None))

        await self._queue.put({
            "kind": "call",
            "agent": self._agent,
            "name": name,
            "arguments": arguments,
        })

        try:
            await call_next()
        except Exception as exc:
            await self._queue.put({
                "kind": "error",
                "agent": self._agent,
                "name": name,
                "exception": str(exc),
            })
            raise

        await self._queue.put({
            "kind": "result",
            "agent": self._agent,
            "name": name,
            "result": _normalize_result(getattr(context, "result", None)),
        })


def _normalize_result(result: Any) -> Any:
    """Unwrap MAF's ``list[Content]`` envelope into something renderable.

    Tool functions in MAF return their value, but the framework wraps
    the value in ``[Content(type='function_result', text='{json}')]``
    before middleware sees it on ``context.result``. Downstream
    consumers (CLI / UI) want either the raw dict the tool returned, a
    string preview, or — at worst — a list of strings. We do that
    extraction once here so the renderer never has to know about
    ``Content`` at all.

    Strategy:

    - If it's a list of ``Content``-like objects (single ``.text``
      string each), join the texts. With one element, return the text
      directly so JSON detection further downstream sees a clean string.
    - If it's a single ``Content``-like object, return its ``.text``.
    - Otherwise, return as-is.
    """
    if result is None:
        return None
    if isinstance(result, list):
        texts = []
        for item in result:
            text = _content_text(item)
            if text is None:
                # Not a Content envelope — bail out, keep original list
                return result
            texts.append(text)
        if len(texts) == 1:
            return texts[0]
        return texts
    text = _content_text(result)
    if text is not None:
        return text
    return result


def _content_text(value: Any) -> Optional[str]:
    """Pull ``.text`` from an ``agent_framework._types.Content`` instance.

    Returns None for anything else so callers can detect non-Content
    inputs and fall through.
    """
    if value is None:
        return None
    # Plain string passes through (already extracted)
    if isinstance(value, str):
        return value
    # Duck-typed Content — has a ``type`` discriminator AND a ``text``
    # field. Don't isinstance-check against agent_framework._types here
    # to keep the tap importable in tests where the SDK isn't loaded.
    ctype = getattr(value, "type", None)
    if ctype is None:
        return None
    text = getattr(value, "text", None)
    if isinstance(text, str):
        return text
    return None


def _normalize_arguments(args: Any) -> Any:
    """Coerce pydantic models to dicts so downstream renderers get JSON."""
    if args is None:
        return None
    # pydantic v2 models expose ``model_dump`` and ``__class__.__name__``.
    dump = getattr(args, "model_dump", None)
    if callable(dump):
        try:
            return dump()
        except Exception:
            pass
    if isinstance(args, dict):
        return dict(args)
    return args


def install_tool_taps(
    agents_by_name: dict,
    queue: "asyncio.Queue[dict]",
) -> None:
    """Attach one :class:`WorkflowToolTap` to each agent.

    Mutates the ``agent.middleware`` attribute directly — that's the
    public list MAF's ``Agent`` reads to dispatch middleware into the
    right pipeline (function / chat / agent). We must NOT push the tap
    through ``default_options["middleware"]`` because that dict is
    forwarded verbatim to the chat client's ``create()`` call, and
    ``AsyncResponses.create()`` rejects the unknown ``middleware`` key.

    Idempotent per (agent, queue) pair — re-running installs at most
    one tap per queue on any given agent.
    """
    for name, agent in agents_by_name.items():
        existing = list(getattr(agent, "middleware", None) or [])
        # Skip if we already installed a tap for this queue
        if any(
            isinstance(m, WorkflowToolTap) and m._queue is queue
            for m in existing
        ):
            continue
        existing.append(WorkflowToolTap(queue, agent_name=name))
        agent.middleware = existing


def drain_ready(queue: "asyncio.Queue[dict]") -> list[dict]:
    """Non-blocking: pull every currently-queued event and return them.

    Useful when you want to flush remaining taps after the workflow
    stream ends without awaiting further.
    """
    events: list[dict] = []
    while True:
        try:
            events.append(queue.get_nowait())
        except asyncio.QueueEmpty:
            break
    return events
