"""Pydantic config models for the Microsoft Agent Framework (MAF) YAML schema.

MAF has two distinct execution models; the schema structurally discriminates:

- **Agent mode**: presence of ``agent:`` (singular). Builds a single ``Agent``
  instance; multi-agent composition is via ``agent-as-tool`` entries in
  ``agent.tools``.
- **Workflow mode**: presence of ``workflow:``. Builds a ``WorkflowBuilder``
  graph of ``AgentExecutor`` nodes connected by direct / chain / fan-out /
  fan-in / switch-case edges.

Exactly one of ``agent:`` or ``workflow:`` must be set. A cross-validator
enforces this.

Schema shape (agent mode)::

    backend: agent-framework
    metadata: { version, name, ... }
    llm: { provider, config }

    agent:                         # singular — agent mode
      name: orchestrator
      instructions: "..."
      tools:
        builtin: [web_search]
        - { agent: billing }       # agent-as-tool composition
      plugins: [...]
      mcp_servers: [live-data]
      model_settings: { ... }

    agents:                        # auxiliary agents callable via {agent: name}
      billing: { instructions, plugins, ... }

    guards: [...] / optimizers: [...] / observers: [...]
    mcp_servers: { <name>: { transport, ... } }

Schema shape (workflow mode)::

    backend: agent-framework
    metadata: { ... }
    llm: { provider, config }

    workflow:                      # graph mode
      start_executor: triage
      max_iterations: 50
      executors:
        triage: { agent: triage_agent }
        billing: { agent: billing_agent }
      edges:
        - { kind: direct, source: triage, target: billing, condition: "..." }
        - { kind: chain, executors: [...] }
        - { kind: fan_out, source: X, targets: [A, B] }
        - { kind: fan_in, sources: [A, B], target: Y }
        - { kind: switch_case, source: X, cases: [{when, target}], default: Y }

    agents: { triage_agent: {...}, billing_agent: {...}, ... }
"""

from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator

from agentflow.genui import UIToolsConfig


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


class MafMetadata(BaseModel):
    version: str = Field(..., description="Schema version (e.g. '1.0').")
    name: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    tags: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------


class LLMProvider(str, Enum):
    """LLM providers supported by the MAF backend.

    Unlike OAI, MAF's ``OpenAIChatClient`` covers BOTH the OpenAI public API
    and Azure OpenAI — the provider flag selects the constructor kwarg set.
    """

    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    FOUNDRY = "foundry"            # Azure AI Foundry (FoundryChatClient)
    ANTHROPIC = "anthropic"
    BEDROCK = "bedrock"            # AWS Bedrock
    CUSTOM = "custom"              # user pre-configures the client


class LLMConfig(BaseModel):
    """Top-level or per-agent LLM config.

    Common keys across providers: ``model``, ``api_key``, ``base_url``.
    Azure-specific: ``azure_endpoint``, ``api_version``, ``azure_identity``.
    Foundry-specific: ``project_endpoint``, ``credential``.
    Anthropic-specific: ``api_key``, ``model``.
    Bedrock-specific: ``region_name``, ``aws_profile``.
    """

    provider: LLMProvider = Field(default=LLMProvider.OPENAI)
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Provider-specific config. Passed to the corresponding MAF "
            "client constructor. ${VAR} env interpolation applied before "
            "validation."
        ),
    )


# ---------------------------------------------------------------------------
# Model settings (subset of ChatOptions)
# ---------------------------------------------------------------------------


class ReasoningOptionsConfig(BaseModel):
    """OpenAI reasoning model options (o1/o3/gpt-5 family)."""

    effort: Optional[Literal["low", "medium", "high"]] = None
    summary: Optional[Literal["auto", "concise", "detailed"]] = None


class ModelSettingsConfig(BaseModel):
    """Subset of MAF's ChatOptions fields that apply across providers.

    Per-provider extras can still be passed via ``extra_args``.
    """

    temperature: Optional[float] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    max_tokens: Optional[int] = Field(None, gt=0)
    seed: Optional[int] = None
    stop: Optional[Union[str, List[str]]] = None
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None
    allow_multiple_tool_calls: Optional[bool] = None
    response_format: Optional[Dict[str, Any]] = None
    reasoning: Optional[ReasoningOptionsConfig] = None
    metadata: Optional[Dict[str, Any]] = None
    user: Optional[str] = None
    store: Optional[bool] = None
    prompt_cache_retention: Optional[Literal["24h"]] = None
    prompt_cache_key: Optional[str] = None
    service_tier: Optional[Literal["auto", "default", "flex", "priority"]] = None
    truncation: Optional[Literal["auto", "disabled"]] = None
    top_logprobs: Optional[int] = None
    max_tool_calls: Optional[int] = None

    # Pass-through bucket for provider-specific fields not modeled above.
    extra_args: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


class BuiltinTool(str, Enum):
    """Hosted built-in tools.

    The first four require a Foundry-compatible client (``FoundryChatClient``
    or an OpenAI Responses-API endpoint); ``mcp`` bridges a configured
    ``mcp_servers:`` entry as a hosted tool rather than a local client.
    """

    WEB_SEARCH = "web_search"
    FILE_SEARCH = "file_search"
    CODE_INTERPRETER = "code_interpreter"
    IMAGE_GENERATION = "image_generation"
    HOSTED_MCP = "hosted_mcp"


class BuiltinToolConfig(BaseModel):
    """One built-in tool + its optional config passthrough."""

    name: BuiltinTool
    config: Dict[str, Any] = Field(default_factory=dict)


class AgentToolRef(BaseModel):
    """Agent-as-tool composition — expose another agent as a callable tool."""

    agent: str = Field(..., description="Target agent name (must exist in agents:)")
    tool_name: Optional[str] = Field(
        None,
        description="Override the tool name exposed to the LLM (default: agent name).",
    )
    description: Optional[str] = None
    approval_mode: Optional[Literal["always_require", "never_require"]] = None
    propagate_session: bool = False


# A single ``tools:`` entry can be a bare builtin name, a detailed builtin
# spec, or an agent-as-tool reference.
ToolEntry = Union[BuiltinTool, BuiltinToolConfig, AgentToolRef]


class ToolsConfig(BaseModel):
    """Tools available to an agent.

    Accepts mixed entries:

    - Bare enum: ``- web_search``
    - Detailed builtin: ``- {name: file_search, config: {vector_store_ids: [...]}}``
    - Agent-as-tool: ``- {agent: billing}``
    """

    builtin: List[ToolEntry] = Field(default_factory=list)

    def normalized(self) -> List[Union[BuiltinToolConfig, AgentToolRef]]:
        """Promote bare enum entries to ``BuiltinToolConfig`` for downstream use."""
        out: List[Union[BuiltinToolConfig, AgentToolRef]] = []
        for item in self.builtin:
            if isinstance(item, BuiltinTool):
                out.append(BuiltinToolConfig(name=item))
            else:
                out.append(item)
        return out


# ---------------------------------------------------------------------------
# Plugins (custom @tool-decorated Python functions)
# ---------------------------------------------------------------------------


class PluginType(str, Enum):
    PYTHON = "python"


class PluginRef(BaseModel):
    """Reference to a Python module of ``@tool``-decorated functions."""

    name: str = Field(..., description="Logical plugin name (telemetry).")
    type: PluginType = Field(default=PluginType.PYTHON)
    module: str = Field(..., description="Python module path.")
    functions: Optional[List[str]] = Field(
        None,
        description="Restrict to these function names (default: all @tool-decorated).",
    )


# ---------------------------------------------------------------------------
# Middleware (cross-backend observers compile to these too)
# ---------------------------------------------------------------------------


class MiddlewareKind(str, Enum):
    AGENT = "agent"           # AgentMiddleware — wraps agent invocations
    CHAT = "chat"             # ChatMiddleware — wraps LLM calls
    FUNCTION = "function"     # FunctionMiddleware — wraps tool calls


class MiddlewareRef(BaseModel):
    """User-provided middleware implementation.

    Matches MAF's three middleware interfaces. The builder imports the class
    and adds it to the appropriate list on the Agent / ChatClient.
    """

    kind: MiddlewareKind = MiddlewareKind.AGENT
    module: str = Field(..., description="Python module path.")
    class_name: str = Field(..., description="Middleware subclass name.")


# ---------------------------------------------------------------------------
# MCP servers — 3 transports (stdio / http / websocket)
# ---------------------------------------------------------------------------


class MCPTransport(str, Enum):
    STDIO = "stdio"
    HTTP = "http"              # MCPStreamableHTTPTool
    WEBSOCKET = "websocket"    # MCPWebsocketTool — new vs other backends


class MCPServerEntry(BaseModel):
    transport: MCPTransport = Field(default=MCPTransport.STDIO)

    # stdio-specific
    command: Optional[str] = None
    args: Optional[List[str]] = None
    env: Optional[Dict[str, str]] = None

    # http / websocket
    url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    terminate_on_close: Optional[bool] = None

    # shared
    tool_name_prefix: Optional[str] = None
    request_timeout: Optional[int] = Field(None, gt=0)
    load_tools: bool = True
    load_prompts: bool = True
    allowed_tools: Optional[List[str]] = None
    approval_mode: Optional[Literal["always_require", "never_require"]] = None
    description: Optional[str] = None

    @model_validator(mode="after")
    def _validate_transport_fields(self) -> "MCPServerEntry":
        if self.transport == MCPTransport.STDIO:
            if not self.command:
                raise ValueError("MCP transport 'stdio' requires 'command'")
        else:
            if not self.url:
                raise ValueError(
                    f"MCP transport {self.transport.value!r} requires 'url'"
                )
        return self


# ---------------------------------------------------------------------------
# Cross-backend portable tier (shared enum vocabulary with SK/CAS/OAI)
# ---------------------------------------------------------------------------


class GuardType(str, Enum):
    PII = "pii"
    MODEL_CALL_LIMIT = "model_call_limit"
    TOOL_CALL_LIMIT = "tool_call_limit"
    INPUT_VALIDATION = "input_validation"
    CONTENT_FILTER = "content_filter"


class GuardConfig(BaseModel):
    type: GuardType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class OptimizerType(str, Enum):
    TOOL_RETRY = "tool_retry"
    SUMMARIZATION = "summarization"
    PROMPT_CACHING = "prompt_caching"


class OptimizerConfig(BaseModel):
    type: OptimizerType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class ObserverType(str, Enum):
    AUDIT_LOG = "audit_log"
    COST_TRACKING = "cost_tracking"
    LATENCY_TRACKING = "latency_tracking"


class ObserverConfig(BaseModel):
    type: ObserverType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


# ---------------------------------------------------------------------------
# Checkpointing (workflow mode only)
# ---------------------------------------------------------------------------


class CheckpointConfig(BaseModel):
    """MAF-native workflow checkpoint storage.

    ``file`` uses ``FileCheckpointStorage(base_path=...)`` — checkpoints at
    superstep boundaries. ``memory`` is per-process (no persistence). No
    ``sqlite``/``postgres`` here — those are for the AgentFlow thread-id
    binding, not MAF's own checkpoints.
    """

    backend: Literal["memory", "file"] = Field(default="memory")
    base_path: Optional[str] = Field(
        None,
        description="Directory for file checkpoints (required when backend='file').",
    )

    @model_validator(mode="after")
    def _validate_backend(self) -> "CheckpointConfig":
        if self.backend == "file" and not self.base_path:
            raise ValueError("CheckpointConfig.backend='file' requires 'base_path'")
        return self


# ---------------------------------------------------------------------------
# AgentSpec — one agent definition
# ---------------------------------------------------------------------------


class AgentSpec(BaseModel):
    """One agent.

    Used either as the single top-level ``agent:`` (agent mode) or as an
    entry in ``agents:`` (referenced by agent-as-tool in agent mode, or by
    workflow executors in workflow mode).
    """

    name: Optional[str] = None
    instructions: Optional[str] = Field(
        None,
        description="System prompt / persona.",
    )
    description: Optional[str] = None
    id: Optional[str] = Field(
        None,
        description="Stable agent id (used as gen_ai.agent.id in telemetry).",
    )

    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    plugins: Optional[List[PluginRef]] = None
    mcp_servers: Optional[List[str]] = Field(
        None,
        description="References to top-level mcp_servers entries by name.",
    )

    # Cross-backend generative-UI components. The model is the same
    # one used by other AG-UI-supporting backends so a single YAML
    # block works everywhere.
    ui_tools: Optional[UIToolsConfig] = Field(
        None,
        description=(
            "Generative-UI components: a module of "
            "``@agentflow.genui.ui_component``-decorated fetchers exposed "
            "as MAF tools. The MAF resolver wraps each fetcher to emit "
            "``agent_framework_ag_ui.state_update(...)``, which the upstream "
            "bridge surfaces as both a chat-side text result and a "
            "frontend-side typed render event."
        ),
    )

    # Cross-backend predicate gating. Each entry is
    # ``{component_class_name: simpleeval_expression}``. Predicates
    # evaluate at **agent-construction time** against the deployment's
    # build state (env-derived or passed to ``build_agui``); tools
    # whose predicate is falsy are excluded from the agent's tool list
    # permanently. Dynamic per-call gating is not implemented on MAF
    # in this release; see ``src/agentflow/maf/docs/AG_UI.md`` for the
    # rationale.
    available_when: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Predicate gating for ``ui_tools``: "
            "``{ComponentClassName: \"state.user_role == 'manager'\"}``. "
            "Evaluated at agent-construction time against the deployment "
            "build state. Tools with falsy predicates are excluded from "
            "the LLM's tool list."
        ),
    )

    # Per-agent LLM override (otherwise inherits top-level llm:)
    llm: Optional[LLMConfig] = None

    model_settings: Optional[ModelSettingsConfig] = None

    # Middleware attached at the agent level
    middleware: Optional[List[MiddlewareRef]] = None


# ---------------------------------------------------------------------------
# WorkflowSpec — graph of executors + edges
# ---------------------------------------------------------------------------


class ExecutorSpec(BaseModel):
    """One workflow node.

    ``agent:`` refers to an entry in the top-level ``agents:`` dict.
    ``function:`` is a user-provided callable registered as ``FunctionExecutor``.
    """

    agent: Optional[str] = Field(
        None, description="Agent name (from top-level agents:)."
    )
    function: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "{module, function} ref for a FunctionExecutor. Mutually "
            "exclusive with 'agent:'."
        ),
    )
    id: Optional[str] = None

    @model_validator(mode="after")
    def _validate_one_of(self) -> "ExecutorSpec":
        if bool(self.agent) == bool(self.function):
            raise ValueError(
                "ExecutorSpec must have exactly one of 'agent:' or 'function:'"
            )
        return self


class EdgeKind(str, Enum):
    DIRECT = "direct"         # add_edge(source, target, condition=...)
    CHAIN = "chain"           # add_chain([executors...])
    FAN_OUT = "fan_out"       # add_fan_out_edges(source, targets)
    FAN_IN = "fan_in"         # add_fan_in_edges(sources, target)
    SWITCH_CASE = "switch_case"  # add_switch_case_edge_group(source, cases, default)


class SwitchCase(BaseModel):
    """One case in a switch_case edge group."""

    when: str = Field(..., description="Condition expression (evaluated at runtime).")
    target: str = Field(..., description="Executor name to route to when condition matches.")


class EdgeSpec(BaseModel):
    """One edge-group record. ``kind:`` discriminates the topology."""

    kind: EdgeKind

    # direct
    source: Optional[str] = None
    target: Optional[str] = None
    condition: Optional[str] = None

    # chain
    executors: Optional[List[str]] = None

    # fan_out / fan_in
    sources: Optional[List[str]] = None
    targets: Optional[List[str]] = None

    # switch_case
    cases: Optional[List[SwitchCase]] = None
    default: Optional[str] = None

    @model_validator(mode="after")
    def _validate_kind_fields(self) -> "EdgeSpec":
        if self.kind == EdgeKind.DIRECT:
            if not self.source or not self.target:
                raise ValueError(
                    "edge kind='direct' requires 'source' and 'target'"
                )
        elif self.kind == EdgeKind.CHAIN:
            if not self.executors or len(self.executors) < 2:
                raise ValueError(
                    "edge kind='chain' requires 'executors' list with >=2 entries"
                )
        elif self.kind == EdgeKind.FAN_OUT:
            if not self.source or not self.targets:
                raise ValueError(
                    "edge kind='fan_out' requires 'source' and 'targets'"
                )
        elif self.kind == EdgeKind.FAN_IN:
            if not self.sources or not self.target:
                raise ValueError(
                    "edge kind='fan_in' requires 'sources' and 'target'"
                )
        elif self.kind == EdgeKind.SWITCH_CASE:
            if not self.source or not self.cases:
                raise ValueError(
                    "edge kind='switch_case' requires 'source' and 'cases'"
                )
        return self


class WorkflowSpec(BaseModel):
    """Workflow graph — executors + edges. Only used in workflow mode."""

    start_executor: str = Field(
        ..., description="Entry-point executor name (must be a key in executors:)."
    )
    max_iterations: int = Field(default=100, gt=0)
    name: Optional[str] = None
    description: Optional[str] = None

    executors: Dict[str, ExecutorSpec] = Field(
        ..., description="Named nodes in the graph."
    )
    edges: List[EdgeSpec] = Field(default_factory=list)

    output_executors: Optional[List[str]] = Field(
        None,
        description="Terminal executors whose output is returned to the caller.",
    )

    checkpoint: Optional[CheckpointConfig] = None

    @model_validator(mode="after")
    def _validate_graph(self) -> "WorkflowSpec":
        if not self.executors:
            raise ValueError("workflow.executors: cannot be empty")
        if self.start_executor not in self.executors:
            raise ValueError(
                f"workflow.start_executor {self.start_executor!r} is not in "
                f"executors: {sorted(self.executors)}"
            )

        # All edge references must resolve to an executor name
        known = set(self.executors)
        for idx, edge in enumerate(self.edges):
            refs = _collect_edge_refs(edge)
            missing = [r for r in refs if r not in known]
            if missing:
                raise ValueError(
                    f"workflow.edges[{idx}] references unknown executor(s) "
                    f"{missing}. Known: {sorted(known)}"
                )

        # output_executors must resolve
        if self.output_executors:
            missing = [o for o in self.output_executors if o not in known]
            if missing:
                raise ValueError(
                    f"workflow.output_executors references unknown "
                    f"executor(s) {missing}. Known: {sorted(known)}"
                )
        return self


def _collect_edge_refs(edge: EdgeSpec) -> List[str]:
    """Return every executor name referenced by an edge spec."""
    out: List[str] = []
    for attr in ("source", "target", "default"):
        v = getattr(edge, attr, None)
        if v:
            out.append(v)
    for attr in ("executors", "sources", "targets"):
        v = getattr(edge, attr, None)
        if v:
            out.extend(v)
    if edge.cases:
        out.extend(c.target for c in edge.cases)
    return out


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


class MafYAMLConfig(BaseModel):
    """Root Microsoft Agent Framework YAML config.

    Discriminated structurally:

    - ``agent:`` (singular) → agent mode
    - ``workflow:`` (graph)  → workflow mode

    Exactly one of those two must be set. Both together, or neither, raises
    a validation error.
    """

    backend: Literal["agent-framework"] = Field(default="agent-framework")
    metadata: MafMetadata

    # Top-level LLM default (per-agent ``llm:`` overrides)
    llm: Optional[LLMConfig] = None

    # Mode — exactly one required
    agent: Optional[AgentSpec] = None
    workflow: Optional[WorkflowSpec] = None

    # Auxiliary agents — referenced by AgentToolRef (agent mode) or
    # WorkflowSpec.executors[].agent (workflow mode).
    agents: Optional[Dict[str, AgentSpec]] = None

    # Cross-backend portable tier
    guards: Optional[List[GuardConfig]] = None
    optimizers: Optional[List[OptimizerConfig]] = None
    observers: Optional[List[ObserverConfig]] = None

    # Shared middleware (applies to all agents unless overridden per-agent)
    middleware: Optional[List[MiddlewareRef]] = None

    # MCP servers (referenced by agents via agents.<name>.mcp_servers: [name])
    mcp_servers: Optional[Dict[str, MCPServerEntry]] = None

    @model_validator(mode="after")
    def _validate_structure(self) -> "MafYAMLConfig":
        # Rule 1: exactly one of agent: or workflow:
        if self.agent is None and self.workflow is None:
            raise ValueError(
                "Must set exactly one of 'agent:' (agent mode) or "
                "'workflow:' (workflow mode)."
            )
        if self.agent is not None and self.workflow is not None:
            raise ValueError(
                "Cannot set both 'agent:' and 'workflow:' — pick one mode."
            )

        # Rule 2: at least one LLM config must exist — top-level OR the
        # active mode's agent(s)
        if self.llm is None:
            if self.agent is not None and self.agent.llm is None:
                raise ValueError(
                    "No LLM configured. Set top-level 'llm:' or "
                    "'agent.llm:'."
                )
            if self.workflow is not None:
                # workflow mode — at least one executor must resolve to an
                # agent with an llm (either inherited from top-level or
                # explicit on that agent)
                agents = self.agents or {}
                for ex_name, ex_spec in self.workflow.executors.items():
                    if ex_spec.agent:
                        agent_spec = agents.get(ex_spec.agent)
                        if agent_spec and agent_spec.llm is None:
                            raise ValueError(
                                f"No LLM configured. Set top-level 'llm:' "
                                f"or per-agent 'llm:' for executor "
                                f"{ex_name!r} → agent {ex_spec.agent!r}."
                            )

        # Rule 3: agent-as-tool references resolve
        # Check top-level agent.tools for any AgentToolRef pointing at a
        # non-existent auxiliary agent.
        agents = self.agents or {}
        if self.agent and self.agent.tools:
            for entry in self.agent.tools.builtin:
                if isinstance(entry, AgentToolRef):
                    if entry.agent not in agents:
                        raise ValueError(
                            f"Agent-as-tool reference {entry.agent!r} is "
                            f"not in agents: {sorted(agents)}"
                        )

        # Rule 4: workflow executor agent references resolve
        if self.workflow is not None:
            for ex_name, ex_spec in self.workflow.executors.items():
                if ex_spec.agent and ex_spec.agent not in agents:
                    raise ValueError(
                        f"workflow.executors[{ex_name!r}].agent "
                        f"{ex_spec.agent!r} is not in agents: "
                        f"{sorted(agents)}"
                    )

        # Rule 5: every agent.mcp_servers reference must exist at top level
        known_mcp = set(self.mcp_servers or {})
        all_agents: List[tuple[str, AgentSpec]] = []
        if self.agent:
            all_agents.append(("<top>", self.agent))
        for n, spec in (self.agents or {}).items():
            all_agents.append((n, spec))
        for name, spec in all_agents:
            if not spec.mcp_servers:
                continue
            missing = [n for n in spec.mcp_servers if n not in known_mcp]
            if missing:
                raise ValueError(
                    f"Agent {name!r} references unknown mcp_servers "
                    f"{missing}. Known: {sorted(known_mcp) or 'none'}"
                )

        return self
