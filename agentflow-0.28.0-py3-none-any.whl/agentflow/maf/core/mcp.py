"""Translate YAML ``mcp_servers`` entries into MAF MCP tool instances.

MAF has three MCP client transports — the third (``websocket``) is new
relative to the OAI / CAS / SK backends:

- :class:`MCPStdioTool(name, command, args, env, ...)`
- :class:`MCPStreamableHTTPTool(name, url, headers, ...)`
- :class:`MCPWebsocketTool(name, url, ...)`
"""

from __future__ import annotations

from typing import Any, Dict

from agentflow.maf.core.config_models import MCPServerEntry, MCPTransport


def resolve_mcp_servers(
    servers: Dict[str, MCPServerEntry] | None,
) -> Dict[str, Any]:
    """Return a dict of ``{name: MCP*Tool-instance}`` — agents reference by name."""
    if not servers:
        return {}

    from agent_framework import (  # lazy
        MCPStdioTool,
        MCPStreamableHTTPTool,
        MCPWebsocketTool,
    )

    out: Dict[str, Any] = {}
    for name, entry in servers.items():
        shared_kwargs: Dict[str, Any] = {"name": name}
        if entry.tool_name_prefix:
            shared_kwargs["tool_name_prefix"] = entry.tool_name_prefix
        if entry.request_timeout is not None:
            shared_kwargs["request_timeout"] = entry.request_timeout
        shared_kwargs["load_tools"] = entry.load_tools
        shared_kwargs["load_prompts"] = entry.load_prompts
        if entry.allowed_tools is not None:
            shared_kwargs["allowed_tools"] = entry.allowed_tools
        if entry.approval_mode:
            shared_kwargs["approval_mode"] = entry.approval_mode
        if entry.description:
            shared_kwargs["description"] = entry.description

        if entry.transport == MCPTransport.STDIO:
            kwargs = {**shared_kwargs, "command": entry.command}
            if entry.args:
                kwargs["args"] = entry.args
            if entry.env:
                kwargs["env"] = entry.env
            out[name] = MCPStdioTool(**kwargs)

        elif entry.transport == MCPTransport.HTTP:
            kwargs = {**shared_kwargs, "url": entry.url}
            if entry.headers:
                # MAF exposes header_provider (callable) rather than a static
                # dict; wrap the user's dict so both shapes work.
                headers_copy = dict(entry.headers)
                kwargs["header_provider"] = lambda _: headers_copy
            if entry.terminate_on_close is not None:
                kwargs["terminate_on_close"] = entry.terminate_on_close
            out[name] = MCPStreamableHTTPTool(**kwargs)

        elif entry.transport == MCPTransport.WEBSOCKET:
            kwargs = {**shared_kwargs, "url": entry.url}
            out[name] = MCPWebsocketTool(**kwargs)

    return out
