"""Shared helpers for the MAF backend.

Mirror of ``src/agentflow/oai/core/helpers.py`` — env-var interpolation +
project ``.env`` loading anchored at the shell's CWD (not the installed
module's directory).
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def load_dotenv_for(yaml_path: str) -> None:
    """Load the project ``.env`` relative to the YAML file, falling back to CWD.

    Critical: anchor at the user's cwd — the installed module's directory
    must not shadow a project-local .env.

    Call order:

    1. ``<yaml_dir>/.env`` — the .env that sits next to the YAML (highest
       priority, loaded with ``override=True``).
    2. ``<cwd>/.env`` (walked up from the user's cwd, **not** the installed
       module's directory) — the ``find_dotenv(usecwd=True)`` anchor is
       what prevents a stale site-packages-adjacent .env from overwriting
       the good values we just loaded.

    Using ``override=True`` on both calls means the cwd-anchored .env
    wins over the yaml-adjacent one if both are set — that's usually what
    the user wants (running from a project root with its own secrets).
    Neither call walks into the installed module's directory.
    """
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:  # pragma: no cover
        return

    yaml_dir = Path(yaml_path).resolve().parent
    load_dotenv(yaml_dir / ".env", override=True)

    # Anchor the fallback walk at the user's cwd — NOT at the caller's
    # module location. Without usecwd=True the default find_dotenv walks up
    # from this file's path (~/.../site-packages/agentflow/maf/core/helpers.py),
    # which on some layouts passes through a stale ancestor .env (e.g.
    # ~/Labs/agentflow/.env) and clobbers the yaml-adjacent values we just
    # loaded. Loud bug — don't remove this flag.
    cwd_dotenv = find_dotenv(usecwd=True)
    if cwd_dotenv and Path(cwd_dotenv).resolve() != (yaml_dir / ".env").resolve():
        load_dotenv(cwd_dotenv, override=True)


def resolve_env_vars(value: Any) -> Any:
    """Replace ``${VAR}`` placeholders recursively. Loud on missing vars."""
    if isinstance(value, str):
        return _ENV_PATTERN.sub(_resolve_match, value)
    if isinstance(value, dict):
        return {k: resolve_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_env_vars(v) for v in value]
    return value


def _resolve_match(m: re.Match) -> str:
    from agentflow.core.exceptions import MissingEnvVarError

    name = m.group(1)
    value = os.environ.get(name)
    if value is None:
        raise MissingEnvVarError(name)
    return value
