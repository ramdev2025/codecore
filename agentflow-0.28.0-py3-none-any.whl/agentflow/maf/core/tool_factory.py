"""Translate YAML ``tools`` entries into MAF-compatible tool values.

MAF's ``ToolTypes`` union accepts:

- :class:`FunctionTool` instances (from ``@tool``)
- Plain callables (auto-wrapped)
- ``Mapping[str, Any]`` dicts — used for **hosted** tool descriptors like
  ``{"type": "web_search"}`` on Foundry / OpenAI Responses endpoints
- Any ``object`` (opaque — provider-specific)

We map:

- :class:`BuiltinTool` enum → dict ``{"type": <name>, **config}``
- :class:`AgentToolRef`    → deferred; the builder resolves it to
  ``agents_by_name[<name>].as_tool(...)`` in pass 2 (after every agent is
  built, so peer references can resolve).
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from agentflow.maf.core.config_models import (
    AgentToolRef,
    BuiltinToolConfig,
)


def build_builtin_tool_dicts(
    tools: List[BuiltinToolConfig],
) -> List[Dict[str, Any]]:
    """Convert hosted-tool specs into the dict form MAF accepts.

    Returns a list of ``{"type": <name>, **config}`` dicts ready to pass
    in ``default_options.tools`` or ``Agent(tools=[...])``.
    """
    return [
        {"type": spec.name.value, **spec.config}
        for spec in tools
    ]


def split_tools(
    entries: List[Any],
) -> Tuple[List[BuiltinToolConfig], List[AgentToolRef]]:
    """Partition normalized tool entries into builtins + agent-as-tool refs.

    The builder processes each bucket separately:
    - builtins: built into dict form and passed immediately to the Agent
    - agent refs: deferred until every agent in the graph has been built,
      then resolved via ``agents_by_name[ref.agent].as_tool(...)``
    """
    builtins: List[BuiltinToolConfig] = []
    agent_refs: List[AgentToolRef] = []
    for entry in entries:
        if isinstance(entry, BuiltinToolConfig):
            builtins.append(entry)
        elif isinstance(entry, AgentToolRef):
            agent_refs.append(entry)
        else:  # pragma: no cover — schema enforces the union
            raise TypeError(f"Unknown tool entry type: {type(entry).__name__}")
    return builtins, agent_refs


def build_agent_as_tool(
    ref: AgentToolRef,
    agent: Any,
) -> Any:
    """Resolve an ``AgentToolRef`` to a ``FunctionTool`` via ``agent.as_tool()``.

    Called in pass 2 of the builder, after every target agent exists.
    """
    kwargs: Dict[str, Any] = {}
    if ref.tool_name:
        kwargs["name"] = ref.tool_name
    if ref.description:
        kwargs["description"] = ref.description
    if ref.approval_mode:
        kwargs["approval_mode"] = ref.approval_mode
    if ref.propagate_session:
        kwargs["propagate_session"] = True
    return agent.as_tool(**kwargs)
