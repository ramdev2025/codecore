"""Bridge AgentFlow lifecycle plugins to MAF middleware.

AgentFlow's ``Plugin`` ABC (``agentflow.workflows.plugins``) is a set of
observer hooks — ``on_tool_call``, ``on_tool_result``, ``on_error``,
``on_workflow_start/end``, ``on_agent_start/end``. MAF's native surface
uses three ``*Middleware`` classes. This module bridges the two so
existing telemetry / logging / cost plugins work unmodified on MAF agents.

Duck-typed ``plugin_manager`` — any object with ``emit_tool_call`` /
``emit_tool_result`` / ``emit_error`` / ``emit_agent_start`` /
``emit_agent_end`` methods. Keeps this module import-safe whether or not
the workflows package is installed.
"""

from __future__ import annotations

from typing import Any, Optional, Tuple


def build_plugin_bridge_middleware(
    plugin_manager: Any,
    context: Any,
) -> Tuple[Optional[Any], Optional[Any]]:
    """Return ``(agent_middleware, function_middleware)`` bridging to plugins.

    ``agent_middleware`` fires ``emit_agent_start`` / ``emit_agent_end``;
    ``function_middleware`` fires ``emit_tool_call`` / ``emit_tool_result``.
    Either can be ``None`` if no plugin manager is supplied.
    """
    if plugin_manager is None:
        return None, None

    from agent_framework import AgentMiddleware, FunctionMiddleware

    class _AgentBridge(AgentMiddleware):
        async def process(self, ctx, call_next):
            _safe_emit(
                plugin_manager,
                "emit_agent_start",
                context,
                getattr(getattr(ctx, "agent", None), "name", "?"),
            )
            try:
                await call_next()
                status = "success"
            except Exception as exc:
                _safe_emit(plugin_manager, "emit_error", context, exc, {})
                status = "failed"
                raise
            finally:
                _safe_emit(
                    plugin_manager,
                    "emit_agent_end",
                    context,
                    getattr(getattr(ctx, "agent", None), "name", "?"),
                    status,
                )

    class _FunctionBridge(FunctionMiddleware):
        async def process(self, ctx, call_next):
            fn = getattr(ctx, "function", None)
            name = getattr(fn, "name", type(fn).__name__ if fn else "?")
            args = getattr(ctx, "arguments", None)
            _safe_emit(plugin_manager, "emit_tool_call", context, name, args)
            try:
                await call_next()
            finally:
                result = getattr(ctx, "result", None)
                _safe_emit(
                    plugin_manager, "emit_tool_result", context, name, result
                )

    return _AgentBridge(), _FunctionBridge()


# ---------------------------------------------------------------------------
# Lifecycle emitter — used by the CLI around the top-level run
# ---------------------------------------------------------------------------


class WorkflowLifecycleEmitter:
    """Context manager firing ``on_workflow_start/end`` around a MAF run.

    Usage::

        with WorkflowLifecycleEmitter(plugin_manager, context, agent_name):
            await runner.query(...)
    """

    def __init__(self, plugin_manager: Any, context: Any, agent_name: str):
        self.plugin_manager = plugin_manager
        self.context = context
        self.agent_name = agent_name

    def __enter__(self):
        _safe_emit(self.plugin_manager, "emit_workflow_start", self.context)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "failed" if exc_type else "success"
        if exc_val is not None:
            _safe_emit(
                self.plugin_manager,
                "emit_error",
                self.context,
                exc_val,
                {"agent": self.agent_name},
            )
        _safe_emit(
            self.plugin_manager,
            "emit_workflow_end",
            self.context,
            None,
            status,
        )
        return False  # don't swallow exceptions


def _safe_emit(plugin_manager: Any, method: str, *args: Any) -> None:
    fn = getattr(plugin_manager, method, None)
    if fn is None:
        return
    try:
        fn(*args)
    except Exception:
        # Observers must not break the agent.
        pass
