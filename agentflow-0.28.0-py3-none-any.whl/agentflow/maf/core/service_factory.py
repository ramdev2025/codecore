"""Resolve an :class:`LLMConfig` into a concrete MAF chat client instance.

Unlike OAI (two different clients for OpenAI vs Azure OpenAI), MAF's
``OpenAIChatClient`` covers both surfaces — we just route kwargs based on
the declared provider:

- ``openai``:      ``OpenAIChatClient(model, api_key, base_url, ...)``
- ``azure_openai``: ``OpenAIChatClient(model, azure_endpoint, api_version, credential)``
- ``foundry``:     ``FoundryChatClient(project_endpoint, credential, model)``
- ``anthropic``:   ``AnthropicClient(model, api_key)``
- ``bedrock``:     ``BedrockChatClient(model, region_name, ...)``
- ``custom``:      ``None`` — caller supplies the client elsewhere

The function returns the constructed client ready to pass to
``Agent(client=...)``.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional, Tuple

from agentflow.maf.core.config_models import LLMConfig, LLMProvider


def build_chat_client(llm: LLMConfig) -> Optional[Any]:
    """Instantiate the MAF client implied by ``llm.provider``.

    Returns ``None`` for ``custom`` — the caller is expected to wire a
    pre-constructed client elsewhere.
    """
    cfg = dict(llm.config)

    if llm.provider == LLMProvider.OPENAI:
        return _build_openai(cfg)
    if llm.provider == LLMProvider.AZURE_OPENAI:
        return _build_azure_openai(cfg)
    if llm.provider == LLMProvider.FOUNDRY:
        return _build_foundry(cfg)
    if llm.provider == LLMProvider.ANTHROPIC:
        return _build_anthropic(cfg)
    if llm.provider == LLMProvider.BEDROCK:
        return _build_bedrock(cfg)
    if llm.provider == LLMProvider.CUSTOM:
        return None
    raise ValueError(f"Unknown provider: {llm.provider!r}")  # pragma: no cover


# ---------------------------------------------------------------------------
# Per-provider constructors
# ---------------------------------------------------------------------------


def _build_openai(cfg: Dict[str, Any]) -> Any:
    """OpenAI public API (or an OpenAI-compatible endpoint via ``base_url``)."""
    from agent_framework_openai import OpenAIChatClient

    kwargs: Dict[str, Any] = {}
    if "model" in cfg:
        kwargs["model"] = cfg["model"]
    if "api_key" in cfg:
        kwargs["api_key"] = cfg["api_key"]
    elif "OPENAI_API_KEY" in os.environ:
        kwargs["api_key"] = os.environ["OPENAI_API_KEY"]
    if "base_url" in cfg:
        kwargs["base_url"] = cfg["base_url"]
    if "org_id" in cfg:
        kwargs["org_id"] = cfg["org_id"]
    return OpenAIChatClient(**kwargs)


def _build_azure_openai(cfg: Dict[str, Any]) -> Any:
    """Azure OpenAI via the *same* ``OpenAIChatClient``.

    Honored keys:
    - ``azure_endpoint`` (required)
    - ``api_version`` (required)
    - ``azure_identity: true`` → use ``DefaultAzureCredential``
    - ``api_key`` → alternative to ``azure_identity``
    - ``model`` → Azure deployment name (passes straight through to the client)
    """
    from agent_framework_openai import OpenAIChatClient

    endpoint = cfg.get("azure_endpoint") or cfg.get("endpoint")
    api_version = cfg.get("api_version")
    if not endpoint:
        raise ValueError("Azure OpenAI requires 'azure_endpoint' in llm.config")
    if not api_version:
        raise ValueError("Azure OpenAI requires 'api_version' in llm.config")

    kwargs: Dict[str, Any] = {
        "azure_endpoint": endpoint,
        "api_version": api_version,
    }
    if "model" in cfg:
        kwargs["model"] = cfg["model"]

    azure_identity = cfg.get("azure_identity", False)
    api_key = cfg.get("api_key")

    if azure_identity:
        try:
            from azure.identity import DefaultAzureCredential
        except ImportError as exc:
            raise ImportError(
                "azure_identity=true requires azure-identity: "
                "pip install azure-identity"
            ) from exc
        kwargs["credential"] = DefaultAzureCredential()
    elif api_key:
        kwargs["api_key"] = api_key
    # else: MAF will fall through to AZURE_OPENAI_API_KEY env var if present

    return OpenAIChatClient(**kwargs)


def _build_foundry(cfg: Dict[str, Any]) -> Any:
    """Azure AI Foundry chat client.

    Honored keys:
    - ``project_endpoint`` (required)
    - ``model`` (the Foundry deployment / agent model)
    - ``credential`` → currently implied (``DefaultAzureCredential``)
    """
    try:
        from agent_framework_foundry import FoundryChatClient
    except ImportError as exc:
        raise ImportError(
            "Foundry provider requires agent-framework-foundry "
            "(already pulled in by agentflow[agent-framework])."
        ) from exc

    endpoint = cfg.get("project_endpoint")
    if not endpoint:
        raise ValueError("Foundry requires 'project_endpoint' in llm.config")

    kwargs: Dict[str, Any] = {"project_endpoint": endpoint}
    if "model" in cfg:
        kwargs["model"] = cfg["model"]
    # Foundry always uses Azure RBAC; build the credential here so users
    # don't have to think about it.
    try:
        from azure.identity import DefaultAzureCredential

        kwargs["credential"] = DefaultAzureCredential()
    except ImportError:  # pragma: no cover
        pass
    return FoundryChatClient(**kwargs)


def _build_anthropic(cfg: Dict[str, Any]) -> Any:
    """Anthropic direct."""
    try:
        from agent_framework_anthropic import AnthropicClient
    except ImportError as exc:
        raise ImportError(
            "Anthropic provider requires agent-framework-anthropic."
        ) from exc

    kwargs: Dict[str, Any] = {}
    if "model" in cfg:
        kwargs["model"] = cfg["model"]
    if "api_key" in cfg:
        kwargs["api_key"] = cfg["api_key"]
    elif "ANTHROPIC_API_KEY" in os.environ:
        kwargs["api_key"] = os.environ["ANTHROPIC_API_KEY"]
    return AnthropicClient(**kwargs)


def _build_bedrock(cfg: Dict[str, Any]) -> Any:
    """AWS Bedrock."""
    try:
        from agent_framework_bedrock import BedrockChatClient
    except ImportError as exc:
        raise ImportError(
            "Bedrock provider requires agent-framework-bedrock."
        ) from exc

    kwargs: Dict[str, Any] = {}
    for key in ("model", "region_name", "aws_profile", "aws_access_key_id",
                "aws_secret_access_key", "aws_session_token"):
        if key in cfg:
            kwargs[key] = cfg[key]
    return BedrockChatClient(**kwargs)


# ---------------------------------------------------------------------------
# Dry-run summary helper
# ---------------------------------------------------------------------------


def split_config(llm: LLMConfig) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Return ``(client_kwargs, extras)`` for dry-run display.

    ``api_key`` / ``credential`` are stripped (sensitive). Other keys are
    bucketed into the client kwargs (known recognised field names) vs. an
    ``extras`` passthrough for anything the user slipped in.
    """
    cfg = dict(llm.config)
    cfg.pop("api_key", None)
    cfg.pop("credential", None)

    known = {
        LLMProvider.OPENAI: {"model", "base_url", "org_id"},
        LLMProvider.AZURE_OPENAI: {
            "model", "azure_endpoint", "endpoint", "api_version", "azure_identity",
        },
        LLMProvider.FOUNDRY: {"project_endpoint", "model"},
        LLMProvider.ANTHROPIC: {"model"},
        LLMProvider.BEDROCK: {
            "model", "region_name", "aws_profile",
            "aws_access_key_id", "aws_secret_access_key", "aws_session_token",
        },
        LLMProvider.CUSTOM: set(),
    }[llm.provider]

    client_kwargs = {k: v for k, v in cfg.items() if k in known}
    extras = {k: v for k, v in cfg.items() if k not in known}
    return client_kwargs, extras
