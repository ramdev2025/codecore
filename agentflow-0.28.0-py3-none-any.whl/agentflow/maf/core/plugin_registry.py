"""Resolve :class:`PluginRef` entries into MAF ``FunctionTool`` instances.

MAF's ``@tool`` decorator produces a :class:`FunctionTool`. The registry
imports the module, collects every decorated function, and (optionally)
filters to a named subset.
"""

from __future__ import annotations

import importlib
from typing import Any, List

from agentflow.maf.core.config_models import PluginRef, PluginType


def resolve_plugins(plugins: List[PluginRef] | None) -> List[Any]:
    """Flatten all plugins into a single list of ``FunctionTool`` instances."""
    if not plugins:
        return []

    from agent_framework import FunctionTool  # lazy

    out: List[Any] = []
    for ref in plugins:
        if ref.type != PluginType.PYTHON:  # pragma: no cover — schema enforces
            raise ValueError(
                f"Plugin type {ref.type.value!r} not supported. Only 'python' in v1."
            )
        tools = _load_tools(ref.module, ref.functions, FunctionTool)
        if not tools:
            raise ValueError(
                f"Plugin {ref.name!r}: no @tool-decorated functions found in "
                f"{ref.module!r}"
                + (f" (filter: {ref.functions})" if ref.functions else "")
            )
        out.extend(tools)
    return out


def _load_tools(module_path: str, filter_names: List[str] | None, tool_cls: type) -> List[Any]:
    """Import ``module_path`` and return every ``FunctionTool`` found."""
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Plugin module {module_path!r} could not be imported: {exc}. "
            f"Is it on PYTHONPATH?"
        ) from exc

    found: list[tuple[str, Any]] = [
        (attr, obj)
        for attr, obj in vars(mod).items()
        if isinstance(obj, tool_cls)
    ]

    if filter_names:
        allowed = set(filter_names)
        found = [
            (n, t)
            for n, t in found
            if n in allowed or getattr(t, "name", None) in allowed
        ]

    return [t for _, t in found]
