"""``MafAgentBuilder`` — compose a runnable MAF agent or workflow from YAML.

MAF has two distinct execution models; the builder branches at ``build()``:

- **Agent mode** (``agent:`` in YAML) — one ``Agent(client, instructions,
  tools)``; auxiliary agents become tools via ``agent.as_tool()``.
- **Workflow mode** (``workflow:`` in YAML) — a ``WorkflowBuilder`` graph of
  ``AgentExecutor`` nodes connected by the YAML's edge list.

Both modes return a :class:`MafRunner` with ``query()`` and
``query_streamed()`` methods so the CLI doesn't care which mode is active.
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional

import yaml

from agentflow.maf.core.config_models import (
    AgentSpec,
    EdgeKind,
    EdgeSpec,
    ExecutorSpec,
    LLMConfig,
    MafYAMLConfig,
    MiddlewareKind,
    ModelSettingsConfig,
    ReasoningOptionsConfig,
    WorkflowSpec,
)
from agentflow.maf.core.helpers import load_dotenv_for, resolve_env_vars
from agentflow.maf.core.mcp import resolve_mcp_servers
from agentflow.maf.core.middleware_registry import (
    partition_by_kind,
    resolve_middleware,
)
from agentflow.maf.core.plugin_registry import resolve_plugins
from agentflow.maf.core.service_factory import build_chat_client, split_config
from agentflow.maf.core.tool_factory import (
    build_agent_as_tool,
    build_builtin_tool_dicts,
    split_tools,
)


@dataclass
class MafRunner:
    """Wraps either an ``Agent`` or a ``Workflow`` under a uniform API.

    - Agent mode: ``starting_agent`` is the built ``Agent``; ``workflow`` is None.
    - Workflow mode: ``workflow`` is the built ``Workflow``; ``starting_agent``
      is None (but ``agents_by_name`` still exposes the auxiliary agents).
    """

    mode: str                              # 'agent' or 'workflow'
    starting_agent: Optional[Any]          # agent mode only
    workflow: Optional[Any]                # workflow mode only
    agents_by_name: Dict[str, Any] = field(default_factory=dict)
    mcp_servers_by_name: Dict[str, Any] = field(default_factory=dict)
    summary: Dict[str, Any] = field(default_factory=dict)
    # Workflow-mode only: an ``asyncio.Queue`` receiving
    # ``{"kind": "call"|"result"|"error", "agent": str, "name": str, ...}``
    # from middleware taps installed on every agent in the graph. Lets the
    # CLI/UI renderer interleave tool markers with executor lifecycle
    # events the outer workflow stream normally hides. ``None`` in agent
    # mode — use the native content stream there.
    tool_event_queue: Optional[Any] = None

    async def query(self, prompt: str) -> Any:
        """One-shot run. Returns a MAF response object (AgentResponse or
        WorkflowRunResult depending on mode)."""
        if self.mode == "agent":
            return await self.starting_agent.run(prompt)
        return await self.workflow.run(prompt)

    async def query_streamed(self, prompt: str) -> AsyncIterator[Any]:
        """Streaming run — yields the stream's native update events.

        Agent mode: ``AgentResponseUpdate``.
        Workflow mode: ``WorkflowEvent``.
        """
        if self.mode == "agent":
            stream = self.starting_agent.run(prompt, stream=True)
            async for update in stream:
                yield update
        else:
            stream = self.workflow.run(prompt, stream=True)
            async for event in stream:
                yield event


class MafAgentBuilder:
    """Build a :class:`MafRunner` from a YAML config path or parsed dict."""

    def __init__(
        self,
        config: MafYAMLConfig,
        yaml_path: Optional[str] = None,
        build_state: Optional[Dict[str, Any]] = None,
    ):
        self.config = config
        self.yaml_path = yaml_path
        # Build-time state for ``available_when`` predicate evaluation.
        # Tools whose predicate is falsy against this state are excluded
        # from the agent's bound tool list. ``None`` is treated as an
        # empty dict.
        self.build_state: Dict[str, Any] = build_state or {}

    # -- Construction ------------------------------------------------------

    @classmethod
    def from_yaml(
        cls,
        path: str,
        build_state: Optional[Dict[str, Any]] = None,
    ) -> "MafAgentBuilder":
        load_dotenv_for(path)
        raw = yaml.safe_load(Path(path).read_text())
        if raw is None:
            raise ValueError(f"YAML file is empty: {path}")
        raw = resolve_env_vars(raw)
        config = MafYAMLConfig.model_validate(raw)
        return cls(config, yaml_path=path, build_state=build_state)

    @classmethod
    def from_dict(
        cls,
        data: Dict[str, Any],
        build_state: Optional[Dict[str, Any]] = None,
    ) -> "MafAgentBuilder":
        resolved = resolve_env_vars(data)
        config = MafYAMLConfig.model_validate(resolved)
        return cls(config, build_state=build_state)

    # -- Build -------------------------------------------------------------

    def build(self) -> MafRunner:
        """Dispatch to agent-mode or workflow-mode build path."""
        mcp_by_name = resolve_mcp_servers(self.config.mcp_servers)

        # Build every agent referenced in the graph (top-level + aux). In
        # agent mode the "top-level" agent is unnamed; we key it as "<main>".
        agents_by_name = self._build_all_agents(mcp_by_name)

        # Pass 2 — resolve agent-as-tool references on the main agent
        if self.config.agent is not None:
            self._attach_agent_as_tool(agents_by_name)

        if self.config.agent is not None:
            return MafRunner(
                mode="agent",
                starting_agent=agents_by_name["<main>"],
                workflow=None,
                agents_by_name=agents_by_name,
                mcp_servers_by_name=mcp_by_name,
                summary=self.dry_run(),
            )

        # Workflow mode — install per-agent tool taps so the outer stream
        # can surface tool invocations that happen inside each
        # AgentExecutor (otherwise the user sees only executor lifecycle
        # events like ``▶ triage`` / ``✓ triage`` with no sense of what
        # actually happened inside).
        import asyncio

        from agentflow.maf.core.workflow_tap import install_tool_taps

        tool_event_queue: asyncio.Queue = asyncio.Queue()
        install_tool_taps(agents_by_name, tool_event_queue)

        workflow = self._build_workflow(agents_by_name)
        return MafRunner(
            mode="workflow",
            starting_agent=None,
            workflow=workflow,
            agents_by_name=agents_by_name,
            mcp_servers_by_name=mcp_by_name,
            summary=self.dry_run(),
            tool_event_queue=tool_event_queue,
        )

    # -- Dry-run -----------------------------------------------------------

    def dry_run(self) -> Dict[str, Any]:
        llm = self.config.llm
        client_opts, extras = split_config(llm) if llm else ({}, {})

        agents_summary: Dict[str, Any] = {}
        if self.config.agent is not None:
            agents_summary["<main>"] = _summarize_agent(self.config.agent, client_opts)
        for name, spec in (self.config.agents or {}).items():
            agents_summary[name] = _summarize_agent(spec, client_opts)

        wf_summary: Optional[Dict[str, Any]] = None
        if self.config.workflow is not None:
            wf = self.config.workflow
            wf_summary = {
                "start_executor": wf.start_executor,
                "max_iterations": wf.max_iterations,
                "executors": list(wf.executors.keys()),
                "edges": [
                    {
                        "kind": e.kind.value,
                        **{
                            k: v
                            for k, v in e.model_dump(exclude_none=True).items()
                            if k != "kind"
                        },
                    }
                    for e in wf.edges
                ],
                "checkpoint": (
                    wf.checkpoint.backend if wf.checkpoint else None
                ),
            }

        return {
            "backend": "agent-framework",
            "mode": "agent" if self.config.agent is not None else "workflow",
            "metadata": self.config.metadata.model_dump(exclude_none=True),
            "llm": {
                "provider": llm.provider.value if llm else None,
                "client_options": client_opts,
                "extras": extras,
            },
            "agents": agents_summary,
            "workflow": wf_summary,
            "guards": [g.type.value for g in (self.config.guards or [])],
            "optimizers": [o.type.value for o in (self.config.optimizers or [])],
            "observers": [o.type.value for o in (self.config.observers or [])],
            "mcp_servers": list((self.config.mcp_servers or {}).keys()),
            "middleware_count": len(self.config.middleware or []),
        }

    # -- Internals ---------------------------------------------------------

    def _build_all_agents(self, mcp_by_name: Dict[str, Any]) -> Dict[str, Any]:
        """Instantiate every declared agent (top-level + auxiliary)."""
        agents_by_name: Dict[str, Any] = {}
        if self.config.agent is not None:
            agents_by_name["<main>"] = self._build_agent(
                "<main>", self.config.agent, mcp_by_name, defer_agent_tools=True
            )
        for name, spec in (self.config.agents or {}).items():
            agents_by_name[name] = self._build_agent(
                name, spec, mcp_by_name, defer_agent_tools=False
            )
        return agents_by_name

    def _build_agent(
        self,
        name: str,
        spec: AgentSpec,
        mcp_by_name: Dict[str, Any],
        *,
        defer_agent_tools: bool,
    ) -> Any:
        """Build one ``Agent`` — ``defer_agent_tools`` skips AgentToolRef entries
        (resolved in pass 2 once every peer agent exists)."""
        from agent_framework import Agent

        # Resolve the LLM client (top-level default OR per-agent override)
        llm = spec.llm or self.config.llm
        if llm is None:  # pragma: no cover — schema enforces one must be set
            raise ValueError(f"Agent {name!r} has no LLM configured.")
        client = build_chat_client(llm)

        # Tools: hosted (dict form) + plugins (@tool FunctionTools);
        # agent-as-tool refs are deferred for pass 2.
        hosted_dicts: List[Dict[str, Any]] = []
        tool_callables: List[Any] = []
        if spec.tools:
            builtins, _agent_refs = split_tools(spec.tools.normalized())
            hosted_dicts = build_builtin_tool_dicts(builtins)
        tool_callables.extend(resolve_plugins(spec.plugins))

        # Generative-UI components: each fetcher in ``spec.ui_tools.module``
        # decorated with ``@agentflow.genui.ui_component`` becomes a MAF
        # FunctionTool whose return wraps the props in
        # ``state_update(text=..., tool_result={"component": Name, **props})``.
        # The upstream AG-UI bridge surfaces ``tool_result`` to the frontend
        # for typed rendering.
        if spec.ui_tools is not None:
            from agentflow.genui import filter_by_availability
            from agentflow.maf.genui import resolve_ui_tools

            ui_tools = resolve_ui_tools(spec.ui_tools)
            # Apply build-time ``available_when`` gating. Tools whose
            # predicate evaluates falsy against ``self.build_state`` are
            # excluded permanently — the LLM never sees them.
            ui_tools = filter_by_availability(
                ui_tools, spec.available_when, self.build_state
            )
            tool_callables.extend(ui_tools)

        # MCP servers — MAF accepts them in ``tools`` as tool-like objects
        mcp_tools = [mcp_by_name[n] for n in (spec.mcp_servers or [])]

        combined_tools: List[Any] = []
        combined_tools.extend(hosted_dicts)
        combined_tools.extend(tool_callables)
        combined_tools.extend(mcp_tools)

        # Middleware — agent-level refs + top-level
        shared_mw = partition_by_kind(self.config.middleware)
        local_mw = partition_by_kind(spec.middleware)
        agent_mw = resolve_middleware(
            shared_mw[MiddlewareKind.AGENT] + local_mw[MiddlewareKind.AGENT]
        )
        # Chat + function middleware are attached on the client / options — we
        # pass them into client_kwargs at runtime; for now only agent-kind is
        # wired onto Agent directly.

        # Model settings are handed to Agent via default_options (a dict for
        # MAF — we build a minimal dict, the client's own options class is a
        # TypedDict so extra keys pass through).
        default_options = _build_default_options(spec.model_settings)

        kwargs: Dict[str, Any] = {
            "client": client,
        }
        if spec.instructions:
            kwargs["instructions"] = spec.instructions
        if spec.name:
            kwargs["name"] = spec.name
        elif name and name != "<main>":
            kwargs["name"] = name
        if spec.id:
            kwargs["id"] = spec.id
        if spec.description:
            kwargs["description"] = spec.description
        if combined_tools:
            kwargs["tools"] = combined_tools
        if agent_mw:
            kwargs["middleware"] = agent_mw
        if default_options:
            kwargs["default_options"] = default_options

        return Agent(**kwargs)

    def _attach_agent_as_tool(self, agents_by_name: Dict[str, Any]) -> None:
        """Pass 2 — resolve ``{agent: <name>}`` tool refs on the main agent."""
        main = agents_by_name["<main>"]
        spec = self.config.agent
        if spec is None or not spec.tools:
            return
        _builtins, agent_refs = split_tools(spec.tools.normalized())
        if not agent_refs:
            return

        # Build the resolved tool callables
        extra_tools = [
            build_agent_as_tool(ref, agents_by_name[ref.agent])
            for ref in agent_refs
        ]

        # Append to the agent's tools list. MAF stores regular (non-MCP)
        # tools inside ``agent.default_options["tools"]`` — the Agent doesn't
        # expose a public ``tools`` attribute. MCP tools live on
        # ``agent.mcp_tools`` and aren't relevant here.
        opts = getattr(main, "default_options", None)
        if opts is None:
            main.default_options = {"tools": list(extra_tools)}
        else:
            existing = list(opts.get("tools", []) or [])
            opts["tools"] = existing + extra_tools

    def _build_workflow(self, agents_by_name: Dict[str, Any]) -> Any:
        from agent_framework import (  # lazy
            AgentExecutor,
            Case,
            Default,
            FunctionExecutor,
            WorkflowBuilder,
        )

        wf: WorkflowSpec = self.config.workflow  # type: ignore[assignment]

        # Build an Executor for each declared node.
        executors_by_name: Dict[str, Any] = {}
        for ex_name, ex_spec in wf.executors.items():
            executors_by_name[ex_name] = _build_executor(
                ex_name, ex_spec, agents_by_name, AgentExecutor, FunctionExecutor
            )

        start = executors_by_name[wf.start_executor]
        output_execs = (
            [executors_by_name[n] for n in wf.output_executors]
            if wf.output_executors
            else None
        )

        # Checkpoint storage
        checkpoint_storage = _build_checkpoint_storage(wf.checkpoint)

        wb_kwargs: Dict[str, Any] = {
            "start_executor": start,
            "max_iterations": wf.max_iterations,
        }
        if wf.name:
            wb_kwargs["name"] = wf.name
        if wf.description:
            wb_kwargs["description"] = wf.description
        if output_execs:
            wb_kwargs["output_executors"] = output_execs
        if checkpoint_storage is not None:
            wb_kwargs["checkpoint_storage"] = checkpoint_storage

        wb = WorkflowBuilder(**wb_kwargs)

        # Attach edges
        for edge in wf.edges:
            _attach_edge(wb, edge, executors_by_name, Case, Default)

        return wb.build()


# ---------------------------------------------------------------------------
# Workflow helpers
# ---------------------------------------------------------------------------


def _build_executor(
    name: str,
    spec: ExecutorSpec,
    agents_by_name: Dict[str, Any],
    AgentExecutor: type,
    FunctionExecutor: type,
) -> Any:
    if spec.agent:
        return AgentExecutor(
            agents_by_name[spec.agent],
            id=spec.id or name,
        )
    # FunctionExecutor — resolve {module, function}
    ref = spec.function or {}
    mod = importlib.import_module(ref["module"])
    fn = getattr(mod, ref["function"])
    return FunctionExecutor(fn, id=spec.id or name)


def _attach_edge(
    wb: Any,
    edge: EdgeSpec,
    executors_by_name: Dict[str, Any],
    Case: Any,
    Default: Any,
) -> None:
    """Translate a single :class:`EdgeSpec` into ``WorkflowBuilder`` calls."""
    if edge.kind == EdgeKind.DIRECT:
        condition = _compile_condition(edge.condition) if edge.condition else None
        wb.add_edge(
            executors_by_name[edge.source],
            executors_by_name[edge.target],
            condition=condition,
        )
        return

    if edge.kind == EdgeKind.CHAIN:
        wb.add_chain([executors_by_name[n] for n in edge.executors])
        return

    if edge.kind == EdgeKind.FAN_OUT:
        wb.add_fan_out_edges(
            executors_by_name[edge.source],
            [executors_by_name[t] for t in edge.targets],
        )
        return

    if edge.kind == EdgeKind.FAN_IN:
        wb.add_fan_in_edges(
            [executors_by_name[s] for s in edge.sources],
            executors_by_name[edge.target],
        )
        return

    if edge.kind == EdgeKind.SWITCH_CASE:
        case_objs = [
            Case(
                condition=_compile_condition(c.when),
                target=executors_by_name[c.target],
            )
            for c in edge.cases
        ]
        if edge.default:
            case_objs.append(Default(target=executors_by_name[edge.default]))
        wb.add_switch_case_edge_group(executors_by_name[edge.source], case_objs)
        return


def _compile_condition(expr: str) -> Any:
    """Turn a YAML condition string into a callable ``fn(input) -> bool``.

    Supports simple attribute / dict access: ``category == 'billing'`` would
    evaluate against whatever shape the upstream executor returns. Users who
    need richer logic can supply ``condition: {module, function}`` (future
    extension).
    """

    code = compile(expr, "<edge_condition>", "eval")

    def _fn(message: Any) -> bool:
        # Expose both attribute and subscript access on the input message
        ns = {"__builtins__": {}}
        if isinstance(message, dict):
            ns.update(message)
        else:
            # Fallback — copy attributes into the namespace
            for attr in dir(message):
                if not attr.startswith("_"):
                    try:
                        ns[attr] = getattr(message, attr)
                    except Exception:
                        continue
        return bool(eval(code, ns))  # noqa: S307 — user-authored YAML

    return _fn


def _build_checkpoint_storage(cfg: Any) -> Any:
    if cfg is None:
        return None
    if cfg.backend == "memory":
        from agent_framework import InMemoryCheckpointStorage
        return InMemoryCheckpointStorage()
    if cfg.backend == "file":
        from agent_framework import FileCheckpointStorage
        # MAF's constructor takes the directory as a positional ``storage_path``
        # (not ``base_path``) — our YAML field keeps the user-friendly name.
        return FileCheckpointStorage(cfg.base_path)
    raise ValueError(f"Unknown checkpoint backend: {cfg.backend!r}")  # pragma: no cover


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _build_default_options(
    cfg: Optional[ModelSettingsConfig],
) -> Optional[Dict[str, Any]]:
    """Translate :class:`ModelSettingsConfig` into a MAF ``default_options`` dict.

    MAF's ChatOptions types are TypedDicts — we pass a plain dict and every
    non-None field is forwarded. Unknown keys are preserved via ``extra_args``.
    """
    if cfg is None:
        return None

    out: Dict[str, Any] = {}
    for field_name in (
        "temperature", "top_p", "frequency_penalty", "presence_penalty",
        "max_tokens", "seed", "stop", "tool_choice",
        "allow_multiple_tool_calls", "response_format", "metadata", "user",
        "store", "prompt_cache_retention", "prompt_cache_key",
        "service_tier", "truncation", "top_logprobs", "max_tool_calls",
    ):
        val = getattr(cfg, field_name, None)
        if val is not None:
            out[field_name] = val

    if cfg.reasoning is not None:
        out["reasoning"] = _build_reasoning(cfg.reasoning)
    if cfg.extra_args:
        # Pass through provider-specific fields verbatim
        out.update(cfg.extra_args)
    return out or None


def _build_reasoning(cfg: ReasoningOptionsConfig) -> Dict[str, Any]:
    r: Dict[str, Any] = {}
    if cfg.effort is not None:
        r["effort"] = cfg.effort
    if cfg.summary is not None:
        r["summary"] = cfg.summary
    return r


def _summarize_agent(
    spec: AgentSpec,
    client_opts: Dict[str, Any],
) -> Dict[str, Any]:
    tool_entries = spec.tools.normalized() if spec.tools else []
    return {
        "name": spec.name,
        "model": (spec.llm.config.get("model") if spec.llm else client_opts.get("model")),
        "tool_count": len(tool_entries),
        "plugin_count": len(spec.plugins or []),
        "mcp_servers": spec.mcp_servers or [],
        "has_middleware": bool(spec.middleware),
        "instructions_len": len(spec.instructions) if spec.instructions else 0,
    }
