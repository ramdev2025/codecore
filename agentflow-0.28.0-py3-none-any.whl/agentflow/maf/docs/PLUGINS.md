# Plugins — Custom Python Tools

A **plugin** in AgentFlow MAF is a Python module containing `@tool`-decorated functions. The builder imports the module, collects every decorated function, and wires them into the agent's `tools:` list.

## Author a plugin

```python
# myapp/tools.py
from agent_framework import tool

@tool
async def lookup_order(order_id: str) -> dict:
    """Look up an order by ID.

    Args:
        order_id: The order's ID (e.g. 'ORD-12345').
    """
    return {"id": order_id, "status": "shipped"}


@tool
async def issue_refund(order_id: str, reason: str) -> dict:
    """Issue a refund for the given order."""
    return {"order_id": order_id, "refunded": True}
```

MAF's `@tool` decorator introspects type hints + docstring to generate the JSON schema the LLM sees. No manual schema authoring needed.

## Reference from YAML

```yaml
agent:
  instructions: "Handle billing inquiries."
  plugins:
    - name: order-tools
      type: python
      module: myapp.tools
      functions:                       # optional — defaults to all @tool fns
        - lookup_order
        - issue_refund
```

Omit `functions:` to expose every decorated function in the module.

## Per-tool options

Options like `approval_mode`, `kind`, `max_invocations`, `max_invocation_exceptions`, and `result_parser` live on the `@tool` decorator in user code (not in YAML):

```python
@tool(
    approval_mode="always_require",
    max_invocations=3,
    max_invocation_exceptions=1,
)
async def refund(order_id: str) -> dict:
    ...
```

This keeps the Python type-checker honest about the contract.

## Approval flow

When `approval_mode="always_require"`, MAF pauses before invoking the function and surfaces an approval request on the stream. The AgentFlow CLI doesn't implement an interactive approval UI — this is for SDK users embedding MAF in their own apps. Reference MAF's upstream docs for the approval callback shape.

## Agent-as-tool — composition, not a plugin

Don't confuse `plugins:` (which maps to custom Python `@tool` functions) with `tools.builtin: [{agent: X}]` (which maps to `agent.as_tool()` — a full agent surfaced as a callable tool):

```yaml
agent:
  tools:
    builtin:
      - {agent: billing}               # agent-as-tool (no plugins entry needed)
  plugins:                             # unrelated — Python @tool modules
    - { name: payments, module: myapp.payments }
```

Both populate the same `Agent(tools=[...])` list — you can mix freely.

## Hosted vs custom tools

| Use `tools.builtin: [...]` | Use `plugins: [...]` |
|---|---|
| Foundry-hosted: web_search, file_search, code_interpreter, image_generation, hosted_mcp | Your own Python functions |
| `agent.as_tool()` composition | `@tool`-decorated modules |
| Declared as strings or `{name, config}` dicts | Declared as `{name, module, functions?}` refs |

## Error handling

If your function raises, MAF catches the exception and returns its string form as the tool result. The agent sees this as a tool error and can retry or pick a different tool. Override with a `result_parser` on the `@tool` decorator if you want custom error surfaces.

## Debugging

```bash
AGENTFLOW_LOG_LEVEL=DEBUG agentflow --yaml maf_agent.yaml "..."
```

You'll see each `@tool` call with its arguments and result (truncated to 2000 chars in the audit log).

## Cross-backend plugin modules

MAF's `@tool` decorator is framework-specific — same function signatures as OAI's `@function_tool` but a different import. For **cross-backend-portable tools**, two options:

1. **Duplicate modules per backend** — small, explicit, zero magic.
2. **Late-bound wrapper**:

```python
# myapp/tools.py
def lookup_order_impl(order_id: str) -> dict:
    """Look up an order by ID."""
    return {"id": order_id, "status": "shipped"}

# Per-backend wrappers that apply the right decorator
from agent_framework import tool as maf_tool
from agents import function_tool as oai_function_tool

lookup_order_maf = maf_tool(lookup_order_impl)
lookup_order_oai = oai_function_tool(lookup_order_impl)
```

Reference the right variant per backend YAML.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
