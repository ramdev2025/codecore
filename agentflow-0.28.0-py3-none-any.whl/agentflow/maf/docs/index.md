# AgentFlow MAF

**YAML-driven agents and workflows on the [Microsoft Agent Framework](https://learn.microsoft.com/en-us/agent-framework/overview/).**

AgentFlow MAF lets you define MAF agents and workflows — with tools, agent composition, middleware, and `gen_ai.*`-semconv OTel tracing — in YAML, without writing SDK boilerplate. Sixth backend of the AgentFlow framework, sitting alongside `workflows` (LangGraph), `deep` (DeepAgents), `sk` (Semantic Kernel), `cas` (Claude Agent SDK), and `oai` (OpenAI Agents SDK).

## Install

```bash
pip install agentflow[agent-framework]
```

This pulls in `agent-framework>=1.1.0` and nothing else — no LangChain, no LangGraph, no Semantic Kernel. Each backend is isolated so you only install what you use.

## Two modes, one backend

MAF has two execution models, both exposed under `backend: agent-framework`:

1. **Agent mode** — single `Agent(client, instructions, tools)` invocation. Multi-agent composition is via `agent.as_tool()` (any agent is exposed as a callable tool to another).
2. **Workflow mode** — explicit `WorkflowBuilder` graph with Pregel BSP superstep execution. Supports chain / direct / fan-out / fan-in / switch-case topologies.

The schema structurally discriminates on presence of `agent:` (singular) vs `workflow:`. See [Modes](MODES.md).

## Quick Start — Agent Mode

```yaml
# maf_agent.yaml
backend: agent-framework

metadata:
  version: "1.0"
  name: customer-support

llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}

agent:
  name: orchestrator
  instructions: |
    Route user questions to the right specialist.
  tools:
    builtin:
      - {agent: billing}              # agent-as-tool composition
      - {agent: technical}

agents:
  billing:
    instructions: "Handle billing, subscriptions, refunds."
    plugins:
      - {name: orders, module: myapp.billing}
  technical:
    instructions: "Handle technical support questions."
```

Run it:

```bash
agentflow --yaml maf_agent.yaml "I got charged twice for my subscription."
```

## Quick Start — Workflow Mode

```yaml
# maf_workflow.yaml
backend: agent-framework
metadata: { version: "1.0", name: pharma }
llm:
  provider: openai
  config: { model: gpt-4o, api_key: ${OPENAI_API_KEY} }

agents:
  triage: { instructions: "Classify the investigation type." }
  mfg: { instructions: "Pull historian data." }
  qa: { instructions: "Classify severity." }
  summary: { instructions: "Compile the final disposition." }

workflow:
  start_executor: triage
  executors:
    triage: { agent: triage }
    mfg: { agent: mfg }
    qa: { agent: qa }
    join: { function: { module: myapp.aggregators, function: join_outputs } }
    summary: { agent: summary }
  edges:
    - { kind: fan_out, source: triage, targets: [mfg, qa] }
    - { kind: fan_in, sources: [mfg, qa], target: join }
    - { kind: direct, source: join, target: summary }
```

## What's Supported

- **Two modes** — single agent + multi-agent composition (`agent.as_tool()`), OR explicit graph (`WorkflowBuilder`)
- **6 providers** — `openai`, `azure_openai` (RBAC), `foundry`, `anthropic`, `bedrock`, `custom`
- **Unified OpenAI/Azure client** — `OpenAIChatClient` covers both surfaces; no separate Azure class
- **Graph topologies** — `direct`, `chain`, `fan_out`, `fan_in`, `switch_case` with condition expressions
- **Native middleware** — `AgentMiddleware` / `ChatMiddleware` / `FunctionMiddleware`, each `process(ctx, call_next)`
- **Custom Python plugins** — `@tool`-decorated modules with optional `functions:` filter
- **MCP (3 transports)** — stdio / HTTP / **WebSocket** (unique to MAF among AgentFlow backends)
- **Native `gen_ai.*` OTel** — MAF auto-emits `invoke_agent` / `chat` / `execute_tool` spans + duration/usage metrics via `configure_otel_providers()`; AgentFlow adds one root span for thread-id correlation
- **Sessions** — `AgentSession` with service-managed (Foundry / OpenAI Responses) or client-managed (Chat Completions) history; persistence bridges `thread_id` ↔ `session_id`
- **Workflow checkpoints** — `FileCheckpointStorage` / `InMemoryCheckpointStorage` at superstep boundaries
- **Cross-backend portable tier** — `guards:` / `optimizers:` / `observers:` compile down to the right middleware layer

## Next Steps

- [Getting Started](GETTING_STARTED.md) — install and first agent + first workflow
- [YAML Reference](YAML_REFERENCE.md) — full schema
- [Modes](MODES.md) — agent vs. workflow discrimination
- [Workflows](WORKFLOWS.md) — graph topologies in detail
- [Middleware](MIDDLEWARE.md) — MAF's native hook mechanism
- [Full Example](FULL_EXAMPLE.md) — enterprise YAML exercising every feature
- [Migration](MIGRATION.md) — from `workflows`, `deep`, `sk`, `cas`, or `oai`

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
