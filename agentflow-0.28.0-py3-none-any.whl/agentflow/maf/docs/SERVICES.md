# Services — LLM Providers

MAF ships six providers out of the box. AgentFlow routes them via the `llm.provider` field.

| `provider:` | MAF class | Install | Auth |
|---|---|---|---|
| `openai` | `OpenAIChatClient` | `agent-framework-openai` (bundled) | API key OR OpenAI-compatible endpoint |
| `azure_openai` | `OpenAIChatClient` (same class!) | `agent-framework-openai` | API key OR Azure RBAC |
| `foundry` | `FoundryChatClient` | `agent-framework-foundry` (bundled) | Azure RBAC (`DefaultAzureCredential`) |
| `anthropic` | `AnthropicClient` | `agent-framework-anthropic` (bundled) | API key |
| `bedrock` | `BedrockChatClient` | `agent-framework-bedrock` (bundled) | AWS credentials |
| `custom` | — | — | user pre-configures |

## openai (default)

```yaml
llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}
    base_url: https://api.openai.com/v1        # optional — for proxies / Groq / Together
    org_id: "..."
```

## azure_openai

**Key design note:** MAF uses the *same* `OpenAIChatClient` for Azure — you pass `azure_endpoint` + `credential` instead of `api_key` + `base_url`. Unlike the OAI backend, there is no separate `AzureOpenAIChatClient`.

```yaml
llm:
  provider: azure_openai
  config:
    model: csdep-gpt-4o                        # Azure deployment name
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "preview"                     # MAF-native magic string
    azure_identity: true                       # DefaultAzureCredential + bearer provider
    # Alternative: api_key: ${AZURE_OPENAI_API_KEY}
```

Two auth styles:

- **API key** — set `api_key:` in config or export `AZURE_OPENAI_API_KEY`.
- **Azure RBAC** — set `azure_identity: true`. Requires `azure-identity` (installed automatically as a transitive dep). Uses `DefaultAzureCredential()` under the hood.

When both are set, `azure_identity: true` wins.

### Azure API version — Responses API required

**MAF's `OpenAIChatClient` targets the Azure Responses API**, not Chat Completions. Use one of these values for `api_version`:

| Value | Meaning |
| --- | --- |
| `"preview"` | MAF-native magic string — routes to the **latest preview** that supports Responses API. **Recommended default** — always up-to-date. |
| dated preview supporting Responses (e.g. `"2025-04-01-preview"`) | Pins a specific preview version |
| (unset) | MAF falls back to its built-in default (`"preview"`) |

**Older dated previews (`2024-12-01-preview` and earlier) don't support the Responses API** — Azure returns a 400 `"API version not supported"` error. Symptom in the CLI:

```
Error: <class 'agent_framework_openai._chat_client.OpenAIChatClient'> service failed to complete the prompt:
Error code: 400 - {'error': {'code': 'BadRequest', 'message': 'API version not supported'}}
```

Fix by bumping the version:

```bash
# in .env
OPENAI_API_VERSION=preview
```

The earlier OAI backend used Chat Completions, so `2024-12-01-preview` works there — don't copy an OAI `.env` into a MAF project without updating this field.

### OTLP metrics / logs on Jaeger

MAF's `configure_otel_providers()` exports **traces, metrics, and logs** by default. Jaeger's OTLP endpoint accepts traces only — metrics and logs both return `UNIMPLEMENTED` on every export cycle. Skip the unsupported signals when targeting Jaeger:

```bash
# in .env
OTEL_METRICS_EXPORTER=none
OTEL_LOGS_EXPORTER=none
```

AgentFlow honors `OTEL_{TRACES,METRICS,LOGS}_EXPORTER=none` in `maf/telemetry.py` by building a filtered exporter list ourselves — the underlying MAF function ignores those env vars and would otherwise re-attach the suppressed signals. The startup banner reports which signals are active (`Signals enabled: traces` when both metrics and logs are off).

For a full OTel collector (Aspire, Phoenix, or a standalone `otelcol`), leave these vars unset — all three signals flow through together.

## foundry — Azure AI Foundry

Foundry is Microsoft's managed agent platform. It hosts tools (`web_search`, `file_search`, `code_interpreter`, `image_generation`, `hosted_mcp`) and provides session persistence on the server side.

```yaml
llm:
  provider: foundry
  config:
    model: gpt-4o-prod                         # Foundry-side deployment
    project_endpoint: https://my-project.services.ai.azure.com
    # credential is always DefaultAzureCredential — automatic
```

Foundry requires Azure RBAC — no API key path.

## anthropic

```yaml
llm:
  provider: anthropic
  config:
    model: claude-opus-4-5
    api_key: ${ANTHROPIC_API_KEY}
```

Anthropic on MAF supports all the standard Claude features (system prompts, tools, extended thinking via `reasoning` on `ChatOptions`).

## bedrock

```yaml
llm:
  provider: bedrock
  config:
    model: anthropic.claude-3-5-sonnet-20241022-v2:0
    region_name: us-east-1
    aws_profile: default                       # optional — picks up ~/.aws/credentials
```

Bedrock reads AWS credentials from the standard chain (environment / profile / instance metadata).

## custom — bring your own client

```yaml
llm:
  provider: custom
  config:
    model: gpt-4o
```

```python
# before agentflow.create(...)
from agent_framework_openai import OpenAIChatClient

# Pre-configure however you need — MAF agents accept any client that
# satisfies SupportsChatGetResponse.
my_client = OpenAIChatClient(
    base_url="https://my-proxy.internal",
    api_key=load_token_from_vault(),
)
# Pass to the builder or agent afterwards — see Programmatic API docs.
```

Use cases: custom retry wrappers, internal auth gateways, dev-only proxies.

## Per-agent override

Top-level `llm:` is the default; any agent under `agents:` (or `agent:`) can override:

```yaml
llm:
  provider: openai
  config: { model: gpt-4o-mini }

agents:
  triage:
    instructions: "..."
    # inherits openai / gpt-4o-mini

  specialist:
    instructions: "..."
    llm:
      provider: azure_openai
      config:
        model: csdep-gpt-4.1
        azure_endpoint: ${AZURE_ENDPOINT}
        api_version: "2024-06-01"
        azure_identity: true
```

Validator rule 2: at least one LLM config must exist (top-level OR on every agent in the active mode). Other agents without an `llm:` block inherit the top-level default.

## Model settings per provider

`model_settings:` is surfaced across providers. Fields that aren't recognized by a given provider are forwarded via the SDK's extra-args mechanism (or raise a 400 at request time — the SDK's error, not ours).

```yaml
agent:
  model_settings:
    temperature: 0.2
    top_p: 0.9
    max_tokens: 1024

    # OpenAI / Azure OpenAI specific
    reasoning: { effort: medium }
    verbosity: low
    prompt_cache_retention: "24h"

    # Anthropic-specific — pass through extra_args
    extra_args:
      thinking: { type: enabled, budget_tokens: 8000 }

    # Bedrock-specific — pass through extra_args
    extra_args:
      guardrailConfig: { guardrailIdentifier: gr-abc, guardrailVersion: 1 }
```

See the provider's upstream docs for the full per-provider field set.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
