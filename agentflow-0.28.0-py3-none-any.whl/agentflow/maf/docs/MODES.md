# Modes

MAF has two distinct execution models. AgentFlow surfaces both under the same `backend: agent-framework` — the schema **structurally discriminates** on which top-level block you provide.

## Agent mode — `agent:` (singular)

```yaml
agent:
  name: orchestrator
  instructions: "..."
  tools:
    builtin:
      - {agent: billing}
      - {agent: technical}

agents:
  billing: { instructions: "..." }
  technical: { instructions: "..." }
```

**When to use:** routing is LLM-driven. The orchestrator decides which specialist to invoke based on the user's question. Multi-agent composition is via `agent.as_tool()` — each auxiliary agent becomes a callable tool on the orchestrator.

**Execution:** `Agent.run(messages, session=...)` — one LLM call initially, then tool-calling loops until a final answer.

**Persistence:** `AgentSession` owns conversation items; AgentFlow binds the `thread_id` to the session id.

## Workflow mode — `workflow:`

```yaml
workflow:
  start_executor: triage
  executors:
    triage: { agent: triage_agent }
    billing: { agent: billing_agent }
    tech: { agent: tech_agent }
    summary: { agent: summary_agent }
  edges:
    - kind: switch_case
      source: triage
      cases:
        - { when: "category == 'billing'", target: billing }
        - { when: "category == 'tech'", target: tech }
      default: summary
```

**When to use:** routing is deterministic (code-driven) or you need parallel fan-out, barrier synchronization, or multi-stage pipelines. The graph expresses control flow explicitly.

**Execution:** Pregel BSP supersteps — all executors in a superstep run concurrently, then synchronize before the next step. Deterministic + debuggable + checkpointable.

**Persistence:** MAF's `FileCheckpointStorage` / `InMemoryCheckpointStorage` at superstep boundaries. The thread-id binding still exists (for run accounting) but the workflow's state is checkpointed separately.

## Choosing a mode

| Characteristic | Agent mode | Workflow mode |
|---|---|---|
| Routing | LLM decides via tool-calling | Code / expressions decide via edges |
| Parallel execution | Only via `parallel_tool_calls` on a single LLM turn | Native via `fan_out` edges |
| Checkpointing | Via session (coarse) | At every superstep (fine) |
| Determinism | LLM-dependent | BSP guarantees deterministic order |
| Error handling | Retry loop | Explicit error edges + retry executors |
| Best for | Chatbots, assistants, triage | Pipelines, batch jobs, multi-stage analysis |

A workflow can still have LLM-driven branches inside an executor — agent mode and workflow mode aren't mutually exclusive strategies, just two ways to compose the same agents.

## Validator

The `MafYAMLConfig` root validator rejects both shapes together or neither:

```yaml
# VALID — agent mode
agent: { instructions: "..." }

# VALID — workflow mode
workflow:
  start_executor: x
  executors: { x: { agent: x } }

# INVALID — neither
# raises: "Must set exactly one of 'agent:' or 'workflow:'"

# INVALID — both
agent: { instructions: "..." }
workflow: { ... }
# raises: "Cannot set both 'agent:' and 'workflow:' — pick one mode."
```

## Switching modes later

Switching from agent → workflow (or back) usually means re-expressing composition:

| Agent-mode pattern | Workflow-mode equivalent |
|---|---|
| `agent.tools.builtin: [{agent: X}, {agent: Y}]` (LLM picks) | `edges: - {kind: switch_case, source: classifier, cases: [...]}` |
| Long tool-call chain | `edges: - {kind: chain, executors: [X, Y, Z]}` |
| Parallel subtasks | `edges: - {kind: fan_out, source: dispatcher, targets: [...]}` |
| Aggregation step | `edges: - {kind: fan_in, sources: [...], target: join}` (target must be a `FunctionExecutor`) |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
