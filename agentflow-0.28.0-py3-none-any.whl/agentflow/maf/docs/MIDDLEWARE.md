# Middleware

Middleware is MAF's native hook mechanism. Three interfaces, each with a single `process(context, call_next)` method — plain async-with-around semantics, simpler than SK's three filter categories or CAS's ten hook events.

## Interfaces

| Class | Wraps | Context type |
|---|---|---|
| `AgentMiddleware` | Full `Agent.run()` call | `AgentContext` |
| `ChatMiddleware` | Each LLM call | `ChatContext` |
| `FunctionMiddleware` | Each tool / function call | `FunctionInvocationContext` |

```python
from agent_framework import AgentMiddleware

class AuditLayer(AgentMiddleware):
    async def process(self, context, call_next):
        print(f"Starting agent {context.agent.name}")
        try:
            await call_next()
            print(f"Agent {context.agent.name} finished: {context.result}")
        except Exception as exc:
            print(f"Agent {context.agent.name} failed: {exc}")
            raise
```

`call_next()` runs the wrapped operation. Before/after you can inspect or modify `context`, emit spans, raise `MiddlewareTermination` to abort, etc.

## YAML — custom middleware

Attach user middleware classes via `middleware:`:

```yaml
agent:
  instructions: "..."
  middleware:
    - kind: agent                       # AgentMiddleware
      module: myapp.mw
      class_name: AuditLayer
    - kind: function                    # FunctionMiddleware
      module: myapp.mw
      class_name: ToolLatencyLogger
```

Top-level `middleware:` applies to every agent; per-agent `middleware:` is additive.

```yaml
middleware:                             # runs on every agent
  - { kind: chat, module: myapp.mw, class_name: PiiScrubber }

agents:
  billing:
    instructions: "..."
    middleware:                         # only on billing
      - { kind: function, module: myapp.mw, class_name: RefundAudit }
```

## Portable tier → middleware

The cross-backend `guards:` / `optimizers:` / `observers:` tier compiles **to** middleware on MAF. You don't write middleware manually for the common cases — declare intent:

```yaml
guards:
  - { type: pii }                       # ChatMiddleware
  - { type: tool_call_limit, config: { max_calls: 50 } }   # FunctionMiddleware counter
  - { type: model_call_limit, config: { max_calls: 100 } } # ChatMiddleware counter

optimizers:
  - { type: tool_retry, config: { max_retries: 2 } }       # FunctionMiddleware retry

observers:
  - { type: audit_log }                 # FunctionMiddleware
  - { type: cost_tracking, config: { budget_limit: 5.00 } } # AgentMiddleware (enforces budget)
  - { type: latency_tracking }          # FunctionMiddleware
```

The compiler picks the appropriate layer automatically — PII needs to inspect pre-LLM messages (chat-level), cost tracking needs the final `UsageDetails` (agent-level), tool observers work per-invocation (function-level). See [Guards / Optimizers / Observers](GUARDS.md) for the full compilation table.

## Termination

Raise `MiddlewareTermination` to stop execution cleanly:

```python
from agent_framework import ChatMiddleware, MiddlewareTermination

class PiiGuard(ChatMiddleware):
    async def process(self, context, call_next):
        if contains_pii(context.messages):
            raise MiddlewareTermination("PII detected; aborting.")
        await call_next()
```

MAF propagates `MiddlewareTermination` without retry; other exceptions are treated as errors. This is how the portable tier's counter guards (`tool_call_limit`, `model_call_limit`) actually stop a runaway loop.

## Order of execution

Middleware composes as an onion — first added = outermost:

```yaml
middleware:
  - { kind: agent, module: m, class_name: Outer }
  - { kind: agent, module: m, class_name: Middle }
  - { kind: agent, module: m, class_name: Inner }
```

Call order: `Outer → Middle → Inner → agent.run → Inner → Middle → Outer`.

## When to write middleware directly vs. use the portable tier

| Scenario | Preference |
|---|---|
| PII / rate limits / audit / cost tracking | Use `guards:` / `optimizers:` / `observers:` — cross-backend portable |
| Custom business logic (e.g. attach tenant context) | Write middleware directly via `middleware:` |
| Emit domain-specific spans | Middleware directly |
| Retry with custom backoff / policy per tool | Middleware directly (the portable `tool_retry` uses a simple exponential backoff) |
| Intercept + rewrite LLM requests | Middleware directly (`ChatMiddleware`) |

The portable tier is a ceiling, not a floor — anything it can't express, you can still do via `middleware:`.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
