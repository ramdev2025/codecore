# YAML Reference

Complete schema for the MAF backend. All fields are validated by Pydantic v2 at load time; invalid configs fail fast with actionable messages.

## Top-level shape

```yaml
backend: agent-framework               # required literal
metadata: { ... }                      # required

llm: { ... }                           # top-level default (optional when per-agent)

# Mode — exactly one required:
agent: { ... }                         # agent mode
# OR
workflow: { ... }                      # workflow mode

agents:                                # auxiliary agents
  <name>: { ... }

middleware: [ ... ]                    # shared middleware
guards: [ ... ]                        # portable tier
optimizers: [ ... ]
observers: [ ... ]
mcp_servers:
  <name>: { ... }
```

## `metadata`

```yaml
metadata:
  version: "1.0"         # required
  name: customer-support
  description: "..."
  author: "..."
  tags: [support, triage]
```

## `llm`

Top-level default; per-agent `agent.llm:` overrides.

```yaml
llm:
  provider: openai | azure_openai | foundry | anthropic | bedrock | custom
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}   # ${VAR} interpolation applied pre-validation
    # Provider-specific keys — see Services
    azure_endpoint: "..."
    api_version: "2024-06-01"
    azure_identity: true
    project_endpoint: "..."
    region_name: "us-east-1"
```

See [Services](SERVICES.md) for the full per-provider key list.

## Agent mode (`agent:`)

Singular — builds one `Agent(client, instructions, tools)` plus any auxiliary agents in `agents:`.

```yaml
agent:
  name: orchestrator
  id: orch-v1                        # stable id (surfaces as gen_ai.agent.id)
  description: "Top-level coordinator"
  instructions: "Route user requests."

  tools:
    builtin:
      # Hosted tool (Foundry / Responses API endpoints only)
      - web_search
      - {name: file_search, config: {vector_store_ids: [vs_abc]}}
      # Agent-as-tool composition
      - {agent: billing}
      - {agent: technical, tool_name: tech_help, approval_mode: always_require}

  plugins:
    - {name: orders, module: myapp.billing}

  mcp_servers: [live-data]           # references top-level mcp_servers:

  model_settings:
    temperature: 0.2
    top_p: 0.9
    max_tokens: 1024
    reasoning: {effort: medium}

  middleware:                        # per-agent middleware
    - {kind: agent, module: myapp.mw, class_name: AuditLayer}

  llm:                               # per-agent LLM override
    provider: azure_openai
    config:
      model: csdep-gpt-4.1
      azure_endpoint: ${AZURE_ENDPOINT}
      api_version: "2024-06-01"
      azure_identity: true
```

## Workflow mode (`workflow:`)

Graph — builds a `WorkflowBuilder`. See [Workflows](WORKFLOWS.md) for the topology guide.

```yaml
workflow:
  start_executor: triage             # required — must be a key in executors:
  max_iterations: 100
  name: "investigation"
  description: "..."

  executors:
    triage: { agent: triage_agent }           # AgentExecutor wrapping an agent
    join:
      function: { module: myapp.agg, function: join_outputs }   # FunctionExecutor

  edges:
    - { kind: direct, source: a, target: b, condition: "..." }
    - { kind: chain, executors: [a, b, c] }
    - { kind: fan_out, source: a, targets: [b, c, d] }
    - { kind: fan_in, sources: [b, c, d], target: join }
    - { kind: switch_case, source: a, cases: [...], default: x }

  output_executors: [summary]        # terminal nodes returning to caller

  checkpoint:
    backend: memory | file
    base_path: .agentflow/maf_checkpoints   # required when backend: file
```

### Executor spec

Each entry in `executors:` wraps either an agent OR a function:

```yaml
executors:
  triage: { agent: triage_agent, id: triage-v1 }
  join: { function: { module: myapp.agg, function: join_outputs } }
```

Exactly one of `agent:` or `function:` must be set.

### Edge kinds

| `kind` | MAF method | Required fields |
|---|---|---|
| `direct` | `add_edge(src, tgt, condition=fn)` | `source`, `target`; optional `condition:` (Python expression) |
| `chain` | `add_chain([executors...])` | `executors:` list with ≥2 entries |
| `fan_out` | `add_fan_out_edges(src, [targets])` | `source`, `targets:` list |
| `fan_in` | `add_fan_in_edges([sources], tgt)` | `sources:` list, `target` (**must be a `FunctionExecutor`** that accepts `list[AgentExecutorResponse]`) |
| `switch_case` | `add_switch_case_edge_group(src, cases)` | `source`, `cases:` list of `{when, target}`; optional `default:` |

See [Workflows](WORKFLOWS.md) for expression syntax and the fan-in sink pattern.

## `agents` (auxiliary)

Named agents that are either composed into the main `agent:` as tools (agent mode) or wrapped in `executors.<name>.agent:` (workflow mode). Same fields as `agent:` (except they don't use the top-level `tools.builtin: [{agent: ...}]` recursion).

```yaml
agents:
  billing:
    instructions: "Handle billing."
    description: "Billing specialist for refunds / subscriptions."
    plugins: [...]
    mcp_servers: [live-data]
    llm: { ... }
    model_settings: { ... }
```

## `tools.builtin` — entry types

```yaml
tools:
  builtin:
    - web_search                               # bare enum (no config)
    - {name: file_search, config: {vector_store_ids: [vs_x]}}   # detailed
    - {agent: billing}                         # agent-as-tool (short form)
    - {agent: technical, tool_name: tech, approval_mode: always_require}
```

Valid builtin names (hosted tools): `web_search`, `file_search`, `code_interpreter`, `image_generation`, `hosted_mcp`.

Hosted tools are provider-dependent — only Foundry-backed or OpenAI-Responses-API endpoints accept them. Agent-as-tool works everywhere.

## `middleware`

User-provided middleware classes. MAF has three middleware interfaces — pick the right `kind:`:

```yaml
middleware:
  - kind: agent             # AgentMiddleware — wraps full agent.run()
    module: myapp.mw
    class_name: RetryOnFailure
  - kind: chat              # ChatMiddleware — wraps each LLM call
    module: myapp.mw
    class_name: PiiScrubber
  - kind: function          # FunctionMiddleware — wraps each tool call
    module: myapp.mw
    class_name: ToolLatencyLogger
```

See [Middleware](MIDDLEWARE.md).

## `guards` / `optimizers` / `observers` (portable tier)

Enum values identical across SK / CAS / OAI / MAF — migrate mechanically:

```yaml
guards:
  - { type: pii, config: { patterns: [email, phone, ssn, credit_card] } }
  - { type: tool_call_limit, config: { max_calls: 50 } }
  - { type: model_call_limit, config: { max_calls: 100 } }
  - { type: input_validation, module: myapp.g, function: validate }
  - { type: content_filter, module: myapp.g, function: filter_output }

optimizers:
  - { type: tool_retry, config: { max_retries: 2 } }
  - { type: summarization, config: { trigger_messages: 40 } }
  - { type: prompt_caching }                    # patches ModelSettings; no mw

observers:
  - { type: audit_log }
  - { type: cost_tracking, config: { budget_limit: 5.00 } }
  - { type: latency_tracking }
```

Compilation targets per entry — see [Guards / Optimizers / Observers](GUARDS.md).

## `mcp_servers`

```yaml
mcp_servers:
  local-fs:
    transport: stdio
    command: npx
    args: [-y, "@modelcontextprotocol/server-filesystem", "/tmp"]
    env: { DEBUG: "1" }

  remote-http:
    transport: http
    url: https://mcp.example.com/v1
    headers: { Authorization: "Bearer ${MCP_TOKEN}" }
    terminate_on_close: true

  live-ws:
    transport: websocket                        # MAF-unique vs other backends
    url: wss://mcp.example.com/stream

  # Common options (any transport)
    tool_name_prefix: "mcp_"
    request_timeout: 30
    load_tools: true
    load_prompts: true
    allowed_tools: [list_dir, read_file]
    approval_mode: always_require | never_require
    description: "..."
```

See [MCP](MCP.md).

## Validator rules

Root `MafYAMLConfig` enforces:

1. **Exactly one of `agent:` or `workflow:` is set** — structural mode discrimination.
2. **At least one LLM is configured** — top-level `llm:` OR per-agent `llm:` on the active mode's agents.
3. **Agent-as-tool references resolve** — every `{agent: <name>}` in `agent.tools.builtin` must exist in `agents:`.
4. **Workflow executor agent references resolve** — every `executors.<name>.agent:` must exist in `agents:`.
5. **MCP references resolve** — every `agent.mcp_servers: [name]` must exist in top-level `mcp_servers:`.

Inside `workflow:`:

- `start_executor` must be a key in `executors:`.
- Every edge reference (source / target / sources / targets / chain executors / case targets / default) must be a known executor.
- `output_executors` must all be known.
- Every `executors.<n>` must set exactly one of `agent:` / `function:`.

Inside `edges:`:

- `direct` requires `source` + `target`.
- `chain` requires `executors:` with ≥2 entries.
- `fan_out` requires `source` + `targets:`.
- `fan_in` requires `sources:` + `target`.
- `switch_case` requires `source` + `cases:`.

Inside `mcp_servers.<name>`:

- `stdio` requires `command`.
- `http` / `websocket` require `url`.

Inside `workflow.checkpoint`:

- `backend: file` requires `base_path`.

## Environment variable interpolation

Any `${VAR}` in a string is resolved against `os.environ` (and `.env`) before validation. Missing vars raise a clear error.

```yaml
llm:
  config:
    api_key: ${OPENAI_API_KEY}
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
