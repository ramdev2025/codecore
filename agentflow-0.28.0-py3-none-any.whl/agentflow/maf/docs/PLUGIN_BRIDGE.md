# Plugin Bridge

AgentFlow ships a cross-backend `Plugin` ABC (see `agentflow.workflows.plugins`) — telemetry, logging, cost tracking, and audit plugins written once run unchanged on every backend. The MAF plugin bridge wires AgentFlow `Plugin` events to MAF middleware.

## What it bridges

| Plugin event | Source in MAF |
|---|---|
| `emit_tool_call(ctx, tool_name, args)` | `FunctionMiddleware.process` — pre-`call_next()` |
| `emit_tool_result(ctx, tool_name, result)` | `FunctionMiddleware.process` — post-`call_next()` |
| `emit_agent_start(ctx, agent_name)` | `AgentMiddleware.process` — pre-`call_next()` |
| `emit_agent_end(ctx, agent_name, status)` | `AgentMiddleware.process` — finally-block |
| `emit_error(ctx, exc, details)` | `AgentMiddleware.process` — except-block |
| `emit_workflow_start(ctx)` | `WorkflowLifecycleEmitter.__enter__` (CLI wraps run) |
| `emit_workflow_end(ctx, output, status)` | `WorkflowLifecycleEmitter.__exit__` |

Events that don't apply to MAF (`emit_hitl_*`, `emit_external_agent_*`, `emit_mcp_connect`) simply never fire.

## Duck-typed plugin manager

The bridge accepts **any object** with these methods. Missing methods are silently skipped — a plugin manager doesn't need to handle every event.

```python
# myapp/plugins/manager.py
class MyPluginManager:
    def emit_tool_call(self, ctx, tool_name, args):
        my_metrics.counter("tool_calls", {"tool": tool_name}).inc()

    def emit_agent_end(self, ctx, name, status):
        my_metrics.counter("agents_finished", {"status": status}).inc()

    # No emit_handoff? No problem — silently skipped.
```

## Wiring

```python
from agentflow.maf.core.builder import MafAgentBuilder
from agentflow.maf.core.plugin_bridge import (
    build_plugin_bridge_middleware,
    WorkflowLifecycleEmitter,
)
from myapp.plugins.manager import MyPluginManager

pm = MyPluginManager()

runner = MafAgentBuilder.from_yaml("maf_agent.yaml").build()

# Build the two middleware bridges
agent_mw, function_mw = build_plugin_bridge_middleware(pm, context={})

# Attach to the agent (agent mode) — middleware is on the Agent instance
existing_mw = list(runner.starting_agent.middleware or [])
runner.starting_agent.middleware = existing_mw + [agent_mw, function_mw]

# Wrap the run
with WorkflowLifecycleEmitter(pm, context={}, agent_name=runner.starting_agent.name):
    result = await runner.starting_agent.run("Hello")
```

For workflow mode, attach the function middleware to each `AgentExecutor` that you want bridged. (A top-level hook for workflow-wide events is on the roadmap.)

## Robustness

All `_safe_emit` calls are wrapped in `try/except`:

- Missing methods on the plugin manager → silently skipped (no-op)
- Exceptions thrown by the plugin manager → caught and swallowed

A broken plugin never crashes the agent.

## Composing with other middleware

Plugin bridge middleware composes naturally with user-written middleware and with the portable-tier-compiled middleware — MAF's middleware model is just a list:

```yaml
middleware:
  - { kind: agent, module: myapp.bridge, class_name: AgentBridge }
  - { kind: function, module: myapp.bridge, class_name: FunctionBridge }
  - { kind: chat, module: myapp.mw, class_name: PiiScrubber }

guards: [...]          # compile additional middleware
observers: [...]       # compile additional middleware
```

MAF runs them in declaration order as an onion. Earlier entries = outermost wrapper.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
