# Workflows

MAF's `WorkflowBuilder` expresses agent orchestration as a directed graph with **Pregel BSP superstep** semantics: every executor in a superstep runs concurrently, then the framework synchronizes before the next step. This gives deterministic execution, fine-grained checkpointing, and natural parallelism.

## Executors

Every node in the graph is an `Executor`. AgentFlow's YAML surfaces two flavours:

```yaml
executors:
  triage:
    agent: triage_agent                       # wraps an agent from `agents:`

  join:
    function:
      module: myapp.aggregators
      function: join_specialist_outputs       # FunctionExecutor
```

- `AgentExecutor` wraps an `Agent` — receives input, invokes the agent, emits an `AgentExecutorResponse`.
- `FunctionExecutor` wraps an `async def fn(input)` — receives the upstream value, returns whatever your function returns.

Each executor has a unique `id` (defaults to the executor's YAML key).

## Edge kinds

| `kind` | YAML | MAF method | Use |
|---|---|---|---|
| `direct` | `{kind: direct, source: a, target: b}` | `add_edge(a, b)` | 1:1 passthrough |
| `direct` with condition | `{kind: direct, source: a, target: b, condition: "category == 'x'"}` | `add_edge(a, b, condition=fn)` | Conditional passthrough |
| `chain` | `{kind: chain, executors: [a, b, c]}` | `add_chain([a, b, c])` | Sequential pipeline |
| `fan_out` | `{kind: fan_out, source: a, targets: [b, c, d]}` | `add_fan_out_edges(a, [b, c, d])` | Parallel dispatch |
| `fan_in` | `{kind: fan_in, sources: [b, c, d], target: join}` | `add_fan_in_edges([b, c, d], join)` | Barrier aggregation |
| `switch_case` | see below | `add_switch_case_edge_group(...)` | N-way branch with default |

### `switch_case` full form

```yaml
edges:
  - kind: switch_case
    source: classifier
    cases:
      - { when: "category == 'billing'", target: billing_agent }
      - { when: "category == 'technical'", target: tech_agent }
      - { when: "priority == 'urgent'", target: escalation }
    default: general_support
```

The `when:` field is a Python expression evaluated against the executor's output. Simple attribute / dict access works out of the box:

```yaml
- { when: "category == 'billing'", target: billing }
- { when: "status == 'open' and priority == 'high'", target: escalation }
```

For more complex logic, return a dict from the upstream executor and reference its keys.

## Fan-in — the sink-type gotcha

**MAF's `WorkflowBuilder.build()` runs `validate_workflow_graph`**, which checks input/output type compatibility on every edge. A `fan_in` edge delivers `list[AgentExecutorResponse]` to its sink — a plain `AgentExecutor` rejects this shape and the build fails.

**Fix:** use a `FunctionExecutor` as the fan_in sink. Define an aggregator:

```python
# myapp/aggregators.py
async def join_specialist_outputs(responses: list) -> str:
    """Joins list[AgentExecutorResponse] into a single string the
    downstream agent can consume."""
    parts = []
    for r in responses:
        agent_run = getattr(r, "agent_run_response", None)
        text = getattr(agent_run, "text", None)
        if callable(text):
            text = text()
        parts.append(str(text) if text else repr(r))
    return "\n\n---\n\n".join(parts)
```

Wire it in YAML:

```yaml
executors:
  # Specialist agents
  mfg: { agent: manufacturing }
  qa: { agent: qa_investigation }
  reg: { agent: regulatory }

  # Fan-in sink — FunctionExecutor, not AgentExecutor
  join:
    function: { module: myapp.aggregators, function: join_specialist_outputs }

  # Downstream agent that consumes the joined string
  summary: { agent: summary_agent }

edges:
  - { kind: fan_in, sources: [mfg, qa, reg], target: join }
  - { kind: direct, source: join, target: summary }
```

## Example topologies

### Triage + handoff (switch_case)

```yaml
workflow:
  start_executor: classifier
  executors:
    classifier: { agent: classifier }
    billing: { agent: billing }
    technical: { agent: technical }
    summary: { agent: summary }
  edges:
    - kind: switch_case
      source: classifier
      cases:
        - { when: "category == 'billing'", target: billing }
        - { when: "category == 'tech'", target: technical }
      default: summary
    - { kind: direct, source: billing, target: summary }
    - { kind: direct, source: technical, target: summary }
  output_executors: [summary]
```

### Parallel fan-out then aggregate (fan_in with sink)

```yaml
workflow:
  start_executor: dispatcher
  executors:
    dispatcher: { agent: dispatcher }
    search_a: { agent: search_a }
    search_b: { agent: search_b }
    search_c: { agent: search_c }
    aggregate: { function: { module: myapp.agg, function: merge_results } }
    synthesize: { agent: synthesizer }
  edges:
    - { kind: fan_out, source: dispatcher, targets: [search_a, search_b, search_c] }
    - { kind: fan_in, sources: [search_a, search_b, search_c], target: aggregate }
    - { kind: direct, source: aggregate, target: synthesize }
  output_executors: [synthesize]
```

### Sequential pipeline (chain)

```yaml
workflow:
  start_executor: ingest
  executors:
    ingest: { agent: ingest }
    clean: { agent: clean }
    enrich: { agent: enrich }
    publish: { agent: publish }
  edges:
    - { kind: chain, executors: [ingest, clean, enrich, publish] }
```

## Checkpointing

```yaml
workflow:
  checkpoint:
    backend: file                                 # OR memory
    base_path: .agentflow/maf_checkpoints
```

- `file` — `FileCheckpointStorage` at `base_path`; checkpoints at every superstep boundary. Required for long-running / resumable runs.
- `memory` — `InMemoryCheckpointStorage`; per-process, lost on exit. Good for tests.

Checkpoint schema is MAF-native — not LangGraph-compatible. If you need cross-framework checkpoint portability, implement custom `CheckpointStorage` and register via Python.

## Output routing

`output_executors:` marks which nodes' outputs are returned to the caller. Typical pattern — the final aggregator or summary agent:

```yaml
workflow:
  # ...
  output_executors: [summary]
```

Without `output_executors`, MAF returns the "last fired" executor's output — which may be unpredictable in fan_in graphs.

## Max iterations

```yaml
workflow:
  max_iterations: 100         # safety cap on supersteps
```

Once exceeded, MAF raises `WorkflowConvergenceException`. Bump the value for deep pipelines; tune down for runaway-prevention.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
