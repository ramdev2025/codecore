# Persistence

AgentFlow MAF stores a **binding table** that maps human-readable `thread_id` strings to MAF `AgentSession` identifiers. The conversation items themselves live inside MAF's `AgentSession` (service-managed for Foundry / OpenAI Responses API, client-managed for Chat Completions / Anthropic).

Workflow mode has its own checkpointing via MAF's `FileCheckpointStorage` / `InMemoryCheckpointStorage` at superstep boundaries — that's configured in the workflow YAML, separate from the thread-id binding.

## Three persistence backends (binding table)

| Backend | Class | Use when |
|---|---|---|
| `memory` | `InMemoryPersistence` | Tests, stateless workers, CI |
| `sqlite` (default) | `SQLitePersistence` | Single-instance deployments, dev laptops |
| `postgres` | `PostgresPersistence` | Production, multi-instance |

## CLI

```bash
# Default: sqlite at .agentflow/maf_threads.db
agentflow --yaml maf_agent.yaml --thread-id my-session "..."

# Memory (no persistence — each run fresh)
agentflow --persistence memory --yaml maf_agent.yaml "..."

# Custom SQLite path
agentflow --persistence sqlite --db-path /data/maf_threads.db \
    --yaml maf_agent.yaml "..."

# Postgres
agentflow --persistence postgres \
    --connection-string "postgresql://user:pass@host:5432/agentflow" \
    --yaml maf_agent.yaml "..."
```

## Environment variables

Persistence is infrastructure — pick the backend at deploy time
without editing the YAML. The CLI honors:

| Variable                     | Effect                                                                                  |
| ---------------------------- | --------------------------------------------------------------------------------------- |
| `AGENTFLOW_PERSISTENCE`      | Backend selector: `memory` / `sqlite` / `postgres` (used when `--persistence` is unset) |
| `POSTGRES_CONNECTION_STRING` | Postgres DSN (used when `--connection-string` is unset)                                 |
| `CHECKPOINTER_DB_PATH`       | SQLite path (used when `--db-path` is unset)                                            |

Resolution order: CLI flag > env var > default (sqlite). See
[`workflows/PERSISTENCE.md`](../../workflows/docs/PERSISTENCE.md)
for the canonical reference — workflows adds the `POSTGRES_POOL_*`
family, `AGENTFLOW_STORE_ENABLED`, and `AGENTFLOW_ENCRYPTION_KEY`
for tuning.

> **Connection resilience.** This backend opens a PostgreSQL connection per
> operation and closes it again, so it is not exposed to the stale-connection
> failure fixed in 0.28.0 (where a database restart or reaped idle connection
> left the app permanently failing). Connection pooling and the
> `POSTGRES_POOL_*` tuning vars apply to the `workflows` and `deep` backends
> only.

## Python API

```python
from agentflow.maf.persistence import create_persistence_manager

pm = create_persistence_manager(
    backend="sqlite",
    db_path=".agentflow/maf_threads.db",
)

# Read/write the binding
session_id = pm.get_or_create_session_id("my-thread")
pm.bump_turns("my-thread")

# Enumerate
print(pm.list_threads())

# Delete
pm.delete("my-thread")
```

## Schema

```sql
CREATE TABLE maf_threads (
    thread_id   TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL,
    first_seen  REAL NOT NULL,
    last_seen   REAL NOT NULL,
    turns       INTEGER NOT NULL DEFAULT 0
);
```

Postgres uses `DOUBLE PRECISION` for timestamps, rest identical.

## Encryption at rest

Set `AGENTFLOW_ENCRYPTION_KEY` (16 / 24 / 32 bytes) and the `session_id` column is AES-GCM encrypted:

```bash
export AGENTFLOW_ENCRYPTION_KEY="thirtytwo-byte-key-for-production!"
agentflow --yaml maf_agent.yaml --thread-id private-session "..."
```

Rows are encoded as `aes:<base64-nonce-tag-ct>`. Missing the key on read raises a clear error rather than returning ciphertext.

Protects the **session identifier** in the binding table; conversation items themselves live in MAF's session state (client-managed dict or server-side thread) and aren't encrypted by AgentFlow.

## Agent mode — typical flow

```bash
# First turn
agentflow --yaml maf_agent.yaml --thread-id customer-42 "Investigate batch 23F4."

# Second turn — MAF session reloaded automatically
agentflow --yaml maf_agent.yaml --thread-id customer-42 "What's the disposition?"
```

Step by step:

1. CLI looks up `customer-42` in the binding table → miss, allocates a new UUID.
2. CLI calls `agent.create_session(session_id=<uuid>)` — MAF builds an `AgentSession` keyed on that id.
3. `agent.run(query, session=maf_session)` — MAF reads prior items + appends new ones.
4. Next call: CLI finds `customer-42` → reuses the same UUID → same session state.

## Workflow mode — checkpoints at supersteps

Workflow mode doesn't use `AgentSession`. It uses MAF's own `CheckpointStorage`, configured in the YAML:

```yaml
workflow:
  checkpoint:
    backend: file
    base_path: .agentflow/maf_workflow_checkpoints
```

Resume a previously-checkpointed workflow by passing the checkpoint id to `workflow.run(checkpoint_id=...)` — AgentFlow's CLI doesn't surface this yet; use the Python API.

| Checkpoint backend | Class | Notes |
|---|---|---|
| `memory` | `InMemoryCheckpointStorage` | Per-process, lost on exit |
| `file` | `FileCheckpointStorage` | Directory at `base_path`; one file per checkpoint |

Unlike the binding table, the checkpoint schema is **MAF-native** — not portable across frameworks. If you need LangGraph-compatible checkpoints, use the `workflows` backend.

## Multi-instance (Postgres binding)

```bash
# Instance A
agentflow --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id customer-42 "first turn"

# Instance B — same thread, different container
agentflow --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id customer-42 "follow-up"
```

Both instances share the binding table. MAF's session backend needs to be shared too (for service-managed providers that's automatic; for Chat Completions you'd need a shared `AgentSession` implementation — roadmap).

### FastAPI lifespan pattern

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow.maf.persistence import create_persistence_manager

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pm = create_persistence_manager(
        backend="postgres",
        connection_string=os.environ["DATABASE_URL"],
    )
    yield

app = FastAPI(lifespan=lifespan)
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `ImportError: pycryptodome` | `pip install pycryptodome` (only needed when encryption is enabled) |
| `sqlite3.OperationalError: database is locked` | Multiple processes writing the same SQLite file — move to Postgres |
| `ValueError: AGENTFLOW_ENCRYPTION_KEY must be 16, 24, or 32 bytes` | Key length check |
| Session id in binding is garbage after enabling encryption | You wrote rows *before* setting `AGENTFLOW_ENCRYPTION_KEY`. Encrypted rows start with `aes:`; the loader detects plaintext and returns it |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
