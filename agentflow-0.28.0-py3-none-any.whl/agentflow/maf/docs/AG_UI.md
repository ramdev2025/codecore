# AG-UI Integration

AgentFlow's MAF backend ships a thin harness on top of Microsoft's first-party AG-UI bridge (`agent-framework-ag-ui`). The protocol layer, the HITL approval registry, the SSE framing, the event translation — all of that lives in Microsoft's package. AgentFlow's job is **configuration**: load the YAML, build the MAF agent with its tools / middleware / persistence, hand the configured agent to the upstream bridge.

This page covers the harness API, setup, a minimal end-to-end example, and the gotchas worth knowing.

---

## Why this design

AG-UI is an open event protocol for agent-to-frontend streaming — tool calls, render events, run lifecycle, human-in-the-loop interrupts — over server-sent events. The protocol is framework-agnostic, but each framework needs its own bridge to translate framework-native events into AG-UI wire events. Microsoft has built that bridge for MAF; AgentFlow uses it.

The alternative — AgentFlow re-implementing the bridge ourselves — would mean owning code Microsoft already maintains, falling behind upstream changes, and duplicating logic that already works. The harness pattern keeps AgentFlow in its lane: YAML-driven configuration. The bridge stays where the framework owner maintains it.

---

## Install

The MAF extra now pulls the AG-UI bridge and FastAPI as transitive dependencies:

```bash
pip install "agentflow[agent-framework]"
```

This installs:

- `agent-framework` (and the relevant chat-client subpackages)
- `agent-framework-ag-ui>=1.0.0rc3` — Microsoft's AG-UI bridge
- `fastapi[standard]` — required because the upstream bridge mounts on a FastAPI app

If you separately install just `pip install agent-framework` and skip the AgentFlow extras path, you'll need to add `agent-framework-ag-ui` and `fastapi[standard]` yourself.

---

## API

```python
from agentflow.maf.agui import build_agui
```

```python
def build_agui(
    app: FastAPI,
    yaml_path: str,
    *,
    path: str = "/",
    state_schema: Any | None = None,
    predict_state_config: dict[str, dict[str, str]] | None = None,
    default_state: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    dependencies: Sequence[Depends] | None = None,
) -> None
```

`build_agui` loads `yaml_path` via the existing `MafAgentBuilder`, picks the `starting_agent` (agent mode) or `workflow` (workflow mode), and calls `agent_framework_ag_ui.add_agent_framework_fastapi_endpoint(app, target, path=path, ...)`.

| Parameter | Purpose |
|---|---|
| `app` | The FastAPI app you own. The caller owns its lifecycle. |
| `yaml_path` | Path to a MAF `workflow.yaml`. |
| `path` | Endpoint path (defaults to `"/"`; use `"/agui"` when mounting alongside other routes). |
| `state_schema` | Optional schema for shared state with the frontend (dict or Pydantic model class). |
| `predict_state_config` | Optional predictive-state-update config: `{"key": {"tool": "name", "tool_argument": "arg"}}`. |
| `default_state` | Optional initial state when the client doesn't provide state keys. |
| `tags` | OpenAPI tags for the mounted endpoint. Defaults to `["AG-UI"]` upstream. |
| `dependencies` | FastAPI dependencies for auth / rate-limiting. Run before the endpoint handler. |

All keyword arguments pass straight through to the upstream helper — no AgentFlow-side mutation.

---

## Minimal end-to-end example

### `workflow.yaml`

```yaml
backend: agent-framework

metadata:
  version: "1.0"
  name: maf-agui-smoke
  description: Minimal AG-UI smoke test.

llm:
  provider: azure_openai
  config:
    model: ${AZURE_DEPLOYMENT}
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    # See "Responses API caveat" below — MAF uses Responses, not Chat Completions.
    api_version: "preview"
    azure_identity: true

agent:
  name: smoke_agent
  instructions: |
    You are a concise assistant. Answer in one sentence.
```

### `app.py`

```python
from fastapi import FastAPI
from dotenv import load_dotenv
from agentflow.maf.agui import build_agui

load_dotenv()
app = FastAPI()
build_agui(app, yaml_path="workflow.yaml", path="/agui")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
```

### Run

```bash
python app.py
```

### Verify

```bash
curl -sN -X POST http://127.0.0.1:8000/agui \
  -H "Content-Type: application/json" \
  -d '{"threadId":"t1","runId":"r1","messages":[{"role":"user","content":"Say hello in one word."}]}'
```

You should see an SSE stream:

```
data: {"type":"RUN_STARTED","threadId":"resp_...","runId":"resp_..."}
data: {"type":"TEXT_MESSAGE_START","messageId":"...","role":"assistant"}
data: {"type":"TEXT_MESSAGE_CONTENT","messageId":"...","delta":"Hello"}
data: {"type":"TEXT_MESSAGE_CONTENT","messageId":"...","delta":"!"}
data: {"type":"CUSTOM","name":"usage","value":{"input_token_count":28,"output_token_count":3,"total_token_count":31}}
data: {"type":"TEXT_MESSAGE_END","messageId":"..."}
data: {"type":"MESSAGES_SNAPSHOT","messages":[...]}
data: {"type":"RUN_FINISHED","threadId":"resp_...","runId":"resp_..."}
```

That's a complete AG-UI round-trip. Microsoft's bridge translated MAF's native `AgentResponseUpdate` events into AG-UI wire events; AgentFlow's only contribution was producing the agent from YAML.

---

## Generative UI — typed components via `ui_tools`

The minimal example above ships plain text. The interesting case is **generative UI**: the agent invokes a tool whose return value is a typed Pydantic component, and the AG-UI frontend renders a corresponding React component inline.

AgentFlow provides this through **`agentflow.genui`** — a cross-backend vocabulary that works the same way on every supporting backend. On MAF, the integration wraps each fetcher so its return value flows out as `agent_framework_ag_ui.state_update(...)` and the upstream bridge surfaces it as both a chat-side text result (for the LLM) and a typed `tool_result` payload (for the frontend).

### The pattern

A component is a Pydantic class plus a fetcher function decorated with `@ui_component(Class)`:

```python
# components.py
from pydantic import BaseModel
from agentflow.genui import ui_component


class PortfolioOverview(BaseModel):
    aum_usd: int
    day_pnl_pct: float
    top_sector: str
    position_count: int


@ui_component(PortfolioOverview)
def get_portfolio_overview() -> PortfolioOverview:
    """Top-level snapshot of the fund."""
    return PortfolioOverview(
        aum_usd=43_796_189,
        day_pnl_pct=0.69,
        top_sector="Information Technology",
        position_count=18,
    )
```

The function IS the tool the LLM calls. AgentFlow:

* exposes the function as a MAF `FunctionTool` named after the **fetcher** (`get_portfolio_overview`, *not* the component class name),
* runs the fetcher when the LLM calls it,
* validates the return value against the Pydantic schema (lenient — accepts both class instances and dicts that validate),
* wraps the props in `state_update(text=<props as JSON>, tool_result={"component": "PortfolioOverview", **props})`.

!!! info "Tool name vs component name — kept deliberately distinct"

    The **tool name** (what the LLM sees) is the fetcher's function name (a verb, e.g. `get_portfolio_overview`). The **component name** (what the frontend dispatches on) is the Pydantic class name (a noun, e.g. `PortfolioOverview`).

    This separation matters because CopilotKit v2's `useComponent({ name: "PortfolioOverview" })` advertises the component as a *frontend tool* in `RunAgentInput.tools[]`. Microsoft's bridge then calls `merge_tools(server_tools, client_tools)`. If the server tool were also named `PortfolioOverview`, the merge would raise `ValueError("Duplicate tool name")` and the run would fail with a `RUN_ERROR` event.

    Separating the namespaces avoids the conflict and is also semantically right — the LLM-facing tool is an *action* (fetch this data), the frontend-facing identifier is a *component* (render this widget). The `tool_result.component` field carries the component name so the frontend's `useComponent` registry still dispatches the render correctly.

    This was caught live during the first CopilotKit v2 + MAF round-trip. See ``tests/test_maf_genui.py::test_tool_name_is_fetcher_name_not_component_name`` for a regression test.

### YAML

Reference the module under `agent.ui_tools`:

```yaml
agent:
  name: apex_copilot
  instructions: |
    You are an analyst assistant. Pick the right tool and write a
    short analyst commentary alongside whatever component renders.
  ui_tools:
    module: components             # importable Python module
    use:                           # optional allow-list
      - PortfolioOverview
      - PositionTable
      - AlertFeed
```

`use:` is an allow-list — names that don't exist in the module raise a clear error at builder time, naming both the missing entries and what's available. Omit `use:` to expose every `@ui_component` fetcher in the module.

### Wire shape

Each tool call produces a `TOOL_CALL_RESULT` event whose `content` is a JSON-stringified object carrying the component marker:

```
data: {
  "type": "TOOL_CALL_RESULT",
  "messageId": "...",
  "toolCallId": "call_...",
  "content": "{\"component\": \"PortfolioOverview\", \"aum_usd\": 43796189, \"day_pnl_pct\": 0.69, \"top_sector\": \"Information Technology\", \"position_count\": 18}",
  "role": "tool"
}
```

The frontend dispatches on `content.component` and renders the matching React component with the remaining keys as props. CopilotKit's `useComponent` hook (and any AG-UI client following the same convention) keys off this exact shape.

### Sync and async

The wrapper handles both. `inspect.iscoroutinefunction` decides which wrapper to build; async fetchers are awaited transparently:

```python
@ui_component(WeatherCard)
async def get_weather(city: str) -> WeatherCard:
    data = await _fetch_weather(city)
    return WeatherCard(city=city, **data)
```

### Error handling

A fetcher that returns the wrong type, or a dict that doesn't validate, surfaces as an error string the LLM consumes — not a crash:

```
[PortfolioOverview failed] dict didn't validate: 1 validation error for PortfolioOverview
[PortfolioOverview failed] got int
```

The agent re-plans or apologises based on the error. This matches the workflows backend's `ToolError` policy, so apps switching backends see the same agent-side behavior.

### What gets emitted on the wire

For one call to a `@ui_component`-decorated fetcher, the upstream bridge produces:

1. `TOOL_CALL_START` — `toolCallName` is the fetcher function name (e.g. `get_portfolio_overview`)
2. `TOOL_CALL_ARGS` — the LLM's args, deltas
3. `TOOL_CALL_END`
4. `TOOL_CALL_RESULT` — `content` is `{"component": Name, **props}` JSON-stringified
5. Subsequent `TEXT_MESSAGE_*` — the LLM's commentary alongside the rendered component

Nothing AgentFlow-specific in those events. Any AG-UI client can consume them.

---

## Frontend-defined tools

In some AG-UI integrations (notably the workflows backend on `dev`), client-side tools are declared in YAML as `client_tools:`. On MAF, **AgentFlow doesn't declare client-side tools at all** — Microsoft's bridge accepts them per-request from the frontend, advertised via `RunAgentInput.tools`.

The split:

| What | Where |
|---|---|
| Browser-side tool implementation | React app, via `@copilotkit/react-core`'s `useFrontendTool` |
| Per-request tool advertisement to the LLM | `RunAgentInput.tools` (CopilotKit sends automatically) |
| Server-side tool registration on the agent | `agent_framework_ag_ui` — sees the per-request `tools`, calls `convert_agui_tools_to_agent_framework` + `register_additional_client_tools` + `merge_tools` |
| Pause / resume across HTTP boundary | Upstream's `_pending_approvals` registry |

Nothing in AgentFlow's MAF integration. The frontend declares; the upstream bridge wires it in.

### Example (frontend, CopilotKit v2)

```tsx
import { useFrontendTool } from "@copilotkit/react-core/v2";
import { z } from "zod";

useFrontendTool({
  name: "openSecFiling",
  description: "Open the SEC EDGAR filings page for a ticker in a new tab.",
  parameters: z.object({ ticker: z.string() }),
  handler: async ({ ticker }) => {
    const url = `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${ticker}`;
    window.open(url, "_blank", "noopener");
    return `Opened SEC EDGAR for ${ticker}.`;
  },
});
```

When the LLM proposes calling `openSecFiling`, the upstream bridge pauses, the React app runs the `handler`, and the result is delivered back via the same `POST /<path>` channel on the next request.

### Why no YAML schema for this on MAF

The upstream bridge already owns the entire round-trip — declaration, advertisement, pause, resume. Adding a YAML schema in AgentFlow would mean either:

1. **Duplicating the frontend declaration** (extra place to keep in sync, no functional benefit), or
2. **Replacing the frontend declaration** (defeats the upstream design — and CopilotKit users would still write the handler in `useFrontendTool` anyway).

Per the harness-configurator framing, AgentFlow doesn't add YAML config when the framework's own ecosystem already handles it. MAF + CopilotKit handle this end-to-end; AgentFlow's role ends at handing the configured agent to the bridge.

### Workflows version is different

The workflows backend on `dev` declares `client_tools:` in YAML and emits stubs that pause via `langgraph.types.interrupt(...)`. That's the only path because the workflows bridge doesn't (yet) parse per-request `tools` from the frontend. When the workflows backend migrates to the harness pattern (after SK), it will probably also adopt the per-request model and the YAML block becomes deprecated. Until then, two backends, two stories — documented.

---

## Responses API caveat

!!! warning "MAF uses the Azure OpenAI Responses API, not Chat Completions"

    `agent_framework_openai.OpenAIChatClient` — the chat client AgentFlow's MAF backend uses for `provider: azure_openai` — calls the **Responses API** endpoint exclusively. This has two implications:

    1. **`api_version` must be Responses-compatible.** Common values that work in other AgentFlow backends — `2024-12-01-preview`, `2024-10-21`, `2024-08-01-preview` — all return `Error code: 400 — "API version not supported"` from this client. Use `api_version: "preview"` (MAF's own default literal) or a recent Responses-supporting preview like `2025-04-01-preview`.

    2. **The Azure deployment must have Responses enabled.** Most modern `gpt-4o` / `gpt-4o-mini` / `gpt-5` deployments do; older deployments may not. If you get persistent "API version not supported" errors with `api_version: "preview"`, the deployment itself is likely not Responses-API-compatible.

    Cross-backend YAMLs (one YAML reused across workflows, MAF, SK) typically can't share a single `api_version`. The workaround is to override per backend or use environment-variable indirection like `api_version: ${AZURE_API_VERSION_MAF}` with backend-specific values in `.env`.

---

## Predicate-gated tools (`available_when`)

Some tools shouldn't be available to every user. The cross-backend YAML vocabulary supports per-tool predicates that filter out gated tools so the LLM literally never sees them.

### YAML

```yaml
agent:
  ui_tools:
    module: components
    use:
      - PortfolioOverview
      - ComplianceDashboard       # manager-only
  available_when:
    ComplianceDashboard: "state.user_role == 'manager'"
```

Keys are **component class names** (matching what you list under `use:`). Values are [`simpleeval`](https://pypi.org/project/simpleeval/) expressions evaluated against the deployment's *build state*. Predicates that aren't matched against any tool, and tools without a predicate, are both silently no-ops.

### Build state

The state is passed once to `build_agui` at agent-construction time:

```python
build_agui(
    app,
    yaml_path="workflow.yaml",
    build_state={"user_role": os.environ.get("USER_ROLE", "analyst")},
)
```

If `build_state` is `None` (default), all predicates that reference `state.X` resolve to `False` — every gated tool is hidden. This is the **fail-safe default**: a deployment that doesn't explicitly set state can't accidentally expose privileged tools.

### Build-time only — no per-call dynamic gating yet

The filter runs **once at agent construction**. Tools whose predicate is falsy against the supplied build state are excluded from the agent's bound tool list permanently — the LLM never sees them.

Dynamic per-call gating (the predicate is re-evaluated on every model call against the live `useCoAgentState` value) is **not implemented** on MAF in this release. Microsoft's bridge filters `current_state` out of `chat_options.metadata` before the chat layer, and `AgentMiddleware` can only set run-level tool overrides — neither composes cleanly into "filter the agent's bound tools by live state."

For "the gating decision shouldn't change across a session," build-time evaluation is the right tool — deployments are bound to one user role at a time, you swap deployments per role. For "the gating decision changes mid-session as state evolves," you'll currently want the workflows backend (when it migrates to this harness pattern, since LangChain's `wrap_model_call` middleware composes cleanly).

### Fail-closed semantics

- Predicate that raises (typo, missing field, syntax error) → tool is excluded, **WARNING** logged with the rule text.
- `build_state=None` → predicates resolve falsy → all gated tools hidden.
- A predicate naming a component not in `use:` → silently ignored (no error — supports stale config drift).

### Operator visibility

Each filtered tool produces one INFO log line at construction:

```
INFO  agentflow.maf.availability  available_when excluded 'ComplianceDashboard' at build time (predicate="state.user_role == 'manager'")
```

So an operator can see at boot exactly which tools the LLM will and won't have access to without re-reading the YAML.

### Expression syntax

Use Python comparison and boolean operators. Tuple/list literals are NOT supported by the default `simpleeval` sandbox — use `or`-chains for membership checks. See [`agentflow.genui.predicates`](https://example.com) for the full notes.

```yaml
available_when:
  PortfolioActions:    "state.user_role == 'manager' or state.user_role == 'trader'"
  ComplianceDashboard: "state.user_role == 'manager' and state.compliance_module_enabled"
  AdvancedAnalytics:   "state.tier == 'pro' or state.tier == 'enterprise'"
```

---

## CopilotKit v2 wire-shape patch (default-on)

By default, `build_agui(...)` monkey-patches `ag_ui.encoder.EventEncoder.encode` to align Microsoft's bridge wire shape with CopilotKit v2's chat rendering. Without it, **tool-using turns render the typed components but drop the agent's follow-up commentary** — a real interop gap caught during the first live test.

Two specific behaviors get patched:

1. **Empty `TEXT_MESSAGE` pairs at the start of tool-using turns.** The upstream emits `TEXT_MESSAGE_START` unconditionally at every LLM call. A turn whose only output was tool calls produces an empty pair (no content); the follow-up commentary opens a second pair. CopilotKit renders only the first pair as the assistant bubble and silently drops the second. The patch defers `TEXT_MESSAGE_START` until the first content event — empty lifecycles never go on the wire. Matches the workflows backend's own AG-UI adapter behavior.

2. **`MESSAGES_SNAPSHOT` id mismatch.** The bridge emits a final snapshot whose `messageId`s don't align with the IDs streamed in `TEXT_MESSAGE_*` events. CopilotKit reconciles to the snapshot and orphans the streamed text. The patch suppresses `MESSAGES_SNAPSHOT` entirely — CopilotKit's streaming-accumulated view is correct on its own.

Net wire-level difference for a `"Show me top positions"` turn:

| | Before patch | After patch |
|---|---|---|
| `TEXT_MESSAGE_START` count | 2 | 1 |
| `TEXT_MESSAGE_END` count | 2 | 1 |
| `MESSAGES_SNAPSHOT` count | 1 | 0 |
| Tool call lifecycle | unchanged | unchanged |
| Content delta count | unchanged | unchanged |

To opt out (e.g. wiring a non-CopilotKit AG-UI client that already handles the upstream shape correctly), pass `apply_event_shape_fix=False` to `build_agui`. The patch is idempotent; applied once per process at the first `build_agui` call.

This is a temporary shim. Will be removed when either Microsoft's bridge defers `TEXT_MESSAGE_START` itself or CopilotKit renders multi-message assistant turns.

---

## What gets mounted

```
POST /<path>    AG-UI HTTP+SSE endpoint
```

That's it. Unlike some AG-UI integrations that expose `/info`, `/health`, `/components`, the Microsoft bridge intentionally only mounts the protocol endpoint. If you need:

- **Health probes** — add a plain `@app.get("/health")` route on your FastAPI app.
- **CopilotKit auto-discovery** (`/info`) — add a stub route that returns the minimum shape CopilotKit Core expects.
- **Component schema export** (`/components`) — when AgentFlow's typed `ui_tools` support lands on this backend, this will become an AgentFlow concern; until then, return any schemas you publish manually.

The harness deliberately doesn't add these on your behalf, so the mount stays a one-liner and you keep control of your route table.

---

## Bonus events MAF emits

Microsoft's bridge emits a few AG-UI event types you don't get from a bare-bones bridge:

| Event | What it carries |
|---|---|
| `CUSTOM` (`name: "usage"`) | Per-turn token usage: input, output, total. Useful for cost dashboards without setting up OTel. |
| `MESSAGES_SNAPSHOT` | The full message history (user + assistant) after each completed turn. Lets the frontend re-hydrate state without parsing the incremental TEXT_MESSAGE_* stream. |
| `STATE_SNAPSHOT` | When `state_schema` is supplied, the bridge emits shared-state snapshots the frontend's `useCoAgentState` hook can consume. |

These are free — AgentFlow doesn't do anything to make them appear; the upstream produces them natively.

---

## What this module deliberately doesn't do

- **No event translation.** All AG-UI event shaping happens in `agent_framework_ag_ui`.
- **No HITL state ownership.** Microsoft maintains an in-process `_pending_approvals` registry (bounded at 10,000 entries by default) keyed by interrupt ID. Approval responses come back through the same `POST /<path>` channel as new messages; the upstream bridge matches them.
- **No SSE framing.** Done upstream.
- **No FastAPI lifespan management.** You own the app and its lifecycle. The MAF agent has no external resources that require teardown for the SQLite checkpoint storage; for HTTP-based persistence backends you'd handle teardown yourself.

This is intentional: the smaller the wrapper, the less drift between AgentFlow and Microsoft's bridge as the upstream evolves.

---

## Reference

- **Upstream package**: `agent-framework-ag-ui` on PyPI (and on the Microsoft GitHub `microsoft/agent-framework` repo). Currently `1.0.0rc3`; the stable `1.0.0` is expected once Microsoft cuts it.
- **AG-UI protocol spec**: https://docs.copilotkit.ai/ag-ui-protocol
- **CopilotKit (the typical frontend)**: https://docs.copilotkit.ai/
- **AgentFlow MAF builder** (the YAML → agent layer this harness depends on): see `MafAgentBuilder` in `agentflow.maf.core.builder`.

---

## Roadmap

- **Cross-backend `client_tools`** — frontend-implemented tools where the agent's tool call pauses for the browser to execute and resume. Microsoft's bridge has the upstream primitive (`_pending_approvals` registry + `available_interrupts`); AgentFlow needs to add a `ClientToolConfig` to `agentflow.genui` and a MAF resolver that wires it up.
- **Cross-backend `available_when`** — predicate-based tool gating evaluated per turn against the agent state. MAF's `ChatMiddleware` is the natural insertion point; the existing `agentflow/maf/filters/compiler.py` guards system already half-implements this pattern.
- **Live test with a real CopilotKit frontend** pointing at this endpoint, validating the typed-component render end-to-end (not just the wire shape over curl).
- **Workflows-side migration** — once SK and MAF are both in, design the workflows AG-UI integration on the same harness pattern, informed by both reference implementations.

See `AG_UI_ROADMAP.md` (if/when committed) for the cross-backend rollout plan.
