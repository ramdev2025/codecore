# Migration Guide

If you already have a YAML for another AgentFlow backend, here's how to port it to MAF.

## From `oai` (OpenAI Agents SDK)

MAF and OAI overlap heavily — both are flat multi-agent frameworks with middleware-style hooks and MCP tool support. The structural differences:

| OAI | MAF |
|---|---|
| `backend: openai-agents` | `backend: agent-framework` |
| `agents:` (flat dict) + `starting_agent:` (name pointer) | `agent:` (singular) + `agents:` (auxiliary dict) OR `workflow:` |
| Native `handoffs:` on every agent | `agent-as-tool` composition (`{agent: X}` in tools) OR workflow edges |
| `input_guardrails:` / `output_guardrails:` on agents | `middleware:` (ChatMiddleware) OR portable `guards:` |
| `tools.builtin: [{agent: X}]` — not supported | `tools.builtin: [{agent: X}]` — native primitive |
| `OpenAIChatClient` vs `AsyncAzureOpenAI` (two classes) | `OpenAIChatClient` covers both |

### Porting template

Before (OAI):

```yaml
backend: openai-agents
metadata: { version: "1.0" }
llm:
  provider: openai
  config: { model: gpt-4o-mini, api_key: ${OPENAI_API_KEY} }

agents:
  triage:
    instructions: "Route."
    handoffs: [billing]
  billing:
    instructions: "Handle billing."

starting_agent: triage
```

After (MAF):

```yaml
backend: agent-framework
metadata: { version: "1.0" }
llm:
  provider: openai
  config: { model: gpt-4o-mini, api_key: ${OPENAI_API_KEY} }

agent:                                # singular — the starting agent
  instructions: "Route."
  tools:
    builtin:
      - {agent: billing}              # agent-as-tool (replaces handoff)

agents:
  billing:
    instructions: "Handle billing."
```

**Key reshape:** OAI's `starting_agent: triage` becomes MAF's top-level `agent:` entry; handoff targets become agent-as-tool entries under `agent.tools.builtin`.

## From `cas` (Claude Agent SDK)

| CAS | MAF |
|---|---|
| `backend: claude-agent-sdk` | `backend: agent-framework` |
| `agent:` (single) + `subagents:` (dict) | `agent:` (single) + `agents:` (auxiliary dict) |
| Subagent delegation via built-in `Task` tool | Agent-as-tool in `tools.builtin` |
| `llm.provider: anthropic` | `llm.provider: anthropic` (same name) |
| Preset `claude_code` (11 tools) | No preset; list `builtin:` explicitly |
| Hooks (10 events) | Middleware (3 kinds, 1 method) |
| `permission_mode:` + allow/deny | No permission system; use `@tool(approval_mode=...)` per function |

### Porting template

Before (CAS):

```yaml
backend: claude-agent-sdk
metadata: { version: "1.0" }
llm:
  provider: anthropic
  config: { model: claude-opus-4-5, api_key: ${ANTHROPIC_API_KEY} }

agent:
  name: orchestrator
  system_prompt: "Delegate research and review."
  tools:
    builtin: [task, web_search, read, grep]

subagents:
  researcher:
    description: "Research the codebase."
    system_prompt: "You research thoroughly."
    tools: [read, grep, web_search]
  reviewer:
    description: "Review code."
    system_prompt: "You review critically."
```

After (MAF):

```yaml
backend: agent-framework
metadata: { version: "1.0" }
llm:
  provider: anthropic
  config: { model: claude-opus-4-5, api_key: ${ANTHROPIC_API_KEY} }

agent:
  name: orchestrator
  instructions: "Delegate research and review."
  tools:
    builtin:
      - {agent: researcher}
      - {agent: reviewer}
    # web_search / read / grep are not MAF hosted tools on Anthropic —
    # implement them as @tool plugins if you need the same behaviour.

agents:
  researcher:
    instructions: "You research thoroughly."
    description: "Research the codebase."
    plugins:
      - {name: dev-tools, module: myapp.tools}  # port the CAS preset here
  reviewer:
    instructions: "You review critically."
    description: "Review code."
    plugins:
      - {name: review-tools, module: myapp.review}
```

## From `sk` (Semantic Kernel)

| SK | MAF |
|---|---|
| `backend: semantic-kernel` | `backend: agent-framework` |
| `services:` + per-agent `service:` ref | `llm:` + per-agent `llm:` |
| `mode: autonomous/handoff/sequential/concurrent/groupchat/magentic` | `agent:` (LLM-driven) OR `workflow:` (graph) |
| `orchestration:` block | `workflow:` graph with edges |
| Filters (`guards:` / `optimizers:` / `observers:`) | Same YAML keys — identical vocabulary |
| Python `@kernel_function` | `@tool` from `agent_framework` |

MAF's workflow mode + agent mode roughly covers SK's orchestration modes:

| SK orchestration | MAF equivalent |
|---|---|
| Sequential | `workflow: edges: - kind: chain` |
| Concurrent | `workflow: edges: - kind: fan_out` then fan_in with aggregator |
| Handoff | `agent:` + `tools.builtin: [{agent: X}]` (LLM-driven) |
| GroupChat | agent-as-tool with every participant exposed on the orchestrator |
| Magentic | Complex — model it as a workflow with switch_case + chain |

## From `deep` (DeepAgents)

Deep's single-agent + built-in filesystem/plan tools maps to MAF agent mode:

- Deep's `agent:` → MAF's `agent:` (same shape conceptually)
- Deep's subagents → MAF's `agents:` + agent-as-tool in `agent.tools.builtin`
- No drop-in replacement for Deep's filesystem preset — implement via `@tool` plugins

## From `workflows` (LangGraph)

Workflows is graph-based, and MAF's workflow mode is also graph-based — this migration is **structural-equivalent**:

| Workflows (LangGraph) | MAF |
|---|---|
| `workflows.<name>.nodes` | `workflow.executors` |
| `workflows.<name>.edges` | `workflow.edges` (with `kind:` discriminator) |
| Conditional edges | `direct` edge with `condition:` expression OR `switch_case` edge |
| `StateGraph` merge nodes | `fan_in` edge with `FunctionExecutor` sink |
| LangGraph checkpointer (sqlite/postgres) | MAF `FileCheckpointStorage` (file-based only) |

The key constraint: MAF workflow checkpoints are MAF-native format, not LangGraph-compatible. If checkpoint portability matters, stay on `workflows`.

## Flags that stay the same

Every cross-backend flag means the same on MAF:

- `--yaml`, `--backend`, `--query`, `--interactive`, `--dry-run`, `--json`
- `--thread-id`, `--persistence`, `--db-path`, `--connection-string`
- `AGENTFLOW_ENCRYPTION_KEY`, `OTEL_TRACES_ENABLED`, etc.

## The portable tier migrates mechanically

```yaml
guards:
  - type: pii
    config: { patterns: [email, phone] }
  - type: tool_call_limit
    config: { max_calls: 50 }

optimizers:
  - type: prompt_caching
    config: { retention: "24h" }

observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 5.00 }
  - type: latency_tracking
```

These blocks are identical on SK / CAS / OAI / MAF. Copy-paste and forget.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
