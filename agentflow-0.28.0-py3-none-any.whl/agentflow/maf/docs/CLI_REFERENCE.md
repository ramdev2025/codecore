# CLI Reference

The MAF backend is invoked through the unified `agentflow` command. When the YAML's `backend:` field is `agent-framework`, the router dispatches here.

> **Cross-backend flags** — `--output ndjson`, `--debug`, `--verbose`, `--ascii`, REPL slash commands, the `agentflow-init` and `agentflow-threads` companion commands, and the JSON event schema are documented in `agentflow/cli/CLI_FLAGS.md` (in the source tree). This page covers MAF-specific behaviour only.

## Synopsis

```
agentflow [QUERY] [OPTIONS]
```

## Options

| Flag | Type | Default | Purpose |
|---|---|---|---|
| `QUERY` | positional | prompts if absent | Task for the agent |
| `--yaml PATH` | string | auto-detected | Path to the YAML config |
| `--backend TEXT` | string | YAML's `backend:` field | Override dispatch |
| `--interactive` | flag | off | REPL loop; `quit` / `q` / `exit` to end |
| `--dry-run` | flag | off | Validate config and print summary without calling the API |
| `--json` | flag | off | Output dry-run summary as JSON |
| `--thread-id TEXT` | string | random UUID | Conversation-continuity handle (agent mode) |
| `--persistence` | `memory \| sqlite \| postgres` | `sqlite` | Persistence backend for the thread-id binding |
| `--db-path PATH` | string | `.agentflow/maf_threads.db` | SQLite path for the thread→session binding |
| `--connection-string TEXT` | string | — | Postgres DSN (required when `--persistence postgres`) |

Cross-backend flags that don't apply to MAF (`--tools`, `--workdir`, `--no-tui`, `--recursion-limit`) are silently accepted and ignored.

## Auto-detection

When `--yaml` is omitted, the CLI searches the current directory in order:

```
workflow.yaml
agentflow.yaml
agent.yaml
deep.yaml
deep_agent.yaml
sk_agent.yaml
cas_agent.yaml
oai_agent.yaml
maf_agent.yaml
```

If none match, the CLI prints an error and exits.

## Environment Variables

| Variable | Purpose |
|---|---|
| `OPENAI_API_KEY` | Default for `provider: openai` |
| `AZURE_OPENAI_ENDPOINT` / `AZURE_OPENAI_API_KEY` | Azure credentials (alternative to YAML fields) |
| `ANTHROPIC_API_KEY` | Default for `provider: anthropic` |
| `AGENTFLOW_ENCRYPTION_KEY` | AES-GCM key (16/24/32 bytes) for the thread-id binding at rest |
| `AGENTFLOW_LOG_LEVEL` | `DEBUG / INFO / WARNING / ERROR` (default: `WARNING`) |
| `OTEL_TRACES_ENABLED` | `true` to enable OpenTelemetry (default: off) |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | OTLP collector endpoint (default: `http://localhost:4317`) |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | `grpc \| http/protobuf` (default: `grpc`) |
| `OTEL_SERVICE_NAME` | Trace service name (default: `agentflow`) |
| `ENABLE_INSTRUMENTATION` | MAF-level flag forced to `true` by `setup_tracing()` |
| `CHECKPOINTER_DB_PATH` | SQLite path override (same semantics as `--db-path`) |
| `POSTGRES_CONNECTION_STRING` | Postgres DSN override |

A `.env` file in the current working directory is loaded automatically at startup.

## Modes

### Dry-run

```bash
agentflow --yaml maf_agent.yaml --dry-run
agentflow --yaml maf_agent.yaml --dry-run --json
```

Validates the YAML, loads `.env`, resolves `${VAR}`, prints a rich table or JSON summary.

### One-shot

```bash
agentflow "What's the weather in Paris?"
agentflow --yaml maf_agent.yaml "Investigate batch 23F4."
agentflow --yaml maf_workflow.yaml "Run the triage workflow for this ticket."
```

### Interactive (REPL)

```bash
agentflow --yaml maf_agent.yaml --interactive
```

## Streaming output

During a live run (one-shot or REPL turn) the CLI streams progress markers as MAF's `AgentResponseUpdate.contents` arrives. Agent mode:

| Marker | Meaning | Content type |
| --- | --- | --- |
| `· thinking…` | Model is in a reasoning block (shown once per streak) | `text_reasoning` |
| `▸ tool_name(args)` | Tool invocation (arguments accumulated across streamed deltas and emitted when the JSON parses) | `function_call`, `mcp_server_tool_call`, `search_tool_call`, `shell_tool_call`, `code_interpreter_tool_call`, `image_generation_tool_call` |
| `  ← tool result · N chars` | Tool returned normally | matching `*_result` type |
| `  ← tool error · <msg>` | Tool raised an exception (red) | matching `*_result` type with `.exception` |
| `→ agent: <name>` | Conversation switched to another agent (multi-agent runs) | `update.author_name` change |
| streamed text | Final assistant output — printed as it arrives | `text` |
| `✗ [code] message` | Error content surfaced in the stream (red) | `error` |

Workflow mode uses a different set of markers reflecting the Pregel BSP execution: `┌── superstep N`, `▶ executor_id`, `✓ executor_id`, `✗ executor_id: reason`, `⚠ warning`, `└── superstep complete`, plus inline text for workflow-level outputs.

The stream driver wraps each run in an `agentflow.maf.run` span so MAF's native `gen_ai.*` spans nest under one trace.

## Persistence

Agent mode (session-bridged):

```bash
agentflow --yaml maf_agent.yaml --thread-id my-session "first message"
agentflow --yaml maf_agent.yaml --thread-id my-session "follow-up"
```

The binding table maps `my-session → AgentSession.session_id`. MAF's `AgentSession` holds the actual conversation items.

Workflow mode: the YAML's `workflow.checkpoint:` block controls persistence (MAF's `FileCheckpointStorage` / `InMemoryCheckpointStorage` at superstep boundaries). `--thread-id` is still bumped (for run accounting) but workflow state is checkpointed separately.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Config error, missing YAML, API error, or user interrupt |

## Docs launcher

```bash
agentflow-docs --backend agent-framework
# or the explicit alias
agentflow docs --dev-addr 127.0.0.1:9500
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
