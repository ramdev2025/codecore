# Getting Started

## Prerequisites

- Python 3.10+
- An OpenAI API key (or Azure OpenAI / Anthropic / Bedrock credentials — see [Services](SERVICES.md))

## Install

```bash
pip install agentflow[agent-framework]
```

Set the key:

```bash
export OPENAI_API_KEY=sk-...
```

Or put it in a `.env` next to your YAML — AgentFlow auto-loads it at startup.

## 1. Your First Agent (agent mode)

```yaml
# maf_agent.yaml
backend: agent-framework

metadata:
  version: "1.0"
  name: hello

llm:
  provider: openai
  config:
    model: gpt-4o-mini

agent:
  instructions: "You are a helpful assistant."
```

Validate without calling the API:

```bash
agentflow --yaml maf_agent.yaml --dry-run
```

Run:

```bash
agentflow --yaml maf_agent.yaml "What is the capital of France?"
```

## 2. Compose Multiple Agents (agent-as-tool)

MAF's idiomatic composition primitive is `agent.as_tool()` — any agent can be surfaced as a callable tool to another. In YAML:

```yaml
agent:
  name: orchestrator
  instructions: "Route user questions to the right specialist."
  tools:
    builtin:
      - {agent: billing}                           # shorthand
      - {agent: technical, tool_name: tech_help}   # with overrides

agents:
  billing:
    instructions: "Handle billing, subscriptions, refunds."
    description: "Billing specialist"
  technical:
    instructions: "Handle technical questions."
    description: "Technical support specialist"
```

The `description:` fields are hand to the LLM to decide which tool to call. See [Modes](MODES.md).

## 3. Custom Python Tools

Write a module with `@tool`-decorated functions:

```python
# myapp/tools.py
from agent_framework import tool

@tool
async def lookup_order(order_id: str) -> dict:
    """Look up an order by ID.

    Args:
        order_id: The order identifier.
    """
    return {"id": order_id, "status": "shipped"}
```

Reference from YAML:

```yaml
agents:
  billing:
    instructions: "Handle billing inquiries."
    plugins:
      - name: order-tools
        module: myapp.tools
        functions: [lookup_order]        # optional filter
```

See [Plugins](PLUGINS.md).

## 4. Workflow Mode — Explicit Graph

When routing is deterministic (not LLM-driven), use workflow mode:

```yaml
backend: agent-framework
metadata: { version: "1.0", name: triage-pipeline }
llm: { provider: openai, config: { model: gpt-4o-mini } }

agents:
  classifier: { instructions: "Classify the request type." }
  billing: { instructions: "Handle billing." }
  technical: { instructions: "Handle tech questions." }

workflow:
  start_executor: classifier
  executors:
    classifier: { agent: classifier }
    billing: { agent: billing }
    technical: { agent: technical }
  edges:
    - kind: switch_case
      source: classifier
      cases:
        - { when: "category == 'billing'", target: billing }
        - { when: "category == 'tech'", target: technical }
      default: billing
```

See [Workflows](WORKFLOWS.md).

## 5. Add a Guardrail

The cross-backend portable tier is identical across SK / CAS / OAI / MAF — paste the same block:

```yaml
guards:
  - type: pii
    config: { patterns: [email, phone, ssn] }
  - type: tool_call_limit
    config: { max_calls: 50 }

observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 5.00 }
  - type: latency_tracking
```

On MAF these compile to the right middleware layer (`ChatMiddleware` for PII, `AgentMiddleware` for cost tracking). See [Guards / Optimizers / Observers](GUARDS.md).

## 6. Persistence

```bash
agentflow --yaml maf_agent.yaml --thread-id my-session "first message"
agentflow --yaml maf_agent.yaml --thread-id my-session "follow-up"
```

AgentFlow stores `my-session → AgentSession.session_id` binding in SQLite (default `.agentflow/maf_threads.db`). MAF's native `AgentSession` owns the conversation items. See [Persistence](PERSISTENCE.md).

For workflow mode, use MAF's own `FileCheckpointStorage`:

```yaml
workflow:
  checkpoint:
    backend: file
    base_path: .agentflow/maf_checkpoints
```

## 7. Observability

Enable OpenTelemetry tracing:

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
agentflow --yaml maf_agent.yaml "What's the weather?"
```

MAF auto-emits:
- `invoke_agent <name>` root span per agent call
- `chat <model>` per LLM call
- `execute_tool <function>` per tool invocation
- `gen_ai.client.operation.duration` / `gen_ai.client.token.usage` metrics

AgentFlow adds one `agentflow.maf.run` root span so the trace is keyed by `thread_id`. See [Observability](OBSERVABILITY.md).

## Next

- [YAML Reference](YAML_REFERENCE.md) — every field, every validator
- [CLI Reference](CLI_REFERENCE.md) — every flag and env var
- [Full Example](FULL_EXAMPLE.md) — production-grade pharma investigation

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
