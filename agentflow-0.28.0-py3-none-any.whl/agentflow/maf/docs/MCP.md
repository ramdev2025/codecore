# MCP Integration

MAF ships MCP client support for **three transports** — one more than every other AgentFlow backend (the others are limited to stdio/SSE/HTTP). The addition is **WebSocket**, which lets agents talk to long-lived streaming tool servers with a single persistent connection.

| Transport | Class | YAML `transport:` |
|---|---|---|
| stdio | `MCPStdioTool` | `stdio` |
| HTTP (streamable) | `MCPStreamableHTTPTool` | `http` |
| WebSocket | `MCPWebsocketTool` | `websocket` |

## Declare servers

```yaml
mcp_servers:
  local-fs:
    transport: stdio
    command: npx
    args: [-y, "@modelcontextprotocol/server-filesystem", "/tmp"]
    env: { DEBUG: "1" }

  remote-http:
    transport: http
    url: https://mcp.example.com/v1
    headers: { Authorization: "Bearer ${MCP_TOKEN}" }
    terminate_on_close: true

  live-stream:
    transport: websocket
    url: wss://mcp.example.com/stream
    headers: { Authorization: "Bearer ${MCP_TOKEN}" }
```

## Attach to agents

```yaml
agent:
  instructions: "Use MCP tools when needed."
  mcp_servers: [local-fs, live-stream]  # references by name
```

Or on an auxiliary agent in workflow mode:

```yaml
agents:
  researcher:
    instructions: "..."
    mcp_servers: [remote-http]
```

The validator rejects any reference to a name not declared in top-level `mcp_servers:`.

## Transport details

### stdio

Spawns a subprocess. The server reads/writes on stdin/stdout.

```yaml
  local-fs:
    transport: stdio
    command: uvx
    args: [mcp-server-filesystem, /data]
    env: { LOG_LEVEL: debug }
```

Use for local tools, one-shot MCP servers, or anything you can run as a subprocess.

### http

Microsoft MAF supports the MCP Streamable HTTP transport (the current MCP spec's production transport — full-duplex HTTP).

```yaml
  remote:
    transport: http
    url: https://mcp.example.com/v1
    headers: { Authorization: "Bearer ${MCP_TOKEN}" }
    terminate_on_close: true                # send a teardown frame on close
```

### websocket — MAF-unique

WebSocket MCP is the newest transport and is ideal when the server emits events (e.g. long-running jobs, streaming data feeds).

```yaml
  live:
    transport: websocket
    url: wss://mcp.example.com/stream
    headers: { Authorization: "Bearer ${TOKEN}" }
```

WebSocket avoids per-request TCP overhead and keeps one connection alive for the whole agent run.

## Shared options (any transport)

```yaml
    tool_name_prefix: "mcp_"        # prefix added to every tool name registered from this server
    request_timeout: 30
    load_tools: true                # pull the server's tools list on connect
    load_prompts: true              # pull the server's prompts list too
    allowed_tools: [list_dir, read_file]   # restrict exposed tools
    approval_mode: always_require   # or never_require
    description: "..."              # attached to the MCP client object
```

## MCP + middleware

MCP tool calls flow through the same `FunctionMiddleware` pipeline as `@tool` Python functions, so `audit_log`, `latency_tracking`, and custom observers see them automatically:

```yaml
observers:
  - type: audit_log
  - type: latency_tracking

mcp_servers:
  tracking:
    transport: websocket
    url: wss://tracking.internal
```

Spans emitted carry the tool name, so MCP-hosted tool calls appear alongside `@tool` calls in Jaeger / Tempo / Datadog.

## Hosted MCP (server-side)

Separate from the three client transports above, MAF also supports **Foundry's hosted MCP** — where OpenAI / Foundry invokes a remote MCP server on your behalf:

```yaml
agent:
  tools:
    builtin:
      - name: hosted_mcp
        config:
          server_label: my-tools
          server_url: https://mcp.example.com
          require_approval: never
```

This is a different execution path — OpenAI's servers call the MCP server, not your process. Only available on Foundry and OpenAI Responses API endpoints.

## Debugging

```bash
AGENTFLOW_LOG_LEVEL=DEBUG agentflow --yaml maf_agent.yaml "..."
```

For stdio servers, check the server's own stderr — MAF forwards it. For HTTP / WebSocket, enable the exporter's access log.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
