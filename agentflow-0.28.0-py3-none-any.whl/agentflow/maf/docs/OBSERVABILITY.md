# Observability

**MAF has native OpenTelemetry instrumentation.** Unlike CAS / OAI where AgentFlow emits every `gen_ai.*` span manually from observers, on MAF the framework itself auto-emits the span tree and we just turn it on.

## Opt-in

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
export OTEL_EXPORTER_OTLP_PROTOCOL=grpc              # or http/protobuf
export OTEL_SERVICE_NAME=maf-prod                    # default: agentflow

agentflow --yaml maf_agent.yaml "..."
```

Without `OTEL_TRACES_ENABLED=true`, `setup_tracing()` is a no-op. Tracing never crashes the agent — the setup path is wrapped in `try/except`.

## What MAF emits natively

Spans (GenAI Semantic Conventions):

| Span | Attributes |
|---|---|
| `invoke_agent <agent_name>` | `gen_ai.agent.id`, `gen_ai.agent.name`, `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.usage.total_tokens` |
| `chat <model_name>` | `gen_ai.request.model`, `gen_ai.request.*` fields, `gen_ai.response.*` |
| `execute_tool <function_name>` | `gen_ai.operation.name=execute_tool`, `gen_ai.tool.name` |

Metrics (histograms):

- `gen_ai.client.operation.duration` (seconds)
- `gen_ai.client.token.usage` (tokens)
- `agent_framework.function.invocation.duration` (seconds)

## What AgentFlow adds

**One span:** `agentflow.maf.run` — a root wrapper so the full trace is keyed by `thread_id`.

```
agentflow.maf.run  (root)
├── invoke_agent orchestrator   (MAF-native)
│   ├── chat gpt-4o-mini         (MAF-native)
│   ├── execute_tool lookup_order (MAF-native)
│   └── ...
└── agentflow.cost_tracking      (our observer — budget rollup)
```

Our observers emit supplementary spans only where MAF's natives don't cover the concern:

| Observer | Span | Why we still emit it |
|---|---|---|
| `audit_log` | `agentflow.tool.audit <name>` | MAF's `execute_tool` doesn't include argument / result attributes by default |
| `cost_tracking` | `agentflow.cost_tracking` | Rolls up usage across the whole run + enforces `budget_limit` (MAF emits per-call usage but doesn't cap) |

`latency_tracking` is a pure log-emitting observer — MAF's `agent_framework.function.invocation.duration` metric is already the canonical source.

## Per-collector recipes

### Jaeger

```yaml
# docker-compose.yaml
services:
  jaeger:
    image: jaegertracing/all-in-one:latest
    ports: ["4317:4317", "16686:16686"]
```

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
export OTEL_METRICS_EXPORTER=none   # Jaeger accepts traces only — skip metrics
export OTEL_LOGS_EXPORTER=none      # and skip logs (also UNIMPLEMENTED on Jaeger)
agentflow --yaml maf_agent.yaml "..."
open http://localhost:16686
```

### Langfuse

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=https://cloud.langfuse.com/api/public/otel
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic <base64(pk:sk)>"
```

### Phoenix

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

### Azure Monitor

```bash
pip install azure-monitor-opentelemetry-exporter
export OTEL_TRACES_ENABLED=true
# Set APPLICATIONINSIGHTS_CONNECTION_STRING before running — the Azure
# exporter picks it up automatically.
```

### Aspire Dashboard

Spin up the dashboard, then:

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:18889
export OTEL_EXPORTER_OTLP_PROTOCOL=grpc
```

### Tempo, Datadog, New Relic, Honeycomb

Any OTLP-compatible endpoint works. Point `OTEL_EXPORTER_OTLP_ENDPOINT` at the collector's gRPC (4317) or HTTP (4318) port.

## Zero-code instrumentation

MAF's `configure_otel_providers()` plays nicely with `opentelemetry-instrument`:

```bash
opentelemetry-instrument agentflow --yaml maf_agent.yaml "..."
```

If an external SDK (Azure Monitor, Langfuse) has already installed a `TracerProvider`, set `ENABLE_INSTRUMENTATION=true` — MAF's instrumentation paths activate without replacing the provider.

## Control env vars (MAF-specific)

| Variable | Purpose |
|---|---|
| `ENABLE_INSTRUMENTATION` | Forced to `true` by our `setup_tracing()` when OTel is on |
| `ENABLE_SENSITIVE_DATA` | Include prompt / response content as span attributes (default: off) |
| `ENABLE_CONSOLE_EXPORTERS` | Echo spans to console in addition to OTLP |

## Redaction

MAF's default is **sensitive data off** — span attributes don't include prompt text or tool outputs. Flip `ENABLE_SENSITIVE_DATA=true` for debugging, but leave it off in production.

Our `audit_log` observer truncates tool I/O to 2000 chars (span attribute limit). For stricter redaction, write a custom observer callable:

```python
# myapp/observers.py
import re

_EMAIL = re.compile(r"[\w\.-]+@[\w\.-]+")

async def redact(tool_name, args, result):
    scrubbed = _EMAIL.sub("[REDACTED]", str(result))
    send_to_audit_sink(tool_name, scrubbed)
```

```yaml
observers:
  - type: audit_log
    module: myapp.observers
    function: redact
```

## Logging (non-OTel)

Even with tracing off, observers emit structured log records:

```python
import logging
logging.getLogger("agentflow.maf.audit").setLevel(logging.INFO)
logging.getLogger("agentflow.maf.cost").setLevel(logging.INFO)
logging.getLogger("agentflow.maf.latency").setLevel(logging.INFO)
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
