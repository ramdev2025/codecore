# Full Example

Annotated, production-grade YAML exercising both modes. Scenario: a pharmaceutical deviation investigation with three specialist agents and a final disposition report.

## Agent mode — orchestrator + agent-as-tool composition

```yaml
# pharma_agent.yaml
backend: agent-framework

metadata:
  version: "1.0"
  name: pharma-deviation-investigation
  description: >-
    Multi-agent deviation investigation with GxP compliance checks.
  author: Quality Engineering team
  tags: [pharma, gxp, production]

# -- Default LLM — Azure OpenAI with RBAC ----------------------------
llm:
  provider: azure_openai
  config:
    model: csdep-gpt-4o-prod
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true

# -- Main agent (orchestrator) ---------------------------------------
agent:
  name: orchestrator
  id: orch-v1                       # stable id for telemetry
  instructions: |
    You are the lead quality engineer orchestrating a pharmaceutical
    deviation investigation. You follow GxP standards and 21 CFR Part 211.

    Workflow:
      1. Hand off to `manufacturing_data` for historian / MES data.
      2. Hand off to `qa_investigation` for severity classification and RCA.
      3. Hand off to `regulatory_compliance` for GxP + disposition.
      4. Synthesize: batch id, severity, root cause, disposition, rationale.

    Ground every claim in tool output. Never fabricate data.
  tools:
    builtin:
      # Agent-as-tool composition — MAF's native delegation primitive
      - {agent: manufacturing_data, tool_name: call_manufacturing}
      - {agent: qa_investigation, tool_name: call_qa}
      - {agent: regulatory_compliance, tool_name: call_regulatory}
  model_settings:
    temperature: 0.2
    parallel_tool_calls: false

# -- Auxiliary agents (exposed as tools) -----------------------------
agents:

  manufacturing_data:
    instructions: |
      Manufacturing Data specialist. Pull historian / MES / sensor data.
    description: "MES logs, process historian, sensor-fault correlation."
    plugins:
      - {name: mfg-tools, module: myapp.manufacturing}

  qa_investigation:
    instructions: |
      QA specialist. Classify severity per ALCOA+, draft RCA, open QMS record.
    description: "Severity classification + RCA drafting + QMS record."
    plugins:
      - {name: qa-tools, module: myapp.qa}
    # Run with a cheaper model for routine classifications
    llm:
      provider: azure_openai
      config:
        model: csdep-gpt-4o-mini
        azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
        api_version: "2024-06-01"
        azure_identity: true

  regulatory_compliance:
    instructions: |
      Regulatory specialist. Validate GxP, check release criteria, issue
      disposition. Cite the regulation for every finding.
    description: "GxP / ALCOA+ validation, batch release, disposition."
    plugins:
      - {name: reg-tools, module: myapp.regulatory}
    mcp_servers: [compliance-kb]

# -- Cross-backend portable tier -------------------------------------
guards:
  - type: pii
    config: { patterns: [email, phone, ssn, credit_card] }
  - type: tool_call_limit
    config: { max_calls: 40 }
  - type: model_call_limit
    config: { max_calls: 15 }

optimizers:
  - type: tool_retry
    config: { max_retries: 2 }
  - type: prompt_caching
    config: { retention: "24h" }

observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 8.00 }
  - type: latency_tracking

# -- External MCP servers --------------------------------------------
mcp_servers:
  compliance-kb:
    transport: websocket               # MAF-unique transport
    url: wss://mcp.internal/v1/compliance
    headers:
      Authorization: "Bearer ${COMPLIANCE_KB_TOKEN}"
    allowed_tools: [search_regulations, lookup_citation]
    request_timeout: 30
```

## Workflow mode — explicit graph with fan-out + fan-in

Same scenario, different topology. Here the three specialists run in **parallel** (fan_out), and their outputs are aggregated by a `FunctionExecutor` before the summary agent:

```yaml
# pharma_workflow.yaml
backend: agent-framework

metadata: { version: "1.0", name: pharma-workflow }

llm:
  provider: azure_openai
  config:
    model: csdep-gpt-4o-prod
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true

# -- Agents (all wrapped as executors below) -------------------------
agents:

  triage:
    instructions: |
      Classify the investigation. Emit a structured handoff with
      fields that the downstream specialists need.

  manufacturing_data:
    instructions: "Pull historian + MES + sensor data."
    plugins:
      - {name: mfg-tools, module: myapp.manufacturing}

  qa_investigation:
    instructions: "Classify severity + draft RCA."
    plugins:
      - {name: qa-tools, module: myapp.qa}

  regulatory_compliance:
    instructions: "GxP validation + disposition."
    plugins:
      - {name: reg-tools, module: myapp.regulatory}

  summary:
    instructions: |
      Compile the final disposition report. Ground every claim in the
      specialists' outputs.

# -- Workflow graph --------------------------------------------------
workflow:
  name: pharma-investigation-graph
  start_executor: triage
  max_iterations: 40

  executors:
    triage: { agent: triage }
    mfg: { agent: manufacturing_data }
    qa: { agent: qa_investigation }
    reg: { agent: regulatory_compliance }
    # FunctionExecutor sink for fan_in — MAF's graph validator requires
    # a sink that accepts list[AgentExecutorResponse].
    join: { function: { module: myapp.aggregators, function: join_outputs } }
    summary: { agent: summary }

  edges:
    # Parallel fan-out from triage to all three specialists
    - kind: fan_out
      source: triage
      targets: [mfg, qa, reg]

    # Fan-in to the join function (aggregates 3 responses into one string)
    - kind: fan_in
      sources: [mfg, qa, reg]
      target: join

    # Chain from join into the summarizer
    - kind: direct
      source: join
      target: summary

  output_executors: [summary]

  checkpoint:
    backend: file
    base_path: .agentflow/pharma_checkpoints

observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 12.00 }
  - type: latency_tracking
```

## Supporting Python

```python
# myapp/manufacturing.py
from agent_framework import tool

@tool
async def query_historian(equipment_id: str, start: str, end: str) -> dict:
    """Query the process historian for time-series data."""
    ...

@tool
async def get_batch_logs(batch_id: str) -> dict:
    """Retrieve the MES execution log for a batch."""
    ...

@tool
async def correlate_faults(batch_id: str, date: str) -> dict:
    """Correlate equipment sensor faults with batch events."""
    ...
```

```python
# myapp/aggregators.py — FunctionExecutor sink for fan_in
async def join_outputs(responses: list) -> str:
    """Joins list[AgentExecutorResponse] into a single transcript for
    the summary agent."""
    parts = []
    for r in responses:
        agent_run = getattr(r, "agent_run_response", None)
        text = getattr(agent_run, "text", None)
        if callable(text):
            text = text()
        parts.append(str(text) if text else repr(r))
    return "\n\n---\n\n".join(parts)
```

## Run

### Dry-run both

```bash
agentflow --yaml pharma_agent.yaml --dry-run
agentflow --yaml pharma_workflow.yaml --dry-run
```

### Live run with OTel + Postgres persistence

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=https://otel-collector.internal:4317
export AGENTFLOW_ENCRYPTION_KEY=$(openssl rand -hex 32 | cut -c1-64)

agentflow \
  --yaml pharma_agent.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id "inv-$(uuidgen)" \
  "Investigate temperature excursion in Bioreactor 4 for batch 23F4."
```

## What gets emitted

Per run (with OTel + all observers on):

**Native (MAF):**
- `invoke_agent orchestrator` (agent mode) or `invoke_agent triage` (workflow mode)
- Child `invoke_agent <specialist>` per auxiliary agent / executor
- `chat <model>` per LLM call
- `execute_tool <function>` per tool invocation
- Metrics: `gen_ai.client.operation.duration`, `gen_ai.client.token.usage`, `agent_framework.function.invocation.duration`

**AgentFlow-added:**
- `agentflow.maf.run` root span with `agentflow.thread_id`, `agentflow.mode`
- `agentflow.tool.audit <name>` per tool call (supplemental attributes via `audit_log`)
- `agentflow.cost_tracking` once per run (with rolled-up usage + `agentflow.estimated_cost_usd`)

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
