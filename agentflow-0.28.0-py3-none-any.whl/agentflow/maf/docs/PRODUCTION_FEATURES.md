# Production Features

The MAF backend is built for enterprise deployment. Every feature below ships out of the box — no third-party middleware required.

## Enterprise feature matrix

| Feature | How |
|---|---|
| **Multi-provider LLM routing** | `llm.provider: openai \| azure_openai \| foundry \| anthropic \| bedrock \| custom`; per-agent override via `agent.llm:` |
| **Azure RBAC** | `azure_identity: true` → `DefaultAzureCredential` |
| **Azure AI Foundry** | `provider: foundry` with `project_endpoint` — hosted agents + server-side tools |
| **Two execution models** | `agent:` (LLM-driven composition) OR `workflow:` (explicit graph with BSP supersteps) |
| **Graph topologies** | `direct` / `chain` / `fan_out` / `fan_in` / `switch_case` in YAML |
| **Workflow checkpointing** | `FileCheckpointStorage` at every superstep boundary — resume after crash |
| **Budget enforcement** | `observers[].type: cost_tracking` with `budget_limit` (enforced via `MiddlewareTermination`); `guards[].type: model_call_limit` / `tool_call_limit` |
| **PII detection** | `guards[].type: pii` with named regex patterns, or custom `ChatMiddleware` |
| **Content filtering** | `guards[].type: content_filter` → custom chat middleware |
| **Structured output** | `model_settings.response_format: { ... }` — forwarded to the SDK |
| **Retry with backoff** | `optimizers[].type: tool_retry` → `FunctionMiddleware` with exponential backoff |
| **Prompt caching** | `optimizers[].type: prompt_caching` → `ModelSettings.prompt_cache_retention` |
| **Tracing (native `gen_ai.*`)** | `OTEL_TRACES_ENABLED=true` → `configure_otel_providers()`; MAF auto-emits `invoke_agent` / `chat` / `execute_tool` |
| **Metrics** | MAF auto-emits `gen_ai.client.operation.duration`, `gen_ai.client.token.usage`, `agent_framework.function.invocation.duration` |
| **Persistence / resume** | `--persistence sqlite\|postgres` + `--thread-id` (agent mode) |
| **Encryption at rest** | `AGENTFLOW_ENCRYPTION_KEY` — AES-GCM for binding table |
| **MCP** | 3 transports — stdio / HTTP / **WebSocket** (WebSocket unique to MAF) |
| **Middleware (three kinds)** | `AgentMiddleware` / `ChatMiddleware` / `FunctionMiddleware` — same `process(ctx, call_next)` shape |
| **Cross-backend plugins** | `plugin_bridge` — existing AgentFlow lifecycle plugins work unchanged |
| **YAML env interpolation** | `${VAR}` with `.env` auto-loading from cwd |
| **Cross-backend portable tier** | `guards:` / `optimizers:` / `observers:` — enum vocabulary identical across SK / CAS / OAI / MAF |

## Deployment checklist

- [ ] API key / Azure credentials set
- [ ] `OTEL_TRACES_ENABLED=true` + `OTEL_EXPORTER_OTLP_ENDPOINT`
- [ ] Picked a persistence backend (`sqlite` for single-instance, `postgres` for multi-instance)
- [ ] `AGENTFLOW_ENCRYPTION_KEY` set if regulatory requirements apply
- [ ] For agent mode — `observers:` declared: `audit_log`, `cost_tracking` (with `budget_limit`), `latency_tracking`
- [ ] For agent mode — `guards:` declared: `pii`, `tool_call_limit`, `model_call_limit`
- [ ] For workflow mode — `workflow.checkpoint.backend: file` configured with a safe `base_path`
- [ ] YAML validated with `agentflow --yaml <path> --dry-run`
- [ ] Log level configured (`AGENTFLOW_LOG_LEVEL=INFO` for production)

## Example production YAML (agent mode)

```yaml
backend: agent-framework

metadata:
  version: "1.0"
  name: customer-support-prod
  tags: [support, production]

llm:
  provider: azure_openai
  config:
    model: csdep-gpt-4.1-prod
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true

agent:
  name: orchestrator
  instructions: "Route user questions to the right specialist."
  tools:
    builtin:
      - {agent: billing}
      - {agent: technical}
      - {agent: kb_search}
  model_settings:
    temperature: 0.2

agents:
  billing:
    instructions: "Handle billing, subscriptions, refunds."
    plugins:
      - { name: billing-api, module: myapp.billing }
  technical:
    instructions: "Handle technical support."
    plugins:
      - { name: kb-search, module: myapp.kb }
  kb_search:
    instructions: "Query the knowledge base."
    mcp_servers: [kb]

guards:
  - { type: pii, config: { patterns: [email, phone, ssn, credit_card] } }
  - { type: tool_call_limit, config: { max_calls: 50 } }
  - { type: model_call_limit, config: { max_calls: 20 } }

optimizers:
  - { type: tool_retry, config: { max_retries: 2 } }
  - { type: prompt_caching, config: { retention: "24h" } }

observers:
  - { type: audit_log }
  - { type: cost_tracking, config: { budget_limit: 10.00 } }
  - { type: latency_tracking }

mcp_servers:
  kb:
    transport: websocket
    url: wss://mcp.internal/v1/kb
    headers: { Authorization: "Bearer ${KB_MCP_TOKEN}" }
```

```bash
export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -hex 32 | cut -c1-64)"
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=https://otel-collector.internal:4317

agentflow \
  --yaml maf_agent.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id "$(uuidgen)" \
  "I got charged twice last month."
```

## Backend comparison

| Feature | Workflows | Deep | SK | CAS | OAI | **MAF** |
|---|---|---|---|---|---|---|
| Single agent | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| Multi-agent composition | Nodes + edges | Subagents | Handoff orchestration | Task-tool subagents | Handoffs | Agent-as-tool OR Workflow graph |
| Explicit graph | LangGraph nodes | — | — | — | — | **WorkflowBuilder (BSP)** |
| Hosted tools | — | — | — | — | ✓ | ✓ (Foundry) |
| Structured output (Pydantic) | ✓ | ✓ | ✓ | — | ✓ | ✓ |
| Guardrails (tripwire) | — | — | filters | hooks | ✓ | Middleware |
| Sessions (SDK-native) | — | — | — | — | ✓ | ✓ |
| MCP transports | stdio/SSE/HTTP | — | stdio/SSE | stdio/SSE/HTTP | stdio/SSE/HTTP | **stdio/HTTP/WebSocket** |
| Azure RBAC | ✓ | ✓ | ✓ | — | ✓ | ✓ |
| Native `gen_ai.*` spans | ✓ | ✓ | ✓ | our observers | our observers | **SDK auto-emits** |
| Checkpointing | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (superstep granularity) |
| Plugin bridge | ✓ | — | ✓ | ✓ | ✓ | ✓ |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
