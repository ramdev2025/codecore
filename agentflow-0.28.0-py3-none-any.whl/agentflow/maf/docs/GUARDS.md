# Guards / Optimizers / Observers

AgentFlow's cross-backend portable tier — declare intent in YAML, the backend compiles to its native mechanism. Enum values are **identical across SK / CAS / OAI / MAF**, so YAML migrates mechanically.

```yaml
guards: [...]         # constrain execution
optimizers: [...]     # improve efficiency
observers: [...]      # watch without modifying
```

On MAF each entry compiles to a `AgentMiddleware` / `ChatMiddleware` / `FunctionMiddleware` instance attached to the appropriate layer.

## Compilation table

| YAML entry | Compiles to | Layer | What it does |
|---|---|---|---|
| `guards[].type: pii` | PII scan middleware | `ChatMiddleware` | Inspects pre-LLM messages; raises `MiddlewareTermination` on match |
| `guards[].type: tool_call_limit` | Counter | `FunctionMiddleware` | Raises when `on_tool_start` count exceeds `max_calls` |
| `guards[].type: model_call_limit` | Counter | `ChatMiddleware` | Raises when `on_llm_start` count exceeds `max_calls` |
| `guards[].type: input_validation` | Wraps user predicate | `ChatMiddleware` | Custom `async fn(messages) -> bool` — True = trip |
| `guards[].type: content_filter` | Wraps user predicate | `ChatMiddleware` | Custom `async fn(messages) -> bool` applied post-LLM via wrapped `ChatMiddleware` |
| `optimizers[].type: tool_retry` | Retry with exponential backoff | `FunctionMiddleware` | Retries failing tool calls; logs + re-raises after `max_retries` |
| `optimizers[].type: summarization` | Log | `AgentMiddleware` | No-op log — MAF has native `CompactionStrategy` you pick via `model_settings` |
| `optimizers[].type: prompt_caching` | **`ModelSettings.prompt_cache_retention`** | (settings patch) | No middleware — SDK-native |
| `observers[].type: audit_log` | Tool log + `agentflow.tool.audit` span | `FunctionMiddleware` | Supplements MAF's native `execute_tool` span with args + result |
| `observers[].type: cost_tracking` | Usage accumulator + budget enforcement | `AgentMiddleware` | Reads final `UsageDetails`; raises when `budget_limit` exceeded |
| `observers[].type: latency_tracking` | Per-tool latency log | `FunctionMiddleware` | Supplements MAF's native `function.invocation.duration` metric |

## Guards — examples

```yaml
guards:
  - type: pii
    config:
      patterns: [email, phone]          # default: [email, phone, ssn, credit_card]

  - type: tool_call_limit
    config: { max_calls: 50 }

  - type: model_call_limit
    config: { max_calls: 100 }

  - type: input_validation
    module: myapp.guards
    function: ensure_non_empty

  - type: content_filter
    module: myapp.guards
    function: check_pii_in_output
```

### Named PII patterns

| Name | Regex |
|---|---|
| `email` | `[\w\.-]+@[\w\.-]+` |
| `phone` | `\b(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b` |
| `ssn` | `\b\d{3}-\d{2}-\d{4}\b` |
| `credit_card` | `\b(?:\d[ -]*?){13,16}\b` |

Unknown names are treated as raw regex strings:

```yaml
    config:
      patterns: [email, '\b[A-Z]{2}\d{6}\b']    # email + custom tracking id
```

## Optimizers — examples

```yaml
optimizers:
  - type: tool_retry
    config:
      max_retries: 2
      initial_backoff_ms: 500

  - type: prompt_caching
    config:
      retention: "24h"                  # patches ModelSettings.prompt_cache_retention

  - type: summarization
    config:
      trigger_messages: 40              # no-op log; use CompactionStrategy for real
      keep_messages: 10
```

**Design note.** MAF handles `tool_retry` and `prompt_caching` natively via `ModelSettings` — our compiler patches the right field on `default_options` when possible and only emits middleware when MAF has no SDK-level knob.

## Observers — examples

```yaml
observers:
  - type: audit_log

  - type: cost_tracking
    config: { budget_limit: 5.00 }      # hard ceiling (approximate, uses $0.002/1K tokens default)

  - type: latency_tracking

  # Custom observer — arbitrary async function invoked on every tool end
  - type: audit_log
    module: myapp.observers
    function: forward_to_slack          # async fn(tool_name, args, result)
```

## Combining with per-agent middleware

Run-level `guards:` / `observers:` apply globally. For agent-specific middleware, use the agent's own `middleware:` block:

```yaml
guards:
  - { type: pii }                       # every agent

agents:
  billing:
    instructions: "..."
    middleware:                         # billing-only
      - { kind: function, module: myapp.mw, class_name: RefundAudit }
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
