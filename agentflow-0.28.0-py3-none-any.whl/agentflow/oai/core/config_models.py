"""Pydantic config models for the OpenAI Agents SDK (OAI) YAML schema.

The OAI schema mirrors the SDK's `Agent` + `handoffs` mental model — the
primitive that makes the SDK distinctive. Every agent is a peer in a flat
`agents:` dict; one is marked as the `starting_agent`; any agent can declare
`handoffs: [agent_name, ...]` to delegate to another.

Schema shape::

    backend: openai-agents
    metadata: { version, name, ... }

    llm:
      provider: openai | azure_openai | litellm | custom
      config: { model, api_key, ... }

    agents:
      <name>:
        instructions: "..."
        handoffs: [billing, technical]       # first-class — the SDK's killer primitive
        tools:
          builtin: [web_search, file_search, code_interpreter, ...]
        plugins: [...]                        # custom @function_tool modules
        mcp_servers: [local-data]             # reference top-level mcp_servers
        model: gpt-4o                         # per-agent override
        model_settings: { temperature, reasoning, verbosity, ... }
        input_guardrails: [...]               # first-class — community praises these
        output_guardrails: [...]
        output_type: { schema: ... }

    starting_agent: triage                    # required — where Runner.run() starts

    # Cross-backend portable tier (compiles down to hooks / guardrails)
    guards: [...]
    optimizers: [...]
    observers: [...]

    # Session-level options mapping to SDK RunConfig
    run_config:
      max_turns: 10
      workflow_name: "customer-support"
      tracing_disabled: false
      trace_include_sensitive_data: true
      nest_handoff_history: false
      sandbox: { ... }

    mcp_servers: { <name>: { transport, ... } }

The SDK has no native subagent hierarchy — any agent can hand off to any
other. That's why we use a flat `agents:` dict + explicit `starting_agent:`
pointer, NOT CAS's main-agent + subagents shape.
"""

from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator

from agentflow.genui import ClientToolConfig, UIToolsConfig


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


class OaiMetadata(BaseModel):
    version: str = Field(..., description="Schema version (e.g. '1.0')")
    name: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    tags: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# Providers + LLM
# ---------------------------------------------------------------------------


class LLMProvider(str, Enum):
    """LLM providers supported by the OAI backend.

    - ``openai``: native OpenAI API
    - ``azure_openai``: Azure OpenAI (auth via API key or Azure RBAC)
    - ``litellm``: multi-provider routing via LiteLLM (requires
      ``openai-agents[litellm]``)
    - ``custom``: user pre-configures the client via
      ``set_default_openai_client()`` before invoking agentflow
    """

    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    LITELLM = "litellm"
    CUSTOM = "custom"


class LLMConfig(BaseModel):
    """LLM-level config. Top-level default; per-agent ``agent.llm`` overrides."""

    provider: LLMProvider = Field(default=LLMProvider.OPENAI)
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Provider-specific config. Common keys: model, api_key, "
            "base_url (OpenAI-compatible endpoints); azure_endpoint, "
            "api_version, azure_identity (Azure RBAC); model_provider, "
            "litellm_api_key (LiteLLM)."
        ),
    )


# ---------------------------------------------------------------------------
# Model settings — mirror SDK ModelSettings dataclass
# ---------------------------------------------------------------------------


class ReasoningConfig(BaseModel):
    """SDK Reasoning config (for reasoning models like o1/o3/gpt-5)."""

    effort: Optional[Literal["low", "medium", "high"]] = None
    summary: Optional[Literal["auto", "concise", "detailed"]] = None
    generate_summary: Optional[bool] = None


class ModelRetryConfig(BaseModel):
    """Mirror of SDK ModelRetrySettings — per-model retry with backoff."""

    max_retries: Optional[int] = Field(None, ge=0)
    # `backoff` and `policy` are SDK-specific object types; pass through as dicts
    backoff: Optional[Dict[str, Any]] = None


class ModelSettingsConfig(BaseModel):
    """Mirror of SDK ModelSettings. Passed to every API call unless overridden."""

    temperature: Optional[float] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None
    parallel_tool_calls: Optional[bool] = None
    truncation: Optional[Literal["auto", "disabled"]] = None
    max_tokens: Optional[int] = Field(None, gt=0)
    reasoning: Optional[ReasoningConfig] = None
    verbosity: Optional[Literal["low", "medium", "high"]] = None
    metadata: Optional[Dict[str, str]] = None
    store: Optional[bool] = None
    prompt_cache_retention: Optional[Literal["in_memory", "24h"]] = None
    include_usage: Optional[bool] = None
    response_include: Optional[List[str]] = None
    top_logprobs: Optional[int] = None
    extra_query: Optional[Dict[str, Any]] = None
    extra_body: Optional[Dict[str, Any]] = None
    extra_headers: Optional[Dict[str, str]] = None
    extra_args: Optional[Dict[str, Any]] = None
    retry: Optional[ModelRetryConfig] = None


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


class BuiltinTool(str, Enum):
    """Hosted/built-in tools from the SDK.

    Hosted (OpenAI-server-side, GA):
      - ``web_search`` — WebSearchTool
      - ``file_search`` — FileSearchTool (requires vector_store_ids)
      - ``code_interpreter`` — CodeInterpreterTool
      - ``image_generation`` — ImageGenerationTool
      - ``hosted_mcp`` — HostedMCPTool (OpenAI-side MCP execution)

    Local (SDK-side execution):
      - ``computer`` — ComputerTool (requires Computer interface impl)
      - ``shell`` — ShellTool (requires sandbox config)
      - ``local_shell`` — LocalShellTool (legacy)
      - ``apply_patch`` — ApplyPatchTool (requires ApplyPatchEditor)
      - ``tool_search`` — ToolSearchTool (deferred tool loading)
    """

    WEB_SEARCH = "web_search"
    FILE_SEARCH = "file_search"
    CODE_INTERPRETER = "code_interpreter"
    IMAGE_GENERATION = "image_generation"
    HOSTED_MCP = "hosted_mcp"
    COMPUTER = "computer"
    SHELL = "shell"
    LOCAL_SHELL = "local_shell"
    APPLY_PATCH = "apply_patch"
    TOOL_SEARCH = "tool_search"


class BuiltinToolConfig(BaseModel):
    """One built-in tool with its optional config passthrough.

    Tools that need parameters (``file_search`` needs vector_store_ids;
    ``web_search`` can be tuned with search_context_size) carry them via
    ``config``. Tools with no config can be declared as a bare string in
    ``tools.builtin``; the validator normalizes both forms.
    """

    name: BuiltinTool
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Tool-specific kwargs (e.g. vector_store_ids for file_search)",
    )


class ToolsConfig(BaseModel):
    """Built-in tools on an agent. Accepts either bare names or detailed entries.

    - Bare form: ``builtin: [web_search, code_interpreter]``
    - Detailed: ``builtin: [{name: file_search, config: {vector_store_ids: [...]}}]``
    - Mixed is also fine.
    """

    builtin: List[Union[BuiltinTool, BuiltinToolConfig]] = Field(default_factory=list)

    def normalized(self) -> List[BuiltinToolConfig]:
        """Promote bare enum entries to ``BuiltinToolConfig`` for uniform downstream use."""
        out: List[BuiltinToolConfig] = []
        for item in self.builtin:
            if isinstance(item, BuiltinTool):
                out.append(BuiltinToolConfig(name=item))
            else:
                out.append(item)
        return out


# ---------------------------------------------------------------------------
# Plugins (custom @function_tool-decorated Python functions)
# ---------------------------------------------------------------------------


class PluginType(str, Enum):
    PYTHON = "python"


class PluginRef(BaseModel):
    """Reference to a Python module of ``@function_tool``-decorated functions.

    Per-tool options (``needs_approval``, ``timeout``, guardrails) are set on
    the decorator in user code — YAML just references the module.
    """

    name: str = Field(..., description="Logical plugin name (used in telemetry)")
    type: PluginType = Field(default=PluginType.PYTHON)
    module: str = Field(..., description="Python module path")
    functions: Optional[List[str]] = Field(
        None,
        description="Restrict to these function names (default: all @function_tool fns)",
    )


# ---------------------------------------------------------------------------
# Guardrails (SDK-native — first-class per community feedback)
# ---------------------------------------------------------------------------


class GuardrailRef(BaseModel):
    """Reference to a user-provided input/output guardrail function.

    The SDK's ``InputGuardrail`` / ``OutputGuardrail`` take a callable that
    returns ``GuardrailFunctionOutput(tripwire_triggered, output_info)``.
    Users author the function and we resolve it at build time.
    """

    module: str = Field(..., description="Python module path")
    function: str = Field(..., description="Async guardrail function name")
    name: Optional[str] = Field(None, description="Display name (default: function name)")
    run_in_parallel: bool = Field(
        default=True,
        description="Run this guardrail in parallel with the first LLM call (input guardrails only)",
    )


# ---------------------------------------------------------------------------
# Handoffs — THE killer primitive per community research; first-class
# ---------------------------------------------------------------------------


class HandoffDetailed(BaseModel):
    """Detailed handoff configuration — full SDK ``handoff()`` surface."""

    agent: str = Field(..., description="Target agent name (must exist in agents: dict)")
    tool_name_override: Optional[str] = None
    tool_description_override: Optional[str] = None
    on_handoff: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Callback invoked when the LLM triggers the handoff. "
            "Dict form: {module: '...', function: '...'}"
        ),
    )
    input_type: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "Pydantic schema reference for structured handoff input. "
            "Dict form: {module: '...', class_name: '...'}"
        ),
    )
    input_filter: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Function that trims/rewrites history before the receiving agent sees it. "
            "Dict form: {module: '...', function: '...'}"
        ),
    )
    nest_handoff_history: Optional[bool] = None
    is_enabled: Optional[Union[bool, Dict[str, str]]] = Field(
        default=True,
        description=(
            "Controls dynamic handoff availability. "
            "True/False for static, {module, function} for runtime predicate."
        ),
    )


# A handoff entry is either a plain agent-name string or the detailed dict
HandoffEntry = Union[str, HandoffDetailed]


# ---------------------------------------------------------------------------
# Output type (structured output)
# ---------------------------------------------------------------------------


class OutputTypeRef(BaseModel):
    """Reference to a Pydantic model / TypedDict class for structured output.

    The builder imports ``module.class_name`` and passes it to
    ``Agent(output_type=...)``. The SDK uses this to drive JSON-schema-enforced
    responses when the Responses API supports it.
    """

    module: str
    class_name: str


# ---------------------------------------------------------------------------
# MCP servers
# ---------------------------------------------------------------------------


class MCPTransport(str, Enum):
    STDIO = "stdio"
    SSE = "sse"
    HTTP = "http"  # StreamableHttp (current MCP spec)


class MCPServerEntry(BaseModel):
    transport: MCPTransport = Field(default=MCPTransport.STDIO)

    # stdio
    command: Optional[str] = None
    args: Optional[List[str]] = None
    env: Optional[Dict[str, str]] = None
    cwd: Optional[str] = None

    # sse / http
    url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    timeout: Optional[float] = None
    sse_read_timeout: Optional[float] = None
    terminate_on_close: Optional[bool] = None

    # shared MCPServer options
    cache_tools_list: bool = Field(default=False)
    use_structured_content: bool = Field(default=False)
    max_retry_attempts: int = Field(default=0, ge=0)
    retry_backoff_seconds_base: float = Field(default=1.0, ge=0)
    client_session_timeout_seconds: Optional[float] = Field(default=5.0)
    require_approval: Optional[Union[bool, Dict[str, Any]]] = None

    @model_validator(mode="after")
    def _validate_transport_fields(self) -> "MCPServerEntry":
        if self.transport == MCPTransport.STDIO:
            if not self.command:
                raise ValueError("MCP transport 'stdio' requires 'command'")
        else:
            if not self.url:
                raise ValueError(
                    f"MCP transport {self.transport.value!r} requires 'url'"
                )
        return self


# ---------------------------------------------------------------------------
# Cross-backend portable tier (guards/optimizers/observers)
# ---------------------------------------------------------------------------


class GuardType(str, Enum):
    PII = "pii"
    MODEL_CALL_LIMIT = "model_call_limit"
    TOOL_CALL_LIMIT = "tool_call_limit"
    INPUT_VALIDATION = "input_validation"
    CONTENT_FILTER = "content_filter"


class GuardConfig(BaseModel):
    type: GuardType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class OptimizerType(str, Enum):
    TOOL_RETRY = "tool_retry"
    SUMMARIZATION = "summarization"
    PROMPT_CACHING = "prompt_caching"


class OptimizerConfig(BaseModel):
    type: OptimizerType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class ObserverType(str, Enum):
    AUDIT_LOG = "audit_log"
    COST_TRACKING = "cost_tracking"
    LATENCY_TRACKING = "latency_tracking"


class ObserverConfig(BaseModel):
    type: ObserverType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


# ---------------------------------------------------------------------------
# Sandbox (SDK v0.14 beta)
# ---------------------------------------------------------------------------


class SandboxConfig(BaseModel):
    """Passthrough for SDK ``SandboxRunConfig`` (beta).

    The sandbox layer supports multiple backends (Docker, E2B, Modal, Blaxel,
    Daytona, Runloop, Vercel, Cloudflare). We accept the full config as a dict
    to avoid re-modeling backend-specific fields; the builder validates at
    runtime when the sandbox is actually used.
    """

    backend: Optional[str] = Field(
        None,
        description="Sandbox backend: docker | e2b | modal | blaxel | daytona | runloop | vercel | cloudflare",
    )
    config: Dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# RunConfig (session-level execution)
# ---------------------------------------------------------------------------


class RunConfigModel(BaseModel):
    """Mirror of SDK ``RunConfig`` — session-level knobs.

    Note: this is named ``RunConfigModel`` to avoid confusion with Pydantic's
    internal ``RunConfig``-like patterns.
    """

    max_turns: int = Field(default=10, gt=0, description="SDK ``Runner.run(max_turns=...)``")
    workflow_name: str = Field(default="Agent workflow")
    trace_id: Optional[str] = None
    group_id: Optional[str] = None
    trace_metadata: Optional[Dict[str, Any]] = None
    tracing_disabled: bool = False
    trace_include_sensitive_data: bool = True
    nest_handoff_history: bool = False
    sandbox: Optional[SandboxConfig] = None

    # Per-run model/settings overrides (uncommon — usually per-agent)
    model: Optional[str] = None
    model_settings: Optional[ModelSettingsConfig] = None

    # Run-level guardrails (apply before agent-level ones)
    input_guardrails: Optional[List[GuardrailRef]] = None
    output_guardrails: Optional[List[GuardrailRef]] = None


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class AgentSpec(BaseModel):
    """One agent. Flat dict under root ``agents:``; `starting_agent:` picks the entry point."""

    instructions: Union[str, Dict[str, str]] = Field(
        ...,
        description=(
            "Static string OR dynamic callable reference "
            "{module, function} returning str at runtime. Docs call this "
            "the 'system prompt'."
        ),
    )
    handoff_description: Optional[str] = Field(
        None,
        description="Shown to the LLM when another agent is considering handing off here.",
    )

    # Tools
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    plugins: Optional[List[PluginRef]] = None
    mcp_servers: Optional[List[str]] = Field(
        None,
        description="References to top-level mcp_servers entries by name",
    )

    # Cross-backend generative-UI components. Same schema MAF / SK / ADK
    # use, so a single YAML block works across backends.
    ui_tools: Optional[UIToolsConfig] = Field(
        None,
        description=(
            "Generative-UI components: a module of "
            "``@agentflow.genui.ui_component``-decorated fetchers exposed "
            "as openai-agents ``FunctionTool`` instances. Frontend "
            "rendering requires a separate AG-UI bridge."
        ),
    )
    # Frontend-implemented tools. The OAI AG-UI bridge advertises these
    # as additional ``FunctionTool`` instances on the agent; when the LLM
    # invokes one the orchestrator catches ``ClientToolPause`` and emits
    # an AG-UI Interrupt. Same cross-backend schema as workflows / deep /
    # MAF / SK / CAS.
    client_tools: Optional[List[ClientToolConfig]] = Field(
        default=None,
        description=(
            "Frontend-implemented (browser-side) tools. Each becomes a "
            "``FunctionTool`` on the agent; the OAI AG-UI bridge pauses "
            "the run when it's invoked and resumes once the browser "
            "posts the result. Bound only when the AG-UI router opts "
            "in via ``bind_client_tools=True``."
        ),
    )

    available_when: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Build-time predicate gating for ``ui_tools``. Keys are "
            "component class names; values are ``simpleeval`` expressions "
            "evaluated once at agent construction against the build "
            "state. Tools with falsy predicates are excluded."
        ),
    )

    # Handoffs — THE distinctive SDK primitive
    handoffs: Optional[List[HandoffEntry]] = None

    # Per-agent LLM override
    model: Optional[str] = None
    model_settings: Optional[ModelSettingsConfig] = None
    llm: Optional[LLMConfig] = Field(
        None,
        description="Per-agent provider override (e.g. mix OpenAI + LiteLLM agents in one run)",
    )

    # Guardrails — first-class per community feedback
    input_guardrails: Optional[List[GuardrailRef]] = None
    output_guardrails: Optional[List[GuardrailRef]] = None

    # Structured output
    output_type: Optional[OutputTypeRef] = None

    # Tool-use behavior
    tool_use_behavior: Literal["run_llm_again", "stop_on_first_tool"] = Field(
        default="run_llm_again"
    )
    reset_tool_choice: bool = True

    # Prompt template (SDK Prompt object; passthrough dict)
    prompt: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


class OaiYAMLConfig(BaseModel):
    """Root OpenAI Agents SDK YAML config."""

    backend: Literal["openai-agents"] = Field(default="openai-agents")
    metadata: OaiMetadata

    # Flat dict of all agents
    agents: Dict[str, AgentSpec] = Field(..., description="All agents in the run")
    starting_agent: str = Field(
        ...,
        description="Name of the agent where Runner.run() starts",
    )

    # Session-level knobs
    run_config: RunConfigModel = Field(default_factory=RunConfigModel)

    # Top-level LLM default (per-agent ``llm:`` overrides)
    llm: Optional[LLMConfig] = None

    # Cross-backend portable tier
    guards: Optional[List[GuardConfig]] = None
    optimizers: Optional[List[OptimizerConfig]] = None
    observers: Optional[List[ObserverConfig]] = None

    # MCP servers (referenced by agents via agents.<name>.mcp_servers: [name, ...])
    mcp_servers: Optional[Dict[str, MCPServerEntry]] = None

    @model_validator(mode="after")
    def _validate_structure(self) -> "OaiYAMLConfig":
        # Rule 1: agents dict cannot be empty
        if not self.agents:
            raise ValueError("'agents:' dict cannot be empty — declare at least one agent.")

        # Rule 2: starting_agent must reference a defined agent
        if self.starting_agent not in self.agents:
            raise ValueError(
                f"starting_agent {self.starting_agent!r} is not in agents: "
                f"{sorted(self.agents)}"
            )

        # Rule 3: every handoff target must reference a defined agent
        for agent_name, spec in self.agents.items():
            if not spec.handoffs:
                continue
            for entry in spec.handoffs:
                target = entry if isinstance(entry, str) else entry.agent
                if target not in self.agents:
                    raise ValueError(
                        f"Agent {agent_name!r} has handoff to unknown agent "
                        f"{target!r}. Known: {sorted(self.agents)}"
                    )

        # Rule 4: every agent.mcp_servers reference must exist at top level
        known_mcp = set(self.mcp_servers or {})
        for agent_name, spec in self.agents.items():
            if not spec.mcp_servers:
                continue
            missing = [n for n in spec.mcp_servers if n not in known_mcp]
            if missing:
                raise ValueError(
                    f"Agent {agent_name!r} references unknown mcp_servers "
                    f"{missing}. Known: {sorted(known_mcp) or 'none'}"
                )

        # Rule 5: at least one LLM config must exist (top-level OR on the
        # starting agent). Per-agent llm overrides otherwise.
        starting = self.agents[self.starting_agent]
        if self.llm is None and starting.llm is None:
            raise ValueError(
                "No LLM configured. Set 'llm:' at the top level or "
                f"agents.{self.starting_agent}.llm:"
            )

        return self
