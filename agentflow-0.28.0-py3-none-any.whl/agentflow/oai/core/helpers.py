"""Shared helpers for the OAI backend.

Mirror of ``src/agentflow/cas/core/helpers.py`` — env-var interpolation +
project ``.env`` loading anchored at the shell's CWD (not the installed
module's directory).
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def load_dotenv_for(yaml_path: str) -> None:
    """Load the project ``.env`` relative to the YAML file, falling back to CWD.

    Critical: anchor the fallback walk at the user's cwd (via
    ``find_dotenv(usecwd=True)``) — the bare ``load_dotenv()`` default
    walks up from the **caller's module** (this file), which on a pip
    install sits inside ``site-packages/`` and can traverse into an
    ancestor .env that has nothing to do with the user's project. With
    ``override=True`` that ancestor would silently clobber the values we
    just loaded from the yaml-adjacent .env.
    """
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:  # pragma: no cover
        return

    yaml_dir = Path(yaml_path).resolve().parent
    load_dotenv(yaml_dir / ".env", override=True)

    # Anchor at user cwd; skip if it would re-load the yaml-adjacent .env.
    cwd_dotenv = find_dotenv(usecwd=True)
    if cwd_dotenv and Path(cwd_dotenv).resolve() != (yaml_dir / ".env").resolve():
        load_dotenv(cwd_dotenv, override=True)


def resolve_env_vars(value: Any) -> Any:
    """Replace ``${VAR}`` placeholders recursively. Loud on missing vars."""
    if isinstance(value, str):
        return _ENV_PATTERN.sub(_resolve_match, value)
    if isinstance(value, dict):
        return {k: resolve_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_env_vars(v) for v in value]
    return value


def _resolve_match(m: re.Match) -> str:
    from agentflow.core.exceptions import MissingEnvVarError

    name = m.group(1)
    value = os.environ.get(name)
    if value is None:
        raise MissingEnvVarError(name)
    return value
