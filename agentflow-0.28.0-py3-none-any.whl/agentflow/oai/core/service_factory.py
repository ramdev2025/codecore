"""LLM config → SDK configuration.

The OpenAI Agents SDK picks up the OpenAI client from
``AsyncOpenAI()`` at module import time, reading ``OPENAI_API_KEY`` from
the environment. So ``api_key`` in YAML bridges to the env var. Provider
dispatch is via ``set_default_openai_client()`` (for Azure / custom
base URLs) or ``LitellmModel`` / MultiProvider (for LiteLLM).
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional, Tuple

from agentflow.oai.core.config_models import LLMConfig, LLMProvider

# ModelSettings fields the SDK understands — passed to the Agent(model_settings=...)
_MODEL_SETTING_KEYS = frozenset(
    {
        "temperature",
        "top_p",
        "frequency_penalty",
        "presence_penalty",
        "tool_choice",
        "parallel_tool_calls",
        "truncation",
        "max_tokens",
        "reasoning",
        "verbosity",
        "metadata",
        "store",
        "prompt_cache_retention",
        "include_usage",
        "response_include",
        "top_logprobs",
        "extra_query",
        "extra_body",
        "extra_headers",
        "extra_args",
        "retry",
    }
)


def apply_llm_config(llm: LLMConfig) -> Dict[str, Any]:
    """Apply side effects (env vars, default client) and return leftovers.

    Returns a dict of ``{"model": <resolved-model-name>}`` for the caller
    to pass to ``Agent(model=...)``. Leftover config keys are ignored —
    model-settings-level options belong on ``ModelSettings``.
    """
    cfg = dict(llm.config)

    # api_key → OPENAI_API_KEY env var (SDK reads env var directly)
    api_key = cfg.pop("api_key", None)
    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key

    if llm.provider == LLMProvider.OPENAI:
        _apply_openai(cfg)
    elif llm.provider == LLMProvider.AZURE_OPENAI:
        _apply_azure_openai(cfg)
    elif llm.provider == LLMProvider.LITELLM:
        _apply_litellm(cfg)
    elif llm.provider == LLMProvider.CUSTOM:
        # User is expected to have called set_default_openai_client() already
        pass

    out: Dict[str, Any] = {}
    if "model" in cfg:
        out["model"] = cfg.pop("model")
    return out


def _apply_openai(cfg: Dict[str, Any]) -> None:
    """Configure the default OpenAI client if a custom base_url is given."""
    base_url = cfg.pop("base_url", None)
    if base_url:
        from agents import AsyncOpenAI, set_default_openai_client  # lazy

        set_default_openai_client(AsyncOpenAI(base_url=base_url))


def _apply_azure_openai(cfg: Dict[str, Any]) -> None:
    """Wire up Azure OpenAI client — manual since SDK doesn't do it for us.

    Keys honored from config:
    - ``azure_endpoint`` (required)
    - ``api_version`` (required)
    - ``azure_deployment`` — used as the OpenAI ``model`` parameter
      (in Azure the deployment name plays the role of the model id)
    - ``azure_identity: true`` → use DefaultAzureCredential / token provider
    - ``api_key`` → already bridged to env var upstream
    """
    from agents import set_default_openai_client, set_default_openai_api  # lazy

    endpoint = cfg.pop("azure_endpoint", None) or cfg.pop("endpoint", None)
    api_version = cfg.pop("api_version", None)
    azure_identity = cfg.pop("azure_identity", False)
    # Azure deployments are identified by name, which maps to OpenAI's `model`.
    # If the user only supplied `azure_deployment:`, bridge it to `model:` so
    # the Agent's runtime call carries the right value.
    deployment = cfg.pop("azure_deployment", None)
    if deployment and "model" not in cfg:
        cfg["model"] = deployment

    if not endpoint:
        raise ValueError(
            "Azure OpenAI requires 'azure_endpoint' in llm.config"
        )
    if not api_version:
        raise ValueError(
            "Azure OpenAI requires 'api_version' in llm.config"
        )

    try:
        from openai import AsyncAzureOpenAI  # part of openai package
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "Azure OpenAI provider requires the openai package "
            "(already a transitive dep of openai-agents)."
        ) from exc

    kwargs: Dict[str, Any] = {
        "azure_endpoint": endpoint,
        "api_version": api_version,
    }

    if azure_identity:
        try:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        except ImportError as exc:
            raise ImportError(
                "azure_identity=true requires azure-identity: "
                "pip install azure-identity"
            ) from exc
        kwargs["azure_ad_token_provider"] = get_bearer_token_provider(
            DefaultAzureCredential(),
            "https://cognitiveservices.azure.com/.default",
        )

    client = AsyncAzureOpenAI(**kwargs)
    set_default_openai_client(client)
    # Azure OpenAI only implements Chat Completions (not Responses API yet)
    set_default_openai_api("chat_completions")


def _apply_litellm(cfg: Dict[str, Any]) -> None:
    """LiteLLM is opt-in via ``openai-agents[litellm]``.

    No side effects needed at the client level — per-agent model strings
    like ``litellm/anthropic/claude-sonnet-4-6`` trigger the adapter.
    """
    try:
        import litellm  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "provider 'litellm' requires openai-agents[litellm]"
        ) from exc


def split_config(llm: LLMConfig) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Return (agent_kwargs, extras) for dry-run display."""
    cfg = dict(llm.config)
    cfg.pop("api_key", None)
    # Mirror the Azure deployment → model bridge so dry-run displays the
    # effective model name.
    if llm.provider == LLMProvider.AZURE_OPENAI:
        deployment = cfg.pop("azure_deployment", None)
        if deployment and "model" not in cfg:
            cfg["model"] = deployment
    agent_kwargs = {}
    if "model" in cfg:
        agent_kwargs["model"] = cfg.pop("model")
    return agent_kwargs, cfg
