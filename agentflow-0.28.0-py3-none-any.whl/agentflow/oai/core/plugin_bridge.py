"""Bridge AgentFlow lifecycle plugins to OAI RunHooks.

AgentFlow's ``Plugin`` ABC (``agentflow.workflows.plugins``) is a set of
observer hooks — ``on_tool_call``, ``on_tool_result``, ``on_error``,
``on_workflow_start/end``, ``on_agent_start/end``, etc. The OAI SDK's
``RunHooks`` interface is an async callback set (``on_tool_start``,
``on_tool_end``, ``on_agent_start``, ``on_agent_end``, ``on_handoff``).
This module bridges the two so existing telemetry / logging / cost
plugins work on OAI agents without modification.

Design note (same as the SK / CAS bridges): duck-typed ``plugin_manager``
— any object with ``emit_tool_call`` / ``emit_tool_result`` / ``emit_error``
methods. Keeps this module import-safe whether or not the workflows
package is installed.

Events this bridge produces:

- ``on_tool_call``   — from OAI's ``on_tool_start`` hook
- ``on_tool_result`` — from OAI's ``on_tool_end`` hook
- ``on_error``       — from exception paths surfaced by the runner
- ``on_agent_start/end`` + ``on_workflow_start/end`` — fired by the CLI
  driver around the ``Runner.run()`` invocation (see
  :class:`WorkflowLifecycleEmitter`). Events that don't apply to OAI
  (``on_hitl_*``, ``on_external_agent_*``, ``on_mcp_connect``) simply
  never fire.
"""

from __future__ import annotations

from typing import Any, Optional


def build_plugin_bridge_hook(
    plugin_manager: Any,
    context: Any,
) -> Optional[Any]:
    """Return a ``RunHooks`` subclass instance that relays SDK events to plugins.

    Callers compose this with other observer hooks via
    :func:`agentflow.oai.filters.builtin.compose_hooks` before passing to
    ``Runner.run(hooks=...)``.
    """
    if plugin_manager is None:
        return None

    from agents import RunHooks  # lazy

    class _PluginBridge(RunHooks):
        async def on_tool_start(self, ctx, agent, tool):
            name = getattr(tool, "name", type(tool).__name__)
            _safe_emit(plugin_manager, "emit_tool_call", context, name, None)

        async def on_tool_end(self, ctx, agent, tool, result):
            name = getattr(tool, "name", type(tool).__name__)
            _safe_emit(plugin_manager, "emit_tool_result", context, name, result)

        async def on_agent_start(self, ctx, agent):
            _safe_emit(
                plugin_manager,
                "emit_agent_start",
                context,
                getattr(agent, "name", "?"),
            )

        async def on_agent_end(self, ctx, agent, output):
            _safe_emit(
                plugin_manager,
                "emit_agent_end",
                context,
                getattr(agent, "name", "?"),
                "success",
            )

        async def on_handoff(self, ctx, from_agent, to_agent):
            _safe_emit(
                plugin_manager,
                "emit_handoff",
                context,
                getattr(from_agent, "name", "?"),
                getattr(to_agent, "name", "?"),
            )

    return _PluginBridge()


# ---------------------------------------------------------------------------
# Lifecycle emitter — used by the CLI around the top-level run
# ---------------------------------------------------------------------------


class WorkflowLifecycleEmitter:
    """Context manager that fires ``on_workflow_start/end`` events around an
    OAI run.

    Usage::

        with WorkflowLifecycleEmitter(plugin_manager, context, agent_name):
            await runner.query(...)
    """

    def __init__(self, plugin_manager: Any, context: Any, agent_name: str):
        self.plugin_manager = plugin_manager
        self.context = context
        self.agent_name = agent_name

    def __enter__(self):
        _safe_emit(self.plugin_manager, "emit_workflow_start", self.context)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "failed" if exc_type else "success"
        if exc_val is not None:
            _safe_emit(
                self.plugin_manager,
                "emit_error",
                self.context,
                exc_val,
                {"agent": self.agent_name},
            )
        _safe_emit(
            self.plugin_manager,
            "emit_workflow_end",
            self.context,
            None,
            status,
        )
        return False  # don't swallow exceptions


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_emit(plugin_manager: Any, method: str, *args: Any) -> None:
    """Call ``plugin_manager.<method>(*args)`` swallowing exceptions.

    Plugins are optional observers — a missing method means the host
    doesn't care about that event, which is not an error.
    """
    fn = getattr(plugin_manager, method, None)
    if fn is None:
        return
    try:
        fn(*args)
    except Exception:
        # Observers must not break the agent.
        pass
