"""Map YAML ``BuiltinToolConfig`` entries to SDK built-in tool instances.

The SDK provides 10 built-in tool classes with heterogeneous constructors:
some take kwargs (WebSearchTool, FileSearchTool), some take a single
``tool_config`` object (CodeInterpreterTool, ImageGenerationTool,
HostedMCPTool), and some take runtime callables or custom class refs
(ComputerTool, ShellTool, LocalShellTool, ApplyPatchTool). This module
dispatches by tool name with clear errors for the ones that need more
than a config dict.
"""

from __future__ import annotations

import importlib
from typing import Any, Dict, List

from agentflow.oai.core.config_models import BuiltinTool, BuiltinToolConfig


def build_builtin_tools(tools: List[BuiltinToolConfig]) -> List[Any]:
    """Convert a list of ``BuiltinToolConfig`` into concrete SDK tool instances."""
    return [_build_one(t) for t in tools]


def _build_one(tool: BuiltinToolConfig) -> Any:
    name = tool.name
    cfg = dict(tool.config)

    # Lazy imports — only pull in classes the user actually asked for.
    if name == BuiltinTool.WEB_SEARCH:
        from agents import WebSearchTool
        return WebSearchTool(**cfg)

    if name == BuiltinTool.FILE_SEARCH:
        from agents import FileSearchTool
        if "vector_store_ids" not in cfg:
            raise ValueError(
                "FileSearchTool requires 'vector_store_ids' in config"
            )
        return FileSearchTool(**cfg)

    if name == BuiltinTool.CODE_INTERPRETER:
        from agents import CodeInterpreterTool
        return CodeInterpreterTool(tool_config=_dict_or_obj(cfg, "tool_config"))

    if name == BuiltinTool.IMAGE_GENERATION:
        from agents import ImageGenerationTool
        return ImageGenerationTool(tool_config=_dict_or_obj(cfg, "tool_config"))

    if name == BuiltinTool.HOSTED_MCP:
        from agents import HostedMCPTool
        on_approval = _resolve_optional_callable(cfg.pop("on_approval_request", None))
        return HostedMCPTool(
            tool_config=_dict_or_obj(cfg, "tool_config"),
            on_approval_request=on_approval,
        )

    if name == BuiltinTool.TOOL_SEARCH:
        from agents import ToolSearchTool
        return ToolSearchTool(**cfg)

    # Tools that need a user-provided Python class or callable:
    if name == BuiltinTool.COMPUTER:
        from agents import ComputerTool
        computer = _resolve_required_ref(cfg, "computer", "ComputerTool")
        on_safety = _resolve_optional_callable(cfg.pop("on_safety_check", None))
        return ComputerTool(computer=computer, on_safety_check=on_safety)

    if name == BuiltinTool.SHELL:
        from agents import ShellTool
        executor = _resolve_optional_ref(cfg.pop("executor", None))
        environment = _resolve_optional_ref(cfg.pop("environment", None))
        on_approval = _resolve_optional_callable(cfg.pop("on_approval", None))
        return ShellTool(
            executor=executor,
            environment=environment,
            on_approval=on_approval,
            **cfg,
        )

    if name == BuiltinTool.LOCAL_SHELL:
        from agents import LocalShellTool
        executor = _resolve_required_ref(cfg, "executor", "LocalShellTool")
        return LocalShellTool(executor=executor)

    if name == BuiltinTool.APPLY_PATCH:
        from agents import ApplyPatchTool
        editor = _resolve_required_ref(cfg, "editor", "ApplyPatchTool")
        on_approval = _resolve_optional_callable(cfg.pop("on_approval", None))
        return ApplyPatchTool(
            editor=editor,
            on_approval=on_approval,
            **cfg,
        )

    raise ValueError(f"Unknown built-in tool: {name!r}")  # pragma: no cover


# ---------------------------------------------------------------------------
# Helpers for resolving {module, class_name} / {module, function} refs
# ---------------------------------------------------------------------------


def _resolve_required_ref(cfg: Dict[str, Any], key: str, tool_name: str) -> Any:
    """Pop ``cfg[key]`` and instantiate it as a {module, class_name} ref."""
    ref = cfg.pop(key, None)
    if ref is None:
        raise ValueError(
            f"{tool_name} requires {key!r} in config as "
            f"{{module: ..., class_name: ...}} — builder cannot construct it otherwise."
        )
    return _instantiate_ref(ref)


def _resolve_optional_ref(ref: Any) -> Any:
    if ref is None:
        return None
    return _instantiate_ref(ref)


def _resolve_optional_callable(ref: Any) -> Any:
    """Resolve a {module, function} ref into the callable object."""
    if ref is None:
        return None
    if callable(ref):  # pragma: no cover
        return ref
    if not isinstance(ref, dict):
        raise ValueError(
            f"Callable ref must be a dict with 'module' + 'function', got {ref!r}"
        )
    module_path = ref["module"]
    function_name = ref["function"]
    mod = importlib.import_module(module_path)
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"{function_name!r} not found in module {module_path!r}"
        )
    return fn


def _instantiate_ref(ref: Any) -> Any:
    """Instantiate a {module, class_name} ref into an object."""
    if isinstance(ref, dict):
        module_path = ref.get("module")
        class_name = ref.get("class_name")
        if not module_path or not class_name:
            raise ValueError(
                f"ref must have 'module' and 'class_name' keys, got {ref!r}"
            )
        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name, None)
        if cls is None:
            raise AttributeError(
                f"{class_name!r} not found in module {module_path!r}"
            )
        return cls()
    return ref  # already an object


def _dict_or_obj(cfg: Dict[str, Any], key: str) -> Any:
    """For tools that take a config object: return the full cfg dict as-is,
    or pull out the nested ``tool_config`` key if provided."""
    if key in cfg:
        return cfg[key]
    return cfg
