"""Async orchestrator for the OAI AG-UI bridge.

Wraps the :class:`OaiRunner` (OpenAI Agents SDK) and translates its
``Runner.run_streamed()`` event stream into the dict event format
the AG-UI adapter consumes.

The OAI SDK emits three event flavors:

  * ``RawResponsesStreamEvent`` — raw Responses API events (token
    deltas, function call deltas). We extract text deltas for the
    streaming text path.
  * ``RunItemStreamEvent`` — high-level items: ``tool_called``,
    ``tool_output``, ``message_output_created``, ``handoff_*``. We
    translate ``tool_called`` → ``tool_call``, ``tool_output`` →
    ``tool``, and surface ``message_output_created`` as a final
    ``agent`` event when streaming is off.
  * ``AgentUpdatedStreamEvent`` — emitted when a handoff happens.
    We pass through for diagnostic logging; no AG-UI event is
    emitted (handoffs are an OAI internal concern).

State: in-memory per-thread prompt history (the OAI SDK doesn't have
a built-in checkpointer). Paused interrupts kept in
``_paused_threads`` for the bridge resilience checks.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AsyncOAIAGUIRuntime:
    """Async runtime wrapping an openai-agents OaiRunner."""

    def __init__(
        self,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> None:
        self._config_path = config_path
        self._build_state = build_state or {}
        self._bind_client_tools = bind_client_tools
        self._builder: Any = None
        self._runner: Any = None
        self._thread_history: dict[str, list[str]] = {}
        self._paused_threads: dict[str, dict[str, Any]] = {}

    @classmethod
    async def create(
        cls,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> "AsyncOAIAGUIRuntime":
        from agentflow.oai.core.builder import OaiAgentBuilder

        inst = cls(
            config_path=config_path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )
        inst._builder = OaiAgentBuilder.from_yaml(
            config_path,
            build_state=inst._build_state,
            bind_client_tools=bind_client_tools,
        )
        inst._runner = inst._builder.build()
        return inst

    async def cleanup(self) -> None:
        return None

    async def get_state(self, thread_id: str) -> dict[str, Any]:
        from types import SimpleNamespace

        tasks = ()
        pending = self._paused_threads.get(thread_id)
        if pending is not None:
            intr = SimpleNamespace(id=pending["id"], value=pending["value"])
            task = SimpleNamespace(id=f"task-{thread_id}", interrupts=(intr,))
            tasks = (task,)

        return {
            "values": {"history_turns": len(self._thread_history.get(thread_id, []))},
            "tasks": tasks,
            "next": (),
        }

    async def run(
        self,
        state: Any,
        config: dict,
        stream_tokens: bool = False,
    ):
        """Yield orchestrator events translated from OAI's stream."""
        from langgraph.types import Command

        from agentflow.oai.agui.client_tools import ClientToolPause

        thread_id = (config.get("configurable") or {}).get("thread_id") or "default"
        history = self._thread_history.setdefault(thread_id, [])

        prompt: Optional[str] = None
        if isinstance(state, Command):
            pending = self._paused_threads.pop(thread_id, None)
            if pending is None:
                logger.warning("OAI: resume requested for thread=%s but no paused interrupt", thread_id)
                return
            tool_name = pending["value"].get("tool_name") or "?"
            content = state.resume if isinstance(state.resume, str) else str(state.resume)
            prompt = f"Tool result for {tool_name}: {content}\n\nContinue based on this result."
        elif isinstance(state, dict) and state.get("messages"):
            for msg in state["messages"]:
                if msg.get("role") == "user" and msg.get("content"):
                    prompt = msg["content"]
        if not prompt:
            return

        history.append(prompt)

        if stream_tokens:
            yield {"type": "agent_start", "name": "oai-agent", "content": ""}

        accumulated_text = ""
        tool_call_names: dict[str, str] = {}  # call_id → tool name

        try:
            async for event in self._runner.query_streamed(prompt):
                events = list(self._translate_event(
                    event,
                    tool_call_names,
                    stream_tokens,
                ))
                for ev in events:
                    if ev.get("type") == "token":
                        accumulated_text += ev.get("content", "") or ""
                    yield ev
        except ClientToolPause as pause:
            interrupt_id = uuid.uuid4().hex[:12]
            payload = {
                "type": "agentflow:client_tool",
                "tool_name": pause.tool_name,
                "args": pause.tool_args,
            }
            self._paused_threads[thread_id] = {
                "id": interrupt_id,
                "value": payload,
            }
            yield {
                "type": "interrupt",
                "interrupts": [{
                    "id": interrupt_id,
                    "reason": "agentflow:client_tool",
                    "tool_name": pause.tool_name,
                    "metadata": {"args": pause.tool_args},
                }],
            }
            return

        if stream_tokens:
            yield {"type": "agent_end", "name": "oai-agent"}

        if accumulated_text:
            history.append(f"[assistant]: {accumulated_text}")

    # ------------------------------------------------------------------
    # Event translation
    # ------------------------------------------------------------------

    def _translate_event(
        self,
        event: Any,
        tool_call_names: dict[str, str],
        stream_tokens: bool,
    ):
        """Translate one OAI StreamEvent into zero-or-more dict events."""
        etype = getattr(event, "type", None)

        if etype == "raw_response_event":
            # Raw Responses API event. We're interested in output-text
            # deltas for streaming text.
            data = getattr(event, "data", None)
            data_type = getattr(data, "type", None)
            if data_type == "response.output_text.delta":
                delta = getattr(data, "delta", "") or ""
                if delta and stream_tokens:
                    yield {"type": "token", "name": "oai-agent", "content": delta}

        elif etype == "run_item_stream_event":
            name = getattr(event, "name", None)
            item = getattr(event, "item", None)

            if name == "tool_called":
                # ``item`` is a ToolCallItem wrapping a ResponseFunctionToolCall.
                raw = getattr(item, "raw_item", None)
                tool_name = (
                    getattr(raw, "name", None)
                    or getattr(item, "name", None)
                    or "tool"
                )
                call_id = (
                    getattr(raw, "call_id", None)
                    or getattr(raw, "id", None)
                    or ""
                )
                arguments = getattr(raw, "arguments", None) or {}
                if isinstance(arguments, str):
                    try:
                        import json
                        arguments = json.loads(arguments)
                    except Exception:
                        arguments = {"raw": arguments}
                tool_call_names[call_id] = tool_name
                yield {
                    "type": "tool_call",
                    "name": tool_name,
                    "args": arguments if isinstance(arguments, dict) else {"raw": str(arguments)},
                }

            elif name == "tool_output":
                raw = getattr(item, "raw_item", None)
                call_id = (
                    getattr(raw, "call_id", None)
                    or getattr(raw, "id", None)
                    or ""
                )
                # ``output`` may live on the item itself or its raw_item.
                output = getattr(item, "output", None)
                if output is None and raw is not None:
                    output = getattr(raw, "output", None)
                payload: Any = output
                if isinstance(output, str):
                    try:
                        import json
                        payload = json.loads(output)
                    except Exception:
                        payload = output
                # Detect a ``ClientToolPause`` propagated as a tool error
                # output (the SDK serializes exceptions raised in
                # ``@function_tool`` bodies as strings).
                if isinstance(output, str) and "client_tool pause:" in output:
                    raise _decode_client_tool_pause(output)
                yield {
                    "type": "tool",
                    "name": tool_call_names.get(call_id, ""),
                    "content": payload,
                }

            elif name == "message_output_created":
                # Final assistant message item. When NOT streaming tokens
                # we surface the whole text as one ``agent`` event so the
                # adapter can emit a proper TEXT_MESSAGE pair.
                if stream_tokens:
                    return
                raw = getattr(item, "raw_item", None)
                text = ""
                content = getattr(raw, "content", None) or []
                for block in content:
                    btype = getattr(block, "type", None)
                    if btype == "output_text":
                        text += getattr(block, "text", "") or ""
                if text:
                    yield {"type": "agent", "name": "oai-agent", "content": text}

        # AgentUpdatedStreamEvent / others: ignored for now.


def _decode_client_tool_pause(text: str):
    """Reconstruct a ``ClientToolPause`` from the SDK's stringified
    representation."""
    from agentflow.oai.agui.client_tools import ClientToolPause

    name = "?"
    args: dict[str, Any] = {}
    try:
        body = text.split("client_tool pause:", 1)[1].strip()
        if "(" in body:
            name = body.split("(", 1)[0].strip()
            arg_repr = body[len(name):].strip()
            if arg_repr.startswith("(") and arg_repr.endswith(")"):
                inner = arg_repr[1:-1]
                try:
                    import json
                    args = json.loads(inner)
                except Exception:
                    try:
                        import ast
                        parsed = ast.literal_eval(inner)
                        if isinstance(parsed, dict):
                            args = parsed
                    except Exception:
                        args = {"raw": inner}
    except Exception:
        pass
    return ClientToolPause(tool_name=name, args=args)
