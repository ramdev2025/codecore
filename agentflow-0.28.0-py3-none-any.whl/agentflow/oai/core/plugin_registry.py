"""Resolve ``PluginRef`` entries into lists of SDK ``FunctionTool`` instances.

Python ``@function_tool``-decorated functions return ``FunctionTool``
objects. The registry imports the module, collects those objects, and
(optionally) filters to a named subset.
"""

from __future__ import annotations

import importlib
from typing import Any, List

from agentflow.oai.core.config_models import PluginRef, PluginType


def resolve_plugins(plugins: List[PluginRef] | None) -> List[Any]:
    """Flatten all plugins into a single list of FunctionTool instances.

    Unlike CAS (where plugins become MCP SDK servers), OAI's custom tools
    are just ``FunctionTool`` objects passed directly to ``Agent(tools=...)``.
    """
    if not plugins:
        return []

    from agents import FunctionTool  # lazy

    out: List[Any] = []
    for ref in plugins:
        if ref.type != PluginType.PYTHON:  # pragma: no cover - schema enforces
            raise ValueError(
                f"Plugin type {ref.type.value!r} not supported yet. "
                f"Only 'python' works in v1."
            )
        tools = _load_tools(ref.module, ref.functions, FunctionTool)
        if not tools:
            raise ValueError(
                f"Plugin {ref.name!r}: no @function_tool-decorated functions "
                f"found in {ref.module!r}"
                + (f" (filter: {ref.functions})" if ref.functions else "")
            )
        out.extend(tools)
    return out


def _load_tools(module_path: str, filter_names: List[str] | None, tool_cls: type) -> List[Any]:
    """Import ``module_path`` and return every ``FunctionTool`` found."""
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Plugin module {module_path!r} could not be imported: {exc}. "
            f"Is it on PYTHONPATH?"
        ) from exc

    found: list[tuple[str, Any]] = [
        (attr, obj)
        for attr, obj in vars(mod).items()
        if isinstance(obj, tool_cls)
    ]

    if filter_names:
        allowed = set(filter_names)
        found = [
            (n, t)
            for n, t in found
            if n in allowed or getattr(t, "name", None) in allowed
        ]

    return [t for _, t in found]
