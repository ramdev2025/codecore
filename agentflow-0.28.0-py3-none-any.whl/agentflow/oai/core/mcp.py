"""Translate YAML ``mcp_servers:`` entries into SDK MCP server instances.

The SDK's ``mcp_servers=`` on an Agent takes a list of ``MCPServer``
instances (``MCPServerStdio``, ``MCPServerSse``, ``MCPServerStreamableHttp``).
Each agent picks the subset it needs by name.
"""

from __future__ import annotations

from typing import Any, Dict

from agentflow.oai.core.config_models import MCPServerEntry, MCPTransport


def resolve_mcp_servers(
    servers: Dict[str, MCPServerEntry] | None,
) -> Dict[str, Any]:
    """Return a dict of ``{name: MCPServer-instance}`` — agents reference by name."""
    if not servers:
        return {}

    from agents.mcp import (  # lazy
        MCPServerSse,
        MCPServerSseParams,
        MCPServerStdio,
        MCPServerStdioParams,
        MCPServerStreamableHttp,
        MCPServerStreamableHttpParams,
    )

    out: Dict[str, Any] = {}
    for name, entry in servers.items():
        # Common kwargs accepted by all three transports
        common = {
            "name": name,
            "cache_tools_list": entry.cache_tools_list,
            "use_structured_content": entry.use_structured_content,
            "max_retry_attempts": entry.max_retry_attempts,
            "retry_backoff_seconds_base": entry.retry_backoff_seconds_base,
        }
        if entry.client_session_timeout_seconds is not None:
            common["client_session_timeout_seconds"] = entry.client_session_timeout_seconds
        if entry.require_approval is not None:
            common["require_approval"] = entry.require_approval

        if entry.transport == MCPTransport.STDIO:
            params: Dict[str, Any] = {"command": entry.command}
            if entry.args:
                params["args"] = entry.args
            if entry.env:
                params["env"] = entry.env
            if entry.cwd:
                params["cwd"] = entry.cwd
            out[name] = MCPServerStdio(params=MCPServerStdioParams(**params), **common)

        elif entry.transport == MCPTransport.SSE:
            params = {"url": entry.url}
            if entry.headers:
                params["headers"] = entry.headers
            if entry.timeout is not None:
                params["timeout"] = entry.timeout
            if entry.sse_read_timeout is not None:
                params["sse_read_timeout"] = entry.sse_read_timeout
            out[name] = MCPServerSse(params=MCPServerSseParams(**params), **common)

        elif entry.transport == MCPTransport.HTTP:
            params = {"url": entry.url}
            if entry.headers:
                params["headers"] = entry.headers
            if entry.timeout is not None:
                params["timeout"] = entry.timeout
            if entry.sse_read_timeout is not None:
                params["sse_read_timeout"] = entry.sse_read_timeout
            if entry.terminate_on_close is not None:
                params["terminate_on_close"] = entry.terminate_on_close
            out[name] = MCPServerStreamableHttp(
                params=MCPServerStreamableHttpParams(**params), **common
            )
    return out
