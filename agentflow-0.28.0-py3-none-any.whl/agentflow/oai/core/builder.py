"""``OaiAgentBuilder`` — compose a runnable OpenAI Agents SDK workflow from YAML.

Pipeline::

    yaml file
        -> OaiYAMLConfig (Pydantic)
        -> helpers.resolve_env_vars
        -> service_factory.apply_llm_config (api_key -> env var, Azure / LiteLLM client)
        -> tool_factory.build_builtin_tools (per-agent hosted + local tools)
        -> plugin_registry.resolve_plugins (Python @function_tool modules)
        -> guardrail_registry (InputGuardrail / OutputGuardrail instances)
        -> mcp.resolve_mcp_servers (stdio / sse / http MCPServer instances)
        -> Agent instances (two-pass — handoffs populated after all agents built)
        -> RunConfig
        -> OaiRunner wrapping starting_agent + run_config
"""

from __future__ import annotations

import importlib
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional

import yaml

from agentflow.oai.core.config_models import (
    AgentSpec,
    HandoffDetailed,
    ModelSettingsConfig,
    OaiYAMLConfig,
    OutputTypeRef,
    ReasoningConfig,
)
from agentflow.oai.core.guardrail_registry import (
    resolve_input_guardrails,
    resolve_output_guardrails,
)
from agentflow.oai.core.helpers import load_dotenv_for, resolve_env_vars
from agentflow.oai.core.mcp import resolve_mcp_servers
from agentflow.oai.core.plugin_registry import resolve_plugins
from agentflow.oai.core.service_factory import apply_llm_config, split_config
from agentflow.oai.core.tool_factory import build_builtin_tools
from agentflow.oai.filters.compiler import CompiledFilters, compile_filters


@dataclass
class OaiRunner:
    """Pre-configured OpenAI Agents SDK runner.

    Holds the starting agent, the ``RunConfig``, and a summary dict for
    ``--dry-run``. Callers choose the invocation style:

    - ``await runner.query(prompt)`` — one-shot via ``Runner.run()``
    - ``async for ev in runner.query_streamed(prompt)`` — streaming via
      ``Runner.run_streamed()``
    """

    starting_agent: Any
    run_config: Any
    max_turns: int
    agents_by_name: Dict[str, Any]
    mcp_servers_by_name: Dict[str, Any]
    summary: Dict[str, Any]
    compiled_hooks: List[Any]   # RunHooks instances from `observers:` / `optimizers:` / counter-based guards

    def _compose_run_kwargs(self, extra_hooks: Optional[List[Any]] = None) -> Dict[str, Any]:
        """Assemble kwargs for ``Runner.run*()`` including a composed hooks instance."""
        from agentflow.oai.filters.builtin import compose_hooks  # lazy

        hooks_list = list(self.compiled_hooks)
        if extra_hooks:
            hooks_list.extend(extra_hooks)
        kwargs: Dict[str, Any] = {
            "run_config": self.run_config,
            "max_turns": self.max_turns,
        }
        composed = compose_hooks(hooks_list)
        if composed is not None:
            kwargs["hooks"] = composed
        return kwargs

    async def query(self, prompt: str) -> Any:
        """One-shot run. Returns a ``RunResult``."""
        from agents import Runner  # lazy

        return await Runner.run(
            self.starting_agent, prompt, **self._compose_run_kwargs()
        )

    async def query_streamed(self, prompt: str) -> AsyncIterator[Any]:
        """Streaming run — async iterator of ``StreamEvent``s."""
        from agents import Runner  # lazy

        result = Runner.run_streamed(
            self.starting_agent, prompt, **self._compose_run_kwargs()
        )
        async for event in result.stream_events():
            yield event


class OaiAgentBuilder:
    """Build a :class:`OaiRunner` from a YAML config path or parsed dict."""

    def __init__(
        self,
        config: OaiYAMLConfig,
        yaml_path: Optional[str] = None,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ):
        self.config = config
        self.yaml_path = yaml_path
        # Build-time state for ``available_when`` predicate evaluation
        # of ``ui_tools``. See ``agentflow.genui.availability`` for
        # semantics (fail-safe default when ``None``).
        self.build_state: Dict[str, Any] = build_state or {}
        # AG-UI router opt-in for client_tools. Off by default — CLI /
        # script callers never see them. Flipped on by
        # ``AsyncOAIAGUIRuntime.create`` so the agent also carries the
        # ``ClientToolPause`` stubs.
        self.bind_client_tools: bool = bind_client_tools

    # -- Construction ------------------------------------------------------

    @classmethod
    def from_yaml(
        cls,
        path: str,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ) -> "OaiAgentBuilder":
        load_dotenv_for(path)
        raw = yaml.safe_load(Path(path).read_text())
        if raw is None:
            raise ValueError(f"YAML file is empty: {path}")
        raw = resolve_env_vars(raw)
        config = OaiYAMLConfig.model_validate(raw)
        return cls(
            config,
            yaml_path=path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    @classmethod
    def from_dict(
        cls,
        data: Dict[str, Any],
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ) -> "OaiAgentBuilder":
        resolved = resolve_env_vars(data)
        config = OaiYAMLConfig.model_validate(resolved)
        return cls(
            config,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    # -- Build -------------------------------------------------------------

    def build(self) -> OaiRunner:
        import os

        from agents import set_tracing_disabled  # lazy

        # Auto-disable the OpenAI Agents SDK's hosted-tracing span
        # exporter when there's no ``OPENAI_API_KEY``. The exporter
        # POSTs every span to ``platform.openai.com/v1/traces`` and
        # needs an OpenAI API key — which Azure-RBAC users don't have.
        # Without this, every run logs ``Tracing client error 401``
        # noise even though nothing is broken. This only kills the
        # OpenAI hosted-dashboard export; AgentFlow's own OTel span
        # (``agui.run`` / etc.) and ``RunResult.usage`` are unaffected.
        # Users who set ``OPENAI_API_KEY`` explicitly keep the SDK's
        # default tracing behavior.
        if not os.environ.get("OPENAI_API_KEY"):
            set_tracing_disabled(True)

        # 1. Apply top-level LLM config (side effects: env vars, default client)
        top_llm = self.config.llm
        top_agent_kwargs = apply_llm_config(top_llm) if top_llm else {}
        default_model = top_agent_kwargs.get("model")

        # 2. Compile the cross-backend portable tier.
        # Produces: extra input/output guardrails, RunHooks list, and a
        # ModelSettings patch (e.g. prompt_cache_retention, retry).
        compiled: CompiledFilters = compile_filters(
            guards=self.config.guards,
            optimizers=self.config.optimizers,
            observers=self.config.observers,
        )

        # 3. Resolve session-level MCP servers (referenced by agents by name)
        mcp_by_name = resolve_mcp_servers(self.config.mcp_servers)

        # 4. Pass 1 — build every Agent WITHOUT handoffs
        agents_by_name: Dict[str, Any] = {}
        for name, spec in self.config.agents.items():
            agent = self._build_agent(
                name, spec, default_model, mcp_by_name
            )
            agents_by_name[name] = agent

        # 5. Pass 2 — populate handoffs (may reference any agent built in pass 1)
        for name, spec in self.config.agents.items():
            self._attach_handoffs(agents_by_name[name], spec, agents_by_name)

        # 6. Build RunConfig, merging compiled guardrails onto whatever the
        # user already declared in `run_config.*_guardrails:`.
        run_config = self._build_run_config(compiled)

        return OaiRunner(
            starting_agent=agents_by_name[self.config.starting_agent],
            run_config=run_config,
            max_turns=self.config.run_config.max_turns,
            agents_by_name=agents_by_name,
            mcp_servers_by_name=mcp_by_name,
            summary=self.dry_run(),
            compiled_hooks=compiled.hooks,
        )

    # -- Dry-run -----------------------------------------------------------

    def dry_run(self) -> Dict[str, Any]:
        llm = self.config.llm
        sdk_opts, extras = split_config(llm) if llm else ({}, {})

        agents_summary = {}
        for name, spec in self.config.agents.items():
            agents_summary[name] = {
                "model": spec.model or sdk_opts.get("model"),
                "tools": [t.value for t in (t.name for t in spec.tools.normalized())] or [],
                "plugin_count": len(spec.plugins or []),
                "handoffs": [
                    e if isinstance(e, str) else e.agent
                    for e in (spec.handoffs or [])
                ],
                "input_guardrails": len(spec.input_guardrails or []),
                "output_guardrails": len(spec.output_guardrails or []),
                "mcp_servers": spec.mcp_servers or [],
            }

        return {
            "backend": "openai-agents",
            "metadata": self.config.metadata.model_dump(exclude_none=True),
            "llm": {
                "provider": llm.provider.value if llm else None,
                "sdk_options": sdk_opts,
                "extras": extras,
            },
            "starting_agent": self.config.starting_agent,
            "agents": agents_summary,
            "run_config": {
                "max_turns": self.config.run_config.max_turns,
                "workflow_name": self.config.run_config.workflow_name,
                "tracing_disabled": self.config.run_config.tracing_disabled,
                "sandbox": self.config.run_config.sandbox.backend
                if self.config.run_config.sandbox
                else None,
            },
            "guards": [g.type.value for g in (self.config.guards or [])],
            "optimizers": [o.type.value for o in (self.config.optimizers or [])],
            "observers": [o.type.value for o in (self.config.observers or [])],
            "mcp_servers": list((self.config.mcp_servers or {}).keys()),
        }

    # -- Internals ---------------------------------------------------------

    def _build_agent(
        self,
        name: str,
        spec: AgentSpec,
        default_model: Optional[str],
        mcp_by_name: Dict[str, Any],
    ) -> Any:
        """Construct one ``Agent`` instance (sans handoffs — those come in pass 2)."""
        from agents import Agent

        # Per-agent LLM override
        agent_model = spec.model
        if spec.llm is not None:
            per_agent_kwargs = apply_llm_config(spec.llm)
            agent_model = agent_model or per_agent_kwargs.get("model")
        agent_model = agent_model or default_model

        # Tools: builtin + plugins + ui_tools
        tools = []
        tools.extend(build_builtin_tools(spec.tools.normalized()))
        tools.extend(resolve_plugins(spec.plugins))

        # Generative-UI components. Each ``@ui_component`` fetcher in
        # ``spec.ui_tools.module`` becomes an openai-agents
        # ``FunctionTool``. Build-time ``available_when`` predicates
        # filter the list before binding.
        if spec.ui_tools is not None:
            from agentflow.genui import filter_by_availability
            from agentflow.oai.genui import resolve_ui_tools

            ui_tools = resolve_ui_tools(spec.ui_tools)
            ui_tools = filter_by_availability(
                ui_tools, spec.available_when, self.build_state
            )
            tools.extend(ui_tools)

        # Frontend client_tools. The AG-UI router opts in via
        # ``bind_client_tools=True``; each ``ClientToolConfig`` becomes
        # a ``FunctionTool`` whose body raises ``ClientToolPause``. The
        # orchestrator catches the exception and emits an AG-UI
        # Interrupt. CLI / script callers leave the flag off and the
        # tools stay invisible — no phantom calls.
        if self.bind_client_tools and spec.client_tools:
            from agentflow.oai.agui.client_tools import build_client_tool_function_tools

            tools.extend(build_client_tool_function_tools(spec.client_tools))

        # Instructions (static string OR {module, function} callable ref)
        instructions = _resolve_instructions(spec.instructions)

        # Guardrails
        input_guardrails = resolve_input_guardrails(spec.input_guardrails)
        output_guardrails = resolve_output_guardrails(spec.output_guardrails)

        # MCP servers — referenced by name
        mcp_servers = [mcp_by_name[n] for n in (spec.mcp_servers or [])]

        # Output type — import Pydantic class
        output_type = _resolve_output_type(spec.output_type)

        # Warn if model_settings has fields that reasoning models reject.
        # The SDK will return a 400 otherwise; this catches the mistake at
        # build time with a clearer actionable message.
        if spec.model_settings and agent_model:
            _warn_if_reasoning_incompatible(name, agent_model, spec.model_settings)

        # Model settings — only pass when set (Agent rejects None). Default
        # ``include_usage=True`` so observer spans always see token counts.
        # Without this, Azure Chat Completions streaming silently drops
        # ``stream_options.include_usage`` and every ``response.usage`` is
        # None → all observer token totals collapse to 0.
        model_settings = _build_model_settings(
            spec.model_settings, default_include_usage=True
        )

        kwargs: Dict[str, Any] = {
            "name": name,
            "instructions": instructions,
            "handoff_description": spec.handoff_description,
            "tools": tools,
            "mcp_servers": mcp_servers,
            "input_guardrails": input_guardrails,
            "output_guardrails": output_guardrails,
            "output_type": output_type,
            "tool_use_behavior": spec.tool_use_behavior,
            "reset_tool_choice": spec.reset_tool_choice,
        }
        if agent_model is not None:
            kwargs["model"] = agent_model
        if model_settings is not None:
            kwargs["model_settings"] = model_settings
        if spec.prompt is not None:
            kwargs["prompt"] = spec.prompt
        return Agent(**kwargs)

    def _attach_handoffs(
        self,
        agent: Any,
        spec: AgentSpec,
        agents_by_name: Dict[str, Any],
    ) -> None:
        """Populate ``agent.handoffs`` now that every agent instance exists."""
        if not spec.handoffs:
            return

        from agents import handoff  # lazy

        out: List[Any] = []
        for entry in spec.handoffs:
            if isinstance(entry, str):
                out.append(agents_by_name[entry])
            else:
                assert isinstance(entry, HandoffDetailed)
                kwargs: Dict[str, Any] = {}
                if entry.tool_name_override:
                    kwargs["tool_name_override"] = entry.tool_name_override
                if entry.tool_description_override:
                    kwargs["tool_description_override"] = entry.tool_description_override
                if entry.on_handoff:
                    kwargs["on_handoff"] = _resolve_ref_callable(entry.on_handoff)
                if entry.input_type:
                    kwargs["input_type"] = _resolve_ref_class(entry.input_type)
                if entry.input_filter:
                    kwargs["input_filter"] = _resolve_ref_callable(entry.input_filter)
                if entry.nest_handoff_history is not None:
                    kwargs["nest_handoff_history"] = entry.nest_handoff_history
                if entry.is_enabled is not None:
                    if isinstance(entry.is_enabled, bool):
                        kwargs["is_enabled"] = entry.is_enabled
                    else:
                        kwargs["is_enabled"] = _resolve_ref_callable(entry.is_enabled)
                out.append(handoff(agents_by_name[entry.agent], **kwargs))
        agent.handoffs = out

    def _build_run_config(self, compiled: Optional[CompiledFilters] = None) -> Any:
        from agents import RunConfig  # lazy

        rc_cfg = self.config.run_config
        kwargs: Dict[str, Any] = {
            "workflow_name": rc_cfg.workflow_name,
            "tracing_disabled": rc_cfg.tracing_disabled,
            "trace_include_sensitive_data": rc_cfg.trace_include_sensitive_data,
            "nest_handoff_history": rc_cfg.nest_handoff_history,
        }
        if rc_cfg.trace_id:
            kwargs["trace_id"] = rc_cfg.trace_id
        if rc_cfg.group_id:
            kwargs["group_id"] = rc_cfg.group_id
        if rc_cfg.trace_metadata:
            kwargs["trace_metadata"] = rc_cfg.trace_metadata
        if rc_cfg.model:
            kwargs["model"] = rc_cfg.model
        if rc_cfg.model_settings:
            kwargs["model_settings"] = _build_model_settings(rc_cfg.model_settings)

        # Merge explicit guardrails from run_config with ones compiled from
        # the cross-backend `guards:` tier.
        extra_in = list(compiled.input_guardrails) if compiled else []
        extra_out = list(compiled.output_guardrails) if compiled else []
        explicit_in = resolve_input_guardrails(rc_cfg.input_guardrails)
        explicit_out = resolve_output_guardrails(rc_cfg.output_guardrails)
        if explicit_in or extra_in:
            kwargs["input_guardrails"] = explicit_in + extra_in
        if explicit_out or extra_out:
            kwargs["output_guardrails"] = explicit_out + extra_out

        if rc_cfg.sandbox:
            kwargs["sandbox"] = _build_sandbox(rc_cfg.sandbox)
        return RunConfig(**kwargs)


# ---------------------------------------------------------------------------
# Small resolvers — kept at module level so they can be reused by tests
# ---------------------------------------------------------------------------


def _resolve_instructions(instructions: Any) -> Any:
    """Static string passes through; {module, function} resolves to callable."""
    if isinstance(instructions, str):
        return instructions
    if isinstance(instructions, dict):
        return _resolve_ref_callable(instructions)
    return instructions


def _resolve_ref_callable(ref: Dict[str, str]) -> Any:
    """Resolve a ``{module, function}`` ref into the callable."""
    module_path = ref["module"]
    function_name = ref["function"]
    mod = importlib.import_module(module_path)
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"{function_name!r} not found in module {module_path!r}"
        )
    return fn


def _resolve_ref_class(ref: Dict[str, Any]) -> Any:
    """Resolve a ``{module, class_name}`` ref into the class."""
    module_path = ref.get("module")
    class_name = ref.get("class_name")
    if not module_path or not class_name:
        raise ValueError(
            f"class ref must include 'module' and 'class_name', got {ref!r}"
        )
    mod = importlib.import_module(module_path)
    cls = getattr(mod, class_name, None)
    if cls is None:
        raise AttributeError(
            f"{class_name!r} not found in module {module_path!r}"
        )
    return cls


def _resolve_output_type(ref: Optional[OutputTypeRef]) -> Any:
    if ref is None:
        return None
    return _resolve_ref_class({"module": ref.module, "class_name": ref.class_name})


def _build_model_settings(
    cfg: Optional[ModelSettingsConfig],
    default_include_usage: bool = False,
) -> Any:
    """Translate our ModelSettingsConfig to SDK ``ModelSettings``.

    ``default_include_usage`` controls the default of the SDK's
    ``include_usage`` field when the user didn't specify it. Set to ``True``
    for agents so Chat Completions streaming emits per-turn usage
    (Responses API includes usage regardless). Any explicit
    ``model_settings.include_usage:`` in YAML wins.
    """
    from agents import ModelSettings

    # Build-up — start with the default so we always return a ModelSettings
    # when default_include_usage is True, even if the user supplied no cfg.
    kwargs: Dict[str, Any] = {}
    if cfg is None:
        if default_include_usage:
            kwargs["include_usage"] = True
            return ModelSettings(**kwargs)
        return None

    for field in (
        "temperature", "top_p", "frequency_penalty", "presence_penalty",
        "tool_choice", "parallel_tool_calls", "truncation", "max_tokens",
        "verbosity", "metadata", "store", "prompt_cache_retention",
        "include_usage", "response_include", "top_logprobs",
        "extra_query", "extra_body", "extra_headers", "extra_args",
    ):
        value = getattr(cfg, field)
        if value is not None:
            kwargs[field] = value

    # Apply default only if the user didn't explicitly set one.
    if default_include_usage and "include_usage" not in kwargs:
        kwargs["include_usage"] = True

    if cfg.reasoning is not None:
        kwargs["reasoning"] = _build_reasoning(cfg.reasoning)
    if cfg.retry is not None:
        kwargs["retry"] = _build_retry(cfg.retry)

    return ModelSettings(**kwargs)


def _build_reasoning(cfg: ReasoningConfig) -> Any:
    """Translate our ReasoningConfig to the openai ``Reasoning`` model."""
    from openai.types.shared import Reasoning

    kwargs: Dict[str, Any] = {}
    if cfg.effort is not None:
        kwargs["effort"] = cfg.effort
    if cfg.summary is not None:
        kwargs["summary"] = cfg.summary
    if cfg.generate_summary is not None:
        kwargs["generate_summary"] = cfg.generate_summary
    return Reasoning(**kwargs)


def _build_retry(cfg: Any) -> Any:
    """Translate our ModelRetryConfig to SDK ``ModelRetrySettings``."""
    from agents.model_settings import ModelRetrySettings

    kwargs: Dict[str, Any] = {}
    if cfg.max_retries is not None:
        kwargs["max_retries"] = cfg.max_retries
    if cfg.backoff is not None:
        kwargs["backoff"] = cfg.backoff
    return ModelRetrySettings(**kwargs)


def _build_sandbox(cfg: Any) -> Any:
    """Passthrough for SandboxRunConfig."""
    from agents.sandbox import SandboxRunConfig  # type: ignore

    data = {"backend": cfg.backend, **cfg.config} if cfg.backend else dict(cfg.config)
    return SandboxRunConfig(**data)


# ---------------------------------------------------------------------------
# Reasoning-model compatibility warnings
# ---------------------------------------------------------------------------

# Matches gpt-5 family (gpt-5, gpt-5-mini, gpt-5.4, gpt-5.4-mini, …) and
# the o-series (o1, o1-mini, o3, o3-mini, o4-mini, …) anywhere within a
# model identifier — including Azure deployment names like
# ``csdep-30429803-gpt-5-mini`` where the family suffix is what matters.
_REASONING_MODEL_PATTERN = re.compile(
    r"(?:^|[-_/])(?:gpt-5(?:\.\d+)?(?:-mini)?|o[134](?:-mini)?)(?:$|[-_/])",
    re.IGNORECASE,
)

# Fields reasoning models don't support. The value is the short reason
# shown in the warning.
_REASONING_INCOMPATIBLE_FIELDS = {
    "temperature": "only the default (1) is accepted",
    "top_p": "only the default is accepted",
    "frequency_penalty": "not supported",
    "presence_penalty": "not supported",
}


def is_reasoning_model(model: str) -> bool:
    """Return True if ``model`` looks like a reasoning model (gpt-5* / o-series).

    Accepts Azure deployment names (``csdep-…-gpt-5-mini``), plain OpenAI
    model ids (``gpt-5-mini``, ``o3-mini``), and LiteLLM-prefixed names.
    """
    if not model:
        return False
    return bool(_REASONING_MODEL_PATTERN.search(model))


def _warn_if_reasoning_incompatible(
    agent_name: str,
    model: str,
    cfg: ModelSettingsConfig,
) -> None:
    """Log a warning if ``cfg`` sets fields reasoning models will reject.

    Emitted to the ``agentflow.oai`` logger at WARNING — visible by default.
    Silent on non-reasoning models, silent when the listed fields are unset.
    Users can still configure the fields (we don't override or strip them);
    the warning just flags that the SDK will likely return a 400.
    """
    if not is_reasoning_model(model):
        return

    offending = []
    for field, reason in _REASONING_INCOMPATIBLE_FIELDS.items():
        value = getattr(cfg, field, None)
        if value is not None:
            offending.append(f"{field}={value!r} ({reason})")
    if not offending:
        return

    logging.getLogger("agentflow.oai").warning(
        "agent %r uses reasoning model %r but sets %s. "
        "The API will likely return 400. Use `reasoning.effort` + "
        "`verbosity` for reasoning models, or switch to a non-reasoning "
        "deployment (gpt-4o / gpt-4.1).",
        agent_name, model, ", ".join(offending),
    )
