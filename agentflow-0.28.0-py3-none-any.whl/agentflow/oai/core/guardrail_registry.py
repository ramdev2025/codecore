"""Resolve ``GuardrailRef`` entries into SDK ``InputGuardrail`` / ``OutputGuardrail``
instances.

User authors an async function with the SDK-expected signature, points to it
via ``{module, function}``, and we wrap it in the SDK's guardrail dataclass.
"""

from __future__ import annotations

import importlib
from typing import Any, Callable, List

from agentflow.oai.core.config_models import GuardrailRef


def resolve_input_guardrails(refs: List[GuardrailRef] | None) -> List[Any]:
    if not refs:
        return []
    from agents import InputGuardrail  # lazy

    return [
        InputGuardrail(
            guardrail_function=_load_callable(ref.module, ref.function),
            name=ref.name or ref.function,
            run_in_parallel=ref.run_in_parallel,
        )
        for ref in refs
    ]


def resolve_output_guardrails(refs: List[GuardrailRef] | None) -> List[Any]:
    if not refs:
        return []
    from agents import OutputGuardrail  # lazy

    return [
        OutputGuardrail(
            guardrail_function=_load_callable(ref.module, ref.function),
            name=ref.name or ref.function,
        )
        for ref in refs
    ]


def _load_callable(module_path: str, function_name: str) -> Callable[..., Any]:
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Guardrail module {module_path!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"Guardrail {function_name!r} not found in module {module_path!r}"
        )
    if not callable(fn):
        raise TypeError(
            f"{module_path}.{function_name} is not callable"
        )
    return fn
