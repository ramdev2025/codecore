"""Built-in guard / optimizer / observer implementations for OAI.

Each helper returns one of the SDK primitives:

- ``InputGuardrail`` / ``OutputGuardrail`` — the SDK's first-class
  guardrail mechanism (tripwire-triggered). Used for **guards**.
- ``RunHooks`` subclass instance — lifecycle callbacks
  (``on_llm_start/end``, ``on_tool_start/end``, ``on_agent_start/end``,
  ``on_handoff``). Used for **observers** and counter-based guards.
- No return / side-effect on ``ModelSettings`` — the SDK handles
  prompt_caching and retry natively, so those **optimizers** just
  configure settings instead of emitting hooks.

OTel: when ``OTEL_TRACES_ENABLED=true`` (set up by ``oai.telemetry``),
observers emit spans using the ``gen_ai.*`` semantic conventions so
tools appear as their own spans in Jaeger / Tempo / Datadog / etc.
"""

from __future__ import annotations

import logging
import re
import time
from collections import defaultdict
from typing import Any, Callable, Dict, List, Optional


# ---------------------------------------------------------------------------
# Loggers — agentflow.oai.audit is the canonical tool-audit stream
# ---------------------------------------------------------------------------

_audit_log = logging.getLogger("agentflow.oai.audit")
_cost_log = logging.getLogger("agentflow.oai.cost")
_latency_log = logging.getLogger("agentflow.oai.latency")


def _tracer():
    from opentelemetry import trace

    return trace.get_tracer("agentflow.oai")


# ---------------------------------------------------------------------------
# GUARDS — SDK guardrails OR counter-based RunHooks
# ---------------------------------------------------------------------------


def make_pii_input_guardrail(patterns: Optional[List[str]] = None):
    """Return an ``InputGuardrail`` that trips when PII patterns match.

    Named patterns supported: ``email``, ``phone``, ``ssn``, ``credit_card``.
    Unknown names are treated as raw regex strings.

    The OAI SDK guardrail model is boolean (trip or not) — it does NOT
    modify the prompt. Users that want PII *redaction* should wire a
    custom ``module:`` / ``function:`` that modifies the input via an
    ``on_llm_start`` hook before the LLM call.
    """
    from agents import GuardrailFunctionOutput, InputGuardrail

    named = {
        "email": r"[\w\.-]+@[\w\.-]+",
        "phone": r"\b(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "credit_card": r"\b(?:\d[ -]*?){13,16}\b",
    }
    patterns = patterns or ["email", "phone", "ssn", "credit_card"]
    compiled = [re.compile(named.get(p, p)) for p in patterns]

    async def fn(context, agent, input_data):
        text = _coerce_text(input_data)
        matches = [p.pattern for p in compiled if p.search(text)]
        return GuardrailFunctionOutput(
            output_info={"matched_patterns": matches, "count": len(matches)},
            tripwire_triggered=bool(matches),
        )

    return InputGuardrail(guardrail_function=fn, name="pii")


def make_input_validation_guardrail(module: str, function: str):
    """Wrap a user-provided async validator as an ``InputGuardrail``."""
    from agents import InputGuardrail

    fn = _resolve_callable(module, function)
    return InputGuardrail(guardrail_function=fn, name=f"{module}.{function}")


def make_content_filter_output_guardrail(module: str, function: str):
    """Wrap a user-provided async content filter as an ``OutputGuardrail``."""
    from agents import OutputGuardrail

    fn = _resolve_callable(module, function)
    return OutputGuardrail(guardrail_function=fn, name=f"{module}.{function}")


def make_tool_call_limit_hook(max_calls: int = 50):
    """Return a ``RunHooks`` subclass that raises past ``max_calls``."""
    from agents import RunHooks

    class _ToolLimit(RunHooks):
        def __init__(self):
            self._n = 0

        async def on_tool_start(self, context, agent, tool):
            self._n += 1
            if self._n > max_calls:
                raise RuntimeError(
                    f"tool_call_limit reached ({max_calls}); agent stopped "
                    f"to prevent runaway execution"
                )

    return _ToolLimit()


def make_model_call_limit_hook(max_calls: int = 100):
    """Return a ``RunHooks`` subclass that raises past ``max_calls`` LLM calls."""
    from agents import RunHooks

    class _ModelLimit(RunHooks):
        def __init__(self):
            self._n = 0

        async def on_llm_start(self, context, agent, system_prompt, input_items):
            self._n += 1
            if self._n > max_calls:
                raise RuntimeError(
                    f"model_call_limit reached ({max_calls})"
                )

    return _ModelLimit()


# ---------------------------------------------------------------------------
# OPTIMIZERS — SDK ModelSettings + RunHooks logging
# ---------------------------------------------------------------------------


def make_tool_retry_hook(max_retries: int = 2):
    """Return a ``RunHooks`` subclass that logs tool failures.

    **Design note.** The OAI SDK does not expose a retry-on-failure hook —
    tool errors are surfaced via ``ToolCallOutput`` items with the error
    text. Retries are instead driven at the model layer via
    ``ModelSettings.retry`` (which the SDK handles natively). This hook
    only logs for visibility.
    """
    from agents import RunHooks

    counters: Dict[str, int] = defaultdict(int)

    class _ToolRetryLog(RunHooks):
        async def on_tool_end(self, context, agent, tool, result):
            if isinstance(result, str) and result.startswith("Error:"):
                name = getattr(tool, "name", "<unknown>")
                counters[name] += 1
                _audit_log.info(
                    "tool_error_observed tool=%s count=%d max_retries=%d",
                    name, counters[name], max_retries,
                )

    return _ToolRetryLog()


def make_summarization_hook(trigger_messages: int = 40, keep_messages: int = 10):
    """Return a ``RunHooks`` subclass that logs handoffs.

    **Design note.** The OAI SDK doesn't expose a pre-compaction hook. This
    optimizer logs handoffs — often where summarization matters most — so
    operators can correlate with context growth.
    """
    from agents import RunHooks

    class _SummarizationLog(RunHooks):
        async def on_handoff(self, context, from_agent, to_agent):
            _audit_log.info(
                "handoff from=%s to=%s trigger_messages=%d keep_messages=%d",
                getattr(from_agent, "name", "?"),
                getattr(to_agent, "name", "?"),
                trigger_messages,
                keep_messages,
            )

    return _SummarizationLog()


# ---------------------------------------------------------------------------
# OBSERVERS — RunHooks composite
# ---------------------------------------------------------------------------


def make_audit_log_hook():
    """Tool-level span + structured log, using ``gen_ai.*`` semconv."""
    from agents import RunHooks

    active_spans: Dict[int, Any] = {}

    class _AuditLog(RunHooks):
        async def on_tool_start(self, context, agent, tool):
            name = getattr(tool, "name", type(tool).__name__)
            _audit_log.info(
                "tool_use_start tool=%s agent=%s", name, getattr(agent, "name", "?")
            )
            try:
                span = _tracer().start_span(
                    f"gen_ai.execute_tool {name}",
                    attributes={
                        "gen_ai.operation.name": "execute_tool",
                        "gen_ai.tool.name": name,
                        "gen_ai.agent.name": getattr(agent, "name", "?"),
                    },
                )
                active_spans[id(tool)] = span
            except Exception:
                pass  # tracing must never break the agent

        async def on_tool_end(self, context, agent, tool, result):
            name = getattr(tool, "name", type(tool).__name__)
            _audit_log.info("tool_use_end tool=%s ok=True", name)
            span = active_spans.pop(id(tool), None)
            if span is not None:
                try:
                    span.set_attribute(
                        "gen_ai.tool.call.result", _truncate(result)
                    )
                    span.end()
                except Exception:
                    pass

    return _AuditLog()


def make_cost_tracking_hook(budget_limit: Optional[float] = None):
    """Agent-end hook emitting token usage + cost estimate span.

    **Design note.** The OAI SDK's ``ModelResponse`` carries
    ``Usage`` (``input_tokens``, ``output_tokens``, ``total_tokens``) on
    each LLM turn. The CLI driver accumulates these across turns and
    attaches them to the root ``agentflow.oai.run`` span. This hook
    additionally emits a per-agent ``gen_ai.agent_end`` span so
    multi-agent handoff costs are discoverable.
    """
    from agents import RunHooks

    usage_by_agent: Dict[str, Dict[str, int]] = defaultdict(
        lambda: {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    )

    class _CostTracking(RunHooks):
        async def on_llm_end(self, context, agent, response):
            usage = getattr(response, "usage", None)
            if usage is None:
                return
            name = getattr(agent, "name", "?")
            usage_by_agent[name]["input_tokens"] += getattr(usage, "input_tokens", 0) or 0
            usage_by_agent[name]["output_tokens"] += getattr(usage, "output_tokens", 0) or 0
            usage_by_agent[name]["total_tokens"] += getattr(usage, "total_tokens", 0) or 0

        async def on_agent_end(self, context, agent, output):
            name = getattr(agent, "name", "?")
            u = usage_by_agent.get(name, {})
            _cost_log.info(
                "agent_end agent=%s input_tokens=%d output_tokens=%d total=%d budget=%s",
                name,
                u.get("input_tokens", 0),
                u.get("output_tokens", 0),
                u.get("total_tokens", 0),
                budget_limit,
            )
            try:
                attrs: Dict[str, Any] = {
                    "gen_ai.operation.name": "agent_end",
                    "gen_ai.agent.name": name,
                    "gen_ai.usage.input_tokens": u.get("input_tokens", 0),
                    "gen_ai.usage.output_tokens": u.get("output_tokens", 0),
                    "gen_ai.usage.total_tokens": u.get("total_tokens", 0),
                }
                if budget_limit is not None:
                    attrs["agentflow.budget_usd"] = budget_limit
                with _tracer().start_as_current_span(
                    "gen_ai.agent_end", attributes=attrs
                ):
                    pass
            except Exception:
                pass

    return _CostTracking()


def make_latency_tracking_hook():
    """Per-tool latency hook + dedicated latency span."""
    from agents import RunHooks

    starts: Dict[int, float] = {}
    spans: Dict[int, Any] = {}

    class _LatencyTracking(RunHooks):
        async def on_tool_start(self, context, agent, tool):
            name = getattr(tool, "name", type(tool).__name__)
            starts[id(tool)] = time.perf_counter()
            try:
                span = _tracer().start_span(
                    f"agentflow.tool.latency {name}",
                    attributes={"gen_ai.tool.name": name},
                )
                spans[id(tool)] = span
            except Exception:
                pass

        async def on_tool_end(self, context, agent, tool, result):
            started = starts.pop(id(tool), None)
            name = getattr(tool, "name", type(tool).__name__)
            elapsed_ms = (time.perf_counter() - started) * 1000 if started else None
            if elapsed_ms is not None:
                _latency_log.info(
                    "tool_latency tool=%s elapsed_ms=%.2f", name, elapsed_ms
                )
            span = spans.pop(id(tool), None)
            if span is not None:
                try:
                    if elapsed_ms is not None:
                        span.set_attribute(
                            "agentflow.tool.latency_ms", elapsed_ms
                        )
                    span.end()
                except Exception:
                    pass

    return _LatencyTracking()


# ---------------------------------------------------------------------------
# Composite RunHooks — Runner.run() takes ONE hooks instance
# ---------------------------------------------------------------------------


def compose_hooks(hooks_list: List[Any]) -> Any:
    """Fan out every lifecycle callback to all hook instances.

    ``Runner.run(hooks=...)`` accepts a single ``RunHooks``. When multiple
    observers are configured (audit + latency + cost), we wrap them in a
    composite that dispatches each event to every hook in order.
    Exceptions are logged and swallowed so one broken hook can't break the
    agent.
    """
    from agents import RunHooks

    if not hooks_list:
        return None
    if len(hooks_list) == 1:
        return hooks_list[0]

    class _Composite(RunHooks):
        async def on_agent_start(self, context, agent):
            for h in hooks_list:
                await _safe_call(h, "on_agent_start", context, agent)

        async def on_agent_end(self, context, agent, output):
            for h in hooks_list:
                await _safe_call(h, "on_agent_end", context, agent, output)

        async def on_llm_start(self, context, agent, system_prompt, input_items):
            for h in hooks_list:
                await _safe_call(
                    h, "on_llm_start", context, agent, system_prompt, input_items
                )

        async def on_llm_end(self, context, agent, response):
            for h in hooks_list:
                await _safe_call(h, "on_llm_end", context, agent, response)

        async def on_tool_start(self, context, agent, tool):
            for h in hooks_list:
                await _safe_call(h, "on_tool_start", context, agent, tool)

        async def on_tool_end(self, context, agent, tool, result):
            for h in hooks_list:
                await _safe_call(h, "on_tool_end", context, agent, tool, result)

        async def on_handoff(self, context, from_agent, to_agent):
            for h in hooks_list:
                await _safe_call(h, "on_handoff", context, from_agent, to_agent)

    return _Composite()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _safe_call(hook: Any, method_name: str, *args: Any) -> None:
    """Invoke ``hook.method(*args)`` swallowing only non-fatal errors.

    Guards that stop the run (``tool_call_limit``, ``model_call_limit``,
    user-provided custom guards) must raise so the SDK aborts the run —
    otherwise the agent keeps looping past the cap. We distinguish by
    *intent* via a marker attribute (``_agentflow_propagate = True``),
    falling back to exception type: ``RuntimeError`` / ``ValueError`` are
    treated as deliberate stops, ``AttributeError`` / ``TypeError`` as
    bugs in the hook itself.
    """
    method = getattr(hook, method_name, None)
    if method is None:
        return
    try:
        await method(*args)
    except (RuntimeError, ValueError):
        # Intentional hard-stop — bubble up so Runner aborts.
        raise
    except Exception as exc:
        if getattr(hook, "_agentflow_propagate", False):
            raise
        logging.getLogger("agentflow.oai").warning(
            "hook %s.%s raised; swallowed: %s",
            type(hook).__name__, method_name, exc,
        )


def _coerce_text(input_data: Any) -> str:
    """Flatten SDK guardrail input (str | list[TResponseInputItem]) to text."""
    if isinstance(input_data, str):
        return input_data
    if isinstance(input_data, list):
        parts: List[str] = []
        for item in input_data:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                content = item.get("content")
                if isinstance(content, str):
                    parts.append(content)
                elif isinstance(content, list):
                    for c in content:
                        if isinstance(c, dict):
                            t = c.get("text")
                            if isinstance(t, str):
                                parts.append(t)
        return "\n".join(parts)
    return repr(input_data)


def _truncate(value: Any, max_len: int = 2000) -> str:
    s = repr(value) if not isinstance(value, str) else value
    return s if len(s) <= max_len else s[: max_len - 12] + "...[trunc]"


def _resolve_callable(module: str, function: str) -> Callable[..., Any]:
    import importlib

    try:
        mod = importlib.import_module(module)
    except ImportError as exc:
        raise ImportError(
            f"Filter module {module!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function, None)
    if fn is None:
        raise AttributeError(
            f"Filter function {function!r} not found in module {module!r}"
        )
    return fn
