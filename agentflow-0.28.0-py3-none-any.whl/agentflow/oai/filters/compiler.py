"""Compile cross-backend guards/optimizers/observers into OAI-native primitives.

The cross-backend schema (``guards:`` / ``optimizers:`` / ``observers:``) is
identical across SK, CAS, and OAI so YAML migrates mechanically. In OAI
each entry compiles to:

- ``guardrails`` — a list of ``InputGuardrail`` / ``OutputGuardrail``
  instances (for ``Agent.input_guardrails`` / ``Agent.output_guardrails``
  or ``RunConfig.*_guardrails``).
- ``hooks`` — a list of ``RunHooks`` instances. The caller composes them
  into one ``RunHooks`` (the SDK accepts a single hooks object per
  ``Runner.run()``) via ``builtin.compose_hooks``.
- ``model_settings_patch`` — dict of ``ModelSettings`` fields the optimizer
  wants set natively (e.g. ``prompt_cache_retention='24h'``). The builder
  merges this into the top-level ``ModelSettings``.
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from agentflow.oai.core.config_models import (
    GuardConfig,
    GuardType,
    ObserverConfig,
    ObserverType,
    OptimizerConfig,
    OptimizerType,
)
from agentflow.oai.filters import builtin


@dataclass
class CompiledFilters:
    """Bundle of OAI-native primitives produced by the compiler."""

    input_guardrails: List[Any] = field(default_factory=list)
    output_guardrails: List[Any] = field(default_factory=list)
    hooks: List[Any] = field(default_factory=list)
    model_settings_patch: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------


def compile_guards(
    guards: Optional[List[GuardConfig]], out: CompiledFilters
) -> None:
    if not guards:
        return
    for g in guards:
        cfg = g.config or {}
        if g.module and g.function:
            # Custom guard — type decides which list receives it
            if g.type in (GuardType.CONTENT_FILTER,):
                out.output_guardrails.append(
                    builtin.make_content_filter_output_guardrail(g.module, g.function)
                )
            else:
                out.input_guardrails.append(
                    builtin.make_input_validation_guardrail(g.module, g.function)
                )
            continue

        if g.type == GuardType.PII:
            out.input_guardrails.append(
                builtin.make_pii_input_guardrail(cfg.get("patterns"))
            )
        elif g.type == GuardType.TOOL_CALL_LIMIT:
            out.hooks.append(
                builtin.make_tool_call_limit_hook(
                    max_calls=cfg.get("max_calls", 50)
                )
            )
        elif g.type == GuardType.MODEL_CALL_LIMIT:
            out.hooks.append(
                builtin.make_model_call_limit_hook(
                    max_calls=cfg.get("max_calls", 100)
                )
            )
        elif g.type in (GuardType.INPUT_VALIDATION, GuardType.CONTENT_FILTER):
            raise ValueError(
                f"Guard type {g.type.value!r} requires a custom "
                f"`module:` + `function:` implementation."
            )
        else:  # pragma: no cover — schema enforces enum
            raise ValueError(f"Unknown guard type: {g.type!r}")


# ---------------------------------------------------------------------------
# Optimizers
# ---------------------------------------------------------------------------


def compile_optimizers(
    optimizers: Optional[List[OptimizerConfig]], out: CompiledFilters
) -> None:
    if not optimizers:
        return
    for o in optimizers:
        cfg = o.config or {}
        if o.module and o.function:
            # Custom optimizers register as hooks via the user-provided callable
            fn = _resolve_callable(o.module, o.function)
            out.hooks.append(_wrap_custom_hook(fn))
            continue

        if o.type == OptimizerType.TOOL_RETRY:
            # ModelSettings.retry is the SDK-native retry mechanism.
            out.model_settings_patch["retry"] = {
                "max_retries": cfg.get("max_retries", 2),
                "backoff": cfg.get("backoff"),
            }
            out.hooks.append(
                builtin.make_tool_retry_hook(max_retries=cfg.get("max_retries", 2))
            )
        elif o.type == OptimizerType.SUMMARIZATION:
            out.hooks.append(
                builtin.make_summarization_hook(
                    trigger_messages=cfg.get("trigger_messages", 40),
                    keep_messages=cfg.get("keep_messages", 10),
                )
            )
        elif o.type == OptimizerType.PROMPT_CACHING:
            # SDK-native via ModelSettings; no hook needed.
            out.model_settings_patch["prompt_cache_retention"] = cfg.get(
                "retention", "in_memory"
            )
        else:  # pragma: no cover — schema enforces enum
            raise ValueError(f"Unknown optimizer type: {o.type!r}")


# ---------------------------------------------------------------------------
# Observers
# ---------------------------------------------------------------------------


def compile_observers(
    observers: Optional[List[ObserverConfig]], out: CompiledFilters
) -> None:
    if not observers:
        return
    for obs in observers:
        cfg = obs.config or {}
        if obs.module and obs.function:
            fn = _resolve_callable(obs.module, obs.function)
            out.hooks.append(_wrap_custom_hook(fn))
            continue

        if obs.type == ObserverType.AUDIT_LOG:
            out.hooks.append(builtin.make_audit_log_hook())
        elif obs.type == ObserverType.COST_TRACKING:
            out.hooks.append(
                builtin.make_cost_tracking_hook(
                    budget_limit=cfg.get("budget_limit")
                )
            )
        elif obs.type == ObserverType.LATENCY_TRACKING:
            out.hooks.append(builtin.make_latency_tracking_hook())
        else:  # pragma: no cover — schema enforces enum
            raise ValueError(f"Unknown observer type: {obs.type!r}")


# ---------------------------------------------------------------------------
# Top-level entry point
# ---------------------------------------------------------------------------


def compile_filters(
    guards: Optional[List[GuardConfig]] = None,
    optimizers: Optional[List[OptimizerConfig]] = None,
    observers: Optional[List[ObserverConfig]] = None,
) -> CompiledFilters:
    """Run all three compilation passes and return the merged bundle."""
    out = CompiledFilters()
    compile_guards(guards, out)
    compile_optimizers(optimizers, out)
    compile_observers(observers, out)
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_callable(module_path: str, function_name: str) -> Callable[..., Any]:
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Filter module {module_path!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"Filter function {function_name!r} not found in module {module_path!r}"
        )
    return fn


def _wrap_custom_hook(fn: Callable[..., Any]) -> Any:
    """Wrap a user callable as a ``RunHooks.on_tool_end`` subclass.

    Users provide a function with signature ``fn(tool_name, result)`` (or
    any superset). We invoke it from ``on_tool_end`` and swallow any
    exceptions so the agent keeps running.
    """
    from agents import RunHooks

    class _CustomHook(RunHooks):
        async def on_tool_end(self, context, agent, tool, result):
            try:
                name = getattr(tool, "name", type(tool).__name__)
                import asyncio
                maybe = fn(name, result)
                if asyncio.iscoroutine(maybe):
                    await maybe
            except Exception:
                pass

    return _CustomHook()
