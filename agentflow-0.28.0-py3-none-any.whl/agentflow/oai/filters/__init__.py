"""Cross-backend portable filter tier for the OAI backend.

``guards:`` / ``optimizers:`` / ``observers:`` declared in YAML compile
down to SDK-native primitives here:

- guards   → InputGuardrail / OutputGuardrail (or a RunHooks subclass for
             counter-based limits)
- observers → RunHooks composite emitting OTel spans
- optimizers → ModelSettings tweaks + RunHooks logging

The enum vocabulary matches SK and CAS so YAML migrates mechanically.
"""
