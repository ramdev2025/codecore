"""OAI adapter for the cross-backend ``ui_tools`` vocabulary.

The OpenAI Agents SDK uses the ``@function_tool`` decorator (from the
``agents`` package) to convert Python functions into ``FunctionTool``
instances. The decorator handles signature introspection and JSON Schema
generation for the LLM's function-calling interface.

Each ``@ui_component`` fetcher gets wrapped: a thin shim that validates
the return against the declared Pydantic class and emits JSON, then
the wrapper is decorated with ``@function_tool``. The resulting
``FunctionTool`` carries ``_agentflow_component_name`` for build-time
predicate gating.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
import logging
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from agentflow.genui import (
    UIToolsConfig,
    discover_ui_components,
    get_component_class,
)

logger = logging.getLogger(__name__)


def resolve_ui_tools(config: UIToolsConfig | None) -> list[Any]:
    """Build a list of OAI ``FunctionTool`` instances from a ``UIToolsConfig``.

    Returns an empty list when ``config`` is ``None``.

    Args:
        config: The parsed ``ui_tools:`` YAML block.

    Returns:
        List of ``FunctionTool`` objects ready for
        ``Agent(tools=[...])``.

    Raises:
        ImportError: If the ``agents`` SDK isn't installed.
        ValueError: If ``config.use`` names an unknown component.
    """
    if config is None:
        return []

    try:
        from agents import function_tool  # noqa: F401  (verifies install)
    except ImportError as exc:  # pragma: no cover — covered by import-error test
        raise ImportError(
            "openai-agents is required to resolve ui_tools on the OAI backend. "
            "Install via `pip install agentflow[openai-agents]`."
        ) from exc

    discovered = discover_ui_components(config.module)
    if config.use is not None:
        missing = sorted(set(config.use) - set(discovered.keys()))
        if missing:
            available = sorted(discovered.keys())
            raise ValueError(
                f"ui_tools.use names component(s) not found in "
                f"{config.module!r}: {missing}. Available: {available}"
            )
        discovered = {n: discovered[n] for n in config.use}

    return [_wrap_for_oai(name, fetcher) for name, fetcher in discovered.items()]


def _wrap_for_oai(component_name: str, fetcher: Callable[..., Any]) -> Any:
    """Wrap a ``@ui_component`` fetcher as an OAI ``FunctionTool``.

    The wrapper preserves the fetcher's signature so the SDK can
    introspect parameters for the LLM's function-calling schema,
    validates the return against the Pydantic class, and returns a
    JSON string consumable as the function result.
    """
    component_cls = get_component_class(fetcher)
    if component_cls is None:  # pragma: no cover — discover_ui_components guards
        raise RuntimeError(f"{fetcher} is not @ui_component-decorated")

    from agents import function_tool

    is_async = asyncio.iscoroutinefunction(fetcher)

    if is_async:

        @functools.wraps(fetcher)
        async def async_wrapper(*args: Any, **kwargs: Any) -> str:
            result = await fetcher(*args, **kwargs)
            return _to_tool_result(component_name, component_cls, result)

        async_wrapper.__signature__ = inspect.signature(fetcher)  # type: ignore[attr-defined]
        ft = function_tool(async_wrapper)
        ft._agentflow_component_name = component_name  # type: ignore[attr-defined]
        return ft

    @functools.wraps(fetcher)
    def sync_wrapper(*args: Any, **kwargs: Any) -> str:
        result = fetcher(*args, **kwargs)
        return _to_tool_result(component_name, component_cls, result)

    sync_wrapper.__signature__ = inspect.signature(fetcher)  # type: ignore[attr-defined]
    ft = function_tool(sync_wrapper)
    ft._agentflow_component_name = component_name  # type: ignore[attr-defined]
    return ft


def _to_tool_result(
    component_name: str,
    component_cls: type[BaseModel],
    result: Any,
) -> str:
    """Validate and serialize a fetcher's return for OAI consumption."""
    if isinstance(result, component_cls):
        instance = result
    elif isinstance(result, dict):
        try:
            instance = component_cls.model_validate(result)
        except Exception as exc:
            return f"[{component_name} failed] dict didn't validate: {exc}"
    else:
        return (
            f"[{component_name} failed] fetcher must return a {component_name} "
            f"instance or a dict, got {type(result).__name__}"
        )

    payload = {"__component__": component_name, **instance.model_dump()}
    return json.dumps(payload)
