"""AG-UI bridge for the OAI (OpenAI Agents SDK) backend.

Brings the AG-UI HTTP+SSE protocol to YAML-driven OpenAI Agents SDK
agents. No published upstream AG-UI package exists for the
openai-agents SDK, so AgentFlow carries the full implementation:

  * :mod:`events` — Pydantic wire models for AG-UI events
  * :mod:`adapter` — stateful event translator from orchestrator
    events to AG-UI wire events
  * :mod:`client_tools` — ``ClientToolPause``-raising
    ``@function_tool`` stubs registered on the agent's tools list
  * :mod:`router` — FastAPI router + ``build_agui`` public entrypoint

The public entrypoint is :func:`build_agui`. Mount the returned
``(router, lifespan)`` into your own FastAPI app::

    from fastapi import FastAPI
    from agentflow.oai.agui import build_agui

    router, lifespan = build_agui(yaml_path="agent.yaml")
    app = FastAPI(lifespan=lifespan)
    app.include_router(router, prefix="/agui")

What OAI gets vs the LangGraph-based bridges
--------------------------------------------

  * ``ui_tools`` ✓ — same cross-backend YAML, ``@ui_component``
    fetchers become ``FunctionTool`` instances on the agent.
  * Token-level text streaming ✓ — translated from
    ``RawResponsesStreamEvent`` deltas.
  * Tool call lifecycle ✓ — translated from
    ``RunItemStreamEvent`` with ``name=tool_called`` /
    ``name=tool_output``.
  * ``client_tools`` ✓ — exception-based pause via
    ``ClientToolPause`` raised inside a ``@function_tool`` body,
    caught at the orchestrator layer and re-surfaced as an AG-UI
    Interrupt.
  * ``available_when`` (build-time only — OAI's SDK doesn't expose
    a clean per-call hide-from-list hook).
  * State persistence: in-memory only (OAI has no checkpointer).
"""

from .adapter import AGUIAdapter, translate_stream
from .client_tools import (
    ClientToolPause,
    build_client_tool_function_tools,
)
from .events import (
    AGUIEvent,
    CustomEvent,
    EventType,
    Interrupt,
    InterruptOutcome,
    RunError,
    RunFinished,
    RunStarted,
    StateDelta,
    StateSnapshot,
    TextMessageContent,
    TextMessageEnd,
    TextMessageStart,
    ToolCallArgs,
    ToolCallEnd,
    ToolCallResult,
    ToolCallStart,
    render_component,
)
from .router import build_agui

__all__ = [
    "AGUIAdapter",
    "AGUIEvent",
    "ClientToolPause",
    "CustomEvent",
    "EventType",
    "Interrupt",
    "InterruptOutcome",
    "RunError",
    "RunFinished",
    "RunStarted",
    "StateDelta",
    "StateSnapshot",
    "TextMessageContent",
    "TextMessageEnd",
    "TextMessageStart",
    "ToolCallArgs",
    "ToolCallEnd",
    "ToolCallResult",
    "ToolCallStart",
    "build_agui",
    "build_client_tool_function_tools",
    "render_component",
    "translate_stream",
]
