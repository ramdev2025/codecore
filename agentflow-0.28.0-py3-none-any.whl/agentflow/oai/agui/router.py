"""FastAPI router + lifespan exposing AG-UI over HTTP+SSE, WebSocket, and
schema export.

AgentFlow provides the router and the lifespan; you bring the server.
Mount both into your own FastAPI app:

    from fastapi import FastAPI
    from agentflow.oai.agui import build_agui

    router, lifespan = build_agui(yaml_path="agent.yaml")
    app = FastAPI(lifespan=lifespan)
    app.include_router(router, prefix="/agui")

Endpoints (relative to the mount prefix):

    POST  /                  — AG-UI HTTP+SSE transport. Body is a
                               ``RunAgentInput`` (threadId, runId, messages,
                               ...); response is ``text/event-stream`` with
                               one AG-UI event per SSE ``data:`` frame.
                               This is what CopilotKit's ``HttpAgent`` and
                               any AG-UI-compatible client speaks.
    WS    /{thread_id}       — Convenience WebSocket. Client frames are
                               ``{type: 'user_message', content: str}``;
                               server frames are AG-UI events as JSON.
    GET   /components        — JSON Schema for every component exposed by the
                               agent's ui_tools (frontends use this to
                               discover renderable props).
    GET   /info              — CopilotKit-compatible runtime info ping.
    GET   /health            — liveness probe.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from typing import Any

from fastapi import APIRouter, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from langgraph.errors import GraphInterrupt
from langgraph.types import Command
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from agentflow.genui import discover_ui_components, get_component_class

from .adapter import AGUIAdapter, translate_stream

logger = logging.getLogger(__name__)

# Module-level tracer. Resolves to a no-op when no OTel provider is
# configured (which is the case when AGENTFLOW's OTEL_TRACES_ENABLED is
# unset), so wrapping every request in a span is safe by default.
_tracer = trace.get_tracer(__name__)


def build_agui(
    yaml_path: str,
) -> tuple[APIRouter, Callable[[FastAPI], AbstractAsyncContextManager[None]]]:
    """Build the AG-UI router and matching lifespan for a OAI agent YAML.

    Returns a ``(router, lifespan)`` pair. Wire both into your FastAPI app:

        router, lifespan = build_agui(yaml_path="agent.yaml")
        app = FastAPI(lifespan=lifespan)
        app.include_router(router, prefix="/agui")

    The lifespan brings the orchestrator up at app startup and tears it
    down on shutdown. Endpoints will raise ``RuntimeError`` if called
    before the lifespan has run — this is intentional, so a deployment
    that forgets to pass ``lifespan=lifespan`` to ``FastAPI(...)`` fails
    loudly instead of silently leaking orchestrator state.

    Args:
        yaml_path: Path to a deepagent.yaml declaring the agent and
            optionally ``agent.ui_tools`` / ``agent.client_tools``. Tool
            references are resolved from the YAML's ``tools.custom``
            block (no separate ``tools_module`` parameter — deep loads
            custom tools by qualified Python path declared in YAML).
    """
    state = _RouterState(yaml_path=yaml_path)
    router = APIRouter()

    @router.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @router.get("/info")
    async def info() -> dict[str, Any]:
        """CopilotKit-compatible runtime info.

        Returns the minimum shape CopilotKit Core expects: empty ``agents``
        (the frontend supplies its own agent via ``selfManagedAgents``), SSE
        transport mode, and telemetry disabled. Letting this 200 with valid
        JSON prevents the "runtime_info_fetch_failed" / "Unexpected token
        '<'" toast that fires when the auto-discovery ping is unanswered.
        """
        return {
            "version": "agentflow-agui-alpha",
            "agents": {},
            "mode": "sse",
            "audioFileTranscriptionEnabled": False,
            "a2uiEnabled": False,
            "openGenerativeUIEnabled": False,
            "telemetryDisabled": True,
        }

    @router.get("/components")
    async def components() -> dict[str, Any]:
        """Schema export — the frontend uses this to discover renderable props.

        Returns ``{component_name: pydantic_json_schema}`` for every
        ``@ui_component`` exposed by the agent's ``ui_tools.module``.
        """
        state.assert_started()
        ui_tools = state.ui_tools_config
        if ui_tools is None:
            return {}
        discovered = discover_ui_components(ui_tools.module)
        if ui_tools.use is not None:
            discovered = {n: discovered[n] for n in ui_tools.use if n in discovered}
        return {
            name: cls.model_json_schema()
            for name, fn in discovered.items()
            if (cls := get_component_class(fn)) is not None
        }

    @router.post("/")
    async def run_http(payload: dict[str, Any]) -> StreamingResponse:
        """AG-UI HTTP+SSE transport.

        Body is a ``RunAgentInput`` per the AG-UI spec — at minimum
        ``threadId``, ``runId``, ``messages: [{role, content, ...}]``.
        Response is ``text/event-stream`` with one AG-UI event per SSE
        ``data:`` frame.

        Accepts both camelCase (``threadId``) and snake_case (``thread_id``)
        keys to play nicely with CopilotKit (camelCase) and plain HTTP
        clients (either).
        """
        state.assert_started()

        thread_id = payload.get("threadId") or payload.get("thread_id") or _new_thread_id()
        run_id = payload.get("runId") or payload.get("run_id")

        # Three mutually exclusive resume / fresh-turn paths:
        #   1. ``resume[]`` — HITL approval (item 5). Each entry carries a
        #      decision: approve / reject / modify / cancelled.
        #   2. ``messages[role:"tool", ...]`` — client-tool result (item 7).
        #      The browser-side handler ran the tool and is delivering its
        #      output back to the agent's paused interrupt() call.
        #   3. Plain ``messages`` / ``message`` — fresh user turn.
        resume_raw = payload.get("resume")
        messages = payload.get("messages") or []
        client_tool_result = _last_tool_message_content(messages)
        resume_command: Command | None = None
        message: str | None = None

        if resume_raw and client_tool_result is not None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Body carries both 'resume[]' (HITL) and a role:tool message "
                    "(client-tool result). These are different resume paths and "
                    "must not be combined in one request."
                ),
            )

        if resume_raw:
            resume_command = Command(resume={"decisions": _resume_to_decisions(resume_raw)})
        elif client_tool_result is not None:
            resume_command = await state.build_resume_for_tool_message(
                thread_id=thread_id, content=client_tool_result
            )
        else:
            message = _last_user_message(messages) if messages else payload.get("message")
            if not message:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "No input. Provide 'messages' (AG-UI), a top-level "
                        "'message' string, 'resume' to continue a HITL pause, "
                        "or a role:tool message to deliver a client-tool result."
                    ),
                )

        kind = (
            "resume[]" if resume_raw
            else "client_tool_result" if client_tool_result is not None
            else "user_message"
        )
        logger.info(
            "AG-UI POST thread=%s run=%s kind=%s messages=%d",
            thread_id, run_id, kind, len(messages or []),
        )

        async def sse_stream():
            # Wrap the whole streaming response in an ``agui.run`` OTel
            # span. LangChain's auto-emitted ``chat`` / ``execute_tool``
            # spans inside ``orchestrator.run`` nest under it via
            # contextvars, so a single trace covers the full turn — POST
            # → LLM calls → tool calls → SSE emission. The tracer is a
            # no-op when no OTel provider is configured, so the wrap is
            # always safe.
            with _tracer.start_as_current_span(
                "agui.run",
                attributes={
                    "agui.thread_id": thread_id,
                    "agui.run_id": run_id or "",
                    "agui.kind": kind,
                    "agui.messages_count": len(messages or []),
                },
            ) as span:
                event_count = 0
                try:
                    async for ag_event in state.run(
                        thread_id=thread_id,
                        message=message,
                        run_id=run_id,
                        resume_command=resume_command,
                    ):
                        event_count += 1
                        logger.debug(
                            "AG-UI emit thread=%s #%d type=%s",
                            thread_id, event_count, ag_event.type,
                        )
                        yield f"data: {json.dumps(ag_event.to_wire())}\n\n"
                except Exception as exc:  # noqa: BLE001 — recorded + re-raised
                    span.record_exception(exc)
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                    raise
                finally:
                    span.set_attribute("agui.events_emitted", event_count)
                    logger.info(
                        "AG-UI POST thread=%s done, %d events emitted",
                        thread_id, event_count,
                    )

        return StreamingResponse(
            sse_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",  # disable proxy buffering for streaming
            },
        )

    @router.websocket("/{thread_id}")
    async def ws(websocket: WebSocket, thread_id: str) -> None:
        """Bidirectional AG-UI WebSocket.

        Client → server frames:  ``{"type": "user_message", "content": str}``
        Server → client frames:  one AG-UI event per frame (JSON).
        """
        state.assert_started()
        await websocket.accept()
        try:
            while True:
                raw = await websocket.receive_text()
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "RUN_ERROR",
                                "message": "Invalid JSON frame.",
                                "code": "BadFrame",
                            }
                        )
                    )
                    continue

                content = msg.get("content")
                if msg.get("type") != "user_message" or not content:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "RUN_ERROR",
                                "message": "Expected {type: 'user_message', content: str}.",
                                "code": "BadFrame",
                            }
                        )
                    )
                    continue

                async for ag_event in state.run(thread_id=thread_id, message=content):
                    await websocket.send_text(json.dumps(ag_event.to_wire()))
        except WebSocketDisconnect:
            logger.info("AG-UI WebSocket disconnect: thread=%s", thread_id)
        except Exception as exc:  # noqa: BLE001 — final-defense logging
            logger.exception("AG-UI WebSocket fatal: thread=%s", thread_id)
            try:
                await websocket.send_text(
                    json.dumps(
                        {
                            "type": "RUN_ERROR",
                            "message": str(exc),
                            "code": type(exc).__name__,
                        }
                    )
                )
            except Exception:
                pass

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        await state.start()
        try:
            yield
        finally:
            await state.stop()

    return router, lifespan


def _new_thread_id() -> str:
    import uuid

    return f"thread_{uuid.uuid4().hex[:12]}"


def _strip_messages(values: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of the graph-state dict without the ``messages`` field.

    Messages flow over the wire as TEXT_MESSAGE_* / TOOL_CALL_* events
    already; we drop them from STATE_SNAPSHOT to avoid duplicating them
    (and to keep snapshots small for CopilotKit's ``useCoAgentState``,
    which expects application state, not chat history).
    """
    return {k: v for k, v in values.items() if k != "messages"}


def _resume_to_decisions(resume: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Translate AG-UI ``resume[]`` entries into LangChain HITL ``decisions``.

    AG-UI carries each resume entry as ``{interruptId, status, payload?}``
    where ``status`` is ``"resolved"`` or ``"cancelled"``. LangChain's
    ``HumanInTheLoopMiddleware`` expects a list of Decision dicts whose
    ``type`` is one of ``approve | edit | reject | respond`` plus
    type-specific extras (``message`` for reject/respond, ``edited_action``
    for edit).

    We forward the payload verbatim so each decision shape works without
    a code change here — only enforcing:
      * Cancelled resumes become ``{type: "reject", message: "User cancelled."}``
      * ``type`` defaults to ``"approve"`` when missing

    The ``interruptId`` field is intentionally not forwarded — LangChain's
    middleware resumes by position, and AG-UI guarantees resume entries
    appear in the same order as the interrupts they answer.
    """
    decisions: list[dict[str, Any]] = []
    for entry in resume:
        if entry.get("status") == "cancelled":
            decisions.append({"type": "reject", "message": "User cancelled."})
            continue
        payload = entry.get("payload") or {}
        decision: dict[str, Any] = dict(payload)
        decision.setdefault("type", "approve")
        decisions.append(decision)
    return decisions


def _has_pending_interrupts(snapshot: dict[str, Any]) -> bool:
    """True if the langgraph state snapshot has any pending interrupt.

    Used to detect the "thread is silently paused" hazard: if a previous
    pause never got resolved (e.g. the frontend missed the interrupt
    outcome) and the user now sends a fresh message, LangGraph won't
    advance — it can't. The bridge re-surfaces the pending interrupt so
    the user gets another chance to answer it.
    """
    for task in (snapshot or {}).get("tasks") or []:
        if getattr(task, "interrupts", None):
            return True
    return False


def _extract_interrupts(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    """Walk a langgraph state snapshot for pending interrupt payloads.

    Returns dicts in the shape the adapter's ``_on_interrupt`` handler
    expects: ``{id, reason, message?, tool_name?, response_schema?,
    metadata?}``.

    Two payload shapes are recognized:

    1. **LangChain ``HumanInTheLoopMiddleware``** emits a ``HITLRequest``
       (``{action_requests: [{name, args, description}], review_configs:
       [{action_name, allowed_decisions, args_schema?}]}``). Each
       ``ActionRequest`` becomes one Interrupt with ``reason: "tool_call"``,
       ``tool_name = action.name`` (so the deferred tool-call lifecycle
       binds), the description as ``message``, and the matching review
       config's ``allowed_decisions`` as the ``response_schema``.

    2. **Ad-hoc dicts** (the AG-UI ``client_tools`` stubs use
       ``{"type": "agentflow:client_tool", "tool_name": ..., "args": ...}``;
       custom code may use other keys). We extract a small set of known
       keys (``type``, ``question``, ``message``, ``tool_name``,
       ``allowed_decisions``) and pass the rest through as ``metadata``.
    """
    import uuid

    known_adhoc = {"type", "question", "message", "tool_name", "allowed_decisions"}
    result: list[dict[str, Any]] = []
    for task in snapshot.get("tasks") or []:
        interrupts = getattr(task, "interrupts", None) or []
        for intr in interrupts:
            raw = getattr(intr, "value", None)
            interrupt_id = getattr(intr, "id", None) or f"int_{uuid.uuid4().hex[:12]}"

            if (
                isinstance(raw, dict)
                and "action_requests" in raw
                and "review_configs" in raw
            ):
                # LangChain HITLRequest — one Interrupt per ActionRequest.
                actions = raw.get("action_requests") or []
                reviews = raw.get("review_configs") or []
                review_by_name = {
                    rc.get("action_name"): rc
                    for rc in reviews
                    if isinstance(rc, dict) and rc.get("action_name")
                }
                for i, action in enumerate(actions):
                    if not isinstance(action, dict):
                        continue
                    tool_name = action.get("name")
                    review = review_by_name.get(tool_name) or (
                        reviews[i] if i < len(reviews) and isinstance(reviews[i], dict) else {}
                    )
                    entry: dict[str, Any] = {
                        "id": f"{interrupt_id}-{i}" if len(actions) > 1 else interrupt_id,
                        "reason": "tool_call",
                        "message": action.get("description"),
                    }
                    if tool_name:
                        entry["tool_name"] = tool_name
                    if review.get("allowed_decisions"):
                        entry["response_schema"] = {"enum": list(review["allowed_decisions"])}
                    if action.get("args") is not None:
                        entry["metadata"] = {"args": action["args"]}
                    if review.get("args_schema"):
                        entry.setdefault("metadata", {})["args_schema"] = review["args_schema"]
                    result.append(entry)
                continue

            # Ad-hoc / client_tool stub payload — be lenient.
            raw_dict = raw if isinstance(raw, dict) else {}
            entry = {
                "id": interrupt_id,
                "reason": raw_dict.get("type") or "confirmation",
                "message": raw_dict.get("question") or raw_dict.get("message"),
            }
            if "tool_name" in raw_dict:
                entry["tool_name"] = raw_dict["tool_name"]
            if "allowed_decisions" in raw_dict:
                entry["response_schema"] = {"enum": list(raw_dict["allowed_decisions"])}
            extra = {k: v for k, v in raw_dict.items() if k not in known_adhoc}
            if extra:
                entry["metadata"] = extra
            result.append(entry)
    return result


def _last_tool_message_content(messages: list) -> str | None:
    """Return the content if (and only if) the **last** message is ``role: "tool"``.

    AG-UI's contract for delivering a client-tool result is a tool-role
    message tacked onto the end of ``RunAgentInput.messages`` — the new
    item the client is *adding* this turn. We must NOT match historical
    tool messages from earlier turns: CopilotKit (and any well-behaved
    client) replays the whole chat transcript on every POST, so
    historical tool calls are always somewhere in ``messages``. Treating
    those as client-tool resumes would make every follow-up turn try to
    resume a non-existent pause and the orchestrator would fail to
    accept the new user input.

    The rule: only the trailing message can carry a fresh client-tool
    result. A trailing user message means a fresh turn; a trailing tool
    message means the client just executed a tool and is handing the
    result back.
    """
    if not messages:
        return None
    last = messages[-1] if isinstance(messages, list) else None
    if not isinstance(last, dict) or last.get("role") != "tool":
        return None
    content = last.get("content")
    return content if isinstance(content, str) else None


def _last_user_message(messages: list) -> str | None:
    """Pull the last user-role message content out of an AG-UI RunAgentInput.

    AG-UI messages are a discriminated union by role; we only need the
    latest user turn since the orchestrator keeps full thread history via
    the LangGraph checkpointer.
    """
    for msg in reversed(messages or []):
        if not isinstance(msg, dict):
            continue
        if msg.get("role") == "user":
            content = msg.get("content")
            if isinstance(content, str) and content:
                return content
    return None


class _RouterState:
    """Shared orchestrator state between the AG-UI router and its lifespan.

    Brought up by :meth:`start` (called from the lifespan on app startup)
    and torn down by :meth:`stop` (called on app shutdown). Endpoints use
    :meth:`assert_started` to fail fast if the lifespan was never wired.
    """

    def __init__(self, yaml_path: str) -> None:
        self.yaml_path = yaml_path
        self._orchestrator = None
        self._ui_tools_config = None
        self._started = False

    @property
    def ui_tools_config(self):
        return self._ui_tools_config

    def assert_started(self) -> None:
        if not self._started:
            raise RuntimeError(
                "AG-UI router used before its lifespan started. Pass the "
                "lifespan returned by build_agui(...) to FastAPI(lifespan=...) "
                "before mounting the router."
            )

    async def start(self) -> None:
        from pathlib import Path

        import yaml

        from agentflow.oai.core.config_models import OaiYAMLConfig
        from agentflow.oai.core.helpers import load_dotenv_for, resolve_env_vars
        from agentflow.oai.core.agui_runtime import AsyncOAIAGUIRuntime

        # Parse just to extract ui_tools (used by /components).
        load_dotenv_for(self.yaml_path)
        raw = yaml.safe_load(Path(self.yaml_path).read_text())
        raw = resolve_env_vars(raw or {})
        parsed = OaiYAMLConfig.model_validate(raw)
        # OAI uses a flat ``agents:`` dict with ``starting_agent:`` as the
        # entrypoint. ``ui_tools`` lives on the starting agent's spec.
        starting = parsed.agents.get(parsed.starting_agent) if parsed.agents else None
        self._ui_tools_config = starting.ui_tools if starting else None

        self._orchestrator = await AsyncOAIAGUIRuntime.create(
            config_path=self.yaml_path,
            # The AG-UI router is the resume site for client-tool
            # interrupts (``role:"tool"`` messages + ``Command(resume=...)``).
            # Opt the orchestrator in so client_tools are actually bound to
            # the LLM. Other call sites (CLI, scripts) keep the default
            # False and the tools are filtered out — no phantom calls.
            bind_client_tools=True,
        )
        self._started = True
        logger.info("AG-UI router ready: yaml=%s", self.yaml_path)

    async def stop(self) -> None:
        if self._orchestrator is not None:
            await self._orchestrator.cleanup()
            self._orchestrator = None
        self._started = False

    async def build_resume_for_tool_message(self, thread_id: str, content: str) -> Command:
        """Translate a trailing ``role:"tool"`` message into the right
        ``Command(resume=...)`` shape based on what the paused interrupt
        expects.

        CopilotKit's ``useHumanInTheLoop`` and ``useFrontendTool`` both
        deliver results through the same channel (a tool-role message),
        but the *resume payload* langgraph expects differs:

          * LangChain ``HumanInTheLoopMiddleware`` waits for
            ``{"decisions": [<DecisionType>]}`` — the content of the
            tool message is a JSON-encoded Decision dict.
          * A ``client_tool`` stub's ``interrupt(...)`` call returns the
            resume value verbatim; the content of the tool message is
            whatever the browser-side handler returned (typically a
            short string).

        We disambiguate by reading the paused state and looking at the
        interrupt value. Falling through (no checkpoint, unknown shape)
        passes the content through verbatim — the conservative default.
        """
        self.assert_started()
        orchestrator = self._orchestrator
        if orchestrator is None:
            raise RuntimeError("Router not started.")
        try:
            snapshot = await orchestrator.get_state(thread_id=thread_id)
        except Exception:
            logger.exception("AG-UI: failed to read state when resuming via tool message")
            return Command(resume=content)

        for task in (snapshot or {}).get("tasks") or []:
            interrupts = getattr(task, "interrupts", None) or []
            for intr in interrupts:
                raw = getattr(intr, "value", None)
                if (
                    isinstance(raw, dict)
                    and "action_requests" in raw
                    and "review_configs" in raw
                ):
                    # LangChain HITLRequest — parse content as a Decision.
                    decision: Any
                    if isinstance(content, dict):
                        decision = content
                    elif isinstance(content, str):
                        try:
                            decision = json.loads(content)
                        except json.JSONDecodeError:
                            # The browser sent a free-form string; assume approval.
                            decision = {"type": "approve"}
                    else:
                        decision = {"type": "approve"}
                    if not isinstance(decision, dict):
                        decision = {"type": "approve"}
                    decision.setdefault("type", "approve")
                    # LangChain's HumanInTheLoopMiddleware insists on one
                    # decision per ActionRequest. CopilotKit's
                    # ``useHumanInTheLoop`` only stores a single resolve
                    # promise per tool name, so when the agent batches N
                    # calls to the same tool in one turn the browser can
                    # only express one decision. Replicate it so all N
                    # tool calls inherit the same answer — the only
                    # sensible UX given CopilotKit's single-card render.
                    n_actions = len(raw.get("action_requests") or [])
                    decisions = [dict(decision) for _ in range(max(n_actions, 1))]
                    return Command(resume={"decisions": decisions})
        # No HITL pause matched — treat as a plain client-tool result.
        return Command(resume=content)

    async def run(
        self,
        thread_id: str,
        message: str | None = None,
        run_id: str | None = None,
        resume_command: Command | None = None,
    ):
        self.assert_started()
        orchestrator = self._orchestrator
        if orchestrator is None:
            raise RuntimeError("Router not started.")
        if message is None and resume_command is None:
            raise ValueError("either 'message' or 'resume_command' is required")
        adapter = AGUIAdapter(thread_id=thread_id, run_id=run_id)

        # ``last_state`` tracks the most recent snapshot we yielded so we can
        # de-duplicate identical state events (token streaming doesn't change
        # the graph state, so most events leave it unchanged).
        last_state: dict[str, Any] | None = None

        async def emit_state_if_changed():
            """Yield a state envelope if the orchestrator's current state
            differs from the last one we surfaced. No-op if the orchestrator
            has no checkpointer (state sync degrades gracefully — it depends
            on persistence being on)."""
            nonlocal last_state
            try:
                snapshot = await orchestrator.get_state(thread_id=thread_id)
            except Exception:
                return None
            values = _strip_messages((snapshot or {}).get("values") or {})
            if values != last_state:
                last_state = values
                return {"type": "state", "snapshot": values}
            return None

        async def event_source():
            nonlocal last_state
            # Either a fresh user turn (message-state dict) or a HITL
            # resume (langgraph Command). The orchestrator branches on
            # ``isinstance(state, Command)`` internally.
            state_in: Any = (
                resume_command
                if resume_command is not None
                else {"messages": [{"role": "user", "content": message}]}
            )
            config = {"configurable": {"thread_id": thread_id}}

            # Read the thread's current state ONCE at the top — used for
            # both the resilience check (paused-thread recovery) and the
            # initial state snapshot. Calling get_state twice would
            # double-consume any per-call test fixtures.
            try:
                initial_snapshot = await orchestrator.get_state(thread_id=thread_id)
            except Exception:
                initial_snapshot = None

            # Resilience check: if the thread already has a pending interrupt
            # and the client is sending a *fresh* message (not a resume),
            # LangGraph would silently no-op — it can't advance until the
            # pause is answered. Re-surface the interrupt instead so the
            # frontend gets another chance to render the approval card and
            # the user can resolve it. Skipped when ``resume_command`` is
            # set: that's the user actually answering the pause.
            if resume_command is None and _has_pending_interrupts(initial_snapshot or {}):
                logger.info(
                    "AG-UI thread=%s is paused, re-surfacing pending interrupt",
                    thread_id,
                )
                yield {
                    "type": "interrupt",
                    "interrupts": _extract_interrupts(initial_snapshot or {}),
                }
                return

            # Initial state snapshot from the reading we already did.
            initial_values = _strip_messages((initial_snapshot or {}).get("values") or {})
            if initial_values != last_state:
                last_state = initial_values
                yield {"type": "state", "snapshot": initial_values}

            # Track whether the orchestrator produced any user-visible output
            # — anything besides ``agent_start`` (which is structural). If the
            # LLM returns an empty response (Azure content-filter soft-block,
            # over-cautious model, etc.) the run completes silently and the
            # frontend would render a blank assistant turn. Emit a fallback
            # message in that case so the user always sees something.
            content_events_fired = False
            try:
                async for event in orchestrator.run(
                    state=state_in,
                    config=config,
                    stream_tokens=True,
                ):
                    logger.debug(
                        "AG-UI upstream thread=%s type=%s name=%s",
                        thread_id, event.get("type"), event.get("name"),
                    )
                    etype = event.get("type")
                    if etype in {"token", "agent", "tool_call", "tool"}:
                        content_events_fired = True
                    yield event
                    # Re-snapshot only after events that can mutate graph
                    # state — token streaming and tool_call buffering don't.
                    if etype in {"tool", "agent", "agent_end"}:
                        changed = await emit_state_if_changed()
                        if changed is not None:
                            yield changed
            except GraphInterrupt:
                # A pause is an expected, orderly end-of-stream: read state,
                # yield an interrupt envelope to the adapter, return.
                logger.info("AG-UI thread=%s GraphInterrupt caught", thread_id)
                snapshot = await orchestrator.get_state(thread_id=thread_id)
                yield {"type": "interrupt", "interrupts": _extract_interrupts(snapshot)}
            except Exception:
                logger.exception("AG-UI thread=%s upstream exception", thread_id)
                raise
            else:
                # Normal completion (no GraphInterrupt re-raised). Two
                # post-conditions to check, in order:
                #
                #   1. **Silent pause** — LangGraph can finalize an
                #      interrupt into state without re-raising
                #      ``GraphInterrupt`` to us (e.g. when the interrupt
                #      fires inside a tool node that LangGraph's runner
                #      catches internally). The agent run returns
                #      "complete" from our POV but the thread is actually
                #      paused. Surface the interrupt instead of treating
                #      the empty stream as an empty response.
                #
                #   2. **Empty response** — the model returned with no
                #      content, no tool calls, no interrupt. Emit a
                #      fallback text so the frontend doesn't render a
                #      blank assistant turn.
                try:
                    final_snapshot = await orchestrator.get_state(thread_id=thread_id)
                except Exception:
                    final_snapshot = None
                if _has_pending_interrupts(final_snapshot or {}):
                    logger.info(
                        "AG-UI thread=%s run finalized with pending interrupt — surfacing",
                        thread_id,
                    )
                    yield {
                        "type": "interrupt",
                        "interrupts": _extract_interrupts(final_snapshot or {}),
                    }
                elif not content_events_fired:
                    logger.warning(
                        "AG-UI thread=%s agent produced no content — emitting fallback",
                        thread_id,
                    )
                    yield {
                        "type": "agent",
                        "content": (
                            "I wasn't able to generate a response for that. "
                            "Could you rephrase your question or try again?"
                        ),
                    }

        async for ag_event in translate_stream(adapter, event_source()):
            yield ag_event
