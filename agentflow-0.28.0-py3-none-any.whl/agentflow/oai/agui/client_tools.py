"""Frontend-implemented (client-side) tool stubs for the OAI AG-UI bridge.

The OpenAI Agents SDK exposes user-defined tools as ``FunctionTool``
instances built by the ``@function_tool`` decorator. To implement
client_tools on OAI, each ``ClientToolConfig`` becomes a
``FunctionTool`` whose async body raises :class:`ClientToolPause`.
The OAI AG-UI orchestrator catches the pause while iterating over
``Runner.run_streamed()``, emits an AG-UI Interrupt event, and ends
the run. The browser handler executes and posts the result back on
the next request.

Three runtimes (workflows / deep / SK / CAS), same pause contract.
On OAI we lean on ``@function_tool`` so the schema generation, name
exposure, and parameter binding all flow through the SDK's standard
machinery.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agentflow.genui import ClientToolConfig

logger = logging.getLogger(__name__)


class ClientToolPause(Exception):
    """Raised by a client_tool stub body to pause the agent run.

    The OAI AG-UI orchestrator catches this exception while iterating
    over ``Runner.run_streamed()`` events; emits an AG-UI Interrupt
    with the tool name and args; ends the stream. The browser
    handler runs; the orchestrator resumes on the next request by
    feeding the result as a user-message preamble.
    """

    def __init__(self, tool_name: str, args: dict[str, Any]) -> None:
        super().__init__(f"client_tool pause: {tool_name}({args})")
        self.tool_name = tool_name
        self.tool_args = args


def build_client_tool_function_tools(specs: list["ClientToolConfig"]) -> list[Any]:
    """Build one ``FunctionTool`` per ``ClientToolConfig`` whose handler
    raises ``ClientToolPause``.

    Called by the OAI AG-UI router at orchestrator-build time when
    ``bind_client_tools=True``. Each tool is added to the agent's
    tools list alongside the ``ui_tools`` ``FunctionTool``s.
    """
    from agents import function_tool

    tools: list[Any] = []
    for spec in specs:
        tools.append(_make_function_tool(spec, function_tool))
    return tools


def _make_function_tool(spec: "ClientToolConfig", function_tool: Any) -> Any:
    """Build one FunctionTool whose body raises ClientToolPause."""
    tool_name = spec.name
    description = spec.description or ""

    # The OAI SDK introspects the wrapped callable to derive the tool's
    # JSON schema. We accept ``**kwargs`` since the schema is declared
    # in YAML via ``ClientToolConfig.parameters`` — but the SDK doesn't
    # consume that. For now the LLM gets a generic shape. A full
    # ``Pydantic`` model-based binding is the next iteration.
    async def handler(**kwargs: Any) -> str:
        raise ClientToolPause(tool_name=tool_name, args=dict(kwargs))

    # Add a docstring derived from the spec description so the SDK's
    # docstring-based metadata generation has something to chew on.
    handler.__name__ = tool_name
    handler.__doc__ = description

    ft = function_tool(
        handler,
        name_override=tool_name,
        description_override=description,
        # Disable strict_mode so the auto-derived schema (which is
        # effectively ``{}`` since handler has no typed params) is
        # accepted as-is.
        strict_mode=False,
    )
    ft._agentflow_client_tool = True  # type: ignore[attr-defined]
    return ft
