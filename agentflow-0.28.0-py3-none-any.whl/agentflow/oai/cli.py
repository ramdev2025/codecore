"""AgentFlow OAI CLI — run OpenAI Agents SDK agents from the unified
``agentflow`` command.

The CLI router dispatches ``backend: openai-agents`` to ``run_from_router``
in this module. It translates canonical flags into SDK-specific objects,
executes the agent, and streams output to the console.

Supported modes:

- **dry-run** — validate the YAML and print a summary
- **one-shot** — single query via ``Runner.run_streamed()``
- **interactive** — REPL over the same runner with thread continuity

Persistence (``--persistence``, ``--db-path``, ``--thread-id``) uses
``OaiPersistenceManager`` to bind ``thread_id → SDK session id``. The
actual conversation items live in the SDK ``Session``
(``SQLiteSession`` by default), so resumption is truly automatic.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any, Optional

from agentflow.cli import (
    ExecutionTimer,
    console,
    print_banner,
    print_config_table,
    print_error,
    print_execution_summary,
    print_info,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_AGENT_SWITCH,
    EVENT_COMPLETE,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)


def run_from_router(
    yaml_path: str,
    query: Optional[str] = None,
    persistence: Optional[str] = None,
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
    thread_id: Optional[str] = None,
    interactive: bool = False,
    dry_run: bool = False,
    json_output: bool = False,
    output: str = "tty",
    **_ignored: Any,
):
    """Entry point called by the unified CLI router.

    Cross-backend flags that don't apply to OAI (``workdir``, ``no_tui``,
    ``tools_module``, ``recursion_limit``) are absorbed via ``**_ignored``.

    Persistence precedence: ``--persistence`` flag > ``AGENTFLOW_PERSISTENCE``
    env var > default (sqlite).
    """
    from dotenv import find_dotenv, load_dotenv

    env_path = find_dotenv(usecwd=True)
    if env_path:
        load_dotenv(env_path, override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(
        getattr(logging, log_level, logging.WARNING)
    )

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    if persistence is None:
        persistence = os.environ.get("AGENTFLOW_PERSISTENCE", "sqlite").strip().lower()

    if dry_run:
        _run_dry(yaml_path, json_output=json_output)
        return

    json_sink: Optional[JsonSink] = JsonSink(backend="openai-agents") if is_json_mode(output) else None
    if json_sink is None:
        print_banner(
            "AgentFlow OAI",
            "Run OpenAI Agents SDK agents from the command line",
        )

    from agentflow.oai.telemetry import setup_tracing

    setup_tracing()

    try:
        from agentflow.oai.core.builder import OaiAgentBuilder
    except ImportError:
        print_error(
            "openai-agents is required but not installed. "
            "Install with: pip install agentflow[openai-agents]"
        )
        raise SystemExit(1)

    builder = OaiAgentBuilder.from_yaml(yaml_path)
    runner = builder.build()

    pm = _build_persistence(persistence, db_path, connection_string)
    tid = thread_id or str(uuid.uuid4())
    if json_sink is None:
        _print_run_header(yaml_path, persistence, tid)

    sdk_session = _resolve_sdk_session(pm, tid, persistence, db_path, connection_string)

    if interactive and json_sink is None:
        _run_interactive(runner, pm, tid, sdk_session)
    else:
        if not query:
            query = prompt_user("Query") if json_sink is None else ""
        if not query:
            return
        _run_one_shot(runner, query, pm, tid, sdk_session, json_sink=json_sink)


# ---------------------------------------------------------------------------
# Dry-run
# ---------------------------------------------------------------------------


def _run_dry(yaml_path: str, json_output: bool = False) -> None:
    try:
        from agentflow.oai.core.builder import OaiAgentBuilder
    except ImportError:
        print_error(
            "openai-agents is required but not installed. "
            "Install with: pip install agentflow[openai-agents]"
        )
        raise SystemExit(1)

    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    builder = OaiAgentBuilder.from_yaml(yaml_path)
    summary = builder.dry_run()

    if json_output:
        print(json.dumps(summary, indent=2, default=str))
        return

    print_banner(
        "AgentFlow OAI",
        "Run OpenAI Agents SDK agents from the command line",
    )
    llm_summary = summary.get("llm") or {}
    sdk_opts = llm_summary.get("sdk_options") or {}
    rc = summary.get("run_config") or {}

    rows = [
        ("Backend", "openai-agents"),
        ("Config", yaml_path),
        ("Name", summary["metadata"].get("name") or "-"),
        ("Provider", llm_summary.get("provider") or "-"),
        ("Model", sdk_opts.get("model") or "-"),
        ("Starting agent", summary["starting_agent"]),
        ("Agents", ", ".join(summary["agents"].keys())),
        ("Max turns", str(rc.get("max_turns", "-"))),
        ("Workflow name", rc.get("workflow_name", "-")),
    ]
    if summary.get("guards"):
        rows.append(("Guards", ", ".join(summary["guards"])))
    if summary.get("optimizers"):
        rows.append(("Optimizers", ", ".join(summary["optimizers"])))
    if summary.get("observers"):
        rows.append(("Observers", ", ".join(summary["observers"])))
    if summary.get("mcp_servers"):
        rows.append(("MCP servers", ", ".join(summary["mcp_servers"])))
    if rc.get("sandbox"):
        rows.append(("Sandbox", rc["sandbox"]))

    print_config_table(rows)
    console.print("[bold green]Config is valid.[/bold green]")


# ---------------------------------------------------------------------------
# One-shot + interactive
# ---------------------------------------------------------------------------


def _run_one_shot(
    runner: Any,
    query: str,
    pm: Optional[Any],
    thread_id: str,
    sdk_session: Optional[Any],
    json_sink: Optional[JsonSink] = None,
) -> None:
    if json_sink is None:
        console.print()
    timer = ExecutionTimer()
    timer.start()
    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    asyncio.run(_drive_query(runner, query, pm, thread_id, sdk_session, json_sink=json_sink))
    if json_sink is not None:
        json_sink.emit(EVENT_STATS, elapsed_s=timer.elapsed())
        json_sink.emit(EVENT_COMPLETE)
    else:
        print_execution_summary(console, timer.elapsed())


def _run_interactive(
    runner: Any,
    pm: Optional[Any],
    thread_id: str,
    sdk_session: Optional[Any],
) -> None:
    init_history()
    repl_state = ReplState(thread_id=thread_id)
    console.print(
        "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, "
        "[bold]/quit[/bold] to exit\n"
    )
    while True:
        try:
            q = prompt_user("Query")
            if is_quit_alias(q):
                console.print("\nGoodbye.")
                break
            if not q.strip():
                continue
            if is_slash_command(q):
                if dispatch_slash_command(q, repl_state, console) == "quit":
                    console.print("\nGoodbye.")
                    break
                continue

            console.print()
            timer = ExecutionTimer()
            timer.start()
            asyncio.run(_drive_query(runner, q, pm, thread_id, sdk_session))
            print_execution_summary(console, timer.elapsed())
        except (KeyboardInterrupt, EOFError):
            console.print("\nGoodbye.")
            break
        except Exception as e:
            from agentflow.cli.errors import friendly_error
            print_error(friendly_error(e))
    cleanup_terminal_state()


# ---------------------------------------------------------------------------
# SDK invocation — streams events, accumulates usage, attaches to root span
# ---------------------------------------------------------------------------


async def _drive_query(
    runner: Any,
    query_text: str,
    pm: Optional[Any],
    thread_id: str,
    sdk_session: Optional[Any],
    json_sink: Optional[JsonSink] = None,
) -> None:
    """Run a query through ``Runner.run_streamed()``, rendering events live.

    Wraps the entire run in an ``agentflow.oai.run`` root span so per-tool
    observer spans nest under it. Accumulates per-turn ``Usage`` and
    attaches the rollup to the root span + emits a
    ``gen_ai.session_summary`` child span.

    When ``json_sink`` is provided, OAI stream events are translated to
    the shared ndjson schema and emitted to that sink instead of the
    Rich-rendered terminal output.
    """
    from agents import Runner
    from opentelemetry import trace

    tracer = trace.get_tracer("agentflow.oai")
    renderer = _StreamRenderer(console) if json_sink is None else None

    model = getattr(runner.starting_agent, "model", None) or ""

    with tracer.start_as_current_span(
        "agentflow.oai.run",
        attributes={
            "agentflow.backend": "openai-agents",
            "agentflow.thread_id": thread_id,
            "agentflow.query_length": len(query_text),
            "gen_ai.request.model": model if isinstance(model, str) else "",
        },
    ) as root_span:
        # Usage accumulator hook — populates `total_usage` from every
        # ``on_llm_end`` callback. This works uniformly across the Responses
        # API and Azure Chat Completions, unlike per-event inspection.
        total_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
        usage_hook = _make_usage_accumulator_hook(total_usage)

        # Compose kwargs including the hooks composite (observers + counter
        # guards + optimizers that emit hooks, plus our usage accumulator).
        # Without this, none of the `observers:` declared in YAML would fire.
        kwargs = runner._compose_run_kwargs(extra_hooks=[usage_hook])
        if sdk_session is not None:
            kwargs["session"] = sdk_session

        stream = Runner.run_streamed(
            runner.starting_agent, query_text, **kwargs,
        )

        emitted_text = False
        async for event in stream.stream_events():
            if json_sink is not None:
                if _emit_oai_event(json_sink, event):
                    emitted_text = True
            else:
                renderer.render(event)

        if renderer is not None:
            renderer.flush()

        # Final output (if the agent produced one) prints after streaming
        final_output = getattr(stream, "final_output", None)
        if final_output is not None:
            if json_sink is not None:
                if not emitted_text:
                    json_sink.emit(EVENT_TOKEN, content=str(final_output))
            elif not renderer.emitted_text:
                console.print()
                console.print(str(final_output), highlight=False, markup=False)
                console.print()

        # Root span rollup
        for k, v in total_usage.items():
            root_span.set_attribute(f"gen_ai.usage.{k}", v)

        # Session summary child span (mirror of the CAS pattern)
        with tracer.start_as_current_span(
            "gen_ai.session_summary",
            attributes={
                "gen_ai.operation.name": "session_summary",
                **{f"gen_ai.usage.{k}": v for k, v in total_usage.items()},
            },
        ):
            pass

        # Persistence bump — OAI sessions are keyed on a stable id we own
        if pm is not None:
            pm.bump_turns(thread_id)


# ---------------------------------------------------------------------------
# Stream renderer
# ---------------------------------------------------------------------------


class _StreamRenderer:
    """Turns OAI ``StreamEvent``s into terminal output as they arrive.

    - ``RawResponsesStreamEvent`` with a text-delta → streams inline
    - ``RunItemStreamEvent``:
        * ``tool_called`` → ``▸ Tool(short-args)``
        * ``tool_output`` → ``← tool result · N chars``
        * ``handoff_requested`` → ``↳ delegate to <agent>``
        * ``handoff_occured`` (SDK typo kept) → ``→ now active: <agent>``
        * ``message_output_created`` → collected; final text flushed at end
        * ``reasoning_item_created`` → ``· thinking…``
    - ``AgentUpdatedStreamEvent`` → ``→ now active: <agent>``
    """

    _MAX_ARG_CHARS = 110

    def __init__(self, output):
        self._out = output
        self._streaming_text = False
        self.emitted_text = False

    def render(self, event: Any) -> None:
        try:
            ev_type = getattr(event, "type", None)
            if ev_type == "raw_response_event":
                self._render_raw(event)
            elif ev_type == "run_item_stream_event":
                self._render_run_item(event)
            elif ev_type == "agent_updated_stream_event":
                self._render_agent_update(event)
        except Exception as e:  # pragma: no cover
            self._out.print(f"[dim red](renderer error: {e})[/dim red]")

    def flush(self) -> None:
        self._end_text_stream()

    # --- internals --------------------------------------------------------

    def _render_raw(self, event: Any) -> None:
        """Stream text deltas inline."""
        data = getattr(event, "data", None)
        if data is None:
            return
        # Text deltas from the Responses API have type 'response.output_text.delta'
        data_type = getattr(data, "type", "")
        if data_type == "response.output_text.delta":
            delta = getattr(data, "delta", "") or ""
            if delta:
                if not self._streaming_text:
                    self._out.print()
                    self._streaming_text = True
                self._out.print(delta, end="", highlight=False, markup=False)
                self.emitted_text = True

    def _render_run_item(self, event: Any) -> None:
        name = getattr(event, "name", "")
        item = getattr(event, "item", None)
        if item is None:
            return

        if name == "tool_called":
            self._end_text_stream()
            tool_name, short = _describe_tool_call(item)
            self._out.print(
                f"[cyan]▸[/cyan] {tool_name}({short})", highlight=False
            )
        elif name == "tool_output":
            self._end_text_stream()
            length = _tool_output_length(item)
            self._out.print(
                f"  [dim]← tool result · {length} chars[/dim]",
                highlight=False,
            )
        elif name == "handoff_requested":
            self._end_text_stream()
            target = _extract_handoff_target(item)
            self._out.print(
                f"[bold blue]↳[/bold blue] delegate to [bold]{target}[/bold]",
                highlight=False,
            )
        elif name == "handoff_occured":  # SDK literal spelling — keep as-is
            self._end_text_stream()
            target = getattr(item, "target_agent", None)
            target_name = getattr(target, "name", "?") if target else "?"
            self._out.print(
                f"[bold green]→[/bold green] now active: [bold]{target_name}[/bold]",
                highlight=False,
            )
        elif name == "reasoning_item_created":
            self._end_text_stream()
            self._out.print("[dim italic]· thinking…[/dim italic]")
        # mcp_approval_requested, mcp_list_tools, message_output_created etc.
        # are either handled via raw text deltas or don't need rendering.

    def _render_agent_update(self, event: Any) -> None:
        self._end_text_stream()
        new_agent = getattr(event, "new_agent", None)
        name = getattr(new_agent, "name", "?") if new_agent else "?"
        self._out.print(
            f"[bold green]→[/bold green] agent: [bold]{name}[/bold]",
            highlight=False,
        )

    def _end_text_stream(self) -> None:
        if self._streaming_text:
            self._out.print()
            self._streaming_text = False


def _emit_oai_event(sink: JsonSink, event: Any) -> bool:
    """Translate one OAI ``StreamEvent`` into ndjson events.

    Returns ``True`` when a text token was emitted, so the caller can
    avoid double-emitting the final output.

    Mirrors the dispatch in :class:`_StreamRenderer`:
    - text deltas → ``token`` events
    - ``run_item_stream_event`` ``tool_called`` → ``tool_call``
    - ``run_item_stream_event`` ``tool_output`` → ``tool``
    - ``handoff_requested`` / ``handoff_occured`` /
      ``agent_updated_stream_event`` → ``agent_switch``
    - ``reasoning_item_created`` → ``reasoning``
    """
    ev_type = getattr(event, "type", None)
    if ev_type == "raw_response_event":
        data = getattr(event, "data", None)
        if data is None:
            return False
        if getattr(data, "type", "") == "response.output_text.delta":
            delta = getattr(data, "delta", "") or ""
            if delta:
                sink.emit(EVENT_TOKEN, content=delta)
                return True
        return False
    if ev_type == "run_item_stream_event":
        name = getattr(event, "name", "")
        item = getattr(event, "item", None)
        if name == "tool_called":
            tool_name, _ = _describe_tool_call(item) if item is not None else ("<tool>", "")
            raw_args = None
            if item is not None:
                raw = getattr(item, "raw_item", None)
                raw_args = getattr(raw, "arguments", None) or getattr(raw, "input", None)
            sink.emit(EVENT_TOOL_CALL, name=tool_name, args=raw_args)
        elif name == "tool_output":
            output = getattr(item, "output", None) if item is not None else None
            sink.emit(EVENT_TOOL, content=output)
        elif name == "handoff_requested":
            target = _extract_handoff_target(item) if item is not None else "?"
            sink.emit(EVENT_AGENT_SWITCH, name=target, kind="handoff_requested")
        elif name == "handoff_occured":
            target = getattr(item, "target_agent", None) if item is not None else None
            target_name = getattr(target, "name", "?") if target else "?"
            sink.emit(EVENT_AGENT_SWITCH, name=target_name, kind="handoff_occurred")
        elif name == "reasoning_item_created":
            sink.emit(EVENT_REASONING)
        return False
    if ev_type == "agent_updated_stream_event":
        new_agent = getattr(event, "new_agent", None)
        n = getattr(new_agent, "name", "?") if new_agent else "?"
        sink.emit(EVENT_AGENT_SWITCH, name=n, kind="agent_updated")
    return False


def _describe_tool_call(item: Any) -> tuple[str, str]:
    """Best-effort pull of (tool_name, short-args) from a ToolCallItem."""
    raw = getattr(item, "raw_item", None)
    tool_name = (
        getattr(raw, "name", None)
        or getattr(raw, "tool_name", None)
        or type(raw).__name__
        or "<tool>"
    )
    # Arguments live in raw.arguments (JSON string) for function tools
    raw_args = getattr(raw, "arguments", None) or getattr(raw, "input", None)
    if isinstance(raw_args, str):
        short = raw_args if len(raw_args) <= 110 else raw_args[:109] + "…"
    elif isinstance(raw_args, dict):
        short = _short_dict(raw_args)
    else:
        short = ""
    return str(tool_name), short


def _short_dict(d: dict, limit: int = 110) -> str:
    pairs: list[str] = []
    for k, v in d.items():
        pairs.append(f"{k}={v!r}")
        if sum(len(p) for p in pairs) > limit:
            break
    joined = ", ".join(pairs)
    return joined if len(joined) <= limit else joined[: limit - 1] + "…"


def _tool_output_length(item: Any) -> int:
    output = getattr(item, "output", None)
    if isinstance(output, str):
        return len(output)
    if output is None:
        return 0
    return len(repr(output))


def _extract_handoff_target(item: Any) -> str:
    """Pull target-agent name out of a HandoffCallItem."""
    raw = getattr(item, "raw_item", None)
    name = getattr(raw, "name", None) or ""
    # Handoff tool names look like 'transfer_to_billing' — strip the prefix.
    if name.startswith("transfer_to_"):
        return name[len("transfer_to_"):]
    return name or "?"


# ---------------------------------------------------------------------------
# Usage accumulator
# ---------------------------------------------------------------------------


def _make_usage_accumulator_hook(totals: dict) -> Any:
    """RunHooks subclass that sums ``ModelResponse.usage`` across every LLM turn.

    This works for both the Responses API and Azure Chat Completions
    because the SDK normalizes the per-turn usage onto ``ModelResponse``
    before invoking ``on_llm_end``.
    """
    from agents import RunHooks

    class _UsageAccumulator(RunHooks):
        async def on_llm_end(self, context, agent, response):
            usage = getattr(response, "usage", None)
            if usage is None:
                return
            totals["input_tokens"] += getattr(usage, "input_tokens", 0) or 0
            totals["output_tokens"] += getattr(usage, "output_tokens", 0) or 0
            totals["total_tokens"] += getattr(usage, "total_tokens", 0) or 0

    return _UsageAccumulator()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_persistence(
    backend: str,
    db_path: Optional[str],
    connection_string: Optional[str],
) -> Optional[Any]:
    try:
        from agentflow.oai.persistence import create_persistence_manager
    except ImportError:
        return None
    return create_persistence_manager(
        backend=backend,
        db_path=db_path,
        connection_string=connection_string,
    )


def _resolve_sdk_session(
    pm: Optional[Any],
    thread_id: str,
    persistence: str,
    db_path: Optional[str],
    connection_string: Optional[str],
) -> Optional[Any]:
    """Map the agentflow ``thread_id`` to a concrete SDK ``Session`` object.

    When ``persistence == "memory"``, we skip sessions entirely (each run is
    fresh). Otherwise we look up or create a session id via the persistence
    manager and hand back a ``SQLiteSession`` (or similar) already pointing
    at the right row.
    """
    if pm is None or persistence == "memory":
        return None
    try:
        from agentflow.oai.persistence import build_sdk_session
    except ImportError:
        return None
    session_id = pm.get_or_create_session_id(thread_id)
    return build_sdk_session(
        session_id,
        session_backend=persistence,
        db_path=db_path,
        connection_string=connection_string,
    )


def _print_run_header(
    yaml_path: str, persistence: str, thread_id: str
) -> None:
    print_info(f"Config: {yaml_path}")
    print_info(f"Persistence: {persistence}")
    print_info(f"Thread: {thread_id}")
    console.print()
