# Getting Started

This page walks through your first OAI-backend agent, then adds a handoff, a guardrail, a custom Python tool, and persistence.

## Prerequisites

- Python 3.10+
- An OpenAI API key (or Azure OpenAI / LiteLLM credentials — see [Services](SERVICES.md))

## Install

```bash
pip install agentflow[openai-agents]
```

Set the key:

```bash
export OPENAI_API_KEY=sk-...
```

Or put it in a `.env` file in your project root — AgentFlow loads it automatically.

## 1. Your First Agent

Create `oai_agent.yaml`:

```yaml
backend: openai-agents

metadata:
  version: "1.0"
  name: hello

llm:
  provider: openai
  config:
    model: gpt-4o-mini

agents:
  main:
    instructions: "You are a helpful assistant."

starting_agent: main
```

Run it:

```bash
agentflow --yaml oai_agent.yaml "What is the capital of France?"
```

Or validate without calling the API:

```bash
agentflow --yaml oai_agent.yaml --dry-run
```

## 2. Add a Handoff

The OpenAI Agents SDK's distinguishing primitive is **handoff** — one agent delegating to another. Any agent can hand off to any other; there's no orchestrator/worker hierarchy baked into the schema.

```yaml
agents:
  triage:
    instructions: "Route user questions to the right specialist."
    handoffs: [billing, technical]     # string-shorthand form

  billing:
    instructions: "Handle billing, subscriptions, refunds."
    handoff_description: "Billing specialist"

  technical:
    instructions: "Handle technical support questions."

starting_agent: triage
```

The LLM decides when to hand off based on `handoff_description`. When a handoff fires, the target agent takes over with the full conversation history.

Need finer control? Use the detailed form:

```yaml
    handoffs:
      - agent: billing
        tool_name_override: transfer_to_billing_specialist
        tool_description_override: "Only for billing / refunds."
        on_handoff:
          module: myapp.callbacks
          function: log_handoff
        input_filter:
          module: myapp.filters
          function: trim_history
        is_enabled: true               # or {module, function} for dynamic
```

See [Handoffs](HANDOFFS.md) for the full surface.

## 3. Add Built-in Tools

```yaml
agents:
  triage:
    instructions: "Route user questions to the right specialist."
    tools:
      builtin: [web_search]              # bare-name shorthand
    handoffs: [billing, technical]
```

For tools that need config, use the detailed form:

```yaml
    tools:
      builtin:
        - name: file_search
          config:
            vector_store_ids: ["${VECTOR_STORE_ID}"]
        - web_search                     # mixed bare + detailed is fine
```

Every hosted tool the SDK ships (`web_search`, `file_search`, `code_interpreter`, `image_generation`, `hosted_mcp`) and every local tool (`computer`, `shell`, `local_shell`, `apply_patch`, `tool_search`) is supported. See [YAML Reference](YAML_REFERENCE.md#tools).

## 4. Custom Python Tools

Write a module with `@function_tool`-decorated functions:

```python
# myapp/tools.py
from agents import function_tool

@function_tool
async def lookup_order(order_id: str) -> dict:
    """Look up an order by ID."""
    return {"id": order_id, "status": "shipped"}
```

Reference it from YAML:

```yaml
agents:
  billing:
    instructions: "Handle billing inquiries."
    plugins:
      - name: order-tools
        module: myapp.tools
        functions: [lookup_order]        # optional: restrict to named functions
```

See [Plugins](PLUGINS.md).

## 5. Add a Guardrail

OpenAI's SDK has first-class `InputGuardrail` / `OutputGuardrail` — they run before/after the agent and can trip a **tripwire** that aborts the run.

```yaml
guards:
  - type: pii
    config:
      patterns: [email, phone, ssn]      # built-in named patterns
```

Or write your own:

```python
# myapp/guards.py
from agents import GuardrailFunctionOutput

async def require_non_empty(context, agent, input_data):
    text = input_data if isinstance(input_data, str) else ""
    return GuardrailFunctionOutput(
        output_info={"length": len(text)},
        tripwire_triggered=(len(text.strip()) == 0),
    )
```

```yaml
guards:
  - type: input_validation
    module: myapp.guards
    function: require_non_empty
```

See [Guardrails](GUARDRAILS.md) and [Guards / Optimizers / Observers](GUARDS.md).

## 6. Persistence

```bash
agentflow --yaml oai_agent.yaml --thread-id my-session "first message"
agentflow --yaml oai_agent.yaml --thread-id my-session "follow-up"
```

By default conversations are stored in SQLite (`.agentflow/oai_sessions.db`). Conversation items live inside the SDK's `SQLiteSession`; AgentFlow stores a thread_id → session_id binding so the same `--thread-id` always resumes the same session. See [Persistence](PERSISTENCE.md).

## 7. Observability

Enable OpenTelemetry tracing:

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
agentflow --yaml oai_agent.yaml "What's the weather?"
```

Spans emitted include `agentflow.oai.run` (root), `gen_ai.execute_tool <name>`, `agentflow.tool.latency <name>`, `gen_ai.agent_end`, and `gen_ai.session_summary` with per-turn token rollups. See [Observability](OBSERVABILITY.md).

## Next

- [YAML Reference](YAML_REFERENCE.md) — every field, every validator rule
- [CLI Reference](CLI_REFERENCE.md) — every flag and env var
- [Modes](MODES.md) — single agent, triage-style handoffs, round-trip delegates
- [Full Example](FULL_EXAMPLE.md) — an annotated production-grade YAML

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
