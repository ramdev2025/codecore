# Plugin Bridge

AgentFlow ships a cross-backend `Plugin` ABC (see `agentflow.workflows.plugins`) — telemetry, logging, cost tracking, and audit plugins written for one backend work on every backend. The OAI plugin bridge makes existing plugins fire on OAI agents without modification.

## What it bridges

| Plugin event | Source in OAI |
|---|---|
| `emit_tool_call(ctx, tool_name, input)` | `RunHooks.on_tool_start` |
| `emit_tool_result(ctx, tool_name, result)` | `RunHooks.on_tool_end` |
| `emit_agent_start(ctx, agent_name)` | `RunHooks.on_agent_start` |
| `emit_agent_end(ctx, agent_name, status)` | `RunHooks.on_agent_end` |
| `emit_handoff(ctx, from, to)` | `RunHooks.on_handoff` |
| `emit_workflow_start(ctx)` | `WorkflowLifecycleEmitter.__enter__` (CLI wraps the run) |
| `emit_workflow_end(ctx, output, status)` | `WorkflowLifecycleEmitter.__exit__` |
| `emit_error(ctx, exception, details)` | `WorkflowLifecycleEmitter.__exit__` on exception |

Events that don't apply to OAI (`emit_hitl_*`, `emit_external_agent_*`, `emit_mcp_connect`) simply never fire.

## Duck-typed plugin manager

The bridge accepts **any object** with these methods. Missing methods are silently ignored — a plugin manager doesn't need to handle every event.

```python
# myapp/plugins/manager.py
class MyPluginManager:
    def emit_tool_call(self, ctx, tool_name, tool_input):
        my_metrics.counter("tool_calls", {"tool": tool_name}).inc()

    def emit_workflow_end(self, ctx, output, status):
        my_metrics.counter("workflows_completed", {"status": status}).inc()

    # No emit_handoff method? No problem — silently skipped.
```

## Wiring

```python
from agentflow.oai.cli import run_from_router
from agentflow.oai.core.plugin_bridge import (
    build_plugin_bridge_hook,
    WorkflowLifecycleEmitter,
)
from agentflow.oai.filters.builtin import compose_hooks
from myapp.plugins.manager import MyPluginManager

pm = MyPluginManager()

# Your existing plugin manager becomes a RunHooks instance
bridge_hook = build_plugin_bridge_hook(pm, context={"workflow": "main"})

# Combine with other observers
# (in the CLI this happens automatically; for library usage do it manually)
```

When integrating outside the CLI:

```python
from agents import Runner
from agentflow.oai.core.builder import OaiAgentBuilder

runner = OaiAgentBuilder.from_yaml("oai_agent.yaml").build()

with WorkflowLifecycleEmitter(pm, context={}, agent_name=runner.starting_agent.name):
    result = await Runner.run(
        runner.starting_agent,
        "Hello",
        run_config=runner.run_config,
        hooks=bridge_hook,
    )
```

## Robustness

Plugin callbacks run inside a `try/except`. A broken plugin is logged at DEBUG level but never crashes the agent:

- `AttributeError` for missing methods → silently skipped
- Any other exception → caught, swallowed, event continues to the next plugin

## Composing with other observers

Multiple observers (the plugin bridge + `audit_log` + `cost_tracking`) are combined into one `RunHooks` composite. Every event fires on every hook in declaration order.

```python
from agentflow.oai.filters.builtin import compose_hooks, make_audit_log_hook

composite = compose_hooks([
    build_plugin_bridge_hook(pm, context={}),
    make_audit_log_hook(),
])
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
