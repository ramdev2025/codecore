# Sessions

The OpenAI Agents SDK owns conversation state via its `Session` abstraction. Every turn, the SDK:

1. Reads prior items from the session.
2. Appends the new user input.
3. Calls the LLM.
4. Appends the new items (tool calls, results, assistant messages).

AgentFlow's `--thread-id` is the user-facing handle; internally we map each `thread_id` to an SDK session identifier and hand the runner the appropriate `Session` object.

## Session backends

| `--persistence` value | SDK `Session` class | Storage | Install |
|---|---|---|---|
| `memory` | `SQLiteSession(":memory:")` | Per-process, dies with the run | built-in |
| `sqlite` (default) | `SQLiteSession(path)` | Local `.db` file | built-in |
| `openai` | `OpenAIConversationsSession` | OpenAI server-side | built-in (needs `OPENAI_API_KEY`) |
| `redis` | `RedisSession` | Redis server | `pip install 'openai-agents[redis]'` |
| `sqlalchemy` | `SQLAlchemySession` | Any SQLAlchemy backend | `pip install 'openai-agents[sqlalchemy]'` |
| `mongodb` | `MongoDBSession` | MongoDB | `pip install 'openai-agents[mongodb]'` |

The CLI's `--persistence` flag currently accepts `memory` / `sqlite` / `postgres` (matching other backends); the remaining SDK sessions are reachable via the programmatic API (see [Persistence](PERSISTENCE.md)).

## Default file layout

```
.agentflow/
├── oai_threads.db           # thread_id → session_id binding table (AgentFlow)
└── oai_sessions.db          # SDK SQLiteSession — actual conversation items
```

Override the SDK session path with `OAI_SESSION_DB_PATH`, and the binding table with `--db-path` (or `CHECKPOINTER_DB_PATH`).

## Resume flow

```bash
# First turn
agentflow --yaml oai_agent.yaml --thread-id my-session "order 1234 status"

# Second turn — SDK session reloaded automatically
agentflow --yaml oai_agent.yaml --thread-id my-session "refund it"
```

Step by step:

1. CLI looks up `my-session` in the binding table → misses, allocates a new UUID, stores `my-session → <uuid>`.
2. CLI constructs `SQLiteSession(session_id=<uuid>, db_path=.agentflow/oai_sessions.db)`.
3. `Runner.run_streamed(starting_agent, query, session=sqlite_session)` — SDK reads + appends items.
4. Next call: CLI finds `my-session` in the binding table → reuses the same UUID → same session row.

The binding table lets `--thread-id` be human-readable without leaking SDK internals.

## Switching to OpenAI-hosted sessions

The OpenAI platform has a first-party `OpenAIConversationsSession` that stores conversations on OpenAI's side. Useful when you want:

- No local storage to manage
- Cross-instance continuity without a shared DB
- Built-in OpenAI conversation archiving

```python
from agentflow.oai.persistence import build_sdk_session

session = build_sdk_session("my-session", session_backend="openai")
```

Then in YAML, set `--persistence memory` (so AgentFlow doesn't try to open SQLite) and attach the session manually in your host code.

## Switching to Redis / SQLAlchemy / MongoDB

```python
from agentflow.oai.persistence import build_sdk_session

session = build_sdk_session(
    "my-session",
    session_backend="redis",
    connection_string="redis://localhost:6379/0",
)
```

## Encryption

When `AGENTFLOW_ENCRYPTION_KEY` is set (16/24/32 bytes), the session-id bound in the binding table is AES-GCM encrypted at rest. The SDK session itself (the conversation items) is not encrypted by AgentFlow — use database-level encryption if that's a requirement.

## Sessions vs the AgentFlow binding table

| Table | Lives in | Purpose |
|---|---|---|
| Binding table (`oai_threads`) | `.agentflow/oai_threads.db` | Maps human `thread_id` → SDK session id; audit fields (first/last seen, turns) |
| SDK session | `.agentflow/oai_sessions.db` (or remote) | Actual conversation items |

You can clear one without affecting the other, though in practice they're coupled: deleting a binding orphans the SDK session row.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
