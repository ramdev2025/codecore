# AgentFlow OAI

**YAML-driven agents on the [OpenAI Agents SDK](https://pypi.org/project/openai-agents/).**

AgentFlow OAI lets you define peer-graph multi-agent systems — with handoffs, guardrails, built-in hosted tools, and custom Python tools — in YAML, without writing SDK boilerplate. It's the fifth backend of the AgentFlow framework, sitting alongside `workflows` (LangGraph), `deep` (DeepAgents), `sk` (Semantic Kernel), and `cas` (Claude Agent SDK).

## Install

```bash
pip install agentflow[openai-agents]
```

This pulls in `openai-agents>=0.14.5` and nothing else — no LangChain, no LangGraph, no Semantic Kernel, no Claude Agent SDK. Each backend is isolated so you only install what you use.

## Quick Start

1. **Create a YAML config** (`oai_agent.yaml`):

    ```yaml
    backend: openai-agents

    metadata:
      version: "1.0"
      name: customer-support

    llm:
      provider: openai
      config:
        model: gpt-4o-mini
        api_key: ${OPENAI_API_KEY}

    agents:
      triage:
        instructions: |
          You route user questions to the right specialist.
        handoffs: [billing, technical]
        tools:
          builtin: [web_search]

      billing:
        instructions: "Handle billing, subscriptions, refunds."
        handoff_description: Billing specialist

      technical:
        instructions: "Handle technical support."

    starting_agent: triage

    run_config:
      max_turns: 10
      workflow_name: customer-support
    ```

2. **Run it**:

    ```bash
    agentflow --yaml oai_agent.yaml "I got charged twice for my subscription."
    ```

3. **Or from Python**:

    ```python
    import asyncio
    import agentflow

    async def main():
        builder = await agentflow.create("oai_agent.yaml")
        runner = builder.build()
        result = await runner.query("I got charged twice for my subscription.")
        print(result.final_output)

    asyncio.run(main())
    ```

## What's Supported

- **Peer-graph agents** — flat `agents:` dict where any agent can `handoff` to any other; `starting_agent:` picks the entry point
- **Handoffs** (the SDK's killer primitive) — string shorthand or detailed form with `tool_name_override`, `on_handoff` callback, `input_type`, `input_filter`, `is_enabled` predicate, `nest_handoff_history`
- **Hosted built-in tools** — `web_search`, `file_search`, `code_interpreter`, `image_generation`, `hosted_mcp`
- **Local built-in tools** — `computer`, `shell`, `local_shell`, `apply_patch`, `tool_search`
- **Custom Python plugins** — `@function_tool`-decorated modules with per-tool `functions:` filter
- **Multi-provider LLMs** — `openai`, `azure_openai` (RBAC via `DefaultAzureCredential`), `litellm` (200+ providers), `custom` (bring-your-own-client)
- **Guardrails** — native `InputGuardrail` / `OutputGuardrail` with `GuardrailFunctionOutput(tripwire_triggered, output_info)` semantics
- **MCP** — stdio / SSE / streamable-HTTP transports
- **Sessions** — SDK-native `SQLiteSession`, `OpenAIConversationsSession`, `RedisSession`, `SQLAlchemySession`, `MongoDBSession`
- **Persistence** — thread-id ↔ session-id bridge (memory / SQLite / Postgres), AES-GCM encryption at rest
- **Lifecycle hooks** — `RunHooks` (global) + `AgentHooks` (per-agent), every event (`on_llm_start/end`, `on_tool_start/end`, `on_agent_start/end`, `on_handoff`)
- **OpenTelemetry** — tool call spans, handoff spans, session summary with token rollup, root `agentflow.oai.run` span
- **Cross-backend plugin bridge** — existing AgentFlow lifecycle plugins (telemetry, logging, cost) work on OAI agents
- **Structured output** — `output_type` points at a Pydantic class for JSON-schema-enforced responses
- **Cross-backend portable tier** — `guards:` / `optimizers:` / `observers:` compile down to guardrails + `RunHooks` + `ModelSettings` patches

## Next Steps

- [Getting Started](GETTING_STARTED.md) — install and first agent
- [YAML Reference](YAML_REFERENCE.md) — full schema
- [Handoffs](HANDOFFS.md) — the peer-graph delegation primitive
- [Guardrails](GUARDRAILS.md) — input/output tripwires
- [Full Example](FULL_EXAMPLE.md) — enterprise YAML exercising every feature
- [Migration](MIGRATION.md) — from `workflows`, `deep`, `sk`, or `cas`

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
