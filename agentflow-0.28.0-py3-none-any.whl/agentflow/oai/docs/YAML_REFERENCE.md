# YAML Reference

Complete schema for the OAI backend. All fields are validated by Pydantic v2 at load time; invalid configs fail fast with actionable error messages.

## Top-level shape

```yaml
backend: openai-agents             # required literal
metadata: { ... }                  # required
llm: { ... }                       # top-level default (optional if every agent has its own)
agents:                            # required, non-empty
  <name>: { ... }
starting_agent: <name>             # required — must be a key in `agents:`
run_config: { ... }                # optional
guards: [ ... ]                    # optional cross-backend portable tier
optimizers: [ ... ]                # optional
observers: [ ... ]                 # optional
mcp_servers:                       # optional
  <name>: { ... }
```

## `metadata`

```yaml
metadata:
  version: "1.0"            # required
  name: customer-support    # optional
  description: "..."        # optional
  author: "..."             # optional
  tags: [support, triage]   # optional list[str]
```

## `llm`

Top-level default. Any agent can override via `agent.llm:`.

```yaml
llm:
  provider: openai | azure_openai | litellm | custom
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}    # ${VAR} interpolation
    base_url: https://...         # OpenAI — custom endpoint
    # Azure-only:
    azure_endpoint: https://...
    api_version: "2024-06-01"
    azure_identity: true          # use DefaultAzureCredential
    # LiteLLM-only:
    model_provider: anthropic     # e.g. for `litellm/anthropic/claude-3`
```

See [Services](SERVICES.md) for provider-specific detail.

## `agents` (flat dict)

Every agent is a peer. One is named in `starting_agent:` as the Runner's entry point; any agent can `handoff` to any other.

```yaml
agents:
  triage:
    instructions: "..."              # static string OR {module, function} callable ref
    handoff_description: "..."       # shown to peers considering a handoff here
    tools:
      builtin: [...]
    plugins: [...]
    mcp_servers: [<name>, ...]       # references top-level mcp_servers:
    handoffs: [...]
    model: gpt-4o                    # per-agent override
    model_settings: {...}
    llm: {...}                       # per-agent LLM override
    input_guardrails: [...]
    output_guardrails: [...]
    output_type: {...}
    tool_use_behavior: run_llm_again | stop_on_first_tool
    reset_tool_choice: true
    prompt: {...}                    # SDK Prompt passthrough
```

### `instructions`

Static prompt:

```yaml
    instructions: "You are a billing specialist."
```

Or dynamic — resolves to a callable `fn(run_context, agent) -> str`:

```yaml
    instructions:
      module: myapp.prompts
      function: build_triage_prompt
```

### `tools`

Two equivalent forms:

```yaml
    tools:
      builtin: [web_search, code_interpreter]     # bare-name form

    tools:
      builtin:
        - name: file_search                       # detailed form
          config:
            vector_store_ids: [vs_abc, vs_def]
        - web_search                              # mixed is fine
```

Valid `builtin` names: `web_search`, `file_search`, `code_interpreter`, `image_generation`, `hosted_mcp`, `computer`, `shell`, `local_shell`, `apply_patch`, `tool_search`.

### `plugins`

```yaml
    plugins:
      - name: order-tools
        type: python
        module: myapp.tools
        functions: [lookup_order, refund]   # optional — default is all @function_tool fns
```

See [Plugins](PLUGINS.md).

### `handoffs`

```yaml
    handoffs: [billing, technical]            # string shorthand

    handoffs:                                 # detailed form
      - agent: billing
        tool_name_override: to_billing
        tool_description_override: "..."
        on_handoff: {module: myapp.cb, function: log_handoff}
        input_type: {module: myapp.schemas, class_name: BillingInput}
        input_filter: {module: myapp.filters, function: trim_history}
        nest_handoff_history: false
        is_enabled: true     # or {module, function} for dynamic
```

See [Handoffs](HANDOFFS.md).

### `model_settings`

Every field on the SDK's `ModelSettings` dataclass:

```yaml
    model_settings:
      temperature: 0.2
      top_p: 0.9
      max_tokens: 1024
      parallel_tool_calls: true
      truncation: auto                # auto | disabled
      tool_choice: auto               # auto | none | required | {type, name}
      verbosity: low                  # low | medium | high
      reasoning:
        effort: low                   # low | medium | high (o1/o3/gpt-5)
        summary: concise              # auto | concise | detailed
      prompt_cache_retention: 24h     # in_memory | 24h
      include_usage: true
      metadata: {env: prod}
      store: true
      response_include: ["..."]
      top_logprobs: 3
      extra_query: {...}
      extra_body: {...}
      extra_headers: {...}
      extra_args: {...}
      retry:
        max_retries: 2
        backoff: {...}
```

#### Reasoning models — field compatibility

The **gpt-5 family** (`gpt-5`, `gpt-5-mini`, `gpt-5.4`, `gpt-5.4-mini`, …) and the **o-series** (`o1`, `o1-mini`, `o3`, `o3-mini`, `o4-mini`, …) are reasoning models and reject several classic sampling fields. Use `reasoning.effort` + `verbosity` instead.

| Field | gpt-4o / gpt-4.1 / non-reasoning | gpt-5* / o-series |
|---|---|---|
| `temperature` | ✔ any float | ✖ only default (1) — API returns 400 |
| `top_p` | ✔ | ✖ only default |
| `frequency_penalty` / `presence_penalty` | ✔ | ✖ not supported |
| `max_tokens` | ✔ | ✔ (mapped to `max_completion_tokens` internally) |
| `parallel_tool_calls` | ✔ | ✔ |
| `tool_choice` | ✔ | ✔ |
| `verbosity` (`low` / `medium` / `high`) | ✔ | ✔ — recommended |
| `reasoning.effort` (`low` / `medium` / `high`) | ignored | ✔ — recommended |
| `prompt_cache_retention` | ✔ | ✔ |

AgentFlow detects reasoning models by name (including Azure deployment names like `csdep-…-gpt-5-mini`) and emits a startup warning when you set an incompatible field:

```
WARNING agentflow.oai: agent 'orchestrator' uses reasoning model
'csdep-30429803-gpt-5-mini' but sets temperature=0.2 (only the default (1)
is accepted). The API will likely return 400. Use `reasoning.effort` +
`verbosity` for reasoning models, or switch to a non-reasoning deployment
(gpt-4o / gpt-4.1).
```

The field is still forwarded — the warning doesn't strip or override it — but you'll see the mistake at build time instead of via a 400 mid-run. Per-agent `llm:` overrides let you mix reasoning and non-reasoning models in one graph:

```yaml
agents:
  router:
    # Reasoning — use effort/verbosity
    model_settings:
      reasoning: {effort: medium}
      verbosity: low

  writer:
    # Non-reasoning — classic knobs OK
    llm:
      provider: azure_openai
      config: {azure_deployment: csdep-…-gpt-4o, ...}
    model_settings:
      temperature: 0.7
      top_p: 0.9
      max_tokens: 2000
```

### `input_guardrails` / `output_guardrails`

```yaml
    input_guardrails:
      - module: myapp.guardrails
        function: check_safety
        name: safety_check          # optional display name
        run_in_parallel: true       # optional, input-guardrails only
```

See [Guardrails](GUARDRAILS.md).

### `output_type`

Pydantic class reference for JSON-schema-enforced responses:

```yaml
    output_type:
      module: myapp.schemas
      class_name: BillingResolution
```

## `starting_agent`

```yaml
starting_agent: triage
```

Must be a key in `agents:`. The validator rejects configs where it doesn't match.

## `run_config`

Session-level knobs mapping to the SDK's `RunConfig`:

```yaml
run_config:
  max_turns: 10                           # Runner.run(max_turns=...)
  workflow_name: "customer-support"
  trace_id: "trace_..."                   # optional custom trace id
  group_id: "..."                         # optional
  trace_metadata: {env: prod}
  tracing_disabled: false
  trace_include_sensitive_data: true
  nest_handoff_history: false
  sandbox:                                # beta — passthrough
    backend: docker | e2b | modal | ...
    config: {...}
  model: gpt-4o-mini                      # per-run override
  model_settings: {...}                   # per-run override
  input_guardrails: [...]                 # run-level (before agent-level)
  output_guardrails: [...]
```

## `guards` / `optimizers` / `observers` (cross-backend portable tier)

These enum values are **identical across SK, CAS, and OAI** so YAML migrates mechanically.

```yaml
guards:
  - type: pii
    config:
      patterns: [email, phone, ssn, credit_card]
  - type: tool_call_limit
    config: {max_calls: 50}
  - type: model_call_limit
    config: {max_calls: 100}
  - type: input_validation
    module: myapp.guards
    function: validate
  - type: content_filter
    module: myapp.guards
    function: filter_output

optimizers:
  - type: tool_retry
    config: {max_retries: 2, backoff: {...}}
  - type: summarization
    config: {trigger_messages: 40, keep_messages: 10}
  - type: prompt_caching
    config: {retention: 24h}               # in_memory | 24h

observers:
  - type: audit_log
  - type: cost_tracking
    config: {budget_limit: 5.00}
  - type: latency_tracking
```

See [Guards / Optimizers / Observers](GUARDS.md) for compilation details.

## `mcp_servers`

```yaml
mcp_servers:
  local-data:
    transport: stdio                       # stdio | sse | http
    command: npx
    args: [-y, "@modelcontextprotocol/server-filesystem", "/tmp"]
    env: {DEBUG: "1"}
    cwd: /opt/app
    # common options
    cache_tools_list: true
    use_structured_content: true
    max_retry_attempts: 3
    retry_backoff_seconds_base: 1.0
    client_session_timeout_seconds: 10
    require_approval: false

  remote-data:
    transport: http                        # or sse
    url: https://mcp.example.com
    headers: {Authorization: "Bearer ${MCP_TOKEN}"}
    timeout: 30
    sse_read_timeout: 300
    terminate_on_close: true
```

Agents reference these by name via `agents.<name>.mcp_servers: [local-data, ...]`. See [MCP](MCP.md).

## Validator rules

The root `OaiYAMLConfig` model validator enforces:

1. **Non-empty agents** — `agents:` must have at least one entry.
2. **starting_agent exists** — must be a key in `agents:`.
3. **Handoff targets exist** — every `handoffs: [...]` entry must name a known agent.
4. **MCP references resolve** — every `agent.mcp_servers: [name]` entry must exist in top-level `mcp_servers:`.
5. **At least one LLM** — either top-level `llm:` or `agents.<starting_agent>.llm:` must be set.

## Environment variable interpolation

Any `${VAR}` in a string value is resolved against `os.environ` (and `.env` in cwd) before validation. Missing vars raise a clear error.

```yaml
llm:
  config:
    api_key: ${OPENAI_API_KEY}
    base_url: ${OPENAI_BASE_URL:-https://api.openai.com/v1}
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
