# Production Features

The OAI backend is ready for enterprise deployment. Every feature below ships out of the box — no third-party middleware required.

## Enterprise feature matrix

| Feature | How |
|---|---|
| **Multi-provider LLM routing** | `llm.provider: openai \| azure_openai \| litellm \| custom`; per-agent override via `agent.llm:` |
| **Azure RBAC** | `azure_identity: true` → `DefaultAzureCredential` + `get_bearer_token_provider` |
| **Budget enforcement** | `observers[].type: cost_tracking` with `budget_limit`; `guards[].type: model_call_limit` / `tool_call_limit` |
| **PII detection** | `guards[].type: pii` with named regex patterns, or custom guardrail module |
| **Content filtering** | `guards[].type: content_filter` → `OutputGuardrail` |
| **Structured output** | `agent.output_type: {module, class_name}` — JSON-schema-enforced responses |
| **Retry with backoff** | `optimizers[].type: tool_retry` → `ModelSettings.retry` |
| **Prompt caching** | `optimizers[].type: prompt_caching` → `ModelSettings.prompt_cache_retention` |
| **Tracing (OTel + `gen_ai.*`)** | `OTEL_TRACES_ENABLED=true`; observer spans + session summary |
| **Native SDK tracing** | `run_config.tracing_disabled: false` — OpenAI dashboard |
| **Persistence / resume** | `--persistence sqlite|postgres` + `--thread-id` |
| **Encryption at rest** | `AGENTFLOW_ENCRYPTION_KEY` — AES-GCM for binding table |
| **MCP** | stdio / SSE / StreamableHttp; servers referenced by name |
| **Sandbox (beta)** | `run_config.sandbox: {backend: docker|e2b|modal|...}` |
| **Guardrails (native)** | `input_guardrails: [...]` / `output_guardrails: [...]` per agent or run-wide |
| **Lifecycle hooks** | `RunHooks` (composite) + `AgentHooks` (per agent) |
| **Cross-backend plugins** | `plugin_bridge` — existing AgentFlow lifecycle plugins work unchanged |
| **YAML env interpolation** | `${VAR}` with `.env` auto-loading from cwd |
| **Cross-backend portable tier** | `guards:` / `optimizers:` / `observers:` enum vocabulary identical across SK / CAS / OAI |

## Deployment checklist

- [ ] `OPENAI_API_KEY` (or Azure creds) in env
- [ ] `OTEL_TRACES_ENABLED=true` + `OTEL_EXPORTER_OTLP_ENDPOINT` set
- [ ] Picked a persistence backend (`sqlite` for single-instance, `postgres` for multi-instance)
- [ ] `AGENTFLOW_ENCRYPTION_KEY` set if regulatory requirements apply
- [ ] `observers:` declared: `audit_log`, `cost_tracking` (with `budget_limit`), `latency_tracking`
- [ ] `guards:` declared: `pii`, `tool_call_limit`, `model_call_limit`
- [ ] YAML validated with `agentflow --yaml oai_agent.yaml --dry-run`
- [ ] Log level configured (`AGENTFLOW_LOG_LEVEL=INFO` for production)

## Example production YAML

```yaml
backend: openai-agents

metadata:
  version: "1.0"
  name: customer-support-prod
  description: Triage → billing/technical with full guardrails + observability

llm:
  provider: azure_openai
  config:
    model: gpt-4o-prod
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true

agents:
  triage:
    instructions: "Route user questions to the right specialist."
    handoffs: [billing, technical]
    tools:
      builtin: [web_search]
    model_settings:
      temperature: 0.2
      parallel_tool_calls: true

  billing:
    instructions: "Handle billing, subscriptions, refunds."
    handoff_description: Billing specialist
    plugins:
      - name: billing-api
        module: myapp.billing
    output_type:
      module: myapp.schemas
      class_name: BillingResolution

  technical:
    instructions: "Handle technical support."
    handoff_description: Technical support
    plugins:
      - name: kb-search
        module: myapp.kb

starting_agent: triage

run_config:
  max_turns: 15
  workflow_name: customer-support-prod
  tracing_disabled: false
  trace_metadata: {env: prod, service: support-desk}

guards:
  - type: pii
    config: {patterns: [email, phone, ssn, credit_card]}
  - type: tool_call_limit
    config: {max_calls: 50}
  - type: model_call_limit
    config: {max_calls: 20}
  - type: content_filter
    module: myapp.guardrails
    function: filter_output

optimizers:
  - type: tool_retry
    config: {max_retries: 2}
  - type: prompt_caching
    config: {retention: 24h}

observers:
  - type: audit_log
  - type: cost_tracking
    config: {budget_limit: 10.00}
  - type: latency_tracking

mcp_servers:
  kb:
    transport: http
    url: https://mcp.internal/v1/kb
    headers: {Authorization: "Bearer ${MCP_TOKEN}"}
    cache_tools_list: true
```

```bash
export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -hex 32 | cut -c1-64)"
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=https://otel-collector.internal:4317

agentflow \
  --yaml oai_agent.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id "$(uuidgen)" \
  "I got charged twice last month."
```

## Backend comparison

| Feature | Workflows | Deep | SK | CAS | **OAI** |
|---|---|---|---|---|---|
| Peer-graph agents | - | - | - | - | ✓ |
| Handoffs (native) | - | - | orchestration mode | Task-tool delegation | ✓ |
| Hosted tools (web_search, file_search, code_interpreter) | - | - | - | - | ✓ |
| Structured output (Pydantic) | ✓ | ✓ | ✓ | - | ✓ |
| Guardrails (tripwire) | - | - | filters | hooks | ✓ |
| Sessions (SDK-native) | - | - | - | - | ✓ |
| MCP | ✓ | - | ✓ | ✓ | ✓ |
| Azure RBAC | ✓ | ✓ | ✓ | - | ✓ |
| LiteLLM multi-provider | - | - | - | - | ✓ |
| Persistence | SQLite/Postgres | SQLite/Postgres | SQLite/Postgres | SQLite/Postgres | SQLite/Postgres/Redis/SQLA/Mongo/OpenAI-hosted |
| Cost tracking | ✓ | ✓ | ✓ | ✓ | ✓ |
| OTel `gen_ai.*` spans | ✓ | ✓ | ✓ | ✓ | ✓ |
| Plugin bridge | - | - | ✓ | ✓ | ✓ |
| Sandbox (beta) | - | - | - | - | ✓ |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
