# Handoffs

Handoffs are the OpenAI Agents SDK's distinguishing primitive — one agent delegates to another, and the second agent takes over the conversation. AgentFlow treats them as first-class YAML: any agent can declare `handoffs: [...]`.

## Shorthand

```yaml
agents:
  triage:
    instructions: "Route user questions."
    handoffs: [billing, technical]
```

Each string names a peer in the `agents:` dict. The validator rejects unknown targets at load time.

## Detailed form

For control over the tool name the LLM sees, callback wiring, input schema, or history filtering, switch to the dict form:

```yaml
agents:
  triage:
    instructions: "..."
    handoffs:
      - agent: billing
        tool_name_override: transfer_to_billing_specialist
        tool_description_override: >
          Use when the user asks about invoices, subscriptions, or refunds.
        on_handoff:
          module: myapp.callbacks
          function: on_handoff_to_billing
        input_type:
          module: myapp.schemas
          class_name: BillingHandoffInput
        input_filter:
          module: myapp.filters
          function: trim_history_for_billing
        nest_handoff_history: false
        is_enabled: true
```

Mixed lists (some shorthand, some detailed) work fine.

## Handoff field reference

| Field | Type | Purpose |
|---|---|---|
| `agent` | str | Target agent name (required) |
| `tool_name_override` | str | Name the LLM sees for the handoff tool (default: `transfer_to_<agent>`) |
| `tool_description_override` | str | What the LLM reads when deciding whether to hand off |
| `on_handoff` | `{module, function}` | Async callback invoked when handoff triggers |
| `input_type` | `{module, class_name}` | Pydantic schema for structured handoff input |
| `input_filter` | `{module, function}` | Trim / rewrite history before the receiver sees it |
| `nest_handoff_history` | bool | Whether the receiver sees the prior conversation |
| `is_enabled` | bool or `{module, function}` | Static or runtime gate on handoff availability |

## The `on_handoff` callback

```python
# myapp/callbacks.py
async def on_handoff_to_billing(context) -> None:
    # observability, audit log, state mutation…
    print(f"Handoff fired in workflow {context.workflow_name}")
```

Invoked before the receiving agent starts. Receives the `RunContextWrapper`.

## Structured handoff input

If you want the LLM to pass typed data to the receiver:

```python
# myapp/schemas.py
from pydantic import BaseModel

class BillingHandoffInput(BaseModel):
    order_id: str
    reason: str
```

```yaml
        input_type:
          module: myapp.schemas
          class_name: BillingHandoffInput
```

The handoff tool's parameters become `BillingHandoffInput`'s fields, so the LLM emits them as part of the handoff call and they flow into the `on_handoff` callback.

## Input filters

Trim conversation history before the target agent starts:

```python
# myapp/filters.py
def trim_history_for_billing(handoff_input_data):
    # Keep only messages relevant to billing
    return [m for m in handoff_input_data.messages if "billing" in m.content.lower()]
```

Pair with `nest_handoff_history: false` for fresh-start handoffs.

## Dynamic handoffs with `is_enabled`

Gate handoff availability by runtime state:

```python
# myapp/gates.py
async def has_billing_role(context, agent) -> bool:
    return getattr(context.user, "role", None) == "billing"
```

```yaml
    handoffs:
      - agent: billing
        is_enabled:
          module: myapp.gates
          function: has_billing_role
```

Static values (`true` / `false`) work too — useful for feature-flagging a new agent without code changes.

## Handoff vs tool call vs subagent

| Concept | OAI (SDK-native) | CAS analog | SK analog |
|---|---|---|---|
| Handoff | Yes — first class | Delegation via built-in `Task` tool | "Handoff" orchestration mode |
| Tool call | Yes | Yes | Yes |
| Subagent hierarchy | No (flat peer graph) | Main + `agents:` dict | Group / orchestration modes |

Handoffs are **unidirectional** at the moment of dispatch — control transfers to the target. For round-trip delegation, give the target a handoff back to the caller.

## Common patterns

**Triage**

```yaml
starting_agent: triage
agents:
  triage: {handoffs: [billing, technical]}
  billing: {}
  technical: {}
```

**Supervisor with specialists that return**

```yaml
starting_agent: supervisor
agents:
  supervisor: {handoffs: [researcher, writer]}
  researcher: {handoffs: [supervisor]}
  writer: {handoffs: [supervisor]}
```

**Role-gated handoffs**

```yaml
    handoffs:
      - agent: refund_bot
        is_enabled: {module: myapp.gates, function: can_refund}
      - agent: escalate_to_human
        is_enabled: {module: myapp.gates, function: always}
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
