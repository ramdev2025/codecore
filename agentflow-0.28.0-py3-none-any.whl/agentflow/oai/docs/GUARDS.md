# Guards / Optimizers / Observers

AgentFlow's cross-backend portable tier lets you express intent — "limit tool calls to 50", "track cost", "retry flaky tools" — in YAML keys that are **identical across SK, CAS, and OAI**. The OAI compiler translates them to SDK-native primitives at build time.

```yaml
guards: [...]        # constrain execution
optimizers: [...]    # improve efficiency
observers: [...]     # watch without modifying
```

## Compilation table

| YAML entry | Compiles to | SDK primitive |
|---|---|---|
| `guards[].type: pii` | `InputGuardrail` | `pii` input guardrail with named regex patterns |
| `guards[].type: tool_call_limit` | `RunHooks` counter | Raises `RuntimeError` when `on_tool_start` count exceeds `max_calls` |
| `guards[].type: model_call_limit` | `RunHooks` counter | Raises when `on_llm_start` count exceeds `max_calls` |
| `guards[].type: input_validation` | `InputGuardrail` | Wraps your `(context, agent, input) → GuardrailFunctionOutput` |
| `guards[].type: content_filter` | `OutputGuardrail` | Wraps your `(context, agent, output) → GuardrailFunctionOutput` |
| `optimizers[].type: tool_retry` | `ModelSettings.retry` + log hook | SDK-native retry (max_retries, backoff); hook logs attempts |
| `optimizers[].type: summarization` | `RunHooks.on_handoff` log | Logs handoff events; SDK has no pre-compaction hook |
| `optimizers[].type: prompt_caching` | `ModelSettings.prompt_cache_retention` | SDK-native prompt caching |
| `observers[].type: audit_log` | `RunHooks` | `on_tool_start/end` → `gen_ai.execute_tool` span |
| `observers[].type: cost_tracking` | `RunHooks` | `on_llm_end` accumulates usage; `on_agent_end` emits `gen_ai.agent_end` span |
| `observers[].type: latency_tracking` | `RunHooks` | `on_tool_start/end` → `agentflow.tool.latency` span |

All observer hooks are combined via `compose_hooks()` into one composite `RunHooks` instance passed to the runner.

## Guards — examples

```yaml
guards:
  - type: pii
    config:
      patterns: [email, phone]          # default: [email, phone, ssn, credit_card]

  - type: tool_call_limit
    config: {max_calls: 50}

  - type: model_call_limit
    config: {max_calls: 100}

  - type: input_validation
    module: myapp.guards
    function: ensure_non_empty

  - type: content_filter
    module: myapp.guards
    function: check_pii_in_output
```

### Named PII patterns

| Name | Regex |
|---|---|
| `email` | `[\w\.-]+@[\w\.-]+` |
| `phone` | `\b(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b` |
| `ssn` | `\b\d{3}-\d{2}-\d{4}\b` |
| `credit_card` | `\b(?:\d[ -]*?){13,16}\b` |

Unknown names are treated as raw regex strings, so you can mix:

```yaml
    config:
      patterns: [email, '\b[A-Z]{2}\d{6}\b']    # email + custom tracking id
```

## Optimizers — examples

```yaml
optimizers:
  - type: tool_retry
    config: {max_retries: 2, backoff: {initial_ms: 500, max_ms: 10000}}

  - type: prompt_caching
    config: {retention: 24h}               # in_memory | 24h

  - type: summarization
    config: {trigger_messages: 40, keep_messages: 10}
```

**Design note.** Unlike CAS (where optimizers compile to hooks), OAI's SDK handles `tool_retry` and `prompt_caching` natively via `ModelSettings`. The compiler patches the top-level `ModelSettings` instead of emitting hooks. You get the benefit of SDK-native retries instead of reinventing backoff in userland.

## Observers — examples

```yaml
observers:
  - type: audit_log

  - type: cost_tracking
    config: {budget_limit: 5.00}

  - type: latency_tracking

  # Custom observer
  - type: audit_log
    module: myapp.observers
    function: forward_to_slack
```

Custom observer functions receive `(tool_name, result)` on each `on_tool_end`.

## Combining with per-agent guardrails

Run-level guardrails (from `guards:`) apply globally. For agent-specific ones, use `input_guardrails:` / `output_guardrails:` on the agent:

```yaml
guards:
  - type: pii                              # every agent

agents:
  billing:
    instructions: "..."
    output_guardrails:                     # billing-only
      - module: myapp.guardrails
        function: check_refund_cap
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
