# Services — LLM Providers

The OAI backend supports four providers. Each is selected via `llm.provider:` and configured through `llm.config:`.

## openai (default)

```yaml
llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}
    base_url: https://api.openai.com/v1   # optional — custom OpenAI-compatible endpoint
```

The `api_key` field, if set, bridges to the `OPENAI_API_KEY` environment variable (the SDK reads the env var at client-construction time). `base_url` is useful for proxies or OpenAI-compatible servers (Groq, Together, Fireworks, etc. that follow the Chat Completions API).

## azure_openai

```yaml
llm:
  provider: azure_openai
  config:
    model: gpt-4o-mini                   # deployment name
    api_key: ${AZURE_OPENAI_API_KEY}     # OR leave unset + set azure_identity: true
    azure_endpoint: https://my-resource.openai.azure.com
    api_version: "2024-06-01"
    azure_identity: false                # true → DefaultAzureCredential
```

Two auth styles:

- **API key** — set `api_key:` (or env `AZURE_OPENAI_API_KEY`)
- **Azure RBAC** — set `azure_identity: true`. Requires `azure-identity` installed (already a transitive dep). Uses `DefaultAzureCredential` + `get_bearer_token_provider(...)` under the hood.

Azure OpenAI currently implements **Chat Completions** only (not the Responses API), so AgentFlow calls `set_default_openai_api("chat_completions")` for you.

### Example — managed identity in Azure Container Apps

```yaml
llm:
  provider: azure_openai
  config:
    model: gpt-4o-prod
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true
```

## litellm

[LiteLLM](https://docs.litellm.ai/) provides a unified OpenAI-compatible facade over 200+ providers (Anthropic, Gemini, Bedrock, Ollama, …). Use this to mix non-OpenAI models in the same agent graph.

```bash
pip install 'agentflow[openai-agents]' 'openai-agents[litellm]'
```

```yaml
llm:
  provider: litellm
  config:
    model: "litellm/anthropic/claude-sonnet-4-6"
    api_key: ${ANTHROPIC_API_KEY}        # or AWS creds for Bedrock, etc.
```

Any agent can carry its own `llm:` block, so you can mix providers in one run:

```yaml
agents:
  planner:
    instructions: "Plan the approach."
    llm:
      provider: openai
      config: {model: gpt-4o}
  coder:
    instructions: "Write the code."
    llm:
      provider: litellm
      config:
        model: "litellm/anthropic/claude-sonnet-4-6"
        api_key: ${ANTHROPIC_API_KEY}
```

## custom

"I already configured the OpenAI client myself." The builder skips all client setup.

```yaml
llm:
  provider: custom
  config:
    model: gpt-4o
```

```python
# before agentflow.create(...)
from agents import AsyncOpenAI, set_default_openai_client
set_default_openai_client(AsyncOpenAI(base_url="https://my-proxy.internal"))
```

Use cases:

- Custom retry / rate-limiting / telemetry middleware
- Internal auth gateway with on-behalf-of tokens
- Hard-coded org id in a dev environment

## Per-agent provider override

The `llm:` field at the root of the YAML is the default; any agent can override:

```yaml
llm:
  provider: openai
  config: {model: gpt-4o-mini}

agents:
  triage:
    instructions: "..."
    # uses default

  specialist:
    instructions: "..."
    llm:
      provider: azure_openai
      config:
        model: gpt-4o-prod
        azure_endpoint: https://prod.openai.azure.com
        api_version: "2024-06-01"
        azure_identity: true
```

Validator rule 5 says at least one of top-level `llm:` or `agents.<starting_agent>.llm:` must be set. Other agents without an `llm:` block inherit the top-level default.

## Reasoning vs non-reasoning models

Several knobs in `model_settings` (`temperature`, `top_p`, `frequency_penalty`, `presence_penalty`) are rejected by reasoning models (gpt-5 family, o-series) with a 400. AgentFlow detects this at build time and warns on the `agentflow.oai` logger. See [YAML Reference → `model_settings` → Reasoning models](YAML_REFERENCE.md#reasoning-models-field-compatibility) for the full field-compatibility table and per-agent mixing pattern.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
