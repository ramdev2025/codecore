# Full Example

An annotated, production-grade YAML exercising every feature: peer-graph agents, handoffs, hosted + local tools, custom plugins, per-agent Azure RBAC, MCP, guardrails, structured output, cost tracking, and OTel tracing.

## Scenario — enterprise customer support

A three-agent triage system for an insurance SaaS product:

1. **triage** — routes incoming questions
2. **claims** — handles claim lookups + policy checks (structured output)
3. **tech_support** — handles product bugs and feature questions

## YAML

```yaml
# oai_agent.yaml
backend: openai-agents

metadata:
  version: "1.0"
  name: insurance-support
  description: Triage + claims + tech support with guardrails and observability
  author: Customer Support Platform team
  tags: [insurance, support, production]

# -- Default LLM ---------------------------------------------------------
# All agents inherit this unless they declare their own `llm:`.
llm:
  provider: azure_openai
  config:
    model: gpt-4o-prod                   # Azure deployment name
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: "2024-06-01"
    azure_identity: true                 # DefaultAzureCredential

# -- Agents (peer graph) -------------------------------------------------
agents:

  triage:
    instructions: |
      You route incoming user questions to the right specialist agent.
      For billing / coverage / claim-status questions, hand off to `claims`.
      For product bugs, app crashes, feature questions, hand off to `tech_support`.
      For anything ambiguous, ask one clarifying question first.
    handoffs:
      - agent: claims
        tool_description_override: >
          Claims specialist — use for policy details, claim status,
          coverage verification, refund authorization.
      - agent: tech_support
        tool_description_override: >
          Technical support — use for app bugs, crashes, feature inquiries,
          and account configuration.
    tools:
      builtin: [web_search]              # public help-desk articles
    model_settings:
      temperature: 0.1                   # deterministic routing
      parallel_tool_calls: false         # one handoff at a time

  claims:
    instructions: |
      You are a claims specialist. Look up the user's policy and claim status
      using the tools below, then produce a structured resolution.
    handoff_description: Claims & policy specialist
    plugins:
      - name: claims-api
        module: myapp.claims
        functions: [lookup_policy, lookup_claim, authorize_refund]
    mcp_servers: [knowledge-base]        # cross-reference our KB
    output_type:                         # JSON-schema-enforced
      module: myapp.schemas
      class_name: ClaimsResolution
    input_guardrails:
      - module: myapp.guardrails
        function: require_policy_id
    output_guardrails:
      - module: myapp.guardrails
        function: check_refund_authority
    model_settings:
      temperature: 0.0                   # fully deterministic for money
      verbosity: medium
      retry:
        max_retries: 3
        backoff: {initial_ms: 500, max_ms: 5000}

  tech_support:
    instructions: |
      You are a technical support agent. Investigate the issue, check the
      knowledge base, and produce a numbered resolution with steps.
    handoff_description: Technical support
    plugins:
      - name: diagnostics
        module: myapp.diagnostics
    tools:
      builtin:
        - name: file_search
          config:
            vector_store_ids: ["${VECTOR_STORE_ID_RUNBOOKS}"]
    mcp_servers: [knowledge-base]
    # Uses a cheaper model just for this specialist
    llm:
      provider: openai
      config:
        model: gpt-4o-mini
        api_key: ${OPENAI_API_KEY}

starting_agent: triage

# -- Session-level knobs -------------------------------------------------
run_config:
  max_turns: 20
  workflow_name: insurance-support
  tracing_disabled: false                # emit OpenAI dashboard traces too
  trace_include_sensitive_data: false    # compliance
  trace_metadata:
    env: production
    team: customer-support
    deploy_id: ${DEPLOY_ID}
  nest_handoff_history: true             # specialists see the triage context

# -- Cross-backend portable tier -----------------------------------------
guards:
  - type: pii
    config: {patterns: [email, phone, ssn, credit_card]}
  - type: tool_call_limit
    config: {max_calls: 40}
  - type: model_call_limit
    config: {max_calls: 15}              # hard ceiling on billing loops
  - type: input_validation
    module: myapp.guardrails
    function: require_english

optimizers:
  - type: tool_retry
    config: {max_retries: 2}
  - type: prompt_caching
    config: {retention: 24h}
  - type: summarization
    config: {trigger_messages: 40, keep_messages: 10}

observers:
  - type: audit_log
  - type: cost_tracking
    config: {budget_limit: 8.00}         # abort if costs exceed $8 per run
  - type: latency_tracking

# -- External MCP servers ------------------------------------------------
mcp_servers:
  knowledge-base:
    transport: http
    url: https://mcp.internal/v1/kb
    headers:
      Authorization: "Bearer ${KB_MCP_TOKEN}"
    cache_tools_list: true
    max_retry_attempts: 3
    retry_backoff_seconds_base: 1.0
    client_session_timeout_seconds: 10.0
```

## Supporting Python

```python
# myapp/schemas.py
from pydantic import BaseModel, Field
from typing import Literal


class ClaimsResolution(BaseModel):
    claim_id: str
    policy_id: str
    resolution: Literal["approved", "denied", "need-info"]
    refund_amount_usd: float = Field(0.0, ge=0)
    next_steps: list[str]
    customer_message: str
```

```python
# myapp/claims.py
from agents import function_tool

@function_tool
async def lookup_policy(policy_id: str) -> dict:
    """Look up a policy by its id."""
    # fetch from internal system...
    return {...}

@function_tool
async def lookup_claim(claim_id: str) -> dict:
    """Look up a claim by its id."""
    return {...}

@function_tool(needs_approval=True)
async def authorize_refund(claim_id: str, amount_usd: float, reason: str) -> dict:
    """Authorize a refund. Requires approval."""
    return {...}
```

```python
# myapp/guardrails.py
from agents import GuardrailFunctionOutput

async def require_policy_id(context, agent, input_data):
    text = input_data if isinstance(input_data, str) else ""
    has_id = any(t.startswith("POL-") for t in text.split())
    return GuardrailFunctionOutput(
        output_info={"has_policy_id": has_id},
        tripwire_triggered=not has_id,
    )

async def check_refund_authority(context, agent, output):
    # output is a ClaimsResolution instance
    max_authority = 10_000
    return GuardrailFunctionOutput(
        output_info={"amount": output.refund_amount_usd},
        tripwire_triggered=output.refund_amount_usd > max_authority,
    )

async def require_english(context, agent, input_data):
    # naïve language check
    text = input_data if isinstance(input_data, str) else ""
    is_english = all(ord(c) < 128 for c in text[:200])
    return GuardrailFunctionOutput(
        output_info={"is_english": is_english},
        tripwire_triggered=not is_english,
    )
```

## Run

```bash
# Dry-run first to validate
agentflow --yaml oai_agent.yaml --dry-run

# Actual run with tracing + Postgres persistence
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=https://otel-collector.internal:4317
export AGENTFLOW_ENCRYPTION_KEY=$(openssl rand -hex 32 | cut -c1-64)

agentflow \
  --yaml oai_agent.yaml \
  --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id "customer-$(uuidgen)" \
  "My policy POL-42 — why was my last claim denied?"
```

## What gets emitted

Per run, with observers + tracing on:

- One `agentflow.oai.run` root span (with `agentflow.thread_id`, `agentflow.backend=openai-agents`, rolled-up `gen_ai.usage.*`)
- One `gen_ai.execute_tool <name>` span per tool invocation (nested)
- One `agentflow.tool.latency <name>` span per invocation (latency in ms)
- One `gen_ai.agent_end` span per agent (token breakdown)
- One `gen_ai.session_summary` child span at the end

If a guardrail trips (PII detected, policy-id missing, refund over authority), the run aborts with a typed exception and the spans capture what tripped.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
