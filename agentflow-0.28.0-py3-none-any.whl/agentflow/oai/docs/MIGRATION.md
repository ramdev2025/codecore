# Migration Guide

If you already have a YAML for another AgentFlow backend, here's how to port it to OAI.

## From `cas` (Claude Agent SDK)

CAS and OAI share a surprising amount — both are single-framework SDK backends with hooks, tools, guardrails, and MCP. The biggest structural differences:

| CAS | OAI |
|---|---|
| `backend: claude-agent-sdk` | `backend: openai-agents` |
| `agent:` (single) + `agents:` (subagents dict) | flat `agents:` dict + `starting_agent:` pointer |
| Subagent delegation via built-in `Task` tool | Native `handoffs:` on any agent |
| `llm.provider: anthropic` | `llm.provider: openai` |
| Preset `claude_code` (11 tools) | No preset; list `builtin:` explicitly |
| Hooks (10 events, explicit matchers) | `RunHooks` (7 events, no matchers) |
| `permission_mode:` + allow/deny lists | Permissions not exposed in OAI (the SDK doesn't have an equivalent) |

### Porting template

Before (CAS):

```yaml
backend: claude-agent-sdk
metadata: {version: "1.0"}
llm:
  provider: anthropic
  config:
    model: claude-opus-4-7
    api_key: ${ANTHROPIC_API_KEY}
agent:
  name: researcher
  system_prompt: "You are a researcher."
  tools:
    preset: claude_code
agents:
  summarizer:
    system_prompt: "You summarize findings."
```

After (OAI):

```yaml
backend: openai-agents
metadata: {version: "1.0"}
llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}
agents:
  researcher:
    instructions: "You are a researcher. Delegate summary work."
    handoffs: [summarizer]
    tools:
      builtin: [web_search, code_interpreter]    # pick explicitly
  summarizer:
    instructions: "You summarize findings."
starting_agent: researcher
```

## From `sk` (Semantic Kernel)

| SK | OAI |
|---|---|
| `backend: semantic-kernel` | `backend: openai-agents` |
| `agent:` (singular) OR `agents:` + `orchestration:` | flat `agents:` + `starting_agent:` + handoffs |
| `services:` + per-agent `service:` ref | `llm:` + per-agent `llm:` |
| Filters (`guards:` / `optimizers:` / `observers:`) | Same YAML keys — vocabulary is identical |
| Plugins (`type: python`) | Same shape, same decorator (`@function_tool`) |
| `plugins.<name>.functions: [...]` | Same |

Orchestration modes map to handoff patterns:

| SK orchestration | OAI pattern |
|---|---|
| Sequential | Chain via `handoffs` (A → B → C) |
| Concurrent | Single agent with `parallel_tool_calls: true` + many tools |
| Handoff | Native `handoffs:` (the SDK primitive) |
| GroupChat | Peer-graph with `handoffs: [everyone_else]` |
| Magentic | Not directly supported; approximate with a supervisor agent |

### Porting template

Before (SK, handoff mode):

```yaml
backend: semantic-kernel
metadata: {version: "1.0"}
services:
  gpt4o:
    provider: openai
    config: {model: gpt-4o-mini, api_key: ${OPENAI_API_KEY}}
agents:
  triage:
    service: gpt4o
    system_prompt: "Route questions."
  billing:
    service: gpt4o
    system_prompt: "Handle billing."
orchestration:
  mode: handoff
  start: triage
```

After (OAI):

```yaml
backend: openai-agents
metadata: {version: "1.0"}
llm:
  provider: openai
  config: {model: gpt-4o-mini, api_key: ${OPENAI_API_KEY}}
agents:
  triage:
    instructions: "Route questions."
    handoffs: [billing]
  billing:
    instructions: "Handle billing."
    handoff_description: Billing specialist
starting_agent: triage
```

## From `deep` (DeepAgents)

The Deep backend's single-agent + built-in planning/filesystem tools is a different mental model. To port:

- Treat `agent:` as the single entry in OAI's `agents:` dict.
- Map DeepAgents subagents (if any) to OAI peers with `handoffs:`.
- There's no drop-in replacement for DeepAgents' filesystem preset — use custom `@function_tool` plugins or the SDK's `apply_patch` / `local_shell` built-ins.

## From `workflows` (LangGraph)

Workflows is graph-based (nodes + edges). OAI is agent-based. Porting isn't mechanical; you reshape the graph as an agent network:

- Node that "decides" → agent with `handoffs:` to downstream nodes
- Node that "does" → agent with tools, no handoffs
- Conditional edge → `is_enabled:` predicate on the handoff

If your workflow is primarily a sequence of deterministic steps, **don't** migrate — workflows does that better. Migrate when the routing/delegation is primarily LLM-driven.

## Flags that stay the same

Every cross-backend flag means the same thing on OAI:

- `--yaml`, `--backend`, `--query`, `--interactive`, `--dry-run`, `--json`
- `--thread-id`, `--persistence`, `--db-path`, `--connection-string`
- `AGENTFLOW_ENCRYPTION_KEY`, `OTEL_TRACES_ENABLED`, etc.

## The portable tier migrates mechanically

```yaml
guards:
  - type: pii
    config: {patterns: [email, phone]}
  - type: tool_call_limit
    config: {max_calls: 50}

optimizers:
  - type: prompt_caching
    config: {retention: 24h}

observers:
  - type: audit_log
  - type: cost_tracking
    config: {budget_limit: 5.00}
  - type: latency_tracking
```

These blocks are identical on SK, CAS, and OAI. Copy-paste and forget.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
