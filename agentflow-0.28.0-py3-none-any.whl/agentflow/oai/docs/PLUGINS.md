# Plugins — Custom Python Tools

A **plugin** in AgentFlow OAI is a Python module containing `@function_tool`-decorated functions. The builder imports the module, collects every decorated function, and wires them into the agent's `tools:` list.

## Author a plugin

```python
# myapp/tools.py
from agents import function_tool

@function_tool
async def lookup_order(order_id: str) -> dict:
    """Look up an order by ID.

    Args:
        order_id: The order's ID (e.g. 'ORD-12345').
    """
    # your impl
    return {"id": order_id, "status": "shipped"}


@function_tool
async def issue_refund(order_id: str, reason: str) -> dict:
    """Issue a refund for the given order."""
    return {"order_id": order_id, "refunded": True}
```

The `@function_tool` decorator generates the JSON schema from type hints + docstring, so LLMs call your function with structured arguments.

## Reference from YAML

```yaml
agents:
  billing:
    instructions: "Handle billing inquiries."
    plugins:
      - name: order-tools
        type: python          # default; only 'python' is valid today
        module: myapp.tools
        functions:            # optional — defaults to all @function_tool fns
          - lookup_order
          - issue_refund
```

Omit `functions:` to expose every decorated function in the module.

## Per-tool options

Options like `needs_approval`, `strict_json_schema`, and `failure_error_function` live on the `@function_tool` decorator in user code, not in YAML. This keeps Python type-checkers honest about the contract.

```python
@function_tool(needs_approval=True, strict_json_schema=True)
async def refund(order_id: str) -> dict:
    ...
```

## Approval flow

When `needs_approval=True`, the SDK pauses before invoking the function and surfaces an approval request to your host application. The OAI CLI doesn't implement an interactive approval UI — this is for SDK users embedding agents in their own apps. Reference the SDK docs for the approval callback signature.

## Guardrails at the tool level

Attach guardrails to individual tools:

```python
from agents import GuardrailFunctionOutput, function_tool, input_guardrail

@input_guardrail
async def check_order_id(context, agent, input_data):
    return GuardrailFunctionOutput(
        output_info={},
        tripwire_triggered=not str(input_data).startswith("ORD-"),
    )

@function_tool(input_guardrails=[check_order_id])
async def lookup_order(order_id: str) -> dict:
    ...
```

## Hosted tool vs plugin

| Use hosted built-in | Use a plugin |
|---|---|
| Web search, file search over vector stores, code interpreter, image gen, hosted MCP | Domain-specific functions (your CRM, billing system, internal APIs) |
| Declared in `tools.builtin: [...]` | Declared in `plugins: [...]` |
| Runs on OpenAI infrastructure | Runs in-process |

Both populate the same `Agent(tools=[...])` list — you can mix freely:

```yaml
agents:
  billing:
    instructions: "..."
    tools:
      builtin: [web_search]        # hosted
    plugins:                        # local @function_tool
      - name: orders
        module: myapp.tools
```

## Error handling

If your function raises, the SDK catches the exception and returns its string form as the tool result. The agent sees this as a tool error and can retry, pick a different tool, or explain the problem. Override by passing `failure_error_function=` to `@function_tool`.

## Debugging

Enable debug logs:

```bash
AGENTFLOW_LOG_LEVEL=DEBUG agentflow --yaml oai_agent.yaml "..."
```

## Cross-backend plugins

The same `@function_tool` modules work on every backend that supports Python tools (OAI, SK). For cross-backend portability, the code path is identical; only the YAML shape (the `plugins:` field name and schema) differs per backend.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
