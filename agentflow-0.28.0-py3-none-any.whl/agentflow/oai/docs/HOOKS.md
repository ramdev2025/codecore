# Lifecycle Hooks

The OpenAI Agents SDK ships two hook interfaces, both observation-only:

- `RunHooks` — one global hooks instance for the whole `Runner.run()`
- `AgentHooks` — per-agent overrides attached to `Agent(hooks=...)`

Both expose the same event surface:

| Event | Signature |
|---|---|
| `on_agent_start` | `(context, agent)` |
| `on_agent_end` | `(context, agent, output)` |
| `on_llm_start` | `(context, agent, system_prompt, input_items)` |
| `on_llm_end` | `(context, agent, response)` — `response.usage` has tokens |
| `on_tool_start` | `(context, agent, tool)` |
| `on_tool_end` | `(context, agent, tool, result)` |
| `on_handoff` | `(context, from_agent, to_agent)` |

## YAML — `observers` (recommended)

AgentFlow compiles `observers:` entries into RunHooks automatically:

```yaml
observers:
  - type: audit_log
  - type: cost_tracking
    config: {budget_limit: 5.00}
  - type: latency_tracking
```

Under the hood, each observer creates one `RunHooks` instance; multiple observers are combined into one composite via `compose_hooks()`. See [Guards / Optimizers / Observers](GUARDS.md).

## Custom observer

```python
# myapp/observers.py
async def log_every_tool_end(tool_name, result):
    print(f"Tool {tool_name} returned {len(str(result))} chars")
```

```yaml
observers:
  - type: audit_log
    module: myapp.observers
    function: log_every_tool_end
```

The function receives `(tool_name, result)` on each `on_tool_end` event. Any exception it raises is swallowed — observers must not break the agent.

## Direct RunHooks

If you want the full SDK surface rather than the portable compiler:

```python
# myapp/hooks.py
from agents import RunHooks

class MyHooks(RunHooks):
    async def on_tool_start(self, context, agent, tool):
        print(f"[{agent.name}] calling {getattr(tool, 'name', type(tool).__name__)}")

    async def on_handoff(self, context, from_agent, to_agent):
        print(f"{from_agent.name} → {to_agent.name}")
```

For now, the YAML path compiles `observers:` into RunHooks internally; dropping raw `RunHooks` subclasses in via YAML is on the roadmap and reached today by wiring them in Python after `builder.build()`:

```python
from agents import Runner
from myapp.hooks import MyHooks

builder = OaiAgentBuilder.from_yaml("oai_agent.yaml")
runner = builder.build()
result = await Runner.run(
    runner.starting_agent,
    "Hello",
    run_config=runner.run_config,
    hooks=MyHooks(),
)
```

## Per-agent hooks

Attach `AgentHooks` to individual agents in Python (not via YAML today):

```python
from agents import AgentHooks

class BillingHooks(AgentHooks):
    async def on_agent_start(self, context, agent):
        print(f"Billing agent starting turn")

# After build:
runner.agents_by_name["billing"].hooks = BillingHooks()
```

## Built-in observer internals

Each observer in `agentflow.oai.filters.builtin` is a `RunHooks` subclass that emits OTel spans and structured log records:

- **audit_log** — `on_tool_start` → `gen_ai.execute_tool <name>` span; `on_tool_end` → adds `gen_ai.tool.call.result`. Logs to `agentflow.oai.audit`.
- **latency_tracking** — `on_tool_start/end` pair → `agentflow.tool.latency <name>` span with `agentflow.tool.latency_ms` attribute. Logs to `agentflow.oai.latency`.
- **cost_tracking** — accumulates `ModelResponse.usage` in `on_llm_end`, emits `gen_ai.agent_end` span in `on_agent_end` with `gen_ai.usage.{input,output,total}_tokens`. Logs to `agentflow.oai.cost`.

See [Observability](OBSERVABILITY.md).

## Ordering

When multiple observers are combined, they run in declaration order for each event. If one raises, the composite logs a warning and continues to the next — a broken observer never breaks the agent.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
