# Observability

AgentFlow OAI emits OpenTelemetry spans using the `gen_ai.*` semantic conventions so every collector can parse them without custom dashboards.

## Opt-in

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
export OTEL_EXPORTER_OTLP_PROTOCOL=grpc        # or http/protobuf
export OTEL_SERVICE_NAME=agentflow-prod    # default: agentflow

agentflow --yaml oai_agent.yaml "..."
```

Without `OTEL_TRACES_ENABLED=true`, `setup_tracing()` is a no-op. Tracing never crashes the agent — all emission paths are wrapped in `try/except`.

## Span catalog

| Span | Source | Attributes |
|---|---|---|
| `agentflow.oai.run` (root) | CLI driver | `agentflow.backend=openai-agents`, `agentflow.thread_id`, `agentflow.query_length`, `gen_ai.request.model`, rolled-up `gen_ai.usage.*` |
| `gen_ai.execute_tool <tool_name>` | `audit_log` observer | `gen_ai.operation.name=execute_tool`, `gen_ai.tool.name`, `gen_ai.agent.name`, `gen_ai.tool.call.result` |
| `agentflow.tool.latency <tool_name>` | `latency_tracking` observer | `gen_ai.tool.name`, `agentflow.tool.latency_ms` |
| `gen_ai.agent_end` | `cost_tracking` observer | `gen_ai.agent.name`, `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.usage.total_tokens`, optional `agentflow.budget_usd` |
| `gen_ai.session_summary` | CLI driver | `gen_ai.operation.name=session_summary`, aggregated `gen_ai.usage.*` |

All nested under the root span so one trace = one `agentflow` invocation.

## Enabling the observers

Tracing installs the provider, but spans only fire from observers or the CLI. Declare them in YAML:

```yaml
observers:
  - type: audit_log
  - type: latency_tracking
  - type: cost_tracking
    config: {budget_limit: 5.00}
```

The CLI's root span + session summary fire automatically.

## Per-collector recipes

### Jaeger

```yaml
# docker-compose.yaml
services:
  jaeger:
    image: jaegertracing/all-in-one:latest
    ports:
      - "4317:4317"
      - "16686:16686"
```

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
agentflow --yaml oai_agent.yaml "..."
open http://localhost:16686
```

### Langfuse

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=https://cloud.langfuse.com/api/public/otel
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic <base64(pk:sk)>"
```

### Phoenix

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

### Azure Monitor (Application Insights / Azure AI Foundry)

Install the built-in exporter extra and set the connection string — no code:

```bash
pip install 'agentflow[azure-monitor]'
OTEL_TRACES_ENABLED=true
APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=https://..."
```

The exporter attaches automatically through AgentFlow's shared exporter seam
(`agentflow.core.telemetry_seam`) — additively, so any OTLP export keeps working
alongside Azure (dual-export). Application Insights can't ingest raw OTLP; this
extra's `AzureMonitorTraceExporter` is the translator. Spans appear in App
Insights and, once that resource is linked to a Foundry project, in the Foundry
Tracing tab.

### Tempo, Datadog, New Relic, Honeycomb

Any OTLP-compatible endpoint works. Point `OTEL_EXPORTER_OTLP_ENDPOINT` at the collector's gRPC (4317) or HTTP (4318) port. Most vendors accept both.

## SDK-native tracing

The OpenAI Agents SDK also ships its own tracing that posts to the OpenAI dashboard. Controlled by `run_config.tracing_disabled` — set to `true` in YAML if you only want OTel:

```yaml
run_config:
  tracing_disabled: true
  trace_include_sensitive_data: false
```

The two tracing systems are independent — you can run both simultaneously.

## Redaction

The `audit_log` observer truncates tool I/O to 2000 chars (span attribute limit) and logs to `agentflow.oai.audit`. For stricter redaction, write a custom observer:

```python
# myapp/observers.py
import re

_EMAIL = re.compile(r"[\w\.-]+@[\w\.-]+")

async def redact(tool_name, result):
    # Emit to your audit sink with PII scrubbed
    scrubbed = _EMAIL.sub("[REDACTED]", str(result))
    send_to_audit_log(tool_name, scrubbed)
```

```yaml
observers:
  - type: audit_log
    module: myapp.observers
    function: redact
```

## Logging (non-OTel)

Even with tracing off, `audit_log`, `latency_tracking`, and `cost_tracking` emit structured log records:

```python
import logging
logging.getLogger("agentflow.oai.audit").setLevel(logging.INFO)
logging.getLogger("agentflow.oai.latency").setLevel(logging.INFO)
logging.getLogger("agentflow.oai.cost").setLevel(logging.INFO)
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
