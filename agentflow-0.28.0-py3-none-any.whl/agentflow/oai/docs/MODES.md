# Orchestration Modes

The OpenAI Agents SDK has **one** execution model: an `Agent` that can call tools, delegate to other agents via **handoff**, and emit a final output. AgentFlow's OAI schema surfaces this directly — a flat `agents:` dict plus a `starting_agent:` pointer.

No mode enum, no subagent/supervisor distinction, no autonomous-vs-orchestration schema split. Just a peer graph.

## Single-agent autonomous

```yaml
agents:
  assistant:
    instructions: "You are a helpful assistant."
    tools:
      builtin: [web_search]

starting_agent: assistant
```

The simplest shape. One agent loops over tool calls until it produces a final answer.

## Triage / router

The most common multi-agent pattern: a router that inspects the prompt and hands off to a specialist.

```yaml
agents:
  triage:
    instructions: "Route user questions to the right specialist."
    handoffs: [billing, technical, sales]

  billing:
    instructions: "Handle billing, subscriptions, refunds."
    handoff_description: "Billing expert — subscriptions, refunds, invoices."

  technical:
    instructions: "Handle technical support."
    handoff_description: "Technical support — bugs, error messages, setup."

  sales:
    instructions: "Handle sales inquiries."
    handoff_description: "Sales — pricing, plans, upgrades."

starting_agent: triage
```

The LLM picks a handoff target based on `handoff_description`. After the handoff, the target agent owns the rest of the conversation — it doesn't loop back to triage unless you explicitly wire that.

## Round-trip delegates

You can make handoffs bidirectional:

```yaml
agents:
  orchestrator:
    instructions: "Coordinate research tasks."
    handoffs: [researcher, writer]

  researcher:
    instructions: "Gather info and return to orchestrator."
    handoffs: [orchestrator]
    tools:
      builtin: [web_search]

  writer:
    instructions: "Draft content and return to orchestrator."
    handoffs: [orchestrator]

starting_agent: orchestrator
```

Each specialist can hand control back via a second handoff entry.

## Dynamic handoffs

Use `is_enabled` with a predicate function to gate handoffs by runtime state:

```yaml
agents:
  triage:
    instructions: "..."
    handoffs:
      - agent: billing
        is_enabled:
          module: myapp.gates
          function: has_billing_role
      - agent: technical
        is_enabled:
          module: myapp.gates
          function: has_tech_role
```

```python
# myapp/gates.py
async def has_billing_role(context, agent) -> bool:
    return context.user.role == "billing"
```

## Parallel work (via `parallel_tool_calls`)

The SDK doesn't have a native parallel-agent primitive. For parallelism over independent subtasks, let the agent call multiple function tools in one turn:

```yaml
agents:
  dispatcher:
    instructions: "Fan out queries across data sources in parallel."
    plugins:
      - name: sources
        module: myapp.sources
    model_settings:
      parallel_tool_calls: true
```

Each `@function_tool` call runs concurrently.

## Output type & tool-use behavior

Two per-agent knobs change how "when am I done?" is decided:

```yaml
agents:
  validator:
    instructions: "..."
    output_type:
      module: myapp.schemas
      class_name: ValidationResult
    tool_use_behavior: stop_on_first_tool   # return after first tool call
```

- `output_type` — forces a JSON-schema-enforced response matching a Pydantic class
- `tool_use_behavior: stop_on_first_tool` — the agent returns the first tool result instead of calling the LLM again

## Mode summary

| Pattern | How |
|---|---|
| Single agent | One entry in `agents:` |
| Triage/router | `starting_agent` has `handoffs: [...]` |
| Round-trip | Specialists have `handoffs: [starting_agent]` |
| Dynamic routing | `is_enabled: {module, function}` on each handoff |
| Parallel subtasks | `parallel_tool_calls: true` + many function tools |
| Structured output | `output_type: {module, class_name}` |
| Early-return tool | `tool_use_behavior: stop_on_first_tool` |

## Differences from other backends

- **vs CAS** — CAS has one main agent + a named `agents:` dict of subagents (delegation only via the built-in `Task` tool). OAI is a peer graph with native handoffs between any two agents.
- **vs SK** — SK splits `agent:` (autonomous) vs `agents:` + `orchestration:` (sequential/concurrent/handoff/group/magentic). OAI collapses this into one primitive: handoffs.
- **vs workflows** — Workflows defines nodes + edges explicitly. OAI hands routing to the LLM via `handoff_description`.
- **vs deep** — Deep has a single main agent plus DeepAgents' planning/filesystem tools. OAI doesn't ship a planning preset but supports similar patterns via `tool_use_behavior` and custom plugins.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
