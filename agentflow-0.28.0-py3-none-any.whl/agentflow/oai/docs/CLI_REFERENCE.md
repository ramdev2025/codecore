# CLI Reference

The OAI backend is invoked through the unified `agentflow` command. When the YAML's `backend:` field is `openai-agents`, the router dispatches here.

> **Cross-backend flags** — `--output ndjson`, `--debug`, `--verbose`, `--ascii`, REPL slash commands, the `agentflow-init` and `agentflow-threads` companion commands, and the JSON event schema are documented in `agentflow/cli/CLI_FLAGS.md` (in the source tree). This page covers OAI-specific behaviour only.

## Synopsis

```
agentflow [QUERY] [OPTIONS]
```

## Options

| Flag | Type | Default | Purpose |
|---|---|---|---|
| `QUERY` | positional | prompts if absent | Task for the agent |
| `--yaml PATH` | string | auto-detected | Path to the YAML config |
| `--backend TEXT` | string | YAML's `backend:` field | Override dispatch |
| `--interactive` | flag | off | REPL loop; `quit`/`q`/`exit` to end |
| `--dry-run` | flag | off | Validate config and print summary without calling the API |
| `--json` | flag | off | Output the dry-run summary as JSON |
| `--thread-id TEXT` | string | random UUID | Conversation-continuity handle |
| `--persistence` | `memory\|sqlite\|postgres` | `sqlite` | Persistence backend |
| `--db-path PATH` | string | `.agentflow/oai_threads.db` | SQLite path for the thread→session binding |
| `--connection-string TEXT` | string | — | Postgres DSN (required when `--persistence postgres`) |

Cross-backend flags that don't apply to OAI (`--tools`, `--workdir`, `--no-tui`, `--recursion-limit`) are silently accepted and ignored.

## Auto-detection

When `--yaml` is omitted, the CLI searches the current directory in order:

```
workflow.yaml
agentflow.yaml
agent.yaml
deep.yaml
deep_agent.yaml
sk_agent.yaml
cas_agent.yaml
oai_agent.yaml
```

If none match, the CLI prints an error and exits.

## Environment Variables

| Variable | Purpose |
|---|---|
| `OPENAI_API_KEY` | Default for the `openai` provider |
| `AZURE_OPENAI_ENDPOINT` / `AZURE_OPENAI_API_KEY` | Azure credentials (alternative to YAML fields) |
| `AGENTFLOW_ENCRYPTION_KEY` | AES-GCM key (16/24/32 bytes) for session-id encryption at rest |
| `AGENTFLOW_LOG_LEVEL` | `DEBUG \| INFO \| WARNING \| ERROR` (default: `WARNING`) |
| `OTEL_TRACES_ENABLED` | `true` to enable OpenTelemetry (default: off) |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | OTLP collector endpoint (default: `http://localhost:4317`) |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | `grpc \| http/protobuf` (default: `grpc`) |
| `OTEL_SERVICE_NAME` | Trace service name (default: `agentflow`) |
| `CHECKPOINTER_DB_PATH` | SQLite path override (same semantics as `--db-path`) |
| `POSTGRES_CONNECTION_STRING` | Postgres DSN override |
| `OAI_SESSION_DB_PATH` | Path to the SDK's `SQLiteSession` database (separate from the AgentFlow binding table) |

A `.env` file in the current working directory is loaded automatically at startup.

## Modes

### Dry-run

```bash
agentflow --yaml oai_agent.yaml --dry-run
agentflow --yaml oai_agent.yaml --dry-run --json
```

Validates the YAML, loads `.env`, resolves `${VAR}` interpolation, and prints either a rich table or a JSON summary.

### One-shot

```bash
agentflow "What's the weather in Paris?"
agentflow --yaml oai_agent.yaml "Explain the refund policy."
```

### Interactive (REPL)

```bash
agentflow --yaml oai_agent.yaml --interactive
```

Queries until you type `quit`, `q`, or `exit` (or press `Ctrl-C`).

## Persistence and resumption

```bash
# First call — creates session 'my-session'
agentflow --yaml oai_agent.yaml --thread-id my-session "first"

# Second call — resumes with full history
agentflow --yaml oai_agent.yaml --thread-id my-session "follow-up"
```

Under the hood:

- AgentFlow stores `my-session → sdk-session-uuid` in `.agentflow/oai_threads.db`
- The SDK's `SQLiteSession(sdk-session-uuid)` holds the actual conversation items in `.agentflow/oai_sessions.db`
- When `--persistence memory` is set, both tables are skipped (each run is fresh)

For Postgres:

```bash
agentflow --yaml oai_agent.yaml \
  --persistence postgres \
  --connection-string "postgresql://user:pass@host:5432/db" \
  --thread-id my-session "..."
```

See [Persistence](PERSISTENCE.md) and [Sessions](SESSIONS.md).

## Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Config error, missing YAML, API error, or user interrupt |

## Docs launcher

```bash
agentflow-docs --backend openai-agents
# or the explicit alias
agentflow docs --dev-addr 127.0.0.1:9400
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
