# Guardrails

Guardrails are the SDK's first-class tripwire mechanism. They run before (input) or after (output) the agent and can **abort the run** when a condition is triggered.

Two interfaces:

- **InputGuardrail** — runs on the incoming user message before the LLM is called
- **OutputGuardrail** — runs on the agent's final output before it's returned

Both accept an async function that returns `GuardrailFunctionOutput(output_info, tripwire_triggered)`.

## Declaration

Per-agent:

```yaml
agents:
  billing:
    instructions: "..."
    input_guardrails:
      - module: myapp.guardrails
        function: check_pii
        name: pii_check              # display name (default: module.function)
        run_in_parallel: true        # run alongside the first LLM call (input only)

    output_guardrails:
      - module: myapp.guardrails
        function: check_refund_authority
```

Run-level (apply to every agent):

```yaml
run_config:
  input_guardrails:
    - module: myapp.guardrails
      function: check_pii
  output_guardrails:
    - module: myapp.guardrails
      function: check_safety
```

Run-level guardrails execute **before** agent-level ones.

## Write a guardrail

```python
# myapp/guardrails.py
import re
from agents import GuardrailFunctionOutput

_EMAIL = re.compile(r"[\w\.-]+@[\w\.-]+")

async def check_pii(context, agent, input_data):
    text = input_data if isinstance(input_data, str) else ""
    matches = _EMAIL.findall(text)
    return GuardrailFunctionOutput(
        output_info={"matched": matches},
        tripwire_triggered=bool(matches),
    )
```

When the tripwire is `True`, the SDK raises `InputGuardrailTripwireTriggered` (or `OutputGuardrailTripwireTriggered`) before calling the LLM / returning output. `output_info` is attached to the exception so your host can inspect what the guardrail saw.

## `run_in_parallel` (input guardrails only)

When `True`, the guardrail runs **concurrently** with the first LLM call. If it trips, the LLM call is cancelled. This saves latency when guardrails are fast.

When `False`, the guardrail must complete before the LLM call starts.

## Output guardrails and structured output

Output guardrails receive the agent's final output. If `output_type:` is set, the guardrail sees an instance of that Pydantic class.

```python
async def check_refund_authority(context, agent, output):
    # output is BillingResolution (your Pydantic class) if output_type is set
    return GuardrailFunctionOutput(
        output_info={"amount": output.refund_amount},
        tripwire_triggered=output.refund_amount > 10_000,
    )
```

## Handling tripped guardrails

The SDK raises a typed exception. Catch it in your host code:

```python
from agents.exceptions import InputGuardrailTripwireTriggered

try:
    result = await Runner.run(agent, "my@email.com please")
except InputGuardrailTripwireTriggered as e:
    print("PII detected:", e.output_info)
```

## Built-in vs custom

The `guards:` cross-backend portable tier has one built-in (`pii`) and four hooks for user-provided guardrails:

```yaml
guards:
  - type: pii
    config:
      patterns: [email, phone, ssn, credit_card]
  - type: input_validation
    module: myapp.guardrails
    function: validate_input
  - type: content_filter
    module: myapp.guardrails
    function: filter_output
```

The `pii` type compiles to an `InputGuardrail` covering four named patterns. See [Guards / Optimizers / Observers](GUARDS.md) for the full compilation table.

## Guardrails vs hooks

| Goal | Use |
|---|---|
| Abort the run when a condition hits | Guardrail (tripwire) |
| Observe / log / emit telemetry | Hook (observer) |
| Enforce call-count limits | Hook (counter-based) |
| Modify / redact input text | Not supported by guardrails (they're yes/no). Use an `on_llm_start` hook or preprocessing step. |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
