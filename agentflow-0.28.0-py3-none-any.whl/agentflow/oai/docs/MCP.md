# MCP Integration

The [Model Context Protocol](https://modelcontextprotocol.io/) lets LLMs discover and call tools hosted outside the process. The OpenAI Agents SDK exposes three MCP client transports; AgentFlow surfaces all three.

## Declare servers

```yaml
mcp_servers:
  local-fs:
    transport: stdio
    command: npx
    args: [-y, "@modelcontextprotocol/server-filesystem", "/tmp"]
    env: {DEBUG: "1"}

  remote-stream:
    transport: http                        # StreamableHttp (current MCP spec)
    url: https://mcp.example.com/v1
    headers: {Authorization: "Bearer ${MCP_TOKEN}"}
    timeout: 30.0

  legacy-sse:
    transport: sse
    url: https://mcp.example.com/sse
    sse_read_timeout: 300.0
```

## Attach to agents

```yaml
agents:
  main:
    instructions: "Use the filesystem MCP."
    mcp_servers: [local-fs]          # reference by name
```

The validator rejects references to servers not declared at the top level.

## Transports

### stdio

Spawns a subprocess. The server reads/writes on stdin/stdout.

```yaml
  local-fs:
    transport: stdio
    command: uvx
    args: [mcp-server-filesystem, /data]
    env: {LOG_LEVEL: debug}
    cwd: /opt/mcp
```

Use for local tools, one-shot MCP servers, or anything you can run as a subprocess.

### sse

Server-Sent Events. One long-lived HTTP GET stream from server → client; client sends messages via POST.

```yaml
  realtime:
    transport: sse
    url: https://mcp.example.com/sse
    headers: {Authorization: "Bearer ${MCP_TOKEN}"}
    sse_read_timeout: 300.0
    timeout: 30.0
```

### http (StreamableHttp)

The current MCP spec transport — full-duplex HTTP. Prefer this over SSE for new servers.

```yaml
  remote:
    transport: http
    url: https://mcp.example.com/v1
    headers: {Authorization: "Bearer ${MCP_TOKEN}"}
    timeout: 30.0
    terminate_on_close: true
```

## Shared options

All transports support:

```yaml
    cache_tools_list: true                 # cache the tools list across runs
    use_structured_content: true           # let the SDK use structured tool responses
    max_retry_attempts: 3
    retry_backoff_seconds_base: 1.0
    client_session_timeout_seconds: 10.0
    require_approval: false                # or an object per the SDK
```

## MCP + guardrails + observers

MCP tool calls flow through the same `on_tool_start/end` hooks as built-in and plugin tools, so `audit_log`, `latency_tracking`, and custom observers see them automatically.

```yaml
observers:
  - type: audit_log
  - type: latency_tracking

mcp_servers:
  tracking:
    transport: stdio
    command: mcp-tracking
```

Spans emitted include the tool name, so MCP-hosted tool calls appear alongside SDK-hosted ones in Jaeger / Tempo / Datadog.

## Per-call approval

```yaml
    require_approval:
      default: always                      # or never, or only for specific tools
      tools:
        delete_file: always
```

See the SDK's MCP docs for the full approval object shape.

## Debugging

Run with `AGENTFLOW_LOG_LEVEL=DEBUG` to see MCP stdio / HTTP traffic. For stdio servers specifically, check the server's own stderr — the SDK forwards it.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
