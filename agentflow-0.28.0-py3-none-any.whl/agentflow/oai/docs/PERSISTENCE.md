# Persistence

AgentFlow OAI stores a **binding table** that maps human-readable `thread_id` strings to SDK session identifiers. The conversation items themselves live inside the SDK's [`Session`](SESSIONS.md) abstraction (`SQLiteSession`, `OpenAIConversationsSession`, etc.). AgentFlow does **not** re-serialize the conversation history — the SDK owns that.

Three backends, all with identical API:

| Backend | Class | Use when |
|---|---|---|
| `memory` | `InMemoryPersistence` | Tests, stateless workers, CI |
| `sqlite` (default) | `SQLitePersistence` | Single-instance deployments, dev laptops |
| `postgres` | `PostgresPersistence` | Production, multi-instance |

## CLI

```bash
# Default: sqlite at .agentflow/oai_threads.db
agentflow --yaml oai_agent.yaml --thread-id my-session "..."

# Memory (no persistence — each run fresh)
agentflow --persistence memory --yaml oai_agent.yaml "..."

# Custom SQLite path
agentflow --persistence sqlite --db-path /data/threads.db --yaml oai_agent.yaml "..."

# Postgres
agentflow --persistence postgres \
  --connection-string "postgresql://user:pass@host:5432/agentflow" \
  --yaml oai_agent.yaml "..."
```

## Environment variables

Persistence is infrastructure — pick the backend at deploy time
without editing the YAML. The CLI honors:

| Variable                     | Effect                                                                                  |
| ---------------------------- | --------------------------------------------------------------------------------------- |
| `AGENTFLOW_PERSISTENCE`      | Backend selector: `memory` / `sqlite` / `postgres` (used when `--persistence` is unset) |
| `POSTGRES_CONNECTION_STRING` | Postgres DSN (used when `--connection-string` is unset)                                 |
| `CHECKPOINTER_DB_PATH`       | SQLite path (used when `--db-path` is unset)                                            |
| `OAI_SESSION_DB_PATH`        | SDK Session SQLite path (separate from the agentflow binding table)                     |

Resolution order: CLI flag > env var > default (sqlite). See
[`workflows/PERSISTENCE.md`](../../workflows/docs/PERSISTENCE.md)
for the canonical reference — workflows adds the `POSTGRES_POOL_*`
family, `AGENTFLOW_STORE_ENABLED`, and `AGENTFLOW_ENCRYPTION_KEY`
for tuning.

> **Connection resilience.** This backend opens a PostgreSQL connection per
> operation and closes it again, so it is not exposed to the stale-connection
> failure fixed in 0.28.0 (where a database restart or reaped idle connection
> left the app permanently failing). Connection pooling and the
> `POSTGRES_POOL_*` tuning vars apply to the `workflows` and `deep` backends
> only.

## Python API

```python
from agentflow.oai.persistence import create_persistence_manager

pm = create_persistence_manager(
    backend="sqlite",
    db_path=".agentflow/oai_threads.db",
)

# Read/write the binding
session_id = pm.get_or_create_session_id("my-thread")
pm.bump_turns("my-thread")

# Enumerate
print(pm.list_threads())

# Delete
pm.delete("my-thread")
```

## Schema

```sql
CREATE TABLE oai_threads (
    thread_id   TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL,
    first_seen  REAL NOT NULL,
    last_seen   REAL NOT NULL,
    turns       INTEGER NOT NULL DEFAULT 0
);
```

Postgres uses `DOUBLE PRECISION` for timestamps but the rest of the schema is identical.

## Encryption at rest

Set `AGENTFLOW_ENCRYPTION_KEY` (16, 24, or 32 bytes) and the `session_id` column is AES-GCM encrypted:

```bash
export AGENTFLOW_ENCRYPTION_KEY="thirtytwo-byte-key-for-production!"
agentflow --yaml oai_agent.yaml --thread-id private-session "..."
```

Each binding row is encoded as `aes:<base64-nonce-tag-ct>`. Missing the key on read raises a clear error rather than returning ciphertext.

Note: this protects the **session identifier** in the binding table, not the conversation contents. The SDK session DB is not encrypted by AgentFlow — use database-level encryption or a `Session` backend that encrypts itself (e.g. a Redis cluster with TLS).

## Multi-instance (Postgres)

```bash
# Instance A
agentflow --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id customer-42 "first turn"

# Instance B — same thread, different container
agentflow --persistence postgres \
  --connection-string "$DATABASE_URL" \
  --thread-id customer-42 "follow-up"
```

Both instances hit the same binding table and the same SDK-side session (assuming the SDK session backend is itself shared — e.g. both point at the same Postgres `SQLAlchemySession`, or both use `OpenAIConversationsSession`).

### FastAPI lifespan pattern

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow.oai.persistence import create_persistence_manager

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pm = create_persistence_manager(
        backend="postgres",
        connection_string=os.environ["DATABASE_URL"],
    )
    yield

app = FastAPI(lifespan=lifespan)

@app.post("/chat")
async def chat(req: ChatRequest):
    session_id = app.state.pm.get_or_create_session_id(req.thread_id)
    # ... build runner, resolve session, run...
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `ImportError: pycryptodome` | `pip install pycryptodome` (only needed when encryption is enabled) |
| `sqlite3.OperationalError: database is locked` | Multiple processes writing to the same SQLite file — move to Postgres |
| `ValueError: AGENTFLOW_ENCRYPTION_KEY must be 16, 24, or 32 bytes` | Key length check; use a URL-safe base64-decoded 32-byte key |
| Session id in binding is garbage after enabling encryption | You wrote rows *before* setting `AGENTFLOW_ENCRYPTION_KEY`. The loader detects plaintext and returns it; encrypted rows start with `aes:` |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
