"""
AgentFlow OAI — Documentation server.

Usage:
    agentflow docs                              # Serve on localhost:9400
    agentflow docs --dev-addr 0.0.0.0:8080      # Custom address
"""

import argparse
import subprocess
import sys
from pathlib import Path


def get_docs_root() -> Path:
    """Get the documentation root directory (where mkdocs.yml lives)."""
    current = Path(__file__).resolve()

    # Installed as wheel — mkdocs.yml next to this file
    package_mkdocs = current.parent / "mkdocs.yml"
    if package_mkdocs.exists():
        return current.parent

    # Dev mode — walk up
    for parent in [current.parent.parent.parent, Path.cwd()]:
        mkdocs_path = parent / "mkdocs.yml"
        if mkdocs_path.exists():
            return parent

    return current.parent


from agentflow.cli.errors import wrap_cli_main


@wrap_cli_main
def main():
    """Serve AgentFlow OAI documentation."""
    parser = argparse.ArgumentParser(
        description="Serve AgentFlow OAI documentation",
    )
    parser.add_argument(
        "--dev-addr", default="127.0.0.1:9400",
        help="Address to serve on (default: 127.0.0.1:9400)",
    )

    args = parser.parse_args()

    try:
        subprocess.run(["mkdocs", "--version"], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("Error: MkDocs is not installed.")
        sys.exit(1)

    docs_root = get_docs_root()
    if not (docs_root / "mkdocs.yml").exists():
        print(f"Error: mkdocs.yml not found in {docs_root}")
        sys.exit(1)

    print(f"Serving documentation from {docs_root}")
    print(f"http://{args.dev_addr}")
    print()

    try:
        subprocess.run(
            ["mkdocs", "serve", "--dev-addr", args.dev_addr],
            cwd=docs_root,
            check=True,
        )
    except KeyboardInterrupt:
        print("\nStopped.")
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)


if __name__ == "__main__":
    main()
