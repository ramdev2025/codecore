# Persistence

SK conversation state is a `ChatHistory` (list of messages) tagged by a
`thread_id`. AgentFlow SK serializes `ChatHistory` to JSON and stores it by
thread, so conversations survive process restarts and can be resumed across
sessions, hosts, and replicas.

Persistence is a **deployment concern** — configured via CLI flags or env
vars, not in application code.

## Overview

AgentFlow SK supports three persistence backends:

- **memory** — in-process dict, lost on exit. Testing and stateless workers.
- **sqlite** (default) — file-based, zero configuration. Dev and single-node
  deployments.
- **postgres** — managed database with connection pooling. Production
  multi-instance deployments.

State is thread-keyed: each `thread_id` is an isolated conversation with its
own message history. Concurrent threads do not interfere.

## Backends

| Backend    | Where state lives                                    | When to use                            |
| ---------- | ---------------------------------------------------- | -------------------------------------- |
| `memory`   | In-process dict                                      | Tests, stateless workers               |
| `sqlite`   | Single file (`.agentflow/sk_checkpoints.db` default) | Local dev, single-instance services    |
| `postgres` | Managed Postgres instance                            | Production, horizontal scale           |

### SQLite

- Zero configuration, uses `aiosqlite` for async access
- One file on disk — easy to inspect, back up, or discard
- Not suitable when multiple processes write concurrently

```bash
pip install aiosqlite  # installed with agentflow[semantic-kernel]
```

### PostgreSQL

- Uses `asyncpg` + connection pool
- Safe for multi-process / multi-host deployments
- Survives container restarts; scales horizontally

```bash
pip install asyncpg  # add to your app's deps if using postgres
```

## CLI

```bash
# Default — sqlite at .agentflow/sk_checkpoints.db
agentflow --yaml agent.yaml "hi"

# Memory-only (lost on exit)
agentflow --yaml agent.yaml --persistence memory "hi"

# Custom SQLite path
agentflow --yaml agent.yaml --db-path ./state.db "hi"

# PostgreSQL
agentflow --yaml agent.yaml \
  --persistence postgres \
  --connection-string "postgresql://user:pass@host/db" \
  "hi"
```

The CLI prints the resolved backend and thread ID at startup:

```
Persistence: sqlite
Thread: 001943cb-...
```

## Thread IDs

Each conversation has a thread ID. On first run a fresh UUID is auto-generated
and printed. To resume the conversation, pass the same thread ID back:

```bash
# First turn — auto-generates "u-001"
agentflow --yaml agent.yaml --thread-id u-001 "My name is Alice"

# Second turn — resumes Alice's history
agentflow --yaml agent.yaml --thread-id u-001 "What did I tell you my name was?"
```

### Best practices

1. **Unique IDs per user/session** — generate UUIDs or use user IDs.
2. **Be consistent** — same `thread_id` resumes the same history.
3. **Namespace** — prefix with `user-`, `session-`, `tenant-`, etc., to keep
   collections organized.

## Environment Variables

| Variable                     | Purpose                                                                           |
| ---------------------------- | --------------------------------------------------------------------------------- |
| `AGENTFLOW_PERSISTENCE`      | Backend selector: `memory` / `sqlite` / `postgres` (used when `--persistence` is unset) |
| `CHECKPOINTER_DB_PATH`       | Default SQLite path (overridden by `--db-path`)                                   |
| `POSTGRES_CONNECTION_STRING` | Default Postgres DSN (overridden by `--connection-string`)                        |
| `AGENTFLOW_ENCRYPTION_KEY`   | Key for AES-GCM encryption at rest (16 / 24 / 32 bytes)                           |

Resolution order: CLI flag > env var > default (sqlite). Environment
variables are loaded automatically from `.env` in the working directory.
See [`workflows/PERSISTENCE.md`](../../workflows/docs/PERSISTENCE.md)
for the canonical reference — the workflows backend additionally honors
the `POSTGRES_POOL_*` family, `AGENTFLOW_STORE_ENABLED`, and
`AGENTFLOW_ENCRYPTION_KEY` for tuning.

> **Connection resilience.** This backend opens a PostgreSQL connection per
> operation and closes it again, so it is not exposed to the stale-connection
> failure fixed in 0.28.0 (where a database restart or reaped idle connection
> left the app permanently failing). Connection pooling and the
> `POSTGRES_POOL_*` tuning vars apply to the `workflows` and `deep` backends
> only.

## AES Encryption at Rest

For sensitive conversations (PII, proprietary data, regulated industries),
encrypt persisted payloads with AES-GCM:

```bash
export AGENTFLOW_ENCRYPTION_KEY="0123456789abcdef0123456789abcdef"  # 32 bytes
agentflow --yaml agent.yaml --thread-id abc-123 "sensitive message"
```

| Key size | Algorithm  |
| -------- | ---------- |
| 16 bytes | AES-128    |
| 24 bytes | AES-192    |
| 32 bytes | AES-256    |

Implementation:

- Cipher: AES-GCM (`pycryptodome`)
- Per-payload random nonce + authentication tag
- Stored payload is base64-encoded ciphertext
- The same key is required to decrypt — losing the key means losing the history

Works with all three backends (memory encrypts in RAM too — useful when snapshots
are exported).

## Python API

```python
from agentflow.sk.core.persistence import create_persistence_manager

mgr = create_persistence_manager(
    backend="sqlite",              # memory | sqlite | postgres
    db_path="./state.db",          # SQLite only
    connection_string=None,        # Postgres only
    encryption_key=None,           # Optional AES key
)

# Load by thread (returns None if unknown)
history = mgr.load("user-001")

# Save a ChatHistory object
from semantic_kernel.contents import ChatHistory
hist = ChatHistory()
hist.add_user_message("hello")
mgr.save("user-001", hist)

# Load as an SK thread object
thread = mgr.load_as_thread("user-001")
```

See `SKPersistenceManager` for the full interface and implementation.

## FastAPI Integration

Typical pattern — share one persistence manager across request handlers:

```python
from contextlib import asynccontextmanager

from fastapi import FastAPI

from agentflow.sk import SKAgentBuilder
from agentflow.sk.core.persistence import create_persistence_manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Shared agent + persistence for the lifetime of the process
    app.state.agent = SKAgentBuilder.from_yaml("agent.yaml").build()
    app.state.persistence = create_persistence_manager(
        backend="postgres",
        connection_string="${DATABASE_URL}",
        encryption_key=os.environ.get("AGENTFLOW_ENCRYPTION_KEY"),
    )
    yield
    # Optional cleanup (sqlite/postgres connections close on GC)


app = FastAPI(lifespan=lifespan)


@app.post("/chat/{thread_id}")
async def chat(thread_id: str, message: str):
    thread = app.state.persistence.load_as_thread(thread_id)
    response_text = ""
    async for response in app.state.agent.invoke(messages=message, thread=thread):
        response_text += str(getattr(response, "message", response))
        thread = getattr(response, "thread", thread)
    app.state.persistence.save(thread_id, thread._chat_history)
    return {"thread_id": thread_id, "reply": response_text}
```

Routes pass their `thread_id` (user id, session id) so each user sees their own
history while sharing one agent instance and one DB pool.

## Troubleshooting

### Database is locked (SQLite)

**Symptom:**

```
sqlite3.OperationalError: database is locked
```

**Cause:** multiple processes writing to the same SQLite file, or a
long-running transaction holding a lock.

**Fix:**

- Use one process per SQLite file, or switch to PostgreSQL for concurrency
- Ensure pending transactions are not leaking (use `async with` / context
  managers)
- Put the database on local disk, not on NFS or SMB — those don't support
  SQLite locking properly

### Connection refused (PostgreSQL)

**Symptom:**

```
could not connect to server: Connection refused
```

**Fix:**

- `pg_isready` — confirm the server is running
- Verify the connection string (`postgresql://user:pass@host:5432/dbname`)
- Network / firewall allows the client to reach the database port

### Authentication failed (PostgreSQL)

**Symptom:**

```
password authentication failed for user "…"
```

**Fix:**

- Verify credentials
- Confirm the role has `CONNECT` on the database and `USAGE` on the schema
- If using Azure/AWS, ensure IAM-auth tokens haven't expired

### Missing dependency

**Symptom:**

```
asyncpg is not installed. pip install asyncpg
```

**Fix:**

```bash
pip install asyncpg
```

### Thread not resuming

**Symptom:** the second turn behaves as if it's the first — no memory of the
earlier conversation.

**Fix:**

- Pass `--thread-id` on both calls; without it a fresh UUID is generated each run
- Confirm the persistence backend actually persists (memory loses state between
  process invocations)
- If encrypted, confirm `AGENTFLOW_ENCRYPTION_KEY` is identical across runs

### Encryption key wrong size

**Symptom:**

```
Encryption key must be 16, 24, or 32 bytes
```

**Fix:** generate a proper key:

```bash
python -c "import secrets; print(secrets.token_hex(32))"  # AES-256
```

## Summary

| Feature              | memory | sqlite   | postgres   |
| -------------------- | ------ | -------- | ---------- |
| Survives restart     | No     | Yes      | Yes        |
| Multi-process        | No     | No       | Yes        |
| Horizontal scale     | No     | No       | Yes        |
| AES-GCM at rest      | Yes    | Yes      | Yes        |
| Setup complexity     | None   | None     | Needs DB   |
| Best for             | Tests  | Dev, SMB | Production |

**Quick picks:**

- Development / demos → default (`sqlite`) with no flags
- Production single-user → `sqlite` + `AGENTFLOW_ENCRYPTION_KEY`
- Production multi-user / multi-replica → `postgres` + `AGENTFLOW_ENCRYPTION_KEY`

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
