# CLI Reference

The unified `agentflow` command dispatches to the SK backend when the YAML's
`backend` field is `semantic-kernel` (or when `--backend semantic-kernel` is
passed explicitly).

> **Cross-backend flags** — `--output ndjson`, `--debug`, `--verbose`, `--ascii`, REPL slash commands, the `agentflow-init` and `agentflow-threads` companion commands, and the JSON event schema are documented in `agentflow/cli/CLI_FLAGS.md` (in the source tree). This page covers SK-specific behaviour only.

## Synopsis

```bash
agentflow [OPTIONS] [QUERY]
```

## Common flags

| Flag | Description |
|------|-------------|
| `--yaml PATH` | Path to the YAML config. Auto-detected if omitted (searches `workflow.yaml`, `agent.yaml`, `sk_agent.yaml`, etc.) |
| `--backend semantic-kernel` | Force SK backend (skips auto-detection) |
| `--interactive` | Continuous conversation loop |
| `--dry-run` | Validate config and print summary, without running |
| `--json` | Print dry-run summary as JSON |
| `--thread-id TEXT` | Thread ID for conversation continuity |
| `--persistence {memory,sqlite,postgres}` | Persistence backend (default: `sqlite`) |
| `--db-path PATH` | SQLite database path |
| `--connection-string TEXT` | PostgreSQL connection string |

## Examples

### Dry-run

```bash
agentflow --yaml sk_agent.yaml --dry-run
```

### One-shot query

```bash
agentflow --yaml sk_agent.yaml "What is 2+2?"
```

### Interactive mode

```bash
agentflow --yaml sk_agent.yaml --interactive
```

### Resume a conversation

```bash
agentflow --yaml sk_agent.yaml --thread-id abc-123 "What did I just ask?"
```

### With encrypted SQLite persistence

```bash
export AGENTFLOW_ENCRYPTION_KEY="0123456789abcdef0123456789abcdef"  # 32 bytes
agentflow --yaml sk_agent.yaml --persistence sqlite --db-path ./state.db "hi"
```

### PostgreSQL persistence

```bash
export POSTGRES_CONNECTION_STRING="postgresql://user:pass@host/db"
agentflow --yaml sk_agent.yaml --persistence postgres "hi"
```

## Documentation server

```bash
agentflow docs                                    # http://127.0.0.1:9200
agentflow docs --dev-addr 0.0.0.0:8080            # Custom address
```

## Environment variables

| Variable | Purpose |
|----------|---------|
| `OPENAI_API_KEY` | OpenAI auth |
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI endpoint |
| `AZURE_OPENAI_DEPLOYMENT` | Azure OpenAI deployment name |
| `POSTGRES_CONNECTION_STRING` | Default Postgres connection string |
| `CHECKPOINTER_DB_PATH` | Default SQLite path (shared with workflows/deep) |
| `AGENTFLOW_ENCRYPTION_KEY` | AES-GCM key (16/24/32 bytes) for persistence encryption |
| `AGENTFLOW_LOG_LEVEL` | Log level (default `WARNING`) |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
