# Migration Guide

This guide helps you move existing AgentFlow applications to the SK backend.

## From `workflows` standalone agent

Workflows standalone (LangGraph-based):

```yaml
metadata:
  version: "1.0"
  name: assistant

llm:
  provider: openai
  config:
    model: gpt-4o

agent:
  name: assistant
  system_prompt: You are helpful.
  tools:
    - search_web
  mcp_tools:
    - server: data
      tools: "*"

mcp_servers:
  data:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]
```

Equivalent SK:

```yaml
backend: semantic-kernel

metadata:
  version: "1.0"
  name: assistant

llm:
  provider: openai
  config:
    model: gpt-4o

agent:
  name: assistant
  system_prompt: You are helpful.
  plugins:
    - name: web
      type: python
      module: myproject.tools.search   # your @kernel_function-decorated module
      functions: [search_web]

mcp_servers:
  data:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]
```

Key changes:

- Add `backend: semantic-kernel` at the top.
- Tools: rewrite `@tool`-decorated functions as `@kernel_function`. Keep
  the function body. Reference via `plugins[].type: python`.
- `mcp_tools:` section is gone — MCP servers are added as kernel plugins
  automatically, visible to all agents on that kernel.
- LangChain middleware (`middleware:`) maps to `guards:` /
  `optimizers:` / `observers:` (see [Guards docs](GUARDS.md)).

## From `workflows` orchestrated multi-agent

Workflows orchestrator → SK handoff:

```yaml
# Workflows (before)
orchestrator:
  workflows: [main]

workflows:
  main:
    nodes:
      triage:
        depends_on: []
        routes:
          router_field: category
          billing: billing_agent
          tech: tech_agent

nodes:
  triage: { system_prompt: Route. }
  billing_agent: { system_prompt: Billing specialist. }
  tech_agent: { system_prompt: Tech specialist. }
```

```yaml
# SK handoff (after)
backend: semantic-kernel
mode: handoff

agents:
  - name: triage
    system_prompt: Route customer requests.

  - name: billing
    description: Billing questions, refunds, payment issues
    system_prompt: You are a billing specialist.

  - name: tech
    description: Technical issues, bugs, outages
    system_prompt: You are a technical specialist.
```

First agent is always the router. Routing happens via agent `description`
fields and the triage agent's own judgment, not explicit conditional
routes.

For deterministic step pipelines (like a sequential data pipeline), use
`mode: sequential` instead.

## From `deep` autonomous agent

Deep (DeepAgents):

```yaml
metadata:
  version: "1.0"
  name: coder

agent:
  system_prompt: You write code.
  llm:
    provider: azure_openai
    config: { model: gpt-4o, azure_endpoint: ${AZURE_OPENAI_ENDPOINT} }

tools:
  builtin: [read_file, write_file, execute]
  custom:
    - module: myproject.tools
      functions: [lint, format]
```

Equivalent SK autonomous:

```yaml
backend: semantic-kernel

metadata:
  version: "1.0"
  name: coder

llm:
  provider: azure_openai
  config:
    model: gpt-4o
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
    azure_identity: true

agent:
  name: coder
  system_prompt: You write code.
  plugins:
    - name: files
      type: python
      module: myproject.tools.files        # your own read_file / write_file / execute
    - name: lint_format
      type: python
      module: myproject.tools
      functions: [lint, format]
```

Key changes:

- SK has no built-in filesystem tools. Write your own `@kernel_function`
  methods for file operations, or use an MCP filesystem server:
  ```yaml
  mcp_servers:
    fs:
      transport: stdio
      command: npx
      args: ["-y", "@modelcontextprotocol/server-filesystem", "./"]
  ```
- DeepAgents' planning/todo middleware is not directly portable — use
  Magentic orchestration (`mode: magentic`) for a similar "planner +
  workers" pattern.
- Subagents (deep's `subagents:`) → SK orchestration modes (handoff /
  magentic).

## LangChain `@tool` → `@kernel_function`

```python
# Before (workflows/deep)
from langchain_core.tools import tool

@tool
def search(query: str) -> str:
    """Search the web."""
    return do_search(query)
```

```python
# After (SK)
from semantic_kernel.functions import kernel_function

@kernel_function(name="search", description="Search the web")
def search(query: str) -> str:
    return do_search(query)
```

The function body doesn't change — only the decorator.

## When NOT to migrate

Some patterns don't have a clean SK equivalent:

- **Deterministic DAGs with conditional routing** — use `workflows`
  (LangGraph is better at this).
- **Deep autonomous coding agents with planning + filesystem + memory
  middleware** — `deep` has a richer default toolbelt.
- **External A2A agents** — SK doesn't have A2A client support; stay on
  `workflows`.

The three backends coexist. Use `backend:` per YAML to pick the right
tool for each agent.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
