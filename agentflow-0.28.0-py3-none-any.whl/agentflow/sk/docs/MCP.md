# MCP Integration

Semantic Kernel has native support for [Model Context Protocol](https://modelcontextprotocol.io/)
servers via `MCPStdioPlugin` and `MCPSsePlugin`. AgentFlow's SK backend
translates `mcp_servers:` YAML config into the appropriate SK plugin
class.

## stdio transport

Run a subprocess and speak MCP over stdio.

```yaml
mcp_servers:
  local-fs:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]
    env:
      LOG_LEVEL: INFO
```

## SSE transport

Connect to an HTTP-based MCP server over Server-Sent Events.

```yaml
mcp_servers:
  remote:
    transport: sse
    url: https://example.com/mcp/sse
```

## Tool discovery

When the kernel is built, each MCP plugin connects to its server and
discovers tools automatically. Those tools become callable by the LLM the
same as any other plugin function.

## Auth

Advanced auth (OAuth2, mTLS) isn't natively supported by SK's MCP
connectors yet. For now, use the `env:` field for API keys or bearer tokens
that the MCP server itself consumes:

```yaml
mcp_servers:
  private:
    transport: stdio
    command: python
    args: [-m, my_mcp_server]
    env:
      MY_API_KEY: ${MY_API_KEY}
```

## Unsupported transports

Streamable HTTP isn't directly supported by SK's MCP connectors. Use SSE
on the server side instead. Requesting `transport: streamable_http` raises
a clear error at build time.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
