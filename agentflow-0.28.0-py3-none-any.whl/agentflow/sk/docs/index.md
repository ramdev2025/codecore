# AgentFlow SK

**YAML-driven agents on Microsoft Semantic Kernel.**

AgentFlow SK lets you define autonomous agents, multi-agent orchestrations, and event-driven processes in YAML — without writing kernel setup code. It's the Semantic Kernel backend of the AgentFlow framework, sitting alongside the LangGraph-based `workflows` and `deep` backends.

## Install

```bash
pip install agentflow[semantic-kernel]
```

This pulls in `semantic-kernel>=1.20.0` and nothing else — no LangChain, no LangGraph. Each backend is isolated so you only install what you use.

## Quick Start

1. **Create a YAML config** (`agent.yaml`):

    ```yaml
    backend: semantic-kernel

    metadata:
      version: "1.0"
      name: research-assistant

    llm:
      provider: openai
      config:
        model: gpt-4o
        api_key: ${OPENAI_API_KEY}

    agent:
      name: research_assistant
      system_prompt: |
        You are a research assistant. Use tools to answer questions.
      plugins:
        - name: web_search
          type: python
          module: myproject.tools.search
    ```

2. **Run it**:

    ```bash
    agentflow --yaml agent.yaml "What is the capital of France?"
    ```

3. **Or from Python**:

    ```python
    import asyncio
    import agentflow

    async def main():
        agent = await agentflow.create("agent.yaml")
        # see the YAML reference for what comes back per mode

    asyncio.run(main())
    ```

## What's Supported

- **5 agent modes** — autonomous, handoff, sequential, group chat, magentic, process
- **5 agent types** — ChatCompletion, AzureAI, OpenAIAssistant, OpenAIResponses, Bedrock
- **Multi-service kernels** — chat + embeddings + image + audio on one kernel
- **4 plugin types** — Python modules, prompt templates, OpenAPI specs, SK plugin directories
- **Native MCP** — `MCPStdioPlugin` / `MCPSsePlugin` registered from YAML
- **Filters as guards/optimizers/observers** — PII redaction, call limits, audit log, latency + cost tracking (custom filters welcome)
- **Memory connectors** — Azure AI Search, Qdrant, Chroma, Redis, custom
- **Persistence** — `ChatHistory` save/load in memory, SQLite, PostgreSQL, with optional AES encryption
- **Plugin bridge** — existing AgentFlow lifecycle plugins (telemetry, logging) work on SK agents

## Next Steps

- [Getting Started](GETTING_STARTED.md) — install and first agent
- [YAML Reference](YAML_REFERENCE.md) — full schema
- [Modes](MODES.md) — autonomous vs orchestrations vs process
- [Migration](MIGRATION.md) — from `workflows` or `deep`

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
