# Observability

AgentFlow SK provides built-in distributed tracing via OpenTelemetry (OTLP).
Traces are exported to any OTLP-compatible backend — choose your platform at
deployment time through environment variables alone.

Observability is a **deployment concern** — enabled via `.env`, not in
application code. When disabled, there is zero overhead.

## Tracing

### Enable Tracing

Add to your `.env`:

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
```

That's it. Run your agent normally and traces flow to the configured backend.

The SK CLI's banner confirms it:

```
OpenTelemetry tracing enabled
  Service: my-sk-agent
  Endpoint: http://localhost:4317 (grpc)
  SK GenAI diagnostics: on (chat/tool/agent spans)
```

### How It Works

AgentFlow SK uses a two-layer tracing architecture:

1. **Semantic Kernel GenAI diagnostics** (automatic) — when
   `OTEL_TRACES_ENABLED=true`, the CLI sets the SK environment flags
   (`SEMANTICKERNEL_EXPERIMENTAL_GENAI_ENABLE_OTEL_DIAGNOSTICS=true` and
   `_SENSITIVE=true`) so SK's native instrumentation emits spans for chat
   completion calls, tool invocations, and agent turns, with token counts
   and full prompts/completions.

2. **AgentFlow filters** (domain-specific) — the `audit_log`,
   `latency_tracking`, and `cost_tracking` observers compile to SK filters.
   They emit Python log records today; subscribe to the
   `agentflow.sk.filters.builtin` logger to capture per-tool latency and
   cost.

### What Gets Traced

Each run produces spans across several categories:

| Span name                                     | What it represents                                          |
| --------------------------------------------- | ----------------------------------------------------------- |
| `chat.streaming_completions <model>`          | One per LLM call, streamed or not                           |
| `invoke_agent <agent_name>`                   | One per agent turn in a handoff / sequential / group chat   |
| `execute_tool <plugin>-<function>`            | One per `@kernel_function` call                             |
| `AutoFunctionInvocationLoop`                  | Wraps the auto-invoke tool-calling loop                     |
| `Handoff-transfer_to_<agent>`                 | Explicit handoff between agents                             |
| `Handoff-complete_task`                       | Handoff orchestration termination                           |
| `agent_runtime <verb> <agent>.<topic>-<role>` | InProcessRuntime message bus (create/send/process/ack/...)  |

Each LLM span includes:

- `gen_ai.request.model` — model name (e.g. `gpt-4o-mini`)
- `gen_ai.system` — provider (e.g. `openai`)
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
- `gen_ai.response.id`, `gen_ai.response.finish_reason`

Each tool span includes:

- `gen_ai.tool.name`
- `gen_ai.tool.call.arguments` — serialized JSON args
- `gen_ai.tool.call.result` — tool return value (string-coerced)
- `gen_ai.tool.description`

Each agent span includes:

- `gen_ai.agent.name`, `gen_ai.agent.id`, `gen_ai.agent.description`
- `gen_ai.agent.invocation_input` — full chat history sent in
- `gen_ai.agent.invocation_output` — full response produced

!!! note "SK's InProcessRuntime fragments traces"

    SK uses an actor-style message runtime that links messages via
    `FOLLOWS_FROM` rather than parent/child. In Jaeger this appears as
    **multiple separate traces linked by "Follows From" arrows**, not one
    nested tree — the LLM, agent, and tool spans are each rooted under the
    runtime message that scheduled them.

    To find the interesting data, search by operation name in your backend:

    - `chat.streaming_completions` → LLM calls with tokens and prompts
    - `execute_tool` → tool calls with args and results
    - `invoke_agent` → per-agent input/output

    If your backend supports span links (e.g. Tempo, Honeycomb), the
    `FOLLOWS_FROM` edges stitch the scattered traces together in the UI.

### Backend Configuration

The OTEL SDK reads standard environment variables — no code changes needed
per backend. Set `OTEL_EXPORTER_OTLP_ENDPOINT` and optionally
`OTEL_EXPORTER_OTLP_PROTOCOL` and `OTEL_EXPORTER_OTLP_HEADERS` in your `.env`:

#### Jaeger (gRPC)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

Start Jaeger: `docker run -d -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one:latest`

UI: http://localhost:16686

#### Langfuse (HTTP + auth)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <base64(public_key:secret_key)>
```

Generate the base64 value: `echo -n "pk-lf-...:sk-lf-..." | base64`

#### Phoenix by Arize (HTTP)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

Start Phoenix: `docker run -d -p 6006:6006 -p 4317:4317 arizephoenix/phoenix`

UI: http://localhost:6006

#### Azure Monitor (Application Insights / Azure AI Foundry)

Install the built-in exporter extra and set the connection string — no code:

```bash
pip install 'agentflow[azure-monitor]'
OTEL_TRACES_ENABLED=true
APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=https://..."
```

The exporter attaches automatically through AgentFlow's shared exporter seam
(`agentflow.core.telemetry_seam`) — additively, so any OTLP export keeps working
alongside Azure (dual-export). Application Insights can't ingest raw OTLP; this
extra's `AzureMonitorTraceExporter` is the translator. Spans appear in App
Insights and, once that resource is linked to a Foundry project, in the Foundry
Tracing tab.

#### Grafana Tempo (gRPC)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://tempo:4317
```

#### Datadog (via Datadog Agent)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

Enable OTLP ingestion in the Datadog Agent (`datadog.yaml`):

```yaml
otlp_config:
  receiver:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
```

#### New Relic (HTTP + API key)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=https://otlp.nr-data.net
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=api-key=YOUR_LICENSE_KEY
```

#### Honeycomb (HTTP + API key)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-sk-agent
OTEL_EXPORTER_OTLP_ENDPOINT=https://api.honeycomb.io
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=x-honeycomb-team=YOUR_API_KEY
```

## Filters as observers

For operational signals without a tracing backend, enable the built-in
observers in `agent.yaml`:

```yaml
observers:
  - type: audit_log            # per-tool success/failure + latency
  - type: latency_tracking     # latency distribution per function
  - type: cost_tracking        # token accounting (uses execution_settings)
```

They compile to SK filters and emit structured log records on the
`agentflow.sk.filters.builtin` logger. To print them, set:

```bash
AGENTFLOW_LOG_LEVEL=INFO
```

## Redacting sensitive data

When `SEMANTICKERNEL_EXPERIMENTAL_GENAI_ENABLE_OTEL_DIAGNOSTICS_SENSITIVE`
is off, SK still emits LLM/tool/agent spans but drops prompt and completion
content. Turn the sensitive flag off in high-security environments:

```bash
SEMANTICKERNEL_EXPERIMENTAL_GENAI_ENABLE_OTEL_DIAGNOSTICS=true
SEMANTICKERNEL_EXPERIMENTAL_GENAI_ENABLE_OTEL_DIAGNOSTICS_SENSITIVE=false
```

For tool-level redaction, add a custom function-invocation filter — see
[GUARDS](GUARDS.md) for the PII redaction example.

## Log Level Control

Set `AGENTFLOW_LOG_LEVEL` in `.env` to control agentflow's own logging:

```bash
AGENTFLOW_LOG_LEVEL=DEBUG    # DEBUG, INFO, WARNING (default), ERROR
```

## Environment Variables Reference

| Variable                                                            | Description                                                    | Default                 |
| ------------------------------------------------------------------- | -------------------------------------------------------------- | ----------------------- |
| `OTEL_TRACES_ENABLED`                                               | Enable distributed tracing                                     | `false`                 |
| `OTEL_SERVICE_NAME`                                                 | Service name in traces                                         | `agentflow`          |
| `OTEL_EXPORTER_OTLP_ENDPOINT`                                       | OTLP backend endpoint                                          | `http://localhost:4317` |
| `OTEL_EXPORTER_OTLP_PROTOCOL`                                       | `grpc` or `http/protobuf`                                      | `grpc`                  |
| `OTEL_EXPORTER_OTLP_HEADERS`                                        | Auth headers (`key=value`, comma-separated)                    | (none)                  |
| `OTEL_EXPORTER_OTLP_CERTIFICATE`                                    | TLS certificate path                                           | (none)                  |
| `OTEL_EXPORTER_OTLP_TIMEOUT`                                        | Export timeout (ms)                                            | `10000`                 |
| `SEMANTICKERNEL_EXPERIMENTAL_GENAI_ENABLE_OTEL_DIAGNOSTICS`         | Emit SK GenAI spans (chat/tool/agent)                          | auto-set when tracing on |
| `SEMANTICKERNEL_EXPERIMENTAL_GENAI_ENABLE_OTEL_DIAGNOSTICS_SENSITIVE` | Include prompt/completion content on spans                     | auto-set when tracing on |
| `AGENTFLOW_LOG_LEVEL`                                               | AgentFlow log verbosity                                        | `WARNING`               |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
