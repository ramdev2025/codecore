# Plugin Bridge

AgentFlow's `Plugin` ABC (`agentflow.workflows.plugins`) defines lifecycle
event hooks: `on_workflow_start`, `on_tool_call`, `on_tool_result`,
`on_error`, etc. The SK backend's **plugin bridge** wires these events to
SK's kernel filters so existing lifecycle plugins — telemetry, cost
trackers, loggers — work unchanged on SK agents.

!!! note
    SK "plugins" (capabilities) are distinct from AgentFlow "lifecycle
    plugins" (event observers). The bridge only handles the latter.

## Event coverage

| AgentFlow event | Fires on SK? | Source |
|-----------------|--------------|--------|
| `on_tool_call` | ✓ | FUNCTION_INVOCATION / AUTO_FUNCTION_INVOCATION filter |
| `on_tool_result` | ✓ | same |
| `on_error` | ✓ | filter exception + workflow wrapper |
| `on_workflow_start` / `on_workflow_end` | ✓ | `WorkflowLifecycleEmitter` around `.invoke()` |
| `on_agent_start` / `on_agent_end` | ✓ | same |
| `on_llm_start` / `on_llm_end` | partial | PROMPT_RENDERING (not yet bridged by default) |
| `on_mcp_connect` | — | N/A on SK |
| `on_hitl_start` / `on_hitl_end` | — | SK has no HITL primitive |
| `on_external_agent_start` / `_end` | — | SK has no A2A concept |
| `on_checkpoint_save` / `_load` | ✓ | SKPersistenceManager |

Events that don't apply simply never fire — which is correct, since SK
doesn't have those concepts.

## Wiring the bridge

The bridge expects a duck-typed plugin manager (any object with
`emit_tool_call` / `emit_tool_result` / `emit_error` methods). If you're
already using AgentFlow's `PluginManager`, it works as-is.

```python
from agentflow.sk.core.builder import SKAgentBuilder
from agentflow.sk.core.plugin_bridge import (
    register_plugin_bridge,
    WorkflowLifecycleEmitter,
)
from agentflow.workflows.plugins import PluginManager, WorkflowContext

# Build the agent
builder = SKAgentBuilder.from_yaml("agent.yaml")
agent = builder.build()

# Wire the bridge
pm = PluginManager()
pm.discover_and_register_plugins()
context = WorkflowContext(execution_id="...", workflow_name="sk-run")

register_plugin_bridge(builder._shared_kernel, pm, context)

# Emit workflow lifecycle events around the run
with WorkflowLifecycleEmitter(pm, context, agent_name="assistant"):
    async for response in agent.invoke(messages="hi", thread=thread):
        ...

pm.shutdown()
```

## Writing a plugin that works on SK

Plugins that only use the portable event set work on all three backends
(`workflows`, `deep`, `semantic-kernel`) without modification:

```python
from agentflow.workflows.plugins import Plugin, WorkflowContext

class CostLoggerPlugin(Plugin):
    def on_tool_call(self, context, tool_name, inputs):
        print(f"Tool called: {tool_name}")

    def on_tool_result(self, context, tool_name, result):
        print(f"Tool returned: {tool_name}")

    def on_workflow_end(self, context, final_state, status):
        print(f"Workflow finished: {status}")
```

Install via entry point (`agentflow.plugins` group) or drop in
`~/.agentflow/plugins/`.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
