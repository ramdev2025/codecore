# Memory Connectors

Semantic Kernel supports several vector stores. AgentFlow's `memory:`
section creates the store and validates it against the embedding service.
The store instance is surfaced on the builder so your code can wire it
into custom RAG plugins.

## Configuration

```yaml
services:
  - service_id: embeddings
    type: embeddings
    provider: openai
    config:
      model: text-embedding-3-large
      api_key: ${OPENAI_API_KEY}

memory:
  connector: azure_ai_search
  embedding_service_id: embeddings
  config:
    endpoint: ${AZURE_SEARCH_ENDPOINT}
    index_name: docs
    api_key: ${AZURE_SEARCH_KEY}
```

`embedding_service_id` must reference a service declared in `services:`.

## Supported connectors

| Connector | Requires |
|-----------|----------|
| `azure_ai_search` | `pip install azure-search-documents` |
| `qdrant` | `pip install qdrant-client` |
| `chroma` | `pip install chromadb` |
| `redis` | `pip install redis` |
| `custom` | user-provided class |

Each connector lazy-imports its backend library, so you only pay the
dependency cost for what you use.

## Custom connector

```yaml
memory:
  connector: custom
  embedding_service_id: embeddings
  config:
    class_name: myproject.memory.MyVectorStore
    # other kwargs passed to constructor
```

## Accessing the store

The memory store is **not automatically** wired into plugins — SK's vector
store API is broad and changes across versions, so AgentFlow doesn't
prescribe how to use it. Access the instance via the builder:

```python
import agentflow

builder = await agentflow.create("agent.yaml")
store = builder.memory

# Use `store` to build your own RAG plugin with @kernel_function methods,
# or call it directly from your application code.
```

Typical patterns:

- Write a Python plugin (`type: python`) whose `@kernel_function` methods
  call `store` for search/upsert.
- Call `store` directly from your application before passing queries to
  the agent.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
