# Guards, Optimizers, Observers

Three declarative YAML sections map to SK kernel filters:

- **Guards** constrain and protect — PII redaction, rate limits, input validation.
- **Optimizers** improve efficiency — retry, caching, fallback.
- **Observers** watch without modifying — audit log, cost tracking, latency.

All three compile to `async def(context, next)` filters registered on the
kernel. Built-in types ship with implementations; custom types are plugged in
via `module:` + `function:`.

## Guards

```yaml
guards:
  - type: pii
    config: { replacement: "[REDACTED]" }

  - type: model_call_limit
    config: { max_calls: 50 }

  - type: tool_call_limit
    config: { max_calls: 200 }

  - type: input_validation
    module: myproject.validators     # custom only — no built-in
    function: check_prompt
```

Built-in:

| Type | Behavior |
|------|----------|
| `pii` | Regex-based redaction of emails, phone numbers, SSNs (and custom patterns) |
| `model_call_limit` | Terminates auto-function loop after N LLM rounds |
| `tool_call_limit` | Terminates auto-function loop after N tool calls |

Custom-only (no built-in): `input_validation`, `content_filter`.

## Optimizers

```yaml
optimizers:
  - type: tool_retry
    config: { max_retries: 3, delay_seconds: 0.5 }
```

Built-in: `tool_retry`.

Custom-only: `summarization`, `prompt_caching`, `model_fallback`.

## Observers

```yaml
observers:
  - type: audit_log
    config: { level: INFO }

  - type: latency_tracking
    config: { log_every: 10 }

  - type: cost_tracking
    config: { log_threshold: 1000, budget_limit: 10.00 }
```

Built-in: `audit_log`, `latency_tracking`, `cost_tracking`.

## Custom implementations

For any type — built-in or not — you can provide your own filter:

```yaml
guards:
  - type: pii
    module: myproject.filters
    function: my_custom_pii_filter
```

Your filter must follow SK's signature:

```python
# myproject/filters.py
async def my_custom_pii_filter(context, next):
    # BEFORE: inspect/modify context.rendered_prompt, context.arguments
    await next(context)
    # AFTER: inspect/modify context.result
```

## Scoping

Top-level filters apply to the shared Kernel. Per-agent filters apply to
that agent's Kernel only.

```yaml
guards:
  - type: pii                        # applies to all agents

agents:
  - name: billing
    system_prompt: ...
    guards:
      - type: model_call_limit       # applies to billing agent only
        config: { max_calls: 20 }
```

## SK-native filters

For full power (e.g. complex middleware chains, short-circuit logic), use
the `filters:` section directly:

```yaml
filters:
  - type: auto_function_invocation
    module: myproject.filters
    function: custom_tool_selector
```

See [CLI Reference](CLI_REFERENCE.md) for how these filters are wired.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
