# Services (Multi-service kernels)

Semantic Kernel can host multiple AI services on a single Kernel — chat
completion, embeddings, text-to-image, text-to-audio — each registered
with a unique `service_id`. Agents route requests to specific services via
`execution_settings.service_id`.

## Simple case: single service

Use the `llm:` shorthand at the top level:

```yaml
llm:
  provider: openai
  config:
    model: gpt-4o
    api_key: ${OPENAI_API_KEY}

agent:
  name: assistant
  system_prompt: You are helpful.
```

This creates a single chat completion service with `service_id="default"`.

## Multi-service

Use the `services:` list for explicit multi-service setups:

```yaml
services:
  - service_id: chat
    type: chat_completion
    provider: azure_openai
    config:
      # NOTE: For provider=azure_openai, ``model`` is the Azure **deployment
      # name** (not the underlying model family). SK's service factory
      # passes ``params['model']`` straight through as ``deployment_name``
      # to ``AzureChatCompletion``. Mismatching the deployment name causes
      # a ``DeploymentNotFound`` 404 at first request.
      model: ${AZURE_DEPLOYMENT}        # e.g. "my-gpt4o-prod-deployment"
      azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
      api_version: "2024-12-01-preview"
      api_key: ${AZURE_OPENAI_API_KEY}

  - service_id: embeddings
    type: embeddings
    provider: openai
    config:
      model: text-embedding-3-large
      api_key: ${OPENAI_API_KEY}

agent:
  name: rag_agent
  system_prompt: Use knowledge base to answer questions.
  execution_settings:
    service_id: chat        # route this agent's LLM calls to the chat service

memory:
  connector: azure_ai_search
  embedding_service_id: embeddings   # memory uses the embeddings service
```

## Supported service types × providers

| Type ↓ / Provider → | openai | azure_openai | anthropic | custom |
|---|---|---|---|---|
| `chat_completion` | ✓ | ✓ | ✓ | ✓ |
| `embeddings` | ✓ | ✓ | — | ✓ |
| `text_to_image` | ✓ | ✓ | — | ✓ |
| `text_to_audio` | ✓ | ✓ | — | ✓ |

## Azure AD identity

Use Managed Identity / Azure CLI credentials instead of an API key:

```yaml
services:
  - service_id: chat
    type: chat_completion
    provider: azure_openai
    config:
      model: ${AZURE_DEPLOYMENT}        # deployment name, not model family
      azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
      api_version: "2024-12-01-preview"
      azure_identity: true
      azure_oauth_scope: https://cognitiveservices.azure.com/.default  # optional
```

Requires `az login` locally or a managed identity in Azure.

## Custom provider

```yaml
services:
  - service_id: local
    type: chat_completion
    provider: custom
    config:
      class_name: myproject.services.LocalLLM
      # any other params are passed as constructor kwargs
      model_path: /models/llama.gguf
```

The class must accept `service_id=` plus any extra kwargs.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
