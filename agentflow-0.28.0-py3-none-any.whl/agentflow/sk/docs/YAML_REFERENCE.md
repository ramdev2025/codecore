# YAML Reference

Complete schema reference for AgentFlow SK YAML configs.

## Top-level keys

```yaml
backend: semantic-kernel    # required — routes this YAML to the SK backend
mode: <mode>                # required for orchestration and process modes

metadata: { ... }           # required — name, version, description
llm: { ... }                # single-service shorthand
services: [ ... ]           # multi-service kernel (alternative to llm:)

agent: { ... }              # singular — autonomous or process mode
agents: [ ... ]             # plural — orchestration modes

plugins: [ ... ]            # shared plugins
guards: [ ... ]             # shared guards
optimizers: [ ... ]         # shared optimizers
observers: [ ... ]          # shared observers
filters: [ ... ]            # user-provided SK kernel filters
memory: { ... }             # vector memory connector
mcp_servers: { ... }        # MCP server connections

process: { ... }            # single process (with agent: + mode: process)
processes: { ... }          # named processes linked to agents in orchestration

serving: { ... }            # expose agent as an MCP server
```

## Validation rules

1. Exactly one of `agent:` or `agents:` must be present.
2. `agent:` alone (no `mode:`, no `process:`) → **autonomous** mode.
3. `agent:` + `process:` requires `mode: process`.
4. `agents:` (list) requires `mode:` (non-process).
5. `process:` and `processes:` are mutually exclusive.
6. Each `processes:` entry's `agent:` field must reference an `agents:` entry by name.

## `metadata`

```yaml
metadata:
  version: "1.0"              # required
  name: my-config             # optional, human-readable
  description: ...            # optional
  author: team@acme           # optional
  tags: [tag1, tag2]          # optional
```

## `llm` (single-service shorthand)

```yaml
llm:
  provider: openai            # openai | azure_openai | anthropic | custom
  config:
    model: gpt-4o
    api_key: ${OPENAI_API_KEY}
```

Provider-specific config keys:

- **openai**: `model`, `api_key`, `org_id`
- **azure_openai**: `model` (deployment), `azure_endpoint`, `api_version`, `api_key` or `azure_identity: true`
- **anthropic**: `model`, `api_key`
- **custom**: `class_name: full.import.path.Class`

## `services` (multi-service kernel)

```yaml
services:
  - service_id: chat
    type: chat_completion        # chat_completion | embeddings | text_to_image | text_to_audio
    provider: azure_openai
    config: { ... }

  - service_id: embeddings
    type: embeddings
    provider: openai
    config:
      model: text-embedding-3-large
      api_key: ${OPENAI_API_KEY}
```

Agents reference services via `execution_settings.service_id`.

## `agent` / `agents` (AgentSpec)

```yaml
agent:                             # singular for autonomous/process
  name: assistant                  # required
  description: ...                 # used by handoff routing
  system_prompt: You are helpful.  # required
  type: chat_completion            # default; see Agent Types below
  llm: { ... }                     # overrides top-level llm:
  plugins: [ ... ]                 # agent-scoped plugins
  guards: [ ... ]                  # agent-scoped guards
  optimizers: [ ... ]
  observers: [ ... ]
  execution_settings:
    function_choice_behavior: auto # auto | required | none
    function_filter:
      include: [plugin.function]
      exclude: [plugin.dangerous_function]
    service_id: chat
    temperature: 0.7
    max_tokens: 2048
  config: { ... }                  # agent-type-specific kwargs
```

`agents:` is a list of the same shape. **First in list** is the:
- Router — in `mode: handoff`
- Moderator — in `mode: group_chat`
- Orchestrator — in `mode: magentic`
- First step — in `mode: sequential`

### Agent Types

```yaml
agent:
  type: chat_completion       # default — ChatCompletionAgent
  # type: azure_ai            # AzureAIAgent
  # type: openai_assistant    # OpenAIAssistantAgent
  # type: openai_responses    # OpenAIResponsesAgent
  # type: bedrock             # BedrockAgent
  config: { ... }             # agent-type-specific constructor kwargs
```

## `plugins`

```yaml
plugins:
  - name: math                # required
    type: python              # python | prompt | openapi | directory
    module: myproject.tools   # for type: python
    functions: [add, multiply] # optional; default = all @kernel_function

  - name: summarizer
    type: prompt
    description: Summarizes text
    template: Summarize in {{$style}} style: {{$input}}

  - name: weather_api
    type: openapi
    spec_url: https://api.example.com/openapi.json

  - name: skills
    type: directory
    path: ./sk_plugins/my_skills
```

## `guards`, `optimizers`, `observers`

All three share the same shape:

```yaml
guards:
  - type: pii                          # built-in type
    config: { replacement: "[REDACTED]" }

  - type: input_validation             # no built-in — custom required
    module: myproject.filters
    function: check_prompt_safety

optimizers:
  - type: tool_retry
    config: { max_retries: 3, delay_seconds: 0.5 }

observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 10.00 }
```

Built-in types with implementations shipped by AgentFlow:

- **Guards**: `pii`, `model_call_limit`, `tool_call_limit`
- **Optimizers**: `tool_retry`
- **Observers**: `audit_log`, `latency_tracking`, `cost_tracking`

Types without a built-in (`input_validation`, `content_filter`, `summarization`,
`prompt_caching`, `model_fallback`) require custom `module:` + `function:`.

## `filters` (SK-native)

```yaml
filters:
  - type: function_invocation        # function_invocation | prompt_rendering | auto_function_invocation
    module: myproject.filters
    function: custom_filter
```

The function must be `async def(context, next)`.

## `memory`

```yaml
memory:
  connector: azure_ai_search        # azure_ai_search | qdrant | chroma | redis | custom
  embedding_service_id: embeddings  # references services[].service_id
  config:
    endpoint: ${AZURE_SEARCH_ENDPOINT}
    index_name: docs
    api_key: ${AZURE_SEARCH_KEY}
```

## `mcp_servers`

```yaml
mcp_servers:
  local-data:
    transport: stdio                # stdio | sse
    command: python
    args: [-m, my_mcp_server]
    env: { DATABASE_URL: sqlite:///x.db }

  remote:
    transport: sse
    url: https://example.com/mcp/sse
```

## `process` (single process, with `mode: process`)

```yaml
mode: process

agent:
  name: pipeline
  system_prompt: Document processing pipeline.

process:
  entry_step: ingest
  steps:
    - name: ingest
      module: myproject.pipeline
      class_name: IngestStep
    - name: classify
      module: myproject.pipeline
      class_name: ClassifyStep
    - name: respond
      module: myproject.pipeline
      class_name: RespondStep
  events:
    - { from_step: ingest,   event: ready,      to_step: classify }
    - { from_step: classify, event: classified, to_step: respond }
```

Step classes must be `KernelProcessStep` subclasses.

## `processes` (plural — orchestration + step workflows)

```yaml
mode: handoff

agents:
  - name: triage
    system_prompt: Route.
  - name: email_drafter
    description: Drafts emails
    system_prompt: email process

processes:
  email_drafting:
    agent: email_drafter             # links this process to an agent
    entry_step: analyze
    steps: [ ... ]
    events: [ ... ]
```

## `serving`

```yaml
serving:
  mcp_server: true
  server_name: my-agent
```

Expose the agent as an MCP server.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
