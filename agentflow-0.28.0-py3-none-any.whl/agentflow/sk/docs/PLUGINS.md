# Plugins

Semantic Kernel "plugins" are collections of callable functions exposed to
the LLM via automatic function calling. AgentFlow supports all four native
SK plugin types.

!!! note "Terminology"
    SK "plugins" (capabilities) are distinct from AgentFlow "lifecycle
    plugins" (event observers). See [Plugin Bridge](PLUGIN_BRIDGE.md) for
    how lifecycle plugins are wired to SK agents.

!!! warning "Plugin name restrictions"
    SK validates plugin names against `^[0-9A-Za-z_]+$` — letters, digits,
    and underscores only. **Hyphens, spaces, and dots are rejected** and
    surface as a cryptic `FunctionInitializationError: Failed to create
    KernelFunctionMetadata` (ultimately a Pydantic `string_pattern_mismatch`
    against the `plugin_name` field).
    Use `support_tools`, not `support-tools`. The same rule applies to
    function names declared in `@kernel_function(name="...")`.

## Python module plugins

Reference a Python module; all `@kernel_function`-decorated functions
become plugin functions.

```yaml
plugins:
  - name: math
    type: python
    module: myproject.tools.math
    functions: [add, multiply]   # optional — default = all decorated functions
```

Your module:

```python
# myproject/tools/math.py
from semantic_kernel.functions import kernel_function

@kernel_function(name="add", description="Add two numbers")
def add(a: int, b: int) -> int:
    return a + b

@kernel_function(name="multiply", description="Multiply two numbers")
def multiply(a: int, b: int) -> int:
    return a * b
```

## Prompt plugins (semantic functions)

Wrap a prompt template as a callable.

```yaml
plugins:
  - name: summarizer
    type: prompt
    description: Summarizes text in a chosen style
    template: |
      Summarize the following in {{$style}} style:
      {{$input}}
```

The LLM can invoke `summarizer(input=..., style="bullet")` like any other tool.

## OpenAPI plugins

Generate tools automatically from an OpenAPI spec.

```yaml
plugins:
  - name: weather_api
    type: openapi
    spec_url: https://api.weather.com/openapi.json
    # or: spec_path: ./weather.openapi.json
```

## Directory plugins

Load SK's native plugin directory format (folders with `skprompt.txt` +
`config.json`):

```yaml
plugins:
  - name: skills
    type: directory
    path: ./sk_plugins/my_skills
```

## Scoping

Top-level `plugins:` are registered on the **shared Kernel** (visible to
all agents). Per-agent `plugins:` are registered on that agent's Kernel
only.

```yaml
plugins:
  - name: shared_tools         # all agents see this
    type: python
    module: myproject.tools.common

agents:
  - name: billing
    system_prompt: ...
    plugins:
      - name: billing_tools    # only billing agent sees this
        type: python
        module: myproject.tools.billing
```

## LangChain tool migration

If you have LangChain `@tool`-decorated functions from the `workflows` or
`deep` backend, wrap them with `@kernel_function` instead — the function
body stays the same. SK doesn't consume LangChain `StructuredTool` objects
directly.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
