# Getting Started

## 1. Install

```bash
pip install agentflow[semantic-kernel]
```

## 2. Set API keys

```bash
export OPENAI_API_KEY="sk-..."
# Or for Azure OpenAI:
export AZURE_OPENAI_ENDPOINT="https://...openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"
```

## 3. Write a YAML config

Save as `agent.yaml`:

```yaml
backend: semantic-kernel

metadata:
  version: "1.0"
  name: assistant

llm:
  provider: openai
  config:
    model: gpt-4o
    api_key: ${OPENAI_API_KEY}

agent:
  name: assistant
  system_prompt: You are a helpful assistant.
```

## 4. Validate

```bash
agentflow --yaml agent.yaml --dry-run
```

Output:

```
AgentFlow SK
Run Semantic Kernel agents from the command line

  Backend    semantic-kernel
  Config     agent.yaml
  Name       assistant
  Mode       autonomous
  Agents     assistant

Config is valid.
```

## 5. Run

```bash
agentflow --yaml agent.yaml "What is 2+2?"
```

## 6. Add tools

Create `myproject/tools.py`:

```python
from semantic_kernel.functions import kernel_function

@kernel_function(name="add", description="Add two numbers")
def add(a: int, b: int) -> int:
    return a + b
```

Reference it in YAML:

```yaml
agent:
  name: assistant
  system_prompt: You are a math assistant.
  plugins:
    - name: math
      type: python
      module: myproject.tools
```

## 7. Multi-agent handoff

```yaml
backend: semantic-kernel
mode: handoff

metadata:
  version: "1.0"
  name: support

llm:
  provider: openai
  config: { model: gpt-4o, api_key: ${OPENAI_API_KEY} }

agents:
  - name: triage
    system_prompt: Route customer requests to the right specialist.

  - name: billing
    description: Handles invoices, refunds, payment issues
    system_prompt: You are a billing specialist.

  - name: tech
    description: Handles bugs, outages, technical issues
    system_prompt: You are a technical support specialist.
```

First agent in the list is the router. Subsequent agents are specialists.

## Next

- [YAML Reference](YAML_REFERENCE.md) for the full schema
- [Modes](MODES.md) to learn about sequential / group_chat / magentic / process
- [Plugin Bridge](PLUGIN_BRIDGE.md) to wire telemetry

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
