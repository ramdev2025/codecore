# Production Features

AgentFlow SK is designed for production deployment from day one. Every
feature below is **declarative** — it lives in `agent.yaml` or environment
variables, not in application code — so behavior can be tuned without
touching business logic.

This page is a single reference for the enterprise-grade capabilities that
come out of the box.

## Feature Summary

### Orchestration & Multi-Agent

| Feature                  | YAML location                  | Value                                                                       | Docs                        |
| ------------------------ | ------------------------------ | --------------------------------------------------------------------------- | --------------------------- |
| Handoff orchestration    | `mode: handoff`                | Router delegates work to specialist agents via tool calls                   | [MODES](MODES.md)           |
| Sequential orchestration | `mode: sequential`             | Deterministic pipeline — each agent receives the previous agent's output    | [MODES](MODES.md)           |
| Group chat orchestration | `mode: group_chat`             | Multiple agents deliberate on a task with a manager enforcing turn-taking   | [MODES](MODES.md)           |
| Magentic orchestration   | `mode: magentic`               | Planner-executor pattern with dynamic delegation                            | [MODES](MODES.md)           |
| Process workflows        | `mode: process`                | Event-driven stateful workflows with explicit step graphs                   | [MODES](MODES.md)           |
| Multi-service kernel     | `services:` (list)             | One agent uses chat + embeddings + image + audio models simultaneously      | [SERVICES](SERVICES.md)     |
| Per-agent execution settings | `execution_settings:`      | Pick temperature, model, function choice behavior per specialist            | [YAML](YAML_REFERENCE.md)   |

### Guards — Constrain and Protect

Guards enforce policy and prevent runaway agents. Compiled to Semantic Kernel
filters.

| Guard                | Purpose                                                                  | Configured in |
| -------------------- | ------------------------------------------------------------------------ | ------------- |
| `model_call_limit`   | Hard cap on LLM calls per run; prevents pathological loops               | `guards:`     |
| `tool_call_limit`    | Hard cap on tool invocations per run                                     | `guards:`     |
| `pii_redaction`      | Redact personally identifiable information before it reaches the model   | `guards:`     |
| Custom filters       | Drop-in SK `FilterTypes.*` filters (function / prompt / auto-invocation) | `filters:`    |

See [GUARDS](GUARDS.md) for full configuration and custom-filter authoring.

### Optimizers — Improve Efficiency

SK ships one built-in optimizer today. Three additional types
(`prompt_caching`, `summarization`, `model_fallback`) are recognized
by the schema but have no built-in implementation — declaring them
without a `module:` + `function:` reference hard-errors at startup.
This is intentional: SK's filter API doesn't expose the hooks these
optimizers need (cache-metadata, message-history compression, model
swap), so a one-size-fits-all built-in would be misleading. Other
backends with native support (ADK, OAI) handle these inside their
SDKs.

| Optimizer        | Built-in? | Purpose                                                                  | Configured in |
| ---------------- | --------- | ------------------------------------------------------------------------ | ------------- |
| `tool_retry`     | ✓         | Retry failed tool calls with exponential backoff                         | `optimizers:` |
| `prompt_caching` | ✗ custom  | Track / log prompt-cache hits — supply your own SK filter                | `optimizers:` |
| `summarization`  | ✗ custom  | Compress long conversation history — supply your own SK filter          | `optimizers:` |
| `model_fallback` | ✗ custom  | Fail over to a secondary model on error — supply your own SK filter      | `optimizers:` |

To use a custom filter for an unsupported optimizer:

```yaml
optimizers:
  - type: prompt_caching
    module: myproject.filters.cache
    function: cache_filter      # async def(context, next) → None
```

### Observers — Watch Without Modifying

| Observer           | Purpose                                                                  | Configured in |
| ------------------ | ------------------------------------------------------------------------ | ------------- |
| `audit_log`        | Per-function success/failure + latency to Python logger                  | `observers:`  |
| `latency_tracking` | Latency distribution per kernel function                                 | `observers:`  |
| `cost_tracking`    | Token accounting and budget enforcement                                  | `observers:`  |

### Persistence & State

| Feature                  | YAML / CLI location                  | Value                                                          | Docs                            |
| ------------------------ | ------------------------------------ | -------------------------------------------------------------- | ------------------------------- |
| In-memory persistence    | `--persistence memory`               | Zero-overhead ephemeral threads for tests and stateless jobs   | [PERSISTENCE](PERSISTENCE.md)   |
| SQLite persistence       | default; `--db-path` overrides       | File-based threads, zero configuration                         | [PERSISTENCE](PERSISTENCE.md)   |
| PostgreSQL persistence   | `--persistence postgres`             | Connection-pooled threads for multi-instance services          | [PERSISTENCE](PERSISTENCE.md)   |
| AES-GCM encryption at rest | `AGENTFLOW_ENCRYPTION_KEY`         | Encrypts `ChatHistory` payloads; AES-128/192/256               | [PERSISTENCE](PERSISTENCE.md)   |
| Thread-based isolation   | `--thread-id`                        | Each user/session has a private conversation history           | [PERSISTENCE](PERSISTENCE.md)   |

### Observability & Cost Control

| Feature                           | YAML / env location                                                   | Value                                                                        | Docs                              |
| --------------------------------- | --------------------------------------------------------------------- | ---------------------------------------------------------------------------- | --------------------------------- |
| Distributed tracing (OTel)        | `OTEL_TRACES_ENABLED=true`                                            | OTLP spans to Jaeger, Langfuse, Phoenix, Datadog, New Relic, Honeycomb, …    | [OBSERVABILITY](OBSERVABILITY.md) |
| Built-in GenAI spans              | auto-set by `setup_tracing`                                           | Per-call LLM spans with token counts, prompts, completions, finish reasons   | [OBSERVABILITY](OBSERVABILITY.md) |
| Tool-level spans                  | auto-set by `setup_tracing`                                           | Per-tool arguments and results                                               | [OBSERVABILITY](OBSERVABILITY.md) |
| Handoff tracing                   | automatic in handoff mode                                             | Handoff decisions emit their own spans                                       | [OBSERVABILITY](OBSERVABILITY.md) |
| Token-level streaming             | always on                                                             | Tokens render in the CLI as they arrive                                      | [CLI_REFERENCE](CLI_REFERENCE.md) |
| Cost-budget enforcement           | `observers: [{type: cost_tracking, config: {budget_limit: 25.00}}]`   | Stops execution when the budget is exceeded                                  | [GUARDS](GUARDS.md)               |
| Audit logging                     | `observers: [{type: audit_log}]`                                      | Structured log records per tool call (enable with `AGENTFLOW_LOG_LEVEL=INFO`) | [GUARDS](GUARDS.md)               |

### Integrations

| Integration                   | YAML location        | Value                                                                                   | Docs                              |
| ----------------------------- | -------------------- | --------------------------------------------------------------------------------------- | --------------------------------- |
| MCP tools (stdio, SSE)        | `mcp_servers:`       | Use any Model Context Protocol server as a plugin — no custom code                      | [MCP](MCP.md)                     |
| Memory connectors             | `memory:`            | Azure AI Search, Qdrant, Chroma, Redis, or a custom connector                           | [MEMORY](MEMORY.md)               |
| Python plugins                | `plugins: type: python` | Any module of `@kernel_function`-decorated functions                                 | [PLUGINS](PLUGINS.md)             |
| Prompt plugins                | `plugins: type: prompt` | Prompt templates with parameters, variables, chaining                                | [PLUGINS](PLUGINS.md)             |
| OpenAPI plugins               | `plugins: type: openapi` | Instant tool from any OpenAPI spec                                                  | [PLUGINS](PLUGINS.md)             |
| SK directory plugins          | `plugins: type: directory` | Import SK's native plugin directory format                                        | [PLUGINS](PLUGINS.md)             |
| Cross-backend lifecycle events | plugin bridge       | Workflows `Plugin` hooks (telemetry, logging) fire on SK agents too                     | [PLUGIN_BRIDGE](PLUGIN_BRIDGE.md) |
| Agent-as-MCP-server           | `serving:`           | Expose an SK agent as an MCP endpoint — other agents or tools can call it over MCP     | [MCP](MCP.md)                     |

### Agent Types

| Type                 | Value                                                                                               |
| -------------------- | --------------------------------------------------------------------------------------------------- |
| `chat_completion`    | Standard ChatCompletion agent (default; works with OpenAI, Azure OpenAI, Anthropic, any SK connector) |
| `azure_ai`           | Azure AI agent — managed execution on Azure AI platform                                             |
| `openai_assistant`   | OpenAI Assistants API — server-managed threads and retrieval                                        |
| `openai_responses`   | OpenAI Responses API — newer model-managed tool calling                                             |
| `bedrock`            | AWS Bedrock-hosted foundation models                                                                |

### LLM Providers

| Provider          | Auth                                                  |
| ----------------- | ----------------------------------------------------- |
| OpenAI            | `api_key`                                             |
| Azure OpenAI      | `api_key` or `azure_identity: true` (RBAC via `az login`) |
| Anthropic         | `api_key`                                             |
| AWS Bedrock       | IAM / profile                                         |
| Custom            | Any SK `AIServiceClientBase` subclass via `plugins:`  |

---

## Why These Matter

- **Constrain risk, don't hope for the best.** `model_call_limit` and
  `tool_call_limit` mean a broken loop costs pennies instead of dollars.
  `pii_redaction` means sensitive fields never leave your process.
- **See what your agents are doing.** OTel spans carry token counts,
  prompts, completions, tool args and results. Cost becomes a known
  quantity, not a surprise invoice.
- **Deploy without rewrites.** Memory → SQLite → PostgreSQL is one CLI
  flag. Encryption at rest is one env var. No code changes.
- **Scale horizontally.** Postgres persistence + thread IDs = as many
  workers as you need, all sharing conversation state safely.
- **Plug in your enterprise stack.** OTLP traces go anywhere (Azure
  Monitor, Datadog, New Relic, Splunk). Memory connectors cover all the
  common vector stores. MCP servers add tools without custom glue.
- **Stay vendor-flexible.** Multi-service kernels and per-agent
  `execution_settings` let you mix providers — cheap model for routing,
  premium model for drafting — in the same YAML.

---

## Complete Example

A production handoff orchestration using Azure OpenAI RBAC, guards,
observers, encrypted Postgres persistence, and OTel tracing:

```yaml
backend: semantic-kernel

metadata:
  version: "1.0"
  name: customer-support

services:
  - service_id: gpt-4o
    type: chat_completion
    provider: azure_openai
    config:
      model: ${AZURE_DEPLOYMENT}
      azure_endpoint: ${AZURE_OPENAI_ENDPOINT}
      api_version: ${OPENAI_API_VERSION}
      azure_identity: true

mode: handoff

agents:
  - name: triage
    description: Routes support requests to specialists
    system_prompt: |
      Route to the right specialist by calling the matching transfer tool.
    execution_settings:
      service_id: gpt-4o
      function_choice_behavior: required
  - name: billing
    description: Handles billing questions
    plugins:
      - { name: billing_tools, type: python, module: myapp.billing }
    execution_settings: { service_id: gpt-4o }
  - name: technical
    description: Handles technical questions
    plugins:
      - { name: tech_tools, type: python, module: myapp.technical }
    execution_settings: { service_id: gpt-4o }

guards:
  - type: model_call_limit
    config: { max_calls: 50 }
  - type: tool_call_limit
    config: { max_calls: 200 }
  - type: pii_redaction
    config: { patterns: [email, phone, ssn] }

optimizers:
  - type: tool_retry
    config: { max_retries: 2 }
  # ``summarization`` has no SK built-in — supply a custom filter to use it:
  # - type: summarization
  #   module: myapp.filters.summarize
  #   function: summarize_history

observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 25.00, currency: USD }
```

Runtime configuration stays in `.env`:

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=customer-support
OTEL_EXPORTER_OTLP_ENDPOINT=https://otel.your-collector.com:4317
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Bearer ${OTEL_TOKEN}

AGENTFLOW_ENCRYPTION_KEY=${VAULT_SECRET_AGENT_AES_KEY}

AZURE_OPENAI_ENDPOINT=https://your-account.openai.azure.com
AZURE_DEPLOYMENT=gpt-4o
OPENAI_API_VERSION=2024-12-01-preview
```

Invoke:

```bash
agentflow --yaml agent.yaml \
  --persistence postgres \
  --connection-string "${DATABASE_URL}" \
  --thread-id "user-${USER_ID}" \
  "${USER_MESSAGE}"
```

---

## Comparison with Other AgentFlow Backends

| Feature                    | workflows | deep | sk (this page)           |
| -------------------------- | --------- | ---- | ------------------------ |
| YAML-driven                | Yes       | Yes  | Yes                      |
| Unified CLI / API          | Yes       | Yes  | Yes                      |
| OTel tracing               | Yes       | Yes  | Yes                      |
| Persistence (mem/SQLite/PG)| Yes       | Yes  | Yes                      |
| AES-GCM encryption         | Yes       | Yes  | Yes                      |
| Native Microsoft SK agents | No        | No   | Yes                      |
| Multi-agent orchestration modes | graph    | supervisor | handoff / sequential / group chat / magentic / process |
| Multi-service kernels      | No        | No   | Yes (chat+embed+image+audio) |
| Process (event-driven) mode | No       | No   | Yes                      |
| OpenAPI plugin type        | No        | No   | Yes                      |
| OpenAI Assistants / Responses API | No | No   | Yes                      |

See [MIGRATION](MIGRATION.md) for when to choose SK over workflows or deep.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
