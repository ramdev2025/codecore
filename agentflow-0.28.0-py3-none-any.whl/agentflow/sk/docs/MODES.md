# Agent Modes

AgentFlow SK supports six execution patterns. The YAML structure signals
which pattern applies:

| Mode | YAML structure | `mode:` field | Use when |
|------|----------------|---------------|----------|
| Autonomous | `agent:` alone | (omitted) | Single agent, LLM decides tool calls |
| Handoff | `agents:` list | `handoff` | Triage routes to specialists |
| Sequential | `agents:` list | `sequential` | Pipeline — each agent feeds next |
| Group chat | `agents:` list | `group_chat` | Debate / multiple perspectives |
| Magentic | `agents:` list | `magentic` | Planner + workers (Magentic-One) |
| Process | `agent:` + `process:` | `process` | Deterministic step workflow |

## Autonomous

```yaml
backend: semantic-kernel

metadata: { version: "1.0", name: research }
llm: { provider: openai, config: { model: gpt-4o } }

agent:
  name: research_assistant
  system_prompt: Research and answer questions using tools.
  plugins:
    - name: web
      type: python
      module: myproject.tools.search
```

**How it runs:** user query → agent loops (tool call → observation → ...) →
final answer. LLM decides the sequence.

## Handoff

First agent in `agents:` routes to the rest.

```yaml
mode: handoff

agents:
  - name: triage
    system_prompt: Route requests.
  - name: billing
    description: Billing questions
    system_prompt: You are a billing specialist.
  - name: tech
    description: Technical issues
    system_prompt: You are a tech specialist.
```

## Sequential

List order = execution order.

```yaml
mode: sequential

agents:
  - name: researcher
    system_prompt: Gather facts.
  - name: writer
    system_prompt: Write a draft from the research.
  - name: editor
    system_prompt: Polish the draft.
```

## Group Chat

First agent is the moderator.

```yaml
mode: group_chat

agents:
  - name: moderator
    system_prompt: Facilitate the debate.
  - name: optimist
    system_prompt: Argue the optimistic view.
  - name: skeptic
    system_prompt: Challenge claims.
```

## Magentic

First agent is the orchestrator; others are workers.

```yaml
mode: magentic

agents:
  - name: orchestrator
    system_prompt: Decompose tasks and delegate.
  - name: web_surfer
    description: Browses the web
    system_prompt: Extract info from websites.
  - name: coder
    description: Writes code
    system_prompt: Solve problems with Python.
```

## Process

Deterministic step workflow. Steps are Python classes; events route between them.

```yaml
mode: process

agent:
  name: pipeline
  system_prompt: Document processing pipeline.

process:
  entry_step: ingest
  steps:
    - name: ingest
      module: myproject.pipeline
      class_name: IngestStep
    - name: classify
      module: myproject.pipeline
      class_name: ClassifyStep
  events:
    - { from_step: ingest, event: ready, to_step: classify }
```

!!! note
    Process mode is runnable programmatically via
    `SKAgentBuilder.from_yaml().build()`. CLI execution isn't supported
    because the entry step's input shape depends on user step classes.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
