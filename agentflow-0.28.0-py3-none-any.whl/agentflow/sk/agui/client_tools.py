"""Frontend-implemented (client-side) tool stubs for the SK AG-UI bridge.

The agent calls a ``@client_tools``-declared tool like any other kernel
function; the function body raises :class:`ClientToolPause`, which the
:mod:`agentflow.sk.agui.router` catches mid-stream, surfaces as an
``Interrupt`` AG-UI event, and ends the run. The browser executes the
tool and resumes by posting a ``role: "tool"`` message in the next
``RunAgentInput``; the router converts that into a fake function-result
message in the agent's conversation history and the agent resumes.

This is the SK analogue of the LangGraph ``interrupt(...)`` primitive
the workflows / deep backends use. SK has no built-in pause/resume so
we synthesize one with exceptions.

``available_when`` enforcement on SK is build-time only (see
``DeepAvailabilityMiddleware`` for the LangGraph-based per-call
mechanism workflows / deep use). If a tool's predicate evaluates
falsy against ``build_state``, the kernel function is never registered;
the LLM never sees it and can't call it.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agentflow.genui import ClientToolConfig

logger = logging.getLogger(__name__)


class ClientToolPause(Exception):
    """Raised by a client_tool stub body to pause the agent run.

    The SK AG-UI router catches this exception, emits an ``Interrupt``
    AG-UI event with the tool name + args, and ends the stream.
    The browser's tool handler runs, then posts the result back as a
    ``role:"tool"`` message; the router converts that into a
    ``FunctionResultContent`` injected into the conversation history
    on the next turn.
    """

    def __init__(self, tool_name: str, args: dict[str, Any]) -> None:
        # Call ``super().__init__`` *before* setting attributes — Python's
        # ``BaseException.__init__`` writes to ``self.args`` and would
        # clobber our payload otherwise.
        super().__init__(f"client_tool pause: {tool_name}({args})")
        self.tool_name = tool_name
        self.tool_args = args


def register_client_tools_on_kernel(
    kernel: Any,
    specs: list["ClientToolConfig"],
    *,
    plugin_name: str = "client_tools",
) -> None:
    """Register each client_tool as a kernel function whose body raises
    :class:`ClientToolPause`.

    Called by the SK AG-UI router at orchestrator-build time when
    ``bind_client_tools=True``. The kernel functions are discoverable
    by the LLM (it sees them in the auto-function-choice surface);
    calling one immediately raises through the agent stream and is
    caught by the orchestrator.

    Args:
        kernel: The ``semantic_kernel.Kernel`` to register on.
        specs: List of ``ClientToolConfig`` instances from YAML.
        plugin_name: Name for the SK plugin grouping these functions.
    """
    try:
        from semantic_kernel.functions import (
            KernelFunctionFromMethod,
            KernelPlugin,
            kernel_function,
        )
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "Semantic Kernel is required for the SK AG-UI bridge. "
            "Install agentflow[sk]."
        ) from exc

    functions = []
    for spec in specs:
        functions.append(_make_kernel_function(spec, kernel_function, KernelFunctionFromMethod))

    plugin = KernelPlugin(name=plugin_name, functions=functions)
    kernel.add_plugin(plugin)


def _make_kernel_function(spec: "ClientToolConfig", kernel_function: Any, KernelFunctionFromMethod: Any) -> Any:
    """Build a kernel function whose body raises ClientToolPause when invoked."""
    tool_name = spec.name
    description = spec.description or ""

    # SK introspects the wrapped callable's annotations to build the
    # tool schema the LLM sees. We mirror the JSON schema declared in
    # ``ClientToolConfig.parameters`` by attaching the raw schema as
    # the function's docstring metadata; the explicit annotation is
    # ``**kwargs`` so SK accepts arbitrary structured args.
    @kernel_function(name=tool_name, description=description)
    def stub(**kwargs: Any) -> str:
        raise ClientToolPause(tool_name=tool_name, args=dict(kwargs))

    # Attach the canonical JSON schema for downstream introspection.
    stub.__agentflow_client_tool_schema__ = spec.parameters  # type: ignore[attr-defined]
    return KernelFunctionFromMethod(method=stub, plugin_name=None)


def build_client_tool_result_message(tool_call_id: str, content: str) -> dict:
    """Build the SK-side conversation entry for a resumed client_tool result.

    Called by the router when a ``role:"tool"`` message arrives in the
    next ``RunAgentInput``. The returned dict is appended to the SK
    chat history so the next ``invoke_stream`` sees the function
    result and continues the agent loop.
    """
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": content if isinstance(content, str) else json.dumps(content),
    }
