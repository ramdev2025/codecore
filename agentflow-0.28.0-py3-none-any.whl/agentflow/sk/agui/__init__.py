"""AG-UI bridge for the SK (Semantic Kernel) backend.

Brings the AG-UI HTTP+SSE protocol to YAML-driven Semantic Kernel
agents. AgentFlow owns the bridge — SK has no published upstream
AG-UI package (unlike MAF), so this sub-package carries the full
implementation:

  * :mod:`events` — Pydantic wire models for AG-UI events
  * :mod:`adapter` — stateful event translator from orchestrator
    events to AG-UI wire events
  * :mod:`client_tools` — ``ClientToolPause``-exception-based stubs
    (SK lacks a ``langgraph.interrupt`` equivalent, so we synthesize
    one with raised exceptions caught at the orchestrator layer)
  * :mod:`router` — FastAPI router + ``build_agui`` public entrypoint

The public entrypoint is :func:`build_agui`. Mount the returned
``(router, lifespan)`` into your own FastAPI app::

    from fastapi import FastAPI
    from agentflow.sk.agui import build_agui

    router, lifespan = build_agui(yaml_path="agent.yaml")
    app = FastAPI(lifespan=lifespan)
    app.include_router(router, prefix="/agui")

What SK gets vs the LangGraph-based bridges
-------------------------------------------

  * ``ui_tools`` ✓ — same cross-backend YAML, kernel functions are
    discovered from ``@agentflow.genui.ui_component`` decorators
  * Text streaming ✓ — via ``ChatCompletionAgent.invoke_stream``
  * Tool call lifecycle events ✓ — translated from SK's
    ``FunctionCallContent`` / ``FunctionResultContent``
  * ``client_tools`` ✓ (exception-based; per-process state, not
    durable across restarts)
  * ``available_when`` (build-time only — SK has no clean per-call
    hide-from-list hook; same caveat as MAF)
  * State persistence: in-memory only (SK has no LangGraph-style
    checkpointer)
"""

from .adapter import AGUIAdapter, translate_stream
from .client_tools import (
    ClientToolPause,
    build_client_tool_result_message,
    register_client_tools_on_kernel,
)
from .events import (
    AGUIEvent,
    CustomEvent,
    EventType,
    Interrupt,
    InterruptOutcome,
    RunError,
    RunFinished,
    RunStarted,
    StateDelta,
    StateSnapshot,
    TextMessageContent,
    TextMessageEnd,
    TextMessageStart,
    ToolCallArgs,
    ToolCallEnd,
    ToolCallResult,
    ToolCallStart,
    render_component,
)
from .router import build_agui

__all__ = [
    "AGUIAdapter",
    "AGUIEvent",
    "ClientToolPause",
    "CustomEvent",
    "EventType",
    "Interrupt",
    "InterruptOutcome",
    "RunError",
    "RunFinished",
    "RunStarted",
    "StateDelta",
    "StateSnapshot",
    "TextMessageContent",
    "TextMessageEnd",
    "TextMessageStart",
    "ToolCallArgs",
    "ToolCallEnd",
    "ToolCallResult",
    "ToolCallStart",
    "build_agui",
    "build_client_tool_result_message",
    "register_client_tools_on_kernel",
    "render_component",
    "translate_stream",
]
