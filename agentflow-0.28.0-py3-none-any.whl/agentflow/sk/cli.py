"""
AgentFlow SK CLI — run Semantic Kernel agents from the unified ``agentflow``
command.

The CLI router dispatches ``backend: semantic-kernel`` to ``run_from_router``
in this module. It translates canonical flags into SK-specific objects,
executes the agent/orchestration/process, and streams output to the
console.

Supported modes:

- **dry-run** — validate the YAML and print a summary (no SK dependencies
  on the execution path)
- **one-shot** — run a single query and print the response
- **interactive** — REPL loop with persistence across turns

Persistence (`--persistence`, `--db-path`, `--thread-id`) uses
``SKPersistenceManager`` to save/resume ``ChatHistory`` by thread.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any, Optional

from agentflow.cli import (
    ExecutionTimer,
    console,
    print_agent_response,
    print_banner,
    print_config_table,
    print_error,
    print_execution_summary,
    print_info,
    print_reasoning_marker,
    print_token,
    print_tool_call,
    print_tool_result,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_AGENT_SWITCH,
    EVENT_COMPLETE,
    EVENT_ERROR,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)


def run_from_router(
        yaml_path: str,
        query: Optional[str] = None,
        persistence: Optional[str] = None,
        db_path: Optional[str] = None,
        connection_string: Optional[str] = None,
        thread_id: Optional[str] = None,
        interactive: bool = False,
        dry_run: bool = False,
        json_output: bool = False,
        output: str = "tty",
        **_ignored: Any,
):
    """Entry point called by the unified CLI router.

    Translates canonical flags to SK-internal parameters and runs the
    configured agent/orchestration/process. Extra kwargs from the canonical
    flag set (``workdir``, ``no_tui``, ``recursion_limit``, ``tools_module``)
    are absorbed via ``**_ignored`` — they belong to other backends.

    Persistence precedence: ``--persistence`` flag > ``AGENTFLOW_PERSISTENCE``
    env var > default (sqlite).
    """
    from dotenv import find_dotenv, load_dotenv

    # find_dotenv() defaults to walking up from the caller's file — which is
    # this module in site-packages, not the user's project. usecwd=True anchors
    # the search at the shell's current working directory so the user's
    # project-local .env wins.
    _env_path = find_dotenv(usecwd=True)
    if _env_path:
        load_dotenv(_env_path, override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(getattr(logging, log_level, logging.WARNING))

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    if persistence is None:
        persistence = os.environ.get("AGENTFLOW_PERSISTENCE", "sqlite").strip().lower()

    # ---- Dry-run (no SK construction needed) ------------------------------
    if dry_run:
        _run_dry(yaml_path, json_output=json_output)
        return

    json_sink: Optional[JsonSink] = JsonSink(backend="semantic-kernel") if is_json_mode(output) else None
    if json_sink is None:
        print_banner("AgentFlow SK", "Run Semantic Kernel agents from the command line")

    # ---- Tracing (opt-in via OTEL_TRACES_ENABLED=true) -------------------
    from agentflow.sk.telemetry import setup_tracing

    setup_tracing()

    # ---- Build agent ------------------------------------------------------
    try:
        from agentflow.sk.core.builder import SKAgentBuilder
    except ImportError:
        print_error(
            "semantic-kernel is required but not installed. "
            "Install with: pip install agentflow[semantic-kernel]"
        )
        raise SystemExit(1)

    builder = SKAgentBuilder.from_yaml(yaml_path)
    runner = builder.build()

    # ---- Persistence -----------------------------------------------------
    pm = _build_persistence(persistence, db_path, connection_string)
    tid = thread_id or str(uuid.uuid4())
    if json_sink is None:
        _print_run_header(yaml_path, persistence, tid)

    # ---- Interactive vs one-shot -----------------------------------------
    if interactive and json_sink is None:
        _run_interactive(runner, pm, tid)
    else:
        if not query:
            query = prompt_user("Query") if json_sink is None else ""
        if not query:
            return
        _run_one_shot(runner, query, pm, tid, json_sink=json_sink)


# ---------------------------------------------------------------------------
# Dry-run
# ---------------------------------------------------------------------------


def _run_dry(yaml_path: str, json_output: bool = False) -> None:
    """Validate YAML and print a summary — does not require SK at runtime."""
    try:
        from agentflow.sk.core.builder import SKAgentBuilder
    except ImportError:
        print_error(
            "semantic-kernel is required but not installed. "
            "Install with: pip install agentflow[semantic-kernel]"
        )
        raise SystemExit(1)

    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    builder = SKAgentBuilder.from_yaml(yaml_path)
    summary = builder.dry_run()

    if json_output:
        print(json.dumps(summary, indent=2, default=str))
        return

    print_banner("AgentFlow SK", "Run Semantic Kernel agents from the command line")
    rows = [
        ("Backend", "semantic-kernel"),
        ("Config", yaml_path),
        ("Name", summary["metadata"].get("name") or "-"),
        ("Mode", summary["mode"] or "-"),
        ("Agents", ", ".join(summary["agents"]) or "-"),
    ]
    if summary["services"]:
        rows.append(("Services", ", ".join(summary["services"])))
    if summary["plugins"]:
        rows.append(("Plugins", ", ".join(summary["plugins"])))
    if summary["guards"]:
        rows.append(("Guards", ", ".join(summary["guards"])))
    if summary["optimizers"]:
        rows.append(("Optimizers", ", ".join(summary["optimizers"])))
    if summary["observers"]:
        rows.append(("Observers", ", ".join(summary["observers"])))
    if summary["memory"]:
        rows.append(("Memory", summary["memory"]))
    if summary["mcp_servers"]:
        rows.append(("MCP Servers", ", ".join(summary["mcp_servers"])))
    if summary["process_steps"]:
        rows.append(("Process Steps", ", ".join(summary["process_steps"])))
    if summary["processes"]:
        rows.append(("Processes", ", ".join(summary["processes"])))
    if summary["serving"]:
        rows.append(("Serving", "MCP server"))

    print_config_table(rows)
    console.print("[bold green]Config is valid.[/bold green]")


# ---------------------------------------------------------------------------
# One-shot and interactive
# ---------------------------------------------------------------------------


def _run_one_shot(
        runner: Any,
        query: str,
        pm: Optional[Any],
        thread_id: str,
        json_sink: Optional[JsonSink] = None,
) -> None:
    """Run a single query and print/emit the response."""
    if json_sink is None:
        console.print()
    timer = ExecutionTimer()
    timer.start()
    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    response_text = asyncio.run(
        _invoke_runner(runner, query, pm, thread_id, json_sink=json_sink)
    )
    if json_sink is not None:
        if response_text:
            json_sink.emit(EVENT_TOKEN, name="Agent", content=response_text)
        json_sink.emit(EVENT_STATS, elapsed_s=timer.elapsed())
        json_sink.emit(EVENT_COMPLETE)
        return
    if response_text:
        print_agent_response("Agent", response_text)
    print_execution_summary(console, timer.elapsed())


def _run_interactive(runner: Any, pm: Optional[Any], thread_id: str) -> None:
    """Run a continuous REPL loop, preserving conversation across turns."""
    init_history()
    repl_state = ReplState(thread_id=thread_id)
    console.print(
        "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, "
        "[bold]/quit[/bold] to exit\n"
    )
    while True:
        try:
            q = prompt_user("Query")
            if is_quit_alias(q):
                console.print("\nGoodbye.")
                break
            if not q.strip():
                continue
            if is_slash_command(q):
                if dispatch_slash_command(q, repl_state, console) == "quit":
                    console.print("\nGoodbye.")
                    break
                continue

            console.print()
            timer = ExecutionTimer()
            timer.start()
            response_text = asyncio.run(_invoke_runner(runner, q, pm, thread_id))
            if response_text:
                print_agent_response("Agent", response_text)
            print_execution_summary(console, timer.elapsed())
        except (KeyboardInterrupt, EOFError):
            console.print("\nGoodbye.")
            break
        except Exception as e:
            from agentflow.cli.errors import friendly_error
            print_error(friendly_error(e))
    cleanup_terminal_state()


# ---------------------------------------------------------------------------
# Stream renderer — converts SK StreamingChatMessageContent items to terminal
# output that matches the maf/oai/workflows pattern.
# ---------------------------------------------------------------------------


class _StreamRenderer:
    """Renders SK ``StreamingChatMessageContent.items`` as inline output.

    SK exposes a typed item list per chunk:

    - ``StreamingTextContent`` (``content_type='text'``) → streamed inline
    - ``FunctionCallContent`` (``content_type='function_call'``) → ``▸ name(args)``,
      with arguments accumulated across deltas (SK fragments JSON like MAF)
    - ``FunctionResultContent`` (``content_type='function_result'``) →
      ``← name result · N chars`` plus preview/pretty-JSON

    Agent switches (``→ agent: <name>``) are surfaced in orchestration mode
    when ``message.name`` changes between chunks.
    """

    def __init__(self) -> None:
        self._streaming_text = False
        self._current_author: Optional[str] = None
        self._reasoning_active = False
        self._printed_call_ids: set[str] = set()
        # call_id → {"name": str, "args": str | dict}
        # Mirrors MAF's renderer — SK fragments function_call arguments
        # across chunks so we buffer until they look complete.
        self._pending_calls: dict[str, dict] = {}

    def render_message(self, message: Any, *, surface_author_switch: bool = False) -> None:
        """Render one SK ``StreamingChatMessageContent``.

        ``surface_author_switch`` is True for orchestration mode (multiple
        agents speaking in turn) and False for single-agent mode (no
        ``→ agent:`` marker needed).
        """
        try:
            if surface_author_switch:
                author = getattr(message, "name", None) or getattr(message, "author_name", None)
                if author and author != self._current_author:
                    self._end_text_stream()
                    self._reasoning_active = False
                    if self._current_author is not None:
                        console.print(
                            f"[bold green]→[/bold green] agent: [bold]{author}[/bold]",
                            highlight=False,
                        )
                    self._current_author = author

            for item in getattr(message, "items", None) or []:
                self._render_item(item)
        except Exception as e:  # pragma: no cover
            console.print(f"[dim red](SK render error: {e})[/dim red]")

    def flush(self) -> None:
        self._flush_pending_calls()
        self._end_text_stream()

    # -- Item dispatch -----------------------------------------------------

    def _render_item(self, item: Any) -> None:
        ctype = getattr(item, "content_type", None)

        if ctype == "text":
            text = getattr(item, "text", None) or ""
            if text:
                self._reasoning_active = False
                self._stream_text(text)
            return

        if ctype == "function_call":
            self._accumulate_call(item)
            return

        if ctype == "function_result":
            call_id = getattr(item, "call_id", None) or getattr(item, "id", None)
            if call_id:
                self._flush_pending_call(call_id)
            self._end_text_stream()
            self._reasoning_active = False
            name = getattr(item, "name", None) or "tool"
            result = getattr(item, "result", None)
            print_tool_result(name, result)
            return

        # Some SK builds emit a ``reasoning`` content type for o1-class models.
        if ctype in ("reasoning", "text_reasoning"):
            if not self._reasoning_active:
                self._end_text_stream()
                print_reasoning_marker()
                self._reasoning_active = True
            return

    def _accumulate_call(self, item: Any) -> None:
        call_id = getattr(item, "call_id", None) or getattr(item, "id", None)
        if call_id and call_id in self._printed_call_ids:
            return
        name = getattr(item, "name", None) or getattr(item, "function_name", None) or "<tool>"
        args = getattr(item, "arguments", None)

        if not call_id:
            self._emit_call(name, args)
            return

        pending = self._pending_calls.get(call_id)
        if pending is None:
            self._pending_calls[call_id] = {"name": name, "args": args}
        else:
            if name and not pending.get("name"):
                pending["name"] = name
            pending["args"] = _merge_call_args(pending.get("args"), args)

        if _args_look_complete(self._pending_calls[call_id]["args"]):
            self._flush_pending_call(call_id)

    def _flush_pending_call(self, call_id: str) -> None:
        pending = self._pending_calls.pop(call_id, None)
        if pending is None or call_id in self._printed_call_ids:
            return
        self._printed_call_ids.add(call_id)
        self._emit_call(pending.get("name") or "<tool>", pending.get("args"))

    def _flush_pending_calls(self) -> None:
        for call_id in list(self._pending_calls.keys()):
            self._flush_pending_call(call_id)

    def _emit_call(self, name: str, args: Any) -> None:
        self._end_text_stream()
        self._reasoning_active = False
        print_tool_call(name, args)

    def _stream_text(self, text: str) -> None:
        if not self._streaming_text:
            console.print()
            self._streaming_text = True
        print_token(text)

    def _end_text_stream(self) -> None:
        if self._streaming_text:
            console.print()
            self._streaming_text = False


def _merge_call_args(existing: Any, incoming: Any) -> Any:
    """Concatenate streamed function-call argument deltas.

    SK fragments function-call argument JSON the same way MAF does, so
    we use the same merge logic — concat strings (deduping when the
    server resends), prefer incoming dict.
    """
    if incoming is None:
        return existing
    if existing is None:
        return incoming
    if isinstance(existing, str) and isinstance(incoming, str):
        if incoming.startswith(existing):
            return incoming
        if existing.endswith(incoming):
            return existing
        return existing + incoming
    if isinstance(incoming, dict):
        return incoming
    return incoming if incoming else existing


def _args_look_complete(args: Any) -> bool:
    if args is None:
        return False
    if isinstance(args, dict):
        return True
    if isinstance(args, str):
        s = args.strip()
        if not s:
            return False
        try:
            json.loads(s)
            return True
        except Exception:
            return False
    return True


# ---------------------------------------------------------------------------
# JSON-event emission
# ---------------------------------------------------------------------------


def _emit_sk_message(
        sink: JsonSink,
        message: Any,
        *,
        surface_author_switch: bool = False,
) -> None:
    """Translate one SK ``StreamingChatMessageContent`` into ndjson events.

    Mirrors the dispatch in :class:`_StreamRenderer` — text fragments
    become ``token`` events, function-call items become ``tool_call``
    (no buffering: we emit the partial as-is and rely on consumers to
    coalesce by ``call_id``), function-result items become ``tool``,
    reasoning items become a single ``reasoning`` event.

    Author switches in orchestration mode are surfaced separately by
    the caller (it has the prior-author state); here we only emit the
    inner items.
    """
    for item in getattr(message, "items", None) or []:
        ctype = getattr(item, "content_type", None)
        if ctype == "text":
            text = getattr(item, "text", None) or ""
            if text:
                sink.emit(EVENT_TOKEN, content=text)
        elif ctype == "function_call":
            name = (
                getattr(item, "name", None)
                or getattr(item, "function_name", None)
                or "<tool>"
            )
            sink.emit(
                EVENT_TOOL_CALL,
                name=name,
                args=getattr(item, "arguments", None),
                call_id=getattr(item, "call_id", None) or getattr(item, "id", None),
            )
        elif ctype == "function_result":
            sink.emit(
                EVENT_TOOL,
                name=getattr(item, "name", None) or "tool",
                content=getattr(item, "result", None),
                call_id=getattr(item, "call_id", None) or getattr(item, "id", None),
            )
        elif ctype in ("reasoning", "text_reasoning"):
            sink.emit(EVENT_REASONING)


# ---------------------------------------------------------------------------
# SK invocation (dispatches by runner type)
# ---------------------------------------------------------------------------


async def _invoke_runner(
        runner: Any,
        query: str,
        pm: Optional[Any],
        thread_id: str,
        json_sink: Optional[JsonSink] = None,
) -> str:
    """Invoke the runner and return the final response text.

    Dispatches by runner type:
    - ``ChatCompletionAgent`` (and subclasses) → ``agent.invoke(messages, thread)``
    - Orchestration (HandoffOrchestration, etc.) → ``orchestration.invoke(task, runtime)``
    - ``KernelProcess`` → uses SK's process start API
    """
    from semantic_kernel.agents import ChatCompletionAgent

    if isinstance(runner, ChatCompletionAgent):
        return await _invoke_agent(runner, query, pm, thread_id, json_sink=json_sink)

    # Orchestration
    orchestration_bases = _orchestration_base_classes()
    if orchestration_bases and isinstance(runner, orchestration_bases):
        return await _invoke_orchestration(runner, query, json_sink=json_sink)

    # Process — no ChatHistory; run via runtime
    return await _invoke_process(runner, query)


def _orchestration_base_classes() -> tuple:
    """Return a tuple of orchestration classes for isinstance checks."""
    try:
        from semantic_kernel.agents.orchestration.orchestration_base import OrchestrationBase
        return (OrchestrationBase,)
    except ImportError:
        return ()


async def _invoke_agent(
        agent: Any,
        query: str,
        pm: Optional[Any],
        thread_id: str,
        json_sink: Optional[JsonSink] = None,
) -> str:
    """Invoke a ChatCompletionAgent with optional thread persistence.

    Streams via ``agent.invoke_stream()`` so tool calls, results, and
    text appear inline as they happen. Falls back to ``agent.invoke()``
    if the SDK build doesn't expose ``invoke_stream``. When
    ``json_sink`` is provided, items are emitted as ndjson events and
    the terminal renderer is bypassed.
    """
    thread = None
    if pm is not None:
        thread = pm.load_as_thread(thread_id)
    if thread is None:
        from semantic_kernel.agents import ChatHistoryAgentThread
        thread = ChatHistoryAgentThread(thread_id=thread_id)

    response_text_parts: list[str] = []
    last_thread = thread
    streamed = False

    if hasattr(agent, "invoke_stream"):
        streamed = True
        renderer = _StreamRenderer() if json_sink is None else None
        try:
            async for response in agent.invoke_stream(messages=query, thread=thread):
                # Each yielded ``response`` wraps a StreamingChatMessageContent
                # in ``.message`` (newer builds) or *is* one (older builds).
                msg = getattr(response, "message", None) or response
                if json_sink is not None:
                    _emit_sk_message(json_sink, msg, surface_author_switch=False)
                else:
                    renderer.render_message(msg, surface_author_switch=False)
                last_thread = getattr(response, "thread", last_thread)
        finally:
            if renderer is not None:
                renderer.flush()
    else:
        # Fallback: non-streaming invoke. Output is the panel-after pattern.
        async for response in agent.invoke(messages=query, thread=thread):
            content = getattr(response, "message", None) or response
            text = getattr(content, "content", None) or str(content)
            response_text_parts.append(str(text))
            last_thread = getattr(response, "thread", last_thread)

    if pm is not None and last_thread is not None:
        history = getattr(last_thread, "_chat_history", None) or getattr(
            last_thread, "chat_history", None
        )
        if history is not None:
            pm.save(thread_id, history)

    # When streamed, the renderer already printed the response inline —
    # return "" to suppress the duplicate panel in _run_one_shot.
    if streamed:
        return ""
    return "".join(response_text_parts).strip()


async def _invoke_orchestration(
        orchestration: Any,
        query: str,
        json_sink: Optional[JsonSink] = None,
) -> str:
    """Invoke an orchestration with a fresh runtime and stream tokens.

    Routes streaming chunks through ``_StreamRenderer`` so tool calls,
    results, and agent switches surface the same way they do in the
    single-agent case (and in maf/oai/workflows). The non-streaming
    callback is still used to dedupe the orchestrator's final summary
    against streamed text.
    """
    from semantic_kernel.agents.runtime import InProcessRuntime

    intermediate_parts: list[str] = []
    renderer = _StreamRenderer() if json_sink is None else None
    # Track current author across chunks for the agent_switch event.
    switch_state: dict[str, Any] = {"current": None}

    def _on_stream_chunk(chunk: Any, is_final: bool) -> None:
        # SK calls this with a StreamingChatMessageContent.
        if json_sink is not None:
            author = getattr(chunk, "name", None) or getattr(chunk, "author_name", None)
            if author and author != switch_state["current"]:
                if switch_state["current"] is not None:
                    json_sink.emit(EVENT_AGENT_SWITCH, name=author)
                switch_state["current"] = author
            _emit_sk_message(json_sink, chunk, surface_author_switch=False)
        else:
            renderer.render_message(chunk, surface_author_switch=True)
            if is_final:
                renderer.flush()

    def _on_agent_response(message: Any) -> None:
        content = getattr(message, "content", None)
        if content:
            intermediate_parts.append(str(content).strip())

    if getattr(orchestration, "_streaming_agent_response_callback", None) is None:
        orchestration._streaming_agent_response_callback = _on_stream_chunk
    if getattr(orchestration, "_agent_response_callback", None) is None:
        orchestration._agent_response_callback = _on_agent_response

    runtime = InProcessRuntime()
    runtime.start()
    try:
        result = await orchestration.invoke(task=query, runtime=runtime)
        final = await result.get()
        if renderer is not None:
            renderer.flush()
        final_text = str(final) if final is not None else ""
        # Stream already printed the real output. Only return the final text
        # if it's something new (e.g. a specialist called complete_task with a
        # meaningful summary that wasn't streamed).
        if final_text and "No handoff agent name provided" not in final_text:
            if intermediate_parts and final_text.strip() == intermediate_parts[-1].strip():
                return ""
            return final_text
        return ""
    finally:
        await runtime.stop_when_idle()


async def _invoke_process(process: Any, query: str) -> str:
    """Invoke a process — API varies with SK version; surface a helpful error."""
    # Process invocation requires user-provided start events that match the
    # entry step's signature. We can't infer that generically.
    raise NotImplementedError(
        "Process-mode invocation from the CLI is not yet supported — "
        "the entry step's input shape depends on your step classes. "
        "Run the process programmatically via SKAgentBuilder.from_yaml().build()."
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_persistence(
        backend: str,
        db_path: Optional[str],
        connection_string: Optional[str],
) -> Optional[Any]:
    """Create a persistence manager, unless ``backend == 'memory'`` is explicit."""
    try:
        from agentflow.sk.core.persistence import create_persistence_manager
    except ImportError:
        return None
    return create_persistence_manager(
        backend=backend,
        db_path=db_path,
        connection_string=connection_string,
    )


def _print_run_header(yaml_path: str, persistence: str, thread_id: str) -> None:
    print_info(f"Config: {yaml_path}")
    print_info(f"Persistence: {persistence}")
    print_info(f"Thread: {thread_id}")
    console.print()
