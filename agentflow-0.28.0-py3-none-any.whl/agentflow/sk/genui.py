"""SK adapter for the cross-backend ``ui_tools`` vocabulary.

Takes a :class:`agentflow.genui.UIToolsConfig` (declared in YAML as
``agent.ui_tools``), scans the referenced module for
``@ui_component``-decorated fetchers, and returns an SK
``KernelPlugin`` containing one ``KernelFunction`` per fetcher.

Each wrapped function, when invoked, runs the original fetcher,
validates the return value against the declared Pydantic class, and
returns the props as a JSON string. The LLM consumes the JSON as the
tool's result — without an upstream AG-UI bridge for SK, there is no
frontend-rendering channel, so the chat-side text is the only output.

Why no frontend channel on SK
-----------------------------

MAF has Microsoft's first-party ``agent_framework_ag_ui`` bridge to
ship typed render events to a CopilotKit frontend. SK has no
equivalent upstream package, and AgentFlow's harness-configurator
framing keeps us out of the business of *building* one. SK users who
want generative UI on the frontend would need to bring their own
bridge — see ``src/agentflow/sk/docs/AG_UI.md`` (if/when added) for
the known patterns.

Tool name vs component name
---------------------------

Same convention as MAF: the SK function is named after the
**fetcher function** (e.g. ``get_portfolio_overview``), not the
Pydantic component class name (``PortfolioOverview``). The class
name is attached as ``_agentflow_component_name`` on the resulting
KernelFunction so :mod:`agentflow.sk.availability` can map
predicates (keyed by class name) to functions (named after the
fetcher).
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
import logging
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from agentflow.genui import (
    UIToolsConfig,
    discover_ui_components,
    get_component_class,
)

logger = logging.getLogger(__name__)


def resolve_ui_tools(
    config: UIToolsConfig | None,
    *,
    plugin_name: str = "ui_tools",
) -> Any | None:
    """Build an SK ``KernelPlugin`` from a ``UIToolsConfig``.

    Returns ``None`` when ``config`` is ``None`` so callers can
    short-circuit unconditionally.

    Args:
        config: The parsed ``ui_tools:`` YAML block.
        plugin_name: SK plugin name to expose the wrapped functions
            under. Defaults to ``"ui_tools"``; override when integrating
            with apps that already register a plugin with that name.

    Returns:
        A ``semantic_kernel.functions.KernelPlugin`` ready for
        ``kernel.add_plugin(plugin)``. ``None`` if no fetchers were
        discovered or ``config`` was None.

    Raises:
        ImportError: If ``semantic_kernel`` isn't installed. SK users
            get here by declaring ``ui_tools`` on an SK agent, so the
            error message points at the install path.
        ValueError: If ``config.use`` names a component the module
            doesn't expose.
    """
    if config is None:
        return None

    try:
        from semantic_kernel.functions import KernelFunctionFromMethod, KernelPlugin
    except ImportError as exc:  # pragma: no cover — covered by import-error test
        raise ImportError(
            "semantic-kernel is required to resolve ui_tools on the SK backend. "
            "Install via `pip install agentflow[semantic-kernel]`."
        ) from exc

    discovered = discover_ui_components(config.module)
    if config.use is not None:
        missing = sorted(set(config.use) - set(discovered.keys()))
        if missing:
            available = sorted(discovered.keys())
            raise ValueError(
                f"ui_tools.use names component(s) not found in "
                f"{config.module!r}: {missing}. Available: {available}"
            )
        discovered = {n: discovered[n] for n in config.use}

    if not discovered:
        return None

    functions: list[Any] = []
    for component_name, fetcher in discovered.items():
        wrapped_method = _wrap_for_sk(component_name, fetcher)
        kf = KernelFunctionFromMethod(method=wrapped_method, plugin_name=plugin_name)
        # Tag so the availability filter can map class name → KernelFunction.
        kf._agentflow_component_name = component_name  # type: ignore[attr-defined]
        functions.append(kf)

    return KernelPlugin(name=plugin_name, functions=functions)


def _wrap_for_sk(component_name: str, fetcher: Callable[..., Any]) -> Callable[..., Any]:
    """Wrap a ``@ui_component`` fetcher as an SK-compatible method.

    The wrapper:
      * decorates with ``@kernel_function`` so SK can introspect it,
      * preserves the fetcher's signature for accurate schema generation,
      * validates the return against the declared Pydantic class,
      * returns the props as a JSON string — the LLM's view of the
        tool result.

    Sync and async fetchers are both supported. The kernel_function
    decorator handles either when wrapped properly.
    """
    component_cls = get_component_class(fetcher)
    if component_cls is None:  # pragma: no cover — discover_ui_components guards
        raise RuntimeError(f"{fetcher} is not @ui_component-decorated")

    # Lazy import so this module is importable without semantic-kernel
    # installed (matters for unit tests that mock the SK surface).
    from semantic_kernel.functions import kernel_function

    description = (fetcher.__doc__ or f"Render the {component_name} component.").strip()
    tool_name = fetcher.__name__

    is_async = asyncio.iscoroutinefunction(fetcher)

    if is_async:

        @kernel_function(name=tool_name, description=description)
        @functools.wraps(fetcher)
        async def async_wrapper(*args: Any, **kwargs: Any) -> str:
            result = await fetcher(*args, **kwargs)
            return _to_tool_result(component_name, component_cls, result)

        async_wrapper.__signature__ = inspect.signature(fetcher)  # type: ignore[attr-defined]
        return async_wrapper

    @kernel_function(name=tool_name, description=description)
    @functools.wraps(fetcher)
    def sync_wrapper(*args: Any, **kwargs: Any) -> str:
        result = fetcher(*args, **kwargs)
        return _to_tool_result(component_name, component_cls, result)

    sync_wrapper.__signature__ = inspect.signature(fetcher)  # type: ignore[attr-defined]
    return sync_wrapper


def _to_tool_result(
    component_name: str,
    component_cls: type[BaseModel],
    result: Any,
) -> str:
    """Validate the fetcher's return and serialize for SK consumption.

    SK functions return a string; the LLM consumes it as the tool
    result. Without an AG-UI bridge there's no separate frontend
    channel, so the JSON-formatted props ARE the result.

    Mirrors the MAF wrapper's lenient validation: accepts either a
    class instance or a dict that validates against the class. Bad
    shapes return an ``[Name failed] ...`` string the LLM can react to.
    """
    if isinstance(result, component_cls):
        instance = result
    elif isinstance(result, dict):
        try:
            instance = component_cls.model_validate(result)
        except Exception as exc:
            return f"[{component_name} failed] dict didn't validate: {exc}"
    else:
        return (
            f"[{component_name} failed] fetcher must return a {component_name} "
            f"instance or a dict, got {type(result).__name__}"
        )

    # In-band ``__component__`` marker so the SK AG-UI adapter picks
    # it up and emits a ``CUSTOM RenderComponent`` event. Matches the
    # workflows / deep convention; the underscores keep the key from
    # ever colliding with a real prop on the Pydantic class.
    payload = {"__component__": component_name, **instance.model_dump()}
    return json.dumps(payload)
