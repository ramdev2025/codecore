"""Async orchestrator for the SK AG-UI bridge.

Thin wrapper around ``ChatCompletionAgent.invoke_stream`` plus per-
thread :class:`semantic_kernel.contents.ChatHistory` management.
Exposes the surface :mod:`agentflow.sk.agui.router` needs:

  * :meth:`run` — async generator yielding orchestrator events as
    dicts in the format the AG-UI adapter consumes:
    ``{"type": "agent_start" | "token" | "agent" | "agent_end"
              | "tool_call" | "tool" | "interrupt", ...}``
  * :meth:`get_state` — returns a state-snapshot dict so the bridge
    resilience checks (paused-thread re-surface) can detect pending
    interrupts. SK has no checkpointer; we store per-thread state
    in an in-memory dict (per-process — not durable). This is
    sufficient for AG-UI client_tool resume flows within a session.
  * :meth:`cleanup` — releases SK kernel / MCP resources via the
    underlying builder.

SK runtime differs from LangGraph in two important ways the bridge
papers over:

  1. **No interrupt primitive.** Client_tools use a custom
     ``ClientToolPause`` exception (see
     :mod:`agentflow.sk.agui.client_tools`); the orchestrator
     catches it, yields an ``{"type": "interrupt", ...}`` event,
     and ends the stream.
  2. **No checkpointer.** Per-thread chat history is held in an
     in-memory ``dict[thread_id, ChatHistory]``. Not durable across
     process restarts but adequate for a session.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AsyncSKAGUIRuntime:
    """Async runtime wrapping a Semantic Kernel ChatCompletionAgent."""

    def __init__(
        self,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> None:
        from .builder import SKAgentBuilder

        self._config_path = config_path
        self._builder: Optional[SKAgentBuilder] = None
        self._agent: Any = None
        self._kernel: Any = None
        self._thread_histories: dict[str, Any] = {}
        # ``_paused_threads[thread_id]`` carries the pending interrupt
        # payload so a subsequent GET state / resume request can find it.
        self._paused_threads: dict[str, dict[str, Any]] = {}

        self._build_state = build_state or {}
        self._bind_client_tools = bind_client_tools

    @classmethod
    async def create(
        cls,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> "AsyncSKAGUIRuntime":
        """Async factory: build the agent so the first ``run`` is hot."""
        from .builder import SKAgentBuilder

        inst = cls(
            config_path=config_path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )
        # Load YAML + build the agent. The builder reads ui_tools,
        # client_tools, available_when straight from the schema.
        inst._builder = SKAgentBuilder.from_yaml(
            config_path,
            build_state=inst._build_state,
        )
        inst._agent = inst._builder.build()
        inst._kernel = getattr(inst._agent, "kernel", None)

        if bind_client_tools and inst._kernel is not None:
            from agentflow.sk.agui.client_tools import register_client_tools_on_kernel

            parsed = inst._builder.config
            # SKYAMLConfig supports multiple agent shapes; we just need
            # the per-agent client_tools list. The builder exposes the
            # active spec on ``.agent``.
            spec = getattr(parsed, "agent", None)
            if spec is not None and getattr(spec, "client_tools", None):
                register_client_tools_on_kernel(inst._kernel, spec.client_tools)

        return inst

    async def cleanup(self) -> None:
        """Release SK kernel / MCP resources."""
        if self._builder is not None and hasattr(self._builder, "close"):
            self._builder.close()

    async def get_state(self, thread_id: str) -> dict[str, Any]:
        """Return a state snapshot the AG-UI bridge can inspect.

        SK has no checkpointer; we synthesize a snapshot from the
        in-memory thread history + paused-interrupts map so the
        bridge's resilience checks (paused-thread re-surface) work.
        """
        from types import SimpleNamespace

        tasks = ()
        pending = self._paused_threads.get(thread_id)
        if pending is not None:
            intr = SimpleNamespace(id=pending["id"], value=pending["value"])
            task = SimpleNamespace(id=f"task-{thread_id}", interrupts=(intr,))
            tasks = (task,)

        history = self._thread_histories.get(thread_id)
        values: dict[str, Any] = {}
        if history is not None:
            values["message_count"] = len(getattr(history, "messages", []) or [])

        return {"values": values, "tasks": tasks, "next": ()}

    async def run(
        self,
        state: Any,
        config: dict,
        stream_tokens: bool = False,
    ):
        """Yield orchestrator events translated from SK's stream.

        ``state`` is either a state-input dict (``{"messages":
        [{"role": "user", "content": "..."}]}``) or a langgraph-style
        ``Command`` carrying a ``resume`` payload (synthesised by
        the AG-UI router for client_tool / HITL resumes).

        SK's ``invoke_stream`` only emits the final assistant text when
        ``function_choice_behavior=auto`` (it auto-invokes functions
        internally and hides the calls from the stream). To surface
        tool calls on the AG-UI wire, we register an
        ``auto_function_invocation`` filter that pushes ``tool_call``
        and ``tool`` events onto an asyncio queue this run drains
        concurrently with the text stream.
        """
        import asyncio

        from semantic_kernel.contents import ChatHistory
        from semantic_kernel.filters import FilterTypes

        from agentflow.sk.agui.client_tools import ClientToolPause

        thread_id = (config.get("configurable") or {}).get("thread_id") or "default"

        # Resume vs fresh-turn detection. The router passes
        # ``state`` either as a dict (fresh turn) or as a
        # ``Command(resume=...)`` (HITL / client_tool result).
        from langgraph.types import Command

        history = self._thread_histories.setdefault(thread_id, ChatHistory())

        resume_payload: Any = None
        if isinstance(state, Command):
            resume_payload = state.resume
        elif isinstance(state, dict) and state.get("messages"):
            # Fresh user turn — append the last user message to history.
            for msg in state["messages"]:
                if msg.get("role") == "user" and msg.get("content"):
                    history.add_user_message(msg["content"])

        if resume_payload is not None:
            # A client_tool's frontend handler returned a result; the
            # paused tool call is in ``self._paused_threads[thread_id]``.
            pending = self._paused_threads.pop(thread_id, None)
            if pending is not None:
                tool_name = pending["value"].get("tool_name")
                content = resume_payload if isinstance(resume_payload, str) else str(resume_payload)
                # Inject as a function-result message so the LLM sees the
                # browser's output as the tool's return value.
                history.add_message({
                    "role": "tool",
                    "tool_call_id": pending["id"],
                    "content": content,
                    "name": tool_name,
                })
            else:
                logger.warning(
                    "Resume requested for thread=%s but no paused interrupt found",
                    thread_id,
                )

        # Auto-function-invocation filter: pushes tool_call/tool events
        # onto a per-run queue so the AG-UI wire sees them. Registered
        # for the lifetime of this run only (removed in ``finally``).
        tool_event_queue: asyncio.Queue = asyncio.Queue()

        async def _auto_function_filter(context: Any, next: Any) -> None:  # noqa: A002 - SK contract uses ``next``
            next_ = next  # rebind so the body can refer to the callable safely
            fn = context.function
            fn_name = (
                getattr(fn, "fully_qualified_name", None)
                or getattr(fn, "name", None)
                or ""
            )
            args = {}
            try:
                kargs = getattr(context, "arguments", None)
                if kargs is not None:
                    args = {k: v for k, v in dict(kargs).items() if k != "_chat_history"}
            except Exception:
                pass
            tool_event_queue.put_nowait({
                "type": "tool_call",
                "name": fn_name.split("-")[-1] if "-" in fn_name else fn_name,
                "args": args,
            })

            await next_(context)

            result = None
            try:
                fr = context.function_result
                if fr is not None:
                    result = getattr(fr, "value", None)
                    if result is None:
                        result = str(fr)
            except Exception:
                pass
            tool_event_queue.put_nowait({
                "type": "tool",
                "name": fn_name.split("-")[-1] if "-" in fn_name else fn_name,
                "content": result,
            })

        # Register on the agent's kernel
        self._kernel.add_filter(FilterTypes.AUTO_FUNCTION_INVOCATION, _auto_function_filter)

        if stream_tokens:
            yield {"type": "agent_start", "name": "sk-agent", "content": ""}

        accumulated_text = ""

        try:
            # Drive ``invoke_stream`` as a background task so we can
            # interleave its outputs with tool_events from the filter
            # queue. SK's stream only yields text deltas when
            # auto-invoke is on; tool call info comes via the filter.
            stream_done = asyncio.Event()
            stream_items: asyncio.Queue = asyncio.Queue()
            stream_error: list[BaseException] = []

            async def _drain_stream() -> None:
                try:
                    async for item in self._agent.invoke_stream(messages=history):
                        await stream_items.put(item)
                except BaseException as exc:  # noqa: BLE001 — propagate
                    stream_error.append(exc)
                finally:
                    stream_done.set()

            stream_task = asyncio.create_task(_drain_stream())

            while True:
                # Drain any queued tool events first
                while not tool_event_queue.empty():
                    yield tool_event_queue.get_nowait()
                # Then pick up any stream items
                if not stream_items.empty():
                    item = stream_items.get_nowait()
                    message = getattr(item, "message", item)
                    for content in list(getattr(message, "items", []) or []):
                        ctype = type(content).__name__
                        if ctype.startswith("Streaming") and ctype.endswith("TextContent"):
                            text = getattr(content, "text", None) or ""
                            if text and stream_tokens:
                                accumulated_text += text
                                yield {"type": "token", "name": "sk-agent", "content": text}
                    plain = getattr(message, "content", None)
                    if plain and not accumulated_text and stream_tokens:
                        accumulated_text += plain
                        yield {"type": "token", "name": "sk-agent", "content": plain}
                    continue
                # Nothing immediate — check if we're done
                if stream_done.is_set() and stream_items.empty() and tool_event_queue.empty():
                    break
                # Wait a tick for more activity
                await asyncio.sleep(0.01)

            if stream_error:
                raise stream_error[0]
            await stream_task

        except ClientToolPause as pause:
            # Synthesise an interrupt event the router translates into
            # the AG-UI RunFinished outcome.
            import uuid

            interrupt_id = uuid.uuid4().hex[:12]
            payload = {
                "type": "agentflow:client_tool",
                "tool_name": pause.tool_name,
                "args": pause.tool_args,
            }
            self._paused_threads[thread_id] = {
                "id": interrupt_id,
                "value": payload,
            }
            yield {
                "type": "interrupt",
                "interrupts": [{
                    "id": interrupt_id,
                    "reason": "agentflow:client_tool",
                    "tool_name": pause.tool_name,
                    "metadata": {"args": pause.tool_args},
                }],
            }
            return

        if stream_tokens:
            yield {"type": "agent_end", "name": "sk-agent"}

        # Append the final assistant message to history for the next turn.
        if accumulated_text:
            history.add_assistant_message(accumulated_text)
