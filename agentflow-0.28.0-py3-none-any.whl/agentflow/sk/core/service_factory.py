"""
Service factory for creating SK-native AI service instances from YAML config.

Supports multi-service kernels: chat completion, embeddings, text-to-image,
text-to-audio. Each service is registered on the Kernel with a unique
``service_id`` so agents can route requests to specific services.

The factory is called by the builder in two modes:

1. **Multi-service** (``services:`` section in YAML) — creates each service
   listed and registers them with their declared ``service_id``.
2. **Single-service shorthand** (``llm:`` at top level) — creates a single
   chat completion service with ``service_id="default"``.
"""

from typing import Any

from .config_models import LLMConfig, LLMProvider, ServiceConfig, ServiceType


# Provider × service type matrix:
#
#                 chat_completion    embeddings       text_to_image    text_to_audio
# openai          OpenAIChatCompl.   OpenAITextEmb.   OpenAITextToIm.  OpenAITextToAudio
# azure_openai    AzureChatCompl.    AzureTextEmb.    AzureTextToIm.   AzureTextToAudio
# anthropic       AnthropicChatCo.   —                —                —
# custom          user-provided dynamically


class ServiceFactory:
    """Creates SK AI services from YAML service configs."""

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @staticmethod
    def create_service(config: ServiceConfig) -> Any:
        """Create an SK service instance from a ``ServiceConfig``.

        Args:
            config: A validated ``ServiceConfig`` entry from YAML.

        Returns:
            A provider-specific SK service instance (e.g.
            ``OpenAIChatCompletion``, ``AzureTextEmbedding``). The caller
            registers it on the Kernel via ``kernel.add_service(...)``.

        Raises:
            ImportError: semantic-kernel or a connector package isn't
                installed.
            ValueError: Unsupported provider × service-type combination.
        """
        if config.type == ServiceType.CHAT_COMPLETION:
            return ServiceFactory._create_chat_completion(config)
        elif config.type == ServiceType.EMBEDDINGS:
            return ServiceFactory._create_embeddings(config)
        elif config.type == ServiceType.TEXT_TO_IMAGE:
            return ServiceFactory._create_text_to_image(config)
        elif config.type == ServiceType.TEXT_TO_AUDIO:
            return ServiceFactory._create_text_to_audio(config)
        else:
            raise ValueError(f"Unsupported service type: {config.type}")

    @staticmethod
    def create_service_from_llm(llm_config: LLMConfig, service_id: str = "default") -> Any:
        """Create a single chat completion service from a top-level ``llm:`` shorthand.

        Used when the YAML has ``llm:`` at the top level instead of a full
        ``services:`` list. Equivalent to creating a ``ServiceConfig`` with
        ``type=CHAT_COMPLETION`` and the given ``service_id``.
        """
        svc_config = ServiceConfig(
            service_id=service_id,
            type=ServiceType.CHAT_COMPLETION,
            provider=llm_config.provider,
            config=dict(llm_config.config),
        )
        return ServiceFactory.create_service(svc_config)

    @staticmethod
    def service_display_string(config: ServiceConfig) -> str:
        """Return 'provider:model' for display purposes (dry-run summaries)."""
        model = config.config.get("model", "")
        return f"{config.provider.value}:{model}" if model else config.provider.value

    # ------------------------------------------------------------------
    # Chat completion
    # ------------------------------------------------------------------

    @staticmethod
    def _create_chat_completion(config: ServiceConfig) -> Any:
        provider = config.provider
        params = dict(config.config)

        if provider == LLMProvider.OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import OpenAIChatCompletion
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return OpenAIChatCompletion(
                service_id=config.service_id,
                ai_model_id=params.get("model"),
                api_key=params.get("api_key"),
                org_id=params.get("org_id"),
            )

        if provider == LLMProvider.AZURE_OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return AzureChatCompletion(
                service_id=config.service_id,
                deployment_name=params.get("model"),
                endpoint=params.get("azure_endpoint"),
                api_version=params.get("api_version"),
                api_key=params.get("api_key"),
                ad_token_provider=_resolve_azure_token_provider(params),
            )

        if provider == LLMProvider.ANTHROPIC:
            try:
                from semantic_kernel.connectors.ai.anthropic import AnthropicChatCompletion
            except ImportError as e:
                raise ImportError(
                    "Anthropic chat completion requires the anthropic SDK. "
                    "SK normally installs it with semantic-kernel. "
                    "If missing, run: pip install anthropic"
                ) from e
            return AnthropicChatCompletion(
                service_id=config.service_id,
                ai_model_id=params.get("model"),
                api_key=params.get("api_key"),
            )

        if provider == LLMProvider.CUSTOM:
            return _load_custom_service(params, service_id=config.service_id)

        raise ValueError(f"Unsupported provider for chat completion: {provider}")

    # ------------------------------------------------------------------
    # Embeddings
    # ------------------------------------------------------------------

    @staticmethod
    def _create_embeddings(config: ServiceConfig) -> Any:
        provider = config.provider
        params = dict(config.config)

        if provider == LLMProvider.OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import OpenAITextEmbedding
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return OpenAITextEmbedding(
                service_id=config.service_id,
                ai_model_id=params.get("model"),
                api_key=params.get("api_key"),
                org_id=params.get("org_id"),
            )

        if provider == LLMProvider.AZURE_OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import AzureTextEmbedding
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return AzureTextEmbedding(
                service_id=config.service_id,
                deployment_name=params.get("model"),
                endpoint=params.get("azure_endpoint"),
                api_version=params.get("api_version"),
                api_key=params.get("api_key"),
                ad_token_provider=_resolve_azure_token_provider(params),
            )

        if provider == LLMProvider.CUSTOM:
            return _load_custom_service(params, service_id=config.service_id)

        raise ValueError(f"Unsupported provider for embeddings: {provider}")

    # ------------------------------------------------------------------
    # Text to image
    # ------------------------------------------------------------------

    @staticmethod
    def _create_text_to_image(config: ServiceConfig) -> Any:
        provider = config.provider
        params = dict(config.config)

        if provider == LLMProvider.OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import OpenAITextToImage
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return OpenAITextToImage(
                service_id=config.service_id,
                ai_model_id=params.get("model"),
                api_key=params.get("api_key"),
            )

        if provider == LLMProvider.AZURE_OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import AzureTextToImage
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return AzureTextToImage(
                service_id=config.service_id,
                deployment_name=params.get("model"),
                endpoint=params.get("azure_endpoint"),
                api_version=params.get("api_version"),
                api_key=params.get("api_key"),
                ad_token_provider=_resolve_azure_token_provider(params),
            )

        if provider == LLMProvider.CUSTOM:
            return _load_custom_service(params, service_id=config.service_id)

        raise ValueError(f"Unsupported provider for text_to_image: {provider}")

    # ------------------------------------------------------------------
    # Text to audio
    # ------------------------------------------------------------------

    @staticmethod
    def _create_text_to_audio(config: ServiceConfig) -> Any:
        provider = config.provider
        params = dict(config.config)

        if provider == LLMProvider.OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import OpenAITextToAudio
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return OpenAITextToAudio(
                service_id=config.service_id,
                ai_model_id=params.get("model"),
                api_key=params.get("api_key"),
            )

        if provider == LLMProvider.AZURE_OPENAI:
            try:
                from semantic_kernel.connectors.ai.open_ai import AzureTextToAudio
            except ImportError as e:
                raise ImportError(_sk_install_msg()) from e
            return AzureTextToAudio(
                service_id=config.service_id,
                deployment_name=params.get("model"),
                endpoint=params.get("azure_endpoint"),
                api_version=params.get("api_version"),
                api_key=params.get("api_key"),
                ad_token_provider=_resolve_azure_token_provider(params),
            )

        if provider == LLMProvider.CUSTOM:
            return _load_custom_service(params, service_id=config.service_id)

        raise ValueError(f"Unsupported provider for text_to_audio: {provider}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sk_install_msg() -> str:
    return (
        "semantic-kernel is required but not installed. "
        "Install it with: pip install agentflow[semantic-kernel]"
    )


def _resolve_azure_token_provider(params: dict) -> Any:
    """Build an Azure AD token provider if ``azure_identity: true`` is set."""
    if not params.get("azure_identity", False):
        return None

    try:
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
    except ImportError as e:
        raise ImportError(
            "azure_identity=true requires the azure-identity package (installed with agentflow base)."
        ) from e

    scope = params.get(
        "azure_oauth_scope",
        "https://cognitiveservices.azure.com/.default",
    )
    return get_bearer_token_provider(DefaultAzureCredential(), scope)


def _load_custom_service(params: dict, service_id: str) -> Any:
    """Load a custom service class by fully-qualified path.

    The config must contain a ``class_name`` field with a full import path
    (e.g. ``myproject.services.MyCustomChatService``). Any other keys are
    passed as constructor kwargs, with ``service_id`` injected automatically.
    """
    class_path = params.pop("class_name", None)
    if not class_path:
        raise ValueError(
            "provider=custom requires a 'class_name' field with a full import path "
            "(e.g., 'myproject.services.MyService')"
        )

    import importlib

    module_path, class_name = class_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    cls = getattr(module, class_name)
    return cls(service_id=service_id, **params)
