"""
Plugin registry — resolve YAML ``plugins:`` entries into SK ``KernelPlugin`` objects.

SK's "plugin" concept is a collection of callable functions exposed to the
LLM via automatic function calling — analogous to workflows' ``tools`` +
``mcp_tools`` sections combined. Do not confuse this with AgentFlow's
lifecycle ``Plugin`` ABC (which is an event observer); see the plugin bridge
(step 10) for that.

Four plugin types are supported (full breadth of SK):

1. **Python module** — import a module, wrap its ``@kernel_function``
   functions as a ``KernelPlugin``.
2. **Prompt** — a prompt template (``semantic function``) with ``{{$var}}``
   placeholders, wrapped as a single-function plugin.
3. **OpenAPI** — generate tools from an OpenAPI spec (URL or local path).
4. **Directory** — SK's native plugin directory format (folders with
   ``skprompt.txt`` + ``config.json``).
"""

from __future__ import annotations

import importlib
import inspect
from typing import Any, List, Optional

from .config_models import PluginRef, PluginType


def resolve_plugin(ref: PluginRef, kernel: Optional[Any] = None) -> Any:
    """Resolve a single ``PluginRef`` into an SK ``KernelPlugin`` instance.

    Args:
        ref: A validated ``PluginRef`` from YAML.
        kernel: Required for ``type: prompt`` so the prompt function can
            access kernel services. Optional for other types.

    Returns:
        A ``KernelPlugin`` instance, ready for ``kernel.add_plugin(plugin)``.

    Raises:
        ImportError: ``semantic-kernel`` not installed, or the user's
            Python module for a ``type: python`` plugin is missing.
        ValueError: Missing required fields for the plugin type.
    """
    if ref.type == PluginType.PYTHON:
        return _resolve_python_plugin(ref)
    if ref.type == PluginType.PROMPT:
        return _resolve_prompt_plugin(ref, kernel)
    if ref.type == PluginType.OPENAPI:
        return _resolve_openapi_plugin(ref)
    if ref.type == PluginType.DIRECTORY:
        return _resolve_directory_plugin(ref)
    raise ValueError(f"Unsupported plugin type: {ref.type}")


def resolve_plugins(refs: List[PluginRef], kernel: Optional[Any] = None) -> List[Any]:
    """Resolve a list of ``PluginRef`` into ``KernelPlugin`` instances."""
    return [resolve_plugin(ref, kernel) for ref in refs]


# ---------------------------------------------------------------------------
# Python module plugins
# ---------------------------------------------------------------------------


def _resolve_python_plugin(ref: PluginRef) -> Any:
    """Import a module and wrap its ``@kernel_function`` functions as a plugin.

    If ``ref.functions`` is provided, only those function names are included;
    otherwise every ``@kernel_function``-decorated callable in the module
    becomes part of the plugin.
    """
    if not ref.module:
        raise ValueError(
            f"Plugin '{ref.name}' (type: python) requires a 'module' field "
            f"with the Python module path."
        )

    try:
        from semantic_kernel.functions import KernelPlugin
    except ImportError as e:
        raise ImportError(_sk_install_msg()) from e

    module = importlib.import_module(ref.module)

    functions = _discover_kernel_functions(module, ref.functions)
    if not functions:
        raise ValueError(
            f"Plugin '{ref.name}' (module: {ref.module}): no @kernel_function-decorated "
            f"callables found" + (f" matching names {ref.functions}" if ref.functions else "")
        )

    return KernelPlugin(
        name=ref.name,
        description=ref.description,
        functions=functions,
    )


def _discover_kernel_functions(module: Any, names: Optional[List[str]]) -> List[Any]:
    """Find ``@kernel_function``-decorated callables in ``module``.

    If ``names`` is provided, only callables with matching names are returned
    (and missing names raise). Otherwise every public decorated callable is
    returned in alphabetical order.
    """
    if names:
        funcs = []
        for name in names:
            obj = getattr(module, name, None)
            if obj is None:
                raise ValueError(
                    f"Function '{name}' not found in module '{module.__name__}'"
                )
            if not _is_kernel_function(obj):
                raise ValueError(
                    f"Function '{name}' in module '{module.__name__}' is not "
                    f"decorated with @kernel_function"
                )
            funcs.append(obj)
        return funcs

    # Discover all @kernel_function-decorated callables
    return [
        obj
        for name, obj in inspect.getmembers(module, inspect.isfunction)
        if not name.startswith("_") and _is_kernel_function(obj)
    ]


def _is_kernel_function(obj: Any) -> bool:
    """Return True if ``obj`` is decorated with ``@kernel_function``.

    SK's decorator sets ``__kernel_function__ = True`` as a class attribute
    on the wrapped callable.
    """
    return getattr(obj, "__kernel_function__", False) is True


# ---------------------------------------------------------------------------
# Prompt plugins (semantic functions)
# ---------------------------------------------------------------------------


def _resolve_prompt_plugin(ref: PluginRef, kernel: Optional[Any]) -> Any:
    """Wrap a prompt template as a single-function plugin."""
    if not ref.template:
        raise ValueError(
            f"Plugin '{ref.name}' (type: prompt) requires a 'template' field "
            f"with the prompt template text."
        )

    try:
        from semantic_kernel.functions import KernelFunctionFromPrompt, KernelPlugin
    except ImportError as e:
        raise ImportError(_sk_install_msg()) from e

    # Create a prompt-based kernel function — the plugin wraps a single function
    # whose name matches the plugin's name for straightforward invocation.
    function = KernelFunctionFromPrompt(
        function_name=ref.name,
        plugin_name=ref.name,
        prompt=ref.template,
        description=ref.description,
    )

    return KernelPlugin(
        name=ref.name,
        description=ref.description,
        functions=[function],
    )


# ---------------------------------------------------------------------------
# OpenAPI plugins
# ---------------------------------------------------------------------------


def _resolve_openapi_plugin(ref: PluginRef) -> Any:
    """Generate a plugin from an OpenAPI spec (URL or local path)."""
    if not ref.spec_url and not ref.spec_path:
        raise ValueError(
            f"Plugin '{ref.name}' (type: openapi) requires either 'spec_url' "
            f"or 'spec_path'."
        )

    try:
        from semantic_kernel.functions import KernelPlugin
    except ImportError as e:
        raise ImportError(_sk_install_msg()) from e

    # SK's from_openapi supports both URL and file path (first positional arg
    # is the spec location in most recent versions)
    kwargs: dict = {"plugin_name": ref.name}
    if ref.spec_url:
        kwargs["openapi_document_path"] = ref.spec_url
    else:
        kwargs["openapi_document_path"] = ref.spec_path

    return KernelPlugin.from_openapi(**kwargs)


# ---------------------------------------------------------------------------
# Directory plugins
# ---------------------------------------------------------------------------


def _resolve_directory_plugin(ref: PluginRef) -> Any:
    """Load an SK plugin directory (skprompt.txt + config.json format)."""
    if not ref.path:
        raise ValueError(
            f"Plugin '{ref.name}' (type: directory) requires a 'path' field."
        )

    try:
        from semantic_kernel.functions import KernelPlugin
    except ImportError as e:
        raise ImportError(_sk_install_msg()) from e

    return KernelPlugin.from_directory(
        parent_directory=ref.path,
        plugin_name=ref.name,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sk_install_msg() -> str:
    return (
        "semantic-kernel is required but not installed. "
        "Install it with: pip install agentflow[semantic-kernel]"
    )
