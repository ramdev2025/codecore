"""
Bridge AgentFlow lifecycle plugins to SK kernel filters.

AgentFlow's ``Plugin`` ABC (``agentflow.workflows.plugins``) is a set of
observer hooks — ``on_tool_call``, ``on_agent_start``, ``on_workflow_end``,
etc. SK's filter system uses middleware-style ``async def(context, next)``
functions. This module bridges the two so existing telemetry/logging/cost
plugins work on SK agents without modification.

The bridge receives a ``plugin_manager`` (duck-typed — any object with
``emit_tool_call``/``emit_tool_result``/``emit_error`` methods) and a
``context`` (a ``WorkflowContext``-like object carrying execution metadata).
It registers SK filters that translate kernel events into plugin events.

Events emitted from filter registrations:

- ``on_tool_call`` / ``on_tool_result`` — from ``FUNCTION_INVOCATION``
  and ``AUTO_FUNCTION_INVOCATION``.
- ``on_error`` — from exceptions inside either filter.

Workflow-level events (``on_workflow_start/end``, ``on_agent_start/end``)
are emitted by the SK CLI runner around the top-level ``.invoke()``
call, not by filters. Events that don't apply to SK (``on_hitl_*``,
``on_external_agent_*``, ``on_mcp_connect``) simply never fire.
"""

from __future__ import annotations

from typing import Any, Optional


def register_plugin_bridge(
        kernel: Any,
        plugin_manager: Any,
        context: Any,
) -> None:
    """Register bridge filters on the kernel.

    Args:
        kernel: An SK ``Kernel`` instance.
        plugin_manager: An object with ``emit_tool_call``, ``emit_tool_result``,
            and ``emit_error`` methods (duck-typed to avoid importing workflows).
        context: A ``WorkflowContext``-like object passed to each emit call.
    """
    if plugin_manager is None:
        return

    try:
        from semantic_kernel.filters import FilterTypes
    except ImportError as e:
        raise ImportError(
            "semantic-kernel is required but not installed. "
            "Install it with: pip install agentflow[semantic-kernel]"
        ) from e

    kernel.add_filter(
        FilterTypes.FUNCTION_INVOCATION,
        _make_function_invocation_bridge(plugin_manager, context),
    )
    kernel.add_filter(
        FilterTypes.AUTO_FUNCTION_INVOCATION,
        _make_auto_function_invocation_bridge(plugin_manager, context),
    )


def _make_function_invocation_bridge(plugin_manager: Any, context: Any):
    """Bridge for FUNCTION_INVOCATION — fires for every kernel function call."""

    async def bridge(ctx, next):
        fn_name = _get_function_name(ctx)
        args = _extract_arguments(ctx)
        _safe_emit(plugin_manager, "emit_tool_call", context, fn_name, args)
        try:
            await next(ctx)
            result = _extract_result(ctx)
            _safe_emit(plugin_manager, "emit_tool_result", context, fn_name, result)
        except Exception as e:
            _safe_emit(
                plugin_manager,
                "emit_error",
                context,
                e,
                {"function": fn_name, "args": args},
            )
            raise

    return bridge


def _make_auto_function_invocation_bridge(plugin_manager: Any, context: Any):
    """Bridge for AUTO_FUNCTION_INVOCATION — fires for LLM-initiated tool calls."""

    async def bridge(ctx, next):
        fn_name = _get_function_name(ctx)
        args = _extract_arguments(ctx)
        _safe_emit(plugin_manager, "emit_tool_call", context, fn_name, args)
        try:
            await next(ctx)
            result = _extract_result(ctx)
            _safe_emit(plugin_manager, "emit_tool_result", context, fn_name, result)
        except Exception as e:
            _safe_emit(
                plugin_manager,
                "emit_error",
                context,
                e,
                {"function": fn_name, "args": args},
            )
            raise

    return bridge


# ---------------------------------------------------------------------------
# Helpers — safe emitters and context extraction
# ---------------------------------------------------------------------------


def _safe_emit(plugin_manager: Any, method_name: str, *args: Any) -> None:
    """Call ``plugin_manager.<method_name>(*args)`` if it exists; swallow errors."""
    import logging
    method = getattr(plugin_manager, method_name, None)
    if method is None:
        return
    try:
        method(*args)
    except Exception as e:
        logging.getLogger(__name__).debug(
            "Plugin bridge: %s raised %s (ignored)", method_name, e
        )


def _get_function_name(ctx: Any) -> str:
    fn = getattr(ctx, "function", None)
    if fn is not None:
        name = getattr(fn, "name", None)
        if name:
            return str(name)
    return "<unknown>"


def _extract_arguments(ctx: Any) -> dict:
    args = getattr(ctx, "arguments", None)
    if args is None:
        return {}
    # KernelArguments is dict-like
    try:
        return dict(args)
    except Exception:
        return {}


def _extract_result(ctx: Any) -> Any:
    result = getattr(ctx, "result", None)
    if result is None:
        # Auto-function contexts use function_result
        result = getattr(ctx, "function_result", None)
    return result


# ---------------------------------------------------------------------------
# Convenience: emit workflow/agent lifecycle around a runner call
# ---------------------------------------------------------------------------


class WorkflowLifecycleEmitter:
    """Context manager that emits workflow_start/end around a run.

    Usage::

        with WorkflowLifecycleEmitter(plugin_manager, context, agent_name="assistant"):
            result = await agent.invoke(...)
    """

    def __init__(
            self,
            plugin_manager: Any,
            context: Any,
            agent_name: Optional[str] = None,
            initial_state: Optional[dict] = None,
    ):
        self.plugin_manager = plugin_manager
        self.context = context
        self.agent_name = agent_name
        self.initial_state = initial_state or {}
        self._error: Optional[Exception] = None

    def __enter__(self):
        _safe_emit(
            self.plugin_manager,
            "emit_workflow_start",
            self.context,
            self.initial_state,
        )
        if self.agent_name:
            _safe_emit(
                self.plugin_manager,
                "emit_agent_start",
                self.context,
                self.agent_name,
                self.initial_state,
            )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.agent_name:
            _safe_emit(
                self.plugin_manager,
                "emit_agent_end",
                self.context,
                self.agent_name,
                {},
            )
        status = "error" if exc_val is not None else "completed"
        _safe_emit(
            self.plugin_manager,
            "emit_workflow_end",
            self.context,
            {},
            status,
        )
        if exc_val is not None:
            _safe_emit(
                self.plugin_manager,
                "emit_error",
                self.context,
                exc_val,
                {},
            )
        return False  # don't suppress exceptions
