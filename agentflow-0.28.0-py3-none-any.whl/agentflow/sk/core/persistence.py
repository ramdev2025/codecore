"""
Persistence for SK conversations (``ChatHistory``).

Unlike LangGraph's checkpointer (which snapshots a full graph state), SK
state is just a list of chat messages plus optional thread metadata. We
serialize ``ChatHistory`` to JSON and store it keyed by ``thread_id``.

Backends:

- ``memory`` — in-process dict (session-scoped)
- ``sqlite`` — local file, default ``.agentflow/sk_checkpoints.db``
- ``postgres`` — connection string from config or
  ``POSTGRES_CONNECTION_STRING`` env var

Optional AES encryption protects persisted message content. The encryption
key can be passed explicitly or pulled from ``AGENTFLOW_ENCRYPTION_KEY``.
"""

from __future__ import annotations

import logging
import os
import sqlite3
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

# Shared env-var conventions with workflows/deep persistence
ENV_POSTGRES_CONNECTION_STRING = "POSTGRES_CONNECTION_STRING"
ENV_CHECKPOINTER_DB_PATH = "CHECKPOINTER_DB_PATH"
ENV_ENCRYPTION_KEY = "AGENTFLOW_ENCRYPTION_KEY"

DEFAULT_SQLITE_PATH = ".agentflow/sk_checkpoints.db"


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------


def create_persistence_manager(
        backend: str = "sqlite",
        db_path: Optional[str] = None,
        connection_string: Optional[str] = None,
        encryption_key: Optional[str] = None,
) -> "SKPersistenceManager":
    """Create a persistence manager for one of the supported backends.

    Args:
        backend: One of ``"memory"``, ``"sqlite"``, ``"postgres"``.
        db_path: SQLite database path. Falls back to ``CHECKPOINTER_DB_PATH``
            env var, then to ``.agentflow/sk_checkpoints.db``.
        connection_string: PostgreSQL connection string. Falls back to
            ``POSTGRES_CONNECTION_STRING`` env var.
        encryption_key: AES encryption key (16/24/32 bytes). Falls back to
            ``AGENTFLOW_ENCRYPTION_KEY``. If unset, data is stored in clear.

    Returns:
        An ``SKPersistenceManager`` ready to use.
    """
    backend = (backend or "sqlite").lower()
    key = encryption_key or os.environ.get(ENV_ENCRYPTION_KEY)

    if backend == "memory":
        return InMemoryPersistence(encryption_key=key)

    if backend == "sqlite":
        path = db_path or os.environ.get(ENV_CHECKPOINTER_DB_PATH, DEFAULT_SQLITE_PATH)
        return SQLitePersistence(db_path=path, encryption_key=key)

    if backend == "postgres":
        conn = connection_string or os.environ.get(ENV_POSTGRES_CONNECTION_STRING)
        if not conn:
            raise ValueError(
                f"Postgres backend requires 'connection_string' argument or "
                f"{ENV_POSTGRES_CONNECTION_STRING} env var."
            )
        return PostgresPersistence(connection_string=conn, encryption_key=key)

    raise ValueError(f"Unknown persistence backend: {backend!r}")


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------


class SKPersistenceManager(ABC):
    """Save/load/list/delete ChatHistory by thread_id."""

    def __init__(self, encryption_key: Optional[str] = None):
        self._encryption_key = encryption_key

    @abstractmethod
    def save(self, thread_id: str, chat_history: Any) -> None:
        """Persist ``chat_history`` keyed by ``thread_id``."""

    @abstractmethod
    def load(self, thread_id: str) -> Optional[Any]:
        """Load a ``ChatHistory`` by ``thread_id``, or ``None`` if unknown."""

    @abstractmethod
    def list_threads(self) -> List[str]:
        """Return all known thread IDs."""

    @abstractmethod
    def delete(self, thread_id: str) -> None:
        """Delete a thread's stored history."""

    def load_as_thread(self, thread_id: str) -> Optional[Any]:
        """Load history and return a ``ChatHistoryAgentThread`` ready to resume.

        Returns ``None`` if ``thread_id`` is unknown. Users can create a fresh
        ``ChatHistoryAgentThread(thread_id=thread_id)`` on their own if they
        want an empty thread.
        """
        history = self.load(thread_id)
        if history is None:
            return None
        try:
            from semantic_kernel.agents import ChatHistoryAgentThread
        except ImportError as e:
            raise ImportError(
                "semantic-kernel is required but not installed. "
                "Install it with: pip install agentflow[semantic-kernel]"
            ) from e
        return ChatHistoryAgentThread(chat_history=history, thread_id=thread_id)

    # ------------------------------------------------------------------
    # Serialization + encryption (shared across backends)
    # ------------------------------------------------------------------

    def _serialize(self, chat_history: Any) -> str:
        """Turn a ``ChatHistory`` into a storable string (optionally encrypted)."""
        payload = chat_history.serialize()
        if self._encryption_key:
            payload = _encrypt_aes(payload, self._encryption_key)
        return payload

    def _deserialize(self, payload: str) -> Any:
        """Restore a ``ChatHistory`` from a stored string."""
        try:
            from semantic_kernel.contents import ChatHistory
        except ImportError as e:
            raise ImportError(
                "semantic-kernel is required but not installed. "
                "Install it with: pip install agentflow[semantic-kernel]"
            ) from e

        if self._encryption_key:
            payload = _decrypt_aes(payload, self._encryption_key)
        return ChatHistory.model_validate_json(payload)


# ---------------------------------------------------------------------------
# In-memory (session-scoped)
# ---------------------------------------------------------------------------


class InMemoryPersistence(SKPersistenceManager):
    """Dict-backed persistence — lost on restart, good for tests."""

    def __init__(self, encryption_key: Optional[str] = None):
        super().__init__(encryption_key=encryption_key)
        self._store: dict[str, str] = {}

    def save(self, thread_id: str, chat_history: Any) -> None:
        self._store[thread_id] = self._serialize(chat_history)

    def load(self, thread_id: str) -> Optional[Any]:
        payload = self._store.get(thread_id)
        return self._deserialize(payload) if payload is not None else None

    def list_threads(self) -> List[str]:
        return list(self._store.keys())

    def delete(self, thread_id: str) -> None:
        self._store.pop(thread_id, None)


# ---------------------------------------------------------------------------
# SQLite
# ---------------------------------------------------------------------------


class SQLitePersistence(SKPersistenceManager):
    """SQLite-backed persistence — single file, good for local / dev."""

    def __init__(self, db_path: str, encryption_key: Optional[str] = None):
        super().__init__(encryption_key=encryption_key)
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sk_threads (
                    thread_id TEXT PRIMARY KEY,
                    messages TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

    def save(self, thread_id: str, chat_history: Any) -> None:
        payload = self._serialize(chat_history)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO sk_threads (thread_id, messages) VALUES (?, ?)
                ON CONFLICT(thread_id) DO UPDATE SET
                    messages = excluded.messages,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (thread_id, payload),
            )

    def load(self, thread_id: str) -> Optional[Any]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT messages FROM sk_threads WHERE thread_id = ?",
                (thread_id,),
            ).fetchone()
        return self._deserialize(row[0]) if row else None

    def list_threads(self) -> List[str]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT thread_id FROM sk_threads ORDER BY updated_at DESC"
            ).fetchall()
        return [r[0] for r in rows]

    def delete(self, thread_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM sk_threads WHERE thread_id = ?", (thread_id,))


# ---------------------------------------------------------------------------
# Postgres
# ---------------------------------------------------------------------------


class PostgresPersistence(SKPersistenceManager):
    """PostgreSQL-backed persistence — production durable backend."""

    def __init__(self, connection_string: str, encryption_key: Optional[str] = None):
        super().__init__(encryption_key=encryption_key)
        self.connection_string = connection_string
        self._psycopg = self._load_psycopg()
        self._ensure_schema()

    @staticmethod
    def _load_psycopg() -> Any:
        try:
            import psycopg
        except ImportError as e:
            raise ImportError(
                "Postgres backend requires the 'psycopg' package. "
                "Install with: pip install agentflow[postgres]"
            ) from e
        return psycopg

    def _connect(self) -> Any:
        return self._psycopg.connect(self.connection_string)

    def _ensure_schema(self) -> None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS sk_threads (
                    thread_id TEXT PRIMARY KEY,
                    messages TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
                """
            )
            conn.commit()

    def save(self, thread_id: str, chat_history: Any) -> None:
        payload = self._serialize(chat_history)
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO sk_threads (thread_id, messages) VALUES (%s, %s)
                ON CONFLICT (thread_id) DO UPDATE SET
                    messages = EXCLUDED.messages,
                    updated_at = NOW()
                """,
                (thread_id, payload),
            )
            conn.commit()

    def load(self, thread_id: str) -> Optional[Any]:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT messages FROM sk_threads WHERE thread_id = %s",
                (thread_id,),
            )
            row = cur.fetchone()
        return self._deserialize(row[0]) if row else None

    def list_threads(self) -> List[str]:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT thread_id FROM sk_threads ORDER BY updated_at DESC")
            rows = cur.fetchall()
        return [r[0] for r in rows]

    def delete(self, thread_id: str) -> None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute("DELETE FROM sk_threads WHERE thread_id = %s", (thread_id,))
            conn.commit()


# ---------------------------------------------------------------------------
# AES encryption helpers
# ---------------------------------------------------------------------------


def _encrypt_aes(plaintext: str, key: str) -> str:
    """Encrypt ``plaintext`` with AES-GCM using ``key`` (16/24/32 bytes).

    Returns a base64-encoded string containing nonce + ciphertext + tag.
    """
    import base64

    try:
        from Crypto.Cipher import AES
        from Crypto.Random import get_random_bytes
    except ImportError as e:
        raise ImportError(
            "Encryption requires pycryptodome. "
            "Install with: pip install pycryptodome"
        ) from e

    key_bytes = key.encode("utf-8")
    _validate_aes_key_length(key_bytes)

    nonce = get_random_bytes(12)
    cipher = AES.new(key_bytes, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))

    blob = nonce + tag + ciphertext
    return base64.b64encode(blob).decode("ascii")


def _decrypt_aes(ciphertext_b64: str, key: str) -> str:
    """Inverse of ``_encrypt_aes``."""
    import base64

    try:
        from Crypto.Cipher import AES
    except ImportError as e:
        raise ImportError(
            "Encryption requires pycryptodome. "
            "Install with: pip install pycryptodome"
        ) from e

    key_bytes = key.encode("utf-8")
    _validate_aes_key_length(key_bytes)

    blob = base64.b64decode(ciphertext_b64.encode("ascii"))
    nonce, tag, ciphertext = blob[:12], blob[12:28], blob[28:]

    cipher = AES.new(key_bytes, AES.MODE_GCM, nonce=nonce)
    plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    return plaintext.decode("utf-8")


def _validate_aes_key_length(key_bytes: bytes) -> None:
    if len(key_bytes) not in (16, 24, 32):
        raise ValueError(
            f"AES encryption key must be 16, 24, or 32 bytes; got {len(key_bytes)}."
        )
