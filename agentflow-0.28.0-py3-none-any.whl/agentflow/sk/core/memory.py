"""
Memory connector factory for SK vector stores.

SK supports multiple vector stores (Azure AI Search, Qdrant, Chroma, Redis,
etc.) via its connector packages. Each connector requires its own backend
library as an optional dependency — we import lazily and surface a clear
install hint if the backend isn't available.

**Scope:** this factory creates and returns the raw store instance plus a
reference to the wired embedding service. Building full RAG plugins on top
of the store is user territory — the store is exposed via
``SKAgentBuilder.memory`` so user code can register custom
``@kernel_function`` plugins that use it for search/upsert.

This is the pragmatic middle ground: agentflow standardizes the *creation*
and *wiring* of the store (including env-var expansion and embedding
service resolution), but leaves application-specific RAG logic to the
user.
"""

from typing import Any, Dict, List, Optional

from .config_models import MemoryConfig, MemoryConnectorType, ServiceConfig


def create_memory_store(
        config: MemoryConfig,
        services: Optional[List[ServiceConfig]] = None,
) -> Any:
    """Create an SK vector store from a ``MemoryConfig`` entry.

    Args:
        config: Validated memory config from YAML.
        services: The Kernel's service list (for validating
            ``embedding_service_id`` references).

    Returns:
        A store instance (connector-specific type) — the caller is
        responsible for wiring it into plugins or agents.

    Raises:
        ImportError: The connector's backend library isn't installed.
        ValueError: ``embedding_service_id`` references an unknown service,
            or required config fields are missing.
    """
    _validate_embedding_service(config, services)

    if config.connector == MemoryConnectorType.AZURE_AI_SEARCH:
        return _create_azure_ai_search(config.config)
    if config.connector == MemoryConnectorType.QDRANT:
        return _create_qdrant(config.config)
    if config.connector == MemoryConnectorType.CHROMA:
        return _create_chroma(config.config)
    if config.connector == MemoryConnectorType.REDIS:
        return _create_redis(config.config)
    if config.connector == MemoryConnectorType.CUSTOM:
        return _create_custom(config.config)

    raise ValueError(f"Unsupported memory connector: {config.connector}")


def _validate_embedding_service(
        config: MemoryConfig,
        services: Optional[List[ServiceConfig]],
) -> None:
    """Verify that ``embedding_service_id`` references an existing service."""
    if not config.embedding_service_id:
        return
    if not services:
        raise ValueError(
            f"Memory connector references embedding_service_id "
            f"'{config.embedding_service_id}' but no 'services:' list is defined. "
            f"Add the embedding service to the 'services:' section."
        )
    ids = {s.service_id for s in services}
    if config.embedding_service_id not in ids:
        raise ValueError(
            f"Memory connector references unknown embedding_service_id "
            f"'{config.embedding_service_id}'. Available service IDs: {sorted(ids)}"
        )


# ---------------------------------------------------------------------------
# Connector factories
# ---------------------------------------------------------------------------


def _create_azure_ai_search(params: Dict[str, Any]) -> Any:
    try:
        from semantic_kernel.connectors.azure_ai_search import AzureAISearchStore
    except ImportError as e:
        raise ImportError(
            "Azure AI Search memory requires the azure-search-documents package. "
            "Install with: pip install azure-search-documents"
        ) from e
    return AzureAISearchStore(
        search_endpoint=params.get("endpoint"),
        api_key=params.get("api_key"),
    )


def _create_qdrant(params: Dict[str, Any]) -> Any:
    try:
        from semantic_kernel.connectors.qdrant import QdrantStore
    except ImportError as e:
        raise ImportError(
            "Qdrant memory requires the qdrant-client package. "
            "Install with: pip install qdrant-client"
        ) from e
    return QdrantStore(
        url=params.get("url"),
        api_key=params.get("api_key"),
        host=params.get("host"),
        port=params.get("port"),
    )


def _create_chroma(params: Dict[str, Any]) -> Any:
    try:
        from semantic_kernel.connectors.chroma import ChromaStore
    except ImportError as e:
        raise ImportError(
            "Chroma memory requires the chromadb package. "
            "Install with: pip install chromadb"
        ) from e
    return ChromaStore(
        persist_directory=params.get("persist_directory"),
    )


def _create_redis(params: Dict[str, Any]) -> Any:
    try:
        from semantic_kernel.connectors.redis import RedisStore
    except ImportError as e:
        raise ImportError(
            "Redis memory requires the redis package. "
            "Install with: pip install redis"
        ) from e
    return RedisStore(
        connection_string=params.get("connection_string"),
    )


def _create_custom(params: Dict[str, Any]) -> Any:
    """Load a user-provided memory store class by fully-qualified path."""
    class_path = params.get("class_name")
    if not class_path:
        raise ValueError(
            "connector=custom requires a 'class_name' field with a full import path "
            "(e.g., 'myproject.memory.MyVectorStore')"
        )

    import importlib

    module_path, class_name = class_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    cls = getattr(module, class_name)

    kwargs = {k: v for k, v in params.items() if k != "class_name"}
    return cls(**kwargs)
