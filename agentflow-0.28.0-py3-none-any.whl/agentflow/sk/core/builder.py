"""
SK agent builder — compiles a validated ``SKYAMLConfig`` into a runnable SK
agent, orchestration, or process.

The builder is the single bridge between YAML config and Semantic Kernel's
runtime objects. Dispatch logic:

- ``agent:`` alone         → autonomous ``ChatCompletionAgent``
- ``agent:`` + ``process:`` → ``KernelProcess`` via ``ProcessBuilder``
- ``agents:`` + ``mode:``  → orchestration (handoff/sequential/group_chat/magentic),
                             optionally with process-backed agents via
                             ``processes:`` (plural)

The returned object is ready for execution: the caller invokes ``.invoke(...)``
on a ``ChatCompletionAgent``, or ``.invoke(...)`` on an orchestration runtime,
etc.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .config_models import (
    AgentMode,
    AgentSpec,
    AgentType,
    ExecutionSettings,
    ProcessConfig,
    SKYAMLConfig,
)


class SKAgentBuilder:
    """Builds Semantic Kernel agents/orchestrations/processes from YAML config.

    Users normally invoke the builder through the unified factory
    (``agentflow.create("sk_agent.yaml")``) or the CLI. Direct use:

        builder = SKAgentBuilder.from_yaml("agent.yaml")
        runner = builder.build()
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(
            self,
            config: SKYAMLConfig,
            checkpointer: Optional[Any] = None,
            build_state: Optional[Dict[str, Any]] = None,
    ):
        self.config = config
        self.checkpointer = checkpointer
        # Build-time state for ``available_when`` predicate evaluation.
        # Tools whose predicate is falsy against this state are excluded
        # from the agent's kernel. ``None`` is treated as an empty dict;
        # any ``state.X``-style predicate then resolves falsy, hiding
        # all gated tools.
        self.build_state: Dict[str, Any] = build_state or {}

        # Populated by build() for user access (e.g. custom RAG plugins)
        self.memory: Optional[Any] = None
        self._shared_kernel: Optional[Any] = None
        self._mcp_plugins: List[Any] = []

    @classmethod
    def from_yaml(
            cls,
            path: Union[str, Path],
            checkpointer: Optional[Any] = None,
            build_state: Optional[Dict[str, Any]] = None,
    ) -> "SKAgentBuilder":
        """Load config from YAML, validate, and create builder."""
        from .helpers import load_sk_config

        raw = load_sk_config(path)
        config = SKYAMLConfig.model_validate(raw)
        return cls(config, checkpointer=checkpointer, build_state=build_state)

    # ------------------------------------------------------------------
    # Build — the main dispatch
    # ------------------------------------------------------------------

    def build(self) -> Any:
        """Build and return the configured SK agent/orchestration/process."""
        _ensure_sk_installed()

        # 1. Construct the shared Kernel (services, shared plugins, filters, memory, MCP)
        kernel = self._build_shared_kernel()
        self._shared_kernel = kernel

        # 2. Dispatch on structure
        if self.config.agents:
            return self._build_orchestration(kernel)
        if self.config.mode == AgentMode.PROCESS:
            return self._build_process(kernel)
        return self._build_autonomous_agent(kernel)

    # ------------------------------------------------------------------
    # Kernel construction (shared across all modes)
    # ------------------------------------------------------------------

    def _build_kernel(self) -> Any:
        """Create a fresh SK Kernel instance."""
        from semantic_kernel import Kernel
        return Kernel()

    def _build_shared_kernel(self) -> Any:
        """Construct the kernel + shared services, plugins, filters, memory, MCP."""
        kernel = self._build_kernel()

        # ---- AI services ---------------------------------------------------
        from .service_factory import ServiceFactory

        if self.config.services:
            for svc_cfg in self.config.services:
                kernel.add_service(ServiceFactory.create_service(svc_cfg))
        elif self.config.llm:
            # Top-level llm: shorthand → one chat service with service_id="default"
            kernel.add_service(ServiceFactory.create_service_from_llm(self.config.llm))

        # ---- Shared plugins ------------------------------------------------
        if self.config.plugins:
            from .plugin_registry import resolve_plugins
            for plugin in resolve_plugins(self.config.plugins, kernel=kernel):
                kernel.add_plugin(plugin)

        # ---- MCP server plugins -------------------------------------------
        if self.config.mcp_servers:
            from .mcp import resolve_mcp_plugins
            self._mcp_plugins = resolve_mcp_plugins(self.config.mcp_servers)
            for mcp_plugin in self._mcp_plugins:
                kernel.add_plugin(mcp_plugin)

        # ---- Filters: guards, optimizers, observers ----------------------
        self._register_shared_filters(kernel)

        # ---- Memory store (exposed on builder, not added to kernel) -----
        if self.config.memory:
            from .memory import create_memory_store
            self.memory = create_memory_store(self.config.memory, self.config.services)

        return kernel

    def _register_shared_filters(self, kernel: Any) -> None:
        """Register top-level guards/optimizers/observers + user filters."""
        from ..filters import compile_guards, compile_observers, compile_optimizers

        for compiled in compile_guards(self.config.guards):
            kernel.add_filter(compiled.filter_type, compiled.filter_fn)
        for compiled in compile_optimizers(self.config.optimizers):
            kernel.add_filter(compiled.filter_type, compiled.filter_fn)
        for compiled in compile_observers(self.config.observers):
            kernel.add_filter(compiled.filter_type, compiled.filter_fn)

        # User-provided SK-native filters
        if self.config.filters:
            self._register_raw_filters(kernel, self.config.filters)

    @staticmethod
    def _register_raw_filters(kernel: Any, filter_refs: List[Any]) -> None:
        """Register user-provided ``filters:`` entries on the kernel."""
        import importlib

        from semantic_kernel.filters import FilterTypes

        for ref in filter_refs:
            module = importlib.import_module(ref.module)
            fn = getattr(module, ref.function, None)
            if fn is None:
                raise ValueError(
                    f"Filter '{ref.function}' not found in module '{ref.module}'"
                )
            sk_type = getattr(FilterTypes, ref.type.name)
            kernel.add_filter(sk_type, fn)

    # ------------------------------------------------------------------
    # Autonomous mode
    # ------------------------------------------------------------------

    def _build_autonomous_agent(self, kernel: Any) -> Any:
        """Build a single ChatCompletionAgent (or other agent type) from ``agent:``."""
        spec = self.config.agent
        if spec is None:
            raise ValueError("autonomous mode requires 'agent:' (singular) in YAML")

        # For autonomous mode, the shared kernel IS the agent's kernel.
        # Per-agent overrides (llm, plugins, filters) still layer on top.
        agent_kernel = self._build_agent_kernel(spec, base_kernel=kernel)
        return self._create_agent(spec, agent_kernel)

    # ------------------------------------------------------------------
    # Orchestration modes
    # ------------------------------------------------------------------

    def _build_orchestration(self, kernel: Any) -> Any:
        """Build an agent-list orchestration (handoff/sequential/group_chat/magentic)."""
        built_agents: List[Any] = []
        for spec in self.config.agents or []:
            agent_kernel = self._build_agent_kernel(spec, base_kernel=kernel)
            process_cfg = self._find_process_for_agent(spec.name)
            if process_cfg is not None:
                agent = self._build_process_for_agent(spec, agent_kernel, process_cfg)
            else:
                agent = self._create_agent(spec, agent_kernel)
            built_agents.append(agent)

        mode = self.config.mode
        return self._wire_orchestration(mode, built_agents)

    @staticmethod
    def _wire_orchestration(mode: AgentMode, agents: List[Any]) -> Any:
        """Create the appropriate SK orchestration instance."""
        if mode == AgentMode.SEQUENTIAL:
            from semantic_kernel.agents.orchestration.sequential import SequentialOrchestration
            return SequentialOrchestration(members=agents)

        if mode == AgentMode.HANDOFF:
            from semantic_kernel.agents.orchestration.handoffs import (
                HandoffOrchestration,
                OrchestrationHandoffs,
            )
            # Default handoff graph: first agent can delegate to any other
            handoffs = OrchestrationHandoffs()
            if len(agents) > 1:
                router = agents[0]
                specialist_map = {
                    a.name: f"Delegate to {a.name}"
                    for a in agents[1:]
                    if getattr(a, "name", None)
                }
                handoffs.add_many(source_agent=router.name, target_agents=specialist_map)
            return HandoffOrchestration(members=agents, handoffs=handoffs)

        if mode == AgentMode.GROUP_CHAT:
            from semantic_kernel.agents.orchestration.group_chat import (
                GroupChatOrchestration,
                RoundRobinGroupChatManager,
            )
            # Default to RoundRobin; users can subclass GroupChatManager for custom
            # turn-taking/termination logic and pass it via a future YAML extension.
            return GroupChatOrchestration(
                members=agents,
                manager=RoundRobinGroupChatManager(),
            )

        if mode == AgentMode.MAGENTIC:
            from semantic_kernel.agents.orchestration.magentic import MagenticOrchestration
            return MagenticOrchestration(members=agents)

        raise ValueError(f"Invalid orchestration mode: {mode}")

    def _find_process_for_agent(self, agent_name: str) -> Optional[ProcessConfig]:
        """Return the ProcessConfig linked to the given agent (via processes: map)."""
        if not self.config.processes:
            return None
        for proc in self.config.processes.values():
            if proc.agent == agent_name:
                return proc
        return None

    def _build_process_for_agent(
            self,
            spec: AgentSpec,
            agent_kernel: Any,
            process_cfg: ProcessConfig,
    ) -> Any:
        """Build a process that backs a specific agent in an orchestration.

        SK's orchestration API expects ``Agent`` instances as members, but a
        process-backed agent doesn't fit that shape directly. For now, we
        construct the process and attach it to a placeholder ChatCompletionAgent
        whose instructions tell SK to delegate to the process. Full support
        for process-backed orchestration members is a follow-up when SK
        exposes a native pattern; for now, this surfaces a clear error.
        """
        # This path requires additional SK coordination that doesn't cleanly
        # exist yet. Surface a helpful error rather than silently falling
        # back to autonomous behavior.
        raise NotImplementedError(
            f"Agent '{spec.name}' is backed by a process via 'processes:'. "
            f"Process-backed orchestration members are not yet fully supported "
            f"by SK's orchestration API. Either: (a) make the agent autonomous "
            f"by removing the processes: entry, or (b) run the process as a "
            f"standalone workflow (mode: process, agent: singular)."
        )

    # ------------------------------------------------------------------
    # Process mode
    # ------------------------------------------------------------------

    def _build_process(self, kernel: Any) -> Any:
        """Build a KernelProcess from the ``process:`` section."""
        try:
            from semantic_kernel.processes import ProcessBuilder
        except ImportError as e:
            raise ImportError(
                "Process mode requires semantic-kernel's processes API. "
                "Install with: pip install agentflow[semantic-kernel]"
            ) from e

        if self.config.process is None:
            raise ValueError("mode=process requires a 'process:' definition in YAML")

        builder = ProcessBuilder(
            name=self.config.metadata.name or self.config.agent.name if self.config.agent else "process"
        )

        # Import and add steps
        steps: Dict[str, Any] = {}
        for step_ref in self.config.process.steps:
            step_cls = _import_class(step_ref.module, step_ref.class_name)
            steps[step_ref.name] = builder.add_step(step_cls)

        # Wire events between steps
        for event in self.config.process.events:
            if event.from_step not in steps:
                raise ValueError(
                    f"Process event references unknown 'from_step': {event.from_step}"
                )
            if event.to_step not in steps:
                raise ValueError(
                    f"Process event references unknown 'to_step': {event.to_step}"
                )
            link = steps[event.from_step].on_event(event.event)
            if event.function:
                link.send_event_to(steps[event.to_step], function_name=event.function)
            else:
                link.send_event_to(steps[event.to_step])

        return builder.build()

    # ------------------------------------------------------------------
    # Per-agent kernel + overrides
    # ------------------------------------------------------------------

    def _build_agent_kernel(self, spec: AgentSpec, base_kernel: Any) -> Any:
        """Create a per-agent kernel layered on top of the shared kernel.

        The per-agent kernel:
        - Inherits services from the shared kernel (or uses agent's ``llm:`` override)
        - Adds agent-specific plugins
        - Adds agent-specific filters (guards/optimizers/observers)

        For a single-agent (autonomous) config, we reuse the shared kernel
        directly since there's nothing to distinguish.
        """
        has_override = any([
            spec.llm is not None,
            spec.plugins,
            spec.guards,
            spec.optimizers,
            spec.observers,
            # ``ui_tools`` needs the per-agent-kernel path too; otherwise
            # the LLM is bound to the base kernel which doesn't carry the
            # generative-UI ``KernelFunction``s and never calls them.
            spec.ui_tools is not None,
        ])
        if not has_override:
            return base_kernel

        # Create a fresh kernel for this agent
        from semantic_kernel import Kernel
        from .service_factory import ServiceFactory

        kernel = Kernel()

        # Services: agent's llm override (if present) OR inherit from base
        if spec.llm is not None:
            kernel.add_service(ServiceFactory.create_service_from_llm(spec.llm))
        else:
            # Copy services from base kernel
            for service in base_kernel.services.values():
                kernel.add_service(service)

        # Always copy shared plugins from base
        for plugin in base_kernel.plugins.values():
            kernel.add_plugin(plugin)

        # Agent-specific plugins
        if spec.plugins:
            from .plugin_registry import resolve_plugins
            for plugin in resolve_plugins(spec.plugins, kernel=kernel):
                kernel.add_plugin(plugin)

        # Generative-UI components. Each fetcher in ``spec.ui_tools.module``
        # decorated with ``@agentflow.genui.ui_component`` becomes a
        # KernelFunction. The availability filter narrows the list
        # before registration so tools with falsy ``available_when``
        # predicates never make it onto the kernel.
        if spec.ui_tools is not None:
            from agentflow.genui import filter_by_availability

            from ..genui import resolve_ui_tools

            ui_plugin = resolve_ui_tools(spec.ui_tools)
            if ui_plugin is not None:
                # KernelPlugin exposes its functions via ``.functions`` (a
                # dict). The filter operates on the value list, then we
                # rebuild the plugin if anything was removed.
                from semantic_kernel.functions import KernelPlugin

                fns = list(ui_plugin.functions.values())
                filtered = filter_by_availability(
                    fns, spec.available_when, self.build_state
                )
                if filtered:
                    final_plugin = (
                        ui_plugin
                        if len(filtered) == len(fns)
                        else KernelPlugin(name=ui_plugin.name, functions=filtered)
                    )
                    kernel.add_plugin(final_plugin)

        # Agent-specific filters
        from ..filters import compile_guards, compile_observers, compile_optimizers

        for compiled in compile_guards(spec.guards):
            kernel.add_filter(compiled.filter_type, compiled.filter_fn)
        for compiled in compile_optimizers(spec.optimizers):
            kernel.add_filter(compiled.filter_type, compiled.filter_fn)
        for compiled in compile_observers(spec.observers):
            kernel.add_filter(compiled.filter_type, compiled.filter_fn)

        return kernel

    def _create_agent(self, spec: AgentSpec, kernel: Any) -> Any:
        """Create an SK Agent instance of the configured type."""
        if spec.type == AgentType.CHAT_COMPLETION:
            from semantic_kernel.agents import ChatCompletionAgent

            kwargs: Dict[str, Any] = dict(
                kernel=kernel,
                name=_sanitize_agent_name(spec.name),
                instructions=spec.system_prompt,
            )
            if spec.description:
                kwargs["description"] = spec.description
            behavior = _resolve_function_choice_behavior(spec.execution_settings)
            if behavior is not None:
                kwargs["function_choice_behavior"] = behavior
            if spec.config:
                kwargs.update(spec.config)
            return ChatCompletionAgent(**kwargs)

        if spec.type == AgentType.AZURE_AI:
            from semantic_kernel.agents import AzureAIAgent
            return AzureAIAgent(
                kernel=kernel,
                name=_sanitize_agent_name(spec.name),
                instructions=spec.system_prompt,
                description=spec.description,
                **(spec.config or {}),
            )

        if spec.type == AgentType.OPENAI_ASSISTANT:
            from semantic_kernel.agents import OpenAIAssistantAgent
            return OpenAIAssistantAgent(
                kernel=kernel,
                name=_sanitize_agent_name(spec.name),
                instructions=spec.system_prompt,
                description=spec.description,
                **(spec.config or {}),
            )

        if spec.type == AgentType.OPENAI_RESPONSES:
            from semantic_kernel.agents import OpenAIResponsesAgent
            return OpenAIResponsesAgent(
                kernel=kernel,
                name=_sanitize_agent_name(spec.name),
                instructions=spec.system_prompt,
                description=spec.description,
                **(spec.config or {}),
            )

        if spec.type == AgentType.BEDROCK:
            from semantic_kernel.agents import BedrockAgent
            return BedrockAgent(
                kernel=kernel,
                name=_sanitize_agent_name(spec.name),
                instructions=spec.system_prompt,
                description=spec.description,
                **(spec.config or {}),
            )

        raise ValueError(f"Unsupported agent type: {spec.type}")

    # ------------------------------------------------------------------
    # Serving — expose built agent as an MCP server
    # ------------------------------------------------------------------

    def build_mcp_server(self) -> Any:
        """Build the agent and expose it as an MCP server."""
        if not self.config.serving or not self.config.serving.mcp_server:
            raise ValueError(
                "build_mcp_server() requires 'serving.mcp_server: true' in YAML"
            )
        agent = self.build()
        server_name = (
            self.config.serving.server_name
            or self.config.metadata.name
            or "agentflow-server"
        )
        return agent.as_mcp_server(server_name=server_name)

    # ------------------------------------------------------------------
    # Dry-run summary
    # ------------------------------------------------------------------

    def dry_run(self) -> Dict[str, Any]:
        """Validate config without building SK objects. Returns a summary dict."""
        # Determine effective mode
        if self.config.agents:
            effective_mode = self.config.mode.value if self.config.mode else None
            agent_names = [a.name for a in self.config.agents]
            agent_types = [a.type.value for a in self.config.agents]
        else:
            effective_mode = self.config.mode.value if self.config.mode else "autonomous"
            agent_names = [self.config.agent.name] if self.config.agent else []
            agent_types = [self.config.agent.type.value] if self.config.agent else []

        return {
            "backend": "semantic-kernel",
            "metadata": {
                "name": self.config.metadata.name,
                "version": self.config.metadata.version,
                "description": self.config.metadata.description,
            },
            "mode": effective_mode,
            "agents": agent_names,
            "agent_types": agent_types,
            "services": [s.service_id for s in (self.config.services or [])],
            "plugins": [p.name for p in (self.config.plugins or [])],
            "guards": [g.type.value for g in (self.config.guards or [])],
            "optimizers": [o.type.value for o in (self.config.optimizers or [])],
            "observers": [o.type.value for o in (self.config.observers or [])],
            "filters": [f.type.value for f in (self.config.filters or [])],
            "memory": (
                self.config.memory.connector.value if self.config.memory else None
            ),
            "process_steps": (
                [s.name for s in self.config.process.steps]
                if self.config.process else None
            ),
            "processes": list((self.config.processes or {}).keys()),
            "mcp_servers": list((self.config.mcp_servers or {}).keys()),
            "serving": self.config.serving is not None and self.config.serving.mcp_server,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ensure_sk_installed() -> None:
    try:
        import semantic_kernel  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "semantic-kernel is required but not installed. "
            "Install it with: pip install agentflow[semantic-kernel]"
        ) from e


def _import_class(module_path: str, class_name: str) -> Any:
    """Import a class by module path and class name."""
    import importlib
    module = importlib.import_module(module_path)
    cls = getattr(module, class_name, None)
    if cls is None:
        raise ValueError(f"Class '{class_name}' not found in module '{module_path}'")
    return cls


def _sanitize_agent_name(name: str) -> str:
    """Strip characters SK/Azure OpenAI forbids in agent names."""
    import re
    name = name.replace(" ", "_")
    return re.sub(r"[\s<|\\/>]", "", name)


def _resolve_function_choice_behavior(
        settings: Optional[ExecutionSettings],
) -> Optional[Any]:
    """Translate YAML function_choice_behavior to SK FunctionChoiceBehavior."""
    if settings is None:
        return None

    from semantic_kernel.connectors.ai import FunctionChoiceBehavior

    behavior = (settings.function_choice_behavior or "auto").lower()
    if behavior == "auto":
        return FunctionChoiceBehavior.Auto()
    if behavior == "required":
        return FunctionChoiceBehavior.Required()
    if behavior == "none":
        return FunctionChoiceBehavior.NoneInvoke()
    return FunctionChoiceBehavior.Auto()
