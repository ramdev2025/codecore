"""
Pydantic config models for the Semantic Kernel YAML schema.

The SK schema embraces SK-specific capabilities (multi-service kernels,
filters, memory connectors, process framework, agent orchestrations)
while keeping the same agent-centric mental model as workflows/deep.

Schema shape:

    backend: semantic-kernel

    # Top-level LLM (default for all agents — same as workflows/deep)
    llm: { ... }

    # Multi-service kernel (SK-specific, optional)
    services: [ ... ]

    # Structure declares intent:
    #   agent: (singular) alone        → autonomous
    #   agent: + process: + mode: process → process workflow
    #   agents: (list) + mode: ...     → orchestration (handoff/sequential/...)

    agent: { ... }             # autonomous or process mode
    agents: [ ... ]            # orchestration modes

    # Shared Kernel-level config
    plugins: [ ... ]           # shared plugins (available to all agents)
    guards: [ ... ]            # constrain and protect
    optimizers: [ ... ]        # improve efficiency
    observers: [ ... ]         # watch without modifying
    filters: [ ... ]           # SK-native filter references
    memory: { ... }            # vector store connector

    # Process definitions (mutually exclusive)
    process: { ... }           # single process (with agent: + mode: process)
    processes: { ... }         # named processes linked to agents in orchestration

    mcp_servers: { ... }       # MCP server connections
    serving: { ... }           # agent-as-MCP-server deployment
"""

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, model_validator

from agentflow.genui import ClientToolConfig, UIToolsConfig


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


class SKMetadata(BaseModel):
    """Metadata about the SK YAML config."""

    version: str = Field(..., description="Schema version (e.g. '1.0')")
    name: Optional[str] = Field(None, description="Human-readable name for this config")
    description: Optional[str] = Field(None, description="Description of this config")
    author: Optional[str] = Field(None, description="Author or team")
    tags: Optional[List[str]] = Field(None, description="Tags for categorization")


# ---------------------------------------------------------------------------
# AI services (multi-service kernel)
# ---------------------------------------------------------------------------


class ServiceType(str, Enum):
    """AI service types supported by SK kernels."""

    CHAT_COMPLETION = "chat_completion"
    EMBEDDINGS = "embeddings"
    TEXT_TO_IMAGE = "text_to_image"
    TEXT_TO_AUDIO = "text_to_audio"


class LLMProvider(str, Enum):
    """Supported LLM providers (shared convention with workflows/deep)."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    AZURE_OPENAI = "azure_openai"
    CUSTOM = "custom"


class LLMConfig(BaseModel):
    """LLM configuration — same shape as workflows/deep for the common case."""

    provider: LLMProvider = Field(..., description="LLM provider")
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Provider-specific config (model, api_key, endpoint, etc.)",
    )


class ServiceConfig(BaseModel):
    """One AI service registered on the Kernel.

    Used when multiple services are needed (e.g. chat + embeddings for RAG).
    For simple single-service setups, use the top-level ``llm:`` shorthand.
    """

    service_id: str = Field(default="default", description="Unique service ID within the Kernel")
    type: ServiceType = Field(
        default=ServiceType.CHAT_COMPLETION,
        description="Service type (chat_completion, embeddings, etc.)",
    )
    provider: LLMProvider = Field(..., description="Provider (openai, azure_openai, etc.)")
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Provider-specific config",
    )


# ---------------------------------------------------------------------------
# Execution settings
# ---------------------------------------------------------------------------


class FunctionFilter(BaseModel):
    """Fine-grained control over which functions the model can call."""

    include: Optional[List[str]] = Field(
        None,
        description="Allowlist of 'plugin_name.function_name' patterns",
    )
    exclude: Optional[List[str]] = Field(
        None,
        description="Blocklist of 'plugin_name.function_name' patterns",
    )


class ExecutionSettings(BaseModel):
    """Prompt execution settings passed to SK's ChatPromptExecutionSettings."""

    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    function_choice_behavior: str = Field(
        default="auto",
        description="'auto', 'required', or 'none'",
    )
    function_filter: Optional[FunctionFilter] = None
    service_id: Optional[str] = Field(
        None,
        description="Which service to use (references services[].service_id)",
    )


# ---------------------------------------------------------------------------
# Agent modes and types
# ---------------------------------------------------------------------------


class AgentMode(str, Enum):
    """Execution modes requiring explicit ``mode:`` declaration.

    Autonomous mode is implied by the presence of singular ``agent:`` with no
    ``process:`` and no ``mode:`` field — not an enum value.
    """

    HANDOFF = "handoff"              # HandoffOrchestration — first agent = router
    SEQUENTIAL = "sequential"        # SequentialOrchestration — list order = execution order
    GROUP_CHAT = "group_chat"        # GroupChatOrchestration — first agent = moderator
    MAGENTIC = "magentic"            # MagenticOrchestration — first agent = orchestrator
    PROCESS = "process"              # ProcessBuilder (with agent: + process:)


class AgentType(str, Enum):
    """SK agent implementation types."""

    CHAT_COMPLETION = "chat_completion"
    AZURE_AI = "azure_ai"
    OPENAI_ASSISTANT = "openai_assistant"
    OPENAI_RESPONSES = "openai_responses"
    BEDROCK = "bedrock"


# ---------------------------------------------------------------------------
# Plugins
# ---------------------------------------------------------------------------


class PluginType(str, Enum):
    """Plugin types supported by SK."""

    PYTHON = "python"              # @kernel_function from a Python module
    PROMPT = "prompt"              # Prompt template (semantic function)
    OPENAPI = "openapi"            # OpenAPI spec
    DIRECTORY = "directory"        # SK plugin directory format


class PluginRef(BaseModel):
    """Reference to a plugin that should be registered on the Kernel."""

    name: str = Field(..., description="Plugin name in the Kernel")
    type: PluginType = Field(default=PluginType.PYTHON)

    # Python plugin fields
    module: Optional[str] = Field(None, description="Python module path (for type: python)")
    functions: Optional[List[str]] = Field(
        None,
        description="Specific function names to import (default: all @kernel_function)",
    )

    # Prompt plugin fields
    description: Optional[str] = Field(None, description="Description (for type: prompt)")
    template: Optional[str] = Field(None, description="Prompt template (for type: prompt)")

    # OpenAPI plugin fields
    spec_url: Optional[str] = Field(None, description="OpenAPI spec URL (for type: openapi)")
    spec_path: Optional[str] = Field(None, description="OpenAPI spec local path (for type: openapi)")

    # Directory plugin fields
    path: Optional[str] = Field(None, description="Plugin directory path (for type: directory)")


# ---------------------------------------------------------------------------
# Guards, optimizers, observers, filters
# ---------------------------------------------------------------------------


class GuardType(str, Enum):
    """Guard types — constrain and protect the agent."""

    PII = "pii"
    MODEL_CALL_LIMIT = "model_call_limit"
    TOOL_CALL_LIMIT = "tool_call_limit"
    INPUT_VALIDATION = "input_validation"
    CONTENT_FILTER = "content_filter"


class GuardConfig(BaseModel):
    """A guard entry — built-in type or custom user-provided filter."""

    type: GuardType
    config: Optional[Dict[str, Any]] = None
    # For custom guards, provide module + function instead of a built-in type
    module: Optional[str] = None
    function: Optional[str] = None


class OptimizerType(str, Enum):
    """Optimizer types — improve efficiency."""

    SUMMARIZATION = "summarization"
    PROMPT_CACHING = "prompt_caching"
    MODEL_FALLBACK = "model_fallback"
    TOOL_RETRY = "tool_retry"


class OptimizerConfig(BaseModel):
    """An optimizer entry."""

    type: OptimizerType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class ObserverType(str, Enum):
    """Observer types — watch without modifying execution."""

    AUDIT_LOG = "audit_log"
    COST_TRACKING = "cost_tracking"
    LATENCY_TRACKING = "latency_tracking"


class ObserverConfig(BaseModel):
    """An observer entry."""

    type: ObserverType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class FilterType(str, Enum):
    """SK-native filter types (raw middleware, full power)."""

    FUNCTION_INVOCATION = "function_invocation"
    PROMPT_RENDERING = "prompt_rendering"
    AUTO_FUNCTION_INVOCATION = "auto_function_invocation"


class FilterRef(BaseModel):
    """Reference to a user-provided SK filter function.

    The referenced function must follow SK's signature:
    ``async def(context, next): ...``
    """

    type: FilterType
    module: str = Field(..., description="Python module path")
    function: str = Field(..., description="Filter function name")


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------


class MemoryConnectorType(str, Enum):
    """Supported SK memory connectors."""

    AZURE_AI_SEARCH = "azure_ai_search"
    QDRANT = "qdrant"
    CHROMA = "chroma"
    REDIS = "redis"
    CUSTOM = "custom"


class MemoryConfig(BaseModel):
    """Vector memory configuration.

    References an embedding service from ``services:`` via ``embedding_service_id``.
    """

    connector: MemoryConnectorType
    embedding_service_id: Optional[str] = Field(
        None,
        description="Service ID from services[] to use for embeddings",
    )
    config: Dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Process framework
# ---------------------------------------------------------------------------


class ProcessStepRef(BaseModel):
    """Reference to a Python KernelProcessStep subclass."""

    name: str = Field(..., description="Step name (used to wire events)")
    module: str = Field(..., description="Python module path")
    class_name: str = Field(..., description="KernelProcessStep subclass name")
    config: Optional[Dict[str, Any]] = None


class ProcessEventLink(BaseModel):
    """Routes an event emitted by one step to another step's handler."""

    from_step: str
    event: str
    to_step: str
    function: Optional[str] = Field(
        None,
        description="Target function name on to_step (optional)",
    )


class ProcessConfig(BaseModel):
    """Process definition — step topology and event wiring."""

    agent: Optional[str] = Field(
        None,
        description="For plural 'processes:' only — links process to an agent by name",
    )
    entry_step: str = Field(..., description="Step that receives the initial input")
    steps: List[ProcessStepRef] = Field(..., min_length=1)
    events: List[ProcessEventLink] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Agent spec (shared shape for singular agent: and list entries)
# ---------------------------------------------------------------------------


class AgentSpec(BaseModel):
    """Agent definition. Used for both singular ``agent:`` and entries in ``agents:``.

    Position-based roles in orchestration modes (no ``role:`` field):
    - Handoff: first agent = router
    - Magentic: first agent = orchestrator
    - Group chat: first agent = moderator
    - Sequential: list order = execution order
    """

    name: str = Field(..., description="Agent name (used for SK agent construction + telemetry)")
    description: Optional[str] = Field(
        None,
        description="Description (used by orchestration modes like handoff routing)",
    )
    system_prompt: str = Field(..., description="Agent system prompt / instructions")
    type: AgentType = Field(default=AgentType.CHAT_COMPLETION)

    # Per-agent config (overrides shared Kernel-level config)
    llm: Optional[LLMConfig] = Field(
        None,
        description="Overrides top-level llm: for this agent",
    )
    plugins: Optional[List[PluginRef]] = Field(
        None,
        description="Agent-scoped plugins (registered on this agent's Kernel)",
    )

    # Cross-backend generative-UI components. Same schema MAF uses,
    # so a single YAML block works on either backend.
    ui_tools: Optional[UIToolsConfig] = Field(
        None,
        description=(
            "Generative-UI components: a module of "
            "``@agentflow.genui.ui_component``-decorated fetchers exposed "
            "as SK ``KernelFunction``s on the agent's kernel. Tool name "
            "is the fetcher function name; the return value is validated "
            "against the declared Pydantic class and made available to "
            "the LLM as structured JSON. Frontend rendering requires a "
            "separate AG-UI bridge (not shipped on SK as of this release)."
        ),
    )

    # Frontend-implemented tools. The SK AG-UI bridge advertises these
    # in the agent's tool list and pauses the run when the LLM invokes
    # one; the browser handler executes and posts the result back on the
    # next turn (no langgraph.interrupt — SK doesn't have that primitive).
    # Same cross-backend schema as workflows / deep / MAF.
    client_tools: Optional[List[ClientToolConfig]] = Field(
        default=None,
        description=(
            "Frontend-implemented (browser-side) tools. Each becomes a "
            "tool the LLM sees; the SK AG-UI bridge pauses the run when "
            "it's invoked and resumes once the browser posts the result. "
            "Bound to the agent only when the AG-UI router opts in via "
            "``bind_client_tools=True``."
        ),
    )

    # Cross-backend build-time predicate gating. Same shape as MAF.
    available_when: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Build-time predicate gating for ``ui_tools``. Keys are "
            "component class names; values are ``simpleeval`` expressions "
            "evaluated once at agent construction against the build "
            "state passed to the SK builder. Tools with falsy "
            "predicates are excluded from the kernel — the LLM never "
            "sees them."
        ),
    )

    guards: Optional[List[GuardConfig]] = None
    optimizers: Optional[List[OptimizerConfig]] = None
    observers: Optional[List[ObserverConfig]] = None
    execution_settings: Optional[ExecutionSettings] = None

    # Agent-type-specific config (passed as kwargs to the agent constructor)
    config: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# MCP
# ---------------------------------------------------------------------------


class MCPServerEntry(BaseModel):
    """MCP server connection configuration."""

    transport: str = Field(default="stdio", description="'stdio' or 'sse'")
    command: Optional[str] = None
    args: Optional[List[str]] = None
    url: Optional[str] = None
    env: Optional[Dict[str, str]] = None


# ---------------------------------------------------------------------------
# Serving (agent-as-MCP-server)
# ---------------------------------------------------------------------------


class ServingConfig(BaseModel):
    """Expose the agent as an MCP server."""

    mcp_server: bool = Field(default=False, description="Expose agent as MCP server")
    server_name: Optional[str] = Field(None, description="MCP server name")


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


class SKYAMLConfig(BaseModel):
    """Root Semantic Kernel YAML config."""

    backend: str = Field(default="semantic-kernel")
    metadata: SKMetadata

    # Execution mode — omitted for autonomous, required for everything else
    mode: Optional[AgentMode] = None

    # Mutually exclusive: singular agent OR list of agents
    agent: Optional[AgentSpec] = None
    agents: Optional[List[AgentSpec]] = None

    # Shared (Kernel-level) config
    llm: Optional[LLMConfig] = Field(None, description="Top-level default LLM")
    services: Optional[List[ServiceConfig]] = Field(
        None,
        description="Multi-service kernel (chat + embeddings + etc.)",
    )
    plugins: Optional[List[PluginRef]] = Field(
        None,
        description="Shared plugins on the Kernel (available to all agents)",
    )
    guards: Optional[List[GuardConfig]] = None
    optimizers: Optional[List[OptimizerConfig]] = None
    observers: Optional[List[ObserverConfig]] = None
    filters: Optional[List[FilterRef]] = Field(None, description="SK-native filter references")
    memory: Optional[MemoryConfig] = None
    mcp_servers: Optional[Dict[str, MCPServerEntry]] = None

    # Process definitions (mutually exclusive)
    process: Optional[ProcessConfig] = Field(
        None,
        description="Single process (with agent: + mode: process)",
    )
    processes: Optional[Dict[str, ProcessConfig]] = Field(
        None,
        description="Named processes linked to agents in orchestration modes",
    )

    # Deployment
    serving: Optional[ServingConfig] = None

    @model_validator(mode="after")
    def _validate_structure(self) -> "SKYAMLConfig":
        # Rule 1: exactly one of agent: or agents:
        if self.agent is not None and self.agents is not None:
            raise ValueError(
                "'agent:' (singular) and 'agents:' (list) are mutually exclusive. "
                "Use 'agent:' for autonomous/process modes or 'agents:' for orchestration modes."
            )
        if self.agent is None and self.agents is None:
            raise ValueError(
                "Either 'agent:' (singular, for autonomous/process modes) or "
                "'agents:' (list, for orchestration modes) must be present."
            )

        # Rule 2: process: and processes: are mutually exclusive
        if self.process is not None and self.processes is not None:
            raise ValueError(
                "'process:' (single) and 'processes:' (named map) are mutually exclusive."
            )

        # Rule 3: singular agent: rules
        if self.agent is not None:
            if self.process is not None:
                # process workflow: mode must be PROCESS
                if self.mode != AgentMode.PROCESS:
                    raise ValueError(
                        "When 'process:' is set with singular 'agent:', 'mode:' must be 'process'."
                    )
            else:
                # autonomous: mode must be None
                if self.mode is not None:
                    raise ValueError(
                        "Singular 'agent:' without 'process:' implies autonomous mode — "
                        "do not set 'mode:'."
                    )
            if self.processes is not None:
                raise ValueError(
                    "'processes:' (plural) is for orchestration modes with 'agents:' list — "
                    "not for singular 'agent:'."
                )

        # Rule 4: plural agents: rules
        if self.agents is not None:
            if self.mode is None:
                raise ValueError(
                    "'agents:' (list) requires 'mode:' to be set "
                    "(handoff, sequential, group_chat, or magentic)."
                )
            if self.mode == AgentMode.PROCESS:
                raise ValueError(
                    "'mode: process' requires singular 'agent:' + 'process:', not 'agents:' list."
                )
            if len(self.agents) == 0:
                raise ValueError("'agents:' list cannot be empty.")
            if self.process is not None:
                raise ValueError(
                    "'process:' (singular) is for 'mode: process' with singular 'agent:' — "
                    "use 'processes:' (plural) to link processes to agents in orchestration."
                )

        # Rule 5: each processes: entry must reference an agent in agents:
        if self.processes is not None:
            if self.agents is None:
                raise ValueError(
                    "'processes:' (plural) requires 'agents:' list (orchestration mode)."
                )
            agent_names = {a.name for a in self.agents}
            for proc_name, proc_config in self.processes.items():
                if proc_config.agent is None:
                    raise ValueError(
                        f"Process '{proc_name}' is missing the 'agent:' field "
                        f"(must reference an agent in 'agents:' list)."
                    )
                if proc_config.agent not in agent_names:
                    raise ValueError(
                        f"Process '{proc_name}' references agent '{proc_config.agent}' "
                        f"which is not defined in 'agents:' list."
                    )

        return self
