"""
MCP server integration for Semantic Kernel.

SK has native MCP support via ``MCPStdioPlugin`` and ``MCPSsePlugin``, so this
module is thin — it just translates ``MCPServerEntry`` YAML config into the
appropriate SK plugin class. Each MCP server becomes a ``KernelPlugin`` that
can be registered on the Kernel with ``kernel.add_plugin(plugin)``.

Transports supported (matching SK's capabilities):

- ``stdio`` — subprocess-based, good for local tools
- ``sse`` — Server-Sent Events, good for remote servers

Streamable HTTP is not yet natively supported by SK's MCP connectors; users
who need it should configure SSE on the MCP server side.
"""

from typing import Any, Dict, List

from .config_models import MCPServerEntry


def resolve_mcp_plugins(servers: Dict[str, MCPServerEntry]) -> List[Any]:
    """Create an SK MCP plugin for each configured MCP server.

    Args:
        servers: Mapping of server name → ``MCPServerEntry`` config.

    Returns:
        List of SK ``KernelPlugin`` instances ready for
        ``kernel.add_plugin(plugin)``.

    Raises:
        ImportError: ``semantic-kernel`` not installed.
        ValueError: Unsupported transport or missing required fields.
    """
    try:
        from semantic_kernel.connectors.mcp import MCPSsePlugin, MCPStdioPlugin
    except ImportError as e:
        raise ImportError(
            "semantic-kernel is required but not installed. "
            "Install it with: pip install agentflow[semantic-kernel]"
        ) from e

    plugins: List[Any] = []
    for name, entry in servers.items():
        plugins.append(_build_plugin(name, entry, MCPStdioPlugin, MCPSsePlugin))
    return plugins


def _build_plugin(
        name: str,
        entry: MCPServerEntry,
        stdio_cls: Any,
        sse_cls: Any,
) -> Any:
    """Build a single MCP plugin from a server entry."""
    transport = entry.transport.lower()

    if transport == "stdio":
        if not entry.command:
            raise ValueError(
                f"MCP server '{name}' (transport: stdio) requires a 'command' field."
            )
        return stdio_cls(
            name=name,
            command=entry.command,
            args=entry.args or [],
            env=entry.env,
        )

    if transport == "sse":
        if not entry.url:
            raise ValueError(
                f"MCP server '{name}' (transport: sse) requires a 'url' field."
            )
        return sse_cls(
            name=name,
            url=entry.url,
        )

    raise ValueError(
        f"MCP server '{name}' uses unsupported transport: {entry.transport!r}. "
        f"SK supports 'stdio' and 'sse'."
    )
