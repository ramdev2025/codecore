"""YAML loading helpers for SK config (${ENV_VAR} expansion + .env loading)."""

import os
import os.path
from pathlib import Path
from typing import Any, Dict, Union

import yaml


def expand_env_vars(value: Any) -> Any:
    """Recursively expand ${ENV_VAR} references in strings, dicts, and lists."""
    if isinstance(value, str):
        return os.path.expandvars(value)
    elif isinstance(value, dict):
        return {k: expand_env_vars(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [expand_env_vars(item) for item in value]
    return value


def load_sk_config(path: Union[str, Path]) -> Dict[str, Any]:
    """Load an SK YAML config with ${ENV_VAR} expansion.

    Automatically loads .env from the YAML file's directory and cwd.

    Args:
        path: Path to the YAML configuration file.

    Returns:
        Parsed configuration dictionary with environment variables expanded.
    """
    from dotenv import find_dotenv, load_dotenv

    yaml_dir = Path(path).resolve().parent
    load_dotenv(yaml_dir / ".env", override=True)

    # Anchor the fallback walk at the user's cwd, not the caller's module.
    # On a pip install the bare ``load_dotenv()`` default walks up from
    # inside ``site-packages/`` and can cross into an ancestor .env
    # unrelated to the user's project, silently clobbering the good values.
    cwd_dotenv = find_dotenv(usecwd=True)
    if cwd_dotenv and Path(cwd_dotenv).resolve() != (yaml_dir / ".env").resolve():
        load_dotenv(cwd_dotenv, override=True)

    with open(path, "r", encoding="utf-8") as f:
        raw = os.path.expandvars(f.read())
        config = yaml.safe_load(raw)
    return config or {}
