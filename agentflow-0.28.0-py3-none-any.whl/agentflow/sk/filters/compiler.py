"""
Compile guard/optimizer/observer YAML entries into SK kernel filters.

The compiler looks up built-in implementations by type, or imports a
user-provided ``module:function`` pair for custom filters. Each call
returns a list of ``CompiledFilter`` objects — ``(filter_type, filter_fn)``
pairs — that the builder registers on the Kernel via
``kernel.add_filter(filter_type, filter_fn)``.
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Callable, List, Optional

from ..core.config_models import (
    GuardConfig,
    GuardType,
    ObserverConfig,
    ObserverType,
    OptimizerConfig,
    OptimizerType,
)
from . import builtin


@dataclass
class CompiledFilter:
    """One SK kernel filter ready for ``kernel.add_filter(type, fn)``."""

    filter_type: Any         # SK FilterTypes enum value — resolved lazily
    filter_fn: Callable      # async def(context, next)


# ---------------------------------------------------------------------------
# Built-in type → (sk_filter_type, factory) registries
# ---------------------------------------------------------------------------


def _sk_filter_types():
    """Lazy import so the module loads without semantic-kernel installed."""
    from semantic_kernel.filters import FilterTypes
    return FilterTypes


# Each entry: GuardType/OptimizerType/ObserverType → (sk FilterType name, builtin factory fn)
# The factory fn receives an optional config dict and returns an async filter.

_GUARD_BUILTINS: dict = {
    GuardType.MODEL_CALL_LIMIT:    ("AUTO_FUNCTION_INVOCATION", builtin.make_model_call_limit),
    GuardType.TOOL_CALL_LIMIT:     ("AUTO_FUNCTION_INVOCATION", builtin.make_tool_call_limit),
    GuardType.PII:                 ("PROMPT_RENDERING",          builtin.make_pii_guard),
    GuardType.INPUT_VALIDATION:    ("PROMPT_RENDERING",          None),  # custom only
    GuardType.CONTENT_FILTER:      ("PROMPT_RENDERING",          None),  # custom only
}

_OPTIMIZER_BUILTINS: dict = {
    OptimizerType.TOOL_RETRY:      ("FUNCTION_INVOCATION",       builtin.make_tool_retry),
    OptimizerType.PROMPT_CACHING:  ("PROMPT_RENDERING",          None),  # custom only
    OptimizerType.SUMMARIZATION:   ("PROMPT_RENDERING",          None),  # custom only
    OptimizerType.MODEL_FALLBACK:  ("FUNCTION_INVOCATION",       None),  # custom only
}

_OBSERVER_BUILTINS: dict = {
    ObserverType.AUDIT_LOG:        ("FUNCTION_INVOCATION",       builtin.make_audit_log),
    ObserverType.LATENCY_TRACKING: ("FUNCTION_INVOCATION",       builtin.make_latency_tracking),
    ObserverType.COST_TRACKING:    ("FUNCTION_INVOCATION",       builtin.make_cost_tracking),
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compile_guards(entries: Optional[List[GuardConfig]]) -> List[CompiledFilter]:
    """Compile guard YAML entries into SK filter callables."""
    if not entries:
        return []
    return [_compile_one(e.type.value, e, _GUARD_BUILTINS) for e in entries]


def compile_optimizers(entries: Optional[List[OptimizerConfig]]) -> List[CompiledFilter]:
    """Compile optimizer YAML entries into SK filter callables."""
    if not entries:
        return []
    return [_compile_one(e.type.value, e, _OPTIMIZER_BUILTINS) for e in entries]


def compile_observers(entries: Optional[List[ObserverConfig]]) -> List[CompiledFilter]:
    """Compile observer YAML entries into SK filter callables."""
    if not entries:
        return []
    return [_compile_one(e.type.value, e, _OBSERVER_BUILTINS) for e in entries]


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


def _compile_one(
        type_str: str,
        entry: Any,
        builtins: dict,
) -> CompiledFilter:
    """Build a single compiled filter from a guard/optimizer/observer entry.

    If the entry provides ``module:`` + ``function:``, load the user-provided
    filter. Otherwise, look up the built-in implementation by type.
    """
    # Custom filter via module + function
    if entry.module and entry.function:
        filter_fn = _import_filter(entry.module, entry.function)
        # Default filter type based on the registry — users can override by providing
        # their own filter that wraps around any SK FilterType
        sk_type_name, _ = builtins[entry.type]
        return CompiledFilter(
            filter_type=_resolve_sk_filter_type(sk_type_name),
            filter_fn=filter_fn,
        )

    # Built-in implementation
    sk_type_name, factory = builtins[entry.type]
    if factory is None:
        raise ValueError(
            f"'{type_str}' does not have a built-in implementation. "
            f"Provide 'module:' and 'function:' fields to supply your own "
            f"SK filter (async def(context, next))."
        )

    filter_fn = factory(entry.config or {})
    return CompiledFilter(
        filter_type=_resolve_sk_filter_type(sk_type_name),
        filter_fn=filter_fn,
    )


def _import_filter(module: str, function: str) -> Callable:
    """Import a user-provided filter function by module + name."""
    mod = importlib.import_module(module)
    fn = getattr(mod, function, None)
    if fn is None:
        raise ValueError(
            f"Filter function '{function}' not found in module '{module}'"
        )
    if not callable(fn):
        raise ValueError(
            f"'{module}.{function}' is not callable"
        )
    return fn


def _resolve_sk_filter_type(name: str) -> Any:
    """Translate filter-type name ('FUNCTION_INVOCATION', ...) to SK's enum value."""
    try:
        FilterTypes = _sk_filter_types()
    except ImportError as e:
        raise ImportError(
            "semantic-kernel is required but not installed. "
            "Install it with: pip install agentflow[semantic-kernel]"
        ) from e
    return getattr(FilterTypes, name)
