"""
Built-in SK filter implementations for common guards/optimizers/observers.

Each ``make_*`` factory takes an optional config dict and returns an async
filter function compatible with SK's filter pipeline
(``async def(context, next): ...``).

Filters receive an SK context object and must either call ``await next(ctx)``
to continue the pipeline or mutate/short-circuit (e.g. set ``terminate=True``
on auto-function-invocation contexts).
"""

from __future__ import annotations

import logging
import re
import time
from typing import Any, Callable, Dict

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------


def make_tool_call_limit(config: Dict[str, Any]) -> Callable:
    """Terminate the auto-function-calling loop after N total tool calls.

    Uses ``AutoFunctionInvocationContext.terminate`` to stop the loop.
    Config: ``{"max_calls": 20}`` (default 20).
    """
    max_calls = int(config.get("max_calls", 20))
    state = {"count": 0}

    async def filter_fn(context, next):
        state["count"] += 1
        if state["count"] > max_calls:
            context.terminate = True
            logger.warning(
                "tool_call_limit exceeded: %d > %d — terminating auto-function loop",
                state["count"], max_calls,
            )
            return
        await next(context)

    return filter_fn


def make_model_call_limit(config: Dict[str, Any]) -> Callable:
    """Terminate the auto-function-calling loop after N LLM request rounds.

    Each ``AutoFunctionInvocationContext`` represents one tool call within a
    round of LLM invocations. We track the ``request_sequence_index`` to
    count rounds rather than total tool calls.

    Config: ``{"max_calls": 10}`` (default 10).
    """
    max_calls = int(config.get("max_calls", 10))

    async def filter_fn(context, next):
        # request_sequence_index is 0-based; stop once it reaches max_calls
        if getattr(context, "request_sequence_index", 0) >= max_calls:
            context.terminate = True
            logger.warning(
                "model_call_limit exceeded: request %d >= %d — terminating",
                context.request_sequence_index, max_calls,
            )
            return
        await next(context)

    return filter_fn


def make_pii_guard(config: Dict[str, Any]) -> Callable:
    """Redact common PII patterns (email, phone, SSN) from rendered prompts.

    This is a basic regex scrubber — it catches obvious patterns but isn't a
    substitute for a real PII detection service. Users who need robust PII
    protection should provide a custom filter via ``module:`` + ``function:``.

    Config: ``{"replacement": "[REDACTED]", "patterns": {...custom regexes...}}``
    """
    replacement = config.get("replacement", "[REDACTED]")

    # Default patterns — users can extend via config['patterns']
    patterns = {
        "email": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),
        "phone": re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"),
        "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    }
    custom = config.get("patterns", {})
    for name, pattern in custom.items():
        patterns[name] = re.compile(pattern)

    async def filter_fn(context, next):
        await next(context)
        prompt = getattr(context, "rendered_prompt", None)
        if prompt:
            redacted = prompt
            for pattern in patterns.values():
                redacted = pattern.sub(replacement, redacted)
            context.rendered_prompt = redacted

    return filter_fn


# ---------------------------------------------------------------------------
# Optimizers
# ---------------------------------------------------------------------------


def make_tool_retry(config: Dict[str, Any]) -> Callable:
    """Retry failed function invocations up to N times before giving up.

    Config: ``{"max_retries": 3, "delay_seconds": 0.5}``
    """
    max_retries = int(config.get("max_retries", 3))
    delay = float(config.get("delay_seconds", 0.5))

    async def filter_fn(context, next):
        import asyncio
        last_exc: Exception | None = None
        for attempt in range(max_retries + 1):
            try:
                await next(context)
                return
            except Exception as e:
                last_exc = e
                if attempt < max_retries:
                    fn_name = getattr(getattr(context, "function", None), "name", "<unknown>")
                    logger.warning(
                        "tool_retry: attempt %d/%d for %s failed (%s) — retrying in %.1fs",
                        attempt + 1, max_retries + 1, fn_name, e, delay,
                    )
                    if delay > 0:
                        await asyncio.sleep(delay)
        # All retries exhausted
        raise last_exc

    return filter_fn


# ---------------------------------------------------------------------------
# Observers
# ---------------------------------------------------------------------------


def make_audit_log(config: Dict[str, Any]) -> Callable:
    """Log every function invocation (name, args, success/failure, duration).

    Config: ``{"level": "INFO"}`` — sets the log level.
    """
    level_name = config.get("level", "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)

    async def filter_fn(context, next):
        fn = getattr(context, "function", None)
        fn_name = getattr(fn, "name", "<unknown>") if fn else "<unknown>"
        start = time.perf_counter()
        try:
            await next(context)
            elapsed = time.perf_counter() - start
            logger.log(level, "audit: %s ok (%.3fs)", fn_name, elapsed)
        except Exception as e:
            elapsed = time.perf_counter() - start
            logger.log(level, "audit: %s error (%.3fs): %s", fn_name, elapsed, e)
            raise

    return filter_fn


def make_latency_tracking(config: Dict[str, Any]) -> Callable:
    """Track latency percentiles across function invocations.

    Emits a log line with rolling stats every ``log_every`` calls.
    Config: ``{"log_every": 10}``.
    """
    log_every = int(config.get("log_every", 10))
    samples: list[float] = []

    async def filter_fn(context, next):
        start = time.perf_counter()
        try:
            await next(context)
        finally:
            elapsed = time.perf_counter() - start
            samples.append(elapsed)
            if len(samples) % log_every == 0:
                sorted_samples = sorted(samples)
                n = len(sorted_samples)
                p50 = sorted_samples[n // 2]
                p95 = sorted_samples[int(n * 0.95)]
                logger.info(
                    "latency: n=%d p50=%.3fs p95=%.3fs max=%.3fs",
                    n, p50, p95, sorted_samples[-1],
                )

    return filter_fn


def make_cost_tracking(config: Dict[str, Any]) -> Callable:
    """Track cumulative token usage from function results.

    Looks for ``usage`` or ``usage_metadata`` on the result. Emits a log line
    when token totals cross each ``log_threshold`` bucket.

    Config: ``{"log_threshold": 1000, "budget_limit": 10.00}``.
    """
    log_threshold = int(config.get("log_threshold", 1000))
    budget_limit = config.get("budget_limit")  # optional, in USD
    state = {"tokens": 0, "last_logged": 0}

    async def filter_fn(context, next):
        await next(context)
        result = getattr(context, "result", None)
        if result is None:
            return

        # Try common shapes: usage_metadata.total_tokens, metadata['usage'], etc.
        tokens = _extract_total_tokens(result)
        if tokens is None:
            return

        state["tokens"] += tokens
        if state["tokens"] - state["last_logged"] >= log_threshold:
            logger.info(
                "cost_tracking: cumulative %d tokens",
                state["tokens"],
            )
            state["last_logged"] = state["tokens"]

        if budget_limit is not None:
            # Very rough cost estimate — users should implement real pricing
            # in a custom filter. This just warns on suspiciously high usage.
            if state["tokens"] > 1_000_000:
                logger.warning(
                    "cost_tracking: cumulative %d tokens may exceed budget limit %s",
                    state["tokens"], budget_limit,
                )

    return filter_fn


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_total_tokens(result: Any) -> int | None:
    """Pull total_tokens from an SK FunctionResult via common attribute paths."""
    # Direct usage attribute
    usage = getattr(result, "usage", None)
    if usage is not None:
        total = _get_total_tokens(usage)
        if total is not None:
            return total

    # Nested in metadata
    metadata = getattr(result, "metadata", None)
    if isinstance(metadata, dict):
        u = metadata.get("usage") or metadata.get("usage_metadata")
        if u is not None:
            total = _get_total_tokens(u)
            if total is not None:
                return total

    return None


def _get_total_tokens(usage: Any) -> int | None:
    """Extract total_tokens from a usage object/dict."""
    if isinstance(usage, dict):
        return usage.get("total_tokens") or (
            (usage.get("input_tokens", 0) + usage.get("output_tokens", 0)) or None
        )
    total = getattr(usage, "total_tokens", None)
    if total is not None:
        return total
    prompt = getattr(usage, "prompt_tokens", 0) or getattr(usage, "input_tokens", 0)
    completion = getattr(usage, "completion_tokens", 0) or getattr(usage, "output_tokens", 0)
    if prompt or completion:
        return prompt + completion
    return None
