"""
SK filter compilation — guards, optimizers, observers.

Each ``GuardConfig``/``OptimizerConfig``/``ObserverConfig`` from YAML
compiles into an SK kernel filter (``async def(context, next)``). Users
pick friendly names like ``type: tool_call_limit`` rather than writing
filter middleware by hand.

- **Guards** constrain and protect — PII redaction, rate limits.
- **Optimizers** improve efficiency — caching, retry, fallback.
- **Observers** watch without modifying — audit log, cost tracking.

Users who need custom behavior can provide ``module:`` + ``function:``
fields on any entry to plug in their own filter function.
"""

from .compiler import (
    CompiledFilter,
    compile_guards,
    compile_observers,
    compile_optimizers,
)

__all__ = [
    "CompiledFilter",
    "compile_guards",
    "compile_observers",
    "compile_optimizers",
]
