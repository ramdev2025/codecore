# AgentFlow SK

**YAML-driven agents and orchestrations on [Microsoft Semantic Kernel](https://learn.microsoft.com/en-us/semantic-kernel/).**

Third backend of AgentFlow, alongside `workflows` (LangGraph), `deep` (DeepAgents), `cas` (Claude Agent SDK), `oai` (OpenAI Agents SDK), and `agent-framework` (Microsoft Agent Framework). Install with `pip install agentflow[semantic-kernel]`.

> **Status: stable.** Implementation followed the standard backend-add process.

---

## Three execution modes

SK exposes more than one way to compose agents. The schema discriminates structurally:

1. **Single agent** — `agent: { ... }` → one `ChatCompletionAgent` with plugins.
2. **Orchestration** — `agents: { ... }` + `orchestration: { ... }` → multi-agent group chat / handoff / sequential / concurrent / Magentic patterns.
3. **Process** — `process: { ... }` → SK `KernelProcess` for explicit step graphs (CLI invocation isn't yet supported; build the process programmatically).

> **Why structural?** The YAML shape *is* the mode — no enum to keep in sync with the schema. Same approach as MAF (which discriminates `agent:` vs `workflow:`).

---

## Supported features

| Feature | YAML surface | Notes |
| --- | --- | --- |
| Single agent | `agent:` | `ChatCompletionAgent` with system prompt + plugins |
| Orchestrations | `orchestration: { mode: handoff | group_chat | sequential | concurrent | magentic }` | All five SDK orchestration modes; group chat needs a chat history reducer |
| Multi-agent peer graph (handoff) | `agents:` + `orchestration.mode: handoff` | Each agent has its own handoffs list |
| Services | `services:` | Multiple chat / embedding / image / audio services per kernel |
| LLM providers | `services.<id>.provider` | `openai`, `azure_openai` (RBAC), `anthropic`, custom |
| Plugins (kernel-native) | `plugins:` | `@kernel_function`-decorated modules with optional filter |
| Plugin bridge | `plugins:` with `module:` | Call any Python `@tool`-decorated function — works across backends |
| MCP servers | `mcp_servers:` | stdio / HTTP / SSE transports |
| Memory | `memory:` | Volatile / Redis / Azure AI Search via SK plugins |
| Guards (cross-backend) | `guards:` | Compile to SK function filters (PII, model-call limits, etc.) |
| Optimizers (cross-backend) | `optimizers:` | Tool retry, prompt caching, response caching |
| Observers (cross-backend) | `observers:` | Audit log, cost tracking, latency tracking |
| Sessions (history) | `--persistence` | `ChatHistory` per `thread_id`; AES-GCM encrypted at rest |
| OpenTelemetry tracing | `OTEL_TRACES_ENABLED=true` | `gen_ai.*` semconv; per-function + per-service spans |
| AES-GCM encryption at rest | `AGENTFLOW_ENCRYPTION_KEY` | Encrypts persisted `ChatHistory` payloads |
| MCP server mode | YAML `serving:` | Expose your agent *as* an MCP server other agents can call |
| CLI streaming | tokens / tool calls / agent switches | See [`docs/CLI_REFERENCE.md`](docs/CLI_REFERENCE.md) |
| `--output ndjson` | machine-readable event stream | One JSON event per line; schema in `agentflow.cli.events` |

---

## Minimal example — single agent

```yaml
backend: semantic-kernel

metadata:
  version: "1.0"
  name: customer-support

services:
  - id: chat
    type: chat_completion
    provider: openai
    model: gpt-4o-mini
    api_key: ${OPENAI_API_KEY}

agent:
  name: support-bot
  system_prompt: |
    You handle customer support questions. Keep replies concise.
  plugins:
    - name: orders
      module: myapp.support.order_tools
```

## Minimal example — handoff orchestration

```yaml
backend: semantic-kernel

metadata: { version: "1.0", name: triage }

services:
  - { id: chat, type: chat_completion, provider: openai, model: gpt-4o-mini, api_key: ${OPENAI_API_KEY} }

agents:
  triage:
    name: triage
    system_prompt: "Route to billing or technical."
    handoffs: [billing, technical]
  billing:
    name: billing
    system_prompt: "Handle billing questions."
  technical:
    name: technical
    system_prompt: "Handle technical questions."

orchestration:
  mode: handoff
  starting_agent: triage
```

Run with the unified CLI:

```bash
agentflow "I was charged twice"
agentflow --interactive                       # REPL with /help, /clear, /stats
agentflow --output ndjson "your query" > events.ndjson
```

---

## Documentation

- [`docs/GETTING_STARTED.md`](docs/GETTING_STARTED.md) — first agent walkthrough
- [`docs/YAML_REFERENCE.md`](docs/YAML_REFERENCE.md) — full YAML reference
- [`docs/CLI_REFERENCE.md`](docs/CLI_REFERENCE.md) — CLI flags, streaming output, `--output ndjson` schema
- [`docs/MODES.md`](docs/MODES.md) — single-agent vs orchestration vs process discrimination
- [`docs/SERVICES.md`](docs/SERVICES.md) — chat / embedding / image / audio service config
- [`docs/PLUGINS.md`](docs/PLUGINS.md) — `@kernel_function` plugins
- [`docs/PLUGIN_BRIDGE.md`](docs/PLUGIN_BRIDGE.md) — cross-backend `@tool` plugin bridge
- [`docs/PERSISTENCE.md`](docs/PERSISTENCE.md) — `ChatHistory` persistence, `agentflow-threads`
- [`docs/MEMORY.md`](docs/MEMORY.md) — Volatile / Redis / Azure AI Search memory
- [`docs/MCP.md`](docs/MCP.md) — MCP server integration
- [`docs/GUARDS.md`](docs/GUARDS.md) — cross-backend guard tier
- [`docs/OBSERVABILITY.md`](docs/OBSERVABILITY.md) — OpenTelemetry tracing
- [`docs/MIGRATION.md`](docs/MIGRATION.md) — migrating from other backends
- [`docs/PRODUCTION_FEATURES.md`](docs/PRODUCTION_FEATURES.md) — production deployment notes

Sibling backends: [`workflows/`](../workflows/) · [`deep/`](../deep/) · [`cas/`](../cas/) · [`oai/`](../oai/) · [`maf/`](../maf/)

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See the root [LICENSE](../../../LICENSE) for complete terms.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
