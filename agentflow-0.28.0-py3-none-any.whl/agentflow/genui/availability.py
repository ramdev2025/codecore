"""Cross-backend build-time ``available_when`` filtering.

Every backend's genui adapter (MAF / SK / cas / oai / adk / future
workflows) produces a list of *something callable* — MAF FunctionTool,
SK KernelFunction, in-process MCP server config, plain Python function,
etc. — each tagged with ``_agentflow_component_name`` (the Pydantic
component class name from the ``@ui_component`` decorator).

This module owns the filter: walk that list, look up the predicate by
component name, evaluate against the build state, drop the falsy ones.
Predicate evaluation goes through :func:`agentflow.genui.predicates.
evaluate_availability`, which is sandboxed and fail-closed.

Per-backend modules used to carry their own copies of this loop with
identical bodies; this consolidates them. Each backend's builder now
imports from here directly.
"""

from __future__ import annotations

import logging
from typing import Any

from .predicates import evaluate_availability

logger = logging.getLogger(__name__)


COMPONENT_NAME_ATTR = "_agentflow_component_name"


def filter_by_availability(
    items: list[Any],
    predicates: dict[str, str] | None,
    build_state: dict[str, Any] | None,
) -> list[Any]:
    """Return ``items`` with predicate-gated entries removed.

    Args:
        items: List of backend-native tool / function / MCP-server
            objects produced by an ``agentflow.<backend>.genui``
            adapter. Each genui-derived item carries a
            ``_agentflow_component_name`` attribute holding the
            Pydantic component class name.
        predicates: ``{ComponentClassName: predicate_expression}``.
            ``None`` or empty → return ``items`` unchanged. Class
            names with no matching item are silently ignored (a
            predicate can outlast the component it gated).
        build_state: State the predicates evaluate against. ``None``
            is treated as an empty dict — any ``state.X``-style
            predicate then resolves falsy, so all gated items are
            hidden. This is the fail-safe default.

    Returns:
        ``items`` with falsy-predicate entries removed. Items without
        a ``_agentflow_component_name`` attribute (plain plugin tools,
        MCP tools, anything not produced by ``@ui_component``) always
        pass through — predicates only target ``ui_tools``.

    Side effects:
        Logs one INFO line per filtered item so operators see why the
        bound tool surface differs from the YAML.
    """
    if not predicates or not items:
        return items

    filtered: list[Any] = []
    for item in items:
        component_name = getattr(item, COMPONENT_NAME_ATTR, None)
        predicate = predicates.get(component_name) if component_name else None

        if predicate is None:
            filtered.append(item)
            continue

        if evaluate_availability(predicate, build_state):
            filtered.append(item)
        else:
            logger.info(
                "available_when excluded %r at build time (predicate=%r)",
                component_name,
                predicate,
            )

    return filtered
