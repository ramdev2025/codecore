"""YAML schemas for cross-backend AG-UI vocabularies.

This is the *one* schema definition. Each backend's YAML config
(``agentflow.maf.core.config_models.MafAgentConfig``,
``agentflow.workflows.core.config_models.AgentConfig``, etc.)
references these models for their ``ui_tools`` / ``client_tools``
fields, so the same YAML works on every supporting backend.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class UIToolsConfig(BaseModel):
    """Declares a module of ``@ui_component``-decorated fetchers.

    Each fetcher becomes a tool the agent can call. The tool name is the
    component class name (``cls.__name__``); the tool description is the
    fetcher's docstring (per backend conventions).

    Backends provide their own resolution: workflows wraps each fetcher
    in a LangChain ``StructuredTool``; MAF wraps in an ``@tool``-decorated
    function whose return uses ``agent_framework_ag_ui.state_update`` to
    emit both LLM-side text and a frontend render event. Same input
    fetcher, different wrapper.

    Example (YAML)::

        agent:
          ui_tools:
            module: my_app.components
            use:
              - PortfolioOverview
              - PositionTable
    """

    module: str = Field(
        ...,
        description=(
            "Dotted Python module path containing @ui_component fetchers "
            "(e.g. ``my_app.components``). The module must be importable "
            "from the runtime's sys.path."
        ),
    )

    use: list[str] | None = Field(
        default=None,
        description=(
            "Optional allow-list of component class names to expose. If "
            "unset, every @ui_component fetcher in the module is exposed. "
            "Class names that don't exist in the module raise a clear "
            "error at resolution time."
        ),
    )


class ClientToolConfig(BaseModel):
    """Frontend-implemented tool exposed to the agent over AG-UI.

    Cross-backend YAML schema. **Enforcement is workflows-only today.**
    On workflows, each entry becomes a stub whose body calls
    ``langgraph.types.interrupt(...)``; the AG-UI bridge surfaces the
    pause to the browser, which runs the tool and posts the result
    back. On MAF, frontend tools come from CopilotKit's per-request
    ``RunAgentInput.tools[]`` — there's nothing for AgentFlow to bind,
    so this schema is a no-op there. On SK / CAS / OAI / ADK,
    declaring ``client_tools`` is documented as a gap until upstream
    bridges land.

    Example::

        client_tools:
          - name: openSecFiling
            description: Open the SEC EDGAR filings page for a ticker.
            parameters:
              type: object
              properties:
                ticker: { type: string }
              required: [ticker]
            available_when: "state.user_role != 'guest'"
    """

    name: str = Field(..., description="Tool name (what the agent calls).")
    description: str = Field(..., description="Tool description visible to the LLM.")
    parameters: dict[str, Any] = Field(
        default_factory=lambda: {"type": "object", "properties": {}, "required": []},
        description="JSON Schema for tool args. Mirrors AG-UI's Tool.parameters shape.",
    )
    available_when: str | None = Field(
        None,
        description=(
            "Optional ``simpleeval`` expression. When falsy, the tool is "
            "filtered from the agent's tool list for that LLM turn "
            "(workflows: per-call dynamic; other backends: build-time "
            "only). Available names: ``state``. "
            "Example: ``\"state.user_role == 'admin'\"``."
        ),
    )
