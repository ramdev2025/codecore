"""Module-scoped discovery for ``@ui_component`` fetchers.

Given a module path (the one declared in YAML as ``ui_tools.module``),
walk its top-level attributes and collect every callable decorated with
``@ui_component``. Returns a mapping keyed by the component class name —
the same string used as the tool name advertised to the LLM.
"""

from __future__ import annotations

import importlib
import inspect
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from .decorator import UI_COMPONENT_CLASS_ATTR


def discover_ui_components(module_path: str) -> dict[str, Callable[..., Any]]:
    """Find every ``@ui_component``-decorated function in ``module_path``.

    Walks the module's top-level attributes (no recursion into submodules
    or nested classes — keep this predictable). Class names must be
    unique within the module; two fetchers for the same component class
    is a configuration error.

    Args:
        module_path: A dotted Python module path (e.g. ``"myapp.components"``).
            Resolved via :func:`importlib.import_module`.

    Returns:
        A dict mapping the component class name (``cls.__name__``) to
        the fetcher function. Empty if the module has no decorated
        functions.

    Raises:
        ModuleNotFoundError: If ``module_path`` can't be imported.
        ValueError: If two fetchers target the same component class.
    """
    module = importlib.import_module(module_path)
    found: dict[str, Callable[..., Any]] = {}

    for _name, obj in inspect.getmembers(module):
        if not callable(obj):
            continue
        cls = getattr(obj, UI_COMPONENT_CLASS_ATTR, None)
        if cls is None:
            continue
        cls_name = cls.__name__
        if cls_name in found:
            raise ValueError(
                f"Module {module_path!r} declares two @ui_component fetchers "
                f"for class {cls_name!r} — only one fetcher per class is allowed."
            )
        found[cls_name] = obj

    return found


def get_component_class(fn: Callable[..., Any]) -> type[BaseModel] | None:
    """Return the Pydantic component class attached to ``fn``, or None.

    Use this when you have a callable and want to know whether it's a
    ``@ui_component`` fetcher without re-scanning the whole module.
    """
    return getattr(fn, UI_COMPONENT_CLASS_ATTR, None)
