"""Framework-agnostic predicate evaluation for ``available_when``.

A YAML user writes a small expression — e.g.
``"state.user_role == 'manager'"`` — and gets back a tool that is
visible to the LLM only when the predicate is true against the current
agent state. The predicate itself doesn't care which backend evaluates
it; each backend's adapter wires this evaluator into its own native
middleware/filter primitive.

Why a separate module
---------------------

Putting the evaluator in ``agentflow.genui`` rather than in any single
backend keeps the harness story honest: AgentFlow ships the YAML
vocabulary and the evaluator; each backend translates that into the
framework's native filtering primitive. Workflows uses LangChain
``AgentMiddleware.wrap_model_call``; MAF uses ``ChatMiddleware``; SK
uses kernel filters. Same expression, three attachments.

Sandboxing
----------

Predicates run through :mod:`simpleeval` — a guarded Python expression
evaluator. No imports, no attribute access on arbitrary objects, no
function calls beyond a small whitelist. The only name bound in the
expression environment is ``state``, a :class:`DotDict` wrapper over
the current agent state dict.

Fail-closed semantics
---------------------

A predicate that raises (typo, missing field, expression error) is
treated as **false** — the gated tool is hidden, not exposed. A
predicate failure must never accidentally surface a privileged tool.

Expression syntax notes
-----------------------

The default ``simpleeval`` sandbox supports most Python operators
including ``and`` / ``or`` / ``not``, comparisons, arithmetic, and
attribute access on the bound names. It does **not** support tuple,
list, or set literals — so ``state.tier in ('pro', 'enterprise')``
would fail closed. Use an ``or``-chain instead::

    "state.tier == 'pro' or state.tier == 'enterprise'"
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class DotDict:
    """Tiny wrapper exposing dict access as dotted attributes.

    Used inside ``available_when`` predicates so a user can write
    ``state.user_role`` instead of ``state['user_role']``. Returns a
    fresh wrapper for nested dict values so chained access
    (``state.session.kyc_complete``) keeps working.

    Missing keys return ``None``, not ``KeyError`` — so
    ``state.never_set == 'manager'`` evaluates to ``False`` rather
    than raising. (Predicate failures fail-closed anyway, but having
    sensible default-None semantics means common typos still produce
    the safe falsy result.)
    """

    __slots__ = ("_data",)

    def __init__(self, data: Any) -> None:
        object.__setattr__(self, "_data", data if isinstance(data, dict) else {})

    def __getattr__(self, name: str) -> Any:
        value = self._data.get(name)
        if isinstance(value, dict):
            return DotDict(value)
        return value

    def __getitem__(self, key: str) -> Any:
        return self.__getattr__(key)

    def __contains__(self, key: object) -> bool:
        return key in self._data

    def __bool__(self) -> bool:
        return bool(self._data)

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, DotDict):
            return self._data == other._data
        return self._data == other

    def __ne__(self, other: Any) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        return f"DotDict({self._data!r})"


def evaluate_availability(rule: str, state: dict[str, Any] | None) -> bool:
    """Evaluate an ``available_when`` expression.

    Args:
        rule: A :mod:`simpleeval`-compatible expression. The only name
            bound is ``state`` (a :class:`DotDict` over the supplied
            mapping). Examples::

                "state.user_role == 'manager'"
                "state.session.kyc_complete and state.market_hours"
                "state.account_tier in ('pro', 'enterprise')"

        state: Current agent state as a plain dict, or ``None``.
            ``None`` is treated as an empty dict — all
            ``state.X`` accesses resolve to ``None``.

    Returns:
        ``True`` if the expression evaluates to a truthy value with
        ``state`` bound; ``False`` on any error or falsy result.

    Notes:
        * Fail-closed. A broken predicate hides the tool. The
          security/UX contract is that a typo cannot accidentally
          leak a privileged tool to the wrong user.
        * Logs each evaluation failure at WARNING with the rule
          string so operators see typos in their YAML quickly.
    """
    try:
        from simpleeval import SimpleEval
    except ImportError:  # pragma: no cover — declared in base deps
        logger.warning(
            "available_when ignored: 'simpleeval' is not installed. "
            "Install agentflow base deps to enable conditional tool availability."
        )
        return True  # fail-open *only* when the evaluator itself is missing —
        # that's a deployment misconfiguration, not a predicate failure, and
        # silently hiding every gated tool with no logged signal would be worse.

    evaluator = SimpleEval(names={"state": DotDict(state or {})})
    try:
        return bool(evaluator.eval(rule))
    except Exception:
        logger.warning(
            "available_when predicate raised — hiding the gated tool. rule=%r",
            rule,
            exc_info=True,
        )
        return False
