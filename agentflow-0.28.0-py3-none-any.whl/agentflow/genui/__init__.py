"""Framework-agnostic generative-UI primitives.

This package owns the parts of AG-UI-style generative UI that don't depend
on any agent framework: the ``@ui_component`` decorator, module-scanning
discovery, the YAML schema for ``ui_tools``. Each backend's AG-UI
integration imports from here and provides its own thin wrapper that
turns a fetcher into a backend-native tool.

The same YAML works on every backend that wires this up::

    agent:
      ui_tools:
        module: components
        use:
          - PortfolioOverview
          - PositionTable

And the same Python decoration::

    from agentflow.genui import ui_component
    from pydantic import BaseModel

    class PortfolioOverview(BaseModel):
        aum_usd: int
        ytd_return_pct: float

    @ui_component(PortfolioOverview)
    def get_portfolio_overview() -> PortfolioOverview:
        return PortfolioOverview(aum_usd=42_000_000, ytd_return_pct=8.4)

What this module does not do
----------------------------

* No agent runtime. No tool *binding* — that's the job of each backend's
  integration (e.g. ``agentflow.maf.genui`` wraps for the MAF tool
  factory; ``agentflow.workflows.genui`` would do the LangChain wrapping
  when that integration lands).
* No event emission. The wire shape for the rendered component is the
  backend integration's responsibility (workflows: ``__component__``
  marker on the tool result; MAF: ``state_update(tool_result={...})``).
* No HTTP / SSE. Bridges own that.
"""

from .availability import COMPONENT_NAME_ATTR, filter_by_availability
from .config_models import ClientToolConfig, UIToolsConfig
from .decorator import UI_COMPONENT_CLASS_ATTR, ui_component
from .predicates import DotDict, evaluate_availability
from .registry import discover_ui_components, get_component_class

__all__ = [
    "COMPONENT_NAME_ATTR",
    "ClientToolConfig",
    "DotDict",
    "UI_COMPONENT_CLASS_ATTR",
    "UIToolsConfig",
    "discover_ui_components",
    "evaluate_availability",
    "filter_by_availability",
    "get_component_class",
    "ui_component",
]
