"""The ``@ui_component`` decorator.

Marks a function as a generative-UI fetcher for a Pydantic component
class. The decorator is data — it only attaches the class as an
attribute on the function. The actual binding (turning the decorated
function into a tool the agent can call) is the per-backend integration's
job; this module just owns the convention so every backend sees the
same shape.

Per the harness-configurator framing: AgentFlow doesn't reinvent each
framework's tool-binding mechanics. It provides the YAML and Python
patterns, then hands typed-and-validated fetchers to each framework's
native tool factory.
"""

from __future__ import annotations

from typing import Any, Callable, Type, TypeVar

from pydantic import BaseModel

UI_COMPONENT_CLASS_ATTR = "__agentflow_ui_component_class__"

_F = TypeVar("_F", bound=Callable[..., Any])


def ui_component(cls: Type[BaseModel]) -> Callable[[_F], _F]:
    """Mark ``fn`` as the fetcher for the Pydantic component class ``cls``.

    Use::

        from pydantic import BaseModel
        from agentflow.genui import ui_component

        class WeatherCard(BaseModel):
            city: str
            temp_f: float

        @ui_component(WeatherCard)
        def get_weather(city: str) -> WeatherCard:
            return WeatherCard(city=city, temp_f=72.0)

    The decorated function's return value is expected to be a ``cls``
    instance (or a dict that validates against ``cls`` — backend
    integrations may relax this). The component class's name becomes the
    tool name advertised to the LLM.

    Args:
        cls: A Pydantic ``BaseModel`` subclass declaring the component's
            props. The class itself is attached to the function as
            ``__agentflow_ui_component_class__`` for downstream readers.

    Returns:
        A decorator that returns the function unchanged with the
        component-class attribute set.

    Raises:
        TypeError: If ``cls`` is not a ``BaseModel`` *subclass*. Common
            mistake: passing a ``BaseModel`` *instance* (e.g.
            ``@ui_component(WeatherCard(city="...", temp_f=0))``) — the
            decorator wants the class, not an instance.
    """
    if not (isinstance(cls, type) and issubclass(cls, BaseModel)):
        raise TypeError(
            "ui_component requires a Pydantic BaseModel subclass, got "
            f"{cls!r} (type={type(cls).__name__}). If you passed an instance, "
            "use the class instead."
        )

    def decorator(fn: _F) -> _F:
        setattr(fn, UI_COMPONENT_CLASS_ATTR, cls)
        return fn

    return decorator
