"""Cross-backend YAML migration analyzer.

Reads a source YAML config and a target backend, classifies each feature
as portable / translatable / ambiguous / lossy, and surfaces the target
backend's decision points so the migration skill can interview the user.

Per-backend capability data lives at ``src/agentflow/<backend>/conversion/``.
"""

from agentflow.conversion._models import (
    BACKEND_KEY_TO_DIR,
    Capability,
    Feature,
    Mode,
    capability_path,
    load_capability,
)

__all__ = [
    "BACKEND_KEY_TO_DIR",
    "Capability",
    "Feature",
    "Mode",
    "capability_path",
    "load_capability",
]
