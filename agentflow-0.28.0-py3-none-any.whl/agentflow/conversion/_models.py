"""Pydantic models for capability files.

Why Pydantic here and not for translation-rules:

- `capabilities.yaml` is consumed by analyzer, validator, and the migration
  skill. It has a stable, well-defined schema. Typed access catches typos
  (`yaml_key` vs `yaml_keys`) at load time and gives tooling autocomplete.
- `translation-rules.yaml` is more freeform — sections vary across backends
  (sk has plugin_types, cas has hooks/permissions/sandbox, maf has
  edge_kinds). Modeling it strictly would either grow a 500-line union or
  forfeit the typing benefit. Left as raw dict access.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Union

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator

# ---------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------

#: Mapping from the YAML `backend:` field (and short aliases) to per-backend
#: directory names under `migration/`.
BACKEND_KEY_TO_DIR: dict[str, str] = {
    "workflows": "workflows",
    "deep": "deep",
    "semantic-kernel": "sk",
    "claude-agent-sdk": "cas",
    "openai-agents": "oai",
    "agent-framework": "maf",
    "adk": "adk",
    "sk": "sk",
    "cas": "cas",
    "oai": "oai",
    "maf": "maf",
}


#: Root of the agentflow package (parent of `conversion/`). Per-backend
#: conversion data lives at ``<AGENTFLOW_ROOT>/<backend>/conversion/``.
AGENTFLOW_ROOT = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------
# Capability file schema (Pydantic)
# ---------------------------------------------------------------------

#: Support flag — bool, "partial", or list of supported sub-values.
#: A list means the feature is supported but parameterised — e.g.,
#: `supported: [openai, anthropic, ...]` lists the supported LLM providers.
SupportFlag = Union[bool, Literal["partial"], list[str]]


class YamlMarker(BaseModel):
    """How to detect this backend's YAML shape (top-level keys + discriminators)."""

    required_keys: list[str] = Field(default_factory=list)
    optional_keys: list[str] = Field(default_factory=list)
    required_when: list[str] = Field(default_factory=list)
    detection: str | None = None

    model_config = ConfigDict(extra="allow")


class Mode(BaseModel):
    """One mode of a multi-mode backend (workflows standalone/orchestrated, sk's six modes, maf agent/workflow)."""

    supported: bool = True
    yaml_marker: str | None = None
    description: str | None = None
    yaml_keys: list[str] | None = None
    notes: str | None = None

    model_config = ConfigDict(extra="allow")


class Feature(BaseModel):
    """One feature of a backend.

    `yaml_key` (singular) and `yaml_keys` (plural list or dict) are *both*
    accepted — capability files use whichever fits the feature better. The
    analyzer/validator collect candidates from both.
    """

    supported: SupportFlag
    yaml_key: str | None = None
    yaml_keys: list[str] | dict[str, str] | None = None
    auto_enabled: bool = False
    only_in_mode: str | list[str] | None = None
    notes: str | None = None
    cli_flag: str | None = None
    cli_flags: list[str] | None = None
    mechanism: str | None = None

    # Allow per-feature extension (e.g., sk's `plugin_types`, cas's `sdk_hook_events`).
    model_config = ConfigDict(extra="allow")

    @field_validator("yaml_keys")
    @classmethod
    def _validate_yaml_keys_shape(cls, v: Any) -> Any:
        if v is None:
            return v
        if isinstance(v, list):
            if not all(isinstance(item, str) for item in v):
                raise ValueError("yaml_keys list entries must all be strings")
            return v
        if isinstance(v, dict):
            if not all(isinstance(k, str) and isinstance(val, str) for k, val in v.items()):
                raise ValueError("yaml_keys dict entries must all map str → str")
            return v
        raise ValueError(f"yaml_keys must be list or dict, got {type(v).__name__}")


class DecisionPoint(BaseModel):
    """A question the migration skill asks when migrating *into* this backend."""

    id: str
    when: str | None = None
    question: str
    options: list[str] = Field(default_factory=list)
    default_recommendation: str | None = None
    rationale: str | None = None

    model_config = ConfigDict(extra="allow")


class LossyItem(BaseModel):
    """A feature that doesn't survive when migrating *away from* this backend."""

    feature: str
    note: str

    model_config = ConfigDict(extra="allow")


class Simplification(BaseModel):
    """A target-builtin that can replace source custom code.

    Surfaces only when the user is migrating *into* this backend AND the
    source project matches the `when` heuristic. The skill asks the user
    whether to swap; if yes, the source's custom code (tool / middleware /
    callback / executor) is dropped from the output and the target's
    builtin is wired in instead.
    """

    id: str
    when: str
    suggestion: str
    rationale: str | None = None
    target_yaml_form: str | None = None
    drops_source_files: list[str] = Field(default_factory=list)  # globs
    drops_dependencies: list[str] = Field(default_factory=list)  # pip names

    model_config = ConfigDict(extra="allow")


class Capability(BaseModel):
    """The full capability declaration for a backend."""

    backend: str
    display_name: str
    yaml_marker: YamlMarker | None = None
    modes: dict[str, Mode] = Field(default_factory=dict)
    features: dict[str, Feature] = Field(default_factory=dict)
    decision_points: list[DecisionPoint] = Field(default_factory=list)
    simplifications: list[Simplification] = Field(default_factory=list)

    # `lossy_when_migrating_from_<backend>` — dynamic top-level key. Stored
    # as a separate dict by load_capability(); not modelled directly here.

    model_config = ConfigDict(extra="allow")

    # Convenience accessors --------------------------------------------------

    def feature_yaml_key_candidates(self, feature_name: str) -> list[str]:
        """Collect all yaml-key path candidates for a feature (yaml_key + yaml_keys)."""
        feature = self.features.get(feature_name)
        if feature is None:
            return []
        candidates: list[str] = []
        if feature.yaml_key:
            candidates.append(feature.yaml_key)
        if isinstance(feature.yaml_keys, list):
            candidates.extend(feature.yaml_keys)
        elif isinstance(feature.yaml_keys, dict):
            candidates.extend(feature.yaml_keys.values())
        return candidates

    def auto_enabled_features(self) -> dict[str, Feature]:
        return {name: f for name, f in self.features.items() if f.auto_enabled}

    def lossy_when_leaving(self, raw: dict[str, Any]) -> list[LossyItem]:
        """Read `lossy_when_migrating_from_<self.backend>` from the raw dict."""
        key = f"lossy_when_migrating_from_{self.backend}"
        items = raw.get(key) or []
        return [LossyItem.model_validate(item) for item in items if isinstance(item, dict)]


# ---------------------------------------------------------------------
# Loader helpers
# ---------------------------------------------------------------------


def backend_dir(backend: str) -> Path:
    """Return the per-backend `conversion/` folder under `src/agentflow/`."""
    return AGENTFLOW_ROOT / BACKEND_KEY_TO_DIR.get(backend, backend) / "conversion"


def capability_path(backend: str) -> Path:
    return backend_dir(backend) / "capabilities.yaml"


def samples_dir(backend: str) -> Path:
    return backend_dir(backend) / "samples"


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"missing file: {path}")
    with open(path) as fh:
        return yaml.safe_load(fh) or {}


def load_capability(backend: str) -> tuple[Capability, dict[str, Any]]:
    """Load capabilities.yaml as a Pydantic model AND raw dict.

    The raw dict is returned alongside so callers can read dynamic keys
    like `lossy_when_migrating_from_<backend>` that the model doesn't
    declare statically.
    """
    raw = _load_yaml(capability_path(backend))
    return Capability.model_validate(raw), raw


def load_translation_rules(backend: str) -> dict[str, Any]:
    return _load_yaml(translation_rules_path(backend))


def load_pattern_catalog(backend: str) -> dict[str, Any]:
    """Pattern-catalog files may not exist for every backend yet — caller decides."""
    return _load_yaml(pattern_catalog_path(backend))


@dataclass
class BackendBundle:
    """All assets for one backend, loaded together for the migration skill."""

    backend: str
    dir: Path
    capability: Capability
    capability_raw: dict[str, Any]
    translation_rules: dict[str, Any]
    pattern_catalog: dict[str, Any] | None = None    # None when not yet authored


def load_backend(backend: str, *, require_patterns: bool = False) -> BackendBundle:
    """One-stop loader for a backend's bundle (capabilities + translation-rules + patterns).

    Set `require_patterns=True` to fail when pattern-catalog.yaml is missing
    (relevant once every backend has one). Defaults to permissive so the
    migration skill works during the rollout.
    """
    cap, raw = load_capability(backend)
    rules = load_translation_rules(backend)
    patterns: dict[str, Any] | None
    try:
        patterns = load_pattern_catalog(backend)
    except FileNotFoundError:
        if require_patterns:
            raise
        patterns = None
    return BackendBundle(
        backend=BACKEND_KEY_TO_DIR.get(backend, backend),
        dir=backend_dir(backend),
        capability=cap,
        capability_raw=raw,
        translation_rules=rules,
        pattern_catalog=patterns,
    )
