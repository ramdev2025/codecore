"""Migration analyzer (experimental).

Standalone prototype for cross-backend YAML migration analysis. Not yet
integrated into the agentflow CLI — lives here so the logic can be
iterated on against the sample YAMLs without touching the package.

Reads a source YAML config and a target backend, classifies features
into:

  * portable                — supported in both, same yaml_key
  * translatable            — supported in both, different yaml_key
  * ambiguous               — partial support in either; target's decision
                              points apply
  * lossy                   — used by source, not supported by target
  * behavioural-additions   — auto_enabled by target, source had no opinion

Emits the target's full decision_points list (the migration skill picks
which ones apply at interview time) and the source's lossy_when_leaving
warnings.

Usage:
    python migration-experiment/analyzer.py \\
        --yaml migration-experiment/samples/workflows-orchestrated.yaml \\
        --target-backend deep
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

# Pydantic-backed loaders + path helpers live in _models.py so that the
# validator and the migration skill can share them.
from agentflow.conversion._models import (
    BACKEND_KEY_TO_DIR as BACKEND_KEY_TO_CAPABILITY,  # alias for backward compat
    capability_path,
    load_capability as _load_capability,
)


# ---------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------


@dataclass
class FeatureMapping:
    feature: str
    category: str
    source_yaml_key: Optional[str] = None
    target_yaml_key: Optional[str] = None
    note: Optional[str] = None


@dataclass
class AnalyzerReport:
    source_yaml: str
    source_backend: str
    target_backend: str
    source_mode: Optional[str] = None
    target_mode: Optional[str] = None
    portable: list[FeatureMapping] = field(default_factory=list)
    translatable: list[FeatureMapping] = field(default_factory=list)
    ambiguous: list[FeatureMapping] = field(default_factory=list)
    lossy: list[FeatureMapping] = field(default_factory=list)
    behavioural_additions: list[FeatureMapping] = field(default_factory=list)
    decision_points: list[dict] = field(default_factory=list)
    lossy_when_leaving: list[dict] = field(default_factory=list)
    simplifications: list[dict] = field(default_factory=list)


# ---------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------


def load_capability(backend: str) -> dict:
    """Return the raw capability dict.

    Internally validates against the Pydantic Capability model (raising
    if the YAML is malformed), but keeps returning the raw dict so the
    rest of the analyzer code path (which iterates dynamic keys) is
    unaffected by the migration to typed loading.
    """
    _, raw = _load_capability(backend)
    return raw


def detect_source_backend(source_yaml: dict) -> str:
    explicit = source_yaml.get("backend")
    if explicit:
        normalized = BACKEND_KEY_TO_CAPABILITY.get(explicit)
        if normalized:
            return normalized
        raise ValueError(f"Unknown backend '{explicit}'")

    # Backendless YAMLs are workflows or deep.
    # Workflows orchestrated mode is unambiguous.
    if "orchestrator" in source_yaml or "nodes" in source_yaml:
        return "workflows"

    agent = source_yaml.get("agent")
    has_top_llm = "llm" in source_yaml
    agent_has_nested_llm = isinstance(agent, dict) and "llm" in agent
    has_subagents = "subagents" in source_yaml

    # Deep: agent.llm is nested (no top-level llm), or a subagents block is present.
    if agent_has_nested_llm and not has_top_llm:
        return "deep"
    if has_subagents and not has_top_llm:
        return "deep"

    # Workflows standalone: top-level llm: with an agent: block.
    if has_top_llm and (agent or "agents" in source_yaml):
        return "workflows"
    if has_top_llm:
        return "workflows"

    raise ValueError(
        "Cannot detect source backend: no `backend:` field and no recognisable shape."
    )


# ---------------------------------------------------------------------
# Source YAML inspection
# ---------------------------------------------------------------------


def _tokenize(path: str) -> list[str]:
    """Split a path into segments, preserving bracket groups as single tokens.

    Examples:
      "agents[*].handoffs"     -> ["agents", "[*]", "handoffs"]
      "nodes.<name>.tools"     -> ["nodes", "<name>", "tools"]
      "middleware[type=hitl]"  -> ["middleware", "[type=hitl]"]
    """
    tokens: list[str] = []
    buf = ""
    i = 0
    while i < len(path):
        ch = path[i]
        if ch == ".":
            if buf:
                tokens.append(buf)
                buf = ""
        elif ch == "[":
            if buf:
                tokens.append(buf)
                buf = ""
            end = path.index("]", i)
            tokens.append(path[i : end + 1])
            i = end
        else:
            buf += ch
        i += 1
    if buf:
        tokens.append(buf)
    return tokens


def _resolve(data: Any, path: str) -> list[Any]:
    """Resolve a path with wildcards into a list of matched values.

    Supported segments:
      - literal key            "agents"
      - placeholder            "<name>" matches any key at the current level
      - list wildcard          "[*]" iterates list items (or dict values)
      - filter                 "[key=value]" matches items where item[key] == value
    """
    if path is None or data is None:
        return []

    current: list[Any] = [data]
    for token in _tokenize(path):
        nxt: list[Any] = []
        for cur in current:
            if cur is None:
                continue
            if token.startswith("<") and token.endswith(">"):
                if isinstance(cur, dict):
                    nxt.extend(cur.values())
            elif token == "[*]":
                if isinstance(cur, list):
                    nxt.extend(cur)
                elif isinstance(cur, dict):
                    nxt.extend(cur.values())
            elif token.startswith("[") and token.endswith("]") and "=" in token:
                k, _, v = token[1:-1].partition("=")
                v_norm = v.strip().lower()
                items = cur.values() if isinstance(cur, dict) else cur if isinstance(cur, list) else []
                nxt.extend(
                    item for item in items
                    if isinstance(item, dict) and str(item.get(k)).lower() == v_norm
                )
            else:
                if isinstance(cur, dict) and token in cur:
                    nxt.append(cur[token])
        current = nxt
    return current


def _yaml_key_candidates(feature_def: dict) -> list[str]:
    """Collect yaml-key path candidates from yaml_key (singular) and yaml_keys (plural).

    Capability files use either form, sometimes both. yaml_keys may be a list
    (multiple equivalent paths) or a dict-of-mode-to-path (e.g., sk's
    {standalone: agent.tools, orchestrated: nodes.<name>.tools}).
    """
    candidates: list[str] = []
    yaml_key = feature_def.get("yaml_key")
    yaml_keys = feature_def.get("yaml_keys")
    if isinstance(yaml_key, str):
        candidates.append(yaml_key)
    elif isinstance(yaml_key, list):
        candidates.extend(k for k in yaml_key if isinstance(k, str))
    if isinstance(yaml_keys, list):
        candidates.extend(k for k in yaml_keys if isinstance(k, str))
    elif isinstance(yaml_keys, dict):
        candidates.extend(v for v in yaml_keys.values() if isinstance(v, str))
    return candidates


def feature_used_in_source(feature_def: dict, source_yaml: dict) -> bool:
    """Whether any declared yaml-key path resolves to a populated value."""
    candidates = _yaml_key_candidates(feature_def)
    if not candidates:
        # Deployment concern (CLI-only) or undeclared. Not detectable in YAML.
        return False
    for k in candidates:
        for value in _resolve(source_yaml, k):
            if value not in (None, [], {}, ""):
                return True
    return False


def detect_source_mode(source_yaml: dict, source_cap: dict) -> Optional[str]:
    modes = source_cap.get("modes", {})
    if not modes:
        return None
    if len(modes) == 1:
        return next(iter(modes))

    # Explicit `mode:` field wins.
    explicit = source_yaml.get("mode")
    if explicit and explicit in modes:
        return explicit

    backend = source_cap.get("backend")
    if backend == "workflows":
        return "orchestrated" if "orchestrator" in source_yaml else "standalone"
    if backend == "maf":
        return "workflow" if "workflow" in source_yaml else "agent"
    if backend == "sk":
        # mode: handoff/sequential/group_chat/magentic/process — handled by `explicit` above.
        # Bare YAML with only `agent:` defaults to autonomous.
        if "agent" in source_yaml and "agents" not in source_yaml and "process" not in source_yaml:
            return "autonomous"

    return None


# ---------------------------------------------------------------------
# Categorization
# ---------------------------------------------------------------------


def _display_key(feature_def: dict) -> Optional[str]:
    """Pick a representative yaml-key for display (first candidate, or None)."""
    candidates = _yaml_key_candidates(feature_def)
    return candidates[0] if candidates else None


def categorize_feature(
    feature_name: str,
    source_feature: dict,
    target_feature: Optional[dict],
) -> FeatureMapping:
    src_yaml_key = _display_key(source_feature)
    src_supported = source_feature.get("supported")
    src_partial = src_supported == "partial"

    if target_feature is None:
        return FeatureMapping(
            feature=feature_name,
            category="lossy",
            source_yaml_key=src_yaml_key,
            note="Target backend has no declaration for this feature.",
        )

    tgt_supported = target_feature.get("supported")
    tgt_yaml_key = _display_key(target_feature)
    note = target_feature.get("notes")

    if tgt_supported is False:
        return FeatureMapping(
            feature=feature_name,
            category="lossy",
            source_yaml_key=src_yaml_key,
            target_yaml_key=tgt_yaml_key,
            note=note,
        )

    if tgt_supported == "partial" or src_partial:
        return FeatureMapping(
            feature=feature_name,
            category="ambiguous",
            source_yaml_key=src_yaml_key,
            target_yaml_key=tgt_yaml_key,
            note=note or "Partial support — see target's decision_points.",
        )

    if src_yaml_key == tgt_yaml_key and src_yaml_key is not None:
        return FeatureMapping(
            feature=feature_name,
            category="portable",
            source_yaml_key=src_yaml_key,
            target_yaml_key=tgt_yaml_key,
        )

    return FeatureMapping(
        feature=feature_name,
        category="translatable",
        source_yaml_key=src_yaml_key,
        target_yaml_key=tgt_yaml_key,
    )


def find_behavioural_additions(
    target_cap: dict, used_in_source: set[str]
) -> list[FeatureMapping]:
    additions = []
    for name, feature in target_cap.get("features", {}).items():
        if not feature.get("auto_enabled"):
            continue
        if name in used_in_source:
            continue
        additions.append(
            FeatureMapping(
                feature=name,
                category="behavioural-addition",
                target_yaml_key=_display_key(feature),
                note=feature.get("notes"),
            )
        )
    return additions


# ---------------------------------------------------------------------
# Analyze
# ---------------------------------------------------------------------


def analyze(source_yaml_path: str, target_backend: str) -> AnalyzerReport:
    with open(source_yaml_path) as fh:
        source_yaml = yaml.safe_load(fh)

    source_backend = detect_source_backend(source_yaml)

    if target_backend not in BACKEND_KEY_TO_CAPABILITY:
        raise ValueError(
            f"Unknown target backend '{target_backend}'. "
            f"Known: {sorted(set(BACKEND_KEY_TO_CAPABILITY.values()))}"
        )
    target_backend_norm = BACKEND_KEY_TO_CAPABILITY[target_backend]

    source_cap = load_capability(source_backend)
    target_cap = load_capability(target_backend_norm)

    source_mode = detect_source_mode(source_yaml, source_cap)
    target_modes = target_cap.get("modes", {}) or {}
    target_mode = next(iter(target_modes)) if len(target_modes) == 1 else None

    report = AnalyzerReport(
        source_yaml=source_yaml_path,
        source_backend=source_backend,
        target_backend=target_backend_norm,
        source_mode=source_mode,
        target_mode=target_mode,
    )

    source_features = source_cap.get("features", {}) or {}
    target_features = target_cap.get("features", {}) or {}

    used_in_source: set[str] = set()
    for name, src_feature in source_features.items():
        if src_feature.get("supported") is False:
            continue
        if not feature_used_in_source(src_feature, source_yaml):
            continue
        used_in_source.add(name)

        mapping = categorize_feature(name, src_feature, target_features.get(name))
        bucket = {
            "portable": report.portable,
            "translatable": report.translatable,
            "ambiguous": report.ambiguous,
            "lossy": report.lossy,
        }[mapping.category]
        bucket.append(mapping)

    report.behavioural_additions = find_behavioural_additions(target_cap, used_in_source)
    report.decision_points = target_cap.get("decision_points", []) or []
    report.lossy_when_leaving = (
        source_cap.get(f"lossy_when_migrating_from_{source_backend}", []) or []
    )
    report.simplifications = target_cap.get("simplifications", []) or []

    return report


# ---------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------


def _fmt_arrow(src: Optional[str], tgt: Optional[str]) -> str:
    if src and tgt and src != tgt:
        return f"   ({src} → {tgt})"
    if src:
        return f"   ({src})"
    if tgt:
        return f"   (→ {tgt})"
    return ""


def print_report(report: AnalyzerReport) -> None:
    print(f"agentflow analyze — {report.source_yaml} → {report.target_backend}")
    print()
    print(f"Source: {report.source_backend}", end="")
    if report.source_mode:
        print(f" / {report.source_mode}", end="")
    print()
    print(f"Target: {report.target_backend}", end="")
    if report.target_mode:
        print(f" / {report.target_mode}", end="")
    print()
    print()
    print(
        f"Summary: {len(report.portable)} portable · "
        f"{len(report.translatable)} translatable · "
        f"{len(report.ambiguous)} ambiguous · "
        f"{len(report.lossy)} lossy · "
        f"{len(report.behavioural_additions)} behavioural additions"
    )
    print()

    def _section(title: str, items: list[FeatureMapping]) -> None:
        if not items:
            return
        print(title)
        for it in items:
            print(f"  {it.feature}{_fmt_arrow(it.source_yaml_key, it.target_yaml_key)}")
            if it.note:
                first_line = it.note.strip().split("\n")[0]
                print(f"      {first_line}")
        print()

    _section("PORTABLE (transfers as-is)", report.portable)
    _section("TRANSLATABLE (mechanical key/structure rewrite)", report.translatable)
    _section("AMBIGUOUS (target has decision points)", report.ambiguous)
    _section("LOSSY (no equivalent in target)", report.lossy)
    _section("BEHAVIOURAL ADDITIONS (target auto-enables)", report.behavioural_additions)

    if report.decision_points:
        print(
            f"DECISION POINTS — questions the skill would ask "
            f"when migrating into {report.target_backend}:"
        )
        for dp in report.decision_points:
            print(f"  ? {dp.get('id', '(unnamed)')}")
            when = dp.get("when", "(always)")
            print(f"      when:    {when}")
            question = dp.get("question", "(no question)").strip().split("\n")[0]
            print(f"      asks:    {question}")
            if dp.get("default_recommendation"):
                print(f"      default: {dp['default_recommendation']}")
        print()

    if report.lossy_when_leaving:
        print(f"LOSSY WHEN LEAVING {report.source_backend} (warnings, regardless of target):")
        for item in report.lossy_when_leaving:
            print(f"  ! {item.get('feature', '?')}")
            note = (item.get("note") or "").strip().split("\n")[0]
            if note:
                print(f"      {note}")
        print()

    if report.simplifications:
        print(
            f"SIMPLIFICATIONS — target ({report.target_backend}) builtins that "
            f"could replace source custom code (skill applies on user OK):"
        )
        for s in report.simplifications:
            print(f"  + {s.get('id', '(unnamed)')}")
            when = (s.get("when") or "").strip().split("\n")[0]
            if when:
                print(f"      when:       {when}")
            suggestion = (s.get("suggestion") or "").strip().split("\n")[0]
            if suggestion:
                print(f"      suggestion: {suggestion}")
        print()


def report_to_dict(report: AnalyzerReport) -> dict:
    d = asdict(report)
    return d


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(description="Migration analyzer (experimental)")
    parser.add_argument("--yaml", required=True, help="Source YAML config to analyze")
    parser.add_argument("--target-backend", required=True, help="Target backend")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    try:
        report = analyze(args.yaml, args.target_backend)
    except (FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(report_to_dict(report), indent=2))
    else:
        print_report(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
