# AgentFlow — AI Assistant Context

You are assisting a user who is building an application with **AgentFlow**, a framework-independent, YAML-driven platform for configuring and running AI agent harnesses. It supports **seven backends** — installed as optional extras with a unified API and CLI:

| Backend | YAML `backend:` value | Built on |
| --- | --- | --- |
| `workflows` | `workflows` | LangGraph / LangChain — graph multi-agent |
| `deep` | `deep` *(alias: `deepagents`)* | DeepAgents — long-horizon agents |
| `sk` | `semantic-kernel` | Microsoft Semantic Kernel |
| `cas` | `claude-agent-sdk` | Anthropic Claude Agent SDK |
| `oai` | `openai-agents` | OpenAI Agents SDK |
| `maf` | `agent-framework` | Microsoft Agent Framework |
| `adk` | `adk` | Google Agent Development Kit |

**Every YAML config must declare its backend** via a top-level `backend:` field (the legacy "guess from structure" heuristic was removed in v0.20 — see *Common Pitfalls*). Pick one backend per virtual environment to keep dependency resolution clean.

## Quick Start

```bash
# Install from local wheel (always use the local .whl, never bare "agentflow" from PyPI)
pip install agentflow-*.whl[workflows]         # LangGraph multi-agent
pip install agentflow-*.whl[deep]              # DeepAgents (also accepts [deepagents])
pip install agentflow-*.whl[semantic-kernel]   # SK
pip install agentflow-*.whl[claude-agent-sdk]  # CAS
pip install agentflow-*.whl[openai-agents]     # OAI
pip install agentflow-*.whl[agent-framework]   # MAF
pip install agentflow-*.whl[adk]               # ADK (Google Agent Development Kit)
pip install agentflow-*.whl[adk-extensions]    # ADK + LiteLLM (OpenAI/Anthropic/Azure/...)

# Run from CLI (unified command — reads `backend:` from YAML)
agentflow "your query here"
agentflow --yaml agent.yaml "your query here"
agentflow --yaml workflow.yaml --backend workflows "..."   # override

# Or use the Python API (unified factory — reads `backend:` from YAML)
python -c "
import asyncio
import agentflow

async def main():
    runner = await agentflow.create('workflow.yaml', tools_module='tools')
    async for event in runner.run(
        {'messages': [{'role': 'user', 'content': 'your query'}]},
        config={'configurable': {'thread_id': 'session-1'}},
    ):
        print(event)

asyncio.run(main())
"
```

## Project Structure

A typical AgentFlow project looks like this:

```
my-project/
  workflow.yaml          # Agent/workflow definition (YAML)
  tools/                 # Business logic tools (@tool decorated)
    __init__.py          # Re-exports all @tool functions
    <domain>.py          # Domain-specific tool functions
  data/                  # Data files (JSON, CSV, MD) accessed via MCP
  agentflow-*.whl        # AgentFlow wheel (local dependency)
  requirements.txt       # Python deps (references the wheel)
  .env                   # API keys (ANTHROPIC_API_KEY, etc.)
```

## Workflows-backend YAML Schema

The schemas in this section are **specific to the `workflows` backend** (the LangGraph multi-agent harness). The other six backends each have their own YAML schema documented under `agentflow-{backend}-docs` (run `agentflow-docs --backend <backend>` to launch the per-backend docs site locally).

The `workflows` backend supports two modes. **Always default to standalone** unless there is an explicit need for orchestrated multi-agent pipelines.

### Standalone Agent (Default & Preferred)

A single tool-use ReAct agent that supports all AgentFlow middlewares. Handles even complex tasks through rich tool use. A standalone agent with 10-20 tools is simpler, more reliable, and cheaper than a multi-agent pipeline.

```yaml
backend: workflows                  # REQUIRED — see Common Pitfalls

metadata:
  version: "1.0"
  name: "My Agent"
  description: "What this agent does"

llm:
  provider: anthropic               # workflows is LLM-agnostic — anything LangChain supports
  config:
    model: "claude-sonnet-4-20250514"
    temperature: 0.7
    max_tokens: 4096

mcp_servers:
  project_data:
    transport: stdio
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-filesystem", "data/"]
    context: "All project data files — JSON entities, CSV reference data, documents"

agent:
  name: "My Agent"
  system_prompt: |
    You are a specialist agent. Use your tools to help users.
    Data is in data/ directory (JSON, CSV, MD files) — use MCP tools to read/write.
  tools:                            # Business logic from tools_module
    - calculate_score
    - classify_entity
    - format_report
  mcp_tools:                        # Data access via MCP servers
    - server: project_data
      tools: "*"
  middleware:
    - type: model_call_limit
      model_call_limit:
        run_limit: 15
    - type: tool_call_limit
      tool_call_limit:
        run_limit: 20

# Persistence is NOT configured in YAML. Choose the backend at deploy
# time via the --persistence CLI flag or the AGENTFLOW_PERSISTENCE /
# POSTGRES_CONNECTION_STRING / CHECKPOINTER_DB_PATH env vars. The same
# YAML runs unchanged in dev / staging / prod. See PERSISTENCE.md.
```

**Standalone rules:**
- `agent` section replaces `orchestrator`, `workflows`, and `nodes` — never include those
- `agent.system_prompt` is required
- `agent.tools` lists function names from the tools module
- `agent.mcp_tools` references servers from `mcp_servers`

### Orchestrated Multi-Agent (Only When Necessary)

Use only when requirements genuinely need distinct processing stages with different LLM configs or strict data pipelines.

```yaml
backend: workflows                  # REQUIRED — see Common Pitfalls

metadata:
  version: "1.0"
  name: "My Pipeline"

llm:
  provider: anthropic
  config:
    model: "claude-sonnet-4-20250514"
    temperature: 0.7
    max_tokens: 4096

mcp_servers:
  project_data:
    transport: stdio
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-filesystem", "data/"]

orchestrator:
  workflows:
    - main_workflow

workflows:
  main_workflow:
    description: "Processing pipeline"
    nodes:
      intake:
        depends_on: []               # Entry point
      processor:
        depends_on: [intake]
      reporter:
        depends_on: [processor]
        routes:                      # Optional conditional routing
          router_field: status
          success: END
          default: fallback_node

nodes:
  intake:
    description: "Receive and classify input"
    system_prompt: |
      You classify incoming requests.
    tools:
      - classify_entity
    mcp_tools:
      - server: project_data
        tools: "*"
    middleware:
      - type: model_call_limit
        model_call_limit:
          run_limit: 10

  processor:
    description: "Process classified input"
    system_prompt: |
      You process classified data.
    tools:
      - calculate_score
```

**Orchestrated rules:**
- `orchestrator.workflows` lists at least one workflow name
- Every workflow name must have a matching key in `workflows`
- Every node in `workflows.*.nodes` must have a matching key in `nodes`
- At least one node per workflow must have `depends_on: []`
- No circular dependencies

## Tools (@tool Functions)

Tools contain **business logic only** — all data access goes through MCP servers.

```python
# tools/<domain>.py
import json
from langchain_core.tools import tool

@tool
def calculate_score(entity_id: str, factors: str) -> str:
    """Calculate a score for an entity based on provided factors.

    Args:
        entity_id: The entity to score.
        factors: JSON string with scoring factors and their values.
    """
    try:
        factor_data = json.loads(factors)
        score = sum(factor_data.values()) / len(factor_data)
        return json.dumps({"entity_id": entity_id, "score": round(score, 2)})
    except Exception as e:
        return json.dumps({"error": str(e)})
```

**Tool rules:**
- Docstrings are critical — AgentFlow shows them to the LLM
- Always return JSON strings
- Handle errors gracefully (return JSON, don't raise)
- Names in `workflow.yaml` must match function names exactly
- Re-export all tools in `tools/__init__.py`

## MCP Data Access

Data access is handled by MCP servers, not by tool functions:

```yaml
# workflow.yaml
mcp_servers:
  project_data:
    transport: stdio
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-filesystem", "data/"]
    context: "JSON entities, CSV reference data, documents"
```

The agent reads/writes files in `data/` using MCP filesystem tools. No need to write custom data access code.

## Middleware

Available middleware types (work in both standalone and orchestrated modes):

| Type | Purpose | Key config |
|------|---------|-----------|
| `model_call_limit` | Cap LLM calls per run | `run_limit: 15` |
| `tool_call_limit` | Cap tool calls per run | `run_limit: 20` |
| `summarization` | Summarize long conversations | `max_tokens` |
| `human_in_the_loop` | Require human approval | `tools: [tool_name]` |
| `tool_retry` | Auto-retry failed tools | `max_retries: 3` |
| `model_fallback` | Fallback to another model | `fallback_model` |

```yaml
# Middleware config format (inside agent: or nodes: section)
middleware:
  - type: model_call_limit
    model_call_limit:
      run_limit: 15
```

## Python API

```python
import agentflow

# Unified factory — reads `backend:` field from YAML and dispatches.
# Raises ValueError with a migration message if `backend:` is missing.
runner = await agentflow.create("workflow.yaml", tools_module="tools")

# For `workflows` backend: run returns an async event stream
async for event in runner.run(state, config=config):
    print(event)
await runner.cleanup()

# For `deep` backend: build returns an invocable agent
builder = await agentflow.create("agent.yaml")
agent = builder.build()
result = agent.invoke(input_dict, config=config)

# `sk` / `cas` / `oai` / `maf` backends return a Runner with .query() /
# .query_streamed() — each backend's docs cover the run shape.

# Read the backend value without instantiating a runner
backend = agentflow.detect_backend("workflow.yaml")   # → "workflows"

# Override the YAML's `backend:` field at call time
runner = await agentflow.create("workflow.yaml", backend="workflows")
```

### Streaming with FastAPI Integration

The `run()` method accepts a state dict and config dict, and returns an async generator when `stream_tokens=True`. This is the pattern to use in WebSocket handlers and streaming API endpoints:

```python
orch = await AsyncWorkflowOrchestrator.create(
    config_path="workflow.yaml",
    tools_module="tools",
)

# State contains the conversation messages, config contains the session ID
state = {"messages": [{"role": "user", "content": "my query"}]}
config = {"thread_id": "session-123"}

# Stream events for real-time UI updates
async for event in orch.run(state, config=config, stream_tokens=True):
    # event keys: type, workflow, name, content
    # type values: "agent", "tool", "token", "agent_start", "agent_end"
    if event.get("type") in ("token", "agent"):
        print(event.get("content", ""))
```

Use this pattern in `api/websocket_handler.py` to stream agent responses token-by-token to the React frontend via WebSocket.

## Common Pitfalls

- **Always declare `backend:` at the top of every YAML** — auto-detection from structure was removed in v0.20. A missing field raises `ValueError` with a migration recipe listing all six valid values. The `--backend` CLI flag and `backend=` API kwarg can override what's in the file but cannot substitute for it being absent. Aliases like `deepagents` → `deep` are normalized to canonical names automatically.
- **One backend per virtual environment** — installing multiple `[backend]` extras in the same venv can hit transitive version conflicts (e.g. `[agent-framework]` + `[claude-agent-sdk]` disagree on `claude-agent-sdk` pin).
- **Never use bare `agentflow` from PyPI** — always reference the local `.whl` file.
- **Never put data access in tools/** — use MCP servers for all file I/O.
- **Never create an `agents/` folder** — AgentFlow doesn't support custom agent modules.
- **Always include middleware limits** — prevent runaway LLM/tool calls.
- **Standalone is almost always the right choice** for `workflows` — even for complex multi-tool systems.
- **The wider `[workflows]` schema doesn't apply to `sk` / `cas` / `oai` / `maf` / `adk`** — those backends have their own YAML shape (different sections, different middleware / callback vocabulary). Refer to each backend's docs (`agentflow-docs --backend <name>`).
- **`adk`-specific gotchas:** the `agent.type` discriminator (`llm` / `sequential` / `parallel` / `loop`) defaults to `llm` if omitted. Workflow agents (`sequential` / `parallel` / `loop`) require non-empty `sub_agents`. The CLI auto-upgrades plain `sqlite:///` and `postgresql://` URLs to the async drivers ADK requires (`sqlite+aiosqlite`, `postgresql+asyncpg`).

## Detailed Reference

If `agentflow-reference.md` exists in this project, it contains the full API documentation extracted from the installed AgentFlow package. Consult it for detailed API signatures, advanced middleware configuration, and persistence options.
