"""``AdkAgentBuilder`` — translates ADK YAML into a runnable agent tree.

Two-pass tree build:

1. **First pass (post-order)** — descend the spec tree leaves-first; build
   each ``LlmAgent`` / workflow agent without resolving ``agent_as_tool``
   refs yet. Register every built agent in a name → object map so tool
   refs can find their target by name.
2. **Second pass (post-order again)** — walk the same tree, build each
   agent's ``AgentTool``-wrapped sibling tools, and re-attach those tools
   to the appropriate ``LlmAgent``.

The two-pass design avoids tracking forward references during the first
pass, while keeping a clean post-order so leaf agents are built before
their parents (parents need built children to satisfy ``sub_agents=[...]``).

The result is wrapped in an ``AdkRunner`` dataclass that:

- Holds the root ``BaseAgent`` plus a constructed ``Runner`` (lazy until
  ``query`` is called)
- Holds the resolved ``SessionService`` / ``ArtifactService`` /
  ``MemoryService`` / ``BasePlugin`` list
- Exposes ``query(prompt, *, user_id, session_id, thread_id)`` returning
  the ADK event stream — the CLI consumes this directly
- Exposes ``dry_run()`` returning a JSON-serializable summary

The builder never calls ``Runner.run_async`` — that's the runner's job.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional

import yaml

from agentflow.adk.core.callback_registry import resolve_callbacks
from agentflow.adk.core.config_models import (
    AdkYAMLConfig,
    AgentType,
    LlmAgentSpec,
    LoopAgentSpec,
    ParallelAgentSpec,
    SequentialAgentSpec,
)
from agentflow.adk.core.helpers import load_dotenv_for, resolve_env_vars
from agentflow.adk.core.mcp import resolve_mcp_refs
from agentflow.adk.core.plugin_registry import resolve_plugins
from agentflow.adk.core.service_factory import apply_env_side_effects, resolve_model
from agentflow.adk.core.tool_factory import (
    resolve_builtin_tools,
    resolve_code_executor,
    resolve_output_schema,
    resolve_planner,
)


@dataclass
class AdkRunner:
    """Built agent tree + the services needed to run it.

    Holds enough state for the CLI to either produce a dry-run summary or
    spin up an ADK ``Runner`` and stream events. ``Runner`` is constructed
    lazily on the first ``query`` call so dry-run paths skip the
    instantiation cost (and required SessionService).
    """

    config: AdkYAMLConfig
    root_agent: Any  # BaseAgent
    app_name: str

    session_service: Any = None
    artifact_service: Any = None
    memory_service: Any = None
    plugins: List[Any] = field(default_factory=list)

    _runner: Any = None

    def runner(self) -> Any:
        """Construct the SDK ``Runner`` on first access."""
        if self._runner is None:
            from google.adk.runners import Runner  # lazy

            kwargs: dict[str, Any] = {
                "app_name": self.app_name,
                "agent": self.root_agent,
                "session_service": self.session_service,
                "auto_create_session": True,
            }
            if self.artifact_service is not None:
                kwargs["artifact_service"] = self.artifact_service
            if self.memory_service is not None:
                kwargs["memory_service"] = self.memory_service
            if self.plugins:
                kwargs["plugins"] = self.plugins
            self._runner = Runner(**kwargs)
        return self._runner

    async def query(
        self,
        prompt: str,
        *,
        user_id: str = "default",
        session_id: str = "default",
    ) -> AsyncIterator[Any]:
        """Yield ADK events for one user turn. CLI converts these to UI."""
        from google.genai import types  # lazy

        runner = self.runner()
        new_message = types.Content(
            role="user", parts=[types.Part(text=prompt)]
        )
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=new_message,
        ):
            yield event

    def dry_run(self) -> Dict[str, Any]:
        """JSON-serializable summary of what would run."""

        def describe(agent_obj: Any, spec: Any) -> Dict[str, Any]:
            d: Dict[str, Any] = {
                "name": spec.name,
                "type": spec.type.value,
            }
            if isinstance(spec, LlmAgentSpec):
                d["instruction_chars"] = len(spec.instruction or "")
                d["model"] = (
                    spec.model
                    or (spec.llm.config.get("model") if spec.llm else None)
                    or (self.config.llm.config.get("model") if self.config.llm else None)
                )
                tool_count = (
                    len(spec.tools.builtin)
                    + len(spec.tools.plugins)
                    + len(spec.tools.agent_as_tool)
                    + len(spec.tools.mcp_servers)
                )
                d["tools"] = tool_count
                if spec.output_key:
                    d["output_key"] = spec.output_key
            if isinstance(spec, LoopAgentSpec) and spec.max_iterations:
                d["max_iterations"] = spec.max_iterations
            if getattr(spec, "sub_agents", None):
                d["sub_agents"] = [
                    describe(child_obj, child_spec)
                    for child_obj, child_spec in zip(
                        getattr(agent_obj, "sub_agents", []), spec.sub_agents
                    )
                ]
            return d

        return {
            "backend": "adk",
            "metadata": self.config.metadata.model_dump(exclude_none=True),
            "app_name": self.app_name,
            "root_agent": describe(self.root_agent, self.config.agent),
            "services": {
                "session": _describe_service(self.session_service),
                "artifact": _describe_service(self.artifact_service),
                "memory": _describe_service(self.memory_service),
                "plugins": [type(p).__name__ for p in self.plugins],
            },
            "serving": (
                self.config.serving.model_dump(exclude_none=True)
                if self.config.serving else None
            ),
        }


def _describe_service(svc: Any) -> Optional[str]:
    if svc is None:
        return None
    return type(svc).__name__


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------


class AdkAgentBuilder:
    """Translate ``AdkYAMLConfig`` into a runnable ``AdkRunner``."""

    def __init__(
        self,
        config: AdkYAMLConfig,
        *,
        yaml_path: Optional[str] = None,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ):
        self.config = config
        self.yaml_path = yaml_path
        # Build-time state for ``available_when`` predicate evaluation
        # of ``ui_tools``. ``None`` is treated as an empty dict — any
        # ``state.X`` predicate then resolves falsy, hiding all gated
        # tools (fail-safe default).
        self.build_state: Dict[str, Any] = build_state or {}
        # AG-UI router opt-in for client_tools. Off by default — CLI /
        # script callers never see them. Flipped on by
        # ``AsyncADKAGUIRuntime.create`` so the agent also carries the
        # ``ClientToolPause`` stubs.
        self.bind_client_tools: bool = bind_client_tools
        # Populated during build():
        self._agents_by_name: Dict[str, Any] = {}
        self._spec_by_name: Dict[str, Any] = {}

    # ----- entry points -----

    @classmethod
    def from_yaml(
        cls,
        yaml_path: str,
        *,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ) -> "AdkAgentBuilder":
        load_dotenv_for(yaml_path)
        with open(yaml_path) as f:
            data = yaml.safe_load(f)
        data = resolve_env_vars(data)
        config = AdkYAMLConfig.model_validate(data)
        return cls(
            config,
            yaml_path=yaml_path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    @classmethod
    def from_dict(
        cls,
        data: dict,
        *,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ) -> "AdkAgentBuilder":
        config = AdkYAMLConfig.model_validate(data)
        return cls(
            config,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    # ----- the build itself -----

    def build(self) -> AdkRunner:
        # Apply env side-effects from the top-level llm before constructing
        # any agent — ADK's Gemini client reads env at construction time.
        if self.config.llm is not None:
            _, env = resolve_model(self.config.llm)
            apply_env_side_effects(env)

        # Pass 1: build every agent without agent_as_tool refs.
        root = self._build_spec(self.config.agent)

        # Pass 2: wire agent_as_tool refs (each LlmAgent's tools list gets
        # extended with AgentTool wrappers for the named children).
        self._wire_agent_as_tool(self.config.agent)

        app_name = self.config.metadata.name or self.config.agent.name

        return AdkRunner(
            config=self.config,
            root_agent=root,
            app_name=app_name,
            session_service=self._build_session_service(),
            artifact_service=self._build_artifact_service(),
            memory_service=self._build_memory_service(),
            plugins=self._build_plugins(),
        )

    # ----- pass 1: build agents post-order -----

    def _build_spec(self, spec: Any) -> Any:
        """Build one agent spec recursively (children built first)."""
        children = [self._build_spec(c) for c in getattr(spec, "sub_agents", []) or []]

        if isinstance(spec, LlmAgentSpec):
            agent = self._build_llm_agent(spec, children)
        elif isinstance(spec, SequentialAgentSpec):
            from google.adk.agents import SequentialAgent  # lazy
            agent = SequentialAgent(
                name=spec.name,
                description=spec.description,
                sub_agents=children,
                **resolve_callbacks(spec.callbacks),
            )
        elif isinstance(spec, ParallelAgentSpec):
            from google.adk.agents import ParallelAgent  # lazy
            agent = ParallelAgent(
                name=spec.name,
                description=spec.description,
                sub_agents=children,
                **resolve_callbacks(spec.callbacks),
            )
        elif isinstance(spec, LoopAgentSpec):
            from google.adk.agents import LoopAgent  # lazy
            kwargs: dict[str, Any] = {
                "name": spec.name,
                "description": spec.description,
                "sub_agents": children,
                **resolve_callbacks(spec.callbacks),
            }
            if spec.max_iterations is not None:
                kwargs["max_iterations"] = spec.max_iterations
            agent = LoopAgent(**kwargs)
        else:  # pragma: no cover - schema enforces
            raise TypeError(f"Unknown agent spec type: {type(spec).__name__}")

        self._agents_by_name[spec.name] = agent
        self._spec_by_name[spec.name] = spec
        return agent

    def _build_llm_agent(self, spec: LlmAgentSpec, children: List[Any]) -> Any:
        from google.adk.agents import LlmAgent  # lazy

        # Resolve LLM (per-agent overrides top-level)
        llm = spec.llm or self.config.llm
        if spec.model is not None and spec.llm is None:
            # ``model:`` shorthand — use top-level provider with user's model
            from copy import deepcopy
            llm = deepcopy(self.config.llm) if self.config.llm else None
            if llm is None:
                # Should be caught by validator; defensive.
                raise ValueError(
                    f"Agent {spec.name!r} uses 'model' shorthand but no top-level llm exists"
                )
            llm.config = {**llm.config, "model": spec.model}

        model_value, env = resolve_model(llm)
        apply_env_side_effects(env)

        # Tools: builtin + plugins + mcp_servers (agent_as_tool added in pass 2)
        tools: List[Any] = []
        tools.extend(resolve_builtin_tools(spec.tools.builtin))
        tools.extend(resolve_plugins(spec.tools.plugins))
        tools.extend(resolve_mcp_refs(spec.tools.mcp_servers, self.config.mcp_servers))

        # Generative-UI components. Each ``@ui_component`` fetcher in
        # ``spec.ui_tools.module`` becomes a plain Python callable; ADK
        # auto-wraps it in a FunctionTool. The availability filter
        # narrows the list before registration so falsy-predicate
        # tools never reach the agent.
        if getattr(spec, "ui_tools", None) is not None:
            from agentflow.adk.genui import resolve_ui_tools
            from agentflow.genui import filter_by_availability

            ui_tools = resolve_ui_tools(spec.ui_tools)
            ui_tools = filter_by_availability(
                ui_tools,
                getattr(spec, "available_when", None),
                self.build_state,
            )
            tools.extend(ui_tools)

        # Frontend client_tools. AG-UI router flips ``bind_client_tools``
        # to True; each ``ClientToolConfig`` becomes a callable that
        # raises ``ClientToolPause``. The runtime catches the exception
        # and emits an AG-UI Interrupt. CLI / script callers leave the
        # flag off and the tools stay invisible.
        if self.bind_client_tools and getattr(spec, "client_tools", None):
            from agentflow.adk.agui.client_tools import build_client_tool_callables

            tools.extend(build_client_tool_callables(spec.client_tools))

        kwargs: dict[str, Any] = {
            "name": spec.name,
            "description": spec.description,
            "model": model_value,
            "tools": tools,
            "sub_agents": children,
            "disallow_transfer_to_parent": spec.disallow_transfer_to_parent,
            "disallow_transfer_to_peers": spec.disallow_transfer_to_peers,
            "include_contents": spec.include_contents,
        }
        if spec.instruction is not None:
            kwargs["instruction"] = spec.instruction
        if spec.static_instruction is not None:
            from google.genai import types  # lazy
            kwargs["static_instruction"] = types.Content(
                role="user", parts=[types.Part(text=spec.static_instruction)]
            )
        if spec.output_key is not None:
            kwargs["output_key"] = spec.output_key
        if spec.output_schema is not None:
            kwargs["output_schema"] = resolve_output_schema(spec.output_schema)
        if spec.planner is not None:
            kwargs["planner"] = resolve_planner(spec.planner)
        if spec.code_executor is not None:
            kwargs["code_executor"] = resolve_code_executor(spec.code_executor)

        kwargs.update(resolve_callbacks(spec.callbacks))

        # Apply generate_content_config from llm.config if present
        gcc = (llm.config.get("generate_content_config") if llm else None)
        if gcc:
            from google.genai import types  # lazy
            kwargs["generate_content_config"] = types.GenerateContentConfig(**gcc)

        return LlmAgent(**kwargs)

    # ----- pass 2: agent_as_tool refs -----

    def _wire_agent_as_tool(self, spec: Any) -> None:
        if isinstance(spec, LlmAgentSpec) and spec.tools.agent_as_tool:
            from google.adk.tools.agent_tool import AgentTool  # lazy

            parent_agent = self._agents_by_name[spec.name]
            for ref in spec.tools.agent_as_tool:
                if ref not in self._agents_by_name:
                    raise KeyError(
                        f"Agent {spec.name!r} references agent_as_tool {ref!r} "
                        f"which was not built (must be in the same tree)."
                    )
                target = self._agents_by_name[ref]
                parent_agent.tools.append(AgentTool(agent=target))

        for child in getattr(spec, "sub_agents", []) or []:
            self._wire_agent_as_tool(child)

    # ----- services -----

    def _build_session_service(self) -> Any:
        cfg = self.config.persistence
        from google.adk.sessions import InMemorySessionService  # lazy

        if cfg is None or cfg.type.value == "in_memory":
            return InMemorySessionService()
        if cfg.type.value == "sqlite":
            from google.adk.sessions import DatabaseSessionService  # lazy
            # ADK uses async SQLAlchemy — must use the aiosqlite driver, not
            # the default sync pysqlite. Auto-upgrade plain sqlite:// URLs.
            url = cfg.connection_string or f"sqlite+aiosqlite:///{cfg.db_path or 'state.db'}"
            if url.startswith("sqlite:///"):
                url = "sqlite+aiosqlite:///" + url[len("sqlite:///"):]
            return DatabaseSessionService(db_url=url)
        if cfg.type.value == "postgres":
            from google.adk.sessions import DatabaseSessionService  # lazy
            url = cfg.connection_string
            # Same async-driver requirement for postgres.
            if url.startswith("postgresql://"):
                url = "postgresql+asyncpg://" + url[len("postgresql://"):]
            elif url.startswith("postgres://"):
                url = "postgresql+asyncpg://" + url[len("postgres://"):]
            return DatabaseSessionService(db_url=url)
        if cfg.type.value == "vertex":
            from google.adk.sessions import VertexAiSessionService  # lazy
            return VertexAiSessionService(
                project=cfg.project,
                location=cfg.location,
                agent_engine_id=cfg.agent_engine_id,
            )
        raise ValueError(f"Unknown persistence type: {cfg.type!r}")  # pragma: no cover

    def _build_artifact_service(self) -> Any:
        cfg = self.config.artifacts
        if cfg is None:
            return None
        if cfg.type.value == "in_memory":
            from google.adk.artifacts import InMemoryArtifactService  # lazy
            return InMemoryArtifactService()
        if cfg.type.value == "file":
            from google.adk.artifacts import FileArtifactService  # lazy
            return FileArtifactService(base_dir=cfg.base_dir or "./artifacts")
        if cfg.type.value == "gcs":
            from google.adk.artifacts import GcsArtifactService  # lazy
            return GcsArtifactService(bucket_name=cfg.bucket_name)
        raise ValueError(f"Unknown artifacts type: {cfg.type!r}")  # pragma: no cover

    def _build_memory_service(self) -> Any:
        cfg = self.config.memory
        if cfg is None:
            return None
        if cfg.type.value == "in_memory":
            from google.adk.memory import InMemoryMemoryService  # lazy
            return InMemoryMemoryService()
        if cfg.type.value == "vertex_rag":
            from google.adk.memory import VertexAiRagMemoryService  # lazy
            kwargs: Dict[str, Any] = {}
            if cfg.rag_corpus is not None:
                kwargs["rag_corpus"] = cfg.rag_corpus
            if cfg.similarity_top_k is not None:
                kwargs["similarity_top_k"] = cfg.similarity_top_k
            if cfg.vector_distance_threshold is not None:
                kwargs["vector_distance_threshold"] = cfg.vector_distance_threshold
            return VertexAiRagMemoryService(**kwargs)
        if cfg.type.value == "vertex_memory_bank":
            from google.adk.memory import VertexAiMemoryBankService  # lazy
            return VertexAiMemoryBankService(**(cfg.config or {}))
        raise ValueError(f"Unknown memory type: {cfg.type!r}")  # pragma: no cover

    def _build_plugins(self) -> List[Any]:
        """Build the full plugin list:

        - Cross-backend portable tier (``guards`` / ``optimizers`` /
          ``observers``) → ``BasePlugin`` instances via the dispatch table
        - Explicit ADK plugin refs (``plugins:``) → user-supplied
          ``BasePlugin`` subclasses
        """

        out: List[Any] = []

        # Portable tier first so guards run before user plugins
        from agentflow.adk.filters.dispatch import (  # lazy
            build_guard, build_observer, build_optimizer,
        )
        for g in self.config.guards or []:
            out.append(build_guard(g))
        for o in self.config.optimizers or []:
            out.append(build_optimizer(o))
        for o in self.config.observers or []:
            out.append(build_observer(o))

        if not self.config.plugins:
            return out

        import importlib

        for ref in self.config.plugins:
            try:
                mod = importlib.import_module(ref.module)
            except ImportError as exc:
                raise ImportError(
                    f"Plugin module {ref.module!r} could not be imported: {exc}"
                ) from exc
            cls = getattr(mod, ref.class_name, None)
            if cls is None:
                raise AttributeError(
                    f"Plugin module {ref.module!r} has no attribute "
                    f"{ref.class_name!r}"
                )
            kwargs: Dict[str, Any] = dict(ref.config or {})
            # ADK BasePlugin requires `name` in __init__; respect override
            if ref.name is not None:
                kwargs["name"] = ref.name
            elif "name" not in kwargs:
                kwargs["name"] = ref.class_name
            out.append(cls(**kwargs))
        return out
