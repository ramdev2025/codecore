"""Bridge AgentFlow's cross-backend ``Plugin`` ABC to ADK's ``BasePlugin``.

ADK's ``BasePlugin`` and AgentFlow's
``agentflow.workflows.plugins.base.Plugin`` overlap almost completely:
both expose run/agent/model/tool lifecycle hooks. This module wraps any
agentflow ``Plugin``-like instance (duck-typed) in an ADK ``BasePlugin``
subclass and forwards events.

Hook mapping::

    AgentFlow Plugin event       →   ADK BasePlugin hook
    -----------------------         -----------------------
    on_workflow_start            →   before_run_callback
    on_workflow_end              →   after_run_callback
    on_agent_start               →   before_agent_callback
    on_agent_end                 →   after_agent_callback
    on_llm_start                 →   before_model_callback
    on_llm_end                   →   after_model_callback
    on_tool_call                 →   before_tool_callback
    on_tool_result               →   after_tool_callback
    on_error                     →   on_model_error_callback / on_tool_error_callback

ADK runs each plugin lifecycle hook with framework-specific args
(``InvocationContext`` etc.); we adapt those to the
``WorkflowContext``-shaped dict the agentflow Plugin expects. Methods
that aren't present on the wrapped plugin simply don't fire.

Design note: duck-typed — any object with the matching methods works,
so this is import-safe whether or not workflows is installed.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def make_adk_plugin_from_agentflow(plugin: Any) -> Any:
    """Wrap an agentflow ``Plugin``-like instance in an ADK ``BasePlugin``."""

    from google.adk.plugins.base_plugin import BasePlugin  # lazy

    plugin_name = getattr(plugin, "name", None) or type(plugin).__name__

    class _Bridge(BasePlugin):
        def __init__(self) -> None:
            super().__init__(name=plugin_name)
            self._target = plugin

        # --- Run-level ----------------------------------------------------

        async def before_run_callback(self, *, invocation_context: Any) -> Any:
            self._maybe_call(
                "on_workflow_start",
                _ctx(invocation_context),
                {},
            )
            return None

        async def after_run_callback(self, *, invocation_context: Any) -> Any:
            self._maybe_call(
                "on_workflow_end",
                _ctx(invocation_context),
                {},
                "completed",
            )
            return None

        # --- Agent --------------------------------------------------------

        async def before_agent_callback(self, *, agent: Any, callback_context: Any) -> Any:
            self._maybe_call(
                "on_agent_start",
                _ctx(callback_context),
                getattr(agent, "name", "agent"),
                {},
            )
            return None

        async def after_agent_callback(self, *, agent: Any, callback_context: Any) -> Any:
            self._maybe_call(
                "on_agent_end",
                _ctx(callback_context),
                getattr(agent, "name", "agent"),
                {},
            )
            return None

        # --- Model --------------------------------------------------------

        async def before_model_callback(
            self, *, callback_context: Any, llm_request: Any,
        ) -> Any:
            self._maybe_call(
                "on_llm_start",
                _ctx(callback_context),
                getattr(llm_request, "model", "unknown"),
                getattr(llm_request, "contents", []),
            )
            return None

        async def after_model_callback(
            self, *, callback_context: Any, llm_response: Any,
        ) -> Any:
            self._maybe_call(
                "on_llm_end",
                _ctx(callback_context),
                getattr(llm_response, "content", None),
                getattr(llm_response, "usage_metadata", None),
            )
            return None

        async def on_model_error_callback(
            self, *, callback_context: Any, llm_request: Any, error: Exception,
        ) -> Any:
            self._maybe_call(
                "on_error", _ctx(callback_context), error, {"phase": "model"},
            )
            return None

        # --- Tool ---------------------------------------------------------

        async def before_tool_callback(
            self, *, tool: Any, tool_args: Dict[str, Any], tool_context: Any,
        ) -> Any:
            self._maybe_call(
                "on_tool_call",
                _ctx(tool_context),
                getattr(tool, "name", type(tool).__name__),
                tool_args or {},
            )
            return None

        async def after_tool_callback(
            self, *, tool: Any, tool_args: Dict[str, Any],
            tool_context: Any, result: Any,
        ) -> Any:
            self._maybe_call(
                "on_tool_result",
                _ctx(tool_context),
                getattr(tool, "name", type(tool).__name__),
                result,
            )
            return None

        async def on_tool_error_callback(
            self, *, tool: Any, tool_args: Dict[str, Any],
            tool_context: Any, error: Exception,
        ) -> Any:
            self._maybe_call(
                "on_error", _ctx(tool_context), error,
                {"phase": "tool", "tool": getattr(tool, "name", "unknown")},
            )
            return None

        async def close(self) -> None:
            shutdown = getattr(self._target, "shutdown", None)
            if callable(shutdown):
                try:
                    shutdown()
                except Exception:
                    pass

        def _maybe_call(self, method_name: str, *args: Any) -> None:
            method = getattr(self._target, method_name, None)
            if not callable(method):
                return
            try:
                method(*args)
            except Exception:
                # Plugins must not break the agent; swallow but don't lose.
                # Real telemetry plugins should log internally.
                pass

    return _Bridge()


def _ctx(adk_context: Any) -> Any:
    """Convert an ADK context object to something Plugin expects.

    The cross-backend ``WorkflowContext`` is duck-typed by the existing
    plugins — they typically read ``invocation_id``, ``agent_name``,
    ``state``. We pass the ADK context object directly; plugins that
    care can introspect it.
    """
    return adk_context


def bridge_plugins(plugins: Optional[List[Any]]) -> List[Any]:
    """Convert a mixed list of plugins into a list of ADK ``BasePlugin`` instances.

    - ADK ``BasePlugin`` instances pass through unchanged.
    - Anything else is wrapped via :func:`make_adk_plugin_from_agentflow`.
    """
    if not plugins:
        return []

    from google.adk.plugins.base_plugin import BasePlugin  # lazy

    out: List[Any] = []
    for p in plugins:
        if isinstance(p, BasePlugin):
            out.append(p)
        else:
            out.append(make_adk_plugin_from_agentflow(p))
    return out
