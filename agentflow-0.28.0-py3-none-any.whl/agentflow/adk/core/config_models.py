"""Pydantic config models for the Google ADK YAML schema.

The ADK schema maps onto Google's ``google-adk`` SDK
(``google.adk.agents.LlmAgent`` / ``SequentialAgent`` / ``ParallelAgent`` /
``LoopAgent``). The four agent classes are surfaced through a single
``agent:`` root with a ``type:`` discriminator — the SDK's class hierarchy
maps 1:1 to YAML.

Schema shape::

    backend: adk
    metadata: { version, name, ... }

    # LLM-level options (model + provider)
    llm:
      provider: gemini             # gemini | vertex | litellm | custom
      config:
        model: gemini-2.5-flash
        # provider-specific keys (see llm-config.md)

    # The agent — autonomous LlmAgent OR a workflow agent (sequential /
    # parallel / loop). Workflow agents have no model/tools of their own;
    # they orchestrate sub_agents.
    agent:
      name: assistant
      type: llm                    # default; one of llm | sequential | parallel | loop
      instruction: ...
      tools:
        builtin: [google_search, exit_loop]
        plugins: [...]
        agent_as_tool: [helper-agent-name]
        mcp_servers: [my-mcp-server]
      callbacks:
        before_model: [...]
        after_model: [...]
        # before_tool / after_tool / on_model_error / on_tool_error / before_agent / after_agent
      planner: { type: built_in, thinking: { include_thoughts: true } }
      code_executor: { type: built_in }
      output_key: report
      sub_agents: [ ... ]          # AutoFlow delegation (LlmAgent only)

    # Cross-backend tier 1 (portable) — bridged to ADK BasePlugins
    guards: [...]
    optimizers: [...]
    observers: [...]

    # ADK BasePlugin refs (registered on the Runner)
    plugins: [...]

    # MCP servers (stdio / sse / streamable_http)
    mcp_servers: { ... }

    # Persistence — SessionService selection
    persistence:
      type: in_memory | sqlite | postgres | vertex
      ...

    # Vector memory — MemoryService selection
    memory: { type: in_memory | vertex_rag | vertex_memory_bank, ... }

    # Artifacts — ArtifactService selection
    artifacts: { type: in_memory | file | gcs, ... }

    # Vertex AI Agent Engine deploy
    serving: { type: vertex_agent_engine, project, location, agent_engine_id }

State-scoping prefixes (``user:``, ``app:``, ``temp:``, plain) are
runtime concerns — the YAML schema accepts plain strings everywhere
state keys appear (``output_key``, instruction templates) and the
prefix is applied at runtime by the SDK.
"""

from enum import Enum
from typing import Annotated, Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator

from agentflow.genui import ClientToolConfig, UIToolsConfig


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


class AdkMetadata(BaseModel):
    """Metadata about the ADK YAML config."""

    version: str = Field(..., description="Schema version (e.g. '1.0')")
    name: Optional[str] = Field(None, description="Human-readable name for this config")
    description: Optional[str] = None
    author: Optional[str] = None
    tags: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# LLM providers
# ---------------------------------------------------------------------------


class LLMProvider(str, Enum):
    """LLM providers exposed in v1.

    - ``gemini``: Google AI Studio. Reads ``GOOGLE_API_KEY`` and sets
      ``GOOGLE_GENAI_USE_VERTEXAI=FALSE``. The model field is passed to
      ``LlmAgent(model="...")`` as a plain string.
    - ``vertex``: Vertex AI. Sets ``GOOGLE_GENAI_USE_VERTEXAI=TRUE`` and
      requires ``GOOGLE_CLOUD_PROJECT`` / ``GOOGLE_CLOUD_LOCATION`` (either
      from the environment or from ``config:``). The model field is still
      passed as a string.
    - ``litellm``: Wraps the model in ``LiteLlm(model="...")``. Enables
      OpenAI / Anthropic / Azure / Ollama / vLLM access via the LiteLLM
      router. Requires the ``[extensions]`` extra (``pip install
      google-adk[extensions]``).
    - ``azure_openai``: Turn-key Azure OpenAI shorthand. Builds a LiteLlm
      wrapper with ``model = azure/<deployment>``, reads
      ``AZURE_OPENAI_ENDPOINT`` / ``OPENAI_API_VERSION`` from env (or
      ``config.azure_endpoint`` / ``config.api_version``), and either
      bridges ``api_key`` → ``AZURE_API_KEY`` or — when
      ``azure_identity: true`` — turns on LiteLLM's
      ``enable_azure_ad_token_refresh`` so ``DefaultAzureCredential``
      (Managed Identity / ``az login`` / Service Principal) is used
      automatically. No subclassing required.
    - ``custom``: Subclass of ``BaseLlm`` resolved by ``module:Class``
      reference. The class must satisfy ADK's ``BaseLlm`` interface.
    """

    GEMINI = "gemini"
    VERTEX = "vertex"
    LITELLM = "litellm"
    AZURE_OPENAI = "azure_openai"
    CUSTOM = "custom"


class LLMConfig(BaseModel):
    """LLM-level inference config.

    The ``provider`` selects how the model is constructed; ``config`` carries
    provider-specific keys passed through to ADK / LiteLLM. Known keys for
    every provider are listed in ``migration/adk/llm-config.md`` (and
    ``src/agentflow/adk/docs/SERVICES.md`` once the docs ship).
    """

    provider: LLMProvider = Field(default=LLMProvider.GEMINI)

    config: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Provider config. Required keys: 'model'. Common keys: api_key, "
            "project, location, base_url, generate_content_config (a dict "
            "passed to ADK's GenerateContentConfig)."
        ),
    )

    @model_validator(mode="after")
    def _validate_provider_config(self) -> "LLMConfig":
        if self.provider == LLMProvider.CUSTOM:
            if "module" not in self.config or "class" not in self.config:
                raise ValueError(
                    "provider 'custom' requires both 'module' and 'class' in config"
                )
        elif "model" not in self.config:
            raise ValueError(
                f"provider {self.provider.value!r} requires 'model' in config"
            )
        return self


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


class BuiltinTool(str, Enum):
    """Built-in ADK tools importable from ``google.adk.tools``.

    These are referenced by name in YAML; the builder resolves each name
    to its SDK instance / function. Some require optional config (e.g.
    ``vertex_ai_search`` needs ``data_store_id``) — those are passed via
    ``BuiltinToolRef.config``.
    """

    GOOGLE_SEARCH = "google_search"
    EXIT_LOOP = "exit_loop"
    TRANSFER_TO_AGENT = "transfer_to_agent"
    GET_USER_CHOICE = "get_user_choice"
    LOAD_ARTIFACTS = "load_artifacts"
    LOAD_MEMORY = "load_memory"
    PRELOAD_MEMORY = "preload_memory"
    URL_CONTEXT = "url_context"
    ENTERPRISE_WEB_SEARCH = "enterprise_web_search"
    GOOGLE_MAPS_GROUNDING = "google_maps_grounding"
    VERTEX_AI_SEARCH = "vertex_ai_search"


class BuiltinToolRef(BaseModel):
    """A reference to a built-in tool, optionally with config.

    YAML can write a bare name (``google_search``) or a structured object
    (``{name: vertex_ai_search, config: {data_store_id: ...}}``). The
    builder normalizes both forms.
    """

    name: BuiltinTool
    config: Optional[Dict[str, Any]] = None


class PluginType(str, Enum):
    """Plugin types supported by the ADK backend in v1."""

    PYTHON = "python"


class PluginRef(BaseModel):
    """Reference to a plugin (collection of custom tools) to register.

    Each entry resolves to the @tool-decorated functions exported from the
    given Python module; the builder wraps each function in ``FunctionTool``
    and adds it to the agent's ``tools`` list.
    """

    name: str = Field(..., description="Plugin name (used by telemetry / dry-run summary)")
    type: PluginType = Field(default=PluginType.PYTHON)
    module: str = Field(..., description="Python module path containing tool functions")
    functions: Optional[List[str]] = Field(
        None,
        description="Specific function names to import (default: all decorated tools)",
    )


class ToolsConfig(BaseModel):
    """Tools available to an LlmAgent.

    Four orthogonal sources, all optional:

    - ``builtin``: ADK's built-in tools by name (with optional per-tool config)
    - ``plugins``: Python ``@tool``-decorated functions
    - ``agent_as_tool``: names of sibling sub-agents wrapped via ``AgentTool``
    - ``mcp_servers``: references to top-level ``mcp_servers:`` entries
      (MCP toolsets become ``McpToolset`` instances)

    All four lists merge into the SDK's ``LlmAgent.tools=[...]`` list.
    Workflow agents (Sequential / Parallel / Loop) do not have tools.
    """

    builtin: List[Union[BuiltinTool, BuiltinToolRef]] = Field(default_factory=list)
    plugins: List[PluginRef] = Field(default_factory=list)
    agent_as_tool: List[str] = Field(
        default_factory=list,
        description="Sibling agent names to expose as tools (wrapped via AgentTool)",
    )
    mcp_servers: List[Union[str, Dict[str, Any]]] = Field(
        default_factory=list,
        description="References to mcp_servers entries by name, or inline configs",
    )


# ---------------------------------------------------------------------------
# Callbacks (per-agent)
# ---------------------------------------------------------------------------


class CallbackRef(BaseModel):
    """Reference to a Python callable bound to one of LlmAgent's callbacks.

    The referenced function must match the signature documented for that
    callback type in ADK (e.g. ``before_model_callback`` takes
    ``(CallbackContext, LlmRequest)`` and returns ``Optional[LlmResponse]``).
    """

    module: str = Field(..., description="Python module path")
    function: str = Field(..., description="Callable name within the module")


CallbackEntry = Union[CallbackRef, List[CallbackRef]]


class CallbacksConfig(BaseModel):
    """Per-agent callbacks. Each slot accepts one ref or a list of refs.

    Mirrors ADK's eight callback slots on ``LlmAgent`` (six on workflow
    agents — workflow agents have no model/tool callbacks). Empty by
    default.
    """

    before_agent: Optional[CallbackEntry] = None
    after_agent: Optional[CallbackEntry] = None
    before_model: Optional[CallbackEntry] = None
    after_model: Optional[CallbackEntry] = None
    on_model_error: Optional[CallbackEntry] = None
    before_tool: Optional[CallbackEntry] = None
    after_tool: Optional[CallbackEntry] = None
    on_tool_error: Optional[CallbackEntry] = None


# ---------------------------------------------------------------------------
# Planners
# ---------------------------------------------------------------------------


class ThinkingMode(BaseModel):
    """ADK ``ThinkingConfig`` passthrough — Gemini's extended thinking.

    Maps to ``google.genai.types.ThinkingConfig``. ``include_thoughts``
    surfaces the thinking trace in events; ``thinking_budget`` (when set)
    caps token usage. Both are optional.
    """

    include_thoughts: Optional[bool] = None
    thinking_budget: Optional[int] = Field(None, ge=0)


class BuiltInPlanner(BaseModel):
    type: Literal["built_in"]
    thinking: ThinkingMode = Field(default_factory=ThinkingMode)


class PlanReActPlanner(BaseModel):
    type: Literal["react"]


PlannerConfig = Annotated[
    Union[BuiltInPlanner, PlanReActPlanner],
    Field(discriminator="type"),
]


# ---------------------------------------------------------------------------
# Code executors
# ---------------------------------------------------------------------------


class BuiltInCodeExecutorConfig(BaseModel):
    type: Literal["built_in"]


class ContainerCodeExecutorConfig(BaseModel):
    type: Literal["container"]
    base_url: Optional[str] = None
    image: Optional[str] = None
    docker_path: Optional[str] = None


class UnsafeLocalCodeExecutorConfig(BaseModel):
    type: Literal["unsafe_local"]


class VertexAiCodeExecutorConfig(BaseModel):
    type: Literal["vertex_ai"]
    resource_name: Optional[str] = None


CodeExecutorConfig = Annotated[
    Union[
        BuiltInCodeExecutorConfig,
        ContainerCodeExecutorConfig,
        UnsafeLocalCodeExecutorConfig,
        VertexAiCodeExecutorConfig,
    ],
    Field(discriminator="type"),
]


# ---------------------------------------------------------------------------
# Output schema
# ---------------------------------------------------------------------------


class OutputSchemaRef(BaseModel):
    """Reference to a Pydantic model for structured output.

    The class is resolved at build time and assigned to
    ``LlmAgent.output_schema``. Setting structured output disables tool calls
    in ADK — the schema is enforced as the single response shape.
    """

    module: str = Field(..., description="Python module path")
    class_name: str = Field(..., alias="class", description="Pydantic BaseModel subclass name")

    model_config = {"populate_by_name": True}


# ---------------------------------------------------------------------------
# Cross-backend portable tier (compiled to BasePlugins via the bridge)
# ---------------------------------------------------------------------------


class GuardType(str, Enum):
    PII = "pii"
    MODEL_CALL_LIMIT = "model_call_limit"
    TOOL_CALL_LIMIT = "tool_call_limit"
    INPUT_VALIDATION = "input_validation"
    CONTENT_FILTER = "content_filter"


class GuardConfig(BaseModel):
    type: GuardType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class OptimizerType(str, Enum):
    TOOL_RETRY = "tool_retry"
    SUMMARIZATION = "summarization"
    PROMPT_CACHING = "prompt_caching"


class OptimizerConfig(BaseModel):
    type: OptimizerType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class ObserverType(str, Enum):
    AUDIT_LOG = "audit_log"
    COST_TRACKING = "cost_tracking"
    LATENCY_TRACKING = "latency_tracking"


class ObserverConfig(BaseModel):
    type: ObserverType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


# ---------------------------------------------------------------------------
# ADK BasePlugin refs (registered on the Runner)
# ---------------------------------------------------------------------------


class AdkPluginRef(BaseModel):
    """Reference to an ADK ``BasePlugin`` subclass.

    Distinct from ``PluginRef`` (which is for @tool function modules) —
    this is ADK's tree-wide plugin abstraction with run/agent/model/tool
    lifecycle hooks. Used for cross-cutting concerns: logging, retry,
    observability, custom telemetry. Registered on ``Runner(plugins=[...])``.
    """

    module: str = Field(..., description="Python module path")
    class_name: str = Field(..., alias="class", description="BasePlugin subclass name")
    name: Optional[str] = Field(None, description="Override the plugin's display name")
    config: Optional[Dict[str, Any]] = Field(
        None,
        description="Keyword args passed to the plugin's constructor",
    )

    model_config = {"populate_by_name": True}


# ---------------------------------------------------------------------------
# MCP servers
# ---------------------------------------------------------------------------


class MCPTransport(str, Enum):
    STDIO = "stdio"
    SSE = "sse"
    STREAMABLE_HTTP = "streamable_http"


class MCPServerEntry(BaseModel):
    transport: MCPTransport = Field(default=MCPTransport.STDIO)

    # stdio
    command: Optional[str] = None
    args: Optional[List[str]] = None
    env: Optional[Dict[str, str]] = None
    timeout: Optional[float] = Field(None, gt=0)

    # sse / streamable_http
    url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None

    # All transports — passthroughs to McpToolset
    tool_filter: Optional[List[str]] = None
    tool_name_prefix: Optional[str] = None

    @model_validator(mode="after")
    def _validate_transport_fields(self) -> "MCPServerEntry":
        if self.transport == MCPTransport.STDIO:
            if not self.command:
                raise ValueError("MCP transport 'stdio' requires 'command'")
        else:
            if not self.url:
                raise ValueError(
                    f"MCP transport {self.transport.value!r} requires 'url'"
                )
        return self


# ---------------------------------------------------------------------------
# Persistence (SessionService selection)
# ---------------------------------------------------------------------------


class PersistenceType(str, Enum):
    IN_MEMORY = "in_memory"
    SQLITE = "sqlite"
    POSTGRES = "postgres"
    VERTEX = "vertex"


class PersistenceConfig(BaseModel):
    """SessionService backend.

    - ``in_memory``: ``InMemorySessionService`` (dev only, not thread-safe)
    - ``sqlite``: ``DatabaseSessionService`` with SQLite URL
    - ``postgres``: ``DatabaseSessionService`` with Postgres URL
    - ``vertex``: ``VertexAiSessionService`` (managed by Vertex AI Agent Engine)
    """

    type: PersistenceType = Field(default=PersistenceType.IN_MEMORY)
    db_path: Optional[str] = Field(None, description="SQLite path (sqlite only)")
    connection_string: Optional[str] = Field(
        None,
        description="Full SQLAlchemy URL (postgres or override for sqlite)",
    )
    project: Optional[str] = Field(None, description="GCP project id (vertex only)")
    location: Optional[str] = Field(None, description="GCP location (vertex only)")
    agent_engine_id: Optional[str] = Field(
        None,
        description="Vertex AI Agent Engine id (vertex only)",
    )

    @model_validator(mode="after")
    def _validate_per_type(self) -> "PersistenceConfig":
        if self.type == PersistenceType.POSTGRES and not self.connection_string:
            raise ValueError("persistence type 'postgres' requires 'connection_string'")
        return self


# ---------------------------------------------------------------------------
# Memory (vector store)
# ---------------------------------------------------------------------------


class MemoryType(str, Enum):
    IN_MEMORY = "in_memory"
    VERTEX_RAG = "vertex_rag"
    VERTEX_MEMORY_BANK = "vertex_memory_bank"


class MemoryConfig(BaseModel):
    type: MemoryType = Field(default=MemoryType.IN_MEMORY)
    rag_corpus: Optional[str] = Field(None, description="Vertex RAG corpus name")
    similarity_top_k: Optional[int] = Field(None, ge=1)
    vector_distance_threshold: Optional[float] = None
    config: Optional[Dict[str, Any]] = Field(
        None,
        description="Provider-specific extras passed through to the SessionService",
    )


# ---------------------------------------------------------------------------
# Artifacts
# ---------------------------------------------------------------------------


class ArtifactsType(str, Enum):
    IN_MEMORY = "in_memory"
    FILE = "file"
    GCS = "gcs"


class ArtifactsConfig(BaseModel):
    type: ArtifactsType = Field(default=ArtifactsType.IN_MEMORY)
    bucket_name: Optional[str] = Field(None, description="GCS bucket (gcs only)")
    base_dir: Optional[str] = Field(None, description="Base directory (file only)")

    @model_validator(mode="after")
    def _validate_per_type(self) -> "ArtifactsConfig":
        if self.type == ArtifactsType.GCS and not self.bucket_name:
            raise ValueError("artifacts type 'gcs' requires 'bucket_name'")
        return self


# ---------------------------------------------------------------------------
# Serving (Vertex AI Agent Engine)
# ---------------------------------------------------------------------------


class ServingConfig(BaseModel):
    """Vertex AI Agent Engine deployment target.

    The actual deploy is invoked separately (``agentflow adk deploy ...``);
    this block declares the target so dry-run can validate it without
    network access.
    """

    type: Literal["vertex_agent_engine"] = "vertex_agent_engine"
    project: Optional[str] = None
    location: Optional[str] = None
    agent_engine_id: Optional[str] = Field(
        None,
        description=(
            "Existing Agent Engine id to update; omit to create a new one on deploy"
        ),
    )
    display_name: Optional[str] = None
    description: Optional[str] = None


# ---------------------------------------------------------------------------
# Agent specs (discriminated by ``type:``)
# ---------------------------------------------------------------------------


class AgentType(str, Enum):
    LLM = "llm"
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    LOOP = "loop"


class _AgentBase(BaseModel):
    """Fields shared by every agent type."""

    name: str = Field(..., description="Agent name (used for telemetry + transfer routing)")
    description: str = Field(
        default="",
        description="Free-text description; surfaced to parents for routing decisions",
    )

    # Workflow + LlmAgent both support these:
    callbacks: Optional[CallbacksConfig] = None


class LlmAgentSpec(_AgentBase):
    """Autonomous ``LlmAgent``.

    The ``type:`` field is optional and defaults to ``llm`` (the most common
    case). All other fields are 1:1 with ``google.adk.agents.LlmAgent``;
    snake_case names match the SDK exactly.
    """

    type: Literal[AgentType.LLM] = Field(default=AgentType.LLM)

    # Per-agent LLM (overrides top-level)
    llm: Optional[LLMConfig] = None
    model: Optional[str] = Field(
        None,
        description=(
            "Convenience: model name only; uses the top-level ``llm.provider``. "
            "For provider overrides use ``llm:`` instead."
        ),
    )

    instruction: Optional[str] = None
    static_instruction: Optional[str] = Field(
        None,
        description="Cached system prompt (passed verbatim, not templated)",
    )

    tools: ToolsConfig = Field(default_factory=ToolsConfig)

    # Cross-backend generative-UI components. Same schema MAF / SK use,
    # so a single YAML block works across backends.
    ui_tools: Optional[UIToolsConfig] = Field(
        None,
        description=(
            "Generative-UI components: a module of "
            "``@agentflow.genui.ui_component``-decorated fetchers exposed "
            "as ADK tools. Each fetcher's return is validated against "
            "its declared Pydantic class and surfaced to the LLM as a "
            "JSON string. Frontend rendering requires a separate AG-UI "
            "bridge (not shipped on ADK as of this release)."
        ),
    )
    # Frontend-implemented tools. The ADK AG-UI bridge registers these
    # as ADK tools that raise ``ClientToolPause``; the orchestrator
    # catches the exception and emits an AG-UI Interrupt. Cross-backend
    # schema — same as workflows / deep / MAF / SK / CAS / OAI.
    client_tools: Optional[List[ClientToolConfig]] = Field(
        default=None,
        description=(
            "Frontend-implemented (browser-side) tools. Each becomes "
            "an ADK tool the LLM sees; the AG-UI bridge pauses the "
            "run when it's invoked and resumes once the browser posts "
            "the result. Bound only when the AG-UI router opts in via "
            "``bind_client_tools=True``."
        ),
    )

    available_when: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Build-time predicate gating for ``ui_tools``. Keys are "
            "component class names; values are ``simpleeval`` expressions "
            "evaluated once at agent construction against the build "
            "state. Tools with falsy predicates are excluded — the LLM "
            "never sees them."
        ),
    )

    sub_agents: List["AgentSpec"] = Field(
        default_factory=list,
        description="Children for AutoFlow ``transfer_to_agent`` delegation",
    )
    disallow_transfer_to_parent: bool = False
    disallow_transfer_to_peers: bool = False

    include_contents: Literal["default", "none"] = "default"

    output_schema: Optional[OutputSchemaRef] = Field(
        None,
        description=(
            "Pydantic class for structured output. Setting this disables tool "
            "calls in ADK."
        ),
    )
    output_key: Optional[str] = Field(
        None,
        description=(
            "Session-state key the final response is written to. Supports "
            "ADK's scope prefixes (``user:``, ``app:``, ``temp:``)."
        ),
    )

    planner: Optional[PlannerConfig] = None
    code_executor: Optional[CodeExecutorConfig] = None


class SequentialAgentSpec(_AgentBase):
    """Runs ``sub_agents`` in order, threading state forward."""

    type: Literal[AgentType.SEQUENTIAL]
    sub_agents: List["AgentSpec"] = Field(..., min_length=1)


class ParallelAgentSpec(_AgentBase):
    """Runs ``sub_agents`` concurrently."""

    type: Literal[AgentType.PARALLEL]
    sub_agents: List["AgentSpec"] = Field(..., min_length=1)


class LoopAgentSpec(_AgentBase):
    """Runs ``sub_agents`` in order, repeating until escalate or ``max_iterations``."""

    type: Literal[AgentType.LOOP]
    sub_agents: List["AgentSpec"] = Field(..., min_length=1)
    max_iterations: Optional[int] = Field(None, ge=1)


AgentSpec = Annotated[
    Union[LlmAgentSpec, SequentialAgentSpec, ParallelAgentSpec, LoopAgentSpec],
    Field(discriminator="type"),
]


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


def _default_agent_type(value: Any) -> Any:
    """Inject ``type: llm`` on agent specs that don't declare one.

    Pydantic's discriminated-union machinery needs the tag field to be
    present in the input. Users overwhelmingly write ``LlmAgent`` configs
    without ``type:`` (it's the most common case), so we walk the agent
    tree and fill in the default before discrimination runs.
    """

    if not isinstance(value, dict):
        return value
    out = dict(value)
    if "type" not in out:
        out["type"] = AgentType.LLM.value
    if "sub_agents" in out and isinstance(out["sub_agents"], list):
        out["sub_agents"] = [_default_agent_type(c) for c in out["sub_agents"]]
    return out


class AdkYAMLConfig(BaseModel):
    """Root Google ADK YAML config."""

    backend: Literal["adk"] = Field(default="adk")
    metadata: AdkMetadata

    agent: AgentSpec = Field(
        ...,
        description=(
            "Root agent. Use ``type: llm`` (default) for autonomous, or "
            "``sequential`` / ``parallel`` / ``loop`` for deterministic "
            "orchestration. Workflow agents wrap nested ``sub_agents``; an "
            "LlmAgent's ``sub_agents`` is for AutoFlow delegation."
        ),
    )

    llm: Optional[LLMConfig] = Field(
        None,
        description="Top-level default LLM (per-agent ``llm:`` overrides this)",
    )

    plugins: Optional[List[AdkPluginRef]] = Field(
        None,
        description=(
            "ADK ``BasePlugin`` refs registered on the Runner. The portable "
            "guards/optimizers/observers tier compiles to BasePlugins via the "
            "agentflow plugin bridge — these explicit refs are for plugins "
            "outside that tier."
        ),
    )

    guards: Optional[List[GuardConfig]] = None
    optimizers: Optional[List[OptimizerConfig]] = None
    observers: Optional[List[ObserverConfig]] = None

    mcp_servers: Optional[Dict[str, MCPServerEntry]] = None

    persistence: Optional[PersistenceConfig] = None
    memory: Optional[MemoryConfig] = None
    artifacts: Optional[ArtifactsConfig] = None
    serving: Optional[ServingConfig] = None

    @model_validator(mode="before")
    @classmethod
    def _inject_default_agent_type(cls, value: Any) -> Any:
        if isinstance(value, dict) and "agent" in value:
            value = dict(value)
            value["agent"] = _default_agent_type(value["agent"])
        return value

    # ----- cross-validators -----

    @model_validator(mode="after")
    def _validate_llm_required_for_llm_agents(self) -> "AdkYAMLConfig":
        """Every ``type=llm`` node in the agent tree needs an LLM source.

        Workflow agents (sequential/parallel/loop) don't need an LLM
        themselves, but they must contain at least one llm-typed descendant
        — otherwise the tree has nothing to call.
        """

        def has_llm(spec: Any) -> None:
            if isinstance(spec, LlmAgentSpec):
                if spec.llm is None and spec.model is None and self.llm is None:
                    raise ValueError(
                        f"LlmAgent {spec.name!r} has no LLM configured. "
                        "Set top-level 'llm:', 'agent.llm:', or 'agent.model:'."
                    )
                for child in spec.sub_agents:
                    has_llm(child)
            else:
                # workflow agent
                if not spec.sub_agents:
                    raise ValueError(
                        f"Workflow agent {spec.name!r} (type {spec.type.value!r}) "
                        "needs at least one sub_agent."
                    )
                for child in spec.sub_agents:
                    has_llm(child)

        has_llm(self.agent)
        return self

    @model_validator(mode="after")
    def _validate_mcp_refs(self) -> "AdkYAMLConfig":
        """Tool refs to mcp_servers must exist; agent_as_tool refs must
        point to an actual sibling agent name in the tree."""

        mcp_names = set(self.mcp_servers or {})
        # Collect every name in the agent tree
        agent_names: set[str] = set()

        def collect(spec: Any) -> None:
            agent_names.add(spec.name)
            for child in getattr(spec, "sub_agents", []) or []:
                collect(child)

        collect(self.agent)

        def check(spec: Any) -> None:
            if isinstance(spec, LlmAgentSpec):
                for ref in spec.tools.mcp_servers:
                    if isinstance(ref, str) and ref not in mcp_names:
                        raise ValueError(
                            f"Agent {spec.name!r} references unknown MCP server "
                            f"{ref!r}. Known servers: {sorted(mcp_names) or 'none'}."
                        )
                for ref in spec.tools.agent_as_tool:
                    if ref not in agent_names:
                        raise ValueError(
                            f"Agent {spec.name!r} references unknown agent_as_tool "
                            f"{ref!r}. Known agents: {sorted(agent_names)}."
                        )
            for child in getattr(spec, "sub_agents", []) or []:
                check(child)

        check(self.agent)
        return self

    @model_validator(mode="after")
    def _validate_unique_agent_names(self) -> "AdkYAMLConfig":
        """ADK uses ``find_agent(name)`` for transfer routing; duplicate names
        across the tree make routing ambiguous."""

        seen: Dict[str, int] = {}

        def visit(spec: Any) -> None:
            seen[spec.name] = seen.get(spec.name, 0) + 1
            for child in getattr(spec, "sub_agents", []) or []:
                visit(child)

        visit(self.agent)
        dupes = [n for n, c in seen.items() if c > 1]
        if dupes:
            raise ValueError(
                f"Duplicate agent name(s) in tree: {dupes}. "
                "ADK transfer routing requires unique names."
            )
        return self


# Resolve forward references for the recursive AgentSpec
LlmAgentSpec.model_rebuild()
SequentialAgentSpec.model_rebuild()
ParallelAgentSpec.model_rebuild()
LoopAgentSpec.model_rebuild()
