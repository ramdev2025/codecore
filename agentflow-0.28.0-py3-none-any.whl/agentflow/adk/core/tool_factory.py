"""Resolve YAML tool entries into ADK SDK objects.

Three flavours, each handled separately:

- **Built-in tools** (``BuiltinTool`` enum) → resolved by name to the SDK
  instance / callable. Some need config (e.g. ``vertex_ai_search`` needs a
  ``data_store_id``).
- **Plugins** (Python modules with @tool functions) → handled by
  ``plugin_registry``; this factory passes through the resulting list.
- **agent_as_tool refs** → wrapped via ``AgentTool`` *after* the referenced
  child agent has been built; the builder coordinates the timing.
- **MCP server refs** → handled by ``mcp.py``; this factory passes through.

Built-in tools that don't currently exist in the installed SDK raise an
explicit ``ImportError`` at build time rather than silently dropping —
this is one of the ADK SDK quirks called out in the spec note.
"""

from __future__ import annotations

from typing import Any, Dict, List, Union

from agentflow.adk.core.config_models import BuiltinTool, BuiltinToolRef


def resolve_builtin_tools(
    entries: List[Union[BuiltinTool, BuiltinToolRef]],
) -> List[Any]:
    """Resolve built-in tool refs to their SDK objects."""
    if not entries:
        return []

    out: List[Any] = []
    for entry in entries:
        if isinstance(entry, BuiltinTool):
            out.append(_resolve_one(entry, None))
        else:
            out.append(_resolve_one(entry.name, entry.config))
    return out


def _resolve_one(name: BuiltinTool, config: Dict[str, Any] | None) -> Any:
    """Look up and (if required) instantiate one built-in tool."""
    import google.adk.tools as adk_tools  # lazy

    # Plain instances exported from google.adk.tools
    plain_instances = {
        BuiltinTool.GOOGLE_SEARCH: "google_search",
        BuiltinTool.EXIT_LOOP: "exit_loop",
        BuiltinTool.TRANSFER_TO_AGENT: "transfer_to_agent",
        BuiltinTool.GET_USER_CHOICE: "get_user_choice",
        BuiltinTool.LOAD_ARTIFACTS: "load_artifacts",
        BuiltinTool.LOAD_MEMORY: "load_memory",
        BuiltinTool.PRELOAD_MEMORY: "preload_memory",
        BuiltinTool.URL_CONTEXT: "url_context",
        BuiltinTool.ENTERPRISE_WEB_SEARCH: "enterprise_web_search",
        BuiltinTool.GOOGLE_MAPS_GROUNDING: "google_maps_grounding",
    }
    if name in plain_instances:
        attr = plain_instances[name]
        obj = getattr(adk_tools, attr, None)
        if obj is None:
            raise ImportError(
                f"Built-in tool {name.value!r} is not available in the installed "
                f"google-adk version. Update or remove this entry."
            )
        if config:
            raise ValueError(
                f"Built-in tool {name.value!r} does not accept config; "
                f"got {sorted(config)!r}"
            )
        return obj

    if name == BuiltinTool.VERTEX_AI_SEARCH:
        from google.adk.tools import VertexAiSearchTool  # lazy

        cfg = config or {}
        if "data_store_id" not in cfg and "search_engine_id" not in cfg:
            raise ValueError(
                "Built-in tool 'vertex_ai_search' requires either "
                "'data_store_id' or 'search_engine_id' in its config."
            )
        return VertexAiSearchTool(**cfg)

    raise ValueError(f"Unknown built-in tool: {name!r}")  # pragma: no cover


def resolve_planner(planner: Any) -> Any:
    """Translate a ``PlannerConfig`` to an ADK ``BasePlanner`` instance."""
    if planner is None:
        return None
    from google.adk.planners import BuiltInPlanner, PlanReActPlanner  # lazy

    if planner.type == "built_in":
        from google.genai import types  # lazy

        thinking = planner.thinking
        thinking_kwargs: Dict[str, Any] = {}
        if thinking.include_thoughts is not None:
            thinking_kwargs["include_thoughts"] = thinking.include_thoughts
        if thinking.thinking_budget is not None:
            thinking_kwargs["thinking_budget"] = thinking.thinking_budget
        return BuiltInPlanner(thinking_config=types.ThinkingConfig(**thinking_kwargs))

    if planner.type == "react":
        return PlanReActPlanner()

    raise ValueError(f"Unknown planner type: {planner.type!r}")  # pragma: no cover


def resolve_code_executor(executor: Any) -> Any:
    """Translate a ``CodeExecutorConfig`` to an ADK ``BaseCodeExecutor``."""
    if executor is None:
        return None
    from google.adk.code_executors import (  # lazy
        BuiltInCodeExecutor,
        UnsafeLocalCodeExecutor,
    )

    if executor.type == "built_in":
        return BuiltInCodeExecutor()
    if executor.type == "unsafe_local":
        return UnsafeLocalCodeExecutor()
    if executor.type == "container":
        from google.adk.code_executors import ContainerCodeExecutor  # lazy

        return ContainerCodeExecutor(
            base_url=executor.base_url,
            image=executor.image,
            docker_path=executor.docker_path,
        )
    if executor.type == "vertex_ai":
        from google.adk.code_executors import VertexAiCodeExecutor  # lazy

        return VertexAiCodeExecutor(resource_name=executor.resource_name)

    raise ValueError(f"Unknown code executor type: {executor.type!r}")  # pragma: no cover


def resolve_output_schema(ref: Any) -> Any:
    """Import the user-provided Pydantic class for ``output_schema``."""
    if ref is None:
        return None
    import importlib

    try:
        mod = importlib.import_module(ref.module)
    except ImportError as exc:
        raise ImportError(
            f"output_schema module {ref.module!r} could not be imported: {exc}"
        ) from exc
    cls = getattr(mod, ref.class_name, None)
    if cls is None:
        raise AttributeError(
            f"output_schema module {ref.module!r} has no attribute "
            f"{ref.class_name!r}"
        )
    return cls
