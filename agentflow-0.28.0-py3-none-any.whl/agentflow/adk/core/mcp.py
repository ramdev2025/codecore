"""Translate ``MCPServerEntry`` YAML into ``McpToolset`` instances.

Supports all three transports ADK ships with: stdio, SSE, and
StreamableHTTP. The SDK class is imported lazily so schema-only operations
(dry-run, unit tests) don't require ``google-adk`` to be installed.
"""

from __future__ import annotations

from typing import Any, Dict, List, Union

from agentflow.adk.core.config_models import MCPServerEntry, MCPTransport


def build_mcp_toolset(entry: MCPServerEntry) -> Any:
    """Build an ``McpToolset`` for one server entry."""

    from google.adk.tools.mcp_tool import (  # lazy
        McpToolset,
        SseConnectionParams,
        StdioConnectionParams,
        StreamableHTTPConnectionParams,
    )

    if entry.transport == MCPTransport.STDIO:
        from mcp.client.stdio import StdioServerParameters  # lazy

        params = StdioConnectionParams(
            server_params=StdioServerParameters(
                command=entry.command,
                args=entry.args or [],
                env=entry.env or None,
            ),
            timeout=entry.timeout if entry.timeout is not None else 5.0,
        )
    elif entry.transport == MCPTransport.SSE:
        params = SseConnectionParams(
            url=entry.url,
            headers=entry.headers or None,
        )
    else:  # StreamableHTTP
        params = StreamableHTTPConnectionParams(
            url=entry.url,
            headers=entry.headers or None,
        )

    return McpToolset(
        connection_params=params,
        tool_filter=entry.tool_filter,
        tool_name_prefix=entry.tool_name_prefix,
    )


def resolve_mcp_refs(
    refs: List[Union[str, Dict[str, Any]]],
    registry: Dict[str, MCPServerEntry] | None,
) -> List[Any]:
    """Resolve a list of mcp_servers refs (strings or inline dicts).

    String refs look up by name in the top-level ``mcp_servers:`` registry;
    inline dicts are validated as ``MCPServerEntry`` ad-hoc.
    """

    out: List[Any] = []
    registry = registry or {}
    for ref in refs:
        if isinstance(ref, str):
            entry = registry.get(ref)
            if entry is None:
                raise KeyError(
                    f"MCP server {ref!r} not found in mcp_servers registry; "
                    f"known: {sorted(registry) or 'none'}"
                )
        else:
            entry = MCPServerEntry.model_validate(ref)
        out.append(build_mcp_toolset(entry))
    return out
