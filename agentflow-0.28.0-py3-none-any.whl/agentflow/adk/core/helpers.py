"""Shared helpers for the ADK backend.

Mirror of ``src/agentflow/cas/core/helpers.py`` — keeps env-var interpolation
and project ``.env`` loading consistent across backends.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def load_dotenv_for(yaml_path: str) -> None:
    """Load the project ``.env`` (if present) relative to the YAML file.

    Falls back to the shell's CWD via ``find_dotenv(usecwd=True)``. The
    bare ``load_dotenv()`` default walks up from the caller's module
    location — on a pip install that's inside ``site-packages/`` and can
    cross into an ancestor ``.env`` unrelated to the user's project,
    silently overriding the yaml-adjacent ``.env`` we just loaded.
    """
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:  # pragma: no cover
        return

    yaml_dir = Path(yaml_path).resolve().parent
    load_dotenv(yaml_dir / ".env", override=True)

    cwd_dotenv = find_dotenv(usecwd=True)
    if cwd_dotenv and Path(cwd_dotenv).resolve() != (yaml_dir / ".env").resolve():
        load_dotenv(cwd_dotenv, override=True)


def resolve_env_vars(value: Any) -> Any:
    """Replace ``${VAR}`` placeholders recursively.

    Undefined variables raise ``MissingEnvVarError`` — silent empty
    substitution hides configuration bugs.
    """
    if isinstance(value, str):
        return _ENV_PATTERN.sub(_resolve_match, value)
    if isinstance(value, dict):
        return {k: resolve_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_env_vars(v) for v in value]
    return value


def _resolve_match(m: re.Match) -> str:
    from agentflow.core.exceptions import MissingEnvVarError

    name = m.group(1)
    value = os.environ.get(name)
    if value is None:
        raise MissingEnvVarError(name)
    return value
