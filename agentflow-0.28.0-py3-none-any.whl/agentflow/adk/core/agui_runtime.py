"""Async AG-UI runtime adapter for the ADK backend.

Wraps the :class:`AdkRunner` (Google Agent Development Kit) and
translates its ``Runner.run_async()`` event stream into the dict
event format the cross-backend AG-UI adapter consumes.

ADK ``Event`` items carry a ``content: google.genai.types.Content``
with ``parts: list[Part]``. Each Part may carry:

  * ``text`` — assistant text (delta when ``event.partial=True``)
  * ``function_call`` — LLM is invoking a tool (with ``.name``, ``.args``)
  * ``function_response`` — tool returned (with ``.name``, ``.response``)

Translation:

  * Text Part with ``partial=True`` → ``token`` event
  * Text Part with ``partial=False`` (final text) → ``token`` if streaming
    is on (single chunk) or ``agent`` otherwise
  * ``function_call`` Part → ``tool_call`` event (id from function_call.id)
  * ``function_response`` Part → ``tool`` event (content = .response)
  * ``turn_complete=True`` → ``agent_end``

ADK has no native pause primitive; client_tools use the same
exception-based ``ClientToolPause`` pattern as SK / CAS / OAI.
The exception bubbles up through ``runner.run_async``; the
orchestrator catches and surfaces it.

State is in-memory only — ADK ships its own session services
(``InMemorySessionService`` / ``DatabaseSessionService``) but the
AG-UI bridge's resume flow uses our own paused-interrupt map keyed
by thread_id.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AsyncADKAGUIRuntime:
    """Async AG-UI runtime adapter wrapping a Google ADK ``AdkRunner``."""

    def __init__(
        self,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> None:
        self._config_path = config_path
        self._build_state = build_state or {}
        self._bind_client_tools = bind_client_tools
        self._builder: Any = None
        self._runner: Any = None
        self._paused_threads: dict[str, dict[str, Any]] = {}

    @classmethod
    async def create(
        cls,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> "AsyncADKAGUIRuntime":
        from agentflow.adk.core.builder import AdkAgentBuilder

        inst = cls(
            config_path=config_path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )
        inst._builder = AdkAgentBuilder.from_yaml(
            config_path,
            build_state=inst._build_state,
            bind_client_tools=bind_client_tools,
        )
        inst._runner = inst._builder.build()
        return inst

    async def cleanup(self) -> None:
        return None

    async def get_state(self, thread_id: str) -> dict[str, Any]:
        from types import SimpleNamespace

        tasks = ()
        pending = self._paused_threads.get(thread_id)
        if pending is not None:
            intr = SimpleNamespace(id=pending["id"], value=pending["value"])
            task = SimpleNamespace(id=f"task-{thread_id}", interrupts=(intr,))
            tasks = (task,)
        return {"values": {}, "tasks": tasks, "next": ()}

    async def run(
        self,
        state: Any,
        config: dict,
        stream_tokens: bool = False,
    ):
        """Yield orchestrator events translated from ADK's stream."""
        from langgraph.types import Command

        from agentflow.adk.agui.client_tools import ClientToolPause

        thread_id = (config.get("configurable") or {}).get("thread_id") or "default"

        prompt: Optional[str] = None
        if isinstance(state, Command):
            pending = self._paused_threads.pop(thread_id, None)
            if pending is None:
                logger.warning("ADK: resume requested for thread=%s but no paused interrupt", thread_id)
                return
            tool_name = pending["value"].get("tool_name") or "?"
            content = state.resume if isinstance(state.resume, str) else str(state.resume)
            prompt = f"Tool result for {tool_name}: {content}\n\nContinue based on this result."
        elif isinstance(state, dict) and state.get("messages"):
            for msg in state["messages"]:
                if msg.get("role") == "user" and msg.get("content"):
                    prompt = msg["content"]
        if not prompt:
            return

        if stream_tokens:
            yield {"type": "agent_start", "name": "adk-agent", "content": ""}

        tool_call_names: dict[str, str] = {}  # function_call.id → tool name

        try:
            async for event in self._runner.query(
                prompt,
                user_id="agui-user",
                session_id=thread_id,
            ):
                for ev in self._translate_event(event, tool_call_names, stream_tokens):
                    yield ev
        except ClientToolPause as pause:
            interrupt_id = uuid.uuid4().hex[:12]
            payload = {
                "type": "agentflow:client_tool",
                "tool_name": pause.tool_name,
                "args": pause.tool_args,
            }
            self._paused_threads[thread_id] = {
                "id": interrupt_id,
                "value": payload,
            }
            yield {
                "type": "interrupt",
                "interrupts": [{
                    "id": interrupt_id,
                    "reason": "agentflow:client_tool",
                    "tool_name": pause.tool_name,
                    "metadata": {"args": pause.tool_args},
                }],
            }
            return

        if stream_tokens:
            yield {"type": "agent_end", "name": "adk-agent"}

    # ------------------------------------------------------------------
    # Event translation
    # ------------------------------------------------------------------

    def _translate_event(
        self,
        event: Any,
        tool_call_names: dict[str, str],
        stream_tokens: bool,
    ):
        """Translate one ADK ``Event`` into zero-or-more dict events."""
        content = getattr(event, "content", None)
        if content is None:
            return
        parts = getattr(content, "parts", None) or []
        author = getattr(event, "author", "") or "adk-agent"
        partial = bool(getattr(event, "partial", False))

        for part in parts:
            text = getattr(part, "text", None)
            fcall = getattr(part, "function_call", None)
            fresp = getattr(part, "function_response", None)

            if text and not (fcall or fresp):
                # Text chunk. Partial = token delta; final = whole text.
                if stream_tokens or partial:
                    yield {"type": "token", "name": author, "content": text}
                else:
                    yield {"type": "agent", "name": author, "content": text}

            if fcall is not None:
                call_id = getattr(fcall, "id", None) or ""
                name = getattr(fcall, "name", "") or "tool"
                args = getattr(fcall, "args", None) or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {"raw": args}
                tool_call_names[call_id] = name
                yield {
                    "type": "tool_call",
                    "name": name,
                    "args": args if isinstance(args, dict) else {"raw": str(args)},
                }

            if fresp is not None:
                call_id = getattr(fresp, "id", None) or ""
                name = (
                    getattr(fresp, "name", None)
                    or tool_call_names.get(call_id, "")
                )
                response = getattr(fresp, "response", None)
                payload: Any = response
                # ADK wraps the tool's return in a dict like {"result": <str>}.
                if isinstance(response, dict) and "result" in response and len(response) == 1:
                    inner = response["result"]
                    if isinstance(inner, str):
                        try:
                            payload = json.loads(inner)
                        except Exception:
                            payload = inner
                    else:
                        payload = inner
                yield {
                    "type": "tool",
                    "name": name,
                    "content": payload,
                }
