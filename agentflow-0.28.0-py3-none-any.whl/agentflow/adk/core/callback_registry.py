"""Resolve ``CallbackRef`` YAML entries into Python callables.

ADK callbacks can be a single callable OR a list of callables — the SDK
normalizes them via ``canonical_*`` properties at runtime. Our schema
mirrors that: each slot is ``Optional[CallbackRef | List[CallbackRef]]``.
This registry converts the schema shape into the SDK shape (single
callable or list of callables).
"""

from __future__ import annotations

import importlib
from typing import Any, Callable, List, Union

from agentflow.adk.core.config_models import CallbackRef, CallbacksConfig


def resolve_one(entry: Union[CallbackRef, List[CallbackRef], None]) -> Any:
    """Resolve one slot into a callable, list of callables, or ``None``."""
    if entry is None:
        return None
    if isinstance(entry, list):
        return [_load_callable(ref) for ref in entry]
    return _load_callable(entry)


def resolve_callbacks(cfg: CallbacksConfig | None) -> dict:
    """Return the kwargs to pass to ``LlmAgent(...)`` for callback slots.

    Empty entries are omitted so the SDK gets ``None`` (its default) rather
    than an explicit empty list — same observable behaviour, but it makes
    dry-run summaries cleaner.
    """
    if cfg is None:
        return {}
    out: dict[str, Any] = {}
    slots = {
        "before_agent": "before_agent_callback",
        "after_agent": "after_agent_callback",
        "before_model": "before_model_callback",
        "after_model": "after_model_callback",
        "on_model_error": "on_model_error_callback",
        "before_tool": "before_tool_callback",
        "after_tool": "after_tool_callback",
        "on_tool_error": "on_tool_error_callback",
    }
    for yaml_name, sdk_name in slots.items():
        resolved = resolve_one(getattr(cfg, yaml_name))
        if resolved is not None:
            out[sdk_name] = resolved
    return out


def _load_callable(ref: CallbackRef) -> Callable:
    try:
        mod = importlib.import_module(ref.module)
    except ImportError as exc:
        raise ImportError(
            f"Callback module {ref.module!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, ref.function, None)
    if fn is None:
        raise AttributeError(
            f"Callback module {ref.module!r} has no function {ref.function!r}"
        )
    if not callable(fn):
        raise TypeError(
            f"Callback {ref.module}.{ref.function} is not callable"
        )
    return fn
