"""Resolve ``PluginRef`` YAML entries into Python callables ADK can use.

ADK accepts plain Python callables in ``LlmAgent.tools=[...]`` — they're
automatically wrapped in ``FunctionTool``. There's no decorator
requirement (unlike workflows / cas, which use langchain's ``@tool``).

Discovery rules:

- If ``functions:`` is provided, import exactly those names.
- Otherwise, take every public top-level callable defined in the module
  (i.e. ``not name.startswith('_')`` and ``getattr(obj, '__module__') ==
  module_path``). The module-equality check excludes things imported from
  elsewhere.

Empty modules raise a clear error rather than silently registering zero
tools — that mistake otherwise surfaces as "the agent doesn't seem to
know about my tools" minutes later in production.
"""

from __future__ import annotations

import importlib
import inspect
from typing import Callable, List

from agentflow.adk.core.config_models import PluginRef, PluginType


def resolve_plugins(plugins: List[PluginRef] | None) -> List[Callable]:
    """Return one flat list of callables, ready to drop into ``tools=[...]``."""
    if not plugins:
        return []

    out: List[Callable] = []
    for ref in plugins:
        if ref.type != PluginType.PYTHON:  # pragma: no cover - schema enforces
            raise ValueError(
                f"Plugin type {ref.type.value!r} not supported. "
                f"Only 'python' works in v1."
            )
        callables = _load_callables(ref.module, ref.functions)
        if not callables:
            raise ValueError(
                f"Plugin {ref.name!r}: no tool functions found in {ref.module!r}"
                + (f" (filter: {ref.functions})" if ref.functions else "")
            )
        out.extend(callables)
    return out


def _load_callables(module_path: str, filter_names: List[str] | None) -> List[Callable]:
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Plugin module {module_path!r} could not be imported: {exc}. "
            f"Is it on PYTHONPATH? Is the package installed?"
        ) from exc

    if filter_names:
        out: List[Callable] = []
        for name in filter_names:
            obj = getattr(mod, name, None)
            if obj is None:
                raise AttributeError(
                    f"Plugin module {module_path!r} has no attribute {name!r}"
                )
            if not callable(obj):
                raise TypeError(
                    f"Plugin {module_path}.{name} is not callable"
                )
            out.append(obj)
        return out

    # Default: every public callable defined in this module
    return [
        obj
        for name, obj in vars(mod).items()
        if not name.startswith("_")
        and callable(obj)
        and not inspect.isclass(obj)
        and not inspect.ismodule(obj)
        and getattr(obj, "__module__", None) == module_path
    ]
