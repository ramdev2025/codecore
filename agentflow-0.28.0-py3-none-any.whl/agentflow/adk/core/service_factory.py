"""Resolve ``LLMConfig`` into the value(s) ADK's ``LlmAgent(model=...)`` accepts.

ADK's ``LlmAgent.model`` accepts either:

- a plain string — Gemini model name; ADK's internal Gemini client picks it up
- a ``BaseLlm`` instance — for non-Gemini providers, wrapped via ``LiteLlm``
  or any custom subclass

This factory walks the four providers we support and returns the right
object plus any environment side-effects required (e.g. setting
``GOOGLE_GENAI_USE_VERTEXAI=TRUE`` for the ``vertex`` provider before the
SDK reads it).
"""

from __future__ import annotations

import importlib
import os
from typing import Any, Tuple, Union

from agentflow.adk.core.config_models import LLMConfig, LLMProvider


def resolve_model(llm: LLMConfig) -> Tuple[Union[str, Any], dict]:
    """Return ``(model_value, env_side_effects)`` for the given LLM config.

    ``model_value`` is either a string (Gemini direct) or a ``BaseLlm``
    instance (LiteLlm / custom). ``env_side_effects`` is a dict of env
    vars set by the caller via ``os.environ.update(...)`` before constructing
    the agent — kept explicit so unit tests can verify the side effects
    without actually mutating the process environment.
    """

    if llm.provider == LLMProvider.GEMINI:
        return _resolve_gemini(llm)
    if llm.provider == LLMProvider.VERTEX:
        return _resolve_vertex(llm)
    if llm.provider == LLMProvider.LITELLM:
        return _resolve_litellm(llm)
    if llm.provider == LLMProvider.AZURE_OPENAI:
        return _resolve_azure_openai(llm)
    if llm.provider == LLMProvider.CUSTOM:
        return _resolve_custom(llm)
    raise ValueError(f"Unsupported LLM provider: {llm.provider!r}")  # pragma: no cover


def _resolve_gemini(llm: LLMConfig) -> Tuple[str, dict]:
    cfg = dict(llm.config)
    model = cfg.pop("model")
    env: dict[str, str] = {"GOOGLE_GENAI_USE_VERTEXAI": "FALSE"}
    if api_key := cfg.pop("api_key", None):
        env["GOOGLE_API_KEY"] = api_key
    return model, env


def _resolve_vertex(llm: LLMConfig) -> Tuple[str, dict]:
    cfg = dict(llm.config)
    model = cfg.pop("model")
    env: dict[str, str] = {"GOOGLE_GENAI_USE_VERTEXAI": "TRUE"}
    if project := cfg.pop("project", None):
        env["GOOGLE_CLOUD_PROJECT"] = project
    if location := cfg.pop("location", None):
        env["GOOGLE_CLOUD_LOCATION"] = location
    return model, env


def _resolve_litellm(llm: LLMConfig) -> Tuple[Any, dict]:
    """Wrap the model in ``LiteLlm(model=..., **extras)``.

    Requires ``pip install google-adk[extensions]``. We surface a clear
    install hint if the import fails, since ``ImportError: LiteLLM
    support requires...`` is the SDK's exact message but easy to miss
    in a stack trace.

    For ``azure/<deployment>`` models, we also flip
    ``litellm.enable_azure_ad_token_refresh = True`` so
    ``DefaultAzureCredential`` (Managed Identity / ``az login`` /
    Service Principal env vars) is used when no explicit
    ``api_key`` / ``azure_ad_token_provider`` is supplied. This means
    Azure RBAC works out of the box without needing a custom
    ``LiteLlm`` subclass.
    """

    try:
        from google.adk.models.lite_llm import LiteLlm  # lazy
    except ImportError as exc:
        raise ImportError(
            "LLM provider 'litellm' requires the [extensions] extra. "
            "Install with: pip install 'google-adk[extensions]'"
        ) from exc

    cfg = dict(llm.config)
    model = cfg.pop("model")
    env: dict[str, str] = {}
    # Bridge api_key into the right provider env var (LiteLLM reads from env
    # by convention). Users can also set the env var directly.
    if api_key := cfg.pop("api_key", None):
        env_var = _litellm_env_var_for(model)
        if env_var:
            env[env_var] = api_key

    # Azure RBAC: flip the auto-refresh flag so DefaultAzureCredential is
    # used when api_key isn't set. Idempotent — safe to set every time.
    if model.startswith("azure/"):
        _enable_azure_ad_token_refresh()

    return LiteLlm(model=model, **cfg), env


def _resolve_azure_openai(llm: LLMConfig) -> Tuple[Any, dict]:
    """Turn-key Azure OpenAI provider — RBAC by default, API key optional.

    YAML schema::

        llm:
          provider: azure_openai
          config:
            model: ${AZURE_DEPLOYMENT}              # the deployment name
            azure_endpoint: ${AZURE_OPENAI_ENDPOINT}  # optional (env fallback)
            api_version: ${OPENAI_API_VERSION}        # optional (env fallback)
            azure_identity: true                      # default; flips RBAC on
            # api_key: ${AZURE_API_KEY}               # alternative to RBAC

    Internally builds a ``LiteLlm`` instance with model
    ``azure/<deployment>`` and wires ``litellm.enable_azure_ad_token_refresh``
    so ``DefaultAzureCredential`` is used. Mirrors the workflows backend's
    turn-key Azure RBAC path.

    Required env / config (in priority order):

    - **endpoint**: ``config.azure_endpoint`` → ``AZURE_OPENAI_ENDPOINT``
    - **api_version**: ``config.api_version`` → ``OPENAI_API_VERSION``
    - **deployment**: ``config.model`` (required)

    Auth: if ``azure_identity: true`` (default) — RBAC via
    ``DefaultAzureCredential``. Else if ``config.api_key`` or
    ``AZURE_API_KEY`` is set — bridged through. Else: still RBAC, since
    LiteLLM's auto-refresh kicks in with no key.
    """

    try:
        from google.adk.models.lite_llm import LiteLlm  # lazy
    except ImportError as exc:
        raise ImportError(
            "LLM provider 'azure_openai' requires the [adk-extensions] extra. "
            "Install with: pip install 'agentflow[adk-extensions]'"
        ) from exc

    cfg = dict(llm.config)
    deployment = cfg.pop("model")
    azure_identity = cfg.pop("azure_identity", True)  # RBAC by default

    # Endpoint — config wins, then AZURE_OPENAI_ENDPOINT
    endpoint = (
        cfg.pop("azure_endpoint", None)
        or cfg.pop("api_base", None)
        or os.environ.get("AZURE_OPENAI_ENDPOINT")
    )
    if not endpoint:
        raise ValueError(
            "provider 'azure_openai' requires either 'azure_endpoint' / "
            "'api_base' in config or AZURE_OPENAI_ENDPOINT env var"
        )

    # API version — config wins, then OPENAI_API_VERSION
    api_version = (
        cfg.pop("api_version", None)
        or os.environ.get("OPENAI_API_VERSION")
    )

    # Auth — RBAC first, then explicit API key, then env var
    api_key = cfg.pop("api_key", None) or os.environ.get("AZURE_API_KEY")

    env: dict[str, str] = {}
    kwargs: dict[str, Any] = {
        "model": f"azure/{deployment}",
        "api_base": endpoint,
    }
    if api_version:
        kwargs["api_version"] = api_version

    if azure_identity or not api_key:
        # Auto-refresh flag — LiteLLM picks up DefaultAzureCredential.
        # No subclassing, no token-provider callable. Idempotent.
        _enable_azure_ad_token_refresh()
    elif api_key:
        kwargs["api_key"] = api_key

    # Pass remaining cfg keys through (temperature, max_tokens, etc.)
    kwargs.update(cfg)
    return LiteLlm(**kwargs), env


def _enable_azure_ad_token_refresh() -> None:
    """Flip ``litellm.enable_azure_ad_token_refresh = True``.

    Lazy import; idempotent. Silently no-ops if litellm isn't importable
    (the LiteLlm import in the caller will surface a clearer error).
    """
    try:
        import litellm  # type: ignore[import-not-found]
        litellm.enable_azure_ad_token_refresh = True
    except ImportError:
        pass


def _litellm_env_var_for(model: str) -> str | None:
    """Map a LiteLLM model prefix to the env var the wrapper expects."""
    mapping = {
        "openai/": "OPENAI_API_KEY",
        "anthropic/": "ANTHROPIC_API_KEY",
        "azure/": "AZURE_API_KEY",
        "cohere/": "COHERE_API_KEY",
        "mistral/": "MISTRAL_API_KEY",
        "groq/": "GROQ_API_KEY",
        "together_ai/": "TOGETHER_API_KEY",
    }
    for prefix, var in mapping.items():
        if model.startswith(prefix):
            return var
    return None


def _resolve_custom(llm: LLMConfig) -> Tuple[Any, dict]:
    """Import a user-defined ``BaseLlm`` subclass and instantiate it.

    The class must accept the remaining ``config`` keys as keyword arguments.
    """

    cfg = dict(llm.config)
    module_path = cfg.pop("module")
    class_name = cfg.pop("class")
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Custom LLM module {module_path!r} could not be imported: {exc}"
        ) from exc
    cls = getattr(mod, class_name, None)
    if cls is None:
        raise AttributeError(
            f"Custom LLM module {module_path!r} has no attribute {class_name!r}"
        )
    return cls(**cfg), {}


def apply_env_side_effects(env: dict) -> None:
    """Apply env-var side effects to the process environment.

    Kept as a separate helper so unit tests can inspect ``env`` without
    mutating ``os.environ``.
    """
    for key, value in env.items():
        os.environ[key] = value
