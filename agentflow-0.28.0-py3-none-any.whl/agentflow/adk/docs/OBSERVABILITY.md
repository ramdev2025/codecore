# Observability

Three sources of telemetry overlap on ADK, and you'll usually want them all:

1. **ADK's native GenAI spans** — emitted automatically when ADK's diagnostic instrumentation is on
2. **AgentFlow root + observer spans** — `agentflow.adk.run` wraps each query; `audit_log` / `cost_tracking` / `latency_tracking` observers emit their own
3. **Your tools / callbacks / plugins** — anything you instrument lands on the same provider

## Enable tracing

Opt in via env vars:

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
export OTEL_EXPORTER_OTLP_PROTOCOL=grpc      # or http/protobuf
export OTEL_SERVICE_NAME=my-agent             # default: agentflow
```

Then run as usual:

```bash
agentflow "..."
```

`agentflow.adk.telemetry.setup_tracing()` installs the global `TracerProvider` once per process. Idempotent.

## Span catalog

| Span | Source | Attributes |
|---|---|---|
| `agentflow.adk.run` | CLI driver | `agentflow.backend`, `agentflow.thread_id`, `agentflow.session_id` |
| `gen_ai.execute_tool` | `audit_log` observer | `gen_ai.tool.name` |
| `agentflow.tool.latency` | `latency_tracking` observer | `gen_ai.tool.name`, `agentflow.tool.latency_ms` |
| `gen_ai.session_summary` | `cost_tracking` observer (run end) | `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.usage.cached_tokens`, `gen_ai.usage.thinking_tokens` |
| `agent.run.<name>` | ADK native (when enabled) | depends on ADK version |
| `gen_ai.completion` | ADK native | model name, prompt/completion tokens |

`gen_ai.*` semantic conventions match the OpenTelemetry GenAI spec, so spans render cleanly in Jaeger / Tempo / Datadog / Phoenix / Langfuse.

## Recipes

### Jaeger (local dev)

```bash
docker run -d --name jaeger \
    -e COLLECTOR_OTLP_ENABLED=true \
    -p 16686:16686 -p 4317:4317 -p 4318:4318 \
    jaegertracing/all-in-one:latest

OTEL_TRACES_ENABLED=true \
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317 \
agentflow "..."

# Open http://localhost:16686 → service "agentflow"
```

### Phoenix (Arize)

```bash
pip install arize-phoenix
phoenix serve  # → http://localhost:6006

OTEL_TRACES_ENABLED=true \
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006/v1/traces \
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf \
agentflow "..."
```

### Langfuse

```bash
OTEL_TRACES_ENABLED=true \
OTEL_EXPORTER_OTLP_ENDPOINT=https://cloud.langfuse.com/api/public/otel \
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf \
OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic $(echo -n pk-lf-xxx:sk-lf-xxx | base64)" \
agentflow "..."
```

### Cloud collectors

Datadog / New Relic / Honeycomb all accept OTLP. Set:

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=https://otlp.<vendor>/...
export OTEL_EXPORTER_OTLP_HEADERS="api-key=..."
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

Vendor docs: [Datadog OTLP](https://docs.datadoghq.com/opentelemetry/), [New Relic OTLP](https://docs.newrelic.com/docs/opentelemetry/), [Honeycomb OTLP](https://docs.honeycomb.io/get-started/start-building/application/start-receiving-data/).

### Google Cloud Trace

When running on Vertex AI, ADK's native diagnostics route to Cloud Trace automatically. Outside of Vertex, install the GCP exporter:

```bash
pip install opentelemetry-exporter-gcp-trace
```

Then point `OTEL_EXPORTER_OTLP_ENDPOINT` at a local OpenTelemetry Collector configured with the GCP exporter, or write a tiny bootstrap that swaps in `CloudTraceSpanExporter` directly.

### Azure Monitor (Application Insights / Azure AI Foundry)

Install the built-in exporter extra and set the connection string — no code:

```bash
pip install 'agentflow[azure-monitor]'
OTEL_TRACES_ENABLED=true
APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=https://..."
```

The exporter attaches automatically through AgentFlow's shared exporter seam
(`agentflow.core.telemetry_seam`) — additively, so any OTLP export keeps working
alongside Azure (dual-export). Application Insights can't ingest raw OTLP; this
extra's `AzureMonitorTraceExporter` is the translator. Spans appear in App
Insights and, once that resource is linked to a Foundry project, in the Foundry
Tracing tab.

## Cost tracking

The `cost_tracking` observer aggregates `Event.usage_metadata` across every model event in a run and emits one `gen_ai.session_summary` span at the end:

```yaml
observers:
  - { type: cost_tracking }
```

Attributes:

- `gen_ai.usage.input_tokens` — `prompt_token_count` totals
- `gen_ai.usage.output_tokens` — `candidates_token_count` totals
- `gen_ai.usage.cached_tokens` — `cached_content_token_count` totals (prompt-cache hits)
- `gen_ai.usage.thinking_tokens` — `thoughts_token_count` totals (Gemini extended thinking)

ADK doesn't emit a single terminal "session summary" message like CAS's `ResultMessage`, so the observer aggregates events from `on_event_callback` and reports at `after_run_callback`.

## Per-tool latency

```yaml
observers:
  - { type: latency_tracking }
```

Records start time on `before_tool_callback`, computes elapsed on `after_tool_callback`, emits an `agentflow.tool.latency` span with `agentflow.tool.latency_ms`.

## Audit log

```yaml
observers:
  - { type: audit_log }
```

Logs to `agentflow.adk.audit` (configure via `logging.dictConfig` or just `logging.getLogger`). Lines:

```
INFO  agentflow.adk.audit: tool_call name=search args={'query': 'tokyo weather'}
INFO  agentflow.adk.audit: tool_result name=search result_chars=140
```

Each tool call also opens a `gen_ai.execute_tool` span.

## Redaction

Don't ship tool args or model contents to your collector if they contain PII. Two options:

1. Add a `pii` guard to redact at the source (`guards: [{ type: pii, config: { action: redact } }]`)
2. Configure your collector / processor to strip span attributes

Option 1 is preferable — it stops PII before it leaves the agent process.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
