# Migration

Coming from another AgentFlow backend? Here's what changes and what stays the same.

## What stays the same

- **CLI** — same `agentflow` command, same flags, same auto-detection of `agent.yaml` / `workflow.yaml` / `agentflow.yaml` / `agents.yaml`
- **Cross-backend portable tier** — `guards:` / `optimizers:` / `observers:` use the same vocabulary
- **Persistence flags** — `--persistence`, `--db-path`, `--connection-string`, `--thread-id`
- **`metadata` block** — `version`, `name`, `description`, `author`, `tags` everywhere
- **Env-var interpolation** — `${VAR}` syntax loads from `.env` next to the YAML or in cwd
- **Encryption** — `AGENTFLOW_ENCRYPTION_KEY` works the same way
- **Plugin ABC** — your existing `agentflow.workflows.plugins.Plugin` subclasses run unchanged via the [Plugin Bridge](PLUGIN_BRIDGE.md)
- **Observability** — `OTEL_TRACES_ENABLED=true` opt-in; `gen_ai.*` semantic conventions

## What's specific to ADK

- `backend: adk` (not `google-adk`, not `gcp-adk`)
- `agent.type: llm | sequential | parallel | loop` discriminator (most YAML omits the default `llm`)
- LLM provider names: `gemini`, `vertex`, `litellm`, `azure_openai`, `custom`
- Built-in tool names: `google_search`, `vertex_ai_search`, `exit_loop`, ...
- State scope prefixes: `user:`, `app:`, `temp:`, plain
- Per-agent `callbacks:` block (8 slots)
- ADK-specific `plugins:` (top-level, BasePlugin refs)
- `serving:` block (Vertex AI Agent Engine deploy target)

## From workflows (LangGraph)

| Workflows | ADK equivalent |
|---|---|
| `nodes:` + `edges:` graph | Workflow agents (`sequential` / `parallel` / `loop`) or `LlmAgent.sub_agents` |
| `agents:` list with `routing:` | Single `LlmAgent` with `sub_agents` (AutoFlow) |
| `tools:` Python module | `agent.tools.plugins: [{ name, module }]` |
| `middleware:` | `optimizers` (cross-backend) or per-agent `callbacks` |
| `azure_openai` provider with RBAC | `azure_openai` provider (turn-key, v0.22.1) — same YAML shape, drop `${AZURE_OPENAI_API_KEY}` |

Workflows' explicit DAG maps cleanly to ADK's workflow agents. A `nodes/edges` graph that flows linearly is `sequential`; one that branches is `parallel`; one that iterates is `loop`. Routing is what `LlmAgent.sub_agents` + AutoFlow does natively.

## From deep (DeepAgents)

| Deep | ADK equivalent |
|---|---|
| `agent:` + `subagents:` (dict) | `agent:` (llm) + `sub_agents:` (list) |
| `task` tool delegation | AutoFlow `transfer_to_agent` (no manual tool needed) |
| `coding_agent.yaml` / `deep_agent.yaml` | `agent.yaml` (new convention) |
| LangChain/LangGraph LLM config | `llm.provider: gemini | vertex | litellm` |

Deep's main → subagents pattern is an `LlmAgent` with `sub_agents` in ADK. The shape of the YAML is similar; the mechanism underneath swaps from LangGraph subgraphs to ADK's AutoFlow.

## From sk (Semantic Kernel)

| SK | ADK equivalent |
|---|---|
| `agent:` (singular) — autonomous | `agent.type: llm` (default) |
| `agents:` (plural) + `mode: handoff` | `agent.type: llm` + `sub_agents` |
| `agents:` + `mode: process` / `magentic` | Workflow agents (`sequential` / `parallel`) |
| `services:` (multi-service kernel) | `llm` + per-agent `llm:` overrides |
| `filters:` | `callbacks:` per-agent or `plugins:` tree-wide |
| `kernel_function` decorators | Plain Python callables in `tools.plugins` |

SK's singular/plural distinction maps to the `agent.type` discriminator on ADK. Multi-service kernels translate to ADK's per-agent LLM override pattern.

## From cas (Claude Agent SDK)

| CAS | ADK equivalent |
|---|---|
| `agent:` + `subagents:` (dict) | `agent:` + `sub_agents:` (list) |
| `hooks:` (10 SDK events) | `callbacks:` (8 slots) + `plugins:` (BasePlugin) |
| `permissions:` | (no direct equivalent — use callbacks for tool-allow logic) |
| `sandbox:` | (no direct equivalent — handled at deploy time on Vertex AI) |
| `skills:` | (no direct equivalent — use Python plugins) |
| `tools.builtin:` (Bash/Read/...) | `tools.builtin:` (google_search/exit_loop/...) — different sets |

CAS and ADK have parallel architectures (Pydantic schemas, hooks-first, MCP-native, single-SDK with multi-provider via wrapper) but different built-in tool catalogs and a different permission model. Most YAML translates 1:1 with name changes.

## From oai (OpenAI Agents SDK)

| OAI | ADK equivalent |
|---|---|
| `agent:` + `handoffs:` | `agent:` + `sub_agents` (AutoFlow) |
| `agent_as_tool:` refs | `tools.agent_as_tool:` (same name!) |
| `tools.hosted` (web_search, file_search, ...) | `tools.builtin` (different names: google_search, vertex_ai_search) |
| OpenAI `Responses` API | ADK's GenAI/Vertex API |
| `guardrails:` | `guards:` (cross-backend portable tier) |

The `agent_as_tool` concept and YAML key are identical. Handoffs are ADK's AutoFlow. The hosted-tools catalog is different but the YAML structure parallel.

## From maf (Microsoft Agent Framework)

| MAF | ADK equivalent |
|---|---|
| `agent:` (singular) | `agent.type: llm` |
| `workflow:` + `executors:` + `edges:` | Workflow agents (`sequential` / `parallel` / `loop`) |
| `middleware:` | `callbacks:` (per-agent) or `optimizers:` (cross-backend) |
| `tools.hosted` | `tools.builtin` (different names) |
| Azure OpenAI / AAD turn-key | `azure_openai` provider (turn-key, v0.22.1) |

MAF's workflow primitive (`executors` + `edges` graph) is more general than ADK's three workflow agents but most real workflows reduce to sequential/parallel/loop combinations.

## YAML auto-detection

The CLI looks for these names in cwd (in order):

1. `workflow.yaml` (workflows convention)
2. `agentflow.yaml` (generic)
3. `agent.yaml` (default for ADK / deep / sk / cas / oai / maf)
4. `agents.yaml` (multi-agent / orchestrated configs)

If you have a legacy `oai_agent.yaml` / `maf_agent.yaml` / `cas_agent.yaml` / etc., either rename it or pass it explicitly via `--yaml <path>`.

## Deprecated entry points

Old per-backend commands (`agentflow`, `agentflow-cli`, `afd`) still work but print a deprecation warning. Use the unified `agentflow` command going forward.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
