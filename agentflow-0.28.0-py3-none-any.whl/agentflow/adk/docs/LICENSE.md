**Version 1.0**

**Terms of Use**
Your access to and use of this repository is subject to the following terms and conditions “Terms of Use” contained
within this document, and all applicable laws. By accessing and using this site, you accept the following terms and
conditions, without limitation or qualification:

**Conduct.** Your conduct relating to uploading, downloading, or otherwise using functions on the repository should
comply with these Terms of Use as well as Accenture Policies and our Code of Business Ethics (COBE). Policies with
particular relevance include Policy 1010 – Artificial Intelligence, Policy 57 – Acceptable Use of Information, Devices,
and Technology, Policy 69 – Confidentiality, Policy 1001 – Respecting the Individual, Policy 91 – Intellectual Property,
and Open Source Software, Policy 314.

**Accenture Internal Open-source Agreement.**  All projects, and their contents, hosted in the repository are visible to
those members granted access. All projects must be contributed and utilized in accordance with the terms of this
section, including the Internal Code License below. For clarity, all contributions and accepted projects are subject to
review and removal by the repository’s admin team for any reason.

1. **Contributions**. Members may contribute source code to the repository by submitting a pull request for review.
   Submissions must contain source code only, and such code must be Accenture’s confidential information and
   intellectual property, and/or otherwise subject to a permissive open-source license. Contributions which include
   open-source licensed code must include appropriate citations and complete details of any license. You can consult the
   Open Source Software Resource Site for further information about the proper use of open-source. Submissions should
   not contain third-party owned or otherwise restricted source code. Accepted submissions and any code included in the
   repository is subject to the Internal Code License below.
2. **Internal Code License.** Users who properly submit a pull request grant to other members of the repository a
   perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare
   derivative works of, publicly display, publicly perform, sublicense, and distribute the project code and any
   derivative works for their Accenture business purposes only. Except as set out above, submitters keep all right,
   title, and interest in their code contribution.
3. **Code Usage Requirements**. Any member who utilizes repository code should properly attribute such code in any
   project documentation (i.e. by adding such attribution in their code repository README file) and make their
   derivative project and all its code available under the terms of the Internal Code License above.
4. **Legal.** Before using repository code in a client engagement, contact your local Contract Manager (CM) or
   Contracting Legal Professional (CLP) to assist with drafting the client agreement and ensuring that proper
   intellectual property terms are included. Before using repository code in an Accenture solution and/or offering,
   please contact Accenture Legal for relevant product and/or industry legal counsel as necessary. These terms do not
   replace any existing asset review requirements or onboarding processes (e.g., Accenture Reinvention Console, Global
   Legal Review). Users must likewise ensure that using such code in the market complies with local trade controls
   requirements using ECATT and in accordance with Accenture Policy 1254, International Trade Controls.
5. **Limitations.** All repository projects, and their contents, are provided on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR CONDITIONS OF
   TITLE, NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. CONTRIBUTORS MUST PROVIDE NO
   ADDITIONAL UPDATES, SUPPORT, MAINTENANCE, SERVICES OR INFORMATION OF ANY KIND.

**Consequences.** Violations of Accenture Policies or these Terms of Use may result in appropriate, lawful discipline,
including removal of submissions or revocation of access and credentials.