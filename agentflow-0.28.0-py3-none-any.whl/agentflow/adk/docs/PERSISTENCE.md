# Persistence

ADK has its own `SessionService` for storing conversation history. AgentFlow adds a thin **thread-id ↔ session-id binding** so the user-facing `--thread-id` flag resumes the same ADK session across processes. Together they give you:

- **`thread_id` (yours)** — the stable name you pass via `--thread-id alice`
- **`session_id` (ADK)** — the UUID ADK generates for an internal session
- **AgentFlow binding** — stores `{thread_id: session_id}` mapping (with optional encryption)
- **ADK SessionService** — stores the actual conversation events keyed by `session_id`

Configure persistence at deploy time via CLI flags or environment
variables — not in the YAML. (See the deprecation note below.)

## CLI flags

```bash
# In-memory: lost on process exit; --thread-id has no effect
agentflow --persistence memory "..."

# SQLite (default)
agentflow --thread-id alice "Hi, I'm Alice."
agentflow --thread-id alice "What's my name?"

# Custom SQLite path
agentflow --persistence sqlite --db-path ./project.db --thread-id alice "..."

# Postgres
agentflow --persistence postgres \
    --connection-string "postgresql://user:pass@host/db" \
    --thread-id alice "..."
```

## Environment variables

For containerized deployments where CLI flags are inconvenient:

| Variable                     | Effect                                                                                  |
| ---------------------------- | --------------------------------------------------------------------------------------- |
| `AGENTFLOW_PERSISTENCE`      | Backend selector: `memory` / `sqlite` / `postgres` (used when `--persistence` is unset) |
| `POSTGRES_CONNECTION_STRING` | Postgres DSN (used when `--connection-string` is unset)                                 |
| `CHECKPOINTER_DB_PATH`       | SQLite path (used when `--db-path` is unset)                                            |

Resolution order: CLI flag > env var > default (sqlite). Both the
ADK `SessionService` and the AgentFlow thread-id ↔ session-id binding
table track the same backend.

> **Connection resilience.** The binding table opens a Postgres connection per
> operation via `asyncpg` and closes it again, so it is not exposed to the
> stale-connection failure fixed in 0.28.0. Session storage itself goes through
> ADK's own `DatabaseSessionService`, whose SQLAlchemy engine and connection
> handling are owned by `google-adk` rather than AgentFlow. The
> `POSTGRES_POOL_*` tuning vars apply to the `workflows` and `deep` backends
> only and have no effect here.

## YAML (deprecated for memory / sqlite / postgres)

A top-level `persistence:` section in the YAML is **deprecated** for
the memory / sqlite / postgres backends. ADK will log a warning at
startup naming the offending YAML, then ignore the block in favor of
CLI flags / env vars. Remove the section to silence the warning.

The `vertex` type is the one exception — it still requires YAML
because there's no CLI/env equivalent for `project`, `location`, and
`agent_engine_id` yet:

```yaml
persistence:
  type: vertex                    # only YAML-supported type going forward
  project: my-project
  location: us-central1
  agent_engine_id: "1234"
```

(For pre-deprecation reference, the full schema accepted: `type` —
`in_memory` / `sqlite` / `postgres` / `vertex`; `db_path` — sqlite
only; `connection_string` — postgres only; `project` / `location` /
`agent_engine_id` — vertex only.)

## State scoping prefixes

ADK's session state is a flat dict, but key prefixes change scope:

| Prefix | Scope | Use for |
|---|---|---|
| _(none)_ | Current session | Conversation-local data |
| `user:` | All sessions for that `user_id` | User profile, preferences |
| `app:` | All users in the app | Global config |
| `temp:` | Current invocation only | Scratch / never persisted |

```python
context.state["draft"] = "..."           # this session only
context.state["user:profile"] = {...}    # follows the user across sessions
context.state["app:flags"] = {...}       # global to all users
context.state["temp:scratch"] = "..."    # gone after this turn
```

These prefixes are runtime concerns — the YAML schema accepts plain strings everywhere a state key appears (`output_key:`, `instruction:` templates) and the prefix is applied at runtime by ADK.

## Encryption

Set `AGENTFLOW_ENCRYPTION_KEY` (16 / 24 / 32 bytes) to encrypt the thread-id ↔ session-id binding at rest:

```bash
export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -base64 24 | head -c 32)"
agentflow --thread-id sensitive "..."
```

Stored values are AES-GCM with a fresh nonce per write. Reading a stored binding without the key (or with the wrong key) raises a clear error. ADK's `SessionService` itself handles its own encryption-at-rest separately (e.g. CMEK on Vertex AI Sessions).

## Async-driver gotcha (sqlite / postgres)

ADK's `DatabaseSessionService` requires async SQLAlchemy drivers — the plain sync `sqlite:///...` URL fails with a cryptic `InvalidRequestError`. The builder auto-upgrades:

- `sqlite:///path` → `sqlite+aiosqlite:///path`
- `postgresql://...` → `postgresql+asyncpg://...`

If you pass a `connection_string` directly, either let the builder upgrade it or specify the async driver yourself.

## Vertex AI Sessions

```yaml
persistence:
  type: vertex
  project: my-project
  location: us-central1
  agent_engine_id: existing-engine-id
```

Authenticated via Application Default Credentials. Set up `gcloud auth application-default login` for local dev.

## FastAPI deployment

Use a single `Runner` instance per app and a long-lived `SessionService`:

```python
from fastapi import FastAPI
from contextlib import asynccontextmanager
from agentflow.adk.core.builder import AdkAgentBuilder

@asynccontextmanager
async def lifespan(app: FastAPI):
    runner = AdkAgentBuilder.from_yaml("agent.yaml").build()
    app.state.runner = runner
    yield
    # ADK runners shut down cleanly via Python's atexit hooks

app = FastAPI(lifespan=lifespan)

@app.post("/chat")
async def chat(thread_id: str, query: str):
    async for event in app.state.runner.query(
        query, user_id="api-user", session_id=thread_id,
    ):
        ...   # forward to client
```

## Thread management

```bash
agentflow-threads list                 # show all bindings
agentflow-threads show alice           # details for one
agentflow-threads delete alice         # remove the binding (ADK session stays unless deleted separately)
agentflow-threads clear --confirm      # nuke all bindings
```

The thread management CLI works across backends. Note that deleting a binding doesn't delete the underlying ADK session — for that, use ADK's own session-management APIs.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
