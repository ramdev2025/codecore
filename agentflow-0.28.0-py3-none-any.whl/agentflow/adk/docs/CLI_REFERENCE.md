# CLI Reference

The unified `agentflow` command dispatches to the ADK runner when the YAML's `backend:` is `adk`.

## Usage

```bash
agentflow [OPTIONS] [QUERY]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `QUERY` | string | (prompted) | Task for the agent. Omit for interactive prompt or pair with `--interactive` for REPL. |
| `--yaml PATH` | path | auto-detect | YAML config path. Auto-detects `workflow.yaml` / `agentflow.yaml` / `agent.yaml` / `agents.yaml` in the cwd. |
| `--backend TEXT` | string | from YAML | Override backend detection. Set to `adk` to force ADK dispatch. |
| `--interactive` | flag | off | Continuous-conversation REPL. |
| `--dry-run` | flag | off | Validate config and print summary; no model calls. |
| `--json` | flag | off | Output dry-run summary as JSON. |
| `--thread-id TEXT` | string | random UUID | Resume the same ADK session across runs (binding stored in persistence). |
| `--persistence TEXT` | enum | `sqlite` | `memory` / `sqlite` / `postgres`. Controls both ADK's `SessionService` and our thread-id binding. |
| `--db-path PATH` | path | `.agentflow/adk_threads.db` | SQLite DB path for the thread-id binding. ADK auto-upgrades the URL to use `aiosqlite`. |
| `--connection-string TEXT` | string | (env) | PostgreSQL DSN; auto-upgraded to `postgresql+asyncpg://`. |
| `--output {tty,json,ndjson}` | enum | `tty` | Output format. `json`/`ndjson` emit one JSON event per line for CI / pipelines. |
| `--debug` | flag | off | Show full Python tracebacks. Same as `AGENTFLOW_DEBUG=1`. |
| `--verbose` / `-v` | flag | off | INFO-level logging for `agentflow.*` loggers. |
| `--ascii` | flag | off | ASCII fallbacks for unicode markers. |

Flags absorbed but not used by ADK: `--workdir`, `--no-tui`, `--tools`, `--recursion-limit`.

## Examples

### Dry-run

```bash
agentflow --yaml agent.yaml --dry-run
agentflow --yaml agent.yaml --dry-run --json | jq .
```

### One-shot

```bash
agentflow "Summarize the README"
agentflow --yaml agent.yaml --thread-id alice "What's my name?"
```

### Interactive

```bash
agentflow --interactive
```

REPL slash commands: `/help`, `/quit`, `/clear`, `/save <file>`, `/history`.

### Persistence

```bash
# In-memory (no thread continuity across processes)
agentflow --persistence memory --thread-id session-1 "..."

# SQLite (default)
agentflow --thread-id session-1 "Hi, I'm Alice."
agentflow --thread-id session-1 "What's my name?"

# Postgres
agentflow --persistence postgres \
  --connection-string "postgresql://user:pass@host/db" \
  --thread-id session-1 "..."
```

### Encryption

Set `AGENTFLOW_ENCRYPTION_KEY` (16 / 24 / 32 bytes) to encrypt the thread-id ↔ session-id binding at rest:

```bash
export AGENTFLOW_ENCRYPTION_KEY="$(openssl rand -base64 24 | head -c 32)"
agentflow --thread-id sensitive "..."
```

### JSON streaming output

```bash
agentflow --output ndjson "..." | jq -r 'select(.type == "tool") | "\(.tool_name): \(.result)"'
```

Event types emitted: `tool_call`, `tool`, `agent_switch`, `reasoning`, `token`, `stats`, `complete`, `error`.

## Environment variables

| Variable | Purpose |
|---|---|
| `GOOGLE_API_KEY` | Google AI Studio (default Gemini path) |
| `GOOGLE_CLOUD_PROJECT` / `GOOGLE_CLOUD_LOCATION` / `GOOGLE_GENAI_USE_VERTEXAI` | Vertex AI |
| `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / etc. | LiteLLM-routed providers |
| `AGENTFLOW_ENCRYPTION_KEY` | Persistence encryption key |
| `AGENTFLOW_DEBUG=1` | Show full tracebacks |
| `AGENTFLOW_LOG_LEVEL` | Log level for `agentflow.*` (default WARNING) |
| `OTEL_TRACES_ENABLED=true` | Enable OpenTelemetry tracing |
| `OTEL_EXPORTER_OTLP_ENDPOINT` / `OTEL_EXPORTER_OTLP_PROTOCOL` | OTLP exporter target |
| `OTEL_SERVICE_NAME` | Override service name (default `agentflow`) |

## Auxiliary commands

```bash
# Scaffold a new ADK project
agentflow-init --backend adk --name my-agent

# Serve docs (auto-detects ADK if installed)
agentflow-docs --backend adk        # → http://127.0.0.1:9600
agentflow docs                  # direct alias

# Manage threads (cross-backend)
agentflow-threads list
agentflow-threads delete <thread-id>
agentflow-threads clear --confirm
```

## Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Generic error (config invalid, missing env var, API failure) |
| 2 | CLI usage error (e.g. `--clear` without `--confirm`) |
| 130 | Interrupted (Ctrl-C) |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
