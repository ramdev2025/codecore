# Modes

ADK exposes four agent classes — `LlmAgent` (autonomous) plus three deterministic workflow agents. The YAML schema surfaces all four through a single `agent:` root keyed by `type:`.

## `type: llm` — autonomous

```yaml
agent:
  name: assistant
  type: llm                       # default; may be omitted
  instruction: You are helpful.
```

The LLM drives the conversation. Tools run when the model calls them. Sub-agents (if declared) are reachable via `transfer_to_agent`. Best for open-ended dialogue, agentic tool-use, and routing problems.

## `type: sequential` — fixed-order pipeline

```yaml
agent:
  name: research-pipeline
  type: sequential
  sub_agents:
    - { name: gather, instruction: "Find facts.", output_key: facts }
    - { name: synthesize, instruction: "Summarize: {facts}" }
```

Children run in order. State is the bus: each agent's `output_key` writes to session state; later agents `{key}`-template-substitute it in their `instruction`. Best for ETL-style flows and step-stepped reasoning.

## `type: parallel` — concurrent fan-out

```yaml
agent:
  name: fan-out
  type: parallel
  sub_agents:
    - { name: search_a, instruction: "Search topic A.", output_key: a }
    - { name: search_b, instruction: "Search topic B.", output_key: b }
    - { name: search_c, instruction: "Search topic C.", output_key: c }
```

All children run concurrently against independent state. Outputs land in their `output_key`s. Best when sub-tasks don't depend on each other (search fan-out, multi-perspective evaluation).

To re-aggregate, follow with a `sequential` whose final child reads the per-branch keys:

```yaml
agent:
  name: research
  type: sequential
  sub_agents:
    - { name: fan-out, type: parallel, sub_agents: [...] }
    - { name: combine, instruction: "Merge {a}, {b}, {c}." }
```

## `type: loop` — repeat until done

```yaml
agent:
  name: refiner
  type: loop
  max_iterations: 5               # optional cap
  sub_agents:
    - { name: critic, instruction: "..." }
    - { name: rewriter, instruction: "..." }
```

Children run sequentially each iteration. The loop terminates on:

- `max_iterations` reached (if set)
- Any sub-agent setting `context.actions.escalate = True` — typically by calling the `exit_loop` built-in tool

```yaml
sub_agents:
  - name: critic
    tools: { builtin: [exit_loop] }
    instruction: |
      Review the draft. Call exit_loop when satisfied.
```

## Nesting

Workflow agents can contain other workflow agents:

```yaml
agent:
  name: pipeline
  type: sequential
  sub_agents:
    - name: research
      type: parallel
      sub_agents: [ ... ]
    - name: refine
      type: loop
      max_iterations: 3
      sub_agents: [ ... ]
    - name: render
      type: llm
      instruction: "Format the result for delivery."
```

Sub-tree depth is unlimited; the only constraint is unique `name`s across the whole tree (ADK's `find_agent(name)` requires uniqueness for transfer routing).

## Picking the right mode

| Goal | Mode |
|---|---|
| Open-ended chat, tool-use, routing | `llm` |
| Fixed pipeline of steps | `sequential` |
| Independent sub-tasks, fan-out | `parallel` |
| Iterate until quality threshold met | `loop` |
| Mix of the above | nest them |

If you're not sure, start with `llm` and add structure only when the model clearly needs it. Workflow agents trade flexibility for determinism.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
