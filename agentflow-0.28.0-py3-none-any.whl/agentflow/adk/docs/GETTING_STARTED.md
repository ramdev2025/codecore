# Getting Started

Builds a real ADK agent end-to-end — first an autonomous one, then a sequential workflow, then a tool plugin.

## Prerequisites

```bash
pip install 'agentflow[adk]'
export GOOGLE_API_KEY=...   # Google AI Studio
```

For Vertex AI instead, set:

```bash
export GOOGLE_GENAI_USE_VERTEXAI=TRUE
export GOOGLE_CLOUD_PROJECT=your-project
export GOOGLE_CLOUD_LOCATION=us-central1
```

## Your first agent

```yaml
# agent.yaml
backend: adk
metadata: { version: "1.0", name: assistant }
llm:
  provider: gemini
  config: { model: gemini-2.5-flash }
agent:
  name: assistant
  instruction: You are a concise, friendly assistant.
```

Run:

```bash
agentflow "What is AgentFlow?"
```

Add `--dry-run` to validate without calling the model:

```bash
agentflow --yaml agent.yaml --dry-run
```

## Adding tools

ADK accepts plain Python callables; AgentFlow wires them via `plugins:`.

```python
# tools.py
def get_weather(city: str) -> dict:
    """Get the current weather for a city."""
    return {"city": city, "temp_c": 22, "condition": "sunny"}
```

```yaml
agent:
  name: assistant
  instruction: |
    You answer weather questions. Use the get_weather tool.
  tools:
    plugins:
      - { name: weather, module: tools }
```

```bash
agentflow "What's the weather in Tokyo?"
```

The tool's docstring becomes its description; type hints become its JSON schema. ADK auto-wraps callables in `FunctionTool`.

## Built-in tools

ADK ships several tools you can drop in by name:

```yaml
agent:
  name: researcher
  instruction: Research and answer.
  tools:
    builtin: [google_search]
```

Available built-ins: `google_search`, `exit_loop`, `transfer_to_agent`, `get_user_choice`, `load_artifacts`, `load_memory`, `preload_memory`, `url_context`, `enterprise_web_search`, `google_maps_grounding`, `vertex_ai_search`. Some accept config:

```yaml
tools:
  builtin:
    - google_search
    - { name: vertex_ai_search, config: { data_store_id: my-corpus } }
```

## Your first workflow

`SequentialAgent` runs children in order, threading output through state.

```yaml
agent:
  name: research-pipeline
  type: sequential
  sub_agents:
    - name: gather
      instruction: Search for facts on the user's topic.
      tools: { builtin: [google_search] }
      output_key: facts
    - name: synthesize
      instruction: |
        Summarize the facts gathered. Facts: {facts}
      output_key: report
```

Each sub-agent's `output_key` writes its final response to session state. Subsequent agents can `{key}`-template-substitute it in their `instruction`.

`ParallelAgent` and `LoopAgent` work the same way (the latter accepts `max_iterations` and exits when any child sets `escalate=True`).

## Sub-agent delegation (AutoFlow)

Give an `LlmAgent` `sub_agents` and it gets ADK's `transfer_to_agent` tool automatically:

```yaml
agent:
  name: triage
  instruction: |
    Route requests to the right specialist:
    - billing questions → billing
    - technical issues → support
  sub_agents:
    - { name: billing, instruction: Handle billing. }
    - { name: support, instruction: Handle technical support. }
```

The router LLM picks a sub-agent by name; ADK's runner resumes that agent with the conversation context.

## Guards, optimizers, observers

Cross-backend portable controls work the same way they do on workflows / sk / cas:

```yaml
guards:
  - { type: pii, config: { action: redact } }
  - { type: tool_call_limit, config: { max_calls: 30 } }
optimizers:
  - { type: tool_retry, config: { max_retries: 2 } }
observers:
  - { type: audit_log }
  - { type: cost_tracking }
```

These compile to ADK `BasePlugin` instances and fire across the whole agent tree.

## Persistence

The CLI's `--thread-id` resumes the same ADK session across runs:

```bash
agentflow --thread-id alice "Hi, I'm Alice."
agentflow --thread-id alice "What's my name?"
```

By default sessions live in `.agentflow/adk_threads.db` (SQLite binding) plus ADK's own `DatabaseSessionService` for the conversation content. See [Persistence](PERSISTENCE.md) for backends and encryption.

## Where next

- [YAML Reference](YAML_REFERENCE.md) — every field
- [Modes](MODES.md) — when to use each agent type
- [Sub-agents](SUBAGENTS.md) — AutoFlow vs. AgentTool
- [LLM Services](SERVICES.md) — non-Gemini providers
- [MCP](MCP.md) — connecting MCP servers

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
