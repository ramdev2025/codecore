# AgentFlow ADK

YAML-driven agents on Google's [Agent Development Kit](https://google.github.io/adk-docs/).

The ADK backend brings ADK's dual-mode agent toolkit — **autonomous** `LlmAgent` with sub-agent delegation **and** deterministic `SequentialAgent` / `ParallelAgent` / `LoopAgent` workflows — under AgentFlow's unified YAML schema and CLI.

## Install

```bash
pip install 'agentflow[adk]'
```

For non-Gemini providers (OpenAI / Anthropic / Azure / Ollama / vLLM via LiteLLM):

```bash
pip install 'agentflow[adk-extensions]'
```

## Quick start

Create `agent.yaml`:

```yaml
backend: adk
metadata:
  version: "1.0"
  name: assistant
llm:
  provider: gemini
  config:
    model: gemini-2.5-flash
    api_key: ${GOOGLE_API_KEY}
agent:
  name: assistant
  instruction: |
    You are a helpful assistant. Answer concisely.
```

Then:

```bash
export GOOGLE_API_KEY=...
agentflow "What can you do?"
```

The CLI auto-detects `agent.yaml` (also `workflow.yaml` / `agentflow.yaml` / `agents.yaml`) and dispatches to the ADK runner.

## What the backend supports

| Feature | Status |
|---|---|
| Autonomous `LlmAgent` with `instruction` / `static_instruction` / tools | ✅ |
| Sub-agent delegation via AutoFlow `transfer_to_agent` | ✅ |
| `SequentialAgent` / `ParallelAgent` / `LoopAgent` workflows | ✅ |
| Tools: built-ins, Python `@tool` modules, `AgentTool` wrappers, MCP toolsets | ✅ |
| LLM providers: Gemini AI Studio, Vertex AI, LiteLLM, Azure OpenAI (RBAC turn-key), custom `BaseLlm` | ✅ |
| MCP transports: stdio, SSE, StreamableHTTP | ✅ |
| Persistence: in_memory, sqlite, postgres, Vertex AI Sessions | ✅ |
| Memory: in_memory, Vertex RAG, Vertex Memory Bank | ✅ |
| Artifacts: in_memory, file, GCS | ✅ |
| Per-agent callbacks (8 slots) + tree-wide `BasePlugin` | ✅ |
| Cross-backend portable tier (`guards` / `optimizers` / `observers`) | ✅ |
| Vertex AI Agent Engine deploy target | ✅ (config; deploy CLI follow-up) |
| OpenTelemetry tracing | ✅ |
| AES-GCM encryption for thread-id ↔ session-id binding | ✅ |

## Where next

- [Getting Started](GETTING_STARTED.md) — first agent, first orchestration, first plugin
- [YAML Reference](YAML_REFERENCE.md) — every field documented
- [Modes](MODES.md) — autonomous vs. workflow agent shapes
- [LLM Services](SERVICES.md) — Gemini, Vertex, LiteLLM, custom
- [Migration](MIGRATION.md) — coming from another backend

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
