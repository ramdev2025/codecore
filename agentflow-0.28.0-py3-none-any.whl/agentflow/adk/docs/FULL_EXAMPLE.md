# Full Example

A single annotated config that exercises every major feature. Use it as a reference when assembling your own production agent.

## Scenario

A customer-support triage bot:

- **Triage agent** — routes between Billing and Technical specialists, or answers simple questions itself
- **Billing specialist** — looks up invoices, processes refunds (with HITL approval over $500)
- **Technical specialist** — runs a parallel diagnostic + a refinement loop
- **Plugins** — observability plus a cost budget cap
- **Persistence** — Postgres for the binding, Vertex AI Sessions for ADK's own session store
- **Memory** — Vertex RAG over the support knowledge base

## YAML

```yaml
backend: adk

metadata:
  version: "1.0"
  name: support-triage
  description: Customer-support routing with specialists and HITL gating
  author: ai-platform
  tags: [production, support, demo]

# Default LLM — cheap default; specialists override where needed
llm:
  provider: vertex
  config:
    model: gemini-2.5-flash
    project: ${GCP_PROJECT}
    location: us-central1
    generate_content_config:
      temperature: 0.3
      max_output_tokens: 1024

# MCP server registry (referenced from per-agent tool lists)
mcp_servers:
  knowledge_base:
    transport: streamable_http
    url: ${KB_MCP_URL}
    headers: { Authorization: "Bearer ${KB_TOKEN}" }
    tool_filter: [search, get_article]

  billing_api:
    transport: stdio
    command: mcp-server-billing
    args: ["--prod"]
    env: { BILLING_API_TOKEN: ${BILLING_TOKEN} }

# ADK BasePlugin refs (registered on Runner)
plugins:
  - module: google.adk.plugins
    class: LoggingPlugin
  - module: my.plugins
    class: CostBudgetPlugin
    config: { max_usd: 10.00 }

# Cross-backend portable tier
guards:
  - { type: pii, config: { action: redact } }
  - { type: tool_call_limit, config: { max_calls: 30 } }
  - { type: input_validation, config: {
      schemas: {
        process_refund: {
          type: object,
          required: [invoice_id, amount_usd],
          properties: {
            invoice_id: { type: string },
            amount_usd: { type: number, minimum: 0 }
          }
        }
      }
    }}

optimizers:
  - { type: prompt_caching }
  - { type: tool_retry, config: { max_retries: 2 } }

observers:
  - { type: audit_log }
  - { type: cost_tracking }
  - { type: latency_tracking }

# The agent tree
agent:
  name: triage
  description: First-line support router.
  instruction: |
    You are the front-line support agent. Decide whether to:
    - Transfer to billing (invoices, refunds, payment disputes)
    - Transfer to technical (errors, performance, integration)
    - Answer the question yourself (simple FAQ)
    Be concise and empathetic.
  tools:
    builtin: [google_search]
    mcp_servers: [knowledge_base]
  callbacks:
    before_model:
      - { module: cb, function: tag_user_metadata }
      - { module: cb, function: redact_secrets }
  sub_agents:
    - name: billing
      description: |
        Handles invoices, refunds, payment disputes, subscription
        changes, and billing-cycle questions.
      instruction: |
        Resolve billing questions. Look up invoices via the
        billing_api tools. For refunds over $500, request HITL
        approval before processing.
      llm:
        provider: vertex
        config: { model: gemini-2.5-pro }   # bumps to pro for accuracy
      tools:
        builtin: [get_user_choice]          # HITL for refund approval
        mcp_servers: [billing_api, knowledge_base]
      output_key: billing_resolution

    - name: technical
      description: |
        Diagnoses technical issues. Runs parallel diagnostics and
        iterates on a fix recommendation.
      type: sequential
      sub_agents:
        # Step 1 — fan out diagnostic checks
        - name: diagnose
          type: parallel
          sub_agents:
            - name: check_logs
              instruction: |
                Look for errors in recent logs.
              tools: { mcp_servers: [knowledge_base] }
              output_key: log_findings
            - name: check_status
              instruction: |
                Check service status pages and incident reports.
              tools: { builtin: [google_search, url_context] }
              output_key: status_findings
            - name: check_config
              instruction: |
                Look up config issues for this user's account.
              tools: { mcp_servers: [knowledge_base] }
              output_key: config_findings

        # Step 2 — iterate on fix recommendation until critic approves
        - name: refine
          type: loop
          max_iterations: 3
          sub_agents:
            - name: writer
              instruction: |
                Compose a fix recommendation from:
                - Logs: {log_findings}
                - Status: {status_findings}
                - Config: {config_findings}
                Be specific and actionable.
              output_key: fix_draft
            - name: critic
              instruction: |
                Review the fix recommendation. If it's clear,
                actionable, and complete, call exit_loop.
                Otherwise return feedback for the writer.
              tools: { builtin: [exit_loop] }

        # Step 3 — render final response
        - name: respond
          instruction: |
            Reply to the user with the recommendation:
            {fix_draft}
            Be empathetic. Mention the diagnostic steps you took.

# Persistence — configured at deploy time, not in YAML:
#   export AGENTFLOW_PERSISTENCE=postgres
#   export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
# (or pass --persistence postgres --connection-string "$DATABASE_URL")
# Both the ADK SessionService and the AgentFlow thread↔session binding
# pick up the same backend. See PERSISTENCE.md for the full env-var table.

# Memory — Vertex RAG over the support knowledge base
memory:
  type: vertex_rag
  rag_corpus: ${RAG_CORPUS}
  similarity_top_k: 5

# Artifacts — GCS bucket for screenshots / file uploads
artifacts:
  type: gcs
  bucket_name: ${ARTIFACTS_BUCKET}

# Deploy target — Vertex AI Agent Engine
serving:
  type: vertex_agent_engine
  project: ${GCP_PROJECT}
  location: us-central1
  display_name: Support Triage Bot
  description: Customer support triage with specialist routing
```

## What this exercises

| Feature | Where in YAML |
|---|---|
| Top-level + per-agent LLM | `llm:` (top) + `billing.llm:` + `model:` shorthand |
| All four agent types | `triage` (llm) + `technical` (sequential) + `diagnose` (parallel) + `refine` (loop) |
| AutoFlow delegation | `triage.sub_agents` |
| Workflow nesting | `technical` has parallel + loop + final llm |
| Built-in tools | `google_search`, `url_context`, `get_user_choice`, `exit_loop` |
| MCP servers | `knowledge_base` (StreamableHTTP) + `billing_api` (stdio) |
| Per-agent callbacks | `triage.callbacks.before_model` |
| Cross-backend plugins | `plugins:` (LoggingPlugin + CostBudgetPlugin) |
| Portable guards/optimizers/observers | full set |
| State threading | `output_key` + `{key}` template substitution |
| Persistence + binding | `AGENTFLOW_PERSISTENCE=postgres` + `POSTGRES_CONNECTION_STRING` (env / CLI flags) |
| Memory | `memory:` vertex_rag |
| Artifacts | `artifacts:` gcs |
| Vertex deploy target | `serving:` |
| Env-var interpolation | `${...}` throughout |

## Running it

```bash
# Validate
agentflow --yaml support.yaml --dry-run

# One-shot
agentflow --yaml support.yaml --thread-id user-123 \
    "I was charged twice for the same invoice last month."

# Interactive
agentflow --yaml support.yaml --thread-id user-123 --interactive
```

Each turn, the streaming renderer prints:

```
▸ google_search(query=duplicate charge invoice)
← google_search result · 2.4k chars
↳ transfer to billing
▸ get_invoice(id=INV-12345)
← get_invoice result · 1.1k chars
· thinking… The user has two invoices on the same date for the
            same service — checking if one is a refund.
[final response streams here]
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
