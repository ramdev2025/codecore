# Plugin Bridge

AgentFlow has a cross-backend `Plugin` ABC at `agentflow.workflows.plugins.base.Plugin`. ADK has its own `BasePlugin`. The two have substantial overlap — both expose run / agent / model / tool lifecycle hooks — and the ADK backend bridges them transparently.

If you've written a plugin for workflows / sk / cas / oai / maf, **it works on ADK without modification**.

## Hook mapping

| AgentFlow `Plugin` event | ADK `BasePlugin` hook |
|---|---|
| `on_workflow_start` | `before_run_callback` |
| `on_workflow_end` | `after_run_callback` |
| `on_agent_start` | `before_agent_callback` |
| `on_agent_end` | `after_agent_callback` |
| `on_llm_start` | `before_model_callback` |
| `on_llm_end` | `after_model_callback` |
| `on_tool_call` | `before_tool_callback` |
| `on_tool_result` | `after_tool_callback` |
| `on_error` | `on_model_error_callback` / `on_tool_error_callback` |

Methods that aren't present on the wrapped plugin simply don't fire — duck-typed, so missing hooks aren't an error.

## Using a cross-backend plugin

Just register it as if it were a native ADK plugin:

```yaml
plugins:
  - module: my.cross_backend_plugins
    class: MyAgentFlowPlugin
    config: { ... }
```

The builder detects whether the class subclasses ADK's `BasePlugin` or AgentFlow's `Plugin` ABC:

- `BasePlugin` subclass → registered as-is
- Anything else (duck-typed `Plugin` ABC, or just an object with the right methods) → wrapped via the bridge adapter

## Authoring a portable plugin

```python
# my_plugins.py
from agentflow.workflows.plugins.base import Plugin
from agentflow.workflows.core.runtime_models import WorkflowContext
from typing import Any, Dict


class CostLogger(Plugin):
    """Logs cumulative cost across the run. Works on every backend."""

    def __init__(self):
        self.tools_called = 0
        self.total_chars = 0

    def on_tool_call(
        self,
        context: WorkflowContext,
        tool_name: str,
        inputs: Dict[str, Any],
    ) -> None:
        self.tools_called += 1

    def on_tool_result(
        self,
        context: WorkflowContext,
        tool_name: str,
        result: Any,
    ) -> None:
        self.total_chars += len(str(result))

    def on_workflow_end(
        self,
        context: WorkflowContext,
        final_state: Dict[str, Any],
        status: str = "completed",
    ) -> None:
        print(f"Run done: {self.tools_called} tools, {self.total_chars} chars total")
```

The same class registers identically on ADK, workflows, sk, cas, etc.

## Failure isolation

The bridge swallows exceptions from plugin methods (other than `GuardBlockedError`, which is a deliberate halt). A broken plugin never breaks the agent — it just stops producing useful telemetry. Plugins that need visibility into their own failures should log internally:

```python
try:
    self._send_metric(name, value)
except Exception:
    self._logger.exception("metric send failed")
```

## What doesn't bridge

A few AgentFlow `Plugin` events have no obvious ADK equivalent:

- `on_hitl_*` — ADK has its own `tool_confirmation` / `requested_tool_confirmations` mechanism
- `on_external_agent_*` — ADK doesn't surface external-agent calls as discrete events; they look like tool calls
- `on_mcp_connect` — ADK's MCP toolsets don't emit per-connect events

These methods on a portable Plugin will simply never fire on ADK. Use ADK-native callbacks (`on_event_callback`) if you need that level of granularity.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
