# MCP Integration

Model Context Protocol servers expose tools to your agent. ADK's `McpToolset` is a first-class citizen — drop it into `tools=[]` and ADK calls the tools transparently.

## Three transports

| Transport | When | YAML keys |
|---|---|---|
| `stdio` | Local subprocess (the most common case) | `command`, `args`, `env`, `timeout` |
| `streamable_http` | Remote HTTP/SSE server | `url`, `headers` |
| `sse` | Legacy SSE | `url`, `headers` |

## Top-level registry

Declare named servers once; reference them from any agent:

```yaml
mcp_servers:
  fs:
    transport: stdio
    command: mcp-server-filesystem
    args: ["/workspace"]
    env: { LOG_LEVEL: info }
    timeout: 5.0
    tool_filter: [read, write]    # optional allowlist
    tool_name_prefix: fs_         # prepended to every tool name

  search:
    transport: streamable_http
    url: https://mcp.example.com/sse
    headers:
      Authorization: "Bearer ${SEARCH_API_TOKEN}"
```

## Per-agent reference

```yaml
agent:
  name: assistant
  instruction: ...
  tools:
    mcp_servers: [fs, search]
```

The builder constructs `McpToolset` instances and adds them to the agent's `tools` list. ADK enumerates each toolset's tools at startup and exposes them to the LLM.

## Inline configuration

If you only need a server in one place, skip the top-level registry:

```yaml
agent:
  tools:
    mcp_servers:
      - { transport: stdio, command: mcp-fs, args: ["/tmp"] }
```

## Tool filtering

`tool_filter` accepts a list of tool names — only those tools are exposed to the LLM. Useful for narrowing a server's capabilities to what this agent should do:

```yaml
mcp_servers:
  fs:
    transport: stdio
    command: mcp-server-filesystem
    args: ["/workspace"]
    tool_filter: [read, search]   # no write/delete
```

## Tool name prefix

When two MCP servers expose tools with the same name (e.g. both have `search`), prefix one or both:

```yaml
mcp_servers:
  fs:
    transport: stdio
    command: mcp-fs
    tool_name_prefix: fs_         # tools become fs_search, fs_read, ...
  web:
    transport: streamable_http
    url: ...
    tool_name_prefix: web_
```

## Auth

For remote servers, bearer tokens go in headers:

```yaml
mcp_servers:
  langchain:
    transport: streamable_http
    url: https://api.example.com/mcp
    headers:
      Authorization: "Bearer ${MCP_TOKEN}"
      X-Tenant-Id: "acme-corp"
```

For OAuth flows, ADK's `McpToolset` accepts an `auth_scheme` / `auth_credential` pair. Surface those in YAML by extending the schema or by writing a custom plugin that constructs the toolset programmatically.

## stdio environment

The `env:` key controls only the subprocess's environment — it doesn't affect your agent's process. The default behaviour is to inherit nothing; explicitly forward what the server needs:

```yaml
mcp_servers:
  github:
    transport: stdio
    command: mcp-server-github
    env:
      GITHUB_PERSONAL_ACCESS_TOKEN: ${GITHUB_PAT}
```

## Verifying the connection

`agentflow --dry-run` validates the YAML structure but doesn't connect to the server. To verify a server is reachable, run a real query:

```bash
agentflow "Use the filesystem tool to list files in /workspace"
```

The streaming renderer prints `▸ tool_name(args)` lines — if a server is unreachable, you'll see the connection error in the agent's own response (the LLM sees a tool error and reports it).

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
