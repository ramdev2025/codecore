# LLM Services

ADK supports five provider paths. Pick `provider:` to match how you authenticate to the model:

| Provider | When to use | Auth |
|---|---|---|
| `gemini` | Google AI Studio (free tier, prototyping) | `GOOGLE_API_KEY` |
| `vertex` | Vertex AI (production GCP) | ADC / SA / OAuth |
| `litellm` | Anything LiteLLM supports (OpenAI, Anthropic, Azure, Ollama, vLLM…) | provider-specific env |
| `azure_openai` | Azure OpenAI with **RBAC turn-key** (no API key, no subclass) | `DefaultAzureCredential` (`az login` / Managed Identity / SP) |
| `custom` | A `BaseLlm` subclass you wrote | whatever you implement |

## `provider: gemini`

```yaml
llm:
  provider: gemini
  config:
    model: gemini-2.5-flash       # or gemini-flash-latest, gemini-2.5-pro, ...
    api_key: ${GOOGLE_API_KEY}    # optional; falls back to env var
```

Sets `GOOGLE_GENAI_USE_VERTEXAI=FALSE` and reads `GOOGLE_API_KEY` from the environment (the `api_key` field bridges to it).

## `provider: vertex`

```yaml
llm:
  provider: vertex
  config:
    model: gemini-2.5-pro
    project: my-gcp-project
    location: us-central1
```

Sets `GOOGLE_GENAI_USE_VERTEXAI=TRUE` plus `GOOGLE_CLOUD_PROJECT` / `GOOGLE_CLOUD_LOCATION` if provided. Authentication uses Application Default Credentials — `gcloud auth application-default login` for local dev, or the service account attached to the runtime in production.

## `provider: litellm` — OpenAI / Anthropic / Azure / Ollama / vLLM / …

Requires the `[adk-extensions]` extra:

```bash
pip install 'agentflow[adk-extensions]'
```

Model strings use the `<provider>/<model>` prefix LiteLLM expects:

```yaml
llm:
  provider: litellm
  config:
    model: openai/gpt-4o          # uses OPENAI_API_KEY
    api_key: ${OPENAI_API_KEY}    # optional bridge
```

```yaml
llm:
  provider: litellm
  config:
    model: anthropic/claude-opus-4-7   # uses ANTHROPIC_API_KEY
```

```yaml
llm:
  provider: litellm
  config:
    model: ollama/llama3.2        # local Ollama; no key
    api_base: http://localhost:11434
```

API-key env-var bridge by model prefix:

| Model prefix | Env var |
|---|---|
| `openai/` | `OPENAI_API_KEY` |
| `anthropic/` | `ANTHROPIC_API_KEY` |
| `azure/` | `AZURE_API_KEY` |
| `cohere/` | `COHERE_API_KEY` |
| `mistral/` | `MISTRAL_API_KEY` |
| `groq/` | `GROQ_API_KEY` |
| `together_ai/` | `TOGETHER_API_KEY` |

For models LiteLLM supports but our bridge doesn't recognize, set the env var directly.

## Azure OpenAI

Two paths.

### `provider: azure_openai` — turn-key RBAC (recommended)

The shortest path. No API key, no subclassing, no token-provider callable. Reads
`AZURE_OPENAI_ENDPOINT` / `OPENAI_API_VERSION` from the environment if you don't
supply them in `config:`. AgentFlow internally builds a `LiteLlm` wrapper with
`model = azure/<deployment>` and flips
`litellm.enable_azure_ad_token_refresh = True` so `DefaultAzureCredential`
authenticates automatically (Managed Identity, `az login`, or Service Principal
env vars).

```yaml
llm:
  provider: azure_openai
  config:
    model: ${AZURE_DEPLOYMENT}
    azure_endpoint: ${AZURE_OPENAI_ENDPOINT}    # optional; env fallback
    api_version: ${OPENAI_API_VERSION}          # optional; env fallback
    azure_identity: true                        # default
```

Requires the `[adk-extensions]` extra (`pip install agentflow[adk-extensions]`)
since this path goes through LiteLLM.

For API-key auth instead of RBAC, set `azure_identity: false` and supply
`api_key` (or set `AZURE_API_KEY` in the env).

### `provider: litellm` — direct LiteLLM with Azure prefix

Use this if you want to manage the LiteLLM kwargs yourself or already have an
existing `litellm` configuration. AgentFlow auto-flips
`enable_azure_ad_token_refresh = True` whenever the model starts with `azure/`,
so RBAC works without a subclass here too.

```yaml
llm:
  provider: litellm
  config:
    model: azure/<deployment-name>
    api_base: ${AZURE_API_BASE}
    api_version: ${AZURE_API_VERSION}
    # api_key: ${AZURE_API_KEY}    # optional — omit for RBAC
```

## `provider: custom`

For models LiteLLM doesn't support, or for adding custom retry / telemetry around an existing provider:

```python
# my_llms.py
from google.adk.models import BaseLlm

class MyCustomLlm(BaseLlm):
    def __init__(self, model: str, **kwargs):
        super().__init__(model=model)
        self.opts = kwargs

    async def generate_content_async(self, llm_request, stream=False):
        ...   # hit your endpoint, yield LlmResponse instances
```

```yaml
llm:
  provider: custom
  config:
    module: my_llms
    class: MyCustomLlm
    # any other keys are passed to MyCustomLlm.__init__
    base_url: https://my-endpoint
```

`module` and `class` are required for `custom`; everything else is forwarded as constructor kwargs.

### Subclassing `LiteLlm` as an escape hatch

`provider: custom` also accepts `LiteLlm` subclasses, which is the right pattern when the standard `azure_openai` / `litellm` paths can't express what you need:

- A non-default Azure AD scope (e.g. a Sovereign Cloud endpoint that needs `https://cognitiveservices.azure.us/.default` instead of `.com`)
- A token provider that wraps `DefaultAzureCredential` with a custom retry / cache policy
- Adding logging / cost-accounting middleware around every LiteLLM call
- An auth flow LiteLLM doesn't support natively (e.g. `azure_ad_token_provider` driven by a SAML refresh handler)

Example: a `LiteLlm` subclass that uses an explicit token-provider callable instead of relying on `enable_azure_ad_token_refresh`:

```python
# azure_llm.py
from google.adk.models.lite_llm import LiteLlm

class AzureSovereignLlm(LiteLlm):
    def __init__(self, deployment: str, endpoint: str, api_version: str, **kwargs):
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        token_provider = get_bearer_token_provider(
            DefaultAzureCredential(),
            "https://cognitiveservices.azure.us/.default",   # custom scope
        )
        super().__init__(
            model=f"azure/{deployment}",
            api_base=endpoint,
            api_version=api_version,
            azure_ad_token_provider=token_provider,
            **kwargs,
        )
```

```yaml
llm:
  provider: custom
  config:
    module: azure_llm
    class: AzureSovereignLlm
    deployment: ${AZURE_DEPLOYMENT}
    endpoint: ${AZURE_OPENAI_ENDPOINT}
    api_version: ${OPENAI_API_VERSION}
```

For the **standard** Azure RBAC case (commercial cloud, default scope), prefer `provider: azure_openai` — the subclass adds nothing the built-in path doesn't already do.

## Generation knobs (`generate_content_config`)

Forwarded to ADK's `GenerateContentConfig` for all providers:

```yaml
llm:
  provider: gemini
  config:
    model: gemini-2.5-flash
    generate_content_config:
      temperature: 0.4
      top_p: 0.9
      top_k: 40
      max_output_tokens: 2048
      stop_sequences: ["\n\n###"]
      seed: 42
```

## Per-agent override

Each agent can override the top-level LLM:

```yaml
llm:
  provider: gemini
  config: { model: gemini-2.5-flash }    # cheap default

agent:
  name: pipeline
  type: sequential
  sub_agents:
    - { name: easy, instruction: "..." }                  # uses the cheap default
    - name: hard
      instruction: "..."
      llm:
        provider: gemini
        config: { model: gemini-2.5-pro }                 # bumps to pro
```

Or use the `model:` shorthand to switch model only (keeps the top-level provider):

```yaml
sub_agents:
  - { name: hard, instruction: "...", model: gemini-2.5-pro }
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
