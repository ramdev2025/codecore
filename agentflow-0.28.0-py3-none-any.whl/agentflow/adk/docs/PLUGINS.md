# Plugins

Two distinct concepts share the word "plugin" in ADK:

| Concept | YAML field | Scope | Use for |
|---|---|---|---|
| **Tool plugins** | `agent.tools.plugins` | Per-agent | Custom Python tool functions (`@tool`-style) |
| **ADK BasePlugin** | `plugins:` (top-level) | Tree-wide | Cross-cutting concerns (logging, retry, observability) |

Built-in guards / optimizers / observers (`guards:` / `optimizers:` / `observers:`) compile to the second category; see [Guards / Optimizers / Observers](GUARDS.md).

## Tool plugins (Python `@tool` modules)

ADK accepts plain Python callables in `LlmAgent.tools=[...]`. AgentFlow's tool plugins resolve a Python module to one or more callables and register them on the agent.

### Author a tool

```python
# tools.py
def get_weather(city: str) -> dict:
    """Get the current weather for a city.

    Args:
        city: The city to look up.
    Returns:
        Dict with city, temp_c, condition.
    """
    ...
    return {"city": city, "temp_c": 22, "condition": "sunny"}
```

The docstring becomes the tool description; type hints become the JSON schema. Both sync and async functions are supported.

### Reference it

```yaml
agent:
  name: assistant
  instruction: ...
  tools:
    plugins:
      - { name: weather, module: tools }
```

If you want only a subset of the module's functions:

```yaml
plugins:
  - name: weather
    module: tools
    functions: [get_weather]      # explicit; defaults to all public callables
```

Discovery rules when `functions:` is omitted:

- Only top-level callables defined in the module (not imported)
- Public names (don't start with `_`)
- Not classes or modules

### Tool with state via `ToolContext`

ADK injects a `ToolContext` if you type-hint a parameter as `ToolContext`:

```python
from google.adk.tools import ToolContext

def remember_fact(context: ToolContext, fact: str) -> dict:
    """Save a fact for later."""
    facts = context.state.get("user:facts", [])
    facts.append(fact)
    context.state["user:facts"] = facts
    return {"saved": fact, "count": len(facts)}
```

The `user:` prefix scopes the state across all sessions for the same `user_id`. See [Persistence](PERSISTENCE.md) for scope rules.

### Long-running tools

For tools that take seconds-to-minutes, return progress events and a final result:

```python
from google.adk.tools import LongRunningFunctionTool

async def process_dataset(name: str):
    """Process a dataset (long-running)."""
    yield {"status": "started", "progress": 0}
    ...
    yield {"status": "done", "rows": 1234}
```

ADK auto-wraps a generator function in `LongRunningFunctionTool`. The agent sees streaming progress events; only the final yield is "the result".

## ADK BasePlugin refs

Tree-wide plugins. ADK runs them at the Runner level — they fire across every agent in the tree.

```yaml
plugins:
  - module: google.adk.plugins
    class: LoggingPlugin
  - module: google.adk.plugins
    class: ReflectAndRetryToolPlugin
    name: retry-with-reflection   # override BasePlugin.name
    config:
      max_retries: 3
```

Built-in plugins shipped with ADK:

- `LoggingPlugin` — verbose stdout logging of every event
- `DebugLoggingPlugin` — even more verbose
- `ReflectAndRetryToolPlugin` — re-prompts the model when a tool errors

### Authoring a custom plugin

```python
# my_plugins.py
from google.adk.plugins.base_plugin import BasePlugin
from typing import Any

class CostBudgetPlugin(BasePlugin):
    def __init__(self, max_usd: float = 5.00):
        super().__init__(name="cost_budget")
        self.max_usd = max_usd
        self._spent = 0.0

    async def on_event_callback(self, *, event: Any, **_):
        usage = getattr(event, "usage_metadata", None)
        if usage and self._estimate_cost(usage) > self.max_usd:
            raise RuntimeError(f"Cost budget exceeded ($ {self.max_usd})")

    def _estimate_cost(self, usage):
        # ...
        return 0.0
```

```yaml
plugins:
  - module: my_plugins
    class: CostBudgetPlugin
    config: { max_usd: 1.00 }
```

`BasePlugin` exposes 12 hooks: `before_run` / `after_run`, `before_agent` / `after_agent`, `before_model` / `after_model` / `on_model_error`, `before_tool` / `after_tool` / `on_tool_error`, `on_event`, `on_user_message`. Implement only the ones you need.

## Cross-backend `Plugin` ABC

If you have a plugin written against AgentFlow's portable `Plugin` ABC (works on workflows / sk / cas / maf), the ADK backend wraps it transparently — see [Plugin Bridge](PLUGIN_BRIDGE.md).

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
