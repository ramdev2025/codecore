# Sub-agents

ADK has two distinct mechanisms for one agent to call another. Both are surfaced in our YAML — pick the one that matches the relationship you want.

| Mechanism | YAML | When to use |
|---|---|---|
| **`sub_agents`** + AutoFlow `transfer_to_agent` | `agent.sub_agents: [...]` | Routing / delegation — one autonomous agent hands off to another |
| **`AgentTool`** wrapper | `agent.tools.agent_as_tool: [...]` | Tool-call style — parent calls child like a function and uses the result |

Both can coexist: an agent can `transfer_to_agent` *and* call the child as a tool.

## AutoFlow delegation (`sub_agents`)

When an `LlmAgent` has `sub_agents` and `disallow_transfer_to_*: false` (defaults), ADK adds the `transfer_to_agent` tool automatically. The router LLM picks a sub-agent by name; ADK resumes that agent with the conversation context.

```yaml
agent:
  name: triage
  instruction: |
    Route requests:
    - billing questions → billing
    - technical issues → support
    - everything else → handle yourself
  sub_agents:
    - { name: billing, instruction: "Handle billing questions." }
    - { name: support, instruction: "Handle technical support." }
```

After the transfer, the sub-agent runs and the parent stays inactive until the conversation ends. Setting `disallow_transfer_to_parent: true` on the sub-agent prevents bouncing back; `disallow_transfer_to_peers: true` prevents lateral transfers.

The sub-agent's `description:` field is what the router LLM sees — write it for the routing model, not for humans:

```yaml
sub_agents:
  - name: billing
    description: |
      Handles invoices, refunds, payment disputes, subscription
      changes, and billing-cycle questions.
    instruction: ...
```

## Agent-as-tool (`AgentTool`)

When you want the parent to call a child like a function and use its return value (rather than handing the conversation off):

```yaml
agent:
  name: writer
  instruction: |
    Write the article. Use the editor tool to refine each draft
    before returning the final version.
  tools:
    agent_as_tool: [editor]
  sub_agents:
    - name: editor
      instruction: |
        Improve the writing for clarity. Reply only with the edited text.
```

The parent now has an `editor` tool that takes a string and returns a string. The router model never sees the editor; the writer makes deliberate calls to it.

`agent_as_tool` references must point to a name that appears in the same tree. The builder wraps the named agent in `AgentTool` and adds it to the parent's `tools` list automatically.

## Hybrid

Both mechanisms can apply to the same child:

```yaml
agent:
  name: orchestrator
  instruction: |
    Decide whether to transfer to a specialist or call them as a tool.
  tools:
    agent_as_tool: [researcher]
  sub_agents:
    - { name: researcher, instruction: "Research a topic." }
```

In this shape `researcher` appears in `sub_agents` (so transfer works) and as a tool (so the orchestrator can also invoke it without giving up the conversation).

## Workflow agents and `sub_agents`

The `sub_agents` field has different semantics on workflow agents:

| Agent type | `sub_agents` semantics |
|---|---|
| `llm` | AutoFlow delegation (transfer) |
| `sequential` | Children run in declaration order |
| `parallel` | Children run concurrently |
| `loop` | Children run sequentially, repeat until escalate / `max_iterations` |

Workflow children don't get `transfer_to_agent` — they're driven by their parent's deterministic flow.

## State sharing

ADK's session state is the primary communication channel between sub-agents. Children can:

- Read parent state via `{key}` template substitution in `instruction:`
- Write to state via `output_key:` (final response) or programmatic `context.state[k] = v` from within callbacks / tools

See [Persistence](PERSISTENCE.md) for the four state scopes (`user:`, `app:`, `temp:`, plain).

## Naming uniqueness

ADK's `find_agent(name)` resolves transfer routing by name. The schema enforces unique names across the entire tree:

```yaml
agent:
  name: outer
  type: sequential
  sub_agents:
    - name: dup                   # error: name already used at root
      instruction: ...
```

If you find yourself wanting two agents with the same role, give them differentiated names (`reviewer-style`, `reviewer-content`).

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
