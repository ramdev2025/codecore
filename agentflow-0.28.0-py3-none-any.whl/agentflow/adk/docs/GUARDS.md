# Guards / Optimizers / Observers

The cross-backend portable tier — same vocabulary as workflows / deep / sk / cas. ADK compiles each entry to a `BasePlugin` instance via a typed lookup; there's no separate compilation step (the SK-style `filters/compiler.py` was unnecessary because ADK's `BasePlugin` already aligns with our `Plugin` ABC).

## Three categories

| Category | Purpose | Block? |
|---|---|---|
| **Guards** | Enforce constraints | Yes — raise `GuardBlockedError` to halt the run |
| **Optimizers** | Improve efficiency | No — silently mutate state (retry, cache, compact) |
| **Observers** | Watch without modifying | No — log + emit OTel spans |

## Built-in guards

```yaml
guards:
  - { type: pii, config: { action: redact } }   # action: redact | block
  - { type: tool_call_limit, config: { max_calls: 30 } }
  - { type: model_call_limit, config: { max_calls: 60 } }
  - { type: input_validation,
      config: { schemas: { my_tool: { type: object, required: [city] } } } }
  - { type: content_filter,
      config: { forbidden: ["badword", "another"] } }
```

| Type | Hooks | Default config |
|---|---|---|
| `pii` | `before_tool`, `before_model` | redact mode; SSN/credit card/email/phone patterns |
| `tool_call_limit` | `before_tool` | `max_calls: 50` |
| `model_call_limit` | `before_model` | `max_calls: 100` |
| `input_validation` | `before_tool` | per-tool JSON Schema (requires `jsonschema`) |
| `content_filter` | `after_model` | empty forbidden list (no-op) |

## Built-in optimizers

```yaml
optimizers:
  - { type: tool_retry, config: { max_retries: 2, backoff: 0.5 } }
  - { type: prompt_caching }
  - { type: summarization }
```

| Type | Behaviour |
|---|---|
| `tool_retry` | Retries transient tool errors; exponential backoff |
| `prompt_caching` | Tracks cache hit/miss rates from `Event.cache_metadata` |
| `summarization` | Logs ADK's native context-compaction events (set on `RunConfig`) |

## Built-in observers

```yaml
observers:
  - { type: audit_log }
  - { type: cost_tracking }
  - { type: latency_tracking }
```

| Type | Emits |
|---|---|
| `audit_log` | One log line per tool call + `gen_ai.execute_tool` OTel span |
| `cost_tracking` | Aggregates `Event.usage_metadata`; emits `gen_ai.session_summary` span at run end |
| `latency_tracking` | Per-tool latency log line + `agentflow.tool.latency` span |

All three honor `OTEL_TRACES_ENABLED=true` and emit standard `gen_ai.*` semantic-convention attributes — see [Observability](OBSERVABILITY.md).

## Custom implementations

Override any built-in with your own callable:

```yaml
guards:
  - type: pii                     # the type acts as a label here
    module: my.guards
    function: my_pii_guard
    config: { allowlist: [...] }
```

Your callable receives `(event_name, config, **kwargs)`:

```python
# my/guards.py
async def my_pii_guard(event_name: str, config: dict, **kwargs):
    if event_name != "before_tool":
        return
    args = kwargs.get("tool_args", {})
    # ... raise GuardBlockedError to halt; return to allow
```

To halt the run from a custom guard, raise the typed exception:

```python
from agentflow.adk.filters.builtin import GuardBlockedError
raise GuardBlockedError("...")
```

## How the dispatch works

The builder maps each entry to a `BasePlugin` class via a small lookup table (`agentflow.adk.filters.dispatch`). All three categories end up as plugins on `Runner(plugins=[...])`. Order of execution: guards, then optimizers, then observers, then your explicit `plugins:` entries.

This contrasts with CAS / SK, which compile guards to backend-specific hook shapes via a `compile_*` step. ADK's `BasePlugin` already maps cleanly to our cross-backend `Plugin` ABC, so the compilation reduces to a typed lookup.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
