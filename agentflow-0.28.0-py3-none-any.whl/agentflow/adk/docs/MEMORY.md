# Memory

ADK's `MemoryService` is for **semantic search over past sessions** — distinct from `SessionService` (which stores raw conversation history) and from session state (which holds structured key/value data within one session). Use it when an agent needs to recall something the user told it in a previous conversation.

## Three implementations

| Type | When | Notes |
|---|---|---|
| `in_memory` | Dev / tests | Dict-backed; lost on process exit |
| `vertex_rag` | Vertex AI RAG corpus | Managed; embedding + retrieval |
| `vertex_memory_bank` | Vertex AI Memory Bank | Newer managed service |

## YAML

```yaml
memory:
  type: in_memory
```

```yaml
memory:
  type: vertex_rag
  rag_corpus: projects/my-project/locations/us-central1/ragCorpora/12345
  similarity_top_k: 5
  vector_distance_threshold: 0.7
```

```yaml
memory:
  type: vertex_memory_bank
  config:
    # passed verbatim to VertexAiMemoryBankService(...)
    project_id: my-project
    location: us-central1
```

## Using memory from the agent

Add the `load_memory` (or `preload_memory`) built-in tool — the agent calls it to search past sessions:

```yaml
agent:
  name: assistant
  instruction: |
    Use load_memory to recall past conversations when relevant.
  tools:
    builtin: [load_memory]
```

Or, for tools that need direct access:

```python
from google.adk.tools import ToolContext

async def remember_about(context: ToolContext, query: str) -> dict:
    """Search the user's past sessions for facts about a topic."""
    results = await context.search_memory(query)
    return {"facts": [r.content for r in results.memories]}
```

## Persistence vs. memory vs. state

| Concern | Service | Scope |
|---|---|---|
| Raw event history (what the user said, what tools ran) | `SessionService` | One session |
| Structured key/value within a session | `state` (in `Session`) | One session, possibly user-/app-scoped |
| Semantic recall across sessions | `MemoryService` | All past sessions for the user |
| Binary blobs (files, screenshots) | `ArtifactService` | Per session or per user |

Most agents only need a `SessionService` (configured via the
`--persistence` CLI flag or the `AGENTFLOW_PERSISTENCE` /
`POSTGRES_CONNECTION_STRING` / `CHECKPOINTER_DB_PATH` env vars — see
[PERSISTENCE.md](PERSISTENCE.md)). Add a `MemoryService` only when the
agent should "remember" things across separate conversations.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
