# Callbacks

ADK exposes eight per-agent callback slots — for filtering / mutating / observing model and tool calls without writing a tree-wide plugin. They differ from [BasePlugin](PLUGINS.md) (tree-wide, cross-cutting) — these run only when *this* agent is active.

## YAML shape

Each slot accepts a single `module:function` ref or a list:

```yaml
agent:
  name: assistant
  instruction: ...
  callbacks:
    before_model: { module: cb, function: redact_secrets }
    after_model:
      - { module: cb, function: log_response }
      - { module: cb, function: validate_format }
    before_tool: { module: cb, function: tool_audit }
```

## The eight slots

| Slot | Signature | Returning a value short-circuits |
|---|---|---|
| `before_agent` | `(CallbackContext) -> Optional[Content]` | Replaces agent body |
| `after_agent` | `(CallbackContext, Content) -> Optional[Content]` | Replaces output |
| `before_model` | `(CallbackContext, LlmRequest) -> Optional[LlmResponse]` | Skips LLM call |
| `after_model` | `(CallbackContext, LlmResponse) -> Optional[LlmResponse]` | Replaces response |
| `on_model_error` | `(CallbackContext, LlmRequest, Exception) -> Optional[LlmResponse]` | Recovery |
| `before_tool` | `(ToolContext, ...) -> Optional[dict]` | Skips tool execution |
| `after_tool` | `(ToolContext, dict) -> Optional[dict]` | Replaces tool result |
| `on_tool_error` | `(ToolContext, Exception) -> Optional[dict]` | Recovery |

Returning `None` lets the call proceed unchanged. Returning a value of the documented type replaces / cancels the underlying operation.

Workflow agents (`sequential` / `parallel` / `loop`) only support `before_agent` / `after_agent` — they don't have models or tools.

## Authoring callbacks

Both sync and async are supported. ADK awaits coroutines and dispatches sync calls directly.

```python
# cb.py
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest, LlmResponse
from typing import Optional

async def redact_secrets(
    callback_context: CallbackContext,
    llm_request: LlmRequest,
) -> Optional[LlmResponse]:
    """Strip API keys from outgoing prompts. Returns None to proceed."""
    for content in llm_request.contents or []:
        for part in content.parts or []:
            if part.text and "sk-" in part.text:
                part.text = part.text.replace(part.text, "[REDACTED]")
    return None
```

```python
async def force_response(
    callback_context: CallbackContext,
    llm_request: LlmRequest,
) -> Optional[LlmResponse]:
    """Short-circuit the model with a canned response."""
    if "test" in (callback_context.user_content.parts[0].text or ""):
        return LlmResponse.from_text("This is a test response.")
    return None
```

## Callback vs. plugin: which?

| Use a callback when… | Use a plugin when… |
|---|---|
| Behaviour is specific to this agent | Behaviour applies tree-wide |
| You want the simplest possible signature | You need lifecycle hooks (`on_event`, `on_user_message`) |
| The action is small (redact, validate, log one line) | You need state across multiple agents |
| Existing AgentFlow plugin would work | You want cross-backend portability |

In practice: write tree-wide concerns as plugins (or use the portable `guards:` / `observers:` tier); write per-agent specifics as callbacks.

## State access

Both `CallbackContext` and `ToolContext` expose `state` as a mutable dict. Writes go through ADK's event system so they persist via the `SessionService`:

```python
async def remember(callback_context: CallbackContext, llm_response: LlmResponse):
    text = llm_response.content.parts[0].text
    callback_context.state["last_response"] = text
    return None
```

Use `user:` / `app:` / `temp:` prefixes to scope state — see [Persistence](PERSISTENCE.md).

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
