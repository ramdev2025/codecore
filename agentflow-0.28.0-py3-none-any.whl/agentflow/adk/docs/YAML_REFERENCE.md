# YAML Reference

Every field on the ADK YAML schema, grouped by section. The schema is enforced by Pydantic v2 with `extra='forbid'` — unknown fields raise an error rather than silently dropping.

## Top-level shape

```yaml
backend: adk                      # required, must be exactly "adk"
metadata: { ... }                 # required (version + optional name/description/...)

llm: { ... }                      # default LLM (per-agent llm overrides)

agent: { ... }                    # required — root agent (any type)

mcp_servers: { name: { ... } }    # optional, named registry
plugins: [ { ... }, ... ]         # optional, ADK BasePlugin refs

guards: [ ... ]                   # cross-backend portable tier
optimizers: [ ... ]
observers: [ ... ]

persistence: { ... }              # DEPRECATED — see `persistence` section below.
                                  # Configure SessionService via CLI flags
                                  # (--persistence / --db-path / --connection-string)
                                  # or env vars (AGENTFLOW_PERSISTENCE,
                                  # POSTGRES_CONNECTION_STRING, CHECKPOINTER_DB_PATH).
                                  # Still required in YAML only for
                                  # ``type: vertex``.
memory: { ... }                   # MemoryService selection
artifacts: { ... }                # ArtifactService selection
serving: { ... }                  # Vertex AI Agent Engine deploy target
```

## `metadata`

```yaml
metadata:
  version: "1.0"                  # required
  name: research-bot              # optional; used as ADK app_name
  description: "..."              # optional
  author: "Alice"                 # optional
  tags: [demo, adk]               # optional
```

## `llm`

```yaml
llm:
  provider: gemini                # gemini | vertex | litellm | azure_openai | custom
  config:
    model: gemini-2.5-flash       # required for all providers except 'custom'
    api_key: ${GOOGLE_API_KEY}    # bridged to GOOGLE_API_KEY env var
    # Vertex-only:
    project: my-project
    location: us-central1
    # Custom-only:
    module: my.llms
    class: MyCustomLlm
    # Generation knobs (forwarded to GenerateContentConfig):
    generate_content_config:
      temperature: 0.4
      top_p: 0.9
      max_output_tokens: 2048
```

See [LLM Services](SERVICES.md) for per-provider details and Azure RBAC.

## `agent` — discriminated by `type`

`type` is one of `llm` (default), `sequential`, `parallel`, `loop`. Workflow agents have no `model` / `tools` / `instruction` — they orchestrate `sub_agents` only.

### `type: llm`

```yaml
agent:
  name: my-agent                  # required; unique across the tree
  type: llm                       # default; may be omitted
  description: "..."              # surfaced to parents for routing decisions

  # Per-agent LLM (overrides top-level llm)
  llm: { ... }
  model: gemini-2.5-pro           # shorthand: top-level provider + this model

  instruction: |                  # system prompt; supports {state_key} substitution
    You are a helpful assistant.
  static_instruction: |           # cached system prompt (verbatim, not templated)
    Always reply in JSON.

  tools:
    builtin: [google_search]
    plugins: [ { name: my, module: tools } ]
    agent_as_tool: [helper]
    mcp_servers: [my-mcp]

  sub_agents:                     # AutoFlow delegation children
    - { name: helper, instruction: "..." }

  disallow_transfer_to_parent: false
  disallow_transfer_to_peers: false
  include_contents: default       # default | none

  output_key: report              # write final response to state[report]
  output_schema:                  # disables tool calls; enforces shape
    module: schemas
    class: Report

  planner:                        # optional
    type: built_in
    thinking: { include_thoughts: true, thinking_budget: 8000 }

  code_executor:                  # optional
    type: built_in                # built_in | container | unsafe_local | vertex_ai

  callbacks:                      # see CALLBACKS.md
    before_model: { module: cb, function: redact }
    after_model: [ { ... }, { ... } ]
```

### `type: sequential` / `parallel` / `loop`

```yaml
agent:
  name: pipeline
  type: sequential                # or parallel
  sub_agents: [ ... ]             # required, non-empty
```

```yaml
agent:
  name: refiner
  type: loop
  max_iterations: 5               # optional; cap; exits early on escalate=True
  sub_agents: [ ... ]
```

## `tools.builtin`

Each entry is either a name (string) or `{ name, config }`:

```yaml
tools:
  builtin:
    - google_search
    - exit_loop
    - { name: vertex_ai_search, config: { data_store_id: ds-1 } }
```

Names: `google_search`, `exit_loop`, `transfer_to_agent`, `get_user_choice`, `load_artifacts`, `load_memory`, `preload_memory`, `url_context`, `enterprise_web_search`, `google_maps_grounding`, `vertex_ai_search`.

## `tools.plugins`

Each entry imports tools from a Python module:

```yaml
tools:
  plugins:
    - name: my-tools
      type: python                # default; only 'python' supported in v1
      module: my.tool_module
      functions: [search, fetch]  # optional; defaults to all public callables
```

If `functions:` is omitted, every public top-level callable defined in the module is registered. See [Plugins](PLUGINS.md).

## `tools.agent_as_tool`

Each entry is the name of an `LlmAgent` in the same tree (must appear in `sub_agents` of some ancestor):

```yaml
tools:
  agent_as_tool: [helper, specialist]
```

The builder wraps the named agents in ADK's `AgentTool` and adds them to this agent's `tools` list. See [Sub-agents](SUBAGENTS.md).

## `tools.mcp_servers`

Each entry is either a name (string referencing the top-level `mcp_servers:` registry) or an inline dict:

```yaml
mcp_servers:
  fs:
    transport: stdio
    command: mcp-server-filesystem
    args: ["./"]

agent:
  name: a
  tools:
    mcp_servers: [fs]
```

See [MCP](MCP.md) for transports and config.

## `mcp_servers`

```yaml
mcp_servers:
  fs:
    transport: stdio              # stdio | sse | streamable_http
    command: mcp-server-filesystem
    args: ["./"]
    env: { FOO: bar }
    timeout: 5.0
    tool_filter: [read, write]    # optional allowlist
    tool_name_prefix: fs_         # optional namespace
  remote:
    transport: streamable_http
    url: https://mcp.example.com/sse
    headers: { Authorization: "Bearer ${TOKEN}" }
```

## `plugins`

ADK `BasePlugin` instances registered on the Runner:

```yaml
plugins:
  - module: google.adk.plugins
    class: LoggingPlugin
    name: logger              # override BasePlugin.name (default: class name)
    config: { level: DEBUG }  # constructor kwargs
```

These run at `Runner` level (not per-agent). See [Plugin Bridge](PLUGIN_BRIDGE.md) for cross-backend `Plugin` ABC compatibility.

## `guards` / `optimizers` / `observers`

```yaml
guards:
  - { type: pii, config: { action: redact } }
  - { type: tool_call_limit, config: { max_calls: 30 } }
  - { type: model_call_limit, config: { max_calls: 60 } }
  - { type: input_validation, config: { schemas: { ... } } }
  - { type: content_filter, config: { forbidden: [a, b] } }

optimizers:
  - { type: tool_retry, config: { max_retries: 2, backoff: 0.5 } }
  - { type: prompt_caching }
  - { type: summarization }

observers:
  - { type: audit_log }
  - { type: cost_tracking }
  - { type: latency_tracking }
```

Custom implementations replace built-ins:

```yaml
guards:
  - type: pii                     # or any value; treated as a label
    module: my.guards
    function: my_pii_guard
    config: { ... }
```

See [Guards / Optimizers / Observers](GUARDS.md).

## `persistence` (deprecated for non-vertex types)

Configure persistence at deploy time, not in YAML, so the same
`agent.yaml` runs across dev / staging / prod. For `memory` /
`sqlite` / `postgres` use CLI flags or env vars:

```bash
# CLI
agentflow --persistence sqlite --db-path ./state.db --yaml agent.yaml "..."
agentflow --persistence postgres --connection-string "$DATABASE_URL" --yaml agent.yaml "..."

# Env (AGENTFLOW_PERSISTENCE, CHECKPOINTER_DB_PATH, POSTGRES_CONNECTION_STRING)
export AGENTFLOW_PERSISTENCE=postgres
export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
agentflow --yaml agent.yaml "..."
```

A YAML `persistence:` block for those three types logs a deprecation
warning at startup and is ignored (CLI/env values take effect instead).
Remove it from your YAML to silence the warning. See
[PERSISTENCE.md](PERSISTENCE.md) for the full env-var table and the
resolution order.

**`vertex` is the one exception** — there's no CLI/env equivalent for
`project` / `location` / `agent_engine_id` yet, so vertex still
requires the block:

```yaml
persistence:
  type: vertex
  project: my-project
  location: us-central1
  agent_engine_id: "1234"
```

## `memory`

```yaml
memory:
  type: in_memory                 # in_memory | vertex_rag | vertex_memory_bank
  rag_corpus: projects/p/locations/l/ragCorpora/123
  similarity_top_k: 5
  vector_distance_threshold: 0.7
  config: { ... }                 # provider-specific overrides
```

## `artifacts`

```yaml
artifacts:
  type: in_memory                 # in_memory | file | gcs
  base_dir: ./artifacts           # file only
  bucket_name: my-bucket          # gcs only (required)
```

## `serving`

```yaml
serving:
  type: vertex_agent_engine
  project: my-project
  location: us-central1
  agent_engine_id: existing-id    # omit to create on deploy
  display_name: My Agent
  description: "..."
```

The deploy itself is a separate command (follow-up); this block declares the target so dry-run can validate it.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
