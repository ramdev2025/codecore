# Production Features

What you get when you ship an ADK-backed AgentFlow agent to production.

## Feature matrix

| Capability | Default | Configurable via | Notes |
|---|---|---|---|
| Multi-provider LLM | ✅ | `llm.provider` | Gemini / Vertex / LiteLLM (OpenAI/Anthropic/Azure/...) / custom `BaseLlm` |
| Sub-agent delegation | ✅ | `agent.sub_agents` | AutoFlow `transfer_to_agent`; opt-out per agent |
| Workflow primitives | ✅ | `agent.type` | `sequential` / `parallel` / `loop` with `max_iterations` |
| Tools as Python functions | ✅ | `agent.tools.plugins` | Auto-wrapped in `FunctionTool`; type hints → schema |
| MCP integration | ✅ | `mcp_servers` | stdio / SSE / StreamableHTTP |
| Built-in tools | ✅ | `agent.tools.builtin` | `google_search`, `vertex_ai_search`, etc. |
| Persistence (SQLite, Postgres, Vertex Sessions) | ✅ | `persistence` | Async-driver upgrade automatic |
| Thread-id binding | ✅ | `--thread-id` | Resumes ADK session across processes |
| Encryption at rest | ✅ | `AGENTFLOW_ENCRYPTION_KEY` | AES-GCM; binding only |
| Memory (vector / RAG) | ✅ | `memory` | In-memory / Vertex RAG / Vertex Memory Bank |
| Artifacts (binary blobs) | ✅ | `artifacts` | In-memory / file / GCS |
| Cross-cutting plugins (`BasePlugin`) | ✅ | `plugins` | 12 lifecycle hooks |
| Cross-backend `Plugin` ABC bridge | ✅ | (auto) | Existing AgentFlow plugins work unchanged |
| Portable guards / optimizers / observers | ✅ | `guards` / `optimizers` / `observers` | Same vocabulary as workflows / sk / cas |
| Per-agent callbacks | ✅ | `agent.callbacks` | 8 slots (before/after agent/model/tool, error) |
| Prompt caching | ✅ | `prompt_caching` optimizer | Tracks hit rate from `cache_metadata` |
| Tool retry | ✅ | `tool_retry` optimizer | Exponential backoff |
| Cost tracking | ✅ | `cost_tracking` observer | OTel `gen_ai.session_summary` span |
| OpenTelemetry tracing | ✅ | `OTEL_TRACES_ENABLED=true` | OTLP export; `gen_ai.*` semantic conventions |
| Vertex AI Agent Engine deploy | ✅ (config) | `serving` | YAML target declared; deploy CLI follow-up |
| JSON streaming output | ✅ | `--output ndjson` | One JSON event per line for CI / pipelines |
| Interactive REPL | ✅ | `--interactive` | `/help`, `/quit`, `/save`, `/history` |

## A complete production YAML

```yaml
backend: adk
metadata:
  version: "1.0"
  name: support-bot
  author: ai-platform-team
  tags: [production, customer-support]

llm:
  provider: vertex
  config:
    model: gemini-2.5-pro
    project: ${GCP_PROJECT}
    location: us-central1
    generate_content_config:
      temperature: 0.3
      max_output_tokens: 2048

mcp_servers:
  knowledge_base:
    transport: streamable_http
    url: ${KB_MCP_URL}
    headers: { Authorization: "Bearer ${KB_TOKEN}" }
    tool_filter: [search, get_article]

agent:
  name: triage
  description: First-line support router.
  instruction: |
    You're a support agent. Route to the right specialist or
    handle simple questions yourself. Be concise and empathetic.
  tools:
    builtin: [google_search]
    mcp_servers: [knowledge_base]
  callbacks:
    before_model: { module: cb, function: redact_pii }
  sub_agents:
    - name: billing
      description: Handles invoices, refunds, payment disputes.
      instruction: |
        Resolve billing questions. Look up invoices via the
        knowledge_base tools. Escalate refunds over $500.
      tools:
        mcp_servers: [knowledge_base]
    - name: technical
      description: Diagnoses technical issues.
      instruction: ...
      llm:
        provider: vertex
        config: { model: gemini-2.5-flash }   # cheaper for diagnosis

guards:
  - { type: pii, config: { action: redact } }
  - { type: tool_call_limit, config: { max_calls: 30 } }
  - { type: model_call_limit, config: { max_calls: 60 } }

optimizers:
  - { type: prompt_caching }
  - { type: tool_retry, config: { max_retries: 2, backoff: 0.5 } }

observers:
  - { type: audit_log }
  - { type: cost_tracking }
  - { type: latency_tracking }

plugins:
  - module: my.plugins
    class: CostBudgetPlugin
    config: { max_usd: 10.00 }

# Persistence is configured at deploy time, not in YAML:
#   export AGENTFLOW_PERSISTENCE=postgres
#   export POSTGRES_CONNECTION_STRING="$DATABASE_URL"
# (or pass --persistence postgres --connection-string "$DATABASE_URL")
# See PERSISTENCE.md for the full env-var surface.

memory:
  type: vertex_rag
  rag_corpus: ${RAG_CORPUS}
  similarity_top_k: 5

artifacts:
  type: gcs
  bucket_name: ${ARTIFACTS_BUCKET}

serving:
  type: vertex_agent_engine
  project: ${GCP_PROJECT}
  location: us-central1
  display_name: Support Triage Bot
```

## Backend comparison

| Concern | workflows | deep | sk | cas | oai | maf | **adk** |
|---|---|---|---|---|---|---|---|
| Multi-provider | LangChain | LangChain | Native | LiteLLM bridge (extension) | Native | Native | LiteLLM (extension) |
| Workflow primitives | Custom DAG | Sub-agent | Process / Sequential | — | Handoffs | Workflow / Agent | Sequential / Parallel / Loop / LlmAgent |
| Native MCP | Via plugin | Via plugin | Plugin | First-class | Via tool | Via tool | First-class |
| Persistence | LangGraph checkpoint | LangGraph checkpoint | ChatHistory ser | thread→sess bridge | OpenAI thread bridge | session bridge | thread→sess bridge + ADK SessionService |
| Cross-backend `Plugin` ABC | Source of truth | Bridges | Bridges | Bridges | Bridges | Bridges | Bridges |
| First-class hooks/callbacks | Plugin | — | Filters | 10 hook events | Guardrails | Middleware | 8 callback slots + BasePlugin |
| RBAC turn-key | Azure OpenAI | — | Azure OpenAI | — | Azure OpenAI | Azure OpenAI | Azure OpenAI (`azure_openai` provider, v0.22.1) |
| Native deploy target | — | — | — | — | — | — | Vertex Agent Engine |

## Runtime guarantees

- `extra='forbid'` on every Pydantic model — typos in YAML fail loudly at parse time, not at runtime
- Builder is two-pass — `agent_as_tool` references resolve only after their target is constructed; circular refs would error at parse, not at run time
- Plugin failures don't break the agent — exceptions in observers/optimizers are swallowed; only `GuardBlockedError` halts a run
- ADK's async-driver requirement is handled in the builder — `sqlite:///` and `postgresql://` URLs auto-upgrade

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
