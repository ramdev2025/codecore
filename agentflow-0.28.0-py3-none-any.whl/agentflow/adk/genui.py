"""ADK adapter for the cross-backend ``ui_tools`` vocabulary.

ADK accepts plain Python callables in ``LlmAgent.tools=[...]`` — they're
auto-wrapped into ``FunctionTool`` by ADK itself. No decorator is
required. That makes the ADK genui adapter the simplest of the bunch:
each ``@ui_component`` fetcher is wrapped in a thin shim that validates
the return value and emits a JSON string for the LLM, then added to
the agent's tools list.

Same conventions as MAF / SK:

  * Tool name = fetcher function name (verb).
  * ``_agentflow_component_name`` attribute = Pydantic class name
    (noun), used by ``agentflow.genui.filter_by_availability`` for
    build-time predicate gating.

Without an upstream AG-UI bridge for ADK, the wrapper's JSON return
is the only output channel — the LLM consumes the structured data
directly in its commentary. A future ADK AG-UI bridge could dispatch
typed renders off the ``component`` marker in the JSON.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
import logging
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from agentflow.genui import (
    UIToolsConfig,
    discover_ui_components,
    get_component_class,
)

logger = logging.getLogger(__name__)


def resolve_ui_tools(config: UIToolsConfig | None) -> list[Callable[..., Any]]:
    """Build a list of ADK-compatible callables from a ``UIToolsConfig``.

    Returns an empty list when ``config`` is ``None`` so callers can
    unconditionally extend their tools list with the result.

    Args:
        config: The parsed ``ui_tools:`` YAML block.

    Returns:
        List of plain Python callables ready for ``LlmAgent(tools=[...])``.

    Raises:
        ValueError: If ``config.use`` names a component the module
            doesn't expose.
    """
    if config is None:
        return []

    discovered = discover_ui_components(config.module)
    if config.use is not None:
        missing = sorted(set(config.use) - set(discovered.keys()))
        if missing:
            available = sorted(discovered.keys())
            raise ValueError(
                f"ui_tools.use names component(s) not found in "
                f"{config.module!r}: {missing}. Available: {available}"
            )
        discovered = {n: discovered[n] for n in config.use}

    return [_wrap_for_adk(name, fetcher) for name, fetcher in discovered.items()]


def _wrap_for_adk(
    component_name: str, fetcher: Callable[..., Any]
) -> Callable[..., Any]:
    """Wrap a ``@ui_component`` fetcher as an ADK-ready callable.

    The wrapper preserves the fetcher's parameter signature (ADK
    introspects it to build the function-calling schema for the LLM),
    validates the return against the declared Pydantic class, and
    returns a JSON ``str`` for the LLM. Errors return
    ``[Name failed] ...`` strings — same lenient policy as MAF / SK /
    workflows.

    Why the explicit ``str`` return annotation matters
    ---------------------------------------------------

    ADK ≥ 1.x calls
    ``pydantic.TypeAdapter(return_annotation, config=...)`` to build
    a tool-result JSON schema for the model. Pydantic 2.x raises
    ``PydanticUserError`` when given a ``BaseModel`` annotation
    alongside a ``config`` argument (the BaseModel carries its own
    config). The fetcher's real return annotation is the component
    Pydantic class — handing that to ADK trips the error and logs
    a noisy stack trace for every tool on every run.

    We sidestep the problem by overriding the wrapper's signature
    so the return annotation is ``str`` (which is what we actually
    return — a JSON-encoded payload). The parameter annotations are
    preserved unchanged.
    """
    component_cls = get_component_class(fetcher)
    if component_cls is None:  # pragma: no cover — discover_ui_components guards
        raise RuntimeError(f"{fetcher} is not @ui_component-decorated")

    fetcher_sig = inspect.signature(fetcher)
    # Build a signature that keeps parameter types but pins the return
    # annotation to ``str`` so ADK's response-schema builder skips the
    # BaseModel TypeAdapter call.
    adk_sig = fetcher_sig.replace(return_annotation=str)

    is_async = asyncio.iscoroutinefunction(fetcher)

    if is_async:

        @functools.wraps(fetcher)
        async def async_wrapper(*args: Any, **kwargs: Any) -> str:
            result = await fetcher(*args, **kwargs)
            return _to_tool_result(component_name, component_cls, result)

        async_wrapper.__signature__ = adk_sig  # type: ignore[attr-defined]
        async_wrapper.__annotations__ = {
            **{k: v for k, v in (fetcher.__annotations__ or {}).items() if k != "return"},
            "return": str,
        }
        async_wrapper._agentflow_component_name = component_name  # type: ignore[attr-defined]
        return async_wrapper

    @functools.wraps(fetcher)
    def sync_wrapper(*args: Any, **kwargs: Any) -> str:
        result = fetcher(*args, **kwargs)
        return _to_tool_result(component_name, component_cls, result)

    sync_wrapper.__signature__ = adk_sig  # type: ignore[attr-defined]
    sync_wrapper.__annotations__ = {
        **{k: v for k, v in (fetcher.__annotations__ or {}).items() if k != "return"},
        "return": str,
    }
    sync_wrapper._agentflow_component_name = component_name  # type: ignore[attr-defined]
    return sync_wrapper


def _to_tool_result(
    component_name: str,
    component_cls: type[BaseModel],
    result: Any,
) -> str:
    """Validate and serialize a fetcher's return for ADK consumption."""
    if isinstance(result, component_cls):
        instance = result
    elif isinstance(result, dict):
        try:
            instance = component_cls.model_validate(result)
        except Exception as exc:
            return f"[{component_name} failed] dict didn't validate: {exc}"
    else:
        return (
            f"[{component_name} failed] fetcher must return a {component_name} "
            f"instance or a dict, got {type(result).__name__}"
        )

    payload = {"__component__": component_name, **instance.model_dump()}
    return json.dumps(payload)
