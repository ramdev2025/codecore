"""AG-UI bridge for the ADK (Google Agent Development Kit) backend.

Brings the AG-UI HTTP+SSE protocol to YAML-driven Google ADK agents.
No published upstream AG-UI package exists for google-adk, so
AgentFlow carries the full implementation:

  * :mod:`events` — Pydantic wire models for AG-UI events
  * :mod:`adapter` — stateful event translator from orchestrator
    events to AG-UI wire events
  * :mod:`client_tools` — ``ClientToolPause``-raising plain Python
    callables registered as ADK tools
  * :mod:`router` — FastAPI router + ``build_agui`` public entrypoint

The public entrypoint is :func:`build_agui`. Mount the returned
``(router, lifespan)`` into your own FastAPI app::

    from fastapi import FastAPI
    from agentflow.adk.agui import build_agui

    router, lifespan = build_agui(yaml_path="agent.yaml")
    app = FastAPI(lifespan=lifespan)
    app.include_router(router, prefix="/agui")

What ADK gets vs the LangGraph-based bridges
--------------------------------------------

  * ``ui_tools`` ✓ — same cross-backend YAML, ``@ui_component``
    fetchers become plain Python callables that ADK auto-wraps as
    ``FunctionTool`` instances.
  * Token-level text streaming ✓ — translated from ADK ``Event``
    items whose ``content.parts[].text`` carries partial deltas
    (``event.partial=True``).
  * Tool call lifecycle ✓ — translated from ``function_call`` /
    ``function_response`` Parts in the same event stream.
  * ``client_tools`` ✓ — exception-based pause via
    ``ClientToolPause`` raised inside the tool body, caught at the
    runtime layer and re-surfaced as an AG-UI Interrupt.
  * ``available_when`` (build-time only — ADK has no clean per-call
    hide-from-list hook).
  * State persistence: ADK ships its own ``SessionService`` (in-
    memory / sqlite / postgres). The AG-UI bridge resumes
    client_tool pauses via its own in-memory map keyed by thread_id.
"""

from .adapter import AGUIAdapter, translate_stream
from .client_tools import (
    ClientToolPause,
    build_client_tool_callables,
)
from .events import (
    AGUIEvent,
    CustomEvent,
    EventType,
    Interrupt,
    InterruptOutcome,
    RunError,
    RunFinished,
    RunStarted,
    StateDelta,
    StateSnapshot,
    TextMessageContent,
    TextMessageEnd,
    TextMessageStart,
    ToolCallArgs,
    ToolCallEnd,
    ToolCallResult,
    ToolCallStart,
    render_component,
)
from .router import build_agui

__all__ = [
    "AGUIAdapter",
    "AGUIEvent",
    "ClientToolPause",
    "CustomEvent",
    "EventType",
    "Interrupt",
    "InterruptOutcome",
    "RunError",
    "RunFinished",
    "RunStarted",
    "StateDelta",
    "StateSnapshot",
    "TextMessageContent",
    "TextMessageEnd",
    "TextMessageStart",
    "ToolCallArgs",
    "ToolCallEnd",
    "ToolCallResult",
    "ToolCallStart",
    "build_agui",
    "build_client_tool_callables",
    "render_component",
    "translate_stream",
]
