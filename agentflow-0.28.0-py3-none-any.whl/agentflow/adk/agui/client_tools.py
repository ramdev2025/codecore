"""Frontend-implemented (client-side) tool stubs for the ADK AG-UI bridge.

ADK accepts plain Python callables as tools (it builds the function-
declaration schema by introspection). Each ``ClientToolConfig`` here
becomes a callable that raises :class:`ClientToolPause`; the ADK
runtime executes the call as part of the agent loop, the exception
bubbles up to the orchestrator, and we surface it as an AG-UI
Interrupt event.

Same exception-based pause shape as SK / CAS / OAI — three frameworks
without a native pause primitive, one uniform contract on the wire.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agentflow.genui import ClientToolConfig

logger = logging.getLogger(__name__)


class ClientToolPause(Exception):
    """Raised by a client_tool stub body to pause the agent run.

    The ADK AG-UI orchestrator catches this exception while iterating
    over ``Runner.run_async()``; emits an AG-UI Interrupt with the
    tool name and args; ends the stream. The browser handler runs;
    the orchestrator resumes on the next request by feeding the
    result as a user-message preamble.
    """

    def __init__(self, tool_name: str, args: dict[str, Any]) -> None:
        super().__init__(f"client_tool pause: {tool_name}({args})")
        self.tool_name = tool_name
        self.tool_args = args


def build_client_tool_callables(specs: list["ClientToolConfig"]) -> list[Any]:
    """Build one callable per ``ClientToolConfig`` that raises
    ``ClientToolPause`` when ADK invokes it.

    Called by the AG-UI router at build time when
    ``bind_client_tools=True``. ADK auto-derives the function-
    declaration schema from each callable's signature; we use
    ``**kwargs`` so any args pass through unaltered.
    """
    tools: list[Any] = []
    for spec in specs:
        tools.append(_make_callable(spec))
    return tools


def _make_callable(spec: "ClientToolConfig") -> Any:
    """Build a single Python callable for ADK to introspect + invoke."""
    tool_name = spec.name
    description = spec.description or ""

    def handler(**kwargs: Any) -> str:
        raise ClientToolPause(tool_name=tool_name, args=dict(kwargs))

    handler.__name__ = tool_name
    handler.__doc__ = description
    handler._agentflow_client_tool = True  # type: ignore[attr-defined]
    return handler
