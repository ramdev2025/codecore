"""Built-in guard / optimizer / observer ADK ``BasePlugin`` classes.

Each class is a thin ADK ``BasePlugin`` subclass that implements only the
hooks it needs. Where applicable, observers also emit OTel spans using
``gen_ai.*`` semantic conventions so they appear as their own spans in
Jaeger / Tempo / Datadog / etc.

This module imports ``google.adk`` directly because it's only loaded when
the ADK backend is in use. Other backends never import this module.

Plugin contract:

- Guards raise ``GuardBlockedError`` to halt the run with a structured
  reason. Returning ``None`` allows the request to proceed.
- Optimizers mutate state silently (e.g. tagging requests for caching,
  retrying tools, etc.) and don't block.
- Observers never mutate; they only log / emit spans.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from collections import defaultdict
from typing import Any, Dict

from google.adk.plugins.base_plugin import BasePlugin


_audit_log = logging.getLogger("agentflow.adk.audit")
_cost_log = logging.getLogger("agentflow.adk.cost")
_latency_log = logging.getLogger("agentflow.adk.latency")


def _tracer():
    from opentelemetry import trace
    return trace.get_tracer("agentflow.adk")


class GuardBlockedError(RuntimeError):
    """Raised by guards to halt the run with a structured reason."""


# ---------------------------------------------------------------------------
# GUARDS
# ---------------------------------------------------------------------------


class ToolCallLimitGuard(BasePlugin):
    """Block further tool calls past ``max_calls`` per run."""

    def __init__(self, max_calls: int = 50, name: str = "tool_call_limit") -> None:
        super().__init__(name=name)
        self.max_calls = max_calls
        self._counter = 0

    async def before_tool_callback(self, **_: Any) -> Any:
        self._counter += 1
        if self._counter > self.max_calls:
            raise GuardBlockedError(
                f"tool_call_limit reached ({self.max_calls}); agent stopped"
            )
        return None


class ModelCallLimitGuard(BasePlugin):
    """Block further model calls past ``max_calls`` per run."""

    def __init__(self, max_calls: int = 100, name: str = "model_call_limit") -> None:
        super().__init__(name=name)
        self.max_calls = max_calls
        self._counter = 0

    async def before_model_callback(self, **_: Any) -> Any:
        self._counter += 1
        if self._counter > self.max_calls:
            raise GuardBlockedError(
                f"model_call_limit reached ({self.max_calls}); agent stopped"
            )
        return None


_PII_PATTERNS = {
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "credit_card": re.compile(r"\b(?:\d[ -]?){13,19}\b"),
    "email": re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"),
    "phone": re.compile(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"),
}


class PIIGuard(BasePlugin):
    """Detect PII in tool inputs and model contents.

    ``action`` is ``redact`` (log + warn) or ``block`` (raise
    :class:`GuardBlockedError`). Default redaction mode logs to the
    ``agentflow.adk.audit`` logger; downstream pipelines can subscribe.
    """

    def __init__(
        self,
        patterns: Dict[str, str] | None = None,
        action: str = "redact",
        name: str = "pii",
    ) -> None:
        super().__init__(name=name)
        self.action = action
        self._regex = (
            {k: re.compile(v) for k, v in patterns.items()}
            if patterns else dict(_PII_PATTERNS)
        )

    async def before_tool_callback(
        self, *, tool: Any = None, tool_args: Dict[str, Any] | None = None, **_: Any,
    ) -> Any:
        if not tool_args:
            return None
        where = f"tool {getattr(tool, 'name', '?')}"
        for k, v in tool_args.items():
            if isinstance(v, str) and self._has_pii(v):
                self._handle(f"{where} arg {k!r}")
        return None

    async def before_model_callback(self, *, llm_request: Any = None, **_: Any) -> Any:
        if llm_request is None:
            return None
        for c in getattr(llm_request, "contents", None) or []:
            for p in getattr(c, "parts", []) or []:
                text = getattr(p, "text", None)
                if text and self._has_pii(text):
                    self._handle("model input")
        return None

    def _has_pii(self, text: str) -> bool:
        return any(rx.search(text) for rx in self._regex.values())

    def _handle(self, where: str) -> None:
        if self.action == "block":
            raise GuardBlockedError(f"PII detected in {where}")
        _audit_log.warning("PII detected in %s (action=%s)", where, self.action)


class InputValidationGuard(BasePlugin):
    """Reject tool inputs whose JSON shape doesn't match a per-tool schema."""

    def __init__(
        self,
        schemas: Dict[str, Dict[str, Any]] | None = None,
        name: str = "input_validation",
    ) -> None:
        super().__init__(name=name)
        self.schemas = schemas or {}

    async def before_tool_callback(
        self, *, tool: Any = None, tool_args: Dict[str, Any] | None = None, **_: Any,
    ) -> Any:
        tool_name = getattr(tool, "name", None)
        schema = self.schemas.get(tool_name) if tool_name else None
        if not schema:
            return None
        try:
            import jsonschema
        except ImportError:
            _audit_log.warning(
                "input_validation guard configured but jsonschema not installed"
            )
            return None
        try:
            jsonschema.validate(instance=tool_args or {}, schema=schema)
        except Exception as exc:
            raise GuardBlockedError(
                f"input validation failed for tool {tool_name!r}: {exc}"
            )
        return None


class ContentFilterGuard(BasePlugin):
    """Reject model output containing any of the configured forbidden phrases."""

    def __init__(
        self,
        forbidden: list[str] | None = None,
        name: str = "content_filter",
    ) -> None:
        super().__init__(name=name)
        self.forbidden = [s.lower() for s in (forbidden or [])]

    async def after_model_callback(self, *, llm_response: Any = None, **_: Any) -> Any:
        if not self.forbidden or llm_response is None:
            return None
        content = getattr(llm_response, "content", None)
        for part in getattr(content, "parts", []) or []:
            text = (getattr(part, "text", "") or "").lower()
            for phrase in self.forbidden:
                if phrase in text:
                    raise GuardBlockedError(
                        f"content_filter triggered on phrase {phrase!r}"
                    )
        return None


# ---------------------------------------------------------------------------
# OPTIMIZERS
# ---------------------------------------------------------------------------


class ToolRetryOptimizer(BasePlugin):
    """Retry transient tool errors up to ``max_retries`` times."""

    def __init__(
        self,
        max_retries: int = 2,
        backoff: float = 0.5,
        name: str = "tool_retry",
    ) -> None:
        super().__init__(name=name)
        self.max_retries = max_retries
        self.backoff = backoff
        self._attempts: dict[str, int] = defaultdict(int)

    async def on_tool_error_callback(
        self, *, tool: Any = None, error: Exception | None = None, **_: Any,
    ) -> Any:
        tool_name = getattr(tool, "name", type(tool).__name__) if tool else "unknown"
        self._attempts[tool_name] += 1
        if self._attempts[tool_name] <= self.max_retries:
            _audit_log.info(
                "tool_retry: retrying %s (attempt %d/%d) after %s",
                tool_name, self._attempts[tool_name], self.max_retries,
                type(error).__name__ if error else "error",
            )
            await asyncio.sleep(self.backoff * self._attempts[tool_name])
        return None


class SummarizationOptimizer(BasePlugin):
    """Log when ADK's native context-window compaction kicks in.

    ADK has built-in ``ContextWindowCompressionConfig`` set on
    ``RunConfig``; this plugin doesn't replace it — it observes compaction
    events so users see the optimizer fired.
    """

    def __init__(self, name: str = "summarization") -> None:
        super().__init__(name=name)

    async def on_event_callback(self, *, event: Any = None, **_: Any) -> Any:
        actions = getattr(event, "actions", None) if event else None
        if actions is not None and getattr(actions, "compaction", None):
            _audit_log.info("summarization: history compaction event fired")
        return None


class PromptCachingOptimizer(BasePlugin):
    """Track prompt-cache hit/miss rates from ``Event.cache_metadata``."""

    def __init__(self, name: str = "prompt_caching") -> None:
        super().__init__(name=name)
        self.hits = 0
        self.misses = 0

    async def on_event_callback(self, *, event: Any = None, **_: Any) -> Any:
        meta = getattr(event, "cache_metadata", None) if event else None
        if meta is None:
            return None
        if getattr(meta, "cached_content_token_count", 0):
            self.hits += 1
        else:
            self.misses += 1
        return None


# ---------------------------------------------------------------------------
# OBSERVERS
# ---------------------------------------------------------------------------


class AuditLogObserver(BasePlugin):
    """Emit a structured audit log + OTel span for every tool call."""

    def __init__(self, name: str = "audit_log") -> None:
        super().__init__(name=name)

    async def before_tool_callback(
        self, *, tool: Any = None, tool_args: Dict[str, Any] | None = None, **_: Any,
    ) -> Any:
        tool_name = getattr(tool, "name", type(tool).__name__) if tool else "unknown"
        _audit_log.info("tool_call name=%s args=%s", tool_name, tool_args or {})
        with _tracer().start_as_current_span("gen_ai.execute_tool") as span:
            span.set_attribute("gen_ai.tool.name", tool_name)
        return None

    async def after_tool_callback(
        self, *, tool: Any = None, result: Any = None, **_: Any,
    ) -> Any:
        tool_name = getattr(tool, "name", type(tool).__name__) if tool else "unknown"
        _audit_log.info(
            "tool_result name=%s result_chars=%d",
            tool_name, len(str(result)) if result is not None else 0,
        )
        return None


class CostTrackingObserver(BasePlugin):
    """Aggregate ``Event.usage_metadata`` across the run; emit summary on close."""

    def __init__(self, name: str = "cost_tracking") -> None:
        super().__init__(name=name)
        self.total_in = 0
        self.total_out = 0
        self.total_cached = 0
        self.total_thinking = 0

    async def on_event_callback(self, *, event: Any = None, **_: Any) -> Any:
        usage = getattr(event, "usage_metadata", None) if event else None
        if usage is None:
            return None
        self.total_in += getattr(usage, "prompt_token_count", 0) or 0
        self.total_out += getattr(usage, "candidates_token_count", 0) or 0
        self.total_cached += getattr(usage, "cached_content_token_count", 0) or 0
        self.total_thinking += getattr(usage, "thoughts_token_count", 0) or 0
        return None

    async def after_run_callback(self, **_: Any) -> Any:
        _cost_log.info(
            "run_total prompt=%d candidates=%d cached=%d thinking=%d",
            self.total_in, self.total_out, self.total_cached, self.total_thinking,
        )
        with _tracer().start_as_current_span("gen_ai.session_summary") as span:
            span.set_attribute("gen_ai.usage.input_tokens", self.total_in)
            span.set_attribute("gen_ai.usage.output_tokens", self.total_out)
            span.set_attribute("gen_ai.usage.cached_tokens", self.total_cached)
            span.set_attribute("gen_ai.usage.thinking_tokens", self.total_thinking)
        return None


class LatencyTrackingObserver(BasePlugin):
    """Record per-tool latency and emit on ``after_tool_callback``."""

    def __init__(self, name: str = "latency_tracking") -> None:
        super().__init__(name=name)
        self._t0: dict[str, float] = {}

    async def before_tool_callback(self, *, tool: Any = None, **_: Any) -> Any:
        if tool is not None:
            self._t0[getattr(tool, "name", type(tool).__name__)] = time.time()
        return None

    async def after_tool_callback(self, *, tool: Any = None, **_: Any) -> Any:
        if tool is None:
            return None
        tool_name = getattr(tool, "name", type(tool).__name__)
        if (start := self._t0.pop(tool_name, None)) is not None:
            elapsed_ms = int((time.time() - start) * 1000)
            _latency_log.info("tool_latency name=%s ms=%d", tool_name, elapsed_ms)
            with _tracer().start_as_current_span("agentflow.tool.latency") as span:
                span.set_attribute("gen_ai.tool.name", tool_name)
                span.set_attribute("agentflow.tool.latency_ms", elapsed_ms)
        return None
