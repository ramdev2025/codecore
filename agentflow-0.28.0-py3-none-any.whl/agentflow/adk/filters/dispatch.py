"""Map cross-backend YAML guards/optimizers/observers → ADK ``BasePlugin`` instances.

This is the equivalent of the ``filters/compiler.py`` other backends ship,
but ADK's ``BasePlugin`` aligns so closely with our cross-backend ``Plugin``
ABC that no compilation step is needed — this is just a typed lookup table
plus support for user-supplied custom callables (``module:function``).

Custom user implementations may be either:

- A ``BasePlugin`` subclass — used as-is
- A plain callable — wrapped in a tiny ``BasePlugin`` adapter that calls
  it on every event the YAML type implies (e.g. a custom guard whose YAML
  type is ``input_validation`` is wrapped to fire on
  ``before_tool_callback``)
"""

from __future__ import annotations

import importlib
from typing import Any, Optional

from agentflow.adk.core.config_models import (
    GuardConfig,
    GuardType,
    ObserverConfig,
    ObserverType,
    OptimizerConfig,
    OptimizerType,
)
from agentflow.adk.filters import builtin as _b


_GUARD_CLASSES = {
    GuardType.PII: _b.PIIGuard,
    GuardType.MODEL_CALL_LIMIT: _b.ModelCallLimitGuard,
    GuardType.TOOL_CALL_LIMIT: _b.ToolCallLimitGuard,
    GuardType.INPUT_VALIDATION: _b.InputValidationGuard,
    GuardType.CONTENT_FILTER: _b.ContentFilterGuard,
}

_OPTIMIZER_CLASSES = {
    OptimizerType.TOOL_RETRY: _b.ToolRetryOptimizer,
    OptimizerType.SUMMARIZATION: _b.SummarizationOptimizer,
    OptimizerType.PROMPT_CACHING: _b.PromptCachingOptimizer,
}

_OBSERVER_CLASSES = {
    ObserverType.AUDIT_LOG: _b.AuditLogObserver,
    ObserverType.COST_TRACKING: _b.CostTrackingObserver,
    ObserverType.LATENCY_TRACKING: _b.LatencyTrackingObserver,
}


def build_guard(g: GuardConfig) -> Any:
    if g.module and g.function:
        return _custom_callable_plugin(g.module, g.function, g.config or {}, name=g.type.value)
    cls = _GUARD_CLASSES.get(g.type)
    if cls is None:
        raise ValueError(f"Unknown guard type: {g.type!r}")  # pragma: no cover
    return cls(**(g.config or {}))


def build_optimizer(o: OptimizerConfig) -> Any:
    if o.module and o.function:
        return _custom_callable_plugin(o.module, o.function, o.config or {}, name=o.type.value)
    cls = _OPTIMIZER_CLASSES.get(o.type)
    if cls is None:
        raise ValueError(f"Unknown optimizer type: {o.type!r}")  # pragma: no cover
    return cls(**(o.config or {}))


def build_observer(o: ObserverConfig) -> Any:
    if o.module and o.function:
        return _custom_callable_plugin(o.module, o.function, o.config or {}, name=o.type.value)
    cls = _OBSERVER_CLASSES.get(o.type)
    if cls is None:
        raise ValueError(f"Unknown observer type: {o.type!r}")  # pragma: no cover
    return cls(**(o.config or {}))


def _custom_callable_plugin(
    module_path: str, function_name: str, config: dict, *, name: str,
) -> Any:
    """Wrap a user callable in a BasePlugin that fires on every event type.

    The callable receives ``(event_name, **kwargs)`` so a single function
    can implement guard/optimizer/observer behaviour. Returning a value
    has no effect; raise to block.
    """

    from google.adk.plugins.base_plugin import BasePlugin

    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Custom plugin module {module_path!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"Custom plugin module {module_path!r} has no attribute {function_name!r}"
        )
    if not callable(fn):
        raise TypeError(f"Custom plugin {module_path}.{function_name} is not callable")

    class _CustomBridge(BasePlugin):
        def __init__(self) -> None:
            super().__init__(name=name)
            self._fn = fn
            self._config = config

        async def before_tool_callback(self, **kwargs: Any) -> Any:
            await self._dispatch("before_tool", kwargs)

        async def after_tool_callback(self, **kwargs: Any) -> Any:
            await self._dispatch("after_tool", kwargs)

        async def before_model_callback(self, **kwargs: Any) -> Any:
            await self._dispatch("before_model", kwargs)

        async def after_model_callback(self, **kwargs: Any) -> Any:
            await self._dispatch("after_model", kwargs)

        async def on_event_callback(self, **kwargs: Any) -> Any:
            await self._dispatch("on_event", kwargs)

        async def _dispatch(self, event_name: str, kwargs: dict) -> None:
            import asyncio
            try:
                result = self._fn(event_name=event_name, config=self._config, **kwargs)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                # Re-raise GuardBlockedError so guards halt the run; swallow
                # everything else so optimizers/observers can't break agents.
                from agentflow.adk.filters.builtin import GuardBlockedError
                if isinstance(exc, GuardBlockedError):
                    raise
                # else swallow

    return _CustomBridge()
