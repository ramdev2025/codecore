"""Built-in cross-backend tier (guards, optimizers, observers).

These are implemented directly as ADK ``BasePlugin`` subclasses — there is
no separate compiler step for ADK because ``BasePlugin`` already lines up
with our cross-backend ``Plugin`` ABC. The builder maps each YAML guard /
optimizer / observer entry to one of these classes via a small dispatch
table.
"""

from agentflow.adk.filters.builtin import (
    AuditLogObserver,
    ContentFilterGuard,
    CostTrackingObserver,
    InputValidationGuard,
    LatencyTrackingObserver,
    ModelCallLimitGuard,
    PIIGuard,
    PromptCachingOptimizer,
    SummarizationOptimizer,
    ToolCallLimitGuard,
    ToolRetryOptimizer,
)
from agentflow.adk.filters.dispatch import (
    build_guard,
    build_observer,
    build_optimizer,
)

__all__ = [
    "AuditLogObserver",
    "ContentFilterGuard",
    "CostTrackingObserver",
    "InputValidationGuard",
    "LatencyTrackingObserver",
    "ModelCallLimitGuard",
    "PIIGuard",
    "PromptCachingOptimizer",
    "SummarizationOptimizer",
    "ToolCallLimitGuard",
    "ToolRetryOptimizer",
    "build_guard",
    "build_observer",
    "build_optimizer",
]
