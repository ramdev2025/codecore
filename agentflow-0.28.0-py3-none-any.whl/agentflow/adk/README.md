# AgentFlow ADK

**YAML-driven agents on Google's [Agent Development Kit](https://google.github.io/adk-docs/).**

Seventh backend of AgentFlow, alongside `workflows` (LangGraph), `deep` (DeepAgents), `sk` (Semantic Kernel), `cas` (Claude Agent SDK), `oai` (OpenAI Agents SDK), and `maf` (Microsoft Agent Framework). Install with `pip install agentflow[adk]` — or `pip install agentflow[adk-extensions]` to also pull `google-adk[extensions]` for non-Gemini providers via LiteLLM.

The ADK backend brings ADK's dual-mode toolkit — **autonomous** `LlmAgent` with sub-agent delegation **and** deterministic `SequentialAgent` / `ParallelAgent` / `LoopAgent` workflows — under one YAML schema, one CLI, and the same cross-cutting tier as every other backend.

---

## Supported features (v1)

| Feature | YAML surface | Notes |
| --- | --- | --- |
| Model selection | `llm.config.model` | Plain string for Gemini / Vertex; LiteLLM wraps for OpenAI / Anthropic / Azure / Ollama / vLLM |
| Provider dispatch | `llm.provider` | `gemini` / `vertex` / `litellm` / `azure_openai` / `custom` |
| Azure OpenAI RBAC turn-key | `provider: azure_openai` | v0.22.1 — `DefaultAzureCredential` via `litellm.enable_azure_ad_token_refresh`; no subclass, no API key |
| Generation knobs | `llm.config.generate_content_config` | Forwarded to ADK's `GenerateContentConfig` |
| Per-agent LLM override | `agent.llm` or `agent.model` shorthand | Each agent in the tree can override the top-level default |
| Autonomous `LlmAgent` | `agent.type: llm` (default) | The standard agentic loop with tool use |
| Sub-agent delegation | `agent.sub_agents[]` + AutoFlow | `transfer_to_agent` is added automatically |
| Sequential workflow | `agent.type: sequential` | Children run in declaration order; state threaded via `output_key` |
| Parallel workflow | `agent.type: parallel` | Children run concurrently |
| Loop workflow | `agent.type: loop`, `max_iterations` | Repeats until escalate / max iterations |
| Workflow nesting | unlimited depth | A loop can wrap a parallel can wrap an llm with sub-agents |
| Tools — built-ins | `agent.tools.builtin[]` | `google_search`, `vertex_ai_search`, `exit_loop`, `transfer_to_agent`, `get_user_choice`, `load_artifacts`, `load_memory`, `preload_memory`, `url_context`, `enterprise_web_search`, `google_maps_grounding` |
| Tools — Python plugins | `agent.tools.plugins[]` | Plain callables auto-wrapped in `FunctionTool` |
| Tools — agent-as-tool | `agent.tools.agent_as_tool[]` | Sibling agents wrapped via `AgentTool` (resolved in pass 2) |
| Tools — MCP toolsets | `agent.tools.mcp_servers[]` + top-level `mcp_servers:` | `stdio` / `sse` / `streamable_http` transports |
| Per-agent callbacks | `agent.callbacks.*` | 8 slots: before/after agent, before/after model, on_model_error, before/after tool, on_tool_error |
| ADK BasePlugin refs | top-level `plugins:` | Tree-wide lifecycle hooks via `Runner(plugins=[...])` |
| Cross-backend portable tier | `guards` / `optimizers` / `observers` | Compiled to BasePlugin instances via dispatch table |
| Plugin bridge | (automatic) | AgentFlow `Plugin` ABC instances wrapped in `BasePlugin` adapter |
| Output schema | `agent.output_schema` (`module:class`) | Pydantic class enforced as response shape; disables tool calls |
| Planner | `agent.planner` (`built_in` with `thinking` / `react`) | Maps to `BuiltInPlanner` / `PlanReActPlanner` |
| Code executor | `agent.code_executor` | `built_in` / `container` / `unsafe_local` / `vertex_ai` |
| Persistence — SessionService | `persistence` (`in_memory` / `sqlite` / `postgres` / `vertex`) | Auto-upgrades to async drivers (`sqlite+aiosqlite`, `postgresql+asyncpg`) |
| Thread-id binding | `--thread-id` | Bridges to ADK's internal `session_id` via `AdkPersistenceManager` |
| AES-GCM encryption at rest | `AGENTFLOW_ENCRYPTION_KEY` | Encrypts the binding (ADK SessionService handles its own at-rest crypto separately) |
| Memory — vector | `memory` (`in_memory` / `vertex_rag` / `vertex_memory_bank`) | `MemoryService` injection into the runner |
| Artifacts | `artifacts` (`in_memory` / `file` / `gcs`) | `ArtifactService` injection |
| Vertex AI Agent Engine deploy | `serving.type: vertex_agent_engine` | Target declared; deploy CLI is a follow-up |
| OpenTelemetry tracing | `OTEL_TRACES_ENABLED=true` | `gen_ai.execute_tool`, `gen_ai.session_summary`, `agentflow.tool.latency`, `agentflow.adk.run` |
| Streaming | automatic | Token streaming + `▸ tool(args)` / `← tool result · N chars` markers |
| JSON event output | `--output ndjson` | Same shared schema as workflows / sk / cas / oai / maf |

---

## Deferred / not yet implemented

These exist in ADK but aren't surfaced in v1 — adding them is mostly schema work, but each carries enough complexity to be its own follow-up.

- **Bidirectional live streaming (`StreamingMode.BIDI`)** — voice / audio input via `LiveRequestQueue`. Requires an additional CLI mode beyond `query` / `interactive`.
- **Vertex AI Agent Engine `deploy` command** — the YAML's `serving:` block declares the target; a separate `agentflow adk deploy` CLI is planned.
- **`tool_confirmation` / HITL gating from YAML** — ADK supports `requested_tool_confirmations` on events, but the schema doesn't yet surface a declarative form.
- **`CredentialService`** — for OAuth tokens persisted between invocations. Schema can pass through but no first-class block.
- **A2A protocol bridge** — ADK's killer feature for cross-framework interop. Defer until there's a clear cross-backend story (agentflow already does cross-backend at the YAML layer).

---

## Architecture

The ADK backend follows the same layout as `cas` / `oai` / `maf`:

```
src/agentflow/adk/
├── __init__.py             # public API: AdkYAMLConfig
├── README.md               # this file
├── cli.py                  # run_from_router + streaming renderer + JSON sink
├── docs_cli.py             # mkdocs serve launcher (port 9600)
├── mkdocs.yml
├── telemetry.py            # setup_tracing
├── core/
│   ├── builder.py          # AdkAgentBuilder — two-pass tree build
│   ├── config_models.py    # Pydantic schema, discriminated AgentSpec union
│   ├── helpers.py          # env-var interpolation, .env loading
│   ├── service_factory.py  # 5-provider dispatch (gemini / vertex / litellm / azure_openai / custom)
│   ├── tool_factory.py     # built-in tools, planner, code executor, output schema
│   ├── plugin_registry.py  # Python module → callables for FunctionTool wrapping
│   ├── callback_registry.py # 8 callback slots, single ref or list
│   ├── mcp.py              # 3 MCP transports → McpToolset
│   ├── persistence.py      # thread-id ↔ session-id binding (in-memory / sqlite / postgres) + AES-GCM
│   └── plugin_bridge.py    # AgentFlow Plugin ABC → ADK BasePlugin adapter
├── filters/
│   ├── builtin.py          # 11 BasePlugin subclasses (5 guards, 3 optimizers, 3 observers)
│   └── dispatch.py         # YAML config → BasePlugin instance (replaces SK-style compiler)
└── docs/                   # 18 markdown pages + LICENSE
```

### Two-pass tree build

ADK's `AgentTool` wrapping needs the target agent already constructed. The builder does two post-order traversals:

1. **Pass 1** — build every `LlmAgent` / `SequentialAgent` / `ParallelAgent` / `LoopAgent` and register by name in `_agents_by_name`.
2. **Pass 2** — for every `LlmAgent` that declares `agent_as_tool: [name1, ...]`, wrap each named agent in `AgentTool` and append to that agent's `tools` list.

This avoids forward-reference tracking during pass 1 and keeps construction order strictly leaves-first.

### `BasePlugin` over compiler

Other backends (CAS, SK) compile the cross-backend `guards` / `optimizers` / `observers` tier into backend-specific hook shapes via a dedicated compiler module. ADK skips that step — the alignment between AgentFlow's `Plugin` ABC and ADK's `BasePlugin` is so close that a typed lookup in `filters/dispatch.py` is sufficient. Each YAML entry resolves to a `BasePlugin` subclass instance and is appended to `Runner(plugins=[...])`.

### Async-driver auto-upgrade

ADK's `DatabaseSessionService` requires async SQLAlchemy drivers; plain `sqlite:///` raises an opaque `InvalidRequestError`. The builder transparently rewrites:

- `sqlite:///path` → `sqlite+aiosqlite:///path`
- `postgresql://...` → `postgresql+asyncpg://...`

so the canonical persistence URLs work without user-side changes.

---

## Quick start

```yaml
# agent.yaml
backend: adk
metadata:
  version: "1.0"
  name: assistant
llm:
  provider: gemini
  config:
    model: gemini-2.5-flash
    api_key: ${GOOGLE_API_KEY}
agent:
  name: assistant
  instruction: You are a helpful assistant.
```

```bash
export GOOGLE_API_KEY=...
agentflow --yaml agent.yaml --dry-run     # validate
agentflow --yaml agent.yaml "Hello!"      # run
```

For the full surface (workflow agents, MCP, callbacks, guards / optimizers / observers, persistence, OTel), see the docs:

```bash
agentflow-docs --backend adk    # http://localhost:9600
agentflow docs              # direct alias
```

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See `docs/LICENSE.md` for complete terms.

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
