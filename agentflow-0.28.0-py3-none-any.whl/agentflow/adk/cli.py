"""AgentFlow ADK CLI — run Google ADK agents from the unified ``agentflow`` command.

The CLI router dispatches ``backend: adk`` to :func:`run_from_router` in
this module. It translates canonical flags into ADK-specific concerns
(``SessionService`` selection, thread-id ↔ session-id binding, streaming
renderer for ``Event`` objects) and prints output to the console.

Three modes:

- **Dry-run** — validates the YAML, prints a config summary, exits.
- **One-shot** — runs ``Runner.run_async`` once with the user's query,
  streams events live, prints elapsed time.
- **Interactive** — REPL loop calling ``run_async`` per turn; the
  thread-id ↔ session-id binding makes ``--thread-id`` resume the same
  ADK session across processes.

Streaming renderer covers the ADK event types most users will see:

- ``▸ ToolName(args)`` for ``event.get_function_calls()``
- ``← tool result · N chars`` for ``event.get_function_responses()``
- ``↳ transfer to <agent>`` for ``event.actions.transfer_to_agent``
- ``· thinking…`` for events whose first part is a thought
- Final text streams inline

ADK ships its own GenAI diagnostic spans; ``setup_tracing()`` here just
installs the provider and our observers add a session-summary span.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any, Optional

from agentflow.cli import (
    ExecutionTimer,
    console,
    print_banner,
    print_config_table,
    print_error,
    print_execution_summary,
    print_info,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_AGENT_SWITCH,
    EVENT_COMPLETE,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)


def run_from_router(
    yaml_path: str,
    query: Optional[str] = None,
    persistence: Optional[str] = None,
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
    thread_id: Optional[str] = None,
    interactive: bool = False,
    dry_run: bool = False,
    json_output: bool = False,
    output: str = "tty",
    **_ignored: Any,
):
    """Entry point called by the unified CLI router.

    Cross-backend flags that don't apply to ADK (``workdir``, ``no_tui``,
    ``tools_module``, ``recursion_limit``) are absorbed via ``**_ignored``.
    """

    # Load the project ``.env`` *before* anything else so OTEL_* env vars
    # land in os.environ before ``setup_tracing()`` reads them. The builder
    # also re-loads via ``load_dotenv_for(yaml_path)``, which is fine —
    # ``override=True`` keeps the same precedence either way.
    from dotenv import find_dotenv, load_dotenv

    env_path = find_dotenv(usecwd=True)
    if env_path:
        load_dotenv(env_path, override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(
        getattr(logging, log_level, logging.WARNING)
    )

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    if dry_run:
        _run_dry(yaml_path, json_output=json_output)
        return

    json_sink: Optional[JsonSink] = (
        JsonSink(backend="adk") if is_json_mode(output) else None
    )
    if json_sink is None:
        print_banner(
            "AgentFlow ADK",
            "Run Google Agent Development Kit agents from the command line",
        )

    from agentflow.adk.telemetry import setup_tracing

    setup_tracing()

    try:
        from agentflow.adk.core.builder import AdkAgentBuilder
    except ImportError:
        print_error(
            "google-adk is required but not installed. "
            "Install with: pip install agentflow[adk]"
        )
        raise SystemExit(1)

    builder = AdkAgentBuilder.from_yaml(yaml_path)

    # CLI / env vars override the YAML ``persistence:`` block. When an
    # override is built, the YAML's persistence config is replaced before
    # ``builder.build()`` wires the SessionService.
    cli_override = _persistence_config_from_cli(persistence, db_path, connection_string)
    if builder.config.persistence is not None:
        logging.getLogger(__name__).warning(
            "The 'persistence:' section in %s is deprecated and will be "
            "ignored for memory/sqlite/postgres backends. Persistence "
            "backend is an infrastructure concern and must be configured "
            "via CLI flags (--persistence / --db-path / --connection-string) "
            "or environment variables (AGENTFLOW_PERSISTENCE, "
            "POSTGRES_CONNECTION_STRING, CHECKPOINTER_DB_PATH). The "
            "'vertex' type still requires YAML until env-var support is "
            "added. Remove the 'persistence:' section to silence this "
            "warning.",
            yaml_path,
        )
    if cli_override is not None:
        builder.config.persistence = cli_override

    runner = builder.build()

    # Effective backend label for the binding table + header (the resolved
    # value may have come from CLI flag, env var, or the YAML's vertex
    # fallback). Defaults to sqlite when nothing else is specified.
    effective_persistence = _effective_persistence(persistence, builder.config.persistence)
    pm = _build_persistence(effective_persistence, db_path, connection_string)
    tid = thread_id or str(uuid.uuid4())
    session_id = _resolve_session_id(pm, tid, effective_persistence)

    if json_sink is None:
        _print_run_header(yaml_path, effective_persistence, tid, runner.config.agent.type.value)

    if interactive and json_sink is None:
        _run_interactive(runner, pm, tid, session_id)
    else:
        if not query:
            query = prompt_user("Query") if json_sink is None else ""
        if not query:
            return
        _run_one_shot(runner, query, pm, tid, session_id, json_sink=json_sink)


# ---------------------------------------------------------------------------
# Dry-run
# ---------------------------------------------------------------------------


def _run_dry(yaml_path: str, json_output: bool = False) -> None:
    try:
        from agentflow.adk.core.builder import AdkAgentBuilder
    except ImportError:
        print_error(
            "google-adk is required but not installed. "
            "Install with: pip install agentflow[adk]"
        )
        raise SystemExit(1)

    builder = AdkAgentBuilder.from_yaml(yaml_path)
    runner = builder.build()
    summary = runner.dry_run()

    if json_output:
        print(json.dumps(summary, indent=2, default=str))
        return

    print_banner(
        "AgentFlow ADK",
        "Run Google Agent Development Kit agents from the command line",
    )
    root = summary["root_agent"]
    services = summary["services"]
    rows = [
        ("Backend", "adk"),
        ("Config", yaml_path),
        ("Name", summary["metadata"].get("name") or "-"),
        ("Root agent", root["name"]),
        ("Root type", root["type"]),
        ("Model", root.get("model") or "-"),
        ("Tools", str(root.get("tools", 0))),
        ("Sub-agents", str(len(root.get("sub_agents") or []))),
        ("Session service", services.get("session") or "-"),
        ("Memory service", services.get("memory") or "-"),
        ("Artifact service", services.get("artifact") or "-"),
        ("Plugins", str(len(services.get("plugins") or []))),
    ]
    if summary.get("serving"):
        rows.append(("Serving", summary["serving"].get("type") or "-"))
    print_config_table(rows)
    console.print("[bold green]Config is valid.[/bold green]")


# ---------------------------------------------------------------------------
# Persistence (thread_id ↔ ADK session_id binding)
# ---------------------------------------------------------------------------


_ADK_VALID_BACKENDS = {"memory", "in_memory", "sqlite", "postgres"}


def _persistence_config_from_cli(
    persistence: Optional[str],
    db_path: Optional[str],
    connection_string: Optional[str],
) -> Optional[Any]:
    """Build an ADK ``PersistenceConfig`` override from CLI flags + env vars.

    Returns ``None`` when neither CLI flags nor any persistence-selecting
    env var is set — caller leaves ``builder.config.persistence`` alone
    (which may carry a YAML-supplied vertex config).

    Selecting env vars:
        AGENTFLOW_PERSISTENCE         memory | sqlite | postgres
        POSTGRES_CONNECTION_STRING    implies postgres
        CHECKPOINTER_DB_PATH          implies sqlite
    """
    # Local import — avoids loading google-adk just to parse flags.
    from agentflow.adk.core.config_models import PersistenceConfig, PersistenceType

    env_backend = os.environ.get("AGENTFLOW_PERSISTENCE")
    env_db_path = os.environ.get("CHECKPOINTER_DB_PATH")
    env_conn = os.environ.get("POSTGRES_CONNECTION_STRING")

    if (
        persistence is None
        and db_path is None
        and connection_string is None
        and env_backend is None
        and env_db_path is None
        and env_conn is None
    ):
        return None

    backend = persistence or env_backend
    if backend is None:
        backend = "postgres" if (connection_string or env_conn) else "sqlite"
    backend = backend.strip().lower()
    if backend not in _ADK_VALID_BACKENDS:
        raise ValueError(
            f"Unknown persistence backend: {backend!r}. "
            f"Expected one of: {sorted(_ADK_VALID_BACKENDS)}."
        )

    if backend in ("memory", "in_memory"):
        return PersistenceConfig(type=PersistenceType.IN_MEMORY)

    if backend == "postgres":
        conn = connection_string or env_conn
        if not conn:
            raise ValueError(
                "Postgres persistence requires --connection-string or "
                "the POSTGRES_CONNECTION_STRING environment variable."
            )
        return PersistenceConfig(
            type=PersistenceType.POSTGRES,
            connection_string=conn,
        )

    # SQLite
    return PersistenceConfig(
        type=PersistenceType.SQLITE,
        db_path=db_path or env_db_path or ".agentflow/adk_sessions.db",
    )


def _effective_persistence(cli_value: Optional[str], yaml_cfg: Optional[Any]) -> str:
    """Resolve the persistence label used by the binding table + run header.

    The binding-table factory takes a string (``memory``/``sqlite``/
    ``postgres``); the YAML config (if it survived as vertex) carries a
    ``PersistenceType`` enum. CLI flag wins; otherwise translate the
    YAML's type back to a string; otherwise default to sqlite.
    """
    if cli_value:
        return cli_value
    env_backend = os.environ.get("AGENTFLOW_PERSISTENCE")
    if env_backend:
        return env_backend.strip().lower()
    if yaml_cfg is not None:
        t = yaml_cfg.type.value
        # ``in_memory`` and ``vertex`` aren't binding-table backends —
        # the binding table only knows memory/sqlite/postgres. ``vertex``
        # apps just don't get a local binding table; sessions are managed
        # remotely.
        if t == "in_memory":
            return "memory"
        if t in ("sqlite", "postgres"):
            return t
        return "memory"  # vertex → no binding table
    return "sqlite"


def _build_persistence(
    persistence: str, db_path: Optional[str], connection_string: Optional[str],
) -> Optional[Any]:
    if persistence == "memory":
        return None
    from agentflow.adk.core.persistence import create_persistence_manager

    # AGENTFLOW_ENCRYPTION_KEY is the cross-backend env var for at-rest
    # encryption — ADK's binding-table factory accepts it as bytes.
    enc_key_str = os.environ.get("AGENTFLOW_ENCRYPTION_KEY")
    enc_key_bytes = enc_key_str.encode("utf-8") if enc_key_str else None

    return create_persistence_manager(
        backend=persistence,
        db_path=db_path or os.environ.get("CHECKPOINTER_DB_PATH"),
        connection_string=connection_string or os.environ.get("POSTGRES_CONNECTION_STRING"),
        encryption_key=enc_key_bytes,
    )


def _resolve_session_id(
    pm: Optional[Any], thread_id: str, persistence: str,
) -> str:
    """Look up (or generate) the ADK session_id bound to ``thread_id``."""
    if pm is None:
        return thread_id  # in-memory: thread id IS the session id
    existing = pm.get_session_id(thread_id)
    if existing is not None:
        return existing
    new = str(uuid.uuid4())
    pm.put_session_id(thread_id, new)
    return new


# ---------------------------------------------------------------------------
# Run header
# ---------------------------------------------------------------------------


def _print_run_header(yaml_path: str, persistence: str, thread_id: str, mode: str) -> None:
    print_info(f"Config: {yaml_path}")
    print_info(f"Mode: {mode}")
    print_info(f"Persistence: {persistence}")
    print_info(f"Thread: {thread_id}")
    console.print()


# ---------------------------------------------------------------------------
# One-shot + interactive
# ---------------------------------------------------------------------------


def _run_one_shot(
    runner: Any,
    query: str,
    pm: Optional[Any],
    thread_id: str,
    session_id: str,
    json_sink: Optional[JsonSink] = None,
) -> None:
    if json_sink is None:
        console.print()
    timer = ExecutionTimer()
    timer.start()
    asyncio.run(
        _drive_query(runner, query, pm, thread_id, session_id, json_sink=json_sink)
    )
    if json_sink is not None:
        json_sink.emit(EVENT_STATS, elapsed_s=timer.elapsed())
        json_sink.emit(EVENT_COMPLETE)
    else:
        print_execution_summary(console, timer.elapsed())


def _run_interactive(
    runner: Any,
    pm: Optional[Any],
    thread_id: str,
    session_id: str,
) -> None:
    init_history()
    repl_state = ReplState(thread_id=thread_id)
    console.print(
        "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, "
        "[bold]/quit[/bold] to exit\n"
    )
    while True:
        try:
            q = prompt_user("Query")
            if is_quit_alias(q):
                console.print("\nGoodbye.")
                break
            if not q.strip():
                continue
            if is_slash_command(q):
                if dispatch_slash_command(q, repl_state, console) == "quit":
                    console.print("\nGoodbye.")
                    break
                continue

            console.print()
            timer = ExecutionTimer()
            timer.start()
            asyncio.run(_drive_query(runner, q, pm, thread_id, session_id))
            print_execution_summary(console, timer.elapsed())
        except (KeyboardInterrupt, EOFError):
            console.print("\nGoodbye.")
            break
        except Exception as e:
            from agentflow.cli.errors import friendly_error
            print_error(friendly_error(e))
    cleanup_terminal_state()


# ---------------------------------------------------------------------------
# Stream driver
# ---------------------------------------------------------------------------


async def _drive_query(
    runner: Any,
    query_text: str,
    pm: Optional[Any],
    thread_id: str,
    session_id: str,
    json_sink: Optional[JsonSink] = None,
) -> None:
    """Stream events from one ADK turn, rendering live.

    Wraps the call in an ``agentflow.adk.run`` root span; ADK's own
    diagnostic spans (when configured) nest under it.
    """
    from opentelemetry import trace

    tracer = trace.get_tracer("agentflow.adk")
    renderer = _StreamRenderer(console) if json_sink is None else None

    with tracer.start_as_current_span(
        "agentflow.adk.run",
        attributes={
            "agentflow.backend": "adk",
            "agentflow.thread_id": thread_id,
            "agentflow.session_id": session_id,
        },
    ):
        async for event in runner.query(
            query_text, user_id="default", session_id=session_id,
        ):
            if json_sink is not None:
                _emit_json_event(json_sink, event, runner.root_agent.name)
            else:
                renderer.handle(event)

    if pm is not None:
        pm.bump_turns(thread_id)


# ---------------------------------------------------------------------------
# Streaming renderer (TTY)
# ---------------------------------------------------------------------------


class _StreamRenderer:
    """Render ADK events to the terminal.

    State is per-run; a new renderer is constructed for each ``_drive_query``
    so partial-text accumulators reset between turns.
    """

    def __init__(self, console: Any) -> None:
        self.console = console
        self._partial_buf: str = ""
        self._partial_active: bool = False

    def handle(self, event: Any) -> None:
        # Tool calls — render as ▸ name(args)
        for fn_call in event.get_function_calls() or []:
            args = _short_args(fn_call.args or {})
            self.console.print(f"[bold cyan]▸[/bold cyan] {fn_call.name}({args})")

        # Tool results — render as ← name result · N chars
        for fn_resp in event.get_function_responses() or []:
            response = fn_resp.response or {}
            result_text = _result_preview(response)
            self.console.print(
                f"[dim]← {fn_resp.name} result · {len(str(response))} chars[/dim]"
            )

        # Agent transfer
        actions = getattr(event, "actions", None)
        if actions is not None:
            target = getattr(actions, "transfer_to_agent", None)
            if target:
                self.console.print(f"[bold magenta]↳[/bold magenta] transfer to {target}")
            if getattr(actions, "escalate", None):
                self.console.print("[dim]↑ escalate[/dim]")

        # Thinking content
        content = getattr(event, "content", None)
        if content is not None:
            for part in getattr(content, "parts", []) or []:
                if getattr(part, "thought", False):
                    text = (getattr(part, "text", "") or "").strip()
                    if text:
                        # First non-empty thought line; suppress the rest to
                        # avoid drowning the TTY.
                        self.console.print(f"[dim italic]· {text[:120]}[/dim italic]")
                    continue

        # Token streaming for partial text
        if getattr(event, "partial", False):
            text = _extract_text(event)
            if text:
                self.console.print(text, end="")
                self._partial_active = True
                self._partial_buf += text
            return

        # Final response — text not yet rendered as partial
        if event.is_final_response():
            text = _extract_text(event)
            if text and not self._partial_active:
                self.console.print(text)
            elif self._partial_active:
                # Close the streamed line
                self.console.print()
                self._partial_active = False
                self._partial_buf = ""


def _short_args(args: dict, limit: int = 80) -> str:
    """Render a tool's args dict in a single line, truncating long values."""
    if not args:
        return ""
    out = []
    for k, v in args.items():
        s = str(v)
        if len(s) > 30:
            s = s[:27] + "…"
        out.append(f"{k}={s}")
    rendered = ", ".join(out)
    if len(rendered) > limit:
        rendered = rendered[: limit - 1] + "…"
    return rendered


def _result_preview(response: Any, limit: int = 80) -> str:
    s = str(response)
    return s[:limit] + ("…" if len(s) > limit else "")


def _extract_text(event: Any) -> str:
    content = getattr(event, "content", None)
    if content is None:
        return ""
    pieces: list[str] = []
    for part in getattr(content, "parts", []) or []:
        # Skip thoughts (already rendered separately)
        if getattr(part, "thought", False):
            continue
        text = getattr(part, "text", None)
        if text:
            pieces.append(text)
    return "".join(pieces)


# ---------------------------------------------------------------------------
# JSON sink event mapping
# ---------------------------------------------------------------------------


def _emit_json_event(sink: JsonSink, event: Any, root_name: str) -> None:
    """Translate ADK events to the shared ndjson schema."""

    for fn_call in event.get_function_calls() or []:
        sink.emit(
            EVENT_TOOL_CALL,
            tool_name=fn_call.name,
            args=fn_call.args or {},
            agent=getattr(event, "author", None) or root_name,
        )

    for fn_resp in event.get_function_responses() or []:
        sink.emit(
            EVENT_TOOL,
            tool_name=fn_resp.name,
            result=fn_resp.response,
            agent=getattr(event, "author", None) or root_name,
        )

    actions = getattr(event, "actions", None)
    if actions is not None:
        target = getattr(actions, "transfer_to_agent", None)
        if target:
            sink.emit(EVENT_AGENT_SWITCH, agent=target)

    content = getattr(event, "content", None)
    if content is None:
        return
    for part in getattr(content, "parts", []) or []:
        if getattr(part, "thought", False):
            text = getattr(part, "text", None)
            if text:
                sink.emit(EVENT_REASONING, content=text)
            continue
        text = getattr(part, "text", None)
        if not text:
            continue
        if getattr(event, "partial", False):
            sink.emit(EVENT_TOKEN, content=text)
        elif event.is_final_response():
            sink.emit(EVENT_TOKEN, content=text, final=True)
