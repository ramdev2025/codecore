"""AgentFlow integration for Google's Agent Development Kit (ADK).

The ADK backend exposes Google's ``google-adk`` Python SDK through the same
YAML schema, CLI, and cross-cutting tier as the other backends. ADK ships
both autonomous (``LlmAgent`` with sub-agents + AutoFlow ``transfer_to_agent``)
and deterministic (``SequentialAgent``, ``ParallelAgent``, ``LoopAgent``)
primitives — both are surfaced through a single ``agent:`` root with a
``type:`` discriminator (``llm`` | ``sequential`` | ``parallel`` | ``loop``).
"""

from agentflow.adk.core.config_models import AdkYAMLConfig

__all__ = ["AdkYAMLConfig"]
