"""Shared helpers for inline streaming renderers.

These were originally hand-rolled inside ``agentflow/maf/cli.py``. The
workflows backend now needs the same primitives (compact tool-args
formatting, length/preview/pretty-print of tool results) to reach
parity with maf/oai/cas streaming output, so they live here.

No Rich imports — each backend's renderer wraps these for terminal output.
"""

from __future__ import annotations

import json
from typing import Any, Optional


def short_args(args: Any, limit: int = 110) -> str:
    """Best-effort compact rendering of tool-call arguments.

    Accepts a dict, a JSON string, or anything stringifiable. Renders
    dict-like inputs as ``key=val, key2=val2`` (truncated with ``…``
    when over budget) so the user can see *what* the tool was called
    with without flooding the terminal.
    """
    if args is None:
        return ""
    if isinstance(args, str):
        s = args.strip()
        if s.startswith("{") and s.endswith("}"):
            try:
                parsed = json.loads(s)
                if isinstance(parsed, dict):
                    return short_args(parsed, limit)
            except Exception:
                pass
        if len(s) <= limit:
            return s
        return s[: limit - 1] + "…"
    if isinstance(args, dict):
        pairs: list[str] = []
        total = 0
        for k, v in args.items():
            frag = f"{k}={v!r}"
            if total + len(frag) > limit and pairs:
                pairs.append("…")
                break
            pairs.append(frag)
            total += len(frag) + 2  # ", " separator
        return ", ".join(pairs)
    s = repr(args)
    if len(s) <= limit:
        return s
    return s[: limit - 1] + "…"


def result_length(result: Any) -> int:
    """Approximate character length for the ``← result · N chars`` header."""
    if result is None:
        return 0
    if isinstance(result, str):
        return len(result)
    if isinstance(result, (list, dict)):
        try:
            return len(json.dumps(result, default=str))
        except Exception:
            return len(repr(result))
    return len(repr(result))


def result_preview(result: Any, limit: int = 240) -> str:
    """One-line preview of a tool result. Whitespace-collapsed."""
    if result is None:
        return ""
    if isinstance(result, str):
        s = result.strip()
    else:
        try:
            s = json.dumps(result, default=str, ensure_ascii=False)
        except Exception:
            s = repr(result)
    s = " ".join(s.split())
    if len(s) <= limit:
        return s
    return s[: limit - 1] + "…"


def pretty_json_block(
    result: Any,
    *,
    max_chars: int = 2000,
    max_lines: int = 24,
) -> Optional[str]:
    """Pretty-printed JSON if ``result`` is structured AND fits the budget.

    Recursively unwraps single-string / single-element-list envelopes
    that some chat protocols use to wrap JSON tool returns; otherwise
    the user sees a wall of escaped quotes.
    """
    if result is None:
        return None
    parsed = _unwrap_json(result)
    if not isinstance(parsed, (dict, list)):
        return None
    try:
        pretty = json.dumps(parsed, indent=2, ensure_ascii=False, default=str)
    except Exception:
        return None
    if len(pretty) > max_chars:
        return None
    if pretty.count("\n") + 1 > max_lines:
        return None
    return pretty


def _unwrap_json(value: Any, _depth: int = 0) -> Any:
    if _depth > 4:
        return value
    if isinstance(value, str):
        s = value.strip()
        if (s.startswith("{") and s.endswith("}")) or (
            s.startswith("[") and s.endswith("]")
        ):
            try:
                return _unwrap_json(json.loads(s), _depth + 1)
            except Exception:
                return value
        return value
    if isinstance(value, list):
        if len(value) == 1:
            return _unwrap_json(value[0], _depth + 1)
        return [_unwrap_json(v, _depth + 1) for v in value]
    if isinstance(value, dict):
        return {k: _unwrap_json(v, _depth + 1) for k, v in value.items()}
    return value
