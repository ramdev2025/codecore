"""``agentflow-init`` — scaffold a hello-world agent for the installed backend.

Decision tree (per ``CLI_IMPROVEMENTS_PLAN.md``):

- **Exactly one backend installed** → scaffold silently for that backend.
  Zero prompts.
- **Multiple backends installed** → error, point at the
  one-backend-per-venv guidance, suggest ``--backend <name>`` to override.
- **Zero backends installed** → friendly stop with the
  ``pip install agentflow[<extra>]`` recipe for each backend.

Two files are written: a runnable hello-world YAML (named per the
backend's convention) and a matching ``.env.example``. No tools/, no
data/, no README — those are user choices, not framework opinions.
"""

from __future__ import annotations

import argparse
import importlib.util
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from agentflow.cli.errors import wrap_cli_main


# ---------------------------------------------------------------------------
# Backend detection — what's importable in this venv
# ---------------------------------------------------------------------------


# (canonical backend name, importable module) pairs. Ordered for
# deterministic display when multiple are installed; not a priority list.
_BACKEND_PROBE: List[Tuple[str, str]] = [
    ("workflows",        "langgraph"),
    ("deep",             "deepagents"),
    ("semantic-kernel",  "semantic_kernel"),
    ("claude-agent-sdk", "claude_agent_sdk"),
    ("openai-agents",    "agents"),
    ("agent-framework",  "agent_framework"),
    ("adk",              "google.adk"),
]


def detect_all_installed_backends() -> List[str]:
    """Return every backend whose underlying SDK is importable.

    Differs from :func:`agentflow.cli.docs.detect_installed_backends`
    which short-circuits at the first match. We need the full list to
    distinguish the "exactly one" branch from the "multiple installed"
    branch in the init decision tree.
    """
    found: List[str] = []
    for name, module in _BACKEND_PROBE:
        if importlib.util.find_spec(module) is not None:
            found.append(name)
    return found


# ---------------------------------------------------------------------------
# Scaffold templates — one per backend
# ---------------------------------------------------------------------------


@dataclass
class _Template:
    """Definition of a backend's scaffold."""

    yaml_filename: str
    yaml_body: str
    env_body: str
    next_step: str  # one-line instruction shown after a successful init


def _render(text: str, **vars) -> str:
    """Tiny template substitution — ``{name}`` / ``{provider}`` etc.

    Avoids ``str.format`` because the YAML / env bodies contain literal
    ``${VAR}`` sequences for env-var interpolation that we *don't* want
    treated as format fields.
    """
    out = text
    for k, v in vars.items():
        out = out.replace("{" + k + "}", v)
    return out


_NAME_PLACEHOLDER = "{name}"


_TEMPLATES: Dict[str, _Template] = {
    "workflows": _Template(
        yaml_filename="workflow.yaml",
        yaml_body=f"""\
backend: workflows

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}
  description: A starter workflow agent

llm:
  provider: openai           # or anthropic, azure_openai, …
  config:
    model: gpt-4o-mini
    api_key: ${{OPENAI_API_KEY}}

agent:
  system_prompt: |
    You are a helpful assistant. Reply concisely.
""",
        env_body="""\
# Set the env vars referenced by your workflow.yaml.
OPENAI_API_KEY=sk-...
""",
        next_step="agentflow \"hello, what can you do?\"",
    ),

    "deep": _Template(
        yaml_filename="agent.yaml",
        yaml_body=f"""\
backend: deep

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}

agent:
  system_prompt: |
    You are an autonomous coding/research agent.
  llm:
    provider: anthropic
    config:
      model: claude-sonnet-4-20250514
      api_key: ${{ANTHROPIC_API_KEY}}

middleware:
  - type: prompt_caching
""",
        env_body="""\
ANTHROPIC_API_KEY=sk-ant-...
""",
        next_step="agentflow \"draft a python project skeleton\"",
    ),

    "semantic-kernel": _Template(
        yaml_filename="agent.yaml",
        yaml_body=f"""\
backend: semantic-kernel

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}

services:
  - id: chat
    type: chat_completion
    provider: openai
    model: gpt-4o-mini
    api_key: ${{OPENAI_API_KEY}}

agent:
  name: {_NAME_PLACEHOLDER}
  system_prompt: |
    You are a helpful assistant.
""",
        env_body="""\
OPENAI_API_KEY=sk-...
""",
        next_step="agentflow \"hello\"",
    ),

    "claude-agent-sdk": _Template(
        yaml_filename="agent.yaml",
        yaml_body=f"""\
backend: claude-agent-sdk

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}

llm:
  provider: anthropic
  config:
    model: claude-sonnet-4-20250514
    api_key: ${{ANTHROPIC_API_KEY}}

agent:
  system_prompt: |
    You are a helpful assistant. Use the available tools when relevant.
""",
        env_body="""\
ANTHROPIC_API_KEY=sk-ant-...
""",
        next_step="agentflow \"hello\"",
    ),

    "openai-agents": _Template(
        yaml_filename="agent.yaml",
        yaml_body=f"""\
backend: openai-agents

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}

llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${{OPENAI_API_KEY}}

agent:
  instructions: |
    You are a helpful assistant.
""",
        env_body="""\
OPENAI_API_KEY=sk-...
""",
        next_step="agentflow \"hello\"",
    ),

    "agent-framework": _Template(
        yaml_filename="agent.yaml",
        yaml_body=f"""\
backend: agent-framework

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}

llm:
  provider: openai
  config:
    model: gpt-4o-mini
    api_key: ${{OPENAI_API_KEY}}

agent:
  instructions: |
    You are a helpful assistant. Answer concisely.
""",
        env_body="""\
# Public OpenAI:
OPENAI_API_KEY=sk-...

# Or Azure OpenAI (uncomment + fill in):
# AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
# AZURE_DEPLOYMENT=<your-deployment-name>
# OPENAI_API_VERSION=preview
""",
        next_step="agentflow \"hello\"",
    ),

    "adk": _Template(
        yaml_filename="agent.yaml",
        yaml_body=f"""\
backend: adk

metadata:
  version: "1.0"
  name: {_NAME_PLACEHOLDER}

llm:
  provider: gemini
  config:
    model: gemini-2.5-flash
    api_key: ${{GOOGLE_API_KEY}}

agent:
  name: assistant
  instruction: |
    You are a helpful assistant.
""",
        env_body="""\
# Google AI Studio (default):
GOOGLE_API_KEY=...

# Or Vertex AI (uncomment + fill in):
# GOOGLE_CLOUD_PROJECT=<project-id>
# GOOGLE_CLOUD_LOCATION=us-central1
# GOOGLE_GENAI_USE_VERTEXAI=TRUE
""",
        next_step="agentflow \"hello\"",
    ),
}


# ---------------------------------------------------------------------------
# Decision-tree dispatch
# ---------------------------------------------------------------------------


# Pretty install commands for the no-backend-installed case.
_INSTALL_RECIPES: List[Tuple[str, str]] = [
    ("workflows",        "LangGraph multi-agent orchestration"),
    ("deep",             "DeepAgents — long-horizon coding/research"),
    ("semantic-kernel",  "Microsoft Semantic Kernel"),
    ("claude-agent-sdk", "Anthropic Claude Agent SDK"),
    ("openai-agents",    "OpenAI Agents SDK"),
    ("agent-framework",  "Microsoft Agent Framework"),
    ("adk",              "Google Agent Development Kit"),
]


class _InitError(Exception):
    """Raised when init can't proceed (zero or multiple backends, file
    conflict, etc.). Caught at the top so we can format consistently."""


def _resolve_backend(override: Optional[str], installed: List[str]) -> str:
    """Pick the backend to scaffold for. Honors ``--backend`` if given;
    otherwise applies the decision tree."""
    from agentflow.core.factory import VALID_BACKENDS, BACKEND_ALIASES

    if override:
        canonical = BACKEND_ALIASES.get(override, override)
        if canonical not in VALID_BACKENDS:
            raise _InitError(
                f"Unknown backend: {override!r}. "
                f"Valid: {', '.join(sorted(VALID_BACKENDS))}"
            )
        return canonical

    if not installed:
        lines = ["No backend installed in this venv. Install one of:", ""]
        for extra, blurb in _INSTALL_RECIPES:
            lines.append(f"  pip install agentflow[{extra}]".ljust(45) + f"# {blurb}")
        lines.append("")
        lines.append("Tip: install one — most users do — and re-run `agentflow-init`.")
        raise _InitError("\n".join(lines))

    if len(installed) > 1:
        lines = [
            "Multiple backends installed in this venv:",
            f"    {', '.join(installed)}",
            "",
            "AgentFlow recommends one backend per venv to keep dependency",
            "resolution clean.",
            "",
            "If you really want to scaffold for a specific one, pass --backend:",
        ]
        for b in installed:
            lines.append(f"    agentflow-init --backend {b}")
        raise _InitError("\n".join(lines))

    return installed[0]


def _write_scaffold(
    backend: str,
    name: str,
    cwd: Path,
    force: bool,
) -> Tuple[Path, Path, str]:
    """Write the YAML + .env.example. Returns ``(yaml_path, env_path,
    next_step)``. Raises :class:`_InitError` if either file exists and
    ``force`` is False."""
    tpl = _TEMPLATES[backend]
    yaml_path = cwd / tpl.yaml_filename
    env_path = cwd / ".env.example"

    if not force:
        existing = [p for p in (yaml_path, env_path) if p.exists()]
        if existing:
            paths = ", ".join(p.name for p in existing)
            raise _InitError(
                f"Refusing to overwrite existing file(s): {paths}\n"
                f"Pass --force to overwrite."
            )

    yaml_path.write_text(_render(tpl.yaml_body, name=name))
    env_path.write_text(tpl.env_body)
    return yaml_path, env_path, tpl.next_step


def init(
    backend: Optional[str] = None,
    name: Optional[str] = None,
    force: bool = False,
    cwd: Optional[Path] = None,
) -> int:
    """Scaffold an agent for the installed backend.

    Returns the process exit code (0 on success, non-zero on failure).
    Designed to be callable from tests as well as from ``main()``.
    """
    cwd = cwd or Path.cwd()
    installed = detect_all_installed_backends()

    try:
        chosen = _resolve_backend(backend, installed)
    except _InitError as e:
        print(str(e), file=sys.stderr)
        return 1

    project_name = name or cwd.name
    try:
        yaml_path, env_path, next_step = _write_scaffold(
            chosen, project_name, cwd, force,
        )
    except _InitError as e:
        print(str(e), file=sys.stderr)
        return 1

    print(f"✓ Detected backend: {chosen}")
    print(f"✓ Wrote {yaml_path.name}")
    print(f"✓ Wrote {env_path.name}")
    print()
    print("Next steps:")
    print(f"  cp {env_path.name} .env       # then edit to set your API key")
    print(f"  {next_step}")
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


@wrap_cli_main
def main() -> None:
    parser = argparse.ArgumentParser(
        prog="agentflow-init",
        description="Scaffold a hello-world AgentFlow agent for the installed backend.",
    )
    parser.add_argument(
        "--backend",
        help="Override auto-detection (e.g. workflows, deep, agent-framework, deepagents).",
    )
    parser.add_argument(
        "--name",
        help="metadata.name for the generated YAML (defaults to the cwd directory name).",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files in the cwd.",
    )
    args = parser.parse_args()

    code = init(backend=args.backend, name=args.name, force=args.force)
    raise SystemExit(code)
