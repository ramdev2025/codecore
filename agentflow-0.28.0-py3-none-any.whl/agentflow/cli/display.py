"""Shared Rich display helpers for agentflow CLIs.

All CLI output goes through these functions. No emoji — styled text
and indentation only, for professional, terminal-safe output.
"""

from typing import Any, Dict, List, Optional, Tuple

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table
from rich.text import Text

from . import glyphs as _glyphs_mod
from .streaming import pretty_json_block, result_length, result_preview, short_args
from .timer import format_duration

# Shared console instance
console = Console()


# ---------------------------------------------------------------------------
# Banner and headers
# ---------------------------------------------------------------------------

def print_banner(title: str, subtitle: str = ""):
    """Print a styled banner at the start of a CLI session."""
    banner = Text()
    banner.append(f"{title}\n", style="bold cyan")
    if subtitle:
        banner.append(subtitle, style="dim")
    console.print(Panel(banner, border_style="cyan"))


def print_workflow_header(workflow_name: str):
    """Print the workflow name header."""
    console.print()
    console.print(Panel(
        f"[bold cyan]{workflow_name}[/bold cyan]",
        border_style="cyan",
        expand=False,
    ))
    console.print()


# ---------------------------------------------------------------------------
# Agent events
# ---------------------------------------------------------------------------

def print_agent_start(name: str):
    """Print agent start — shows the agent is thinking."""
    console.print(f"[bold cyan]{name}[/bold cyan] [dim]thinking...[/dim]")


def print_agent_end(name: str, duration_s: Optional[float] = None, tokens: Optional[int] = None):
    """Print agent completion with optional duration and token count."""
    parts = [f"[bold cyan]{name}[/bold cyan] [dim]done"]
    details = []
    if duration_s is not None:
        details.append(format_duration(duration_s))
    if tokens is not None and tokens > 0:
        details.append(f"{tokens:,} tokens")
    if details:
        parts.append(f" ({' · '.join(details)})")
    parts.append("[/dim]")
    console.print("".join(parts))


def print_agent_response(name: str, content: str):
    """Print the final agent response in a panel."""
    if not content or not content.strip():
        return
    console.print(Panel(content, title=name, border_style="green", expand=False))


# ---------------------------------------------------------------------------
# Tool events
# ---------------------------------------------------------------------------

def print_tool_call(name: str, args: Any = None):
    """Print a tool invocation.

    With ``args`` (dict or JSON string), renders the maf/oai-style marker
    ``▸ name(key=val, …)`` (or its ASCII fallback ``> name(…)``) so the
    user can see *what* the agent called. With no args, falls back to
    the historical ``> name`` line.
    """
    g = _glyphs_mod.glyphs
    if args is None or args == "" or args == {}:
        # Same glyph the no-args form has always used — keep ``>`` for
        # back-compat regardless of the active set.
        console.print(f"  [dim]> {name}[/dim]")
        return
    short = short_args(args)
    console.print(f"  [cyan]{g.call}[/cyan] {name}({short})", highlight=False)


def print_tool_result(name: str, content: Any):
    """Print a tool result using the ``← result · N chars`` pattern.

    If the content is structured JSON small enough to fit (≤ 2000 chars,
    ≤ 24 lines) it's pretty-printed beneath the header; otherwise the
    header gets a one-line preview appended. Mirrors the maf/oai
    renderers so output looks the same across backends.
    """
    g = _glyphs_mod.glyphs
    length = result_length(content)
    body = pretty_json_block(content)
    header = f"  [dim]{g.result} {name} result · {length} chars[/dim]"
    if body is None:
        preview = result_preview(content)
        if preview:
            header = f"{header} [dim]{g.thinking}[/dim] {preview}"
        console.print(header, highlight=False)
        return
    console.print(header, highlight=False)
    indented = "\n".join("    " + line for line in body.splitlines())
    console.print(f"[dim]{indented}[/dim]", highlight=False)


def print_reasoning_marker():
    """Indicate the model is in a thinking/reasoning block.

    Shown once per streak — callers track the streak and only call this
    on the *first* reasoning chunk after non-reasoning content.
    """
    g = _glyphs_mod.glyphs
    console.print(f"  [dim italic]{g.thinking} thinking…[/dim italic]")


def print_token(text: str, end: str = ""):
    """Stream a single token (or text chunk) inline, no newline by default."""
    console.print(text, end=end, highlight=False, markup=False)


# ---------------------------------------------------------------------------
# Errors and status
# ---------------------------------------------------------------------------

def print_error(msg: str):
    """Print an error message in red."""
    console.print(f"\n[bold red]Error:[/bold red] {msg}\n")


def print_info(msg: str):
    """Print an informational message."""
    console.print(f"[dim]{msg}[/dim]")


# ---------------------------------------------------------------------------
# Interrupt / Human-in-the-loop
# ---------------------------------------------------------------------------

def print_interrupt_prompt(interrupt_info: Optional[Dict[str, Any]] = None):
    """Print a clean interrupt prompt for human-in-the-loop workflows."""
    console.print()
    console.print("[bold yellow]Workflow paused[/bold yellow] — waiting for input")

    if interrupt_info:
        interrupt_type = interrupt_info.get("type", "unknown")
        question = interrupt_info.get("question")
        context = interrupt_info.get("context")
        proposed = interrupt_info.get("proposed_action")

        console.print(f"  [dim]Type:[/dim] {interrupt_type}")
        if question:
            console.print(f"  [dim]Question:[/dim] {question}")
        if context:
            console.print(f"  [dim]Context:[/dim] {context}")
        if proposed:
            console.print(f"  [dim]Proposed:[/dim] {proposed}")

    console.print()
    console.print("[dim]  yes/no or type custom instructions[/dim]")


def prompt_user(label: str = "Response") -> str:
    """Prompt for user input and return the response."""
    return Prompt.ask(f"[bold]{label}[/bold]").strip()


# ---------------------------------------------------------------------------
# Config / summary tables
# ---------------------------------------------------------------------------

def print_config_table(rows: List[Tuple[str, str]]):
    """Print a key-value config table (used in banners and dry-run output).

    Args:
        rows: List of (key, value) tuples.
    """
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")
    for key, value in rows:
        table.add_row(key, value)
    console.print(table)
    console.print()
