"""Friendly CLI error formatting.

The CLI promises that **no Python traceback ever reaches a non-expert user
by default** — every exception is converted to a one-paragraph message
that answers three questions: *what broke*, *where in the file*, *what
to do*. Tracebacks are gated behind ``--debug`` (or
``AGENTFLOW_DEBUG=1``).

Architecture
------------

Each known exception class has a registered handler that produces a
friendly string. Handlers are tried in registration order; the first one
to return a non-None result wins. Unrecognised exceptions fall through
to :func:`_generic_fallback`, which still prints something useful and
points at ``--debug``.

This module is the framework only. Specific handlers (Pydantic schema
errors, missing env vars, API auth failures, etc.) live in companion
modules under :mod:`agentflow.cli.errors_handlers` and import this one.

Usage
-----

Wrap each Typer / argparse main with :func:`wrap_cli_main`::

    from agentflow.cli.errors import wrap_cli_main

    @wrap_cli_main
    def main():
        ...
"""

from __future__ import annotations

import os
import sys
from functools import wraps
from typing import Callable, List, Optional

# An error handler takes an exception and returns either a friendly
# message string OR ``None`` (meaning "I don't recognise this exception
# — try the next handler").
ErrorHandler = Callable[[BaseException], Optional[str]]

_HANDLERS: List[ErrorHandler] = []


def register_handler(handler: ErrorHandler) -> ErrorHandler:
    """Register an error handler. First match wins, so order matters.

    Use as a decorator::

        @register_handler
        def _pydantic(exc):
            if isinstance(exc, ValidationError):
                return _format_pydantic(exc)
            return None
    """
    _HANDLERS.append(handler)
    return handler


def is_debug_mode() -> bool:
    """True when the user opted in to full tracebacks via ``--debug`` or
    ``AGENTFLOW_DEBUG=1`` (also accepts ``true`` / ``yes`` / ``on``)."""
    return os.environ.get("AGENTFLOW_DEBUG", "").strip().lower() in (
        "1", "true", "yes", "on",
    )


def friendly_error(exc: BaseException) -> str:
    """Convert ``exc`` into a one-paragraph user-facing message.

    Walks the registered handlers and returns the first match. Falls
    back to a generic "Unexpected error" line that points at
    ``--debug``. A buggy handler that itself raises is silently skipped
    — it never blocks the fallback path.
    """
    for handler in _HANDLERS:
        try:
            result = handler(exc)
        except Exception:  # pragma: no cover — defensive
            continue
        if result is not None:
            return result
    return _generic_fallback(exc)


def _generic_fallback(exc: BaseException) -> str:
    return (
        f"Error: {type(exc).__name__}: {exc}\n"
        f"Run with --debug (or set AGENTFLOW_DEBUG=1) for the full traceback."
    )


def _is_clean_exit(exc: BaseException) -> bool:
    """True if ``exc`` is a clean-exit signal that must propagate unchanged.

    Covers stdlib ``SystemExit`` *and* the Click ``Exit`` family (which
    Typer's ``typer.Exit`` extends but isn't a ``SystemExit`` subclass —
    it inherits from ``RuntimeError`` via ``click.exceptions.Exit``).
    Catching the duck-typed ``exit_code`` attribute also future-proofs
    against unrelated CLI frameworks that follow the same convention.
    """
    if isinstance(exc, SystemExit):
        return True
    return type(exc).__name__ == "Exit" and hasattr(exc, "exit_code")


# Handler modules import ``register_handler`` from this module, so they
# must be imported AFTER ``register_handler`` is defined. Importing here
# is what triggers the side-effect registration of all built-in handlers.
def _load_builtin_handlers() -> None:
    try:
        from agentflow.cli import error_handlers  # noqa: F401
    except Exception:  # pragma: no cover — defensive
        pass


def wrap_cli_main(fn: Callable) -> Callable:
    """Decorator: convert unhandled exceptions in a CLI main into friendly
    stderr messages and a non-zero exit.

    Special cases preserved:

    - **Clean-exit signals** — ``SystemExit`` and Click's ``Exit`` (used by
      Typer's ``typer.Exit``) pass through with their original exit code.
    - ``KeyboardInterrupt`` — render ``"Interrupted."`` on stderr and exit
      with the conventional Ctrl-C code (130).
    - When :func:`is_debug_mode` is true the original exception
      re-raises so the user sees the full traceback.
    """
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except KeyboardInterrupt:
            print("\nInterrupted.", file=sys.stderr)
            raise SystemExit(130)
        except BaseException as exc:
            if _is_clean_exit(exc):
                raise
            if is_debug_mode():
                raise
            print(friendly_error(exc), file=sys.stderr)
            raise SystemExit(1)

    return wrapper


# Trigger built-in handler registration. Placed at the bottom so all
# public symbols (``register_handler`` in particular) are defined first.
_load_builtin_handlers()
