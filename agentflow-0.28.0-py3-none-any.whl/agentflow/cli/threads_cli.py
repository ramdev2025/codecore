"""``agentflow-threads`` — list / delete / clear stored conversation threads.

Discovers the project's backend the same way the unified ``agentflow``
command does (auto-detect from a YAML in the cwd, or ``--backend`` /
``--yaml`` overrides) and operates on its persistence store.

Subcommands:

- ``agentflow-threads list``           — table of (thread_id, backend, …)
- ``agentflow-threads delete <id>``    — remove one thread
- ``agentflow-threads clear --confirm`` — wipe all threads in the store

A separate entry point (rather than ``agentflow threads list``) keeps
the unified ``agentflow QUERY`` shape as the primary verb. Same
pattern as ``agentflow-init`` and ``agentflow-docs``.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import List, Optional

import typer
from rich.table import Table

from agentflow.cli import console, print_error, print_info
from agentflow.cli.errors import wrap_cli_main
from agentflow.cli.logging_config import setup_logging
from agentflow.cli.router import OutputMode, resolve_yaml
from agentflow.cli.threads import ThreadInfo, ThreadManager, for_backend
from agentflow.core.factory import detect_backend


app = typer.Typer(
    name="agentflow-threads",
    help="Manage AgentFlow conversation threads — list, delete, clear.",
    add_completion=False,
    rich_markup_mode="rich",
)


# ---------------------------------------------------------------------------
# Manager construction — shared by every subcommand
# ---------------------------------------------------------------------------


def _resolve_manager(
    yaml_path: Optional[str],
    backend_override: Optional[str],
    db_path: Optional[str],
    persistence: str,
    connection_string: Optional[str],
) -> ThreadManager:
    """Detect the active backend and build its :class:`ThreadManager`."""
    yaml_file = resolve_yaml(yaml_path)
    backend = detect_backend(yaml_file, override=backend_override)
    return for_backend(
        backend,
        db_path=db_path,
        persistence=persistence,
        connection_string=connection_string,
    )


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


@app.command("list")
def list_cmd(
    yaml_path: Optional[str] = typer.Option(None, "--yaml"),
    backend_override: Optional[str] = typer.Option(None, "--backend"),
    db_path: Optional[str] = typer.Option(None, "--db-path"),
    persistence: str = typer.Option("sqlite", "--persistence"),
    connection_string: Optional[str] = typer.Option(None, "--connection-string"),
) -> None:
    """List all threads in the active backend's persistence store."""
    manager = _resolve_manager(
        yaml_path, backend_override, db_path, persistence, connection_string,
    )
    threads = manager.list_threads()
    _render_threads_table(threads, manager.backend)


@app.command("delete")
def delete_cmd(
    thread_id: str = typer.Argument(..., help="Thread ID to delete"),
    yaml_path: Optional[str] = typer.Option(None, "--yaml"),
    backend_override: Optional[str] = typer.Option(None, "--backend"),
    db_path: Optional[str] = typer.Option(None, "--db-path"),
    persistence: str = typer.Option("sqlite", "--persistence"),
    connection_string: Optional[str] = typer.Option(None, "--connection-string"),
) -> None:
    """Delete a single thread by ID."""
    manager = _resolve_manager(
        yaml_path, backend_override, db_path, persistence, connection_string,
    )
    if manager.delete_thread(thread_id):
        console.print(
            f"[green]✓[/green] Deleted thread [bold]{thread_id}[/bold] "
            f"from {manager.backend} store.",
            highlight=False,
        )
    else:
        console.print(
            f"[yellow]No such thread:[/yellow] {thread_id}",
            highlight=False,
        )
        raise typer.Exit(1)


@app.command("clear")
def clear_cmd(
    confirm: bool = typer.Option(
        False, "--confirm",
        help="Required — clears all threads from the active backend's store.",
    ),
    yaml_path: Optional[str] = typer.Option(None, "--yaml"),
    backend_override: Optional[str] = typer.Option(None, "--backend"),
    db_path: Optional[str] = typer.Option(None, "--db-path"),
    persistence: str = typer.Option("sqlite", "--persistence"),
    connection_string: Optional[str] = typer.Option(None, "--connection-string"),
) -> None:
    """Wipe every thread in the active backend's store. Requires ``--confirm``."""
    if not confirm:
        print_error(
            "Refusing to wipe without --confirm. Pass --confirm to proceed."
        )
        raise typer.Exit(2)
    manager = _resolve_manager(
        yaml_path, backend_override, db_path, persistence, connection_string,
    )
    n = manager.clear()
    console.print(
        f"[green]✓[/green] Cleared {n} thread(s) from {manager.backend} store.",
        highlight=False,
    )


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


def _render_threads_table(threads: List[ThreadInfo], backend: str) -> None:
    """Print a table of threads. Empty stores show a friendly hint."""
    if not threads:
        print_info(f"No threads in {backend} store yet.")
        return

    table = Table(title=f"Threads ({backend})", show_lines=False)
    table.add_column("Thread ID", style="bold")
    table.add_column("Turns", justify="right")
    table.add_column("Last run", style="dim")

    for t in threads:
        table.add_row(
            t.thread_id,
            str(t.n_turns) if t.n_turns is not None else "-",
            t.last_run_at or "-",
        )
    console.print(table)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


@wrap_cli_main
def main() -> None:
    setup_logging()
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)
    app()


if __name__ == "__main__":
    main()
