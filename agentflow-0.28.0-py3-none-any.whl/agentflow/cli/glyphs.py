"""ASCII / unicode glyph selection for CLI output.

The renderers use ``▸``, ``←``, ``→``, ``·``, ``✓``, ``✗``, ``↳``, ``▶``,
``┌``, ``└`` to mark tool calls, results, agent switches, reasoning,
and so on. On a stock Windows ``cmd.exe`` or in a CI log without a
UTF-8 locale those become ``?`` boxes. The user-facing fix is a
single switch — ``--ascii`` or ``AGENTFLOW_ASCII=1`` — that flips the
glyphs to safe substitutes (``>`` for ``▸``, ``<`` for ``←``, etc.).

We also auto-detect at import: if ``sys.stdout.encoding`` doesn't
advertise UTF-8 we silently default to the ASCII set, so a Windows
user piping into a non-UTF-8 console doesn't have to know to pass the
flag.

Why a module-level singleton instead of injection: the renderers
already touch a *lot* of call sites across six backends. Reaching for
``glyphs.call`` instead of a literal ``"▸"`` is a one-token swap;
plumbing a glyphs object through every renderer's constructor is not.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Glyph sets
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GlyphSet:
    """Canonical names for every CLI marker we draw.

    Add a new attribute when a renderer wants a new glyph — never
    inline the unicode literal in a renderer.
    """

    call: str               # tool call marker
    result: str             # tool result arrow
    handoff: str            # delegate to subagent / agent switch hint
    agent_switch: str       # → agent: <name>
    thinking: str           # · thinking…
    check: str              # success
    cross: str              # error / failure
    pause: str              # paused / interrupted
    bullet: str             # leading bullet for list lines
    superstep_top: str      # ┌── superstep N
    superstep_bottom: str   # └── superstep complete
    invoked: str            # ▶ executor


UNICODE_GLYPHS = GlyphSet(
    call="▸",
    result="←",
    handoff="↳",
    agent_switch="→",
    thinking="·",
    check="✓",
    cross="✗",
    pause="⏸",
    bullet="•",
    superstep_top="┌──",
    superstep_bottom="└──",
    invoked="▶",
)


ASCII_GLYPHS = GlyphSet(
    call=">",
    result="<-",
    handoff="->",
    agent_switch="->",
    thinking=".",
    check="[v]",
    cross="[x]",
    pause="[ii]",
    bullet="*",
    superstep_top="+--",
    superstep_bottom="+--",
    invoked=">",
)


# ---------------------------------------------------------------------------
# Resolution + module-level singleton
# ---------------------------------------------------------------------------


def _stdout_supports_utf8() -> bool:
    """Best-effort check: does ``sys.stdout`` advertise a UTF-8 codec?

    Some shells report ``ascii`` even on systems that *would* render
    UTF-8 fine; users always have ``--ascii`` as the explicit override.
    Conversely, a redirected stdout (``2>&1`` to a file) often loses
    the terminal's codec — falling back to ASCII there is the safe
    default since CI log viewers vary wildly.
    """
    encoding = getattr(sys.stdout, "encoding", None) or ""
    return encoding.lower().replace("-", "").startswith("utf8") or \
           encoding.lower().replace("-", "").startswith("utf16")


def _env_says_ascii() -> bool:
    """Honor ``AGENTFLOW_ASCII`` (any truthy value) as a hard override."""
    return os.environ.get("AGENTFLOW_ASCII", "").lower() in ("1", "true", "yes", "on")


def _resolve_default() -> GlyphSet:
    if _env_says_ascii():
        return ASCII_GLYPHS
    if not _stdout_supports_utf8():
        return ASCII_GLYPHS
    return UNICODE_GLYPHS


# Resolved at import time; the router can override via ``setup_glyphs(ascii=…)``.
glyphs: GlyphSet = _resolve_default()


def setup_glyphs(*, ascii: bool = False) -> GlyphSet:
    """Switch the module-level :data:`glyphs` to ASCII / unicode.

    The router calls this from its ``--ascii`` handler. Returns the
    chosen set so callers can also use it inline if they want
    (rendering a banner once, for example).
    """
    global glyphs
    glyphs = ASCII_GLYPHS if ascii else _resolve_default()
    return glyphs


def is_ascii_mode() -> bool:
    """True when the active glyph set is the ASCII fallback."""
    return glyphs is ASCII_GLYPHS
