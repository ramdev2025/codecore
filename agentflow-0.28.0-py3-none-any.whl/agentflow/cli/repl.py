"""Interactive REPL helpers — history, slash commands, prompt loop.

Each backend's ``--interactive`` mode calls into here so users see
consistent UX: arrow-key history, ``/help`` / ``/clear`` / ``/stats`` /
``/quit`` slash commands, and Ctrl-D / Ctrl-C clean exit.

What's *not* here yet:

- ``/thread <id>`` and ``/save <name>`` — these need persistence-manager
  wiring per backend; they belong with the thread-management work in
  item #7 of CLI_IMPROVEMENTS_PLAN.md.
- Multi-line input. ``readline`` already lets users edit one line with
  arrow keys; backslash-continuation can land in a follow-up.
- Async spinner during the ``thinking…`` pause. The renderers already
  emit ``· thinking…`` markers from the model side; surfacing a spinner
  from the CLI side would require coordinating with the streaming
  driver and is out of scope for this pass.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

# ``readline`` is best-effort: it isn't built into Windows Python by
# default. When it's missing we just skip history and fall back to
# plain input().
try:
    import readline as _readline  # type: ignore[import-not-found]
except ImportError:
    _readline = None


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------


_HISTORY_PATH = Path.home() / ".agentflow" / "history"
_HISTORY_LIMIT = 10_000  # GNU readline default is 1000 — bump for chat use


def init_history(path: Optional[Path] = None) -> None:
    """Load the persistent REPL history into the readline buffer.

    Idempotent: safe to call from multiple entry points. Creates the
    parent directory on first use. When ``readline`` isn't available
    (Windows / minimal Python builds) this is a silent no-op.
    """
    if _readline is None:
        return
    file = path or _HISTORY_PATH
    file.parent.mkdir(parents=True, exist_ok=True)
    if file.exists():
        try:
            _readline.read_history_file(str(file))
        except OSError:
            pass
    _readline.set_history_length(_HISTORY_LIMIT)


def save_history(path: Optional[Path] = None) -> None:
    """Persist the current readline buffer to the history file."""
    if _readline is None:
        return
    file = path or _HISTORY_PATH
    try:
        file.parent.mkdir(parents=True, exist_ok=True)
        _readline.write_history_file(str(file))
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Slash commands
# ---------------------------------------------------------------------------


@dataclass
class ReplState:
    """Mutable state surfaced to slash commands.

    Backends construct one per REPL session and pass it into
    :func:`dispatch_slash_command`. ``stats`` is opaque — backends
    populate whatever counters they track (tool_calls, total_tokens,
    llm_calls, …).
    """

    thread_id: Optional[str] = None
    stats: Dict[str, Any] = field(default_factory=dict)


HELP_TEXT = """Available commands:
  /help                Show this message
  /clear               Clear the terminal
  /stats               Show accumulated stats for this session
  /quit                Exit the REPL (alias: quit, exit, q, Ctrl-D)

Anything that doesn't start with ``/`` is sent to the agent."""


def is_slash_command(line: str) -> bool:
    """A non-empty line starting with ``/`` is treated as a command."""
    return bool(line) and line.startswith("/")


def dispatch_slash_command(line: str, state: ReplState, console: Any) -> str:
    """Run a slash command. Returns ``"quit"`` to break the loop, or
    ``"continue"`` to prompt again. Unknown commands print a hint and
    return ``"continue"`` so a typo doesn't end the session.
    """
    parts = line.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    # arg = parts[1] if len(parts) > 1 else ""  # reserved for /thread etc.

    if cmd in ("/quit", "/exit", "/q"):
        return "quit"
    if cmd == "/help":
        console.print(HELP_TEXT)
        return "continue"
    if cmd == "/clear":
        # ANSI clear-screen — works in any terminal Rich would render to.
        # markup=False so Rich doesn't try to parse ``[2J``/``[H`` as
        # markup tags (which would silently strip the brackets).
        console.print("\x1b[2J\x1b[H", end="", markup=False, highlight=False)
        return "continue"
    if cmd == "/stats":
        if not state.stats:
            console.print("[dim]No stats yet — run a query first.[/dim]", highlight=False)
            return "continue"
        rows = [f"  [bold]{k}[/bold]: {v}" for k, v in state.stats.items()]
        if state.thread_id:
            rows.insert(0, f"  [bold]thread[/bold]: {state.thread_id}")
        # highlight=False so Rich's auto-highlighter doesn't bold numbers
        # / split tokens like ``t-123`` into ``t-`` + bold ``123``.
        console.print("\n".join(rows), highlight=False)
        return "continue"

    console.print(
        f"[yellow]Unknown command:[/yellow] {cmd}\n"
        "Type [bold]/help[/bold] for the list.",
        highlight=False,
    )
    return "continue"


# ---------------------------------------------------------------------------
# Loop helper
# ---------------------------------------------------------------------------


# Tokens that exit the REPL when typed without a leading slash. Mirrors
# the historical behaviour of every backend's REPL prior to this module.
_BARE_QUIT_TOKENS = {"quit", "exit", "q"}


def is_quit_alias(line: str) -> bool:
    """True if ``line`` is one of the bare-word quit aliases."""
    return line.strip().lower() in _BARE_QUIT_TOKENS


def cleanup_terminal_state() -> None:
    """Best-effort restoration of the terminal after a REPL session.

    Saves history. If something already wrote partial bytes (e.g. a
    streaming renderer's tokens-in-flight) the cursor may be in an
    odd column when we exit; not worth trying to fix that here, the
    next prompt will reset it.
    """
    save_history()
