"""Shared CLI display components (used by router + backend CLIs)."""

from .display import (
    console,
    print_banner,
    print_workflow_header,
    print_agent_start,
    print_agent_end,
    print_agent_response,
    print_tool_call,
    print_tool_result,
    print_reasoning_marker,
    print_token,
    print_error,
    print_interrupt_prompt,
    print_info,
    print_config_table,
    prompt_user,
)
from .summary import print_execution_summary, format_tokens
from .timer import ExecutionTimer, format_duration

__all__ = [
    "console",
    "print_banner",
    "print_workflow_header",
    "print_agent_start",
    "print_agent_end",
    "print_agent_response",
    "print_tool_call",
    "print_tool_result",
    "print_reasoning_marker",
    "print_token",
    "print_error",
    "print_interrupt_prompt",
    "print_info",
    "print_config_table",
    "prompt_user",
    "print_execution_summary",
    "format_tokens",
    "ExecutionTimer",
    "format_duration",
]
