"""Execution summary display."""

from typing import Any, Dict, Optional

from rich.console import Console

from .timer import format_duration


def format_tokens(count: int) -> str:
    """Format a token count with comma separators.

    Examples:
        340    -> "340"
        1250   -> "1,250"
        100000 -> "100,000"
    """
    return f"{count:,}"


def print_execution_summary(
        console: Console,
        duration_s: float,
        metrics: Optional[Dict[str, Any]] = None,
        cost: Optional[Dict[str, Any]] = None,
):
    """Print a compact execution summary line.

    Examples:
        Done in 8.4s
        Done in 8.4s · 3 agents · 5 tool calls · 1,250 tokens
        Done in 8.4s · 1,250 tokens · $0.008 ($0.492 remaining)

    Args:
        console: Rich console instance.
        duration_s: Total execution duration in seconds.
        metrics: Optional metrics dict from MetricsCallbackHandler.get_metrics().
        cost: Optional cost dict from CostTrackingCallbackHandler.get_usage().
    """
    parts = [f"Done in {format_duration(duration_s)}"]

    if metrics:
        llm_calls = metrics.get("llm_calls", 0)
        tool_calls = metrics.get("tool_calls", 0)
        total_tokens = metrics.get("total_tokens", 0)

        if llm_calls:
            parts.append(f"{llm_calls} agent calls")
        if tool_calls:
            parts.append(f"{tool_calls} tool calls")
        if total_tokens:
            parts.append(f"{format_tokens(total_tokens)} tokens")

    if cost:
        total_tokens = cost.get("total_tokens", 0)
        remaining = cost.get("remaining")
        budget = cost.get("budget")

        # If we didn't get tokens from metrics, show from cost
        if total_tokens and (not metrics or not metrics.get("total_tokens")):
            parts.append(f"{format_tokens(total_tokens)} tokens")

        if budget and remaining is not None:
            parts.append(f"{format_tokens(remaining)} tokens remaining")

    console.print(f"\n[bold green]{' · '.join(parts)}[/bold green]\n")
