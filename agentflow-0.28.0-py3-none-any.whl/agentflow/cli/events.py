"""JSON event sink for ``--output {json,ndjson}``.

Stable schema consumed by CI / scripts / downstream pipelines. Each
backend's stream renderer can additionally route events through a
:class:`JsonSink`; when the user asks for terminal output the sink is
absent and only the existing Rich-rendered view runs.

Schema
------

Every event is a JSON object on its own line. The ``type`` field is
the discriminator. Unknown / extra fields are allowed (consumers
should ignore them) so backends can attach extra context without
breaking the contract.

Common fields:

- ``type``: one of the constants in :data:`EVENT_TYPES`
- ``ts``: ISO-8601 UTC timestamp
- ``backend``: short backend name (``workflows``, ``deep``, …)

Per-type fields:

- ``status`` — ``message``: short banner text
- ``agent_start`` / ``agent_end`` — ``name``: agent name; ``agent_end``
  may carry ``tokens`` and ``usage`` dicts
- ``token`` — ``name``: agent name; ``content``: text fragment
- ``tool_call`` — ``name``: tool name; ``args``: dict
- ``tool`` — ``name``: tool name; ``content``: structured or text
- ``agent_switch`` — ``name``: new agent name (orchestration mode)
- ``reasoning`` — emitted once per reasoning streak (no payload)
- ``stats`` — ``elapsed_s``, ``llm_calls``, ``tool_calls``,
  ``total_tokens``
- ``complete`` — terminal event; ``response``: optional final text
- ``error`` — ``message``: error text; optional ``traceback``

Why ndjson and not a JSON array? Events stream in real time; an array
can't be flushed line-by-line.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any, Dict, IO, Optional


# ---------------------------------------------------------------------------
# Event type constants — kept narrow on purpose. Backends with extra event
# kinds (``log``, ``rate_limit``, …) map them to one of these or include the
# raw subtype in the event body, but the discriminator stays bounded.
# ---------------------------------------------------------------------------


EVENT_STATUS = "status"
EVENT_AGENT_START = "agent_start"
EVENT_AGENT_END = "agent_end"
EVENT_AGENT_SWITCH = "agent_switch"
EVENT_TOKEN = "token"
EVENT_TOOL_CALL = "tool_call"
EVENT_TOOL = "tool"
EVENT_REASONING = "reasoning"
EVENT_STATS = "stats"
EVENT_COMPLETE = "complete"
EVENT_ERROR = "error"


EVENT_TYPES = frozenset({
    EVENT_STATUS,
    EVENT_AGENT_START,
    EVENT_AGENT_END,
    EVENT_AGENT_SWITCH,
    EVENT_TOKEN,
    EVENT_TOOL_CALL,
    EVENT_TOOL,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_COMPLETE,
    EVENT_ERROR,
})


# ---------------------------------------------------------------------------
# JsonSink — line-delimited JSON output
# ---------------------------------------------------------------------------


class JsonSink:
    """Emits one JSON object per line, flushing after each event.

    The sink is *append-only* — events are written immediately so a
    consumer reading from a pipe sees them as they happen. ``backend``
    is a label every event carries so multi-backend runs (or future
    multiplexing) can be filtered downstream.
    """

    def __init__(self, backend: str, stream: Optional[IO[str]] = None):
        self._backend = backend
        self._stream = stream if stream is not None else sys.stdout

    def emit(self, event_type: str, **fields: Any) -> None:
        """Write one event as a single JSON line.

        Unknown ``event_type`` values are accepted but logged into the
        body for visibility during incremental backend wiring. Once a
        backend's events are stabilised we can tighten this.
        """
        payload: Dict[str, Any] = {
            "type": event_type,
            "ts": datetime.now(timezone.utc).isoformat(),
            "backend": self._backend,
            **fields,
        }
        # default=str makes datetime / Pydantic / SDK objects survive.
        line = json.dumps(payload, default=str, ensure_ascii=False)
        self._stream.write(line + "\n")
        self._stream.flush()


# ---------------------------------------------------------------------------
# Output mode resolution
# ---------------------------------------------------------------------------


VALID_OUTPUT_MODES = ("tty", "json", "ndjson")


def is_json_mode(output: Optional[str]) -> bool:
    """``--output json`` and ``--output ndjson`` both mean the JSON sink.

    They produce identical output (one event per line). ``json`` is
    accepted as a friendly alias since most users reach for it first.
    """
    return output in ("json", "ndjson")
