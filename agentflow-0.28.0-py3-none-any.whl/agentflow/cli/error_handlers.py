"""Friendly-error handlers — one function per known exception class.

Importing this module is what *registers* the handlers (via the
``@register_handler`` decorator). :mod:`agentflow.cli.errors` imports it
at the bottom, so any code that imports ``agentflow.cli.errors`` (or
goes through ``wrap_cli_main``) gets the full handler set automatically.

Order matters: handlers are tried in definition order, so put the
narrowest match first.
"""

from __future__ import annotations

import os
from typing import Any, Optional

from agentflow.cli.errors import register_handler


# ---------------------------------------------------------------------------
# LLM provider authentication failures
# ---------------------------------------------------------------------------


# Map module prefix → (display name, primary env var, fallback hint).
_AUTH_PROVIDER_HINTS = {
    "openai":        ("OpenAI",   "OPENAI_API_KEY",
                      "or AZURE_OPENAI_API_KEY when targeting Azure"),
    "anthropic":     ("Anthropic", "ANTHROPIC_API_KEY",
                      "set on the LLM client or in your .env"),
    "azure":         ("Azure",    "AZURE_OPENAI_API_KEY",
                      "or run `az login` for Azure RBAC (DefaultAzureCredential)"),
    "google":        ("Google",   "GOOGLE_API_KEY",
                      "or run `gcloud auth application-default login`"),
    "boto3":         ("AWS",      "AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY",
                      "or configure ~/.aws/credentials"),
    "botocore":      ("AWS",      "AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY",
                      "or configure ~/.aws/credentials"),
}

_AUTH_CLASS_NAMES = {
    "AuthenticationError",        # openai, anthropic
    "ClientAuthenticationError",  # azure.core
    "InvalidApiKeyError",
    "PermissionDeniedError",      # openai sometimes uses this for 403
}


@register_handler
def _api_auth_failure(exc: BaseException) -> Optional[str]:
    """Detect and reformat LLM-provider authentication failures.

    Matches by:

    1. Class name in :data:`_AUTH_CLASS_NAMES` (covers the typed
       exceptions all three big SDKs raise — OpenAI, Anthropic, Azure
       Core), OR
    2. ``status_code == 401`` on the exception object (catches
       SDK wrappers that mask the typed class but preserve the HTTP
       code).

    The provider is identified from the exception's module path so the
    message can name the right env var without requiring us to import
    each SDK directly.
    """
    cls = type(exc)
    name = cls.__name__
    module = cls.__module__ or ""
    status_code = getattr(exc, "status_code", None)

    matches_by_name = name in _AUTH_CLASS_NAMES
    matches_by_status = status_code == 401
    if not (matches_by_name or matches_by_status):
        return None

    provider, env_var, hint = _identify_provider(module)
    raw_msg = str(exc).strip()
    lines = [
        f"{provider} authentication failed."
        if provider != "unknown"
        else "LLM authentication failed."
    ]
    lines.append(f"  Check {env_var} in your .env or environment ({hint}).")
    if raw_msg and raw_msg.lower() not in ("none", ""):
        # Surface the SDK's own message in dim form. Keep it short — some
        # SDKs include large response bodies.
        snippet = raw_msg[:200] + ("…" if len(raw_msg) > 200 else "")
        lines.append(f"  Details: {snippet}")
    return "\n".join(lines)


def _identify_provider(module: str) -> tuple[str, str, str]:
    """Walk the module path looking for a known provider prefix."""
    for prefix, (display, env_var, hint) in _AUTH_PROVIDER_HINTS.items():
        if module.startswith(prefix) or f".{prefix}." in module:
            return display, env_var, hint
    return "unknown", "the provider's API key env var", "see your provider's docs"


# ---------------------------------------------------------------------------
# YAML file not found
# ---------------------------------------------------------------------------


@register_handler
def _yaml_file_not_found(exc: BaseException) -> Optional[str]:
    """``FileNotFoundError`` for a YAML file the user passed via ``--yaml``
    or that an internal loader tried to open.

    Distinguishes config YAMLs from other missing-file errors by the
    extension (``.yaml`` / ``.yml``) so a generic ``FileNotFoundError``
    coming from, say, MCP file-search doesn't get hijacked.
    """
    if not isinstance(exc, FileNotFoundError):
        return None
    fn = exc.filename or ""
    if not (fn.endswith(".yaml") or fn.endswith(".yml")):
        return None
    return (
        f"YAML config not found: {fn}\n"
        f"  Check the path passed to --yaml, or run from the directory "
        f"that contains your config."
    )


# ---------------------------------------------------------------------------
# Tool / module import errors
# ---------------------------------------------------------------------------


@register_handler
def _module_not_found(exc: BaseException) -> Optional[str]:
    """``ModuleNotFoundError`` when the user's tool module (or a backend
    package the YAML referenced) can't be imported.

    Gives different guidance depending on whether the missing module
    looks like a user tool module (``tools``, ``tools.foo``,
    ``my_app.tools``) versus a backend SDK that wasn't installed via
    extras (``agent_framework``, ``deepagents``, …).
    """
    if not isinstance(exc, ModuleNotFoundError):
        return None
    name = exc.name or ""
    if not name:
        return None

    # Backend SDK missing — point at the right ``[extra]``.
    extra_hint = _BACKEND_SDK_TO_EXTRA.get(name.split(".")[0])
    if extra_hint is not None:
        return (
            f"Required SDK {name!r} is not installed.\n"
            f"  Install the matching backend extra:\n"
            f"      pip install agentflow[{extra_hint}]"
        )

    # Heuristic: anything ending in ``.tools`` or that simply IS ``tools``
    # is almost certainly the user's tool module.
    looks_like_tool_module = name == "tools" or name.endswith(".tools") or "tools" in name.split(".")
    if looks_like_tool_module:
        return (
            f"Tool module {name!r} could not be imported.\n"
            f"  - Make sure the module exists in your project (e.g. "
            f"a ``tools/`` folder with an ``__init__.py``).\n"
            f"  - Make sure your CWD is on PYTHONPATH (running "
            f"``agentflow`` from the project root usually does this)."
        )

    # Anything else — generic but specific.
    return (
        f"Could not import module {name!r}.\n"
        f"  - Make sure the package is installed (``pip show {name}``).\n"
        f"  - Or, if it's your own module, verify it's on PYTHONPATH."
    )


# Map known backend SDK module names → AgentFlow extra names so the
# handler can suggest the exact ``pip install`` line.
_BACKEND_SDK_TO_EXTRA = {
    "agent_framework":   "agent-framework",
    "deepagents":        "deep",
    "openai":            "openai-agents",   # rarely the missing one — OAI is core for many users
    "claude_agent_sdk":  "claude-agent-sdk",
    "semantic_kernel":   "semantic-kernel",
    "langchain":         "workflows",
    "langgraph":         "workflows",
}


# ---------------------------------------------------------------------------
# Pydantic ValidationError
# ---------------------------------------------------------------------------

# Map common pydantic error ``type`` slugs to short human-readable
# fragments. The fragment is plugged into a ``"<field>: <fragment>"``
# line. Anything not in the map falls through to the original
# pydantic ``msg`` (already a complete sentence).
_PYDANTIC_TYPE_MESSAGES = {
    "missing":               "required field is missing",
    "extra_forbidden":       "unknown field (not allowed by the schema)",
    "string_type":           "expected a string",
    "list_type":             "expected a list",
    "dict_type":             "expected a mapping",
    "int_type":              "expected an integer",
    "float_type":            "expected a number",
    "bool_type":             "expected a boolean",
    "string_too_short":      "value is too short",
    "string_too_long":       "value is too long",
    "url_parsing":           "not a valid URL",
}


def _humanize_pydantic_error(err: dict) -> str:
    etype = err.get("type", "")
    msg = err.get("msg", "validation failed")
    inp = err.get("input")
    ctx = err.get("ctx") or {}

    # ``enum`` errors carry the permitted values in ctx['expected'].
    if etype == "enum":
        expected = ctx.get("expected")
        if expected:
            return f"must be one of {expected} (got {inp!r})"
        return msg

    # ``literal_error`` is similar — values live in ctx['expected'].
    if etype == "literal_error":
        expected = ctx.get("expected")
        if expected:
            return f"must be {expected} (got {inp!r})"
        return msg

    # ``string_pattern_mismatch`` — surface the pattern.
    if etype == "string_pattern_mismatch":
        pattern = ctx.get("pattern")
        if pattern:
            return f"must match pattern {pattern!r} (got {inp!r})"
        return msg

    # ``value_error`` — pydantic's ``msg`` already contains the user's
    # validator message; pass through as-is.
    if etype == "value_error":
        return msg

    base = _PYDANTIC_TYPE_MESSAGES.get(etype, msg)
    if etype.endswith("_type") and isinstance(inp, (str, int, float, bool, list, dict)):
        # For type-mismatch errors, mention what we got.
        return f"{base} (got {type(inp).__name__})"
    return base


def _format_loc(loc: tuple) -> str:
    """Pydantic ``loc`` is a tuple of components — strings for fields, ints
    for list indices. ``("agents", 0, "instructions")`` → ``"agents[0].instructions"``."""
    parts: list[str] = []
    for p in loc:
        if isinstance(p, int):
            if parts:
                parts[-1] = f"{parts[-1]}[{p}]"
            else:
                parts.append(f"[{p}]")
        else:
            parts.append(str(p))
    return ".".join(parts) if parts else "<root>"


# ---------------------------------------------------------------------------
# Missing environment variable
# ---------------------------------------------------------------------------


@register_handler
def _missing_env_var(exc: BaseException) -> Optional[str]:
    """Convert :class:`agentflow.core.exceptions.MissingEnvVarError` into a
    short message that names the variable and points at concrete fixes.

    If the cwd has a ``.env.example`` but no ``.env``, suggest copying
    it. If a ``.env`` exists, suggest editing it. Otherwise suggest
    exporting the variable.
    """
    # Late import — avoids any circular-import risk during early module
    # load and lets the handler degrade gracefully if the exceptions
    # module is unavailable in some weird subprocess.
    try:
        from agentflow.core.exceptions import MissingEnvVarError
    except Exception:  # pragma: no cover
        return None
    if not isinstance(exc, MissingEnvVarError):
        return None

    has_env = os.path.exists(".env")
    has_example = os.path.exists(".env.example")

    lines = [f"Environment variable {exc.name!r} is required but not set."]
    if has_env:
        lines.append(f"Add it to .env:    {exc.name}=<value>")
    elif has_example:
        lines.append("There's a .env.example in this directory — copy it:")
        lines.append("    cp .env.example .env")
        lines.append(f"then set {exc.name}=<value> in the new .env.")
    else:
        lines.append(f"Export it before running:    export {exc.name}=<value>")
        lines.append("…or create a .env file in this directory.")
    if exc.source:
        lines.append(f"(referenced in {exc.source})")
    return "\n".join(lines)


@register_handler
def _pydantic_validation(exc: BaseException) -> Optional[str]:
    """Convert ``pydantic_core.ValidationError`` into a structured,
    field-by-field error block.

    The default ``str(exc)`` is a multi-paragraph dump with type slugs,
    repr'd inputs, and a docs URL per error. We replace it with one
    compact line per failed field, using human language for the common
    error types (``missing``, ``string_type``, ``enum``, etc.).
    """
    # Detect duck-typed: anything with ``.errors()`` returning a list of
    # dicts that have ``loc`` / ``type`` / ``msg``. This covers both
    # pydantic v2's ``ValidationError`` and any compatible re-export.
    errors_fn = getattr(exc, "errors", None)
    if not callable(errors_fn):
        return None
    try:
        errs: Any = errors_fn()
    except Exception:
        return None
    if not isinstance(errs, list) or not errs:
        return None
    first = errs[0]
    if not isinstance(first, dict) or "loc" not in first or "type" not in first:
        return None

    n = len(errs)
    title_class = type(exc).__name__
    if title_class != "ValidationError":
        return None

    lines = [f"Configuration error ({n} issue{'s' if n != 1 else ''}):"]
    for err in errs:
        loc = _format_loc(err.get("loc") or ())
        msg = _humanize_pydantic_error(err)
        lines.append(f"  - {loc}: {msg}")
    lines.append("")
    lines.append(
        "Fix the YAML field(s) above and re-run. "
        "Use --debug for the raw Pydantic dump."
    )
    return "\n".join(lines)
