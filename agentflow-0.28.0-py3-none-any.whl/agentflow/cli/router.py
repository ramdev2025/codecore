"""
Unified AgentFlow CLI — single entry point for all backends.

Detects the backend from the YAML's ``backend`` field (or heuristic)
and delegates to the backend-specific runner. Uses the same
``detect_backend()`` factory that the Python API uses.

Usage::

    agentflow "Your query"
    agentflow --yaml workflow.yaml "Your query"
    agentflow --backend deep --yaml agent.yaml --dry-run
    agentflow --interactive
"""

import os
import sys
from enum import Enum
from typing import Optional

import typer

from agentflow.cli import print_error
from agentflow.cli.errors import wrap_cli_main
from agentflow.cli.glyphs import setup_glyphs
from agentflow.cli.logging_config import setup_logging
from agentflow.core.factory import detect_backend

app = typer.Typer(
    name="agentflow",
    help="AgentFlow — Run AI agents from the command line.",
    add_completion=False,
    rich_markup_mode="rich",
)

# YAML filenames to search when --yaml is not provided.
#
# Backend-agnostic convention — the same four names work for every backend.
# The CLI detects the backend from the file's ``backend:`` field, not from
# the filename. Order of search is most-specific to most-generic:
#
#   workflow.yaml   — a single workflow (workflows backend convention)
#   agentflow.yaml  — generic; any backend
#   agent.yaml      — a single agent (autonomous-style backends)
#   agents.yaml     — multi-agent / orchestrated configs
#
# Users may always pass ``--yaml <path>`` explicitly to bypass auto-detection.
YAML_CANDIDATES = [
    "workflow.yaml",
    "agentflow.yaml",
    "agent.yaml",
    "agents.yaml",
]


class Persistence(str, Enum):
    memory = "memory"
    sqlite = "sqlite"
    postgres = "postgres"


class OutputMode(str, Enum):
    """Output format for the run.

    - ``tty`` — Rich-formatted terminal output (default)
    - ``json`` / ``ndjson`` — newline-delimited JSON events on stdout,
      one per line, suitable for ``jq``, CI, or downstream pipelines.
      The two values are aliases.
    """
    tty = "tty"
    json = "json"
    ndjson = "ndjson"


def resolve_yaml(yaml_path: Optional[str]) -> str:
    """Find the YAML config file, or error with a helpful message."""
    if yaml_path is not None:
        if not os.path.exists(yaml_path):
            print_error(f"YAML file not found: {yaml_path}")
            raise typer.Exit(1)
        return yaml_path
    for candidate in YAML_CANDIDATES:
        if os.path.exists(candidate):
            return candidate
    print_error(
        "No agent YAML found. Create one of "
        "workflow.yaml / agentflow.yaml / agent.yaml / agents.yaml, "
        "or use --yaml to specify a path."
    )
    raise typer.Exit(1)


def _version_callback(value: bool) -> None:
    """Eager ``--version`` handler — runs before YAML / backend dispatch.

    Reports the installed ``agentflow`` package version and exits cleanly.
    Works regardless of which backend extras are installed because it
    only reads installed package metadata.
    """
    if not value:
        return
    from importlib.metadata import PackageNotFoundError, version

    try:
        v = version("agentflow")
    except PackageNotFoundError:
        v = "unknown (not installed)"
    typer.echo(f"agentflow {v}")
    raise typer.Exit()


@app.command()
@wrap_cli_main
def main(
        query: Optional[str] = typer.Argument(
            None,
            help="Task for the agent. If omitted, you will be prompted.",
        ),
        version: Optional[bool] = typer.Option(
            None, "--version",
            callback=_version_callback,
            is_eager=True,
            help="Print the agentflow version and exit.",
        ),
        yaml_path: Optional[str] = typer.Option(
            None, "--yaml",
            help="Path to YAML config file (auto-detected if omitted).",
        ),
        backend_override: Optional[str] = typer.Option(
            None, "--backend",
            help="Override backend detection (workflows, deep, semantic-kernel, claude-agent-sdk, openai-agents, agent-framework, adk).",
        ),
        interactive: bool = typer.Option(
            False, "--interactive",
            help="Run in interactive mode (continuous conversation).",
        ),
        dry_run: bool = typer.Option(
            False, "--dry-run",
            help="Validate config and print summary without running.",
        ),
        json_output: bool = typer.Option(
            False, "--json",
            help="Output dry-run summary as JSON.",
        ),
        thread_id: Optional[str] = typer.Option(
            None, "--thread-id",
            help="Thread ID for conversation continuity.",
        ),
        persistence: Optional[Persistence] = typer.Option(
            None, "--persistence",
            help="Persistence backend: memory, sqlite, postgres. "
                 "When set, this (and --db-path / --connection-string) "
                 "overrides any persistence section in the YAML.",
        ),
        db_path: Optional[str] = typer.Option(
            None, "--db-path",
            help="SQLite database path. When set, overrides YAML persistence.",
        ),
        connection_string: Optional[str] = typer.Option(
            None, "--connection-string",
            help="PostgreSQL connection string (supports ${ENV_VAR} syntax). "
                 "When set, overrides YAML persistence.",
        ),
        tools_module: Optional[str] = typer.Option(
            None, "--tools",
            help="Python module containing tools (workflows backend).",
        ),
        workdir: str = typer.Option(
            ".", "--workdir",
            help="Working directory for the agent's filesystem (deep backend).",
        ),
        no_tui: bool = typer.Option(
            False, "--no-tui",
            help="Disable TUI, use plain CLI output (deep backend).",
        ),
        recursion_limit: int = typer.Option(
            100, "--recursion-limit",
            help="Maximum number of agent steps (workflows backend).",
        ),
        debug: bool = typer.Option(
            False, "--debug",
            help="Show full Python tracebacks instead of friendly errors. "
                 "Equivalent to setting AGENTFLOW_DEBUG=1. Implies DEBUG-level "
                 "logging for agentflow.* loggers.",
        ),
        verbose: bool = typer.Option(
            False, "--verbose", "-v",
            help="INFO-level logging for agentflow.* loggers. Quieter than "
                 "--debug, louder than the default. Errors still render via "
                 "the friendly-error framework.",
        ),
        output: OutputMode = typer.Option(
            OutputMode.tty, "--output",
            help="Output format: tty (default), json, ndjson. "
                 "json/ndjson emit one JSON event per line for "
                 "consumption by CI / scripts / pipelines.",
        ),
        ascii_glyphs: bool = typer.Option(
            False, "--ascii",
            help="Use ASCII fallbacks for unicode markers (▸/←/·/✓/✗). "
                 "Auto-enabled when stdout isn't UTF-8; pass --ascii to "
                 "force it on a UTF-8 console for CI logs etc.",
        ),
):
    """Run AI agents from the command line."""
    # Honor --debug by promoting it to the env var the friendly-error
    # framework reads. Set it before anything else so even early
    # imports / dotenv loads see the right value.
    if debug:
        os.environ["AGENTFLOW_DEBUG"] = "1"

    # Configure logging early — quiets gRPC/OTel/asyncio noise and sets
    # the agentflow.* level so the user sees a clean stream by default.
    # Must run BEFORE any backend SDK is imported because GRPC_VERBOSITY
    # is read at gRPC's import time.
    setup_logging(debug=debug, verbose=verbose)

    # Honor --ascii by overriding the auto-detection that ran at glyph
    # module import time. Already-rendered banners aren't affected, but
    # everything from this point on uses the chosen set.
    if ascii_glyphs:
        setup_glyphs(ascii=True)

    # Ensure cwd is on sys.path for tool/module imports
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    yaml_file = resolve_yaml(yaml_path)

    try:
        resolved_backend = detect_backend(yaml_file, override=backend_override)
    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1)

    if resolved_backend == "workflows":
        try:
            from agentflow.workflows.agentflow_cli import run_from_router
        except ImportError:
            print_error(
                "Workflows backend requires LangGraph. "
                "Install with: pip install agentflow[workflows]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            tools_module=tools_module,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            recursion_limit=recursion_limit,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    elif resolved_backend == "deep":
        try:
            from agentflow.deep.cli import run_from_router
        except ImportError:
            print_error(
                "Deep backend requires DeepAgents. "
                "Install with: pip install agentflow[deep]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            workdir=workdir,
            no_tui=no_tui,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    elif resolved_backend == "semantic-kernel":
        try:
            from agentflow.sk.cli import run_from_router
        except ImportError:
            print_error(
                "Semantic Kernel backend requires semantic-kernel. "
                "Install with: pip install agentflow[semantic-kernel]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            workdir=workdir,
            no_tui=no_tui,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    elif resolved_backend == "claude-agent-sdk":
        try:
            from agentflow.cas.cli import run_from_router
        except ImportError:
            print_error(
                "Claude Agent SDK backend requires claude-agent-sdk. "
                "Install with: pip install agentflow[claude-agent-sdk]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            workdir=workdir,
            no_tui=no_tui,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    elif resolved_backend == "openai-agents":
        try:
            from agentflow.oai.cli import run_from_router
        except ImportError:
            print_error(
                "OpenAI Agents backend requires openai-agents. "
                "Install with: pip install agentflow[openai-agents]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            workdir=workdir,
            no_tui=no_tui,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    elif resolved_backend == "agent-framework":
        try:
            from agentflow.maf.cli import run_from_router
        except ImportError:
            print_error(
                "Microsoft Agent Framework backend requires agent-framework. "
                "Install with: pip install agentflow[agent-framework]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            workdir=workdir,
            no_tui=no_tui,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    elif resolved_backend == "adk":
        try:
            from agentflow.adk.cli import run_from_router
        except ImportError:
            print_error(
                "Google ADK backend requires google-adk. "
                "Install with: pip install agentflow[adk]"
            )
            raise typer.Exit(1)

        run_from_router(
            yaml_path=yaml_file,
            query=query,
            persistence=persistence.value if persistence else None,
            db_path=db_path,
            connection_string=connection_string,
            thread_id=thread_id,
            interactive=interactive,
            workdir=workdir,
            no_tui=no_tui,
            dry_run=dry_run,
            json_output=json_output,
            output=output.value,
        )

    else:
        print_error(f"Unknown backend: {resolved_backend!r}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
