"""Execution timing utilities."""

import time


def format_duration(seconds: float) -> str:
    """Format a duration in seconds to a human-readable string.

    Examples:
        0.5   -> "0.5s"
        12.3  -> "12.3s"
        90.0  -> "1m 30s"
        3661  -> "61m 1s"
    """
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    return f"{minutes}m {secs}s"


class ExecutionTimer:
    """Tracks elapsed time for a CLI execution.

    Usage:
        timer = ExecutionTimer()
        timer.start()
        # ... do work ...
        print(f"Done in {format_duration(timer.elapsed())}")
    """

    def __init__(self):
        self._start: float = 0.0
        self._running: bool = False

    def start(self):
        self._start = time.monotonic()
        self._running = True

    def elapsed(self) -> float:
        if not self._running:
            return 0.0
        return time.monotonic() - self._start

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self._running = False
