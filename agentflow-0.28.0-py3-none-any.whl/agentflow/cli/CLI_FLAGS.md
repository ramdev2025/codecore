# Unified `agentflow` CLI flags

Cross-backend reference for the flags / commands shipped in the
unified-CLI work (items #1–#8 of `CLI_IMPROVEMENTS_PLAN.md`). Each
backend's per-backend `CLI_REFERENCE.md` covers backend-specific
behaviour; this file covers everything that's the same regardless of
which `backend:` your YAML declares.

## At-a-glance

```
agentflow [QUERY] [OPTIONS]                  # run an agent

agentflow-init [--backend NAME] [--name NAME] [--force]
                                              # scaffold a hello-world project
agentflow-threads list                        # show stored threads
agentflow-threads delete <thread_id>          # remove one thread
agentflow-threads clear --confirm             # wipe the persistence store

agentflow-docs                                # serve the active backend's docs
```

## Common flags

| Flag | Default | Purpose |
| --- | --- | --- |
| `--yaml PATH` | auto-detect | YAML config file. Auto-detection searches `workflow.yaml`, `agent.yaml`, `agentflow.yaml`, `oai_agent.yaml`, `maf_agent.yaml`, etc. in the cwd. |
| `--backend NAME` | from YAML | Override backend detection: `workflows`, `deep`, `semantic-kernel`, `claude-agent-sdk`, `openai-agents`, `agent-framework`. |
| `--interactive` | off | REPL with readline history (`~/.agentflow/history`) and slash commands. |
| `--dry-run` | off | Validate config and print summary without running the agent. |
| `--json` | off | Print the dry-run summary as JSON (single object). For per-event JSON during a run, use `--output ndjson`. |
| `--thread-id TEXT` | random UUID | Thread ID for conversation continuity. |
| `--persistence {memory,sqlite,postgres}` | `sqlite` | Persistence backend. |
| `--db-path PATH` | per-backend default | SQLite database path. |
| `--connection-string TEXT` | from env | PostgreSQL connection string (supports `${ENV_VAR}` syntax). |
| `--output {tty,json,ndjson}` | `tty` | Output format. `json` and `ndjson` are aliases — both emit one JSON event per line for CI / scripts. See [event schema](#json-event-schema). |
| `--debug` | off | Show full Python tracebacks instead of friendly errors. Implies DEBUG-level `agentflow.*` logging. Equivalent to `AGENTFLOW_DEBUG=1`. |
| `--verbose` / `-v` | off | INFO-level `agentflow.*` logging. Quieter than `--debug`. |
| `--ascii` | auto | Use ASCII fallbacks for unicode markers (`▸/←/·/✓/✗`). Auto-enabled when stdout isn't UTF-8. |

## JSON event schema

When you pass `--output ndjson` (or its alias `--output json`),
`agentflow` emits one JSON object per line on stdout instead of the
Rich-rendered terminal output. The schema is the same for every
backend.

Each line carries:

- `type` — discriminator. One of: `status`, `agent_start`, `agent_end`,
  `agent_switch`, `token`, `tool_call`, `tool`, `reasoning`, `stats`,
  `complete`, `error`.
- `ts` — ISO-8601 UTC timestamp.
- `backend` — short backend name.
- type-specific fields (see `agentflow.cli.events` for the
  authoritative list).

Example pipeline:

```bash
agentflow --output ndjson "your query" \
  | jq -c 'select(.type == "tool")'         # filter to tool results
```

Terminal events: a run always ends with one `stats` event followed by
one `complete` event so consumers can detect the boundary
deterministically.

## Interactive REPL

`--interactive` opens a continuous conversation loop with:

- **readline history** — arrow-up cycles previous queries; persisted
  across sessions in `~/.agentflow/history`.
- **slash commands** —
  - `/help` — list commands
  - `/clear` — clear the screen
  - `/stats` — show accumulated tokens / tool calls / thread id
  - `/quit` (aliases: `/q`, `/exit`)
- **bare quit aliases** — typing `quit`, `exit`, or `q` exits, as does
  Ctrl-D and Ctrl-C.

## Diagnostics

By default the CLI mutes noisy third-party loggers (gRPC,
OpenTelemetry, asyncio, httpx, openai, anthropic, azure.*, langchain,
langgraph) at WARNING. Promote them with environment variables or
flags:

| Use case | How |
| --- | --- |
| See what `agentflow.*` is doing | `agentflow -v "your query"` |
| See full tracebacks for an error | `agentflow --debug "your query"` |
| Re-enable gRPC chatter | `GRPC_VERBOSITY=DEBUG agentflow -v "..."` |
| Pin a specific level | `AGENTFLOW_LOG_LEVEL=INFO agentflow "..."` |

## Cross-platform / non-TTY

- **Auto-detection** — if `sys.stdout.encoding` doesn't advertise
  UTF-8 the CLI silently falls back to ASCII glyphs (`>` for `▸`,
  `<-` for `←`, etc.). No flag needed for the common Windows
  `cmd.exe` / CI-log-without-locale case.
- **`--ascii`** forces the ASCII set on a UTF-8 console (handy for
  copy-pasting into screen-readers or LLM contexts).
- **`AGENTFLOW_ASCII=1`** as a hard env override.
- **`NO_COLOR`** — Rich already honours this convention natively
  (no agentflow-specific flag needed).

## Environment variables

| Variable | Purpose |
| --- | --- |
| `AGENTFLOW_LOG_LEVEL` | `DEBUG` / `INFO` / `WARNING` / `ERROR`. `--debug` and `-v` rewrite this. |
| `AGENTFLOW_DEBUG` | Truthy → traceback mode (same as `--debug`). |
| `AGENTFLOW_ASCII` | Truthy → ASCII glyphs (same as `--ascii`). |
| `AGENTFLOW_ENCRYPTION_KEY` | AES-GCM key for persistence encryption (16/24/32 bytes, hex or raw). |
| `OTEL_TRACES_ENABLED` | `true` → enable OpenTelemetry tracing. |
| `GRPC_VERBOSITY` | `agentflow` sets to `ERROR` by default; export your own value to override. |
| `NO_COLOR` | Standard convention — Rich honours it. |
| `POSTGRES_CONNECTION_STRING` | Default for `--connection-string`. |
| `CHECKPOINTER_DB_PATH` | Default SQLite path (shared by workflows / deep). |
| `POSTGRES_POOL_SIZE` | Max connections in the pool (default `5`). **workflows / deep only.** |
| `POSTGRES_POOL_MIN_SIZE` | Connections kept open at all times (default `1`). |
| `POSTGRES_POOL_MAX_LIFETIME` | Seconds before a connection is retired and reopened (default `600`). |
| `POSTGRES_POOL_MAX_IDLE` | Seconds an idle connection above `min_size` is kept (default `300`). |
| `POSTGRES_POOL_CHECK` | Validate connections on checkout (default `true`). |
| `POSTGRES_POOL_TIMEOUT` | Seconds to wait for a free connection (default `30`). |

The `POSTGRES_POOL_*` family applies to the **workflows** and **deep** backends,
which pool their PostgreSQL connections. The other backends open a connection
per operation and ignore these. Defaults are safe — you only need to touch them
to fit a connection cap or a short server-side idle timeout. See
[`workflows/docs/PERSISTENCE.md`](../workflows/docs/PERSISTENCE.md#connection-pooling-and-resilience).

Every variable in this table is read by one shared resolver, so it applies
whether you start AgentFlow through the `agentflow` CLI or embed it as a
library (`build_agui`, `AsyncWorkflowOrchestrator`). Precedence is CLI flag >
environment variable > default.

Backend-specific env vars (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`,
`AZURE_OPENAI_ENDPOINT`, etc.) are documented in each backend's
own `CLI_REFERENCE.md` / `LLM_PROVIDERS.md`.
