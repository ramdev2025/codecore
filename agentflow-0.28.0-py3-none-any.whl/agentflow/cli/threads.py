"""Backend-agnostic thread management.

Today every backend persists conversation state somewhere — but users
have no way to *see* what's stored, *delete* a polluted thread, or
*wipe* the persistence DB short of ``rm data/*.db``. This module
unifies the various per-backend persistence managers behind one
:class:`ThreadManager` protocol so a single ``agentflow-threads``
command can list / delete / clear regardless of which backend the
project uses.

Discovery
---------

Each backend already has different ergonomics for its persistence:

- ``sk``, ``cas``, ``oai``, ``maf`` — their persistence managers
  expose ``list_threads()`` and ``delete(thread_id)`` natively.
  We just wrap them.
- ``workflows``, ``deep`` — both use LangGraph checkpointers
  (SqliteSaver / PostgresSaver). LangGraph doesn't expose a public
  enumeration API, so we query the underlying SQLite directly via
  the well-known ``checkpoints`` schema.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ThreadInfo:
    """One row of the ``threads list`` output.

    Backends vary in what they track per thread; only ``thread_id`` and
    ``backend`` are guaranteed. The optional fields surface when the
    backend's persistence stores them.
    """

    thread_id: str
    backend: str
    last_run_at: Optional[str] = None
    n_turns: Optional[int] = None
    total_tokens: Optional[int] = None


@runtime_checkable
class ThreadManager(Protocol):
    """Minimum API every backend's thread manager exposes.

    ``list_threads()`` is the only one that has to return rich metadata
    when available. ``delete_thread()`` returns ``True`` when the
    thread existed and was removed, ``False`` if it wasn't there
    (idempotent — safe to call twice). ``clear()`` returns the number
    of threads removed.
    """

    backend: str

    def list_threads(self) -> List[ThreadInfo]: ...

    def delete_thread(self, thread_id: str) -> bool: ...

    def clear(self) -> int: ...


# ---------------------------------------------------------------------------
# Backend implementations
# ---------------------------------------------------------------------------


class _PersistenceWrapperManager:
    """Adapter for backends whose persistence layer already exposes
    ``list_threads()`` + ``delete(thread_id)``.

    Used by sk, cas, oai, maf — their persistence managers all expose
    matching methods (the names converged earlier in the codebase
    independently of this work).
    """

    def __init__(self, backend: str, pm: object):
        self.backend = backend
        self._pm = pm

    def list_threads(self) -> List[ThreadInfo]:
        ids = list(self._pm.list_threads())  # type: ignore[attr-defined]
        return [ThreadInfo(thread_id=t, backend=self.backend) for t in ids]

    def delete_thread(self, thread_id: str) -> bool:
        existing = set(self._pm.list_threads())  # type: ignore[attr-defined]
        if thread_id not in existing:
            return False
        self._pm.delete(thread_id)  # type: ignore[attr-defined]
        return True

    def clear(self) -> int:
        ids = list(self._pm.list_threads())  # type: ignore[attr-defined]
        for tid in ids:
            self._pm.delete(tid)  # type: ignore[attr-defined]
        return len(ids)


class _LangGraphSqliteThreadManager:
    """Manager for ``workflows`` and ``deep`` — both use LangGraph's
    SqliteSaver under the hood.

    The schema we query is part of LangGraph's stable public surface:
    a ``checkpoints`` table with a ``thread_id`` column, and a
    ``writes`` table that joins on the same key. Counting distinct
    ``thread_id``s gives us the list; deleting from both tables
    guarantees a clean removal.
    """

    _CHECKPOINT_TABLES = ("checkpoints", "writes", "checkpoint_blobs")

    def __init__(self, backend: str, db_path: Path):
        self.backend = backend
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        # The DB might not exist yet (fresh install): we still want
        # ``list_threads()`` to return an empty list rather than blow up.
        if not self.db_path.exists():
            return sqlite3.connect(":memory:")
        return sqlite3.connect(str(self.db_path))

    def list_threads(self) -> List[ThreadInfo]:
        with self._connect() as conn:
            try:
                rows = conn.execute(
                    """
                    SELECT thread_id, COUNT(*) AS n, MAX(checkpoint_id) AS last
                    FROM checkpoints
                    GROUP BY thread_id
                    ORDER BY last DESC
                    """
                ).fetchall()
            except sqlite3.OperationalError:
                # Table doesn't exist (fresh DB). Empty list.
                return []
        return [
            ThreadInfo(
                thread_id=tid,
                backend=self.backend,
                n_turns=int(n),
                last_run_at=str(last) if last else None,
            )
            for tid, n, last in rows
        ]

    def delete_thread(self, thread_id: str) -> bool:
        if not self.db_path.exists():
            return False
        deleted = False
        with self._connect() as conn:
            for table in self._CHECKPOINT_TABLES:
                try:
                    cur = conn.execute(
                        f"DELETE FROM {table} WHERE thread_id = ?", (thread_id,)
                    )
                    if cur.rowcount > 0:
                        deleted = True
                except sqlite3.OperationalError:
                    # Table not present in this LangGraph version. Skip.
                    continue
            conn.commit()
        return deleted

    def clear(self) -> int:
        if not self.db_path.exists():
            return 0
        ids = [t.thread_id for t in self.list_threads()]
        for tid in ids:
            self.delete_thread(tid)
        return len(ids)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


_DEFAULT_DB_PATHS = {
    "workflows": ".agentflow/checkpoints.db",
    "deep": ".agentflow/deep_checkpoints.db",
}


def for_backend(
    backend: str,
    *,
    db_path: Optional[str] = None,
    persistence: str = "sqlite",
    connection_string: Optional[str] = None,
) -> ThreadManager:
    """Build a :class:`ThreadManager` for ``backend``.

    ``persistence``, ``db_path``, and ``connection_string`` are the
    same values the user passes to ``agentflow run``; we honor them
    so that ``agentflow-threads`` operates on the same store the
    runs do.
    """
    if backend in ("workflows", "deep"):
        if persistence != "sqlite":
            raise NotImplementedError(
                f"thread management for {backend!r} currently supports "
                f"only sqlite persistence (got {persistence!r}). "
                "Postgres / memory will follow."
            )
        path = Path(db_path or _DEFAULT_DB_PATHS[backend])
        return _LangGraphSqliteThreadManager(backend=backend, db_path=path)

    if backend == "semantic-kernel":
        from agentflow.sk.core.persistence import create_persistence_manager
        pm = create_persistence_manager(
            backend=persistence, db_path=db_path, connection_string=connection_string,
        )
        return _PersistenceWrapperManager(backend=backend, pm=pm)

    if backend == "claude-agent-sdk":
        from agentflow.cas.core.persistence import create_persistence_manager
        pm = create_persistence_manager(
            backend=persistence, db_path=db_path, connection_string=connection_string,
        )
        return _PersistenceWrapperManager(backend=backend, pm=pm)

    if backend == "openai-agents":
        from agentflow.oai.persistence import create_persistence_manager
        pm = create_persistence_manager(
            backend=persistence, db_path=db_path, connection_string=connection_string,
        )
        return _PersistenceWrapperManager(backend=backend, pm=pm)

    if backend == "agent-framework":
        from agentflow.maf.persistence import create_persistence_manager
        pm = create_persistence_manager(
            backend=persistence, db_path=db_path, connection_string=connection_string,
        )
        return _PersistenceWrapperManager(backend=backend, pm=pm)

    raise ValueError(f"Unknown backend: {backend!r}")
