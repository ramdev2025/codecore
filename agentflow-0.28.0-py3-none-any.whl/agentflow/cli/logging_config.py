"""Centralised logging configuration for the CLI.

The default user experience should be: clean lines from ``agentflow.*``
plus your agent's output, *not* gRPC's ``FD from fork parent`` notes,
OpenTelemetry's ``Failed to detach context`` warnings, or the half-dozen
asyncio/httpx/openai INFO records every long-running tool call emits.

This module gives the router one call to make those defaults stick:

- ``setup_logging(debug=…, verbose=…)`` is the public entry point. The
  router invokes it before any backend imports so ``GRPC_VERBOSITY``
  takes effect at gRPC's import-time read.
- ``--debug`` → ``agentflow.*`` at DEBUG, third-party stays clamped.
- ``--verbose`` → ``agentflow.*`` at INFO.
- Default (no flags) → ``agentflow.*`` at WARNING, third-party libs at
  WARNING/ERROR.
- The historical ``AGENTFLOW_LOG_LEVEL`` env var still wins when set;
  power users sometimes want DEBUG without ``--debug``'s side effect of
  surfacing tracebacks.

Backends already call ``logging.getLogger('agentflow').setLevel(...)``
on entry; we rewrite ``AGENTFLOW_LOG_LEVEL`` from the flag so those
existing calls converge on the chosen level without modification.
"""

from __future__ import annotations

import logging
import os
from typing import Iterable

# Loggers we proactively quiet. Each of these has been observed to
# leak INFO / DEBUG records into agentflow CLI sessions during real
# runs. WARNING is still allowed through so genuine problems show up.
_NOISY_LOGGERS = (
    # gRPC (Anthropic SDK, Azure, OTel exporter — anything that uses gRPC)
    "grpc",
    "grpc._channel",
    # OpenTelemetry
    "opentelemetry",
    "opentelemetry.context",
    "opentelemetry.exporter",
    "opentelemetry.sdk",
    "opentelemetry.trace",
    # Async / HTTP
    "asyncio",
    "httpx",
    "httpcore",
    "urllib3",
    # SDK clients
    "openai",
    "anthropic",
    "azure",
    "azure.core",
    "azure.identity",
    # LangChain / LangGraph chatter (workflows + deep)
    "langchain",
    "langchain_core",
    "langgraph",
)


def quiet_third_party_loggers(level: int = logging.WARNING) -> None:
    """Clamp every logger in :data:`_NOISY_LOGGERS` to ``level``.

    Idempotent. The clamp is applied to each logger directly so it
    overrides whatever its parent's level happened to be — which
    matters because once a single ``logging.basicConfig`` call sets
    the root logger to DEBUG (any third-party lib can do this on
    import), every child inherits unless we explicitly clamp.
    """
    for name in _NOISY_LOGGERS:
        logging.getLogger(name).setLevel(level)


def _set_grpc_verbosity_env() -> None:
    """``gRPC`` reads ``GRPC_VERBOSITY`` once at import.

    Setting this from the router *before* any backend SDK is imported
    silences gRPC's chatty ``I0123 ... FD from fork parent`` notices
    that otherwise leak into the user's terminal. The user's existing
    value wins so that telemetry-debugging sessions can keep using
    ``GRPC_VERBOSITY=DEBUG``.
    """
    os.environ.setdefault("GRPC_VERBOSITY", "ERROR")
    # gRPC also has a tracer — keep it silent unless someone really
    # asked for it.
    os.environ.setdefault("GRPC_TRACE", "")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def resolve_agentflow_level(*, debug: bool, verbose: bool) -> str:
    """Return the level name that should drive ``agentflow.*``.

    The flag → level mapping:

    - ``debug`` → ``"DEBUG"``
    - ``verbose`` → ``"INFO"``
    - otherwise → respect ``AGENTFLOW_LOG_LEVEL`` if set, else
      ``"WARNING"``.

    Pure helper so tests can pin the resolution table without touching
    the logging module.
    """
    if debug:
        return "DEBUG"
    if verbose:
        return "INFO"
    return os.environ.get("AGENTFLOW_LOG_LEVEL", "WARNING").upper()


def setup_logging(*, debug: bool = False, verbose: bool = False) -> None:
    """Configure logging for the whole CLI process.

    Called once from the router before any backend import. Safe to call
    again (idempotent). Side effects:

    1. Sets ``GRPC_VERBOSITY`` / ``GRPC_TRACE`` env vars (if unset).
    2. Clamps third-party noisy loggers to WARNING.
    3. Sets ``agentflow.*`` to the level resolved by
       :func:`resolve_agentflow_level`.
    4. Writes the chosen level back to ``AGENTFLOW_LOG_LEVEL`` so the
       per-backend ``run_from_router`` calls (which read that env var
       on entry) inherit it.
    """
    _set_grpc_verbosity_env()
    quiet_third_party_loggers(logging.WARNING)

    level_name = resolve_agentflow_level(debug=debug, verbose=verbose)
    level = getattr(logging, level_name, logging.WARNING)

    # Promote to the env var so the existing per-backend setLevel
    # calls — which read ``AGENTFLOW_LOG_LEVEL`` directly — converge
    # on the same level without per-backend wiring.
    os.environ["AGENTFLOW_LOG_LEVEL"] = level_name
    logging.getLogger("agentflow").setLevel(level)


def list_quieted_loggers() -> Iterable[str]:
    """Diagnostic — names of loggers ``setup_logging`` clamps."""
    return _NOISY_LOGGERS
