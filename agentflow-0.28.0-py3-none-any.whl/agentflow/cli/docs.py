"""
Unified docs launcher.

``agentflow-docs`` auto-detects which backend is installed and serves its
documentation. If multiple backends are installed (dev environments, mostly),
the ``--backend`` flag picks which docs to serve.

Port assignments:
- workflows        → 9000
- deep             → 9100
- semantic-kernel  → 9200
- claude-agent-sdk → 9300
- openai-agents    → 9400
- agent-framework  → 9500

Single command for all backends: ``agentflow docs`` (alias:
``agentflow-docs``). The per-backend ``agentflow-{backend}-docs`` aliases
were removed in v0.24 — backend detection happens via the YAML's
``backend:`` key in the current directory, or you can pass ``--backend``
explicitly.
"""

import argparse
import subprocess
import sys
from pathlib import Path
from typing import List, Optional, Tuple


DEFAULT_PORTS = {
    "workflows": 9000,
    "deep": 9100,
    "semantic-kernel": 9200,
    "claude-agent-sdk": 9300,
    "openai-agents": 9400,
    "agent-framework": 9500,
    "adk": 9600,
}


def detect_installed_backends() -> List[str]:
    """Return the list of installed backend names (at most one).

    Detection priority (first match wins):

    - ``google.adk``       → ``adk``
    - ``agent_framework``  → ``agent-framework``
    - ``claude_agent_sdk`` → ``claude-agent-sdk``
    - ``agents``           → ``openai-agents``
    - ``deepagents``       → ``deep``
    - ``semantic_kernel``  → ``semantic-kernel``
    - ``langchain``        → ``workflows`` (catch-all for LangGraph backend)

    Users aren't expected to install multiple backends in the same env.
    When they do (dev environments), this returns the first by priority
    above, and users can override with ``--backend`` anyway.

    This is robust to future backends — adding a new framework won't
    collide with the workflows fallback, since each new backend adds
    its own specific library check above.
    """
    import importlib.util

    def _has(module_name: str) -> bool:
        return importlib.util.find_spec(module_name) is not None

    # Order: most-specific (and most-recently-added) first. The
    # ``langchain`` check is a deliberate fallback for the ``workflows``
    # backend — every other entry must come before it. ADK leads the
    # specific block so it wins disambiguation in dev environments where
    # multiple SDKs are installed alongside it (e.g. ``Labs/agentflow``).
    if _has("google.adk"):
        return ["adk"]
    if _has("agent_framework"):
        return ["agent-framework"]
    if _has("claude_agent_sdk"):
        return ["claude-agent-sdk"]
    if _has("agents"):
        return ["openai-agents"]
    if _has("deepagents"):
        return ["deep"]
    if _has("semantic_kernel"):
        return ["semantic-kernel"]
    if _has("langchain"):
        return ["workflows"]
    return []


def get_docs_root(backend: str) -> Optional[Tuple[Path, int]]:
    """Find the mkdocs.yml for the given backend. Returns (root_dir, port) or None."""
    import agentflow

    # In installed wheel, mkdocs.yml lives next to the backend module
    backend_module_map = {
        "workflows": "workflows",
        "deep": "deep",
        "semantic-kernel": "sk",
        "claude-agent-sdk": "cas",
        "openai-agents": "oai",
        "agent-framework": "maf",
        "adk": "adk",
    }
    subdir = backend_module_map.get(backend)
    if subdir is None:
        return None

    pkg_root = Path(agentflow.__file__).resolve().parent
    candidate = pkg_root / subdir / "mkdocs.yml"
    if candidate.exists():
        return candidate.parent, DEFAULT_PORTS[backend]

    # Dev mode — walk up to find mkdocs.yml at src/agentflow/<subdir>/mkdocs.yml
    # relative to the current working directory
    dev_candidate = Path.cwd() / "src" / "agentflow" / subdir / "mkdocs.yml"
    if dev_candidate.exists():
        return dev_candidate.parent, DEFAULT_PORTS[backend]

    return None


from agentflow.cli.errors import wrap_cli_main


@wrap_cli_main
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Serve AgentFlow documentation (auto-detects installed backend)",
    )
    parser.add_argument(
        "--backend",
        choices=list(DEFAULT_PORTS.keys()),
        help="Explicit backend (overrides auto-detection)",
    )
    parser.add_argument(
        "--dev-addr",
        default=None,
        help="Address to serve on (default: 127.0.0.1:<backend-port>)",
    )
    args = parser.parse_args()

    # Require mkdocs
    try:
        subprocess.run(["mkdocs", "--version"], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("Error: MkDocs is not installed.", file=sys.stderr)
        sys.exit(1)

    # Resolve backend — use --backend if provided, else auto-detect
    backend = args.backend
    if backend is None:
        installed = detect_installed_backends()
        if not installed:
            print(
                "Error: No AgentFlow backend is installed. Install one:\n"
                "  pip install agentflow[workflows]\n"
                "  pip install agentflow[deep]\n"
                "  pip install agentflow[semantic-kernel]\n"
                "  pip install agentflow[claude-agent-sdk]\n"
                "  pip install agentflow[openai-agents]\n"
                "  pip install agentflow[agent-framework]\n"
                "  pip install agentflow[adk]",
                file=sys.stderr,
            )
            sys.exit(1)
        backend = installed[0]

    # Resolve docs directory
    resolved = get_docs_root(backend)
    if resolved is None:
        print(
            f"Error: docs directory for backend '{backend}' not found. "
            f"Is the backend installed?",
            file=sys.stderr,
        )
        sys.exit(1)
    docs_root, default_port = resolved
    dev_addr = args.dev_addr or f"127.0.0.1:{default_port}"

    print(f"Serving {backend} documentation from {docs_root}")
    print(f"http://{dev_addr}")
    print()

    try:
        subprocess.run(
            ["mkdocs", "serve", "--dev-addr", dev_addr],
            cwd=docs_root,
            check=True,
        )
    except KeyboardInterrupt:
        print("\nStopped.")
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)


if __name__ == "__main__":
    main()
