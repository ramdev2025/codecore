"""Built-in guard / optimizer / observer implementations.

Each function here returns an async hook callable in the SDK's expected
shape. The filter compiler decides which of the 10 hook events the
callable gets registered against.

Hook signatures (per SDK):

    async def on_pre_tool_use(input_data, tool_use_id, context) -> dict
    async def on_post_tool_use(input_data, tool_use_id, context) -> dict
    ...

A return value of ``{"decision": "block", "reason": "..."}`` tells the SDK
to deny the tool call; an empty dict allows it.

OTel: when ``OTEL_TRACES_ENABLED=true`` (set up by ``cas.telemetry``), these
observers emit spans using the ``gen_ai.*`` semantic conventions so tools
appear as their own spans in Jaeger / Tempo / Datadog / etc.
"""

from __future__ import annotations

import logging
import re
import time
from collections import defaultdict
from typing import Any, Dict

# ---------------------------------------------------------------------------
# Loggers — agentflow.cas.audit is the canonical tool-audit stream
# ---------------------------------------------------------------------------

_audit_log = logging.getLogger("agentflow.cas.audit")
_cost_log = logging.getLogger("agentflow.cas.cost")
_latency_log = logging.getLogger("agentflow.cas.latency")


# ---------------------------------------------------------------------------
# Lazy tracer — resolved per-call so OTel setup can happen after import
# ---------------------------------------------------------------------------


def _tracer():
    from opentelemetry import trace

    return trace.get_tracer("agentflow.cas")


# ---------------------------------------------------------------------------
# GUARDS — constrain execution
# ---------------------------------------------------------------------------


def make_tool_call_limit_guard(max_calls: int = 50):
    """Return a PreToolUse hook that blocks past ``max_calls`` invocations."""
    counter = {"n": 0}

    async def guard(input_data: Dict[str, Any], tool_use_id: str, context: Any):
        counter["n"] += 1
        if counter["n"] > max_calls:
            return {
                "decision": "block",
                "reason": (
                    f"tool_call_limit reached ({max_calls}); agent stopped "
                    f"to prevent runaway execution"
                ),
            }
        return {}

    return guard


def make_model_call_limit_guard(max_calls: int = 100):
    """Return a UserPromptSubmit hook blocking past ``max_calls`` model calls.

    Proxy metric: each user-prompt-submit roughly corresponds to a new model
    turn. Not perfect (a single prompt can trigger many inferences) but gives
    a tripwire without SDK-level counters.
    """
    counter = {"n": 0}

    async def guard(input_data: Dict[str, Any], tool_use_id: str, context: Any):
        counter["n"] += 1
        if counter["n"] > max_calls:
            return {
                "decision": "block",
                "reason": f"model_call_limit reached ({max_calls})",
            }
        return {}

    return guard


def make_pii_guard(patterns: list[str] | None = None):
    """Return a UserPromptSubmit hook that redacts PII patterns in-place.

    ``patterns`` is a list of named patterns (``email``, ``phone``, ``ssn``,
    ``credit_card``) — or custom regex strings. Unknown names are ignored.
    """
    named = {
        "email": r"[\w\.-]+@[\w\.-]+",
        "phone": r"\b(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "credit_card": r"\b(?:\d[ -]*?){13,16}\b",
    }
    patterns = patterns or ["email", "phone", "ssn", "credit_card"]
    compiled = [re.compile(named.get(p, p)) for p in patterns]

    async def guard(input_data: Dict[str, Any], tool_use_id: str, context: Any):
        prompt = (input_data or {}).get("prompt")
        if not isinstance(prompt, str):
            return {}
        redacted = prompt
        for pat in compiled:
            redacted = pat.sub("[REDACTED]", redacted)
        if redacted != prompt:
            return {"hookSpecificOutput": {"updatedPrompt": redacted}}
        return {}

    return guard


def make_custom_guard(callable_fn):
    """Wrap a user-provided callable as a guard (no validation)."""

    async def guard(input_data, tool_use_id, context):
        result = callable_fn(input_data, tool_use_id, context)
        if hasattr(result, "__await__"):
            result = await result
        return result or {}

    return guard


# ---------------------------------------------------------------------------
# OPTIMIZERS — improve efficiency
# ---------------------------------------------------------------------------


def make_tool_retry_optimizer(
    max_retries: int = 2, initial_backoff_ms: int = 500
):
    """PostToolUseFailure hook that requests the SDK to retry.

    The SDK honors ``{"decision": "retry"}`` when the hook returns it on a
    ``PostToolUseFailure`` event. We track per-tool retry counts so runaway
    retries don't spiral.
    """
    counters: Dict[str, int] = defaultdict(int)

    async def opt(input_data: Dict[str, Any], tool_use_id: str, context: Any):
        tool_name = (input_data or {}).get("tool_name", "<unknown>")
        counters[tool_name] += 1
        if counters[tool_name] > max_retries:
            return {}
        delay_ms = initial_backoff_ms * (2 ** (counters[tool_name] - 1))
        return {
            "decision": "retry",
            "reason": (
                f"auto-retry ({counters[tool_name]}/{max_retries}) after "
                f"{delay_ms}ms"
            ),
        }

    return opt


def make_summarization_optimizer(
    trigger_messages: int = 40, keep_messages: int = 10
):
    """PreCompact hook — the SDK's native compaction handles summarization.

    Our optimizer just emits a log line so operators can correlate
    compactions with context-size blowups. The actual compaction is done
    by the SDK; we don't override it here.
    """

    async def opt(input_data: Dict[str, Any], tool_use_id: str, context: Any):
        _audit_log.info(
            "summarization_optimizer: pre-compact fired "
            "(trigger=%d, keep=%d)",
            trigger_messages,
            keep_messages,
        )
        return {}

    return opt


# ---------------------------------------------------------------------------
# OBSERVERS — watch without modifying
# ---------------------------------------------------------------------------


def make_audit_log_observer():
    """Per-tool span + structured log.

    PreToolUse starts a ``gen_ai.execute_tool <name>`` span; PostToolUse
    finalizes it with the result. Span carries ``gen_ai.tool.name``,
    ``gen_ai.tool.call.id``, and ``gen_ai.tool.call.arguments`` attributes.
    Also emits Python log records on ``agentflow.cas.audit`` for log
    aggregators that don't consume OTel.
    """
    active_spans: Dict[str, Any] = {}

    async def pre(input_data, tool_use_id, context):
        tool = (input_data or {}).get("tool_name", "<unknown>")
        tool_input = (input_data or {}).get("tool_input")
        _audit_log.info(
            "tool_use_start id=%s tool=%s input=%s", tool_use_id, tool, tool_input
        )
        try:
            span = _tracer().start_span(
                f"gen_ai.execute_tool {tool}",
                attributes={
                    "gen_ai.operation.name": "execute_tool",
                    "gen_ai.tool.name": tool,
                    "gen_ai.tool.call.id": tool_use_id,
                    "gen_ai.tool.call.arguments": _truncate(tool_input),
                },
            )
            active_spans[tool_use_id] = span
        except Exception:
            pass  # tracing must never break the agent
        return {}

    async def post(input_data, tool_use_id, context):
        tool = (input_data or {}).get("tool_name", "<unknown>")
        # SDK's PostToolUseHookInput calls this field ``tool_response``.
        result = (input_data or {}).get("tool_response")
        _audit_log.info("tool_use_end id=%s tool=%s ok=True", tool_use_id, tool)
        span = active_spans.pop(tool_use_id, None)
        if span is not None:
            try:
                span.set_attribute("gen_ai.tool.call.result", _truncate(result))
                span.end()
            except Exception:
                pass
        return {}

    return pre, post


def make_cost_tracking_observer(budget_limit: float | None = None):
    """Stop hook: records that the session ended.

    **Design note.** The SDK's ``StopHookInput`` does NOT carry usage or
    total_cost_usd — those live on the ``ResultMessage`` of the outgoing
    stream, not on any hook payload. The CLI driver intercepts the
    ``ResultMessage`` directly and attaches cost + usage attributes to the
    root ``agentflow.cas.run`` span and a ``gen_ai.session_summary`` child
    span. This observer still fires so the Stop event is visible in audit
    logs, but it carries only operational metadata.
    """

    async def on_stop(input_data, tool_use_id, context):
        _cost_log.info(
            "session_stop session=%s budget=%s",
            (input_data or {}).get("session_id", "?"),
            budget_limit,
        )
        try:
            attrs: Dict[str, Any] = {"gen_ai.operation.name": "session_stop_hook"}
            if budget_limit is not None:
                attrs["agentflow.budget_usd"] = budget_limit
            with _tracer().start_as_current_span(
                "agentflow.session_stop", attributes=attrs
            ):
                pass
        except Exception:
            pass
        return {}

    return on_stop


def make_latency_tracking_observer():
    """PreToolUse + PostToolUse pair that records per-tool latency.

    Emits the duration as a span attribute (``agentflow.tool.latency_ms``) on
    its own span and as a structured log record. Complementary to the audit
    log observer — you get dedicated latency spans even if audit_log is off.
    """
    starts: Dict[str, float] = {}
    spans: Dict[str, Any] = {}

    async def pre(input_data, tool_use_id, context):
        starts[tool_use_id] = time.perf_counter()
        tool = (input_data or {}).get("tool_name", "<unknown>")
        try:
            span = _tracer().start_span(
                f"agentflow.tool.latency {tool}",
                attributes={"gen_ai.tool.name": tool, "gen_ai.tool.call.id": tool_use_id},
            )
            spans[tool_use_id] = span
        except Exception:
            pass
        return {}

    async def post(input_data, tool_use_id, context):
        started = starts.pop(tool_use_id, None)
        tool = (input_data or {}).get("tool_name", "<unknown>")
        elapsed_ms = (time.perf_counter() - started) * 1000 if started else None
        if elapsed_ms is not None:
            _latency_log.info(
                "tool_latency id=%s tool=%s elapsed_ms=%.2f",
                tool_use_id,
                tool,
                elapsed_ms,
            )
        span = spans.pop(tool_use_id, None)
        if span is not None:
            try:
                if elapsed_ms is not None:
                    span.set_attribute("agentflow.tool.latency_ms", elapsed_ms)
                span.end()
            except Exception:
                pass
        return {}

    return pre, post


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _truncate(value: Any, max_len: int = 2000) -> str:
    """Coerce to string and cap at ``max_len`` for span attribute safety.

    OTLP backends reject overly large attribute values; trim long tool I/O.
    """
    s = repr(value) if not isinstance(value, str) else value
    return s if len(s) <= max_len else s[: max_len - 12] + "...[trunc]"
