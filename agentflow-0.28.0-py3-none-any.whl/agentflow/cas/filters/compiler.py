"""Compile cross-backend guards/optimizers/observers into CAS hook registrations.

The cross-backend schema (``guards:`` / ``optimizers:`` / ``observers:``) lives
at tier 1 in our portability model — it migrates mechanically across backends.
In CAS each entry compiles to one or more hook registrations (a
``(event_name, HookConfig-like)`` pair) that are merged with the user's
explicit ``agent.hooks:`` during builder assembly.

The compiler deliberately mirrors ``agentflow.sk.filters.compiler`` so the
cross-backend vocabulary stays stable.
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from agentflow.cas.core.config_models import (
    GuardConfig,
    GuardType,
    HookEvent,
    ObserverConfig,
    ObserverType,
    OptimizerConfig,
    OptimizerType,
)
from agentflow.cas.filters import builtin


@dataclass
class CompiledHook:
    """One hook registration ready to merge into ``ClaudeAgentOptions.hooks``.

    ``event`` is the SDK's string (e.g. ``"PreToolUse"``). ``callback`` is
    the async function. ``matcher`` is an optional regex. ``timeout`` is in
    seconds. The builder wraps these into ``HookMatcher`` instances.
    """

    event: str
    callback: Callable[..., Any]
    matcher: Optional[str] = None
    timeout: int = 30


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------


def compile_guards(guards: List[GuardConfig] | None) -> List[CompiledHook]:
    if not guards:
        return []
    out: List[CompiledHook] = []
    for g in guards:
        cfg = g.config or {}
        if g.module and g.function:
            # Custom guard — user provides the hook function
            fn = _resolve_callable(g.module, g.function)
            out.append(
                CompiledHook(
                    event=HookEvent.PRE_TOOL_USE.value,
                    callback=builtin.make_custom_guard(fn),
                )
            )
            continue

        if g.type == GuardType.TOOL_CALL_LIMIT:
            out.append(
                CompiledHook(
                    event=HookEvent.PRE_TOOL_USE.value,
                    callback=builtin.make_tool_call_limit_guard(
                        max_calls=cfg.get("max_calls", 50)
                    ),
                )
            )
        elif g.type == GuardType.MODEL_CALL_LIMIT:
            out.append(
                CompiledHook(
                    event=HookEvent.USER_PROMPT_SUBMIT.value,
                    callback=builtin.make_model_call_limit_guard(
                        max_calls=cfg.get("max_calls", 100)
                    ),
                )
            )
        elif g.type == GuardType.PII:
            out.append(
                CompiledHook(
                    event=HookEvent.USER_PROMPT_SUBMIT.value,
                    callback=builtin.make_pii_guard(
                        patterns=cfg.get("patterns")
                    ),
                )
            )
        elif g.type in (GuardType.INPUT_VALIDATION, GuardType.CONTENT_FILTER):
            # These are user-provided — require module+function
            raise ValueError(
                f"Guard type {g.type.value!r} requires a custom "
                f"`module:` + `function:` implementation."
            )
        else:  # pragma: no cover - schema enforces enum
            raise ValueError(f"Unknown guard type: {g.type!r}")
    return out


# ---------------------------------------------------------------------------
# Optimizers
# ---------------------------------------------------------------------------


def compile_optimizers(
    optimizers: List[OptimizerConfig] | None,
) -> List[CompiledHook]:
    if not optimizers:
        return []
    out: List[CompiledHook] = []
    for o in optimizers:
        cfg = o.config or {}
        if o.module and o.function:
            fn = _resolve_callable(o.module, o.function)
            out.append(
                CompiledHook(
                    event=HookEvent.POST_TOOL_USE_FAILURE.value,
                    callback=builtin.make_custom_guard(fn),
                )
            )
            continue

        if o.type == OptimizerType.TOOL_RETRY:
            out.append(
                CompiledHook(
                    event=HookEvent.POST_TOOL_USE_FAILURE.value,
                    callback=builtin.make_tool_retry_optimizer(
                        max_retries=cfg.get("max_retries", 2),
                        initial_backoff_ms=cfg.get("initial_backoff_ms", 500),
                    ),
                )
            )
        elif o.type == OptimizerType.SUMMARIZATION:
            out.append(
                CompiledHook(
                    event=HookEvent.PRE_COMPACT.value,
                    callback=builtin.make_summarization_optimizer(
                        trigger_messages=cfg.get("trigger_messages", 40),
                        keep_messages=cfg.get("keep_messages", 10),
                    ),
                )
            )
        elif o.type == OptimizerType.PROMPT_CACHING:
            # Handled natively by the Anthropic SDK; no hook needed. We emit
            # a no-op to make the intent visible in the compiled output.
            async def _noop(*args, **kwargs):  # pragma: no cover
                return {}

            out.append(
                CompiledHook(event=HookEvent.NOTIFICATION.value, callback=_noop)
            )
        else:  # pragma: no cover - schema enforces enum
            raise ValueError(f"Unknown optimizer type: {o.type!r}")
    return out


# ---------------------------------------------------------------------------
# Observers
# ---------------------------------------------------------------------------


def compile_observers(
    observers: List[ObserverConfig] | None,
) -> List[CompiledHook]:
    if not observers:
        return []
    out: List[CompiledHook] = []
    for obs in observers:
        cfg = obs.config or {}
        if obs.module and obs.function:
            fn = _resolve_callable(obs.module, obs.function)
            out.append(
                CompiledHook(
                    event=HookEvent.POST_TOOL_USE.value,
                    callback=builtin.make_custom_guard(fn),
                )
            )
            continue

        if obs.type == ObserverType.AUDIT_LOG:
            pre, post = builtin.make_audit_log_observer()
            out.append(CompiledHook(event=HookEvent.PRE_TOOL_USE.value, callback=pre))
            out.append(CompiledHook(event=HookEvent.POST_TOOL_USE.value, callback=post))
        elif obs.type == ObserverType.COST_TRACKING:
            out.append(
                CompiledHook(
                    event=HookEvent.STOP.value,
                    callback=builtin.make_cost_tracking_observer(
                        budget_limit=cfg.get("budget_limit")
                    ),
                )
            )
        elif obs.type == ObserverType.LATENCY_TRACKING:
            pre, post = builtin.make_latency_tracking_observer()
            out.append(CompiledHook(event=HookEvent.PRE_TOOL_USE.value, callback=pre))
            out.append(CompiledHook(event=HookEvent.POST_TOOL_USE.value, callback=post))
        else:  # pragma: no cover - schema enforces enum
            raise ValueError(f"Unknown observer type: {obs.type!r}")
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_callable(module_path: str, function_name: str) -> Callable[..., Any]:
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Filter module {module_path!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"Filter function {function_name!r} not found in module {module_path!r}"
        )
    return fn


def to_hook_matchers(compiled: List[CompiledHook]) -> Dict[str, List[Any]]:
    """Collapse ``CompiledHook`` list into ``{event: [HookMatcher, ...]}``.

    Callers merge this with the user's explicit ``agent.hooks`` before
    passing to ``ClaudeAgentOptions``.
    """
    from collections import defaultdict

    from claude_agent_sdk import HookMatcher  # lazy

    grouped: Dict[str, List[Any]] = defaultdict(list)
    for c in compiled:
        grouped[c.event].append(
            HookMatcher(matcher=c.matcher, hooks=[c.callback], timeout=c.timeout)
        )
    return dict(grouped)
