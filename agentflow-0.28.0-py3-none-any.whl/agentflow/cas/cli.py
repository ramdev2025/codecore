"""AgentFlow CAS CLI — run Claude Agent SDK agents from the unified ``agentflow``
command.

The CLI router dispatches ``backend: claude-agent-sdk`` to ``run_from_router``
in this module. It translates canonical flags into SDK-specific objects,
executes the agent, and streams output to the console.

Supported modes:

- **dry-run** — validate the YAML and print a summary
- **one-shot** — single query via the SDK's ``query()`` function
- **interactive** — REPL loop over ``ClaudeSDKClient`` with persistent thread

Persistence (``--persistence``, ``--db-path``, ``--thread-id``) uses
``CasPersistenceManager`` to store a ``thread_id → SDK session id`` mapping,
so ``--thread-id my-thread`` always resumes the same SDK session.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any, Optional

from agentflow.cli import (
    ExecutionTimer,
    console,
    print_agent_response,
    print_banner,
    print_config_table,
    print_error,
    print_execution_summary,
    print_info,
    prompt_user,
)
from agentflow.cli.events import (
    EVENT_COMPLETE,
    EVENT_ERROR,
    EVENT_REASONING,
    EVENT_STATS,
    EVENT_TOKEN,
    EVENT_TOOL,
    EVENT_TOOL_CALL,
    JsonSink,
    is_json_mode,
)
from agentflow.cli.repl import (
    ReplState,
    cleanup_terminal_state,
    dispatch_slash_command,
    init_history,
    is_quit_alias,
    is_slash_command,
)
from agentflow.cli.streaming import pretty_json_block, result_length, result_preview


def run_from_router(
    yaml_path: str,
    query: Optional[str] = None,
    persistence: Optional[str] = None,
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
    thread_id: Optional[str] = None,
    interactive: bool = False,
    dry_run: bool = False,
    json_output: bool = False,
    output: str = "tty",
    **_ignored: Any,
):
    """Entry point called by the unified CLI router.

    Extra kwargs from the canonical flag set (``workdir``, ``no_tui``,
    ``tools_module``, ``recursion_limit``) are absorbed via ``**_ignored`` —
    they belong to other backends.

    Persistence precedence: ``--persistence`` flag > ``AGENTFLOW_PERSISTENCE``
    env var > default (sqlite).
    """
    from dotenv import find_dotenv, load_dotenv

    # Anchor dotenv at the user's cwd, not the installed module's directory.
    env_path = find_dotenv(usecwd=True)
    if env_path:
        load_dotenv(env_path, override=True)

    log_level = os.getenv("AGENTFLOW_LOG_LEVEL", "WARNING").upper()
    logging.getLogger("agentflow").setLevel(getattr(logging, log_level, logging.WARNING))

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    if persistence is None:
        persistence = os.environ.get("AGENTFLOW_PERSISTENCE", "sqlite").strip().lower()

    # ---- Dry-run (no SDK construction needed beyond schema validation) ----
    if dry_run:
        _run_dry(yaml_path, json_output=json_output)
        return

    json_sink: Optional[JsonSink] = JsonSink(backend="claude-agent-sdk") if is_json_mode(output) else None
    if json_sink is None:
        print_banner("AgentFlow CAS", "Run Claude Agent SDK agents from the command line")

    # ---- Tracing (opt-in via OTEL_TRACES_ENABLED=true) --------------------
    from agentflow.cas.telemetry import setup_tracing

    setup_tracing()

    # ---- Build runner -----------------------------------------------------
    try:
        from agentflow.cas.core.builder import CasAgentBuilder
    except ImportError:
        print_error(
            "claude-agent-sdk is required but not installed. "
            "Install with: pip install agentflow[claude-agent-sdk]"
        )
        raise SystemExit(1)

    builder = CasAgentBuilder.from_yaml(yaml_path)
    runner = builder.build()

    # ---- Persistence ------------------------------------------------------
    pm = _build_persistence(persistence, db_path, connection_string)
    tid = thread_id or str(uuid.uuid4())
    if json_sink is None:
        _print_run_header(yaml_path, persistence, tid)

    # If the user passed a thread id that already maps to an SDK session,
    # wire the SDK to resume it.
    if pm is not None:
        existing = pm.get_session_id(tid)
        if existing is not None:
            runner.options.resume = existing

    # ---- Interactive vs one-shot -----------------------------------------
    if interactive and json_sink is None:
        _run_interactive(runner, pm, tid)
    else:
        if not query:
            query = prompt_user("Query") if json_sink is None else ""
        if not query:
            return
        _run_one_shot(runner, query, pm, tid, json_sink=json_sink)


# ---------------------------------------------------------------------------
# Dry-run
# ---------------------------------------------------------------------------


def _run_dry(yaml_path: str, json_output: bool = False) -> None:
    try:
        from agentflow.cas.core.builder import CasAgentBuilder
    except ImportError:
        print_error(
            "claude-agent-sdk is required but not installed. "
            "Install with: pip install agentflow[claude-agent-sdk]"
        )
        raise SystemExit(1)

    # Let exceptions propagate to ``wrap_cli_main`` for friendly formatting.
    builder = CasAgentBuilder.from_yaml(yaml_path)
    summary = builder.dry_run()

    if json_output:
        print(json.dumps(summary, indent=2, default=str))
        return

    print_banner("AgentFlow CAS", "Run Claude Agent SDK agents from the command line")
    llm_summary = summary.get("llm") or {}
    sdk_opts = llm_summary.get("sdk_options") or {}
    agent_summary = summary["agent"]

    rows = [
        ("Backend", "claude-agent-sdk"),
        ("Config", yaml_path),
        ("Name", summary["metadata"].get("name") or "-"),
        ("Provider", llm_summary.get("provider") or "-"),
        ("Model", sdk_opts.get("model") or "-"),
        ("Agent", agent_summary["name"]),
        ("Tools", agent_summary["tools"]),
        ("Permission mode", agent_summary["permission_mode"]),
    ]
    if agent_summary.get("skills"):
        rows.append(("Skills", str(agent_summary["skills"])))
    if agent_summary.get("sandbox_enabled") is not None:
        rows.append(("Sandbox", "enabled" if agent_summary["sandbox_enabled"] else "disabled"))
    if summary["subagents"]:
        rows.append(("Subagents", ", ".join(summary["subagents"])))
    if summary["guards"]:
        rows.append(("Guards", ", ".join(summary["guards"])))
    if summary["optimizers"]:
        rows.append(("Optimizers", ", ".join(summary["optimizers"])))
    if summary["observers"]:
        rows.append(("Observers", ", ".join(summary["observers"])))
    if summary["mcp_servers"]:
        rows.append(("MCP servers", ", ".join(summary["mcp_servers"])))
    if agent_summary["hook_count"]:
        rows.append(("Hooks", str(agent_summary["hook_count"])))
    if agent_summary["plugin_count"]:
        rows.append(("Plugins", str(agent_summary["plugin_count"])))

    print_config_table(rows)
    console.print("[bold green]Config is valid.[/bold green]")


# ---------------------------------------------------------------------------
# One-shot + interactive
# ---------------------------------------------------------------------------


def _run_one_shot(
    runner: Any,
    query: str,
    pm: Optional[Any],
    thread_id: str,
    json_sink: Optional[JsonSink] = None,
) -> None:
    if json_sink is None:
        console.print()
    timer = ExecutionTimer()
    timer.start()
    # Streaming renderer prints progress inline — don't duplicate with a
    # final panel. Let exceptions propagate to ``wrap_cli_main`` for
    # friendly formatting.
    asyncio.run(_drive_query(runner, query, pm, thread_id, json_sink=json_sink))
    if json_sink is not None:
        json_sink.emit(EVENT_STATS, elapsed_s=timer.elapsed())
        json_sink.emit(EVENT_COMPLETE)
    else:
        print_execution_summary(console, timer.elapsed())


def _run_interactive(runner: Any, pm: Optional[Any], thread_id: str) -> None:
    init_history()
    repl_state = ReplState(thread_id=thread_id)
    console.print(
        "[bold]Interactive mode[/bold] — type [bold]/help[/bold] for commands, "
        "[bold]/quit[/bold] to exit\n"
    )
    while True:
        try:
            q = prompt_user("Query")
            if is_quit_alias(q):
                console.print("\nGoodbye.")
                break
            if not q.strip():
                continue
            if is_slash_command(q):
                if dispatch_slash_command(q, repl_state, console) == "quit":
                    console.print("\nGoodbye.")
                    break
                continue

            console.print()
            timer = ExecutionTimer()
            timer.start()
            asyncio.run(_drive_query(runner, q, pm, thread_id))
            print_execution_summary(console, timer.elapsed())
        except (KeyboardInterrupt, EOFError):
            console.print("\nGoodbye.")
            break
        except Exception as e:
            from agentflow.cli.errors import friendly_error
            print_error(friendly_error(e))
    cleanup_terminal_state()


# ---------------------------------------------------------------------------
# SDK invocation — streams messages, captures the resolved SDK session id,
# binds it to the agentflow thread_id so the next run can resume.
# ---------------------------------------------------------------------------


async def _drive_query(
    runner: Any,
    query_text: str,
    pm: Optional[Any],
    thread_id: str,
    json_sink: Optional[JsonSink] = None,
) -> str:
    """Run a query against the SDK, streaming progress and updating persistence.

    Wraps the whole invocation in an ``agentflow.cas.run`` span so per-tool
    spans from observers nest under one trace root. When ``json_sink`` is
    provided, each SDK message is forwarded to the sink as ndjson events
    (terminal renderer suppressed); otherwise messages route to the
    Rich-rendered terminal renderer.
    """
    from opentelemetry import trace

    tracer = trace.get_tracer("agentflow.cas")
    response_chars = 0
    sdk_session_id: Optional[str] = None
    renderer = _StreamRenderer(console) if json_sink is None else None
    # When emitting JSON, track tool_use_id → name so result events can be
    # labelled (the SDK only carries the id on the result side).
    tool_name_by_id: dict[str, str] = {}

    with tracer.start_as_current_span(
        "agentflow.cas.run",
        attributes={
            "agentflow.backend": "claude-agent-sdk",
            "agentflow.thread_id": thread_id,
            "agentflow.query_length": len(query_text),
            "gen_ai.request.model": getattr(runner.options, "model", None) or "",
        },
    ) as root_span:
        async for message in runner.query(query_text):
            session = getattr(message, "session_id", None) or _extract_session_id(message)
            if session:
                sdk_session_id = session

            if json_sink is not None:
                response_chars += _emit_cas_message(json_sink, message, tool_name_by_id)
            else:
                response_chars += renderer.render(message)

            _maybe_emit_session_summary(message, tracer, root_span)

        if renderer is not None:
            renderer.flush()

        if pm is not None and sdk_session_id is not None:
            pm.put_session_id(thread_id, sdk_session_id)
            pm.bump_turns(thread_id)

        if sdk_session_id:
            root_span.set_attribute("agentflow.sdk_session_id", sdk_session_id)
        root_span.set_attribute("agentflow.response_length", response_chars)

    return ""  # already streamed to console; caller skips panel render


# ---------------------------------------------------------------------------
# Stream renderer — shows tool calls, subagent progress, thinking, text
# ---------------------------------------------------------------------------


class _StreamRenderer:
    """Turns SDK messages into human-readable terminal output as they arrive.

    Design choices:
    - Tool calls print ``▸ ToolName(short-arg-summary)`` immediately so the
      user sees *something* in the first few seconds.
    - Subagent lifecycle (``TaskStartedMessage`` / ``TaskNotificationMessage``)
      prints ``▶ [subagent] description`` / ``✓ [subagent] status``.
    - The agent's final textual answer streams inline.
    - Thinking blocks are collapsed to ``  · thinking…`` to avoid flooding.
    - ``parent_tool_use_id`` drives indentation so subagent output nests.
    """

    _MAX_ARG_CHARS = 110
    _TOOL_INDENT_PREFIX = "  "

    def __init__(self, output):
        self._out = output
        # True while we're mid-stream on a text response block; controls
        # whether we need to emit a newline before switching to a tool call.
        self._streaming_text = False
        # Tracks parent_tool_use_id → indent level so subagent output indents.
        self._in_subagent = False
        # tool_use_id → tool name. Captured when ToolUseBlock is rendered so
        # we can label the matching ToolResultBlock by name (the SDK only
        # carries the id on the result side).
        self._tool_name_by_use_id: dict[str, str] = {}

    def render(self, message: Any) -> int:
        """Render a single SDK message. Returns any new response-text chars."""
        chars = 0
        try:
            cls_name = type(message).__name__
            if cls_name == "AssistantMessage":
                chars += self._render_assistant(message)
            elif cls_name == "UserMessage":
                self._render_user_tool_results(message)
            elif cls_name == "TaskStartedMessage":
                self._end_text_stream()
                desc = getattr(message, "description", "") or "starting"
                self._out.print(
                    f"[bold cyan]▶[/bold cyan] subagent · {desc}",
                    highlight=False,
                )
                self._in_subagent = True
            elif cls_name == "TaskProgressMessage":
                last = getattr(message, "last_tool_name", None)
                if last:
                    self._out.print(
                        f"  [dim]· {last}[/dim]", highlight=False
                    )
            elif cls_name == "TaskNotificationMessage":
                self._end_text_stream()
                status = getattr(message, "status", "completed")
                summary = getattr(message, "summary", "") or ""
                colour = (
                    "green" if status == "completed"
                    else "yellow" if status == "stopped"
                    else "red"
                )
                # Truncate the summary so it fits
                if len(summary) > 140:
                    summary = summary[:140].rstrip() + "…"
                label = {
                    "completed": "✓",
                    "stopped": "⏸",
                    "failed": "✗",
                }.get(status, "•")
                self._out.print(
                    f"[bold {colour}]{label}[/bold {colour}] subagent · {status}"
                    + (f": {summary}" if summary else ""),
                    highlight=False,
                )
                self._in_subagent = False
            elif cls_name == "RateLimitEvent":
                self._end_text_stream()
                self._out.print("[yellow]⚠ rate limit reached — backing off[/yellow]")
            # SystemMessage, StreamEvent, ResultMessage are skipped in the
            # renderer — session_summary emits its own trace span, and
            # SystemMessage carries only internal session metadata.
        except Exception as e:  # pragma: no cover
            # Never let the renderer break the agent.
            self._out.print(f"[dim red](renderer error: {e})[/dim red]")
        return chars

    def flush(self) -> None:
        """Ensure we end on a newline after any trailing streamed text."""
        self._end_text_stream()

    # --- internals --------------------------------------------------------

    def _render_assistant(self, message: Any) -> int:
        """An AssistantMessage is a list of blocks: text, thinking, tool_use, …"""
        chars = 0
        items = getattr(message, "content", []) or []

        # If this AssistantMessage is from a subagent (has parent_tool_use_id),
        # indent its tool-use lines. Text from subagents we suppress —
        # TaskNotificationMessage gives us the summary instead.
        parent_tool = getattr(message, "parent_tool_use_id", None)
        from_subagent = parent_tool is not None

        for item in items:
            block_name = type(item).__name__
            if block_name == "TextBlock":
                if from_subagent:
                    # Subagent chatter — the TaskNotificationMessage carries
                    # the useful summary. Skip verbose inline text.
                    continue
                text = getattr(item, "text", "") or ""
                if text:
                    if not self._streaming_text:
                        self._out.print()  # blank line before final answer
                        self._streaming_text = True
                    self._out.print(
                        text, end="", highlight=False, markup=False
                    )
                    chars += len(text)
            elif block_name == "ThinkingBlock":
                self._end_text_stream()
                prefix = self._TOOL_INDENT_PREFIX if from_subagent else ""
                self._out.print(f"{prefix}[dim italic]· thinking…[/dim italic]")
            elif block_name == "ToolUseBlock":
                self._end_text_stream()
                self._render_tool_use(item, from_subagent=from_subagent)
            elif block_name == "ToolResultBlock":
                # Rare — usually ToolResultBlocks arrive on UserMessage.
                pass
        return chars

    def _render_tool_use(self, block: Any, from_subagent: bool) -> None:
        name = getattr(block, "name", "?")
        inp = getattr(block, "input", {}) or {}
        short = self._short_args(name, inp)
        prefix = self._TOOL_INDENT_PREFIX if (from_subagent or self._in_subagent) else ""
        # Remember the name so we can label the matching ToolResultBlock.
        use_id = getattr(block, "id", None) or getattr(block, "tool_use_id", None)
        if use_id:
            self._tool_name_by_use_id[use_id] = name
        # The Task tool delegation is visually distinct — it's the orchestrator
        # handing work off, not a plain tool call.
        if name == "Task":
            sub = inp.get("subagent_type", "?")
            desc = inp.get("description", "") or inp.get("prompt", "")
            if len(desc) > 90:
                desc = desc[:90].rstrip() + "…"
            self._out.print(
                f"{prefix}[bold blue]↳[/bold blue] delegate to "
                f"[bold]{sub}[/bold] · {desc}",
                highlight=False,
            )
        else:
            self._out.print(
                f"{prefix}[cyan]▸[/cyan] {name}({short})", highlight=False
            )

    def _short_args(self, tool_name: str, inp: dict) -> str:
        """One-line argument summary, truncated to fit."""
        if not inp:
            return ""
        # Prefer a handful of key fields over a dump
        key_hints = {
            "Bash": ["command"],
            "Read": ["file_path"],
            "Write": ["file_path"],
            "Edit": ["file_path"],
            "Glob": ["pattern"],
            "Grep": ["pattern"],
            "WebFetch": ["url"],
            "WebSearch": ["query"],
        }
        preferred = key_hints.get(tool_name, [])
        pairs = []
        shown_keys = set()
        for k in preferred:
            if k in inp:
                pairs.append(f"{k}={inp[k]!r}")
                shown_keys.add(k)
                break  # one preferred key is usually enough
        if not pairs:
            for k, v in inp.items():
                pairs.append(f"{k}={v!r}")
                if len(", ".join(pairs)) > self._MAX_ARG_CHARS:
                    break
        joined = ", ".join(pairs)
        if len(joined) > self._MAX_ARG_CHARS:
            joined = joined[: self._MAX_ARG_CHARS - 1] + "…"
        return joined

    def _render_user_tool_results(self, message: Any) -> None:
        """UserMessage content can include ToolResultBlocks — show the
        ``← name result · N chars`` marker, optionally with a preview or a
        pretty-printed JSON body when the result is small + structured.

        Matches the maf/oai/workflows pattern so output reads the same
        across backends.
        """
        content = getattr(message, "content", None)
        if not isinstance(content, list):
            return
        parent_tool = getattr(message, "parent_tool_use_id", None)
        for item in content:
            if type(item).__name__ != "ToolResultBlock":
                continue
            raw = getattr(item, "content", None)
            is_error = getattr(item, "is_error", False)
            use_id = (
                getattr(item, "tool_use_id", None) or getattr(item, "id", None)
            )
            tool_name = self._tool_name_by_use_id.get(use_id, "tool") if use_id else "tool"

            indent = self._TOOL_INDENT_PREFIX if parent_tool else ""

            # Errors keep the existing red ✗ one-liner — preview body adds noise.
            if is_error:
                length = result_length(raw) if not isinstance(raw, list) else sum(
                    len(str(x)) for x in raw
                )
                self._out.print(
                    f"{indent}  [red]✗[/red] [dim]{tool_name} error · {length} chars[/dim]",
                    highlight=False,
                )
                continue

            # Some SDK builds give us a list-of-blocks for the result; coerce
            # to the structured value the helpers expect.
            payload = self._coerce_result_payload(raw)
            length = result_length(payload)
            body = pretty_json_block(payload, max_chars=2000, max_lines=24)
            header = (
                f"{indent}  [dim]← {tool_name} result · {length} chars[/dim]"
            )
            if body is None:
                preview = result_preview(payload, limit=240)
                if preview:
                    header = f"{header} [dim]·[/dim] {preview}"
                self._out.print(header, highlight=False)
                continue
            self._out.print(header, highlight=False)
            block_indent = indent + "    "
            indented = "\n".join(block_indent + line for line in body.splitlines())
            self._out.print(f"[dim]{indented}[/dim]", highlight=False)

    @staticmethod
    def _coerce_result_payload(raw: Any) -> Any:
        """Extract a JSON-friendly value from a ToolResultBlock.content.

        The SDK uses one of:
        - ``str`` — return as-is
        - ``list[TextBlock | ImageBlock | …]`` — concatenate the ``.text``
          fields (image/non-text blocks are dropped from the preview)
        """
        if raw is None:
            return None
        if isinstance(raw, str):
            return raw
        if isinstance(raw, list):
            parts: list[str] = []
            for x in raw:
                text = getattr(x, "text", None)
                if isinstance(text, str):
                    parts.append(text)
                elif isinstance(x, str):
                    parts.append(x)
            return "".join(parts) if parts else raw
        return raw

    def _end_text_stream(self) -> None:
        if self._streaming_text:
            self._out.print()  # terminate the current streamed line
            self._streaming_text = False


def _emit_cas_message(
        sink: JsonSink,
        message: Any,
        tool_name_by_id: dict,
) -> int:
    """Translate one SDK message into ndjson events. Returns response char count.

    Mirrors the dispatch in :class:`_StreamRenderer` — text blocks
    become ``token`` events, ``ToolUseBlock`` becomes ``tool_call``,
    ``ToolResultBlock`` (carried on UserMessages) becomes ``tool``,
    ``ThinkingBlock`` becomes a single ``reasoning`` event. Subagent
    lifecycle (``TaskStartedMessage`` / ``TaskNotificationMessage``)
    surfaces as ``tool_call`` / ``tool`` events with ``kind=subagent``
    so consumers can distinguish them.
    """
    chars = 0
    cls = type(message).__name__
    if cls == "AssistantMessage":
        items = getattr(message, "content", []) or []
        parent_tool = getattr(message, "parent_tool_use_id", None)
        for item in items:
            block_name = type(item).__name__
            if block_name == "TextBlock":
                if parent_tool is not None:
                    continue  # subagent chatter — TaskNotification carries summary
                text = getattr(item, "text", "") or ""
                if text:
                    sink.emit(EVENT_TOKEN, content=text)
                    chars += len(text)
            elif block_name == "ThinkingBlock":
                sink.emit(EVENT_REASONING)
            elif block_name == "ToolUseBlock":
                name = getattr(item, "name", "<tool>")
                use_id = getattr(item, "id", None)
                if use_id:
                    tool_name_by_id[use_id] = name
                sink.emit(
                    EVENT_TOOL_CALL,
                    name=name,
                    args=getattr(item, "input", None),
                    call_id=use_id,
                )
    elif cls == "UserMessage":
        content = getattr(message, "content", None)
        if isinstance(content, list):
            for item in content:
                if type(item).__name__ != "ToolResultBlock":
                    continue
                use_id = (
                    getattr(item, "tool_use_id", None) or getattr(item, "id", None)
                )
                name = tool_name_by_id.get(use_id, "tool") if use_id else "tool"
                sink.emit(
                    EVENT_TOOL,
                    name=name,
                    content=getattr(item, "content", None),
                    is_error=bool(getattr(item, "is_error", False)),
                    call_id=use_id,
                )
    elif cls == "TaskStartedMessage":
        sink.emit(
            EVENT_TOOL_CALL,
            name="subagent",
            kind="subagent_start",
            description=getattr(message, "description", None),
        )
    elif cls == "TaskNotificationMessage":
        sink.emit(
            EVENT_TOOL,
            name="subagent",
            kind="subagent_end",
            status=getattr(message, "status", "completed"),
            content=getattr(message, "summary", None),
        )
    elif cls == "RateLimitEvent":
        sink.emit(EVENT_ERROR, message="rate limit reached")
    return chars


def _maybe_emit_session_summary(message: Any, tracer: Any, root_span: Any) -> None:
    """If ``message`` is a ``ResultMessage``, emit the session-summary span
    with usage/cost attributes and also attach those attrs to the root span."""
    try:
        from claude_agent_sdk import ResultMessage
    except ImportError:
        return
    if not isinstance(message, ResultMessage):
        return

    attrs: dict = {"gen_ai.operation.name": "session_summary"}

    duration_ms = getattr(message, "duration_ms", None)
    duration_api_ms = getattr(message, "duration_api_ms", None)
    num_turns = getattr(message, "num_turns", None)
    total_cost = getattr(message, "total_cost_usd", None)
    usage = getattr(message, "usage", None) or {}
    model_usage = getattr(message, "model_usage", None) or {}
    stop_reason = getattr(message, "stop_reason", None)
    is_error = getattr(message, "is_error", None)

    if duration_ms is not None:
        attrs["gen_ai.session.duration_ms"] = duration_ms
        root_span.set_attribute("gen_ai.session.duration_ms", duration_ms)
    if duration_api_ms is not None:
        attrs["gen_ai.session.duration_api_ms"] = duration_api_ms
    if num_turns is not None:
        attrs["gen_ai.session.num_turns"] = num_turns
        root_span.set_attribute("gen_ai.session.num_turns", num_turns)
    if total_cost is not None:
        attrs["gen_ai.usage.total_cost_usd"] = total_cost
        root_span.set_attribute("gen_ai.usage.total_cost_usd", total_cost)
    if stop_reason is not None:
        attrs["gen_ai.session.stop_reason"] = stop_reason
    if is_error is not None:
        attrs["gen_ai.session.is_error"] = is_error

    for key in (
        "input_tokens",
        "output_tokens",
        "cache_creation_input_tokens",
        "cache_read_input_tokens",
    ):
        value = usage.get(key) if isinstance(usage, dict) else None
        if value is not None:
            attrs[f"gen_ai.usage.{key}"] = value
            root_span.set_attribute(f"gen_ai.usage.{key}", value)

    # Per-model rollup (dict of model_id → usage dict)
    if isinstance(model_usage, dict):
        for model_id, u in model_usage.items():
            if not isinstance(u, dict):
                continue
            for k, v in u.items():
                if isinstance(v, (int, float, str, bool)):
                    attrs[f"gen_ai.model_usage.{model_id}.{k}"] = v

    with tracer.start_as_current_span("gen_ai.session_summary", attributes=attrs):
        pass


def _extract_session_id(message: Any) -> Optional[str]:
    """Best-effort extraction of an SDK session id from a streamed message."""
    for attr in ("session_id", "sessionId"):
        value = getattr(message, attr, None)
        if value:
            return str(value)
    data = getattr(message, "data", None) or getattr(message, "content", None)
    if isinstance(data, dict):
        for key in ("session_id", "sessionId"):
            value = data.get(key)
            if value:
                return str(value)
    return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_persistence(
    backend: str,
    db_path: Optional[str],
    connection_string: Optional[str],
) -> Optional[Any]:
    try:
        from agentflow.cas.core.persistence import create_persistence_manager
    except ImportError:
        return None
    return create_persistence_manager(
        backend=backend,
        db_path=db_path,
        connection_string=connection_string,
    )


def _print_run_header(yaml_path: str, persistence: str, thread_id: str) -> None:
    print_info(f"Config: {yaml_path}")
    print_info(f"Persistence: {persistence}")
    print_info(f"Thread: {thread_id}")
    console.print()
