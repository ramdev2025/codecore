"""CAS adapter for the cross-backend ``ui_tools`` vocabulary.

The Claude Agent SDK exposes custom Python tools through **in-process
MCP servers**. Each tool is an ``SdkMcpTool`` produced by the
``@tool(name, description, input_schema)`` decorator; tools are bundled
via ``create_sdk_mcp_server(name, tools=[...])`` into a server config
that goes into ``ClaudeAgentOptions.mcp_servers``.

For genui, each ``@ui_component`` fetcher becomes one ``SdkMcpTool``:
the wrapper validates the return against the Pydantic class and emits
the MCP content shape ``{"content": [{"type": "text", "text": <json>}]}``.

This module returns the **list of SdkMcpTool instances** (not yet
bundled into a server). The cas builder is responsible for filtering
the list via ``agentflow.genui.filter_by_availability``, then calling
``create_sdk_mcp_server`` once with the survivors. Building the server
*after* filtering avoids the impossibility of attaching metadata to
the opaque MCP server config that the filter would need to introspect.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel

from agentflow.genui import (
    UIToolsConfig,
    discover_ui_components,
    get_component_class,
)

logger = logging.getLogger(__name__)


_JSON_SCHEMA_TYPE_MAP: dict[type, Any] = {
    str: str,
    int: int,
    float: float,
    bool: bool,
}


def resolve_ui_tools(config: UIToolsConfig | None) -> list[Any]:
    """Build a list of ``SdkMcpTool`` instances from a ``UIToolsConfig``.

    Returns an empty list when ``config`` is ``None`` so callers can
    unconditionally extend their list of cas tools-pending-bundling.

    Args:
        config: The parsed ``ui_tools:`` YAML block.

    Returns:
        List of ``SdkMcpTool`` objects ready for filtering and then
        bundling via ``create_sdk_mcp_server(...)``. Each carries a
        ``_agentflow_component_name`` attribute for the availability
        filter.

    Raises:
        ImportError: If ``claude-agent-sdk`` is not installed.
        ValueError: If ``config.use`` names an unknown component.
    """
    if config is None:
        return []

    try:
        from claude_agent_sdk import tool  # noqa: F401  (verifies install)
    except ImportError as exc:  # pragma: no cover — covered by import-error test
        raise ImportError(
            "claude-agent-sdk is required to resolve ui_tools on the CAS backend. "
            "Install via `pip install agentflow[claude-agent-sdk]`."
        ) from exc

    discovered = discover_ui_components(config.module)
    if config.use is not None:
        missing = sorted(set(config.use) - set(discovered.keys()))
        if missing:
            available = sorted(discovered.keys())
            raise ValueError(
                f"ui_tools.use names component(s) not found in "
                f"{config.module!r}: {missing}. Available: {available}"
            )
        discovered = {n: discovered[n] for n in config.use}

    return [_wrap_for_cas(name, fetcher) for name, fetcher in discovered.items()]


def _wrap_for_cas(component_name: str, fetcher: Callable[..., Any]) -> Any:
    """Wrap a ``@ui_component`` fetcher as a cas ``SdkMcpTool``.

    The CAS ``@tool`` decorator requires ``input_schema`` upfront,
    not introspected from the function signature. We derive it from
    the fetcher's annotations.
    """
    component_cls = get_component_class(fetcher)
    if component_cls is None:  # pragma: no cover — discover_ui_components guards
        raise RuntimeError(f"{fetcher} is not @ui_component-decorated")

    from claude_agent_sdk import tool as cas_tool

    description = (fetcher.__doc__ or f"Render the {component_name} component.").strip()
    tool_name = fetcher.__name__
    input_schema = _input_schema_from_signature(fetcher)

    is_async = asyncio.iscoroutinefunction(fetcher)

    if is_async:

        @cas_tool(tool_name, description, input_schema)
        async def async_handler(args: dict[str, Any]) -> dict[str, Any]:
            result = await fetcher(**args)
            return _to_mcp_content(component_name, component_cls, result)

        async_handler._agentflow_component_name = component_name  # type: ignore[attr-defined]
        return async_handler

    @cas_tool(tool_name, description, input_schema)
    async def sync_handler(args: dict[str, Any]) -> dict[str, Any]:
        # CAS handlers are always async; wrap the sync fetcher.
        result = fetcher(**args)
        return _to_mcp_content(component_name, component_cls, result)

    sync_handler._agentflow_component_name = component_name  # type: ignore[attr-defined]
    return sync_handler


def _input_schema_from_signature(fetcher: Callable[..., Any]) -> dict[str, Any]:
    """Derive a CAS-compatible input_schema dict from a fetcher's signature.

    CAS accepts either a JSON Schema object or a simpler ``{name: type}``
    dict where types are Python builtins (``str``, ``int``, ``float``,
    ``bool``). We use the simpler form — every reasonable fetcher param
    type maps cleanly. Fetchers with no parameters get ``{}`` (CAS
    accepts that as "no args").
    """
    sig = inspect.signature(fetcher)
    schema: dict[str, Any] = {}
    for name, param in sig.parameters.items():
        annotation = param.annotation
        py_type = _JSON_SCHEMA_TYPE_MAP.get(annotation, str)
        schema[name] = py_type
    return schema


def _to_mcp_content(
    component_name: str,
    component_cls: type[BaseModel],
    result: Any,
) -> dict[str, Any]:
    """Wrap a fetcher's return in the MCP tool-result content shape.

    MCP tools return ``{"content": [{"type": "text", "text": <str>}]}``.
    On validation error we still return a content block — an
    ``[Name failed] ...`` string the LLM can read and react to. Same
    lenient policy as the other backends' wrappers.
    """
    if isinstance(result, component_cls):
        instance = result
        text_payload: dict[str, Any] = {
            "__component__": component_name,
            **instance.model_dump(),
        }
        text = json.dumps(text_payload)
    elif isinstance(result, dict):
        try:
            instance = component_cls.model_validate(result)
            text_payload = {"__component__": component_name, **instance.model_dump()}
            text = json.dumps(text_payload)
        except Exception as exc:
            text = f"[{component_name} failed] dict didn't validate: {exc}"
    else:
        text = (
            f"[{component_name} failed] fetcher must return a {component_name} "
            f"instance or a dict, got {type(result).__name__}"
        )

    return {"content": [{"type": "text", "text": text}]}
