# Full Example

An annotated YAML exercising every v1 feature: main agent with subagents, custom Python plugins, 5 hook events, the full cross-backend tier, sandbox with network policy, structured output, MCP servers on all three transports.

**Scenario:** a code-review assistant for a fintech team. PII-redacted, sandboxed-bash, 25 USD budget, $0 network access outside the allow-list.

## The YAML

```yaml
# ==========================================================================
# Enterprise CAS config — exercises every v1 feature.
#
# Scenario: code-review assistant for a fintech team.
#   - Reads diffs and queries an internal security API over MCP
#   - Delegates deep research to a `researcher` subagent
#   - Delegates style enforcement to a `reviewer` subagent
#   - Hard budget of $25/session, max 40 turns
#   - PII redaction on user prompts before they hit the model
#   - Sandboxed bash with an allowlist of hosts
#   - OpenTelemetry traces + audit log
#
# Placeholders to replace:
#   - ${ANTHROPIC_API_KEY}, ${REVIEWER_USER_ID}, ${SECURITY_DB_TOKEN},
#     ${GITHUB_MCP_TOKEN}
#   - `myapp.review_tools`, `myapp.hooks`, `myapp.permissions`,
#     `myapp.filters` — swap for modules that exist in your project
# ==========================================================================

backend: claude-agent-sdk

metadata:
  version: "1.0"
  name: code-review-assistant
  description: Reviews PRs and flags security issues
  author: platform-team
  tags: [code-review, security, fintech]

# --- LLM — model selection + inference + cost controls -------------------
llm:
  provider: anthropic
  config:
    model: claude-opus-4-7
    fallback_model: claude-sonnet-4-6          # used on transient failures
    api_key: ${ANTHROPIC_API_KEY}              # bridged to env var by builder

    max_budget_usd: 25.00                      # hard stop when exceeded
    max_turns: 40                              # iteration cap

    thinking: { type: adaptive }               # alternatives: enabled / disabled
    effort: high                               # low | medium | high | max
    max_thinking_tokens: 16000

    include_partial_messages: true             # on by default in the CLI
    betas:
      - context-1m-2025-08-07                  # 1M context window opt-in

# --- Main agent ----------------------------------------------------------
agent:
  name: reviewer_main
  description: Coordinates PR review across specialist subagents
  system_prompt: |
    You are the lead code reviewer. For each PR:
    1. Read the diff with Read/Glob/Grep.
    2. Delegate security analysis to the `researcher` subagent.
    3. Delegate style checks to the `reviewer` subagent.
    4. Post consolidated feedback via the `github` MCP server.

  # Filesystem scoping
  cwd: ./workspace
  add_dirs:
    - ./references                             # read-only reference docs
    - /var/cache/sec-advisories                # shared security DB

  # Tools — preset form (hand SDK its Claude Code bundle)
  tools:
    preset: claude_code
  # Alternative opt-out form:
  # tools:
  #   builtin: [bash, read, write, edit, glob, grep, web_fetch, web_search, task]
  #   disabled: [web_fetch]

  # Custom Python tools — in-process MCP SDK servers
  plugins:
    - name: fintech_tools
      type: python
      module: myapp.review_tools
      # Optionally restrict:
      # functions: [lookup_ticker, flag_pii]

  # Permissions
  permissions:
    mode: auto                                 # default | acceptEdits | plan | dontAsk | bypassPermissions | auto
    allowed_tools: [Bash, Read, Grep, Glob]    # capitalized SDK names
    disallowed_tools: [WebFetch]
    prompt_tool_name: approve_sensitive_op     # MCP tool for human approval
    can_use_tool:                              # custom async handler
      module: myapp.permissions
      function: authorize

  # Hooks — 5 of the 10 SDK event types in use here
  hooks:
    - event: PreToolUse                        # gate every bash call
      matcher: "^Bash$"
      module: myapp.hooks
      function: check_bash_safety
      timeout: 5

    - event: PreToolUse                        # screen file writes
      matcher: "^(Write|Edit)$"
      module: myapp.hooks
      function: check_file_write
      timeout: 5

    - event: UserPromptSubmit                  # redact PII before the model
      module: myapp.hooks
      function: redact_pii
      timeout: 10

    - event: PreCompact                        # snapshot context before compression
      module: myapp.hooks
      function: snapshot_context
      timeout: 30

    - event: PostToolUseFailure                # escalate repeated failures
      module: myapp.hooks
      function: notify_oncall
      timeout: 5

  # Skills — load everything the workspace has
  skills: all
  # skills: [sql-review, security-advisor, diff-summarizer]

  # Settings precedence
  setting_sources: [user, project, local]

  # Sandbox — SDK-native sandboxing
  sandbox:
    enabled: true
    auto_allow_bash_if_sandboxed: true
    excluded_commands: [sudo, curl, wget]
    allow_unsandboxed_commands: false
    enable_weaker_nested_sandbox: false
    network:
      allow:
        - github.com
        - api.internal.corp
        - nvd.nist.gov
      deny: ["*"]                              # default-deny

  # Multi-tenant attribution — surfaces in traces and billing
  user: ${REVIEWER_USER_ID}                    # e.g. "alice@corp"

  # Structured output
  output_format:
    config:
      type: json_schema
      schema:
        type: object
        properties:
          severity: { type: string, enum: [low, medium, high, critical] }
          findings: { type: array, items: { type: object } }
        required: [severity, findings]

# --- Subagents — callable by name from the main agent --------------------
subagents:
  researcher:
    description: Investigates security implications of code changes
    prompt: |
      You research security advisories and historical incidents before the
      main agent recommends changes. Always cite sources.
    tools: [bash, read, glob, grep, web_search]
    disallowed_tools: [write, edit]            # read-only by policy
    model: claude-sonnet-4-6                   # cheaper model for research
    effort: medium
    max_turns: 20
    memory: project                            # project-scoped memory
    skills: [sql-review, security-advisor]
    permission_mode: default
    mcp_servers: [security_db]                 # reference to mcp_servers key
    initial_prompt: "Start by running `git log --oneline -20`."

  reviewer:
    description: Enforces team style guide on code changes
    prompt: You check code against the team style guide. Be concise.
    tools: [read, glob, grep]
    model: claude-sonnet-4-6
    effort: low
    max_turns: 10
    permission_mode: plan                      # plan-only, never executes
    background: true                           # may run in parallel

# --- Cross-backend tier 1 — portable across all backends ------------------
guards:
  - type: tool_call_limit
    config: { max_calls: 100 }
  - type: pii
    config: { patterns: [email, phone, ssn, credit_card] }
  - type: content_filter
    module: myapp.filters
    function: block_secrets

optimizers:
  - type: tool_retry
    config: { max_retries: 2, initial_backoff_ms: 500 }
  - type: summarization
    config: { trigger_messages: 40, keep_messages: 10 }

observers:
  - type: audit_log
  - type: cost_tracking
  - type: latency_tracking

# --- MCP servers — all three transports -----------------------------------
mcp_servers:
  filesystem:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./workspace"]
    env:
      LOG_LEVEL: info

  security_db:
    transport: http
    url: https://api.internal.corp/mcp
    headers:
      Authorization: "Bearer ${SECURITY_DB_TOKEN}"
      X-Request-Source: agentflow

  github:
    transport: sse
    url: https://mcp.github.corp/sse
    headers:
      Authorization: "Bearer ${GITHUB_MCP_TOKEN}"
```

## What this exercises

- **LLM:** model + fallback, budget (hard stop), turns, thinking (adaptive), effort, thinking token budget, partial-message streaming, beta opt-in, env-bridged api_key
- **Agent body:** cwd, add_dirs, tool preset, custom Python plugins, 5 permission fields including `can_use_tool`, 5 hooks covering 4 event types, skills (`"all"`), 3 setting sources, full sandbox with network allow/deny, multi-tenant `user`, JSON-schema output format
- **Subagents:** 2 with different models, efforts, memory scopes, permission modes, MCP references, `initial_prompt`, and the `background` flag
- **Cross-backend:** 3 guards (two built-in + one custom), 2 optimizers, 3 observers
- **MCP:** all three transports (stdio, sse, http) + env-bridged auth headers

## Running it

```bash
# Validate
agentflow --yaml cas_agent.yaml --dry-run

# Run
agentflow --yaml cas_agent.yaml "Review PR #1234 for security and style issues"

# Trace
OTEL_TRACES_ENABLED=true OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317 \
  agentflow --yaml cas_agent.yaml "..."
```

## What gets deferred

Features that exist in the SDK but are deferred in v1 behind a future flag:

| Feature                        | Status                    | Planned v2 surface                      |
| ------------------------------ | ------------------------- | --------------------------------------- |
| Managed Agents API (remote)    | Research Preview          | top-level `managed: true`               |
| Bedrock / Vertex model routing | Via Managed Agents        | `llm.provider: bedrock` / `vertex`      |
| Memory stores (persistent)     | Research Preview          | top-level `memory:` block               |
| File checkpointing (CLI mode)  | Research Preview          | `llm.config.enable_file_checkpointing`  |
| Vault-stored MCP OAuth tokens  | Research Preview          | `mcp_servers[].auth.vault`              |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
