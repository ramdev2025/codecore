# YAML Reference

Full schema for a CAS (`backend: claude-agent-sdk`) config. Every field here is backed by a Pydantic model in `agentflow.cas.core.config_models`.

---

## Top level

```yaml
backend: claude-agent-sdk       # required literal
metadata: { ... }               # required
llm: { ... }                    # optional (overridden by agent.llm if both set)
agent: { ... }                  # required — the main agent (singular)
subagents: { ... }              # optional — callable specialist agents
guards: [ ... ]                 # optional cross-backend constraints
optimizers: [ ... ]             # optional efficiency improvements
observers: [ ... ]              # optional passive monitors
mcp_servers: { ... }            # optional MCP connections
```

At least one of `llm:` (top-level) or `agent.llm:` must be present.

---

## `metadata`

| Field         | Type     | Required | Notes                                |
| ------------- | -------- | -------- | ------------------------------------ |
| `version`     | str      | ✅       | Schema version (e.g. `"1.0"`)        |
| `name`        | str      |          | Human-readable config name           |
| `description` | str      |          |                                      |
| `author`      | str      |          |                                      |
| `tags`        | list[str] |         |                                      |

---

## `llm`

| Field       | Type                              | Notes                                            |
| ----------- | --------------------------------- | ------------------------------------------------ |
| `provider`  | `anthropic` \| `custom`           | v1 — Bedrock/Vertex gated by Managed Agents API |
| `config`    | dict                              | Flat passthrough to `ClaudeAgentOptions`         |

**Recognized `config` keys** (everything goes straight into the SDK options):

| Key                        | Type        | Description                                                        |
| -------------------------- | ----------- | ------------------------------------------------------------------ |
| `model`                    | str         | Primary model (e.g. `claude-opus-4-7`, `claude-sonnet-4-6`)        |
| `api_key`                  | str         | Bridged to `ANTHROPIC_API_KEY` env var before SDK invocation       |
| `fallback_model`           | str         | Model used on transient failures                                   |
| `max_budget_usd`           | float       | Hard stop — session terminates when exceeded                        |
| `max_turns`                | int         | Iteration cap per run                                              |
| `thinking`                 | dict        | `{type: enabled, budget_tokens: N}` / `{type: adaptive}` / `{type: disabled}` |
| `effort`                   | `low`…`max` | Thinking-effort preset                                             |
| `max_thinking_tokens`      | int         | Explicit thinking budget                                           |
| `include_partial_messages` | bool        | Token-level streaming (default: `true` in CLI)                     |
| `betas`                    | list[str]   | Opt into SDK beta features (e.g. `context-1m-2025-08-07`)          |

---

## `agent` (the main agent)

```yaml
agent:
  name: str                    # required
  description: str             # optional
  system_prompt: str           # required
  cwd: str                     # working directory
  add_dirs: [str, ...]         # extra allowed directories
  tools: { ... }               # see below
  plugins: [ ... ]             # custom Python tools
  permissions: { ... }         # see below
  hooks: [ ... ]               # see Hooks page
  skills: "all" | [str, ...]   # SDK skills to load
  setting_sources: [user, project, local]
  sandbox: { ... }             # SDK sandbox settings
  user: str                    # actor identity (multi-tenant attribution)
  output_format: { config: {...} }  # JSON-schema / structured output
  llm: { ... }                 # per-agent override
```

### `agent.tools`

Opt-out model: declare what's enabled, then exclude. OR use a preset.

```yaml
tools:
  preset: claude_code          # SDK preset — full Claude Code tool bundle
```

or

```yaml
tools:
  builtin: [bash, read, write, edit, glob, grep, web_fetch, web_search, task, todo_write, exit_plan_mode]
  disabled: [web_fetch]
```

`builtin` defaults to all 11 GA built-ins. `disabled` must be a subset of `builtin`. Use `task` to enable subagent delegation.

### `agent.plugins`

Custom tool modules (Python `@tool`-decorated functions registered as in-process MCP SDK servers).

```yaml
plugins:
  - name: my_tools             # becomes the MCP server name
    type: python               # v1 only supports python
    module: myapp.tools        # importable module path
    functions: [foo, bar]      # optional: restrict to named functions
```

### `agent.permissions`

```yaml
permissions:
  mode: default                # default | acceptEdits | plan | dontAsk | bypassPermissions | auto
  allowed_tools: [Bash, Read]  # whitelist; SDK-case names
  disallowed_tools: [WebFetch] # blacklist (applied after allowed_tools)
  prompt_tool_name: approve    # MCP tool used for interactive approval
  can_use_tool:                # custom async handler
    module: myapp.auth
    function: authorize
```

### `agent.hooks`

See [Hooks](HOOKS.md). Quick form:

```yaml
hooks:
  - event: PreToolUse          # one of 10 SDK events
    matcher: "^Bash$"          # regex; tool name for tool-scoped events
    module: myapp.hooks
    function: check_safety
    timeout: 5
```

### `agent.sandbox`

```yaml
sandbox:
  enabled: true
  auto_allow_bash_if_sandboxed: true
  excluded_commands: [sudo]
  allow_unsandboxed_commands: false
  enable_weaker_nested_sandbox: false
  network:
    allow: [github.com]
    deny: ["*"]
```

Snake_case here is translated to the SDK's camelCase (`excludedCommands`, etc.) in the builder.

### `agent.output_format`

Passthrough for the SDK's structured-output contract — shape depends on the SDK output type.

```yaml
output_format:
  config:
    type: json_schema
    schema:
      type: object
      properties: { ... }
      required: [ ... ]
```

---

## `subagents`

Dict of `name → AgentDefinition`-equivalent. The main agent delegates to them via the `task` tool.

```yaml
subagents:
  researcher:
    description: str           # required — shown to the router
    prompt: str                # required — subagent system prompt
    tools: [bash, read, grep]  # optional; same enum as main agent
    disallowed_tools: [write]
    model: claude-sonnet-4-6
    skills: [a, b]
    memory: user | project | local
    mcp_servers: [name, ...]   # reference top-level mcp_servers keys OR plugin names
    initial_prompt: str
    max_turns: 15
    background: false
    effort: low | medium | high | max | <int>
    permission_mode: default   # overrides the main agent's mode
```

Validator: subagent string references in `mcp_servers` must match a key in either the top-level `mcp_servers:` dict or the `agent.plugins[].name` list.

See [Subagents](SUBAGENTS.md) for the full pattern.

---

## `guards` / `optimizers` / `observers`

Cross-backend tier — portable across workflows / deep / sk / cas. In CAS they compile down to hooks.

```yaml
guards:
  - type: tool_call_limit
    config: { max_calls: 50 }
  - type: pii
    config: { patterns: [email, phone, ssn, credit_card] }
  - type: content_filter
    module: myapp.filters      # for custom types
    function: block_secrets

optimizers:
  - type: tool_retry
    config: { max_retries: 2, initial_backoff_ms: 500 }
  - type: summarization

observers:
  - type: audit_log
  - type: cost_tracking
  - type: latency_tracking
```

See [Guards / Optimizers / Observers](GUARDS.md) for the catalog and compilation rules.

---

## `mcp_servers`

Dict of `name → MCPServerEntry`. Three transports.

```yaml
mcp_servers:
  local-data:                  # stdio
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]
    env: { LOG_LEVEL: info }

  remote-sse:                  # SSE
    transport: sse
    url: https://example.com/mcp/sse
    headers: { Authorization: "Bearer ${TOKEN}" }

  http-api:                    # HTTP (JSON-RPC)
    transport: http
    url: https://api.example.com/mcp
    headers: { Authorization: "Bearer ${TOKEN}" }
```

See [MCP Integration](MCP.md).

---

## Environment variable substitution

Any string value can reference `${VAR}` — the builder resolves it at config-load time, raising a clear error if unset. Standard `.env` files in the working directory are auto-loaded before resolution.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
