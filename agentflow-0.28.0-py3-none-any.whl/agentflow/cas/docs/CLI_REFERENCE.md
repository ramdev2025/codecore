# CLI Reference

All CAS agents are driven by the unified `agentflow` command. The `backend: claude-agent-sdk` literal in your YAML routes to the CAS runner.

> **Cross-backend flags** — `--output ndjson`, `--debug`, `--verbose`, `--ascii`, REPL slash commands, the `agentflow-init` and `agentflow-threads` companion commands, and the JSON event schema are documented in `agentflow/cli/CLI_FLAGS.md` (in the source tree). This page covers CAS-specific behaviour only.

## Synopsis

```
agentflow [QUERY] [OPTIONS]
```

With no `QUERY` argument, the CLI prompts interactively. With `--interactive`, it loops until you type `quit`.

## Common flags

| Flag                             | Description                                                              |
| -------------------------------- | ------------------------------------------------------------------------ |
| `--yaml PATH`                    | Path to the YAML config (auto-detected if omitted)                       |
| `--backend claude-agent-sdk`     | Override auto-detection (needed only for YAMLs without `backend:` field) |
| `--dry-run`                      | Validate the config and print a summary; no LLM call                     |
| `--json`                         | When combined with `--dry-run`, emit the summary as JSON                 |
| `--interactive`                  | REPL loop (type `quit`, `exit`, or `q` to stop)                          |
| `--thread-id ID`                 | Resume a prior session (bridges to the SDK session UUID internally)      |
| `--persistence memory|sqlite|postgres` | Backend for the `thread_id → session_id` mapping (default: sqlite)  |
| `--db-path PATH`                 | SQLite file path (default: `.agentflow/cas_threads.db`)                  |
| `--connection-string URL`        | PostgreSQL DSN (or set `POSTGRES_CONNECTION_STRING`)                     |

Other-backend flags (`--workdir`, `--no-tui`, `--tools`, `--recursion-limit`) are accepted but ignored in CAS.

## Auto-detection

When `--yaml` is omitted, the CLI looks for these filenames in the current directory, first match wins:

```
workflow.yaml
agentflow.yaml
agent.yaml
deep.yaml
deep_agent.yaml
sk_agent.yaml
cas_agent.yaml
```

## Examples

### One-shot

```bash
agentflow --yaml cas_agent.yaml "Summarize the README"
```

### Interactive

```bash
agentflow --yaml cas_agent.yaml --interactive
```

### Validate without calling the API

```bash
agentflow --yaml cas_agent.yaml --dry-run
agentflow --yaml cas_agent.yaml --dry-run --json
```

`--dry-run` prints a compact table — backend, model, permission mode, subagent count, guards/observers, MCP servers, hook count, plugin count. With `--json`, the same summary is emitted as JSON for programmatic consumption.

### Stateful sessions

```bash
# First call — auto-generates a session UUID bound to thread-id "my-session"
agentflow --yaml cas_agent.yaml --thread-id my-session "My name is Alice"

# Second call — resumes the same SDK session; agent remembers "Alice"
agentflow --yaml cas_agent.yaml --thread-id my-session "What's my name?"
```

### Alternate persistence backends

```bash
# In-memory (stateless — thread mapping lost on exit)
agentflow --yaml cas_agent.yaml --persistence memory "..."

# PostgreSQL for multi-instance deployments
agentflow --yaml cas_agent.yaml \
  --persistence postgres \
  --connection-string "postgresql://user:pass@host/db" \
  --thread-id user-42 \
  "..."
```

### Encrypted thread-id mapping

Set an AES key before running; the session-id binding stored in SQLite/Postgres/memory is wrapped with AES-GCM.

```bash
export AGENTFLOW_ENCRYPTION_KEY="0123456789abcdef0123456789abcdef"   # 32 bytes
agentflow --yaml cas_agent.yaml --thread-id secret-session "..."
```

## Environment variables

| Variable                       | Purpose                                                           |
| ------------------------------ | ----------------------------------------------------------------- |
| `ANTHROPIC_API_KEY`            | Required — read by the SDK (bridged from `llm.config.api_key`)    |
| `OTEL_TRACES_ENABLED`          | `true` → install OTLP exporter (see [Observability](OBSERVABILITY.md)) |
| `OTEL_SERVICE_NAME`            | Service name for traces (default: `agentflow`)                |
| `OTEL_EXPORTER_OTLP_ENDPOINT`  | OTLP collector endpoint                                           |
| `OTEL_EXPORTER_OTLP_PROTOCOL`  | `grpc` (default) or `http/protobuf`                               |
| `AGENTFLOW_ENCRYPTION_KEY`     | AES-128/192/256 key (16/24/32 bytes) for thread-id mapping        |
| `AGENTFLOW_LOG_LEVEL`          | `DEBUG`/`INFO`/`WARNING`/`ERROR` (default: `WARNING`)              |
| `CHECKPOINTER_DB_PATH`         | Default SQLite path when `--db-path` is omitted                   |
| `POSTGRES_CONNECTION_STRING`   | Default Postgres DSN when `--connection-string` is omitted        |

## Exit codes

- `0` — success
- `1` — error (invalid YAML, missing env var, SDK failure, etc.) — a traceback is printed

## Docs server

```bash
agentflow-docs                    # auto-detects installed backend; CAS → port 9300
agentflow-docs --backend claude-agent-sdk
agentflow docs                # explicit CAS docs launcher
```

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
