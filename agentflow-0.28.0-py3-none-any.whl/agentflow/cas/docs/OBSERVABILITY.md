# Observability

AgentFlow CAS emits OpenTelemetry spans via OTLP when tracing is enabled. No change to application code — enable with one env var.

## Enable

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_SERVICE_NAME=my-cas-agent
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317    # grpc
# or
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318    # http
```

The CLI prints a tracing banner at startup:

```
OpenTelemetry tracing enabled
  Service: my-cas-agent
  Endpoint: http://localhost:4317 (grpc)
  CAS spans: tool calls + hook lifecycle + cost tracking
```

## Span catalog

Per run (one root + children):

| Span name                               | When it fires                                       | Key attributes                                                                 |
| --------------------------------------- | --------------------------------------------------- | ------------------------------------------------------------------------------ |
| `agentflow.cas.run` (root)              | Once per query                                      | `agentflow.backend`, `agentflow.thread_id`, `gen_ai.request.model`, `agentflow.sdk_session_id`, and (when `ResultMessage` arrives) `gen_ai.usage.*`, `gen_ai.session.*` |
| `gen_ai.execute_tool <tool_name>`       | Per tool call (from `audit_log` observer)           | `gen_ai.operation.name`, `gen_ai.tool.name`, `gen_ai.tool.call.id`, `gen_ai.tool.call.arguments`, `gen_ai.tool.call.result` |
| `agentflow.tool.latency <tool_name>`    | Per tool call (from `latency_tracking` observer)    | `gen_ai.tool.name`, `gen_ai.tool.call.id`, `agentflow.tool.latency_ms`          |
| `gen_ai.session_summary`                | Once at the end of the run (from `ResultMessage`)   | `gen_ai.session.duration_ms`, `gen_ai.session.num_turns`, `gen_ai.usage.input_tokens`, `output_tokens`, `cache_creation_input_tokens`, `cache_read_input_tokens`, `total_cost_usd`, `stop_reason`, per-model rollup under `gen_ai.model_usage.<model_id>.*` |
| `agentflow.session_stop`                | When the SDK's Stop hook fires                      | `gen_ai.operation.name: session_stop_hook`, `agentflow.budget_usd`             |

All spans use the `gen_ai.*` semantic conventions so they render nicely in standard OTel UIs (Jaeger, Tempo, Grafana, Honeycomb, Datadog, etc.).

## Subagent tracing

When the main agent calls the SDK's `Task` tool to delegate, the delegation shows up as `gen_ai.execute_tool Agent` (the SDK names the Task tool `Agent`). The subagent's tool calls appear as children via `parent_tool_use_id` in the hook payload — in Jaeger you'll see the main run → Task call → subagent's `mcp__*` tool calls nested correctly.

## Token + cost attribution

Token usage and cost are **not** available from SDK hooks — they live on the `ResultMessage` the SDK emits at the end of each query. CAS intercepts that message in the CLI driver and:

- Emits a `gen_ai.session_summary` child span with every usage key
- Mirrors the headline numbers onto the root `agentflow.cas.run` span so queries can filter on cost without drilling into children

The per-model rollup surfaces cache hit rates and the exact breakdown when the SDK's `fallback_model` kicks in mid-session.

## Collector recipes

### Jaeger (gRPC)

```bash
docker run -d -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one:latest
```

```bash
OTEL_TRACES_ENABLED=true \
OTEL_SERVICE_NAME=my-cas-agent \
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317 \
agentflow --yaml cas_agent.yaml "..."
```

UI at http://localhost:16686.

### Langfuse

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-cas-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <base64(pk:sk)>
```

### Phoenix (Arize)

```bash
OTEL_TRACES_ENABLED=true
OTEL_SERVICE_NAME=my-cas-agent
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:6006
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

### Grafana Tempo / Datadog / New Relic / Honeycomb / Splunk

Set `OTEL_EXPORTER_OTLP_ENDPOINT`, `OTEL_EXPORTER_OTLP_PROTOCOL`, and `OTEL_EXPORTER_OTLP_HEADERS` (for auth) to the backend of your choice. No code changes needed — the agentflow CLI talks plain OTLP.

### Azure Monitor (Application Insights / Azure AI Foundry)

Install the built-in exporter extra and set the connection string — no code:

```bash
pip install 'agentflow[azure-monitor]'
OTEL_TRACES_ENABLED=true
APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=https://..."
```

The exporter attaches automatically through AgentFlow's shared exporter seam
(`agentflow.core.telemetry_seam`) — additively, so any OTLP export keeps working
alongside Azure (dual-export). Application Insights can't ingest raw OTLP; this
extra's `AzureMonitorTraceExporter` is the translator. Spans appear in App
Insights and, once that resource is linked to a Foundry project, in the Foundry
Tracing tab.

## Filters as observability sinks

For shops without an OTel backend, flip on structured logging via the built-in observers:

```yaml
observers:
  - type: audit_log                  # per-tool start/end log records
  - type: latency_tracking           # per-tool latency log records
  - type: cost_tracking              # session-stop log record
```

Then:

```bash
export AGENTFLOW_LOG_LEVEL=INFO
```

Records land on these loggers:

| Logger                         | Emits                          |
| ------------------------------ | ------------------------------ |
| `agentflow.cas.audit`          | Tool start/end                 |
| `agentflow.cas.latency`        | Tool latency                   |
| `agentflow.cas.cost`           | Session stop                   |
| `agentflow.pharma.audit` (e2e app) | GxP audit hooks             |

Configure your Python logging framework to route them to stdout / files / ELK / Datadog Logs.

## Sensitive data in traces

By default, observer spans include tool `call.arguments` and `call.result`. For sensitive pipelines, pair the PII guard with custom redaction before the data reaches the observer:

```yaml
guards:
  - type: pii
    config: { patterns: [email, ssn, credit_card] }

observers:
  - type: audit_log                 # now sees redacted data
```

The built-in renderer also truncates tool results at ~2 KB to keep span attributes manageable for OTLP backends.

## Env vars reference

| Variable                          | Purpose                                            | Default                 |
| --------------------------------- | -------------------------------------------------- | ----------------------- |
| `OTEL_TRACES_ENABLED`             | Enable distributed tracing                         | `false`                 |
| `OTEL_SERVICE_NAME`               | Service name in traces                             | `agentflow`         |
| `OTEL_EXPORTER_OTLP_ENDPOINT`     | OTLP endpoint                                      | `http://localhost:4317` |
| `OTEL_EXPORTER_OTLP_PROTOCOL`     | `grpc` or `http/protobuf`                          | `grpc`                  |
| `OTEL_EXPORTER_OTLP_HEADERS`      | Auth headers (`key=value,` comma-separated)        | (none)                  |
| `OTEL_EXPORTER_OTLP_CERTIFICATE`  | TLS cert path                                      | (none)                  |
| `OTEL_EXPORTER_OTLP_TIMEOUT`      | Export timeout (ms)                                | `10000`                 |
| `AGENTFLOW_LOG_LEVEL`             | AgentFlow log verbosity                            | `WARNING`               |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
