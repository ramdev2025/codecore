# MCP Integration

The Claude Agent SDK has native support for the [Model Context Protocol](https://modelcontextprotocol.io/) across **three transports**: stdio (subprocess), SSE (server-sent events), and HTTP (JSON-RPC). CAS exposes all three directly in YAML.

## Declare servers

```yaml
mcp_servers:
  # --- stdio: spawns a subprocess ---
  local-data:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]
    env:
      LOG_LEVEL: info

  # --- SSE: server-sent events ---
  remote:
    transport: sse
    url: https://example.com/mcp/sse
    headers:
      Authorization: "Bearer ${REMOTE_TOKEN}"

  # --- HTTP: JSON-RPC over HTTPS ---
  api-gateway:
    transport: http
    url: https://api.example.com/mcp
    headers:
      Authorization: "Bearer ${API_TOKEN}"
      X-Tenant: ${TENANT_ID}
```

## Field reference

| Field       | stdio | sse | http | Notes                                                    |
| ----------- | :---: | :---: | :---: | ------------------------------------------------------- |
| `transport` | ✅    | ✅  | ✅   | `stdio` (default) / `sse` / `http`                      |
| `command`   | ✅    |     |      | Required for stdio; SDK validator enforces              |
| `args`      | opt   |     |      | CLI arguments to `command`                              |
| `env`       | opt   |     |      | Extra env vars for the subprocess                       |
| `url`       |       | ✅  | ✅   | Required for sse/http; SDK validator enforces           |
| `headers`   |       | opt | opt  | Typically used for `Authorization` / tenant headers     |

## How tools appear to the model

MCP tools surface to the model as `mcp__<server_name>__<tool_name>`. So `mcp_servers.local-data` exposing a `list_files` tool becomes `mcp__local-data__list_files` in the LLM's tool list.

## Sharing MCP servers with subagents

Subagents can opt into any session-scoped MCP server by listing its name:

```yaml
mcp_servers:
  security_db:
    transport: http
    url: https://api.internal/mcp

subagents:
  researcher:
    description: Security research
    prompt: ...
    mcp_servers: [security_db]       # ← reference by name
```

The validator checks that every string reference resolves — either to a top-level `mcp_servers:` entry or to an `agent.plugins[].name` (plugins are also registered as in-process MCP servers).

## Env var substitution in headers

Because the whole YAML passes through the env-var resolver before Pydantic validation, you can interpolate secrets:

```yaml
mcp_servers:
  api-gateway:
    transport: http
    url: ${MCP_API_URL}
    headers:
      Authorization: "Bearer ${MCP_TOKEN}"
```

Missing vars fail loud at config-load time — no silent empty-string substitutions.

## Native `@tool` plugins vs MCP

You have two ways to add custom tools:

| Option                     | Use when...                                                        |
| -------------------------- | ------------------------------------------------------------------ |
| `agent.plugins:` (`python`) | Tool logic lives in this Python project; no network dependency    |
| `mcp_servers:`              | Tool is hosted separately (another language, team, or deployment) |

Python plugins register as in-process MCP servers, so from the SDK's perspective they're the same mechanism — you choose based on where the code lives.

## Troubleshooting

**`MCP transport 'stdio' requires 'command'`** — the schema catches missing `command` fields at load time.

**`MCP transport 'sse' requires 'url'`** — same for SSE / HTTP.

**Tool doesn't show up in the model's tool list** — confirm the server name matches; MCP tools are namespaced as `mcp__<server>__<tool>`. Check the CLI's `--dry-run` output for the servers the builder detected.

**Subprocess stdio servers hang** — the SDK waits for the subprocess to handshake. Check that `command` is resolvable (`which npx`), and that `args` don't point at a missing module.

**Authentication fails** — confirm `${VAR}` substitution happened. Run with `AGENTFLOW_LOG_LEVEL=DEBUG` to see the loaded env.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
