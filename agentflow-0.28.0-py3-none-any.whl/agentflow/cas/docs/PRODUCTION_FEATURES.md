# Production Features

A single reference for all production-grade capabilities in CAS. Everything here is configurable from `cas_agent.yaml` or environment variables — no custom code required.

## Feature matrix

### LLM Controls

| Feature              | YAML location                      | What it does                                                            |
| -------------------- | ---------------------------------- | ----------------------------------------------------------------------- |
| Primary model        | `llm.config.model`                 | e.g. `claude-opus-4-7`, `claude-sonnet-4-6`                             |
| Fallback model       | `llm.config.fallback_model`        | Used on transient primary-model failures                                |
| Budget enforcement   | `llm.config.max_budget_usd`        | **Hard stop** — session terminates when spend exceeds the limit        |
| Turn cap             | `llm.config.max_turns`             | Iteration cap                                                            |
| Extended thinking    | `llm.config.thinking`              | `{type: adaptive}` / `{type: enabled, budget_tokens: N}` / `{type: disabled}` |
| Effort preset        | `llm.config.effort`                | `low` / `medium` / `high` / `max`                                       |
| Token streaming      | `llm.config.include_partial_messages` | Default `true` — token-level streaming in the CLI                   |
| Beta opt-in          | `llm.config.betas`                 | e.g. `[context-1m-2025-08-07]`                                          |

### Agent & Subagent

| Feature                | YAML location                | What it does                                                        |
| ---------------------- | ---------------------------- | ------------------------------------------------------------------- |
| Main agent             | `agent:`                     | Single orchestrator-or-solo agent                                    |
| Subagents              | `subagents:` (dict)          | Named specialists; main delegates via `task` tool                    |
| Per-agent LLM override | `agent.llm:` or `subagents.<name>.model` | Cheaper model for grunt work, premium for orchestration  |
| Custom Python plugins  | `agent.plugins:`             | In-process `@tool`-decorated function modules                        |
| Skills                 | `agent.skills: "all"` / list | Load Anthropic skills                                                |
| Settings precedence    | `agent.setting_sources`      | `user` / `project` / `local` layers                                  |
| Structured output      | `agent.output_format`        | Passthrough for JSON-schema-enforced replies                         |
| Multi-tenant identity  | `agent.user`                 | SDK `user` field for attribution                                     |

### Safety & Permissions

| Feature               | YAML location                        | What it does                                                     |
| --------------------- | ------------------------------------ | ---------------------------------------------------------------- |
| Permission modes      | `agent.permissions.mode`             | `default` / `acceptEdits` / `plan` / `dontAsk` / `bypassPermissions` / `auto` |
| Tool allow-list       | `agent.permissions.allowed_tools`    | Whitelist (capitalized SDK names)                                |
| Tool deny-list        | `agent.permissions.disallowed_tools` | Blacklist (applied after allow-list)                             |
| Custom permission     | `agent.permissions.can_use_tool`     | Async `(name, input, ctx) → Allow/Deny` callback                 |
| Interactive approval  | `agent.permissions.prompt_tool_name` | MCP tool used to prompt a human                                  |
| Sandbox               | `agent.sandbox`                      | Network allow/deny, excluded commands, nested-sandbox toggle     |
| Directory restriction | `agent.cwd` + `agent.add_dirs`       | Tools scoped to cwd + explicit extra dirs                         |

### Observability & Telemetry

| Feature               | Where configured                 | What it produces                                                  |
| --------------------- | -------------------------------- | ----------------------------------------------------------------- |
| Distributed tracing   | `OTEL_TRACES_ENABLED=true`       | OTLP spans to any OTel backend — Jaeger, Tempo, Datadog, Langfuse |
| Token + cost tracking | observer + `ResultMessage` bridge | `gen_ai.session_summary` span with per-model usage rollup        |
| Audit log             | `observers: [{type: audit_log}]` | Per-tool spans + log records                                      |
| Latency tracking      | `observers: [{type: latency_tracking}]` | Per-tool latency in spans + logs                            |
| Budget enforcement    | `llm.config.max_budget_usd`      | Hard stop (complementary to cost-tracking observer)               |
| Streaming progress    | CLI renderer                     | Live subagent delegations, tool calls, thinking, streamed text    |

### Integrations

| Feature                      | YAML location                | Value                                                            |
| ---------------------------- | ---------------------------- | ---------------------------------------------------------------- |
| MCP stdio / SSE / HTTP       | `mcp_servers:`               | All three transports; headers for auth                           |
| Cross-backend plugins        | via plugin bridge            | AgentFlow `Plugin` ABC hooks fire on CAS agents                  |
| Cross-backend guards/observers | `guards/optimizers/observers:` | Portable tier; compiles to CAS hooks                         |

### Persistence

| Feature                    | Location                                 | Value                                                   |
| -------------------------- | ---------------------------------------- | ------------------------------------------------------- |
| In-memory mapping          | `--persistence memory`                   | Ephemeral threads                                        |
| SQLite mapping             | default; `--db-path`                     | Single-node `thread_id → session_id` bridge             |
| Postgres mapping           | `--persistence postgres`                 | Multi-instance; one connection per operation, not pooled |
| AES-GCM at rest            | `AGENTFLOW_ENCRYPTION_KEY`               | Encrypts stored session UUIDs                            |
| Thread-id resumption       | `--thread-id`                            | Bridges to SDK session UUID; SDK owns the chat history   |

## Why these matter

- **Cost becomes predictable.** `max_budget_usd` stops spend; `gen_ai.session_summary` span reports it. No surprise bills.
- **Risk is constrained, not hoped for.** `tool_call_limit` + `permission_mode` + `sandbox` mean a bad prompt costs pennies, not dollars or damage.
- **Observability is end-to-end.** One OTel env var → per-tool spans, per-subagent nesting, token breakdown per model, cache hit rates.
- **Deployment is code-free.** memory → sqlite → postgres is a CLI flag. Encryption is one env var. No application changes.
- **Multi-tenant attribution is first-class.** `user:` field propagates to traces and billing.
- **You don't leak secrets.** PII guard redacts before the model. Sandbox denies network by default. Permission hooks gate every tool call.

## Complete example

See [Full Example](FULL_EXAMPLE.md) for an annotated YAML exercising every feature in a realistic code-review / security-research scenario.

## Comparison with other AgentFlow backends

|                                  | workflows | deep | sk   | **cas**                               |
| -------------------------------- | :-------: | :--: | :--: | :-----------------------------------: |
| YAML-driven                      | ✅        | ✅   | ✅   | ✅                                     |
| Unified CLI / API                | ✅        | ✅   | ✅   | ✅                                     |
| OTel tracing                     | ✅        | ✅   | ✅   | ✅                                     |
| Persistence (mem/SQLite/PG)      | ✅        | ✅   | ✅   | ✅                                     |
| AES-GCM encryption               | ✅        | ✅   | ✅   | ✅                                     |
| Native subagents                 | ❌        | ✅   | ❌   | ✅                                     |
| Orchestration modes              | graph     | supervisor | handoff / sequential / group / magentic / process | single-agent + subagents |
| First-class hook events          | ❌        | ❌   | ❌   | ✅ (10 event types)                    |
| Custom Python `@tool` plugins    | (via LangChain) | (via LangChain) | ✅ (SK `@kernel_function`) | ✅ (CAS `@tool`) |
| Structured output                | (via middleware) | (via middleware) | ✅ | ✅ (SDK `output_format`)      |
| Sandbox / network policy         | ❌        | ❌   | ❌   | ✅ (SDK-native)                        |
| Budget enforcement (hard stop)   | (callbacks) | (callbacks) | (observer) | ✅ SDK-native `max_budget_usd` |

See [Migration](MIGRATION.md) for moving between backends.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
