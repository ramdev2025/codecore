# Agent Modes

Unlike SK (handoff / sequential / group-chat / magentic / process), CAS has **one** execution model: a main agent, optionally with subagents. The Claude Agent SDK handles delegation natively via the `Task` tool — agentflow just gives it the YAML shape.

## Single agent

Only an `agent:` block. The agent uses whatever tools / plugins / MCP servers you wire in.

```yaml
agent:
  name: writer
  system_prompt: You write concise Python docstrings.
  tools:
    builtin: [read, edit]
  plugins:
    - name: my_tools
      type: python
      module: myapp.tools
```

Use cases:

- Utility agents (summarizers, generators)
- Workflows where delegation adds latency without value
- Agents that use MCP for everything and don't need subagent specialization

## Main agent + subagents

Add a `subagents:` dict and enable the `task` tool so the main agent can delegate. This is the most common CAS shape for multi-specialist workflows.

```yaml
agent:
  name: orchestrator
  system_prompt: |
    Route research questions to researcher, coding tasks to coder.
  tools:
    builtin: [task]            # ← this unlocks delegation

subagents:
  researcher:
    description: Searches the web and summarizes sources
    prompt: You research carefully and cite.
    tools: [web_search, web_fetch, read]
    model: claude-sonnet-4-6
    max_turns: 10
  coder:
    description: Writes and edits code
    prompt: You follow the project's style guide.
    tools: [read, write, edit, grep, glob, bash]
    model: claude-opus-4-7
    permission_mode: acceptEdits
```

**What happens at runtime:**

1. The main agent receives the user query
2. It picks a subagent (by name, using `Task`) with a focused prompt
3. The SDK spins up that subagent as a nested session; its tool calls nest under the main agent's trace
4. The subagent finishes with a `TaskNotificationMessage` (`completed` / `failed` / `stopped`) summary
5. The main agent integrates the summary and may delegate again or answer

See [Subagents](SUBAGENTS.md) for the full pattern, per-subagent controls, and the MCP-server sharing rules.

## Why no handoff / sequential / group-chat modes?

The Claude Agent SDK doesn't need them:

- **Handoff** — the main agent + subagents shape IS a handoff (orchestrator `Task`-delegates to a specialist that runs to completion)
- **Sequential** — orchestrator prompts enforce order (`"First call researcher, then coder"`)
- **Group chat** — multiple subagents can be invoked in parallel via concurrent `Task` calls when `background: true`

Process-framework-style state machines are also not a first-class SDK concept. If you need them, use the `workflows` (LangGraph) backend.

## Main agent vs subagent — what's different?

| Field              | Main agent | Subagent |
| ------------------ | :--------: | :------: |
| `name`             | ✅         | (dict key) |
| `system_prompt`    | ✅         | (`prompt:`) |
| `cwd`, `add_dirs`  | ✅         | inherited |
| `tools`            | ✅ (preset or list) | list only |
| `plugins`          | ✅ (shared with subagents via name refs) | via `mcp_servers` references |
| `permissions`      | ✅ (full object) | `permission_mode` + `disallowed_tools` only |
| `hooks`            | ✅         | inherited from main agent |
| `skills`           | ✅         | ✅        |
| `sandbox`          | ✅         | inherited |
| `user`             | ✅         | inherited |
| `output_format`    | ✅         | inherited |
| `model` / `effort` / `max_turns` | `llm:` config | top-level fields on subagent |
| `initial_prompt` / `background` | ❌ | ✅        |
| `memory`           | ❌         | ✅ (user/project/local) |

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
