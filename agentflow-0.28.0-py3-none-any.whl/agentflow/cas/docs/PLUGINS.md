# Plugins

A **plugin** in CAS is a Python module of `@tool`-decorated functions that AgentFlow registers as an in-process MCP SDK server on the agent's Kernel.

That's the whole story. In v1 the only plugin type is `python` — the SDK's MCP-based tool API is powerful enough that prompt templates, OpenAPI specs, and directory-format plugins (which SK supports) don't add value here.

## Declare a plugin

```yaml
agent:
  plugins:
    - name: my_tools              # becomes the MCP server name
      type: python
      module: myapp.tools         # importable Python module
      functions: [foo, bar]       # optional: restrict to named functions
```

| Field       | Required | Notes                                                    |
| ----------- | -------- | -------------------------------------------------------- |
| `name`      | ✅       | The MCP server identifier — visible in span attributes   |
| `type`      | ✅       | `python` (the only v1 value)                             |
| `module`    | ✅       | Python import path; must be importable at runtime        |
| `functions` |          | Subset of `@tool` names to expose; defaults to all       |

## Author a tool

Use the SDK's `@tool` decorator — **not** LangChain's. The signature is explicit:

```python
from claude_agent_sdk import tool

@tool(
    "get_weather",                # tool name
    "Look up the current weather for a city.",    # description
    {"city": str},                # input schema (dict or OpenAPI JSON Schema)
)
async def get_weather(args):
    # args is a dict matching the schema
    city = args["city"]
    # ... call a real API ...
    return {
        "content": [
            {"type": "text", "text": f"Weather in {city}: 72°F sunny"}
        ]
    }
```

Requirements:

1. **Use the SDK decorator** (`from claude_agent_sdk import tool`) — LangChain's `@tool` won't work
2. **Async handler** that takes `args: dict` and returns `{"content": [...]}` or an error shape
3. **Input schema** can be a dict like `{"city": str, "units": str}` OR a full OpenAPI JSON Schema dict
4. **Module** must be on `PYTHONPATH` when the CLI runs — usually the project root

## How registration works

The builder:

1. Imports your `module`
2. Collects every `SdkMcpTool` instance (what `@tool` returns)
3. Filters by `functions:` if set
4. Calls `create_sdk_mcp_server(name=<plugin_name>, tools=[...])` to build an in-process server
5. Adds the result to `ClaudeAgentOptions.mcp_servers[<plugin_name>]`

The SDK treats it like any other MCP server — no subprocess, no network round-trip. The tool surface appears to the model as `mcp__<plugin_name>__<tool_name>`.

## Sharing plugins with subagents

Subagents can reference plugin names in their `mcp_servers:` list (same syntax as top-level MCP servers):

```yaml
agent:
  plugins:
    - name: pharma_tools
      type: python
      module: myapp.pharma

subagents:
  analyst:
    description: Analyzes pharma data
    prompt: ...
    mcp_servers: [pharma_tools]      # ← references the plugin by name
```

This works because the plugin registers as an MCP server in the SDK's `mcp_servers` dict, and subagents can access any MCP server registered at the session level.

## Restricting a plugin to specific functions

When a module exports more tools than you want to expose:

```yaml
plugins:
  - name: billing
    type: python
    module: myapp.billing            # exports lookup, refund, chargeback, void
    functions: [lookup, void]        # only expose these two
```

The builder matches either by the Python attribute name (`lookup`) or by the tool's declared `@tool` name, whichever you prefer.

## Errors the builder raises

| Cause                                                   | Error                                                   |
| ------------------------------------------------------- | ------------------------------------------------------- |
| `module:` can't be imported (not on `PYTHONPATH`)       | `ImportError: Plugin module '…' could not be imported` |
| Module has no `@tool`-decorated functions               | `ValueError: Plugin '…': no @tool-decorated functions` |
| `functions:` list names a function that doesn't exist   | Same `no @tool` error if the filter leaves nothing      |

## Example: a full tool module

```python
# myapp/weather.py
from claude_agent_sdk import tool

@tool("get_weather", "Current weather for a city.", {"city": str, "units": str})
async def get_weather(args):
    city, units = args["city"], args.get("units", "imperial")
    ...
    return {"content": [{"type": "text", "text": f"Weather in {city}: ..."}]}

@tool("forecast", "5-day forecast for a city.", {"city": str})
async def forecast(args):
    ...
    return {"content": [{"type": "text", "text": "..."}]}
```

YAML:

```yaml
agent:
  plugins:
    - name: weather
      type: python
      module: myapp.weather
```

At runtime, the model sees two tools: `mcp__weather__get_weather` and `mcp__weather__forecast`.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
