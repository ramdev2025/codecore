# Persistence

CAS conversation state is a **SDK session UUID** — the SDK owns the actual `ChatHistory`. AgentFlow's job is to bridge that UUID to our cross-backend `--thread-id` contract, so users get the same session-resumption story on CAS as on workflows / deep / sk.

## The model

| Layer               | Owns                                       |
| ------------------- | ------------------------------------------ |
| Claude Agent SDK    | The chat history itself (files in `.claude/`) |
| AgentFlow CAS       | `thread_id → SDK session UUID` + audit metadata (first/last seen, turn count) |

When you pass `--thread-id my-session`, the CLI:

1. Looks up `my-session` in the persistence store
2. If a session UUID is bound, sets `ClaudeAgentOptions.resume = <uuid>` so the SDK picks up where it left off
3. After the run, reads the (possibly updated) session UUID from the message stream and writes the mapping back
4. Bumps the turn counter for the thread

## Backends

| Backend      | When to use                                | Storage                                  |
| ------------ | ------------------------------------------ | ---------------------------------------- |
| `memory`     | Tests, stateless workers                   | In-process dict, lost on exit            |
| `sqlite` (default) | Local dev, single-node services      | File: `.agentflow/cas_threads.db`        |
| `postgres`   | Production, multi-instance                 | Connection-pooled Postgres table         |

## CLI flags

```bash
# Default — sqlite
agentflow --yaml cas_agent.yaml --thread-id my-session "..."

# Memory (ephemeral)
agentflow --yaml cas_agent.yaml --persistence memory "..."

# Custom SQLite path
agentflow --yaml cas_agent.yaml --db-path ./state.db --thread-id s1 "..."

# PostgreSQL
agentflow --yaml cas_agent.yaml \
  --persistence postgres \
  --connection-string "postgresql://user:pass@host/db" \
  --thread-id user-42 \
  "..."
```

## Env vars

| Variable                       | Purpose                                                                                 |
| ------------------------------ | --------------------------------------------------------------------------------------- |
| `AGENTFLOW_PERSISTENCE`        | Backend selector: `memory` / `sqlite` / `postgres` (used when `--persistence` is unset) |
| `CHECKPOINTER_DB_PATH`         | Default SQLite path (overridden by `--db-path`)                                         |
| `POSTGRES_CONNECTION_STRING`   | Default DSN (overridden by `--connection-string`)                                       |
| `AGENTFLOW_ENCRYPTION_KEY`     | AES-128/192/256 key for encrypting stored session UUIDs                                 |

Resolution order: CLI flag > env var > default (sqlite). See
[`workflows/PERSISTENCE.md`](../../workflows/docs/PERSISTENCE.md) for
the canonical full reference (workflows adds tuning env vars like the
`POSTGRES_POOL_*` family and `AGENTFLOW_ENCRYPTION_KEY`).

> **Connection resilience.** This backend opens a PostgreSQL connection per
> operation and closes it again, so it is not exposed to the stale-connection
> failure fixed in 0.28.0 (where a database restart or reaped idle connection
> left the app permanently failing). Connection pooling and the
> `POSTGRES_POOL_*` tuning vars apply to the `workflows` and `deep` backends
> only.

## Encryption at rest

When `AGENTFLOW_ENCRYPTION_KEY` is set, the stored `session_id` values are wrapped with **AES-GCM** (via `pycryptodome`). The key must be 16, 24, or 32 bytes for AES-128 / AES-192 / AES-256.

```bash
export AGENTFLOW_ENCRYPTION_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
agentflow --yaml cas_agent.yaml --thread-id secret-session "..."
```

Wrong-key reads fail loud — no silent fallback to cleartext.

## Table schema (SQLite / Postgres)

```sql
CREATE TABLE cas_threads (
    thread_id     TEXT PRIMARY KEY,
    session_id    TEXT NOT NULL,          -- encrypted if AES key set
    first_seen    DOUBLE PRECISION NOT NULL,
    last_seen     DOUBLE PRECISION NOT NULL,
    turns         INTEGER NOT NULL DEFAULT 0
);
```

Thinner than SK's schema because the SDK owns the history. We only store the binding + audit counters.

## Python API

```python
from agentflow.cas.core.persistence import create_persistence_manager

pm = create_persistence_manager(
    backend="sqlite",
    db_path="./my.db",
    encryption_key=b"0123456789abcdef0123456789abcdef",
)

# Look up / save a binding
session_id = pm.get_session_id("my-thread")
pm.put_session_id("my-thread", "sdk-uuid-abc")
pm.bump_turns("my-thread")
pm.list_threads()              # → ["my-thread", ...]
pm.delete("my-thread")
```

## FastAPI integration

One persistence manager per process, shared across request handlers:

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentflow.cas.core.builder import CasAgentBuilder
from agentflow.cas.core.persistence import create_persistence_manager

@asynccontextmanager
async def lifespan(app):
    app.state.runner = CasAgentBuilder.from_yaml("cas_agent.yaml").build()
    app.state.pm = create_persistence_manager(
        backend="postgres",
        connection_string=os.environ["DATABASE_URL"],
    )
    yield

app = FastAPI(lifespan=lifespan)

@app.post("/chat/{thread_id}")
async def chat(thread_id: str, message: str):
    existing = app.state.pm.get_session_id(thread_id)
    if existing:
        app.state.runner.options.resume = existing
    reply = ""
    async for msg in app.state.runner.query(message):
        text = getattr(msg, "session_id", None)
        if text:
            app.state.pm.put_session_id(thread_id, text)
        # extract text from AssistantMessage ...
    app.state.pm.bump_turns(thread_id)
    return {"thread_id": thread_id, "reply": reply}
```

## Troubleshooting

**`database is locked` (SQLite)** — multiple processes writing the same SQLite file, or NFS/SMB storage (which doesn't support SQLite locking). Switch to Postgres for concurrency.

**`Encryption key must be 16, 24, or 32 bytes`** — your `AGENTFLOW_ENCRYPTION_KEY` is the wrong length. Generate a new one: `python -c "import secrets; print(secrets.token_hex(32))"`.

**`Stored session id is encrypted but AGENTFLOW_ENCRYPTION_KEY is not set`** — you wrote encrypted data but are now reading without the key. Export the same key used when saving.

**Session didn't resume** — confirm `--thread-id` is identical. Without it a fresh UUID is auto-generated each run.

## Summary

| Feature                    | memory | sqlite | postgres |
| -------------------------- | :----: | :----: | :------: |
| Survives process restart   | ❌     | ✅     | ✅       |
| Multi-process              | ❌     | ❌     | ✅       |
| Horizontal scale           | ❌     | ❌     | ✅       |
| AES-GCM at rest            | ✅     | ✅     | ✅       |
| Best for                   | Tests  | Local  | Production |

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
