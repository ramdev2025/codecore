# Guards / Optimizers / Observers

Cross-backend concerns — the **portable tier** of the AgentFlow schema. Declare them once, they work on workflows / deep / sk / cas alike. In CAS, they compile **down** to hook registrations and execute as part of the SDK's hook pipeline.

Use this tier when you want portability across backends. If you need SDK-native expressiveness, use [`agent.hooks:`](HOOKS.md) directly — they compose cleanly (user-declared hooks run first per event, followed by compiled ones).

## Guards — constrain and protect

```yaml
guards:
  - type: tool_call_limit
    config: { max_calls: 50 }
  - type: model_call_limit
    config: { max_calls: 100 }
  - type: pii
    config: { patterns: [email, phone, ssn, credit_card] }
  - type: content_filter              # requires custom implementation
    module: myapp.filters
    function: block_secrets
```

| Type                | Compiles to                 | What it does                                                    |
| ------------------- | --------------------------- | --------------------------------------------------------------- |
| `tool_call_limit`   | `PreToolUse` hook           | Blocks tool calls past `max_calls`                              |
| `model_call_limit`  | `UserPromptSubmit` hook     | Blocks user prompts past `max_calls` (proxy for model turns)    |
| `pii`               | `UserPromptSubmit` hook     | Redacts PII patterns in prompts before the model sees them      |
| `input_validation`  | requires `module`+`function` | Custom pre-tool validator                                      |
| `content_filter`    | requires `module`+`function` | Custom content filter                                          |

### `pii` guard patterns

Default patterns: `email`, `phone`, `ssn`, `credit_card`. Pass a custom regex string (compiled verbatim) to extend.

```yaml
guards:
  - type: pii
    config:
      patterns: [email, ssn, "AKIA[0-9A-Z]{16}"]   # AWS access key pattern
```

The guard rewrites the user prompt by replacing each pattern with `[REDACTED]` and returns `{hookSpecificOutput: {updatedPrompt: ...}}` so the SDK sees the redacted version.

## Optimizers — improve efficiency

```yaml
optimizers:
  - type: tool_retry
    config: { max_retries: 2, initial_backoff_ms: 500 }
  - type: summarization
  - type: prompt_caching                # no-op; SDK handles natively
```

| Type              | Compiles to                  | Notes                                                            |
| ----------------- | ---------------------------- | ---------------------------------------------------------------- |
| `tool_retry`      | `PostToolUseFailure` hook    | Returns `{decision: retry}` with exponential backoff             |
| `summarization`   | `PreCompact` hook            | Emits an audit log line; SDK does the actual compaction          |
| `prompt_caching`  | no-op                        | Anthropic SDK handles caching natively based on request settings |

## Observers — watch without modifying

```yaml
observers:
  - type: audit_log
  - type: cost_tracking
    config: { budget_limit: 25.00 }     # informational; real enforcement via llm.config.max_budget_usd
  - type: latency_tracking
```

| Type               | Compiles to                                 | Emits                                                                |
| ------------------ | ------------------------------------------- | -------------------------------------------------------------------- |
| `audit_log`        | `PreToolUse` + `PostToolUse` pair           | `gen_ai.execute_tool <name>` span with args/result + log records     |
| `latency_tracking` | `PreToolUse` + `PostToolUse` pair           | `agentflow.tool.latency <name>` span with `agentflow.tool.latency_ms` |
| `cost_tracking`    | `Stop` hook (operational only)              | `agentflow.session_stop` span. Real usage/cost come from `ResultMessage` → `gen_ai.session_summary` span emitted by the CLI driver |

### Important — cost enforcement vs cost observability

These are **two different knobs**:

| Knob                              | Kind             | Where configured                |
| --------------------------------- | ---------------- | ------------------------------- |
| `llm.config.max_budget_usd`       | **enforcement** (hard stop) | SDK-native                 |
| `observers: [{type: cost_tracking}]` | **observability** (span emission) | AgentFlow layer        |

Enable one or both. The observer doesn't enforce anything — it just surfaces usage in traces. The SDK's `max_budget_usd` does the enforcement and kills the session when exceeded.

## Custom types

Any entry that supports `module: + function:` accepts user-provided async callables:

```yaml
guards:
  - type: input_validation
    module: myapp.policy
    function: validate_batch_id
```

Function signature matches the [Hooks](HOOKS.md) convention:

```python
async def validate_batch_id(input_data, tool_use_id, context):
    # Optionally return {"decision": "block", "reason": "..."}
    return {}
```

The compiler wraps your callable in a safe adapter so exceptions don't break the agent.

## Composition order (same event)

When both `agent.hooks:` and `guards/optimizers/observers` register for the same SDK event, the merged order is:

1. User-declared `agent.hooks:` entries (in YAML order)
2. Compiled cross-backend entries (guards → optimizers → observers)

This lets you pre-empt compiled behavior with an explicit native hook when needed.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
