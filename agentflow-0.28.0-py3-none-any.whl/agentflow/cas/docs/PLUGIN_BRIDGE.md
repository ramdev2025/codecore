# Plugin Bridge

AgentFlow exposes a cross-backend lifecycle Plugin ABC (`agentflow.plugins`). The bridge lets **existing workflow / deep plugins run unchanged on CAS agents** — telemetry, logging, cost, and audit plugins authored for one backend work on all four.

## The pattern

The `Plugin` ABC defines observer hooks like `on_tool_call`, `on_tool_result`, `on_error`, `on_workflow_start`, `on_agent_end`. Each backend has a bridge that translates these into its native hook mechanism.

| Backend    | Native surface                          |
| ---------- | --------------------------------------- |
| workflows  | LangChain callbacks                      |
| deep       | LangChain callbacks                      |
| sk         | Semantic Kernel filters                  |
| **cas**    | Claude Agent SDK hooks                   |

## How it's wired for CAS

`agentflow.cas.core.plugin_bridge.build_plugin_bridge_hooks(plugin_manager, context)` produces a dict of `{event: [HookMatcher, ...]}` that maps to three SDK events:

| SDK event            | Bridges to plugin method    |
| -------------------- | --------------------------- |
| `PreToolUse`         | `emit_tool_call`            |
| `PostToolUse`        | `emit_tool_result`          |
| `PostToolUseFailure` | `emit_error`                |

Plus a `WorkflowLifecycleEmitter` context manager emits `emit_workflow_start` / `emit_agent_start` / `emit_agent_end` / `emit_workflow_end` around the top-level CLI invocation.

## Writing a cross-backend plugin

```python
from agentflow.plugins import Plugin, WorkflowContext

class CostLoggerPlugin(Plugin):
    def on_tool_call(self, context: WorkflowContext, tool_name: str, inputs: dict):
        print(f"[{context.execution_id}] → {tool_name}({inputs})")

    def on_tool_result(self, context: WorkflowContext, tool_name: str, result):
        print(f"[{context.execution_id}] ← {tool_name} ok")

    def on_error(self, context: WorkflowContext, error: Exception, info: dict):
        print(f"[{context.execution_id}] ✗ {error}")

    def on_workflow_end(self, context: WorkflowContext, result, status: str):
        print(f"[{context.execution_id}] workflow {status}")
```

Install it via entry point (`[project.entry-points."agentflow.plugins"]`) or drop it in `~/.agentflow/plugins/`. The bridge picks it up automatically when CAS runs and emits events.

## Duck typing

The bridge uses duck typing — a `plugin_manager` only needs the methods it actually emits. A partial plugin (say, one that only implements `on_tool_call`) is fine; missing methods are no-ops. Exceptions inside plugin methods are caught and logged, never propagated to the agent.

## Events the bridge produces

From **hooks** (per-tool-call):

- `emit_tool_call(context, tool_name, inputs)` — fired on `PreToolUse`
- `emit_tool_result(context, tool_name, result)` — fired on `PostToolUse`
- `emit_error(context, error, info)` — fired on `PostToolUseFailure`

From **lifecycle** (per-run, around the outer invocation):

- `emit_workflow_start(context)`
- `emit_agent_start(context, agent_name)`
- `emit_agent_end(context, agent_name, status)`
- `emit_workflow_end(context, result, status)`

## Events that don't apply to CAS

Some lifecycle events are workflow-backend-specific and simply never fire in CAS:

- `on_hitl_*` (LangGraph interrupt)
- `on_external_agent_*` (A2A protocol)
- `on_mcp_connect` (LangGraph-specific — CAS MCP connection is SDK-internal)
- `on_checkpoint_save` / `on_checkpoint_load` (LangGraph checkpointer)

Plugins that only implement these are still loaded, they just never observe anything from a CAS agent.

## When to prefer plugin bridge vs. native hooks

| Use case                                  | Recommended surface        |
| ----------------------------------------- | -------------------------- |
| Observability plugin you want portable across all four backends | **Plugin ABC** + bridge |
| CAS-specific policy or redaction          | `agent.hooks:` directly    |
| Cross-backend but with simple intent (audit, latency, cost) | `observers:` / `guards:` |

Native hooks have strictly more expressive power (10 event types, regex matchers, typed input dicts). Plugin bridge has strictly more portability. Pick based on which axis matters for the task.

## Internals

`WorkflowLifecycleEmitter(plugin_manager, context, agent_name)` is a regular Python context manager — use it around any programmatic CAS invocation to fire lifecycle events:

```python
from agentflow.cas.core.builder import CasAgentBuilder
from agentflow.cas.core.plugin_bridge import WorkflowLifecycleEmitter

runner = CasAgentBuilder.from_yaml("cas_agent.yaml").build()
with WorkflowLifecycleEmitter(my_plugin_manager, context={"run_id": "abc"}, agent_name="main"):
    async for msg in runner.query("..."):
        ...
```

The CLI does this automatically when plugins are present.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
