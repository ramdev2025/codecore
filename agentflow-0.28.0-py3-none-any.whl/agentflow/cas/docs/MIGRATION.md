# Migration

Coming from another AgentFlow backend? This page maps the concepts and gives you the YAML translations.

---

## From `sk` (Semantic Kernel)

SK and CAS are conceptually closest — both use agents + plugins + filters-or-hooks + MCP. The main differences:

| SK                                     | CAS equivalent                                                 |
| -------------------------------------- | -------------------------------------------------------------- |
| `backend: semantic-kernel`             | `backend: claude-agent-sdk`                                    |
| `mode: handoff` / `sequential` / ...   | main agent + `subagents:` (SDK delegates natively via `task`)  |
| `agents:` (list) with position-based roles | `agent:` (singular) + `subagents:` (dict)                  |
| `agent.plugins[].type: prompt`         | not supported in v1                                            |
| `agent.plugins[].type: openapi`        | not supported in v1                                            |
| `agent.plugins[].type: python` + `@kernel_function` | `agent.plugins[].type: python` + `@tool` (claude_agent_sdk) |
| `services:` (multi-service kernel)     | no equivalent — CAS is Claude-only                             |
| `memory:` (vector connector)           | not supported in v1 (SDK's research-preview `memory_store_id` will land later) |
| `filters:` (3 SK filter types)         | `agent.hooks:` (10 SDK event types) — richer                   |
| `guards:` / `optimizers:` / `observers:` | same — compiles to SDK hooks                                 |
| `mcp_servers:` (stdio / sse)           | `mcp_servers:` (stdio / sse / **http** too)                    |
| `execution_settings.function_choice_behavior` | not in CAS — SDK handles tool-calling internally           |
| `execution_settings.service_id`        | `llm.config.model` per agent                                   |

### Example: SK handoff → CAS main + subagents

**SK:**

```yaml
backend: semantic-kernel
mode: handoff

agents:
  - name: triage
    description: Routes requests
    system_prompt: "Call transfer_to_* to delegate."
    execution_settings: { function_choice_behavior: required }

  - name: billing
    description: Billing questions
    system_prompt: ...
    plugins: [{name: billing, type: python, module: myapp.billing}]

  - name: tech
    description: Tech questions
    system_prompt: ...
    plugins: [{name: tech, type: python, module: myapp.tech}]
```

**CAS:**

```yaml
backend: claude-agent-sdk

agent:
  name: triage
  system_prompt: "Delegate billing to billing, tech to tech."
  tools:
    builtin: [task]                  # enable subagent delegation
  plugins:
    - {name: billing, type: python, module: myapp.billing}
    - {name: tech,    type: python, module: myapp.tech}

subagents:
  billing:
    description: Billing questions
    prompt: You handle billing.
    mcp_servers: [billing]           # reference the plugin by name

  tech:
    description: Tech questions
    prompt: You handle tech.
    mcp_servers: [tech]
```

The CAS main agent delegates via the `Task` tool; the SDK enforces the routing natively. No `function_choice_behavior: required` trick needed.

---

## From `workflows` (LangGraph)

Workflows is graph-structured with explicit routing — CAS is agent-native. Many mappings are conceptual rather than mechanical.

| workflows                          | CAS equivalent                                              |
| ---------------------------------- | ----------------------------------------------------------- |
| `nodes:` + `depends_on:`           | main agent's `system_prompt` + `subagents:` (model handles flow) |
| `routes:` + `router_field`         | subagent delegation by description (model picks)            |
| `middleware: [...]`                | `agent.hooks:` OR `guards` / `optimizers` / `observers`     |
| `interrupt_before:` / `interrupt_after:` | `permission_mode: plan` on a subagent                 |
| `retry_policy`                     | `optimizers: [{type: tool_retry}]` (at tool level)          |
| `callbacks.structured_logging`     | `observers: [{type: audit_log}]` + `AGENTFLOW_LOG_LEVEL=INFO` |
| `callbacks.cost_tracking`          | `llm.config.max_budget_usd` + `observers: [{type: cost_tracking}]` |
| Graph state (`TypedDict`)          | `agent.output_format: {config: {type: json_schema, ...}}`   |

**When to stay on workflows, not migrate to CAS:**

- You need deterministic node-by-node control flow that doesn't tolerate model discretion
- You need cross-model flexibility (OpenAI + Anthropic + Azure in the same graph)
- You rely on LangGraph checkpointing with full state replay
- You have significant investment in LangChain tools or retrievers

**When CAS is the better fit:**

- Anthropic-only deployments where `claude-agent-sdk` native features (sandbox, skills, Task delegation, budget enforcement) matter
- You want Claude's native tool-calling and extended thinking
- You want token-level streaming with zero setup

---

## From `deep` (DeepAgents)

Deep and CAS are closely related — both are Claude-centric with subagent delegation. The main differences are framework-level:

| deep                              | CAS equivalent                                              |
| --------------------------------- | ----------------------------------------------------------- |
| DeepAgents `deepagents.create_deep_agent` | `CasAgentBuilder.from_yaml(...).build()`              |
| `agent:` + `subagents:` + `tools:` (builtin list) | Same YAML shape — nearly identical                 |
| DeepAgents middleware (`@agent_middleware`) | `agent.hooks:` (10 SDK events — richer)               |
| DeepAgents checkpointing (LangGraph SQLite) | `--thread-id` bridge to SDK session UUIDs             |
| TUI (textual)                     | streaming CLI renderer (spinners, subagent-progress indented) |
| LangChain tools (`@tool` from langchain_core) | CAS `@tool` from `claude_agent_sdk`                 |

**Migration is mostly mechanical** — the YAML shape is similar, the tool decorators are different. Rename imports and move `builtin` tool names to lowercase (CAS takes lowercase and translates).

### Example

**Deep:**

```yaml
agent:
  system_prompt: You coordinate.
  llm:
    provider: anthropic
    config: { model: claude-opus-4-7 }

tools:
  builtin: [read_file, write_file, execute]

subagents:
  enabled: true
  agents:
    - name: researcher
      description: Does research
      system_prompt: You research.
```

**CAS:**

```yaml
backend: claude-agent-sdk

llm:
  provider: anthropic
  config: { model: claude-opus-4-7 }

agent:
  name: main
  system_prompt: You coordinate.
  tools:
    builtin: [read, write, bash, task]   # `bash` = execute equivalent; `task` = delegation

subagents:
  researcher:
    description: Does research
    prompt: You research.
```

---

## Shared conventions across all backends

These don't change when you migrate:

- `backend:` literal at the top of the YAML
- `metadata: { version, name, description, tags }`
- `llm: { provider, config }` shape
- `--thread-id` for session resumption (bridged differently per backend, but same CLI contract)
- `--persistence memory / sqlite / postgres` + `AGENTFLOW_ENCRYPTION_KEY`
- `OTEL_TRACES_ENABLED` opt-in
- `guards` / `optimizers` / `observers` as the portable tier
- `mcp_servers:` for stdio / sse / http (CAS adds HTTP; SK has stdio/sse only)
- `agentflow` unified CLI with `--dry-run`, `--json`, `--interactive`, `--thread-id`

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
