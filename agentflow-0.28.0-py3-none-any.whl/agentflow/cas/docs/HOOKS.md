# Hooks

The Claude Agent SDK emits **10 semantic event types**. CAS exposes them as a first-class `agent.hooks:` block — users who want raw SDK expressiveness go straight to hooks; users who want portable cross-backend vocabulary use [`guards` / `optimizers` / `observers`](GUARDS.md), which compile **down** to hooks in this backend.

## The 10 events

| Event                    | When it fires                                                    | Typical uses                                      |
| ------------------------ | ---------------------------------------------------------------- | ------------------------------------------------- |
| `PreToolUse`             | Before any tool executes (main or subagent)                      | Safety gates, PII redaction, budget guards         |
| `PostToolUse`            | After a tool completes successfully                              | Audit log, latency tracking                        |
| `PostToolUseFailure`     | After a tool fails                                                | Retry, escalation, error reporting                 |
| `UserPromptSubmit`       | Before the user's prompt reaches the model                       | Input validation, PII redaction                    |
| `Stop`                   | When the agent stops (top-level agent)                            | Session-end logging                                |
| `SubagentStart`          | When a subagent begins                                            | Per-subagent telemetry start                       |
| `SubagentStop`           | When a subagent ends                                              | Per-subagent telemetry flush                       |
| `PreCompact`             | Before the SDK compacts conversation history                      | Snapshot context for audit                         |
| `Notification`           | Custom notification stream                                        | External dashboards                                |
| `PermissionRequest`      | When interactive approval is needed (depends on `permission_mode`) | Route approvals to a UI or external service      |

## YAML shape

```yaml
agent:
  hooks:
    - event: PreToolUse
      matcher: "^Bash$"         # regex; for tool-scoped events matches tool_name
      module: myapp.hooks       # Python module
      function: check_safety    # async function in the module
      timeout: 5                # seconds, must be >= 1
```

| Field      | Required | Notes                                                       |
| ---------- | -------- | ----------------------------------------------------------- |
| `event`    | ✅       | One of the 10 above                                         |
| `matcher`  |          | Regex. For `PreToolUse` / `PostToolUse` / `PostToolUseFailure`, matched against `tool_name`. Omit for broad matching. |
| `module`   | ✅       | Python import path                                          |
| `function` | ✅       | Async function name in the module                           |
| `timeout`  |          | Defaults to 30s (SDK-enforced)                              |

## Hook function signature

Each hook function is `async def f(input_data, tool_use_id, context)` and returns a dict. An empty dict `{}` means "allow / no-op". Specific return shapes control behavior per event:

```python
# PreToolUse — block a tool call
async def check_safety(input_data, tool_use_id, context):
    if "rm -rf" in input_data.get("tool_input", {}).get("command", ""):
        return {"decision": "block", "reason": "unsafe bash command"}
    return {}

# UserPromptSubmit — redact the prompt before the model sees it
async def redact_pii(input_data, tool_use_id, context):
    prompt = input_data.get("prompt", "")
    redacted = _redact(prompt)
    if redacted != prompt:
        return {"hookSpecificOutput": {"updatedPrompt": redacted}}
    return {}

# PostToolUseFailure — request a retry
async def retry_on_fail(input_data, tool_use_id, context):
    return {"decision": "retry", "reason": "transient error"}
```

## SDK input dicts

Each hook receives a typed `input_data` dict — only the fields listed are available:

| Event                   | Available keys                                                           |
| ----------------------- | ------------------------------------------------------------------------ |
| `PreToolUse`            | `session_id`, `transcript_path`, `cwd`, `agent_id`, `agent_type`, `tool_name`, `tool_input`, `tool_use_id`, `hook_event_name` |
| `PostToolUse`           | same + `tool_response` (**not** `tool_result`)                           |
| `PostToolUseFailure`    | same + `tool_response`, error details                                    |
| `UserPromptSubmit`      | `session_id`, `cwd`, `prompt`, `hook_event_name`                         |
| `Stop`                  | `session_id`, `cwd`, `permission_mode`, `stop_hook_active` (no usage/cost — see below) |
| `SubagentStart`         | `session_id`, `cwd`, `agent_id`, `agent_type`                            |
| `SubagentStop`          | `session_id`, `cwd`, `agent_id`, `agent_type`                            |
| `PreCompact`            | `session_id`, `cwd`, `message_count`                                     |

!!! warning "Cost and usage are NOT on Stop hooks"
    Token usage, duration, and `total_cost_usd` live on the stream's **`ResultMessage`**, not on `StopHookInput`. CAS intercepts the `ResultMessage` in the CLI driver and attaches the data to the root `agentflow.cas.run` span + a `gen_ai.session_summary` child span. See [Observability](OBSERVABILITY.md).

## Regex matchers

For tool-scoped events, `matcher` is a regex against `tool_name`:

```yaml
hooks:
  - event: PreToolUse
    matcher: "^Bash$"              # exact match
    module: m; function: check_bash

  - event: PreToolUse
    matcher: "^(Write|Edit)$"      # any write tool
    module: m; function: check_writes

  - event: PreToolUse
    matcher: "^mcp__.*"            # any MCP tool
    module: m; function: log_mcp
```

Matcher is compiled client-side by the SDK. Multiple hooks for the same event run in YAML order.

## Relationship to `guards` / `optimizers` / `observers`

The cross-backend portable tier compiles down to hooks. Example compilations:

| Portable entry                                   | Compiled hook event       | Behavior                                            |
| ------------------------------------------------ | ------------------------- | --------------------------------------------------- |
| `guards: [{type: tool_call_limit, config: {max_calls: 50}}]` | `PreToolUse`        | Blocks calls past the limit                         |
| `guards: [{type: pii, config: {patterns: [email]}}]`          | `UserPromptSubmit`  | Returns `{hookSpecificOutput.updatedPrompt}` with redaction |
| `optimizers: [{type: tool_retry, config: {max_retries: 2}}]`  | `PostToolUseFailure` | Returns `{decision: retry}` with exponential backoff |
| `observers: [{type: audit_log}]`                 | `PreToolUse` + `PostToolUse` | Logs start/end + emits spans                   |
| `observers: [{type: latency_tracking}]`          | `PreToolUse` + `PostToolUse` | Measures per-tool latency                      |
| `observers: [{type: cost_tracking}]`             | `Stop` (+ ResultMessage)  | Emits a session-summary span with usage/cost        |

User-declared `agent.hooks:` run **before** compiled ones per event (same-event merge order = explicit first).

## Custom guards / optimizers / observers

Bring your own hook — point `module`/`function` at a regular async function and choose the `guard` / `optimizer` / `observer` type most appropriate:

```yaml
guards:
  - type: content_filter          # requires a custom implementation
    module: myapp.filters
    function: block_secrets
```

The compiler wraps your callable in a safe adapter so errors don't break the agent.

---

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
