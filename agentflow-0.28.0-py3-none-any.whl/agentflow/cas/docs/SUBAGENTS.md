# Subagents

A **subagent** is a specialist Claude agent the main (orchestrator) agent can delegate to. Subagents are declared at the top level of the YAML as a dict keyed by name, and surfaced to the main agent via the SDK's built-in `Task` tool.

## Why subagents?

- **Specialization** — each subagent has a focused system prompt, tool set, and (optionally) cheaper model
- **Isolation** — a subagent's tool calls run in its own SDK context; hooks and filters still fire
- **Cost control** — send research tasks to Sonnet, keep Opus for orchestration
- **Parallelism** — `background: true` subagents can be invoked concurrently

## Minimal example

```yaml
agent:
  name: orchestrator
  system_prompt: |
    Route research questions to `researcher`.
    Route coding tasks to `coder`.
  tools:
    builtin: [task]               # ← required for delegation

subagents:
  researcher:
    description: Searches the web and summarizes sources
    prompt: You research carefully and cite sources inline.
    tools: [web_search, web_fetch, read]
    model: claude-sonnet-4-6
    max_turns: 10

  coder:
    description: Writes and edits code in this repo
    prompt: You follow the project's style guide and write tests.
    tools: [read, write, edit, grep, glob, bash]
    model: claude-opus-4-7
    permission_mode: acceptEdits
    max_turns: 20
```

When the orchestrator delegates, the CLI renders `↳ delegate to researcher · "<description>"`, then each of the subagent's tool calls appears indented.

## All supported fields

```yaml
subagents:
  <name>:
    description: str             # required — shown to the router
    prompt: str                  # required — subagent system prompt
    tools: [bash, read, ...]     # optional — same enum as main agent
    disallowed_tools: [write]    # optional deny-list
    model: str                   # e.g. claude-sonnet-4-6
    skills: [a, b]               # SDK skills to load
    memory: user | project | local  # SDK memory scope
    mcp_servers: [name, ...]     # reference top-level mcp_servers OR plugin names
    initial_prompt: str          # runs before the first user turn
    max_turns: int               # iteration cap for this subagent
    background: bool             # run concurrently with sibling subagents
    effort: low|medium|high|max  # thinking-effort preset (or int)
    permission_mode: default     # overrides main agent's mode
```

Field names are snake_case in YAML; the builder translates them to the SDK's camelCase (`maxTurns`, `initialPrompt`, `permissionMode`, `mcpServers`, `disallowedTools`) in the `AgentDefinition` it constructs.

## Sharing plugins and MCP servers

Subagents can reference either **top-level `mcp_servers:`** entries OR **`agent.plugins:`** entries by name — the schema validator checks both:

```yaml
agent:
  name: main
  tools:
    builtin: [task]
  plugins:
    - name: pharma_tools            # this becomes an MCP server too
      type: python
      module: myapp.pharma

mcp_servers:
  external-db:
    transport: http
    url: https://api.example.com/mcp

subagents:
  analyst:
    description: Analyzes pharma data
    prompt: You analyze.
    mcp_servers: [pharma_tools, external-db]   # ← references both
```

The main agent's Python plugins get registered as in-process MCP SDK servers, so they show up alongside the explicit MCP servers. Subagents pick the ones they need.

## Runtime lifecycle

At runtime, three SDK message types surface subagent lifecycle:

| SDK message                    | What it means                              | CLI rendering                      |
| ------------------------------ | ------------------------------------------ | ---------------------------------- |
| `TaskStartedMessage`           | Subagent is spinning up                    | `▶ subagent · <description>`       |
| `TaskProgressMessage`          | Subagent just called a tool                | `  · <last_tool_name>`             |
| `TaskNotificationMessage`      | Subagent finished (completed/failed/stopped) | `✓ subagent · completed: <summary>` |

All three are rendered inline by the CAS CLI streamer, so users see per-subagent progress during long runs. See also the OTel span model in [Observability](OBSERVABILITY.md): delegations show up as `gen_ai.execute_tool Agent` spans nested under the root.

## Parallelism via `background`

When multiple subagents are tagged `background: true`, the SDK can invoke them concurrently:

```yaml
subagents:
  fetcher:
    description: Fetches upstream data
    prompt: ...
    background: true

  validator:
    description: Validates against policy
    prompt: ...
    background: true
```

The orchestrator can fire both with consecutive `Task` calls and the SDK parallelizes them. Their outputs merge at the next orchestrator turn.

## Permission modes per subagent

One of the most useful subagent controls: give a planner subagent `permission_mode: plan` so it can't actually execute anything, then have the orchestrator act on its plan.

```yaml
subagents:
  planner:
    description: Plans changes without executing
    prompt: You propose a plan. Never write files.
    permission_mode: plan           # SDK blocks all tool execution

  executor:
    description: Executes approved plans
    prompt: You follow the approved plan exactly.
    permission_mode: acceptEdits
```

## What subagents **can't** do (today)

- **Have their own `hooks:`** — hooks are set on the main agent's options and apply globally (including to subagent tool calls via `parent_tool_use_id` in the hook input)
- **Override `cwd` / `add_dirs` / `sandbox`** — these are session-wide in the SDK
- **Use a different `output_format`** — structured output is session-scoped
- **Set their own `user`** — actor identity is session-scoped

These are SDK limitations, not agentflow choices.

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
