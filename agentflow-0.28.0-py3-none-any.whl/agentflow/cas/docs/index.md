# AgentFlow CAS

**YAML-driven agents on the [Claude Agent SDK](https://pypi.org/project/claude-agent-sdk/).**

AgentFlow CAS lets you define Claude-powered agents — with subagents, custom Python tools, and GxP-grade guardrails — in YAML, without writing SDK boilerplate. It's the fourth backend of the AgentFlow framework, sitting alongside `workflows` (LangGraph), `deep` (DeepAgents), and `sk` (Semantic Kernel).

## Install

```bash
pip install agentflow[claude-agent-sdk]
```

This pulls in `claude-agent-sdk>=0.1.64` and nothing else — no LangChain, no LangGraph, no Semantic Kernel. Each backend is isolated so you only install what you use.

## Quick Start

1. **Create a YAML config** (`cas_agent.yaml`):

    ```yaml
    backend: claude-agent-sdk

    metadata:
      version: "1.0"
      name: research-assistant

    llm:
      provider: anthropic
      config:
        model: claude-opus-4-7
        api_key: ${ANTHROPIC_API_KEY}

    agent:
      name: researcher
      system_prompt: |
        You are a research assistant. Use your tools to answer questions.
      tools:
        preset: claude_code     # bash/read/grep/glob/web_search/...
    ```

2. **Run it**:

    ```bash
    agentflow --yaml cas_agent.yaml "Summarize the README in this repo."
    ```

3. **Or from Python**:

    ```python
    import asyncio
    import agentflow

    async def main():
        runner = await agentflow.create("cas_agent.yaml")
        async for message in runner.query("Summarize the README."):
            print(message)

    asyncio.run(main())
    ```

## What's Supported

- **Main agent + subagents** — the SDK's native `agents:` map, one orchestrator with specialist delegates
- **Rich LLM controls** — `model` + `fallback_model`, `max_budget_usd` (hard-stop), `max_turns`, `thinking` (adaptive / enabled / disabled), `effort`, extended thinking, beta opt-ins
- **Full tool surface** — 11 built-in SDK tools (bash, read, write, edit, glob, grep, web_fetch, web_search, task, todo_write, exit_plan_mode), the `claude_code` preset, custom Python `@tool` plugins
- **First-class hooks (10 events)** — PreToolUse, PostToolUse, PostToolUseFailure, UserPromptSubmit, Stop, SubagentStart, SubagentStop, PreCompact, Notification, PermissionRequest
- **Permissions** — 6 modes (`default`/`acceptEdits`/`plan`/`dontAsk`/`bypassPermissions`/`auto`), allow/deny lists, custom `can_use_tool` callback
- **MCP** — stdio / SSE / HTTP transports; subagents can reference servers by name
- **Sandbox** — network allow/deny, excluded commands, nested-sandbox toggle
- **Skills + settings sources** — load SDK skills, choose user/project/local precedence
- **Persistence** — memory / SQLite / PostgreSQL, AES-GCM at rest; `--thread-id` bridges to SDK session UUIDs
- **OpenTelemetry** — tool spans, session summary with token + cost breakdown per model, root `agentflow.cas.run` span
- **Cross-backend plugin bridge** — existing AgentFlow lifecycle plugins (telemetry, logging) work on CAS agents
- **Structured output** — passthrough `output_format` for JSON-schema-enforced responses

## Next Steps

- [Getting Started](GETTING_STARTED.md) — install and first agent
- [YAML Reference](YAML_REFERENCE.md) — full schema
- [Subagents](SUBAGENTS.md) — the main agent + delegates pattern
- [Hooks](HOOKS.md) — the 10 first-class events
- [Full Example](FULL_EXAMPLE.md) — enterprise YAML exercising every feature
- [Migration](MIGRATION.md) — from `workflows`, `deep`, or `sk`

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
