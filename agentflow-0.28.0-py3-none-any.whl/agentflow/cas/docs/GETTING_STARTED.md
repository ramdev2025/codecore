# Getting Started

Build and run your first Claude Agent SDK backend in five minutes.

## 1. Install

Python 3.10–3.13 are supported.

```bash
pip install agentflow[claude-agent-sdk]
```

Also export your Anthropic API key (the SDK reads it from the environment):

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

## 2. Minimal agent

Save as `cas_agent.yaml`:

```yaml
backend: claude-agent-sdk

metadata:
  version: "1.0"
  name: hello-agent

llm:
  provider: anthropic
  config:
    model: claude-opus-4-7
    api_key: ${ANTHROPIC_API_KEY}

agent:
  name: main
  system_prompt: |
    You are a concise assistant. Use the file tools if asked.
  tools:
    preset: claude_code
```

Validate it without calling the API:

```bash
agentflow --yaml cas_agent.yaml --dry-run
```

Run a single query:

```bash
agentflow --yaml cas_agent.yaml "List the top-level files in this repo."
```

You'll see each tool call streamed as it happens, then the final answer.

## 3. Add a custom Python tool

Create `tools/weather.py`:

```python
from claude_agent_sdk import tool

@tool(
    "get_weather",
    "Look up the current weather for a city.",
    {"city": str},
)
async def get_weather(args):
    # Replace with a real API call
    return {"content": [{"type": "text", "text": f"Weather in {args['city']}: 72°F sunny"}]}
```

Register it in the YAML:

```yaml
agent:
  name: main
  system_prompt: You answer questions, using tools when helpful.
  plugins:
    - name: weather
      type: python
      module: tools.weather
```

Run from the directory containing `tools/`:

```bash
agentflow --yaml cas_agent.yaml "What's the weather in Tokyo?"
```

Plugins become in-process MCP servers on the agent's Kernel — no subprocess, no network round-trip.

## 4. Add a subagent

Subagents are callable specialists. Declare them at the top level and enable the `task` tool so the main agent can delegate:

```yaml
agent:
  name: orchestrator
  system_prompt: Route research questions to the researcher subagent.
  tools:
    builtin: [task]            # only the delegation tool

subagents:
  researcher:
    description: Searches the web and summarizes.
    prompt: You research carefully and cite sources.
    tools: [web_search, web_fetch]
    model: claude-sonnet-4-6
    max_turns: 10
```

Run:

```bash
agentflow --yaml cas_agent.yaml "Summarize recent MCP protocol updates."
```

The orchestrator now delegates to `researcher` via the `Task` tool. You'll see `↳ delegate to researcher · …` in the output.

See [Subagents](SUBAGENTS.md) for the full pattern.

## 5. Enable guardrails + observability

```yaml
guards:
  - type: tool_call_limit
    config: { max_calls: 50 }
  - type: pii
    config: { patterns: [email, phone, ssn] }

observers:
  - type: audit_log
  - type: cost_tracking
```

Opt into tracing via env vars:

```bash
export OTEL_TRACES_ENABLED=true
export OTEL_SERVICE_NAME=my-cas-agent
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

See [Observability](OBSERVABILITY.md) for the span catalog and more collectors.

## 6. Persist conversations

```bash
# Resume the same session across runs with --thread-id
agentflow --yaml cas_agent.yaml --thread-id my-session "Hello"
agentflow --yaml cas_agent.yaml --thread-id my-session "What did I just say?"
```

AgentFlow stores `thread_id → SDK session id` in SQLite by default. Switch to PostgreSQL or add AES encryption with the standard env vars. See [Persistence](PERSISTENCE.md).

## Next Steps

- [YAML Reference](YAML_REFERENCE.md) — every field, grouped by section
- [Full Example](FULL_EXAMPLE.md) — enterprise config using every feature
- [Production Features](PRODUCTION_FEATURES.md) — the full enterprise matrix
- [Migration](MIGRATION.md) — coming from a different backend

## License

This project is governed by the Accenture Internal Open-source Agreement. See [LICENSE.md](LICENSE.md) for complete
terms and conditions.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
