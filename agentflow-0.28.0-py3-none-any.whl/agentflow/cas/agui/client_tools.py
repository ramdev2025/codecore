"""Frontend-implemented (client-side) tool stubs for the CAS AG-UI bridge.

CAS tools are ``SdkMcpTool`` instances bundled into an in-process MCP
server and registered on ``ClaudeAgentOptions.mcp_servers``. To
implement client_tools on CAS we register each declared
``ClientToolConfig`` as an ``SdkMcpTool`` whose async handler raises
:class:`ClientToolPause`. The CAS AG-UI orchestrator catches the
pause mid-``query()``, emits an AG-UI Interrupt event, and ends the
run. The browser executes the tool and posts the result back on the
next request; the orchestrator injects it as the assistant's next
turn input.

This is the CAS analogue of the LangGraph ``interrupt(...)`` /
SK ``ClientToolPause`` primitive — three different runtimes, same
contract on the AG-UI wire.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agentflow.genui import ClientToolConfig

logger = logging.getLogger(__name__)


class ClientToolPause(Exception):
    """Raised by a client_tool stub body to pause the agent run.

    The CAS AG-UI orchestrator catches this exception while iterating
    over ``query()`` and emits an AG-UI Interrupt with the tool name
    and args. The browser-side handler runs; the orchestrator resumes
    on the next request by injecting the tool result.
    """

    def __init__(self, tool_name: str, args: dict[str, Any]) -> None:
        super().__init__(f"client_tool pause: {tool_name}({args})")
        self.tool_name = tool_name
        self.tool_args = args


_JSON_SCHEMA_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "array": list,
    "object": dict,
}


def build_client_tool_sdk_tools(specs: list["ClientToolConfig"]) -> list[Any]:
    """Build one ``SdkMcpTool`` per ``ClientToolConfig`` whose handler
    raises ``ClientToolPause``.

    Called by the CAS AG-UI router at orchestrator-build time when
    ``bind_client_tools=True``. Each tool is added to the same in-
    process MCP server that hosts the ``ui_tools`` so the LLM sees
    them as ordinary callable tools.
    """
    from claude_agent_sdk import tool as cas_tool

    tools: list[Any] = []
    for spec in specs:
        tools.append(_make_sdk_tool(spec, cas_tool))
    return tools


def _make_sdk_tool(spec: "ClientToolConfig", cas_tool: Any) -> Any:
    """Build one SdkMcpTool whose handler raises ClientToolPause."""
    input_schema = _input_schema_from_json_schema(spec.parameters)
    tool_name = spec.name

    @cas_tool(tool_name, spec.description or "", input_schema)
    async def handler(args: dict[str, Any]) -> dict[str, Any]:
        # Raise to signal the pause. The orchestrator catches this
        # while consuming ``query()`` and emits an AG-UI Interrupt.
        raise ClientToolPause(tool_name=tool_name, args=dict(args or {}))

    handler._agentflow_client_tool = True  # type: ignore[attr-defined]
    return handler


def _input_schema_from_json_schema(parameters: dict[str, Any]) -> dict[str, Any]:
    """Translate a ``ClientToolConfig.parameters`` JSON Schema object
    into CAS's simple ``{name: type}`` form.

    CAS accepts either a full JSON Schema or the simpler form where
    each value is a Python type (``str`` / ``int`` / ``float`` /
    ``bool`` / ``list`` / ``dict``). We use the simple form here for
    parity with ``agentflow.cas.genui``.
    """
    props: dict[str, Any] = parameters.get("properties") or {}
    schema: dict[str, Any] = {}
    for name, prop_schema in props.items():
        py_type = _JSON_SCHEMA_TYPE_MAP.get(prop_schema.get("type", "string"), str)
        schema[name] = py_type
    return schema


def build_client_tool_result_text(tool_call_id: str, content: Any) -> str:
    """Render a client_tool's browser result back into a prompt-injectable
    string for CAS's next ``query()`` call.

    CAS doesn't expose a structured ``role:"tool"`` channel in its
    public API (the SDK manages tool execution internally), so when
    the browser returns a result we inject it as a user message
    preamble like ``Tool result for X: <content>``. The agent picks
    up where it left off.
    """
    if isinstance(content, (dict, list)):
        body = json.dumps(content)
    else:
        body = str(content)
    return body
