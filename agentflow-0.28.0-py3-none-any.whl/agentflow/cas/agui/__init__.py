"""AG-UI bridge for the CAS (Claude Agent SDK) backend.

Brings the AG-UI HTTP+SSE protocol to YAML-driven Claude Agent SDK
agents. AgentFlow owns the bridge — no published upstream AG-UI
package exists for the Claude Agent SDK, so this sub-package carries
the full implementation:

  * :mod:`events` — Pydantic wire models for AG-UI events
  * :mod:`adapter` — stateful event translator from orchestrator
    events to AG-UI wire events
  * :mod:`client_tools` — ``ClientToolPause``-raising
    ``SdkMcpTool`` stubs registered on the in-process MCP server
  * :mod:`router` — FastAPI router + ``build_agui`` public entrypoint

The public entrypoint is :func:`build_agui`. Mount the returned
``(router, lifespan)`` into your own FastAPI app::

    from fastapi import FastAPI
    from agentflow.cas.agui import build_agui

    router, lifespan = build_agui(yaml_path="agent.yaml")
    app = FastAPI(lifespan=lifespan)
    app.include_router(router, prefix="/agui")

What CAS gets vs the LangGraph-based bridges
--------------------------------------------

  * ``ui_tools`` ✓ — same cross-backend YAML, ``@ui_component``
    fetchers become ``SdkMcpTool`` instances bundled into the
    ``ui_tools`` in-process MCP server.
  * Block-level text streaming ✓ — CAS doesn't stream tokens; we
    surface ``TextBlock`` contents as ``token`` events as they
    arrive in the message stream.
  * Tool call lifecycle ✓ — translated from ``ToolUseBlock`` (in
    ``AssistantMessage.content``) and ``ToolResultBlock`` (in the
    follow-up ``UserMessage.content``).
  * ``client_tools`` ✓ — exception-based pause via ``ClientToolPause``
    raised inside the MCP worker, caught at the orchestrator layer
    and re-surfaced as an AG-UI Interrupt.
  * ``available_when`` (build-time only — CAS doesn't have a clean
    per-call hide-from-list hook; same caveat as MAF / SK).
  * State persistence: in-memory only (CAS has no checkpointer).
"""

from .adapter import AGUIAdapter, translate_stream
from .client_tools import (
    ClientToolPause,
    build_client_tool_result_text,
    build_client_tool_sdk_tools,
)
from .events import (
    AGUIEvent,
    CustomEvent,
    EventType,
    Interrupt,
    InterruptOutcome,
    RunError,
    RunFinished,
    RunStarted,
    StateDelta,
    StateSnapshot,
    TextMessageContent,
    TextMessageEnd,
    TextMessageStart,
    ToolCallArgs,
    ToolCallEnd,
    ToolCallResult,
    ToolCallStart,
    render_component,
)
from .router import build_agui

__all__ = [
    "AGUIAdapter",
    "AGUIEvent",
    "ClientToolPause",
    "CustomEvent",
    "EventType",
    "Interrupt",
    "InterruptOutcome",
    "RunError",
    "RunFinished",
    "RunStarted",
    "StateDelta",
    "StateSnapshot",
    "TextMessageContent",
    "TextMessageEnd",
    "TextMessageStart",
    "ToolCallArgs",
    "ToolCallEnd",
    "ToolCallResult",
    "ToolCallStart",
    "build_agui",
    "build_client_tool_result_text",
    "build_client_tool_sdk_tools",
    "render_component",
    "translate_stream",
]
