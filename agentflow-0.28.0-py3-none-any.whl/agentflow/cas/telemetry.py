"""OpenTelemetry setup for the CAS backend.

Mirrors ``agentflow.sk.telemetry`` — install a global ``TracerProvider`` with
an OTLP exporter when ``OTEL_TRACES_ENABLED=true``. The Claude Agent SDK
doesn't ship its own GenAI diagnostics today, so our hook bridge, plugin
bridge, and observers emit spans directly via the provider.

The CLI calls :func:`setup_tracing` once per run before the agent is built.
Subsequent calls in the same process are no-ops (idempotent).
"""

from __future__ import annotations

import os
from typing import Optional

_initialized = False


def setup_tracing(service_name: Optional[str] = None) -> bool:
    """Install an OpenTelemetry TracerProvider if ``OTEL_TRACES_ENABLED=true``.

    Reads standard OTEL env vars (``OTEL_EXPORTER_OTLP_ENDPOINT``,
    ``OTEL_EXPORTER_OTLP_PROTOCOL``, ``OTEL_SERVICE_NAME``, etc.). Returns
    True if tracing was enabled.
    """
    global _initialized
    if _initialized:
        return True

    if os.getenv("OTEL_TRACES_ENABLED", "false").lower() != "true":
        return False

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.resources import SERVICE_NAME, SERVICE_VERSION, Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except ImportError:
        print(
            "OTEL_TRACES_ENABLED=true but opentelemetry is not installed. "
            "Install with: pip install opentelemetry-api opentelemetry-sdk "
            "opentelemetry-exporter-otlp"
        )
        return False

    resolved_service_name = service_name or os.getenv("OTEL_SERVICE_NAME", "agentflow")
    resource = Resource.create(
        {SERVICE_NAME: resolved_service_name, SERVICE_VERSION: "1.0.0"}
    )

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)

    # Exporter seam: attach registered / entry-point-discovered processors
    # (e.g. Azure Monitor via agentflow[azure-monitor]) additively; skip the
    # default OTLP sink when no endpoint is configured but a seam processor is
    # present, so Azure-only apps don't spam localhost:4317. The seam owns
    # provider tracking + atexit shutdown so late registrations reach it.
    from agentflow.core import telemetry_seam as _seam
    otlp_attached = _seam.attach_seam_processors(
        provider,
        default_factory=lambda: BatchSpanProcessor(_create_exporter()),
    )

    print("OpenTelemetry tracing enabled")
    print(f"  Service: {resolved_service_name}")
    if otlp_attached:
        protocol = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
        endpoint = os.getenv(
            "OTEL_EXPORTER_OTLP_ENDPOINT",
            "http://localhost:4317" if protocol == "grpc" else "http://localhost:4318",
        )
        print(f"  Endpoint: {endpoint} ({protocol})")
    else:
        print("  Default OTLP sink: skipped (no OTEL_EXPORTER_OTLP_ENDPOINT set)")
    print("  CAS spans: tool calls + hook lifecycle + cost tracking")

    _initialized = True
    return True


def _create_exporter():
    """Create an OTLP exporter. Reads endpoint/headers from OTEL env vars."""
    protocol = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
    if protocol == "http/protobuf":
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    else:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    return OTLPSpanExporter()
