# AgentFlow CAS

**YAML-driven agents on the [Claude Agent SDK](https://pypi.org/project/claude-agent-sdk/).**

Fourth backend of AgentFlow, alongside `workflows` (LangGraph), `deep` (DeepAgents), and `sk` (Semantic Kernel). Install with `pip install agentflow[claude-agent-sdk]`.

> **Status: in development.** This README documents the target design and the decisions already locked in. Implementation is in progress — see the phases in `.claude/skills/add-backend/SKILL.md`.

---

## Supported features (v1 target — GA only)

These are the features from the Claude Agent SDK that v1 will expose in YAML. All are **GA** in the SDK.

| Feature                          | YAML surface                                   | Notes                                                             |
| -------------------------------- | ---------------------------------------------- | ----------------------------------------------------------------- |
| Model selection                  | `llm.config.model`                             | Anthropic direct (`claude-opus-4-7`, `claude-sonnet-4-6`, …)      |
| Model selection + fallback       | `llm.config.model` / `fallback_model`          | Primary + automatic fallback model                                |
| Cost budget enforcement          | `llm.config.max_budget_usd`                    | Hard-stop when exceeded; SDK-native                               |
| Max turn limit                   | `llm.config.max_turns`                         | Iteration cap per run                                             |
| Extended thinking                | `llm.config.thinking` / `effort`               | `enabled` with budget, `adaptive`, or `disabled`; effort preset   |
| Beta feature opt-in              | `llm.config.betas[]`                           | Passthrough list (e.g. `context-1m-2025-08-07`)                   |
| Single-agent main + subagents    | `agent:` + `subagents:` (dict)                 | Native SDK `agents:` map — subagents callable by name from main   |
| Working-directory sandboxing     | `agent.cwd` + `agent.add_dirs`                 | Tools scoped to cwd plus explicit extra dirs                      |
| Full sandbox settings            | `agent.sandbox.*`                              | `enabled`, `excluded_commands`, `network`, nested-sandbox toggle  |
| Built-in tool suite (8)          | `agent.tools.builtin` + `tools.disabled`       | bash, read, write, edit, glob, grep, web_fetch, web_search        |
| Tool preset shortcut             | `agent.tools.preset: claude_code`              | Hands the SDK its Claude-Code bundle                              |
| Custom Python tools              | `agent.plugins[].type: python`                 | `@tool`-decorated functions                                       |
| Skills loading                   | `agent.skills: "all"` / `[...]`                | Load named Anthropic skills (or all)                              |
| Settings precedence              | `agent.setting_sources[]`                      | `user` / `project` / `local` layers                               |
| Multi-tenant user identity       | `agent.user`                                   | SDK `user` field for attribution                                  |
| Structured output                | `agent.output_format.config`                   | Passthrough dict for SDK's `output_format`                        |
| MCP servers                      | `mcp_servers:` (stdio / sse / http)            | First-class HTTP + SSE; subagents can reference by name           |
| Permission modes (6)             | `agent.permissions.mode`                       | `default` / `acceptEdits` / `plan` / `dontAsk` / `bypassPermissions` / `auto` |
| Tool allow / disallow lists      | `agent.permissions.allowed_tools` / `disallowed_tools` | Lists enforced by the SDK                                 |
| Custom permission handler        | `agent.permissions.can_use_tool`               | Points to an async Python function                                |
| Permission prompt tool           | `agent.permissions.prompt_tool_name`           | MCP tool used for interactive approval                            |
| Hooks (10 event types)           | `agent.hooks[]`                                | `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `UserPromptSubmit`, `Stop`, `SubagentStart`, `SubagentStop`, `PreCompact`, `Notification`, `PermissionRequest` |
| Token-streaming                  | automatic                                      | `include_partial_messages=True` on by default                     |
| Session resumption               | `--thread-id`                                  | Bridged to SDK session UUIDs — see decisions below                |
| Cross-backend persistence        | SQLite / PostgreSQL / memory                   | Same interface as other backends; metadata layer over SDK sessions |
| AES-GCM encryption at rest       | `AGENTFLOW_ENCRYPTION_KEY`                     | Same convention as other backends                                 |
| OpenTelemetry tracing            | `OTEL_TRACES_ENABLED=true`                     | Same convention as other backends                                 |
| Cross-cutting guards / observers | `guards:` / `observers:`                       | Compile *down* to hooks — see decisions below                     |

---

## Deferred / behind a future feature flag

These exist in the Claude Agent SDK family but are **Research Preview** or require the Managed Agents API. They will land behind an explicit opt-in once Anthropic moves them to GA.

| Feature                        | Status in SDK            | Planned v2 surface                                            |
| ------------------------------ | ------------------------ | ------------------------------------------------------------- |
| Managed Agents API (remote)    | Research Preview         | `backend: claude-agent-sdk` + `managed: true`                 |
| Bedrock / Vertex model routing | Via Managed Agents API   | `llm.provider: bedrock` / `vertex` once Managed is enabled    |
| Memory stores (persistent)     | Research Preview         | `memory:` block with `memory_store_id`                        |
| File checkpointing (CLI mode)  | Research Preview         | `llm.config.enable_file_checkpointing: true`                  |
| Vault-stored MCP OAuth tokens  | Research Preview         | `mcp_servers[].auth.vault`                                    |
| Pluggable `session_store`      | GA but niche             | `persistence.backend: sdk_session_store`                      |

---

## Not supported (SDK limitations)

| Gap                                | Workaround                                                            |
| ---------------------------------- | --------------------------------------------------------------------- |
| Sync API                           | SDK is async-only; `agentflow.create()` returns an async runner       |
| Fallback models                    | Not provided by SDK; may add at agentflow layer in a future release   |
| Explicit retry configuration       | SDK retries transient errors opaquely; no tuning knobs                |
| Per-tool cost breakdown            | Only per-session `total_cost_usd`; we surface what the SDK provides   |
| True token-level streaming         | SDK streams message blocks; `include_partial_messages=True` gets us closer but still coarser than SK |

---

## Key design decisions

Decisions taken before implementation. Each links to the consequence in the schema.

### 1. API surface — **SDK client only in v1**

The Claude Agent SDK has two APIs: the local `ClaudeSDKClient` (GA) and the Managed Agents API (Research Preview, remote). We ship the GA surface first. Managed Agents — with Bedrock/Vertex routing and persistent memory stores — lands later behind a YAML flag (see Deferred table above).

> **Consequence:** v1 supports only Anthropic direct (via `ANTHROPIC_API_KEY` or Claude subscription OAuth). No Bedrock, no Vertex. Subagents *are* supported — the SDK client exposes `agents: dict[str, AgentDefinition]` natively, which we surface as the top-level `subagents:` block.

### 2. Session model — **bridge, don't replace**

The SDK persists sessions to a local `.claude/` directory with its own UUIDs. Our other backends use a thread-id + SQLite/Postgres model. Rather than fork the user contract, we bridge:

- `--thread-id` remains the public surface across all four backends
- Internally, `cas` maps `thread-id → SDK session UUID` in the SQLite persistence layer
- The SDK's own session directory is treated as an implementation detail

> **Consequence:** users don't learn a new persistence model when they switch backends. `AGENTFLOW_ENCRYPTION_KEY`, `CHECKPOINTER_DB_PATH`, `POSTGRES_CONNECTION_STRING` all work here too.

### 3. Streaming — **`include_partial_messages=True` by default**

The SDK streams *message blocks*, not tokens. Setting `include_partial_messages=True` yields partial blocks as they arrive, which is closer to true token streaming but still coarser than SK.

> **Consequence:** `cas` output renders in reasonably small chunks; the trade-off (slightly more event volume, partial text that may be edited mid-stream) is documented in `docs/OBSERVABILITY.md`.

### 4. Hooks are first-class, not hidden under guards / observers

The SDK's hook system has 10 semantic event types (`PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop`, `SubagentStart`, `SubagentStop`, `PreCompact`, `Notification`, `PermissionRequest`, `PostToolUseFailure`) with regex matchers and timeouts. That's richer than SK's three filter categories.

Rather than flatten it into `guards: / optimizers: / observers:`, we expose a dedicated `agent.hooks:[]` block. Cross-cutting concerns still exist, but they **compile down to hooks** under the hood — the reverse of the SK direction, where guards/observers are the primitive and filters are the mechanism.

> **Consequence:** users who want SDK-native expressiveness use `hooks:`. Users who want cross-backend portability use `guards:` / `observers:` and get a sensible default hook compilation.

### 5. Tool selection — **opt-out, not opt-in**

Built-in tools are listed on the agent by default. Users **disable** specific ones via `tools.disabled:`, matching the SDK's own "enable all, disable individually" model.

> **Consequence:** less boilerplate for the common case (use everything), explicit intent when restricting. Contrast with other backends where tools are explicitly registered.

### 6. `max_budget_usd` lives under `llm.config`

Budget enforcement feels cross-cutting, but it ships with `ClaudeAgentOptions` and is scoped to the LLM invocation. Matching the SDK layout keeps the mental model simple — a user reading the SDK docs can find the same field in the same place.

> **Consequence:** cost observability (via `observers: [{type: cost_tracking}]`) is separate from budget enforcement (via `llm.config.max_budget_usd`). Both work; they're complementary.

---

## Example

```yaml
backend: claude-agent-sdk

metadata:
  version: "1.0"
  name: enterprise-agent

llm:
  provider: anthropic
  config:
    model: claude-opus-4-7
    api_key: ${ANTHROPIC_API_KEY}        # bridged to ANTHROPIC_API_KEY env var
    fallback_model: claude-sonnet-4-6
    max_budget_usd: 25.00
    max_turns: 40
    thinking: { type: adaptive }          # or {type: enabled, budget_tokens: 8000} / {type: disabled}
    effort: high                          # low | medium | high | max
    max_thinking_tokens: 16000
    include_partial_messages: true        # enabled by default
    betas: [context-1m-2025-08-07]

agent:
  name: main
  system_prompt: You coordinate research and writing tasks.
  cwd: ./workspace
  add_dirs: [./data, ./references]

  tools:
    preset: claude_code                   # or builtin/disabled for opt-out form
    # builtin: [bash, read, write, edit, glob, grep, web_fetch, web_search]
    # disabled: [web_fetch]

  plugins:
    - name: company
      type: python
      module: myapp.tools

  permissions:
    mode: auto                            # default | acceptEdits | plan | dontAsk | bypassPermissions | auto
    allowed_tools: [Bash, Read, Write]
    disallowed_tools: [WebFetch]
    # can_use_tool: { module: myapp.auth, function: authorize }
    # prompt_tool_name: approval_mcp_tool

  hooks:
    - event: PreToolUse
      matcher: "Bash"
      module: myapp.hooks
      function: check_safety
      timeout: 5
    - event: PreCompact
      module: myapp.hooks
      function: capture_context

  skills: all                             # or [skill-a, skill-b]
  setting_sources: [user, project]

  sandbox:
    enabled: true
    excluded_commands: [sudo]
    network: { allow: [github.com], deny: ["*"] }

  user: alice@corp                        # actor identity for multi-tenant attribution
  output_format:
    config:
      type: json_schema
      schema: { type: object }

# Subagents — callable by name from the main agent
subagents:
  researcher:
    description: Researches the codebase and external sources before changes
    prompt: You research thoroughly before making recommendations.
    tools: [bash, read, glob, grep]
    model: claude-sonnet-4-6
    effort: medium
    max_turns: 15
  reviewer:
    description: Reviews proposed changes
    prompt: You review diffs critically.
    permission_mode: plan

# Cross-backend tier 1 — compile down to hooks in CAS
guards:
  - type: tool_call_limit
    config: { max_calls: 100 }

observers:
  - type: audit_log
  - type: cost_tracking

mcp_servers:
  local-data:
    transport: stdio
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "./data"]
  remote-api:
    transport: http
    url: https://api.example.com/mcp
    headers: { Authorization: "Bearer ${API_TOKEN}" }
```

Run:

```bash
agentflow --yaml agent.yaml "Refactor the auth module"
```

---

## Further reading

- [Claude Agent SDK Python docs](https://code.claude.com/docs/en/agent-sdk/python)
- [Managed Agents overview](https://platform.claude.com/docs/en/managed-agents/agent-setup.md) (Research Preview)
- [MCP specification](https://modelcontextprotocol.io/)
- Sibling backend READMEs: [`workflows/`](../workflows/), [`deep/`](../deep/), [`sk/`](../sk/)

## License

This project is governed by the Accenture Internal Open-source Agreement. See the root [LICENSE](../../../LICENSE) for complete terms.

## Support

For questions or issues, contact the **Accenture AI & Data, Global Agentic COE** team.
