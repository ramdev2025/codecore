"""Thread-id ↔ SDK session-id bridge for the CAS backend.

Our cross-backend contract is ``--thread-id``. The Claude Agent SDK uses its
own session UUIDs, stored in ``.claude/`` or a pluggable ``SessionStore``.
This module bridges the two:

- ``thread_id`` is the agentflow-level identifier (set by the user or CLI)
- ``session_id`` is the SDK's UUID (auto-generated on first turn)
- ``CasPersistenceManager`` maps ``thread_id → session_id`` so the user's
  ``--thread-id my-session`` always resumes the same SDK session

Unlike SK (which stores a whole ``ChatHistory``), this is a much thinner
mapping — the SDK owns the actual conversation state. We just remember
which SDK session a given thread is bound to, plus a tiny bit of metadata
(first/last seen, turn count) for observability.

The ``session_id`` value is AES-GCM encrypted at rest when
``AGENTFLOW_ENCRYPTION_KEY`` is set, matching the other backends.
"""

from __future__ import annotations

import base64
import os
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# Encryption helpers (AES-GCM via pycryptodome; same as sk/core/persistence)
# ---------------------------------------------------------------------------


def _get_encryption_key(explicit: Optional[bytes] = None) -> Optional[bytes]:
    if explicit is not None:
        return explicit
    env = os.environ.get("AGENTFLOW_ENCRYPTION_KEY")
    if env is None:
        return None
    key = env.encode("utf-8") if isinstance(env, str) else env
    if len(key) not in (16, 24, 32):
        raise ValueError(
            f"AGENTFLOW_ENCRYPTION_KEY must be 16, 24, or 32 bytes (got {len(key)})"
        )
    return key


def _encrypt_aes(plaintext: str, key: bytes) -> str:
    try:
        from Crypto.Cipher import AES  # pycryptodome
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "Encryption requires pycryptodome. Install with: pip install pycryptodome"
        ) from exc

    cipher = AES.new(key, AES.MODE_GCM)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))
    payload = cipher.nonce + tag + ciphertext
    return base64.b64encode(payload).decode("ascii")


def _decrypt_aes(payload_b64: str, key: bytes) -> str:
    try:
        from Crypto.Cipher import AES
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "Encryption requires pycryptodome. Install with: pip install pycryptodome"
        ) from exc

    payload = base64.b64decode(payload_b64)
    nonce, tag, ciphertext = payload[:16], payload[16:32], payload[32:]
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    return cipher.decrypt_and_verify(ciphertext, tag).decode("utf-8")


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class CasPersistenceManager(ABC):
    """Abstract persistence: maps agentflow ``thread_id`` → SDK ``session_id``."""

    def __init__(self, encryption_key: Optional[bytes] = None):
        self._encryption_key = _get_encryption_key(encryption_key)

    @abstractmethod
    def get_session_id(self, thread_id: str) -> Optional[str]:
        """Return the SDK session id bound to this thread, or ``None``."""

    @abstractmethod
    def put_session_id(self, thread_id: str, session_id: str) -> None:
        """Bind ``session_id`` to ``thread_id``. Updates ``last_seen``."""

    @abstractmethod
    def bump_turns(self, thread_id: str) -> None:
        """Increment the per-thread turn counter (observability)."""

    @abstractmethod
    def list_threads(self) -> List[str]:
        """List all known thread ids."""

    @abstractmethod
    def delete(self, thread_id: str) -> None:
        """Remove the thread binding."""

    # --- encryption helpers used by subclasses -----------------------------

    def _encode(self, session_id: str) -> str:
        if self._encryption_key is None:
            return session_id
        return "aes:" + _encrypt_aes(session_id, self._encryption_key)

    def _decode(self, stored: str) -> str:
        if stored.startswith("aes:"):
            if self._encryption_key is None:
                raise RuntimeError(
                    "Stored session id is encrypted but AGENTFLOW_ENCRYPTION_KEY "
                    "is not set. Cannot decrypt."
                )
            return _decrypt_aes(stored[4:], self._encryption_key)
        return stored


# ---------------------------------------------------------------------------
# In-memory (tests, stateless workers)
# ---------------------------------------------------------------------------


class InMemoryPersistence(CasPersistenceManager):
    def __init__(self, encryption_key: Optional[bytes] = None):
        super().__init__(encryption_key)
        self._store: Dict[str, Dict[str, object]] = {}

    def get_session_id(self, thread_id: str) -> Optional[str]:
        entry = self._store.get(thread_id)
        if entry is None:
            return None
        return self._decode(entry["session_id"])  # type: ignore[arg-type]

    def put_session_id(self, thread_id: str, session_id: str) -> None:
        now = time.time()
        existing = self._store.get(thread_id, {})
        self._store[thread_id] = {
            "session_id": self._encode(session_id),
            "first_seen": existing.get("first_seen", now),
            "last_seen": now,
            "turns": existing.get("turns", 0),
        }

    def bump_turns(self, thread_id: str) -> None:
        entry = self._store.get(thread_id)
        if entry is not None:
            entry["turns"] = int(entry.get("turns", 0)) + 1  # type: ignore[arg-type]
            entry["last_seen"] = time.time()

    def list_threads(self) -> List[str]:
        return list(self._store.keys())

    def delete(self, thread_id: str) -> None:
        self._store.pop(thread_id, None)


# ---------------------------------------------------------------------------
# SQLite (file-based, default)
# ---------------------------------------------------------------------------


class SQLitePersistence(CasPersistenceManager):
    def __init__(
        self,
        db_path: str = ".agentflow/cas_threads.db",
        encryption_key: Optional[bytes] = None,
    ):
        super().__init__(encryption_key)
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _connect(self):
        import sqlite3

        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_schema(self):
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS cas_threads (
                    thread_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    first_seen REAL NOT NULL,
                    last_seen REAL NOT NULL,
                    turns INTEGER NOT NULL DEFAULT 0
                )
                """
            )

    def get_session_id(self, thread_id: str) -> Optional[str]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT session_id FROM cas_threads WHERE thread_id = ?",
                (thread_id,),
            ).fetchone()
            if row is None:
                return None
            return self._decode(row[0])

    def put_session_id(self, thread_id: str, session_id: str) -> None:
        now = time.time()
        encoded = self._encode(session_id)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO cas_threads (thread_id, session_id, first_seen, last_seen, turns)
                VALUES (?, ?, ?, ?, 0)
                ON CONFLICT(thread_id) DO UPDATE SET
                    session_id = excluded.session_id,
                    last_seen = excluded.last_seen
                """,
                (thread_id, encoded, now, now),
            )

    def bump_turns(self, thread_id: str) -> None:
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                "UPDATE cas_threads SET turns = turns + 1, last_seen = ? WHERE thread_id = ?",
                (now, thread_id),
            )

    def list_threads(self) -> List[str]:
        with self._connect() as conn:
            return [
                r[0]
                for r in conn.execute(
                    "SELECT thread_id FROM cas_threads ORDER BY last_seen DESC"
                )
            ]

    def delete(self, thread_id: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM cas_threads WHERE thread_id = ?", (thread_id,)
            )


# ---------------------------------------------------------------------------
# Postgres (production, multi-instance)
# ---------------------------------------------------------------------------


class PostgresPersistence(CasPersistenceManager):
    """asyncpg-backed binding table. Synchronous API wraps the async calls —
    acceptable here because reads and writes are O(single row)."""

    def __init__(
        self,
        connection_string: str,
        encryption_key: Optional[bytes] = None,
    ):
        super().__init__(encryption_key)
        self.dsn = connection_string
        import asyncio

        self._loop = asyncio.new_event_loop()
        self._init_schema()

    def _run(self, coro):
        return self._loop.run_until_complete(coro)

    async def _connect(self):
        import asyncpg

        return await asyncpg.connect(self.dsn)

    def _init_schema(self):
        async def _init():
            conn = await self._connect()
            try:
                await conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS cas_threads (
                        thread_id TEXT PRIMARY KEY,
                        session_id TEXT NOT NULL,
                        first_seen DOUBLE PRECISION NOT NULL,
                        last_seen DOUBLE PRECISION NOT NULL,
                        turns INTEGER NOT NULL DEFAULT 0
                    )
                    """
                )
            finally:
                await conn.close()

        self._run(_init())

    def get_session_id(self, thread_id: str) -> Optional[str]:
        async def _q():
            conn = await self._connect()
            try:
                row = await conn.fetchrow(
                    "SELECT session_id FROM cas_threads WHERE thread_id = $1",
                    thread_id,
                )
                return row["session_id"] if row else None
            finally:
                await conn.close()

        encoded = self._run(_q())
        return self._decode(encoded) if encoded else None

    def put_session_id(self, thread_id: str, session_id: str) -> None:
        now = time.time()
        encoded = self._encode(session_id)

        async def _upsert():
            conn = await self._connect()
            try:
                await conn.execute(
                    """
                    INSERT INTO cas_threads (thread_id, session_id, first_seen, last_seen, turns)
                    VALUES ($1, $2, $3, $3, 0)
                    ON CONFLICT (thread_id) DO UPDATE SET
                        session_id = EXCLUDED.session_id,
                        last_seen = EXCLUDED.last_seen
                    """,
                    thread_id,
                    encoded,
                    now,
                )
            finally:
                await conn.close()

        self._run(_upsert())

    def bump_turns(self, thread_id: str) -> None:
        now = time.time()

        async def _bump():
            conn = await self._connect()
            try:
                await conn.execute(
                    "UPDATE cas_threads SET turns = turns + 1, last_seen = $1 WHERE thread_id = $2",
                    now,
                    thread_id,
                )
            finally:
                await conn.close()

        self._run(_bump())

    def list_threads(self) -> List[str]:
        async def _list():
            conn = await self._connect()
            try:
                rows = await conn.fetch(
                    "SELECT thread_id FROM cas_threads ORDER BY last_seen DESC"
                )
                return [r["thread_id"] for r in rows]
            finally:
                await conn.close()

        return self._run(_list())

    def delete(self, thread_id: str) -> None:
        async def _del():
            conn = await self._connect()
            try:
                await conn.execute(
                    "DELETE FROM cas_threads WHERE thread_id = $1", thread_id
                )
            finally:
                await conn.close()

        self._run(_del())


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_persistence_manager(
    backend: str = "sqlite",
    db_path: Optional[str] = None,
    connection_string: Optional[str] = None,
    encryption_key: Optional[bytes] = None,
) -> CasPersistenceManager:
    """Factory matching the signature of the SK/workflows/deep equivalents."""
    if backend == "memory":
        return InMemoryPersistence(encryption_key=encryption_key)
    if backend == "sqlite":
        path = db_path or os.environ.get(
            "CHECKPOINTER_DB_PATH", ".agentflow/cas_threads.db"
        )
        return SQLitePersistence(db_path=path, encryption_key=encryption_key)
    if backend == "postgres":
        conn = connection_string or os.environ.get("POSTGRES_CONNECTION_STRING")
        if not conn:
            raise ValueError(
                "Postgres persistence requires --connection-string or "
                "POSTGRES_CONNECTION_STRING env var"
            )
        return PostgresPersistence(connection_string=conn, encryption_key=encryption_key)
    raise ValueError(f"Unknown CAS persistence backend: {backend!r}")
