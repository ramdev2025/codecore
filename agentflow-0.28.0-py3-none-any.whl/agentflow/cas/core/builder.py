"""``CasAgentBuilder`` — compose a Claude Agent SDK runner from YAML config.

Pipeline::

    yaml file
        -> CasYAMLConfig (Pydantic)
        -> helpers.resolve_env_vars (${VAR} substitution)
        -> service_factory.apply_llm_config (api_key -> env var, extract SDK kwargs)
        -> plugin_registry.resolve_plugins (Python @tool modules -> MCP SDK servers)
        -> hook_registry.resolve_hooks (module:function -> HookMatcher list)
        -> mcp.resolve_mcp_servers (snake_case -> SDK TypedDicts)
        -> ClaudeAgentOptions (single SDK dataclass)
        -> CasRunner (thin wrapper: options + query() / ClaudeSDKClient())
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Iterable, List, Optional

import yaml

from agentflow.cas.core.config_models import (
    AgentSpec,
    BuiltinTool,
    CasYAMLConfig,
    HookConfig,
    SandboxConfig,
    SubagentSpec,
    ThinkingAdaptive,
    ThinkingDisabled,
    ThinkingEnabled,
    ToolsConfig,
    ToolsPreset,
)
from agentflow.cas.core.helpers import load_dotenv_for, resolve_env_vars
from agentflow.cas.core.hook_registry import resolve_hooks
from agentflow.cas.core.mcp import resolve_mcp_servers
from agentflow.cas.core.plugin_registry import resolve_plugins
from agentflow.cas.core.service_factory import apply_llm_config, split_llm_config
from agentflow.cas.filters.compiler import (
    compile_guards,
    compile_observers,
    compile_optimizers,
    to_hook_matchers,
)

# lowercase-agentflow-name -> SDK capitalized name
_TOOL_NAME_MAP: Dict[str, str] = {
    BuiltinTool.BASH.value: "Bash",
    BuiltinTool.READ.value: "Read",
    BuiltinTool.WRITE.value: "Write",
    BuiltinTool.EDIT.value: "Edit",
    BuiltinTool.GLOB.value: "Glob",
    BuiltinTool.GREP.value: "Grep",
    BuiltinTool.WEB_FETCH.value: "WebFetch",
    BuiltinTool.WEB_SEARCH.value: "WebSearch",
    BuiltinTool.TASK.value: "Task",
    BuiltinTool.TODO_WRITE.value: "TodoWrite",
    BuiltinTool.EXIT_PLAN_MODE.value: "ExitPlanMode",
}


def _sdk_tool_name(name: str) -> str:
    """Translate our lowercase tool names to the SDK's capitalized form.

    Unknown names pass through unchanged — users may reference MCP-provided
    tools by whatever name the MCP server exposes, and those are not in our
    enum.
    """
    return _TOOL_NAME_MAP.get(name, name)


@dataclass
class CasRunner:
    """Pre-configured Claude Agent SDK runner.

    Holds the translated ``ClaudeAgentOptions`` plus a summary dict for
    ``--dry-run``. Callers pick the invocation style:

    - ``runner.query(prompt)`` — one-shot via the SDK's ``query()``
    - ``runner.client()`` — ``ClaudeSDKClient`` for multi-turn interactive use
    """

    options: Any
    summary: Dict[str, Any]

    async def query(self, prompt: str) -> AsyncIterator[Any]:
        """One-shot query. Yields messages as they arrive."""
        from claude_agent_sdk import query  # lazy

        async for message in query(prompt=prompt, options=self.options):
            yield message

    def client(self) -> Any:
        """Return a stateful ``ClaudeSDKClient`` bound to these options."""
        from claude_agent_sdk import ClaudeSDKClient  # lazy

        return ClaudeSDKClient(options=self.options)


class CasAgentBuilder:
    """Build a :class:`CasRunner` from a YAML config path or a parsed config.

    Typical use::

        runner = CasAgentBuilder.from_yaml("agent.yaml").build()
        async for msg in runner.query("Hello"):
            ...
    """

    def __init__(
        self,
        config: CasYAMLConfig,
        yaml_path: Optional[str] = None,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ):
        self.config = config
        self.yaml_path = yaml_path
        # Build-time state for ``available_when`` predicate evaluation
        # of ``ui_tools``. See ``agentflow.genui.availability`` for
        # semantics (fail-safe default when ``None``).
        self.build_state: Dict[str, Any] = build_state or {}
        # AG-UI router opt-in for client_tools. Off by default — CLI /
        # script callers never see them. Flipped on by
        # ``AsyncCASAGUIRuntime.create`` so the in-process MCP server
        # also carries the ``ClientToolPause`` stubs.
        self.bind_client_tools: bool = bind_client_tools

    # -- Construction -------------------------------------------------------

    @classmethod
    def from_yaml(
        cls,
        path: str,
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ) -> "CasAgentBuilder":
        """Load + validate + resolve ``${VAR}`` placeholders from a YAML file."""
        load_dotenv_for(path)

        raw = yaml.safe_load(Path(path).read_text())
        if raw is None:
            raise ValueError(f"YAML file is empty: {path}")

        raw = resolve_env_vars(raw)
        config = CasYAMLConfig.model_validate(raw)
        return cls(
            config,
            yaml_path=path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    @classmethod
    def from_dict(
        cls,
        data: Dict[str, Any],
        build_state: Optional[Dict[str, Any]] = None,
        bind_client_tools: bool = False,
    ) -> "CasAgentBuilder":
        """Alternative entry point for programmatic use / tests."""
        resolved = resolve_env_vars(data)
        config = CasYAMLConfig.model_validate(resolved)
        return cls(
            config,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )

    # -- Build --------------------------------------------------------------

    def build(self) -> CasRunner:
        """Translate the validated config into ``ClaudeAgentOptions``."""
        from claude_agent_sdk import ClaudeAgentOptions  # lazy

        llm = self.config.agent.llm or self.config.llm
        llm_kwargs = apply_llm_config(llm) if llm is not None else {}

        # Default: stream token-level (our design decision #3 in README)
        llm_kwargs.setdefault("include_partial_messages", True)

        # Tools: preset takes precedence, otherwise capitalized list
        tools = self._resolve_tools(self.config.agent.tools)

        # Custom @tool plugins become in-process MCP servers; merged with the
        # user's explicit mcp_servers.
        plugin_servers = resolve_plugins(self.config.agent.plugins)
        mcp_servers = resolve_mcp_servers(self.config.mcp_servers)
        all_mcp = {**mcp_servers, **plugin_servers}

        # Generative-UI components + (optionally) client_tools.
        # Each ``@ui_component`` fetcher becomes an ``SdkMcpTool``;
        # client_tools become ``ClientToolPause``-raising stubs.
        # Both share the in-process ``ui_tools`` MCP server so the LLM
        # sees them as one cohesive tool surface.
        ui_sdk_tools: list[Any] = []
        if self.config.agent.ui_tools is not None:
            from agentflow.cas.genui import resolve_ui_tools
            from agentflow.genui import filter_by_availability

            ui_sdk_tools = resolve_ui_tools(self.config.agent.ui_tools)
            ui_sdk_tools = filter_by_availability(
                ui_sdk_tools,
                self.config.agent.available_when,
                self.build_state,
            )

        if self.bind_client_tools and self.config.agent.client_tools:
            from agentflow.cas.agui.client_tools import build_client_tool_sdk_tools

            ui_sdk_tools.extend(
                build_client_tool_sdk_tools(self.config.agent.client_tools)
            )

        if ui_sdk_tools:
            from claude_agent_sdk import create_sdk_mcp_server

            all_mcp["ui_tools"] = create_sdk_mcp_server(
                name="ui_tools", tools=ui_sdk_tools
            )

        # Subagents → SDK AgentDefinition dict
        subagents = self._build_subagents(self.config.subagents or {})

        # Hooks: user-declared + compiled from guards/optimizers/observers
        hooks = self._collect_hooks()

        # Permissions
        perms = self.config.agent.permissions
        can_use_tool = (
            self._resolve_can_use_tool(perms.can_use_tool) if perms.can_use_tool else None
        )

        # Sandbox, thinking, etc.
        sandbox = self._to_sdk_sandbox(self.config.agent.sandbox)
        thinking = self._to_sdk_thinking(llm_kwargs.pop("thinking", None))
        if thinking is not None:
            llm_kwargs["thinking"] = thinking

        options = ClaudeAgentOptions(
            system_prompt=self.config.agent.system_prompt,
            cwd=self.config.agent.cwd,
            add_dirs=self.config.agent.add_dirs or [],
            tools=tools,
            allowed_tools=perms.allowed_tools or [],
            disallowed_tools=perms.disallowed_tools or [],
            permission_mode=perms.mode.value if perms.mode else None,
            permission_prompt_tool_name=perms.prompt_tool_name,
            can_use_tool=can_use_tool,
            hooks=hooks or None,
            mcp_servers=all_mcp,
            agents=subagents or None,
            skills=self.config.agent.skills,
            setting_sources=(
                [s.value for s in self.config.agent.setting_sources]
                if self.config.agent.setting_sources
                else None
            ),
            sandbox=sandbox,
            user=self.config.agent.user,
            output_format=(
                self.config.agent.output_format.to_sdk()
                if self.config.agent.output_format
                else None
            ),
            **llm_kwargs,
        )

        return CasRunner(options=options, summary=self.dry_run())

    # -- Introspection ------------------------------------------------------

    def dry_run(self) -> Dict[str, Any]:
        """Return a human-readable summary without building an SDK client."""
        llm = self.config.agent.llm or self.config.llm
        sdk_opts, extras = split_llm_config(llm) if llm else ({}, {})

        agent_tools = self.config.agent.tools
        if agent_tools.preset:
            tool_label = f"preset={agent_tools.preset.value}"
        else:
            tool_label = ", ".join(t.value for t in agent_tools.effective) or "none"

        return {
            "backend": "claude-agent-sdk",
            "metadata": self.config.metadata.model_dump(exclude_none=True),
            "llm": {
                "provider": llm.provider.value if llm else None,
                "sdk_options": sdk_opts,
                "extras": extras,
            },
            "agent": {
                "name": self.config.agent.name,
                "cwd": self.config.agent.cwd,
                "tools": tool_label,
                "permission_mode": self.config.agent.permissions.mode.value,
                "hook_count": len(self.config.agent.hooks or []),
                "plugin_count": len(self.config.agent.plugins or []),
                "skills": self.config.agent.skills,
                "sandbox_enabled": (
                    self.config.agent.sandbox.enabled
                    if self.config.agent.sandbox
                    else None
                ),
            },
            "subagents": list((self.config.subagents or {}).keys()),
            "guards": [g.type.value for g in (self.config.guards or [])],
            "optimizers": [o.type.value for o in (self.config.optimizers or [])],
            "observers": [o.type.value for o in (self.config.observers or [])],
            "mcp_servers": list((self.config.mcp_servers or {}).keys()),
        }

    # -- Internal: translations --------------------------------------------

    def _resolve_tools(self, tools: ToolsConfig) -> Any:
        """Pick preset shape or a capitalized list."""
        if tools.preset is not None:
            return {"type": "preset", "preset": tools.preset.value}
        # Preserve order from the user's builtin list, minus disabled
        return [_sdk_tool_name(t.value) for t in tools.effective]

    def _build_subagents(self, subs: Dict[str, SubagentSpec]) -> Dict[str, Any]:
        """Convert subagent specs to the SDK's ``AgentDefinition`` dict."""
        if not subs:
            return {}
        from claude_agent_sdk import AgentDefinition  # lazy

        out: Dict[str, Any] = {}
        for name, sub in subs.items():
            kwargs: Dict[str, Any] = {
                "description": sub.description,
                "prompt": sub.prompt,
            }
            if sub.tools is not None:
                kwargs["tools"] = [_sdk_tool_name(t.value) for t in sub.tools]
            if sub.disallowed_tools is not None:
                kwargs["disallowedTools"] = [
                    _sdk_tool_name(t.value) for t in sub.disallowed_tools
                ]
            if sub.model is not None:
                kwargs["model"] = sub.model
            if sub.skills is not None:
                kwargs["skills"] = sub.skills
            if sub.memory is not None:
                kwargs["memory"] = sub.memory.value
            if sub.mcp_servers is not None:
                kwargs["mcpServers"] = sub.mcp_servers
            if sub.initial_prompt is not None:
                kwargs["initialPrompt"] = sub.initial_prompt
            if sub.max_turns is not None:
                kwargs["maxTurns"] = sub.max_turns
            if sub.background is not None:
                kwargs["background"] = sub.background
            if sub.effort is not None:
                kwargs["effort"] = (
                    sub.effort.value if hasattr(sub.effort, "value") else sub.effort
                )
            if sub.permission_mode is not None:
                kwargs["permissionMode"] = sub.permission_mode.value
            out[name] = AgentDefinition(**kwargs)
        return out

    def _collect_hooks(self) -> Dict[str, List[Any]]:
        """Merge user-declared ``agent.hooks`` with guard/optimizer/observer
        compilations.

        Guards/optimizers/observers are the *portable* layer — in the CAS
        backend they compile down to hooks. User-declared ``agent.hooks:``
        override compiled ones when targeting the same event: user-declared
        entries come first in the merged list (SDK iterates in order).
        """
        user_hooks = resolve_hooks(self.config.agent.hooks)

        compiled = [
            *compile_guards(self.config.guards),
            *compile_optimizers(self.config.optimizers),
            *compile_observers(self.config.observers),
        ]
        compiled_hooks = to_hook_matchers(compiled)

        merged: Dict[str, List[Any]] = {}
        events = set(user_hooks) | set(compiled_hooks)
        for event in events:
            merged[event] = [
                *user_hooks.get(event, []),
                *compiled_hooks.get(event, []),
            ]
        return merged

    def _resolve_can_use_tool(self, ref: Any) -> Any:
        import importlib

        mod = importlib.import_module(ref.module)
        fn = getattr(mod, ref.function, None)
        if fn is None:
            raise AttributeError(
                f"can_use_tool: {ref.function!r} not found in {ref.module!r}"
            )
        return fn

    def _to_sdk_sandbox(self, s: Optional[SandboxConfig]) -> Any:
        if s is None:
            return None
        from claude_agent_sdk import SandboxSettings  # lazy

        kwargs: Dict[str, Any] = {}
        if s.enabled is not None:
            kwargs["enabled"] = s.enabled
        if s.auto_allow_bash_if_sandboxed is not None:
            kwargs["autoAllowBashIfSandboxed"] = s.auto_allow_bash_if_sandboxed
        if s.excluded_commands is not None:
            kwargs["excludedCommands"] = s.excluded_commands
        if s.allow_unsandboxed_commands is not None:
            kwargs["allowUnsandboxedCommands"] = s.allow_unsandboxed_commands
        if s.enable_weaker_nested_sandbox is not None:
            kwargs["enableWeakerNestedSandbox"] = s.enable_weaker_nested_sandbox
        if s.network is not None:
            net: Dict[str, Any] = {}
            if s.network.allow is not None:
                net["allow"] = s.network.allow
            if s.network.deny is not None:
                net["deny"] = s.network.deny
            kwargs["network"] = net
        return SandboxSettings(**kwargs) if kwargs else None

    def _to_sdk_thinking(self, yaml_thinking: Any) -> Any:
        """Translate our ThinkingConfig union (or dict) to the SDK types."""
        if yaml_thinking is None:
            return None
        from claude_agent_sdk import (  # lazy
            ThinkingConfigAdaptive,
            ThinkingConfigDisabled,
            ThinkingConfigEnabled,
        )

        # Accept either a Pydantic model instance or a raw dict (from dry-run extras)
        if isinstance(yaml_thinking, dict):
            t = yaml_thinking.get("type")
            if t == "enabled":
                return ThinkingConfigEnabled(
                    type="enabled",
                    budget_tokens=yaml_thinking["budget_tokens"],
                )
            if t == "adaptive":
                return ThinkingConfigAdaptive(type="adaptive")
            if t == "disabled":
                return ThinkingConfigDisabled(type="disabled")
            raise ValueError(f"Unknown thinking type: {t!r}")

        if isinstance(yaml_thinking, ThinkingEnabled):
            return ThinkingConfigEnabled(
                type="enabled",
                budget_tokens=yaml_thinking.budget_tokens,
            )
        if isinstance(yaml_thinking, ThinkingAdaptive):
            return ThinkingConfigAdaptive(type="adaptive")
        if isinstance(yaml_thinking, ThinkingDisabled):
            return ThinkingConfigDisabled(type="disabled")
        return yaml_thinking  # already-SDK type, trust it
