"""Resolve ``HookConfig`` YAML entries into SDK ``HookMatcher`` objects.

The SDK's hooks parameter is ``dict[HookEvent, list[HookMatcher]]`` where
each matcher carries a regex, a list of callables, and a timeout.
"""

from __future__ import annotations

import importlib
from collections import defaultdict
from typing import Any, Callable, Dict, List

from agentflow.cas.core.config_models import HookConfig


def resolve_hooks(
    hooks: List[HookConfig] | None,
) -> Dict[str, List[Any]]:
    """Resolve all hook refs into a dict keyed by SDK event name.

    Returns ``{}`` if no hooks. Grouped by event so multiple configs for the
    same event become multiple ``HookMatcher`` entries.
    """
    if not hooks:
        return {}

    from claude_agent_sdk import HookMatcher  # lazy

    grouped: Dict[str, List[Any]] = defaultdict(list)
    for h in hooks:
        fn = _resolve_callable(h.module, h.function)
        grouped[h.event.value].append(
            HookMatcher(matcher=h.matcher, hooks=[fn], timeout=h.timeout)
        )
    return dict(grouped)


def _resolve_callable(module_path: str, function_name: str) -> Callable[..., Any]:
    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Hook module {module_path!r} could not be imported: {exc}"
        ) from exc
    fn = getattr(mod, function_name, None)
    if fn is None:
        raise AttributeError(
            f"Hook function {function_name!r} not found in module {module_path!r}"
        )
    if not callable(fn):
        raise TypeError(
            f"{module_path}.{function_name} is not callable"
        )
    return fn
