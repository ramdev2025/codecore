"""Bridge AgentFlow lifecycle plugins to CAS hooks.

AgentFlow's ``Plugin`` ABC (``agentflow.workflows.plugins``) is a set of
observer hooks — ``on_tool_call``, ``on_agent_start``, ``on_workflow_end``,
etc. The Claude Agent SDK's hook system uses async functions registered per
event type. This module bridges the two so existing telemetry/logging/cost
plugins work on CAS agents without modification.

Design note (same as the SK bridge): duck-typed ``plugin_manager`` — any
object with ``emit_tool_call`` / ``emit_tool_result`` / ``emit_error``
methods. Keeps this module import-safe whether or not workflows is
installed.

Events this bridge produces:

- ``on_tool_call`` — from the ``PreToolUse`` SDK event
- ``on_tool_result`` — from ``PostToolUse``
- ``on_error`` — from ``PostToolUseFailure``

Workflow-level events (``on_workflow_start/end``, ``on_agent_start/end``)
are fired by the CAS CLI runner around the top-level query/client call,
not by hooks. Events that don't apply to CAS (``on_hitl_*``,
``on_external_agent_*``, ``on_mcp_connect``) simply never fire.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List


def build_plugin_bridge_hooks(
    plugin_manager: Any,
    context: Any,
) -> Dict[str, List[Any]]:
    """Return a ``{event: [HookMatcher, ...]}`` dict for bridge hooks.

    Callers merge this with the rest of ``agent.hooks`` before passing to
    ``ClaudeAgentOptions``.
    """
    if plugin_manager is None:
        return {}

    from claude_agent_sdk import HookMatcher  # lazy

    return {
        "PreToolUse": [
            HookMatcher(
                matcher=None,
                hooks=[_make_pre_bridge(plugin_manager, context)],
                timeout=30,
            )
        ],
        "PostToolUse": [
            HookMatcher(
                matcher=None,
                hooks=[_make_post_bridge(plugin_manager, context)],
                timeout=30,
            )
        ],
        "PostToolUseFailure": [
            HookMatcher(
                matcher=None,
                hooks=[_make_failure_bridge(plugin_manager, context)],
                timeout=30,
            )
        ],
    }


# ---------------------------------------------------------------------------
# Hook callables
# ---------------------------------------------------------------------------


def _make_pre_bridge(plugin_manager: Any, context: Any) -> Callable:
    async def pre(input_data, tool_use_id, hook_context):
        tool_name = (input_data or {}).get("tool_name", "<unknown>")
        tool_input = (input_data or {}).get("tool_input")
        _safe_emit(plugin_manager, "emit_tool_call", context, tool_name, tool_input)
        return {}

    return pre


def _make_post_bridge(plugin_manager: Any, context: Any) -> Callable:
    async def post(input_data, tool_use_id, hook_context):
        tool_name = (input_data or {}).get("tool_name", "<unknown>")
        # SDK's PostToolUseHookInput calls this field ``tool_response``.
        result = (input_data or {}).get("tool_response")
        _safe_emit(plugin_manager, "emit_tool_result", context, tool_name, result)
        return {}

    return post


def _make_failure_bridge(plugin_manager: Any, context: Any) -> Callable:
    async def on_failure(input_data, tool_use_id, hook_context):
        tool_name = (input_data or {}).get("tool_name", "<unknown>")
        error = (input_data or {}).get("error") or Exception("tool failure")
        _safe_emit(
            plugin_manager,
            "emit_error",
            context,
            error,
            {"tool": tool_name, "tool_use_id": tool_use_id},
        )
        return {}

    return on_failure


# ---------------------------------------------------------------------------
# Lifecycle emitter — used by the CLI around the top-level run
# ---------------------------------------------------------------------------


class WorkflowLifecycleEmitter:
    """Context manager that fires ``on_workflow_start/end`` + ``on_agent_start/end``
    events around a CAS run. Usage::

        with WorkflowLifecycleEmitter(plugin_manager, context, agent_name):
            await runner.query(...)
    """

    def __init__(
        self,
        plugin_manager: Any,
        context: Any,
        agent_name: str,
    ):
        self.plugin_manager = plugin_manager
        self.context = context
        self.agent_name = agent_name

    def __enter__(self):
        _safe_emit(self.plugin_manager, "emit_workflow_start", self.context)
        _safe_emit(
            self.plugin_manager, "emit_agent_start", self.context, self.agent_name
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "failed" if exc_type else "success"
        _safe_emit(
            self.plugin_manager,
            "emit_agent_end",
            self.context,
            self.agent_name,
            status,
        )
        _safe_emit(
            self.plugin_manager, "emit_workflow_end", self.context, None, status
        )
        return False  # don't swallow exceptions


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_emit(plugin_manager: Any, method: str, *args) -> None:
    """Call ``plugin_manager.<method>(*args)`` swallowing AttributeError.

    Plugins are optional observers — a missing method means the host doesn't
    care about that event, which is not an error.
    """
    fn = getattr(plugin_manager, method, None)
    if fn is None:
        return
    try:
        fn(*args)
    except Exception:
        # Observers must not break the agent. Log at debug level in a real
        # deployment; here we swallow to keep the hook pipeline resilient.
        pass
