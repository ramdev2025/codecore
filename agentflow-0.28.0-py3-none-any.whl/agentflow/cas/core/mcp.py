"""Translate YAML ``mcp_servers:`` entries into SDK MCP server configs.

The SDK ``mcp_servers`` value is ``dict[str, McpStdioServerConfig |
McpSSEServerConfig | McpHttpServerConfig | McpSdkServerConfig]``. The
TypedDicts expect specific ``type`` discriminators.
"""

from __future__ import annotations

from typing import Any, Dict

from agentflow.cas.core.config_models import MCPServerEntry, MCPTransport


def resolve_mcp_servers(
    servers: Dict[str, MCPServerEntry] | None,
) -> Dict[str, Dict[str, Any]]:
    """Convert our ``MCPServerEntry`` models to the SDK's TypedDict shape."""
    if not servers:
        return {}

    out: Dict[str, Dict[str, Any]] = {}
    for name, entry in servers.items():
        if entry.transport == MCPTransport.STDIO:
            cfg: Dict[str, Any] = {"type": "stdio", "command": entry.command}
            if entry.args:
                cfg["args"] = entry.args
            if entry.env:
                cfg["env"] = entry.env
        elif entry.transport == MCPTransport.SSE:
            cfg = {"type": "sse", "url": entry.url}
            if entry.headers:
                cfg["headers"] = entry.headers
        elif entry.transport == MCPTransport.HTTP:
            cfg = {"type": "http", "url": entry.url}
            if entry.headers:
                cfg["headers"] = entry.headers
        else:  # pragma: no cover - schema enforces
            raise ValueError(f"Unknown MCP transport: {entry.transport!r}")
        out[name] = cfg
    return out
