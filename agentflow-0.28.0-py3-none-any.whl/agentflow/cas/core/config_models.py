"""Pydantic config models for the Claude Agent SDK (CAS) YAML schema.

The CAS schema maps onto the SDK's ``ClaudeAgentOptions`` dataclass. Fields
use snake_case in YAML and are translated to the SDK's camelCase equivalents
inside the builder where needed (e.g. ``disallowed_tools`` →
``disallowedTools`` in ``AgentDefinition``).

Schema shape::

    backend: claude-agent-sdk
    metadata: { version, name, ... }

    # LLM-level options (model + inference knobs)
    llm:
      provider: anthropic
      config:
        model: claude-opus-4-7
        api_key: ${ANTHROPIC_API_KEY}    # bridged to ANTHROPIC_API_KEY env var
        fallback_model: claude-sonnet-4-6
        max_budget_usd: 5.00             # SDK-native hard stop
        max_turns: 40
        thinking: { type: adaptive }     # or enabled/disabled
        effort: high                     # low | medium | high | max
        max_thinking_tokens: 16000
        include_partial_messages: true   # enabled by default in the CLI
        betas: [context-1m-2025-08-07]

    # The main agent — always present
    agent:
      name: main
      system_prompt: ...
      cwd: ./workspace
      tools: { builtin, disabled }       # opt-out of the SDK's tool suite
      plugins: [...]                     # custom @tool-decorated Python funcs
      permissions: { mode, allowed_tools, can_use_tool }
      hooks: [...]                       # 10 SDK event types, first-class
      skills: [a, b] | "all"
      sandbox: { enabled, network, excluded_commands, ... }
      add_dirs: [./data]
      setting_sources: [user, project, local]
      user: alice@example.com            # actor identity for multi-tenant
      output_format: { ... }             # structured output schema

    # Subagents — a dict of names → AgentDefinition-equivalents, callable
    # from the main agent by name. Reflects the SDK's native agents: field.
    subagents:
      researcher:
        description: Researches codebases
        prompt: You research before making changes.
        tools: [bash, read, glob, grep]
        skills: [a, b]
        model: claude-sonnet-4-6
        max_turns: 20
        effort: medium
        permissions: { mode: default }

    # Cross-backend tier 1 (portable) — compiles down to hooks in CAS
    guards: [...]
    optimizers: [...]
    observers: [...]

    # MCP servers (stdio / sse / http)
    mcp_servers: { ... }

v1 targets the SDK client (GA). Managed Agents API (Research Preview — memory
stores, Bedrock/Vertex routing) lands behind an explicit flag later.
"""

from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator

from agentflow.genui import ClientToolConfig, UIToolsConfig


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


class CasMetadata(BaseModel):
    """Metadata about the CAS YAML config."""

    version: str = Field(..., description="Schema version (e.g. '1.0')")
    name: Optional[str] = Field(None, description="Human-readable name for this config")
    description: Optional[str] = None
    author: Optional[str] = None
    tags: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# Providers + LLM
# ---------------------------------------------------------------------------


class LLMProvider(str, Enum):
    """LLM providers supported in v1.

    Bedrock / Vertex routing requires the Managed Agents API (Research Preview);
    they are deliberately not in this enum so users hit a clear schema error
    today rather than a surprising runtime failure.
    """

    ANTHROPIC = "anthropic"
    CUSTOM = "custom"


# ---------------------------------------------------------------------------
# Extended thinking
# ---------------------------------------------------------------------------


class ThinkingEnabled(BaseModel):
    """Explicit thinking budget (the SDK's ``ThinkingConfigEnabled``)."""

    type: Literal["enabled"]
    budget_tokens: int = Field(..., ge=1)


class ThinkingAdaptive(BaseModel):
    """Model-managed thinking budget (``ThinkingConfigAdaptive``)."""

    type: Literal["adaptive"]


class ThinkingDisabled(BaseModel):
    """Thinking turned off (``ThinkingConfigDisabled``)."""

    type: Literal["disabled"]


ThinkingConfig = Union[ThinkingEnabled, ThinkingAdaptive, ThinkingDisabled]


class Effort(str, Enum):
    """Effort preset forwarded to the SDK."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    MAX = "max"


class LLMConfig(BaseModel):
    """LLM-level inference config.

    Most fields map 1:1 to ``ClaudeAgentOptions``. ``api_key`` is a convenience
    — the builder sets ``ANTHROPIC_API_KEY`` from it before invoking the SDK,
    since the SDK itself reads the env var rather than taking an explicit key.
    """

    provider: LLMProvider = Field(default=LLMProvider.ANTHROPIC)

    # Catch-all dict for primary fields; the builder picks known keys out and
    # passes them to the SDK. Using a dict (rather than typed fields) keeps
    # the provider/config split consistent with the other agentflow backends.
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Inference config. Known keys: model, api_key, fallback_model, "
            "max_budget_usd, max_turns, include_partial_messages, "
            "max_thinking_tokens, thinking, effort, betas."
        ),
    )


# ---------------------------------------------------------------------------
# Tools (opt-out model + preset shortcut)
# ---------------------------------------------------------------------------


class BuiltinTool(str, Enum):
    """Built-in tool names in lowercase agentflow convention.

    The builder capitalizes these to the SDK's expected names
    (``bash`` → ``Bash`` etc.) before passing to ``ClaudeAgentOptions.tools``.

    ``task`` is the subagent delegation tool — required whenever the main
    agent needs to route to a ``subagents:`` entry. ``todo_write`` is the
    SDK's structured task-list tool; ``exit_plan_mode`` is used by the
    planning mode.
    """

    BASH = "bash"
    READ = "read"
    WRITE = "write"
    EDIT = "edit"
    GLOB = "glob"
    GREP = "grep"
    WEB_FETCH = "web_fetch"
    WEB_SEARCH = "web_search"
    TASK = "task"
    TODO_WRITE = "todo_write"
    EXIT_PLAN_MODE = "exit_plan_mode"


class ToolsPreset(str, Enum):
    """SDK-provided tool presets."""

    CLAUDE_CODE = "claude_code"


class ToolsConfig(BaseModel):
    """Tool selection.

    Two forms:

    - ``preset: claude_code`` — hand the SDK its Claude-Code bundle; ignore
      ``builtin``/``disabled``.
    - ``builtin`` + ``disabled`` — explicit opt-out model. ``builtin`` defaults
      to all eight GA tools; ``disabled`` must be a subset.
    """

    preset: Optional[ToolsPreset] = Field(
        None,
        description="Use a named SDK preset. When set, builtin/disabled are ignored.",
    )
    builtin: List[BuiltinTool] = Field(
        default_factory=lambda: list(BuiltinTool),
        description="Built-in tools to expose (defaults to all eight)",
    )
    disabled: List[BuiltinTool] = Field(
        default_factory=list,
        description="Subset of ``builtin`` to exclude",
    )

    @model_validator(mode="after")
    def _validate_disabled_subset(self) -> "ToolsConfig":
        if self.preset is not None:
            return self
        missing = [t for t in self.disabled if t not in self.builtin]
        if missing:
            raise ValueError(
                f"disabled tools {[t.value for t in missing]} are not in builtin; "
                f"builtin={[t.value for t in self.builtin]}"
            )
        return self

    @property
    def effective(self) -> List[BuiltinTool]:
        """The tools that are actually exposed after disabling."""
        if self.preset is not None:
            return []
        return [t for t in self.builtin if t not in self.disabled]


# ---------------------------------------------------------------------------
# Plugins (custom tools)
# ---------------------------------------------------------------------------


class PluginType(str, Enum):
    """Plugin types supported by the CAS backend in v1."""

    PYTHON = "python"


class PluginRef(BaseModel):
    """Reference to a plugin (collection of custom tools) to register."""

    name: str = Field(..., description="Plugin name")
    type: PluginType = Field(default=PluginType.PYTHON)
    module: str = Field(..., description="Python module path containing @tool-decorated functions")
    functions: Optional[List[str]] = Field(
        None,
        description="Specific function names to import (default: all @tool-decorated)",
    )


# ---------------------------------------------------------------------------
# Permissions
# ---------------------------------------------------------------------------


class PermissionMode(str, Enum):
    """SDK permission modes — verbatim from ``ClaudeAgentOptions.permission_mode``."""

    DEFAULT = "default"
    ACCEPT_EDITS = "acceptEdits"
    PLAN = "plan"
    DONT_ASK = "dontAsk"
    BYPASS_PERMISSIONS = "bypassPermissions"
    AUTO = "auto"


class CanUseToolRef(BaseModel):
    """Reference to a custom permission handler.

    The referenced function must match the SDK's ``CanUseTool`` signature::

        async def authorize(
            tool_name: str,
            input_data: dict,
            context: ToolPermissionContext,
        ) -> PermissionResultAllow | PermissionResultDeny
    """

    module: str = Field(..., description="Python module path")
    function: str = Field(..., description="Async permission handler function name")


class PermissionsConfig(BaseModel):
    """Permission policy for the agent."""

    mode: PermissionMode = Field(
        default=PermissionMode.DEFAULT,
        description="Permission mode (default|acceptEdits|plan|dontAsk|bypassPermissions|auto)",
    )
    allowed_tools: Optional[List[str]] = Field(
        None,
        description="Whitelist of tool names the agent may call",
    )
    disallowed_tools: Optional[List[str]] = Field(
        None,
        description="Blacklist of tool names (applied after allowed_tools)",
    )
    can_use_tool: Optional[CanUseToolRef] = None
    prompt_tool_name: Optional[str] = Field(
        None,
        description="SDK ``permission_prompt_tool_name`` — MCP tool to use for interactive prompts",
    )


# ---------------------------------------------------------------------------
# Hooks (first-class — SDK has 10 semantic event types)
# ---------------------------------------------------------------------------


class HookEvent(str, Enum):
    """All 10 hook event types emitted by the Claude Agent SDK."""

    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"
    USER_PROMPT_SUBMIT = "UserPromptSubmit"
    STOP = "Stop"
    SUBAGENT_STOP = "SubagentStop"
    SUBAGENT_START = "SubagentStart"
    PRE_COMPACT = "PreCompact"
    NOTIFICATION = "Notification"
    PERMISSION_REQUEST = "PermissionRequest"


class HookConfig(BaseModel):
    """A single hook registration."""

    event: HookEvent
    matcher: Optional[str] = Field(
        None,
        description="Regex matcher (tool-name for Pre/PostToolUse* events)",
    )
    module: str = Field(..., description="Python module path containing the hook function")
    function: str = Field(..., description="Hook function name")
    timeout: int = Field(default=30, ge=1, description="Hook timeout in seconds")


# ---------------------------------------------------------------------------
# Guards / optimizers / observers (cross-backend; compile down to hooks)
# ---------------------------------------------------------------------------


class GuardType(str, Enum):
    PII = "pii"
    MODEL_CALL_LIMIT = "model_call_limit"
    TOOL_CALL_LIMIT = "tool_call_limit"
    INPUT_VALIDATION = "input_validation"
    CONTENT_FILTER = "content_filter"


class GuardConfig(BaseModel):
    type: GuardType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class OptimizerType(str, Enum):
    TOOL_RETRY = "tool_retry"
    SUMMARIZATION = "summarization"
    PROMPT_CACHING = "prompt_caching"


class OptimizerConfig(BaseModel):
    type: OptimizerType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


class ObserverType(str, Enum):
    AUDIT_LOG = "audit_log"
    COST_TRACKING = "cost_tracking"
    LATENCY_TRACKING = "latency_tracking"


class ObserverConfig(BaseModel):
    type: ObserverType
    config: Optional[Dict[str, Any]] = None
    module: Optional[str] = None
    function: Optional[str] = None


# ---------------------------------------------------------------------------
# MCP servers
# ---------------------------------------------------------------------------


class MCPTransport(str, Enum):
    STDIO = "stdio"
    SSE = "sse"
    HTTP = "http"


class MCPServerEntry(BaseModel):
    transport: MCPTransport = Field(default=MCPTransport.STDIO)

    # stdio
    command: Optional[str] = None
    args: Optional[List[str]] = None
    env: Optional[Dict[str, str]] = None

    # sse / http
    url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None

    @model_validator(mode="after")
    def _validate_transport_fields(self) -> "MCPServerEntry":
        if self.transport == MCPTransport.STDIO:
            if not self.command:
                raise ValueError("MCP transport 'stdio' requires 'command'")
        else:
            if not self.url:
                raise ValueError(f"MCP transport {self.transport.value!r} requires 'url'")
        return self


# ---------------------------------------------------------------------------
# Sandbox
# ---------------------------------------------------------------------------


class SandboxNetworkConfig(BaseModel):
    """Network policy for the sandbox (maps to SDK ``SandboxNetworkConfig``)."""

    allow: Optional[List[str]] = None
    deny: Optional[List[str]] = None


class SandboxConfig(BaseModel):
    """Agent sandbox settings (maps to SDK ``SandboxSettings``).

    snake_case in YAML; the builder translates to the SDK's camelCase
    (``autoAllowBashIfSandboxed`` etc.).
    """

    enabled: Optional[bool] = None
    auto_allow_bash_if_sandboxed: Optional[bool] = None
    excluded_commands: Optional[List[str]] = None
    allow_unsandboxed_commands: Optional[bool] = None
    network: Optional[SandboxNetworkConfig] = None
    enable_weaker_nested_sandbox: Optional[bool] = None


# ---------------------------------------------------------------------------
# Settings + skills
# ---------------------------------------------------------------------------


class SettingSource(str, Enum):
    """Allowed values for ``ClaudeAgentOptions.setting_sources``."""

    USER = "user"
    PROJECT = "project"
    LOCAL = "local"


# ``skills`` may be the literal ``"all"`` (string) or an explicit list.
Skills = Union[Literal["all"], List[str]]


# ---------------------------------------------------------------------------
# Subagents (SDK's ``agents`` dict)
# ---------------------------------------------------------------------------


class MemoryScope(str, Enum):
    """Subagent memory scope (maps to ``AgentDefinition.memory``)."""

    USER = "user"
    PROJECT = "project"
    LOCAL = "local"


class SubagentSpec(BaseModel):
    """Matches the SDK's ``AgentDefinition``. snake_case in YAML.

    The builder translates field names to camelCase (``disallowedTools``,
    ``permissionMode``, ``mcpServers``, ``initialPrompt``, ``maxTurns``) when
    constructing the ``AgentDefinition``.
    """

    description: str = Field(..., description="What this subagent is for (seen by the router)")
    prompt: str = Field(..., description="Subagent system prompt")

    tools: Optional[List[BuiltinTool]] = None
    disallowed_tools: Optional[List[BuiltinTool]] = None

    model: Optional[str] = None
    skills: Optional[List[str]] = None
    memory: Optional[MemoryScope] = None

    mcp_servers: Optional[List[Union[str, Dict[str, Any]]]] = Field(
        None,
        description="References to mcp_servers entries by name, or inline configs",
    )

    initial_prompt: Optional[str] = None
    max_turns: Optional[int] = Field(None, ge=1)
    background: Optional[bool] = None
    effort: Optional[Union[Effort, int]] = None
    permission_mode: Optional[PermissionMode] = None


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class OutputFormat(BaseModel):
    """Structured output format — passthrough to the SDK.

    Schema-free on purpose; the SDK's ``output_format`` is ``dict[str, Any]``
    and the shape depends on the output type (json_schema, function_call,
    etc.). Users construct it verbatim.
    """

    config: Dict[str, Any] = Field(default_factory=dict)

    def to_sdk(self) -> Dict[str, Any]:
        return dict(self.config)


class AgentSpec(BaseModel):
    """The main (always-present) agent.

    v1 always has exactly one main agent. Subagents live in the top-level
    ``subagents:`` dict and are callable by name.
    """

    name: str = Field(..., description="Agent name (used for telemetry)")
    description: Optional[str] = None
    system_prompt: str = Field(..., description="Agent system prompt")

    cwd: Optional[str] = Field(
        None,
        description="Working directory for the agent. Tool operations are scoped here.",
    )
    add_dirs: Optional[List[str]] = Field(
        None,
        description="Additional directories the agent may access (maps to SDK ``add_dirs``)",
    )

    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    plugins: Optional[List[PluginRef]] = None

    # Cross-backend generative-UI components. Same schema MAF / SK / ADK /
    # OAI use. Each ``@ui_component`` fetcher becomes an ``SdkMcpTool``;
    # AgentFlow bundles them into a single in-process MCP server named
    # ``ui_tools`` and adds it to ``ClaudeAgentOptions.mcp_servers``.
    ui_tools: Optional[UIToolsConfig] = Field(
        None,
        description=(
            "Generative-UI components: a module of "
            "``@agentflow.genui.ui_component``-decorated fetchers. CAS "
            "exposes them via an in-process MCP server. Frontend "
            "rendering requires a separate AG-UI bridge (not shipped "
            "on CAS as of this release)."
        ),
    )
    # Frontend-implemented tools. The CAS AG-UI bridge advertises these
    # alongside ``ui_tools`` in the agent's MCP server and pauses the run
    # when the LLM invokes one; the browser handler executes and posts
    # the result back on the next turn. Same cross-backend schema as
    # workflows / deep / MAF / SK.
    client_tools: Optional[List[ClientToolConfig]] = Field(
        default=None,
        description=(
            "Frontend-implemented (browser-side) tools. Each becomes a "
            "tool the LLM sees via the in-process MCP server; the CAS "
            "AG-UI bridge pauses the run when it's invoked and resumes "
            "once the browser posts the result. Bound only when the "
            "AG-UI router opts in via ``bind_client_tools=True``."
        ),
    )

    available_when: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Build-time predicate gating for ``ui_tools``. Keys are "
            "component class names; values are ``simpleeval`` expressions "
            "evaluated once at agent construction. Tools with falsy "
            "predicates are excluded from the MCP server."
        ),
    )

    permissions: PermissionsConfig = Field(default_factory=PermissionsConfig)
    hooks: Optional[List[HookConfig]] = None

    skills: Optional[Skills] = Field(
        None,
        description="Skill names to load, or the literal 'all'",
    )
    setting_sources: Optional[List[SettingSource]] = Field(
        None,
        description="Which setting precedence layers to load (user/project/local)",
    )
    sandbox: Optional[SandboxConfig] = None

    user: Optional[str] = Field(
        None,
        description="Actor identity for multi-tenant attribution (SDK ``user``)",
    )
    output_format: Optional[OutputFormat] = None

    llm: Optional[LLMConfig] = Field(
        None,
        description="Per-agent LLM override (top-level ``llm:`` is the default)",
    )


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


class CasYAMLConfig(BaseModel):
    """Root Claude Agent SDK YAML config."""

    backend: Literal["claude-agent-sdk"] = Field(default="claude-agent-sdk")
    metadata: CasMetadata

    agent: AgentSpec = Field(..., description="The main agent")

    subagents: Optional[Dict[str, SubagentSpec]] = Field(
        None,
        description=(
            "Subagents callable by name from the main agent. Maps to SDK's "
            "``agents: dict[str, AgentDefinition]``."
        ),
    )

    llm: Optional[LLMConfig] = Field(
        None,
        description="Top-level default LLM (agent.llm overrides this)",
    )

    guards: Optional[List[GuardConfig]] = None
    optimizers: Optional[List[OptimizerConfig]] = None
    observers: Optional[List[ObserverConfig]] = None

    mcp_servers: Optional[Dict[str, MCPServerEntry]] = None

    @model_validator(mode="after")
    def _validate_structure(self) -> "CasYAMLConfig":
        # Require some LLM source — otherwise the builder has nothing to call.
        if self.llm is None and self.agent.llm is None:
            raise ValueError(
                "No LLM configured. Set 'llm:' at the top level or 'agent.llm:'."
            )

        # Subagent mcp_servers string references must point to real servers.
        # Custom Python plugins also land in the SDK's mcp_servers dict at
        # runtime (as in-process MCP SDK servers), so a plugin name is a
        # valid reference target too.
        if self.subagents:
            mcp_names = set(self.mcp_servers or {})
            plugin_names = {p.name for p in (self.agent.plugins or [])}
            valid_refs = mcp_names | plugin_names
            for sub_name, sub in self.subagents.items():
                if not sub.mcp_servers:
                    continue
                for ref in sub.mcp_servers:
                    if isinstance(ref, str) and ref not in valid_refs:
                        raise ValueError(
                            f"Subagent '{sub_name}' references unknown MCP server "
                            f"'{ref}'. Known servers: {sorted(valid_refs) or 'none'}."
                        )
        return self
