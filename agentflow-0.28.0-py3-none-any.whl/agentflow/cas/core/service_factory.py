"""LLM config → SDK options translation.

The Claude Agent SDK reads ``ANTHROPIC_API_KEY`` from the environment rather
than taking an explicit key, so ``api_key`` in YAML bridges to the env var.
Other fields under ``llm.config`` map 1:1 to ``ClaudeAgentOptions``.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Tuple

from agentflow.cas.core.config_models import LLMConfig, LLMProvider

# Keys in llm.config that map directly to ClaudeAgentOptions fields.
_LLM_OPTION_KEYS = frozenset(
    {
        "model",
        "fallback_model",
        "max_budget_usd",
        "max_turns",
        "max_thinking_tokens",
        "thinking",
        "effort",
        "include_partial_messages",
        "betas",
    }
)


def apply_llm_config(llm: LLMConfig) -> Dict[str, Any]:
    """Apply side effects (env vars) and return a dict of SDK option kwargs.

    Returns a dict suitable for ``**`` into ``ClaudeAgentOptions(...)``. Any
    unknown keys in ``llm.config`` are passed through unchanged — the SDK
    ignores what it doesn't recognize, but this keeps us forward-compatible
    with new ``ClaudeAgentOptions`` fields without needing a schema bump.
    """
    if llm.provider != LLMProvider.ANTHROPIC:
        if llm.provider == LLMProvider.CUSTOM:
            # `custom` is a hatch for users who know what they're doing —
            # they must configure the SDK's transport themselves.
            return _extract_known_options(llm.config)
        raise ValueError(
            f"LLM provider {llm.provider.value!r} is not supported in v1. "
            f"Only 'anthropic' and 'custom' are valid; bedrock/vertex require "
            f"the Managed Agents API (Research Preview)."
        )

    # api_key → env var (SDK reads ANTHROPIC_API_KEY)
    cfg = dict(llm.config)
    api_key = cfg.pop("api_key", None)
    if api_key:
        os.environ["ANTHROPIC_API_KEY"] = api_key

    return _extract_known_options(cfg)


def _extract_known_options(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Pull the keys the SDK's ``ClaudeAgentOptions`` knows about."""
    return {k: v for k, v in cfg.items() if k in _LLM_OPTION_KEYS}


def split_llm_config(llm: LLMConfig) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Return (sdk_kwargs, extras) so callers can choose what to drop.

    ``sdk_kwargs`` is safe to splat into ``ClaudeAgentOptions``. ``extras`` is
    anything else the user put under ``llm.config`` (useful for debugging
    dry-run output).
    """
    cfg = dict(llm.config)
    cfg.pop("api_key", None)
    sdk = {k: v for k, v in cfg.items() if k in _LLM_OPTION_KEYS}
    extras = {k: v for k, v in cfg.items() if k not in _LLM_OPTION_KEYS}
    return sdk, extras
