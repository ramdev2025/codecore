"""Resolve ``PluginRef`` YAML entries into in-process MCP servers.

The Claude Agent SDK exposes custom Python tools through in-process MCP
servers. The flow is:

1. Author functions decorated with ``@tool(name, description, input_schema)``
   in a Python module.
2. Register them with ``create_sdk_mcp_server(name, tools=[...])`` which
   returns an ``McpSdkServerConfig``.
3. Add that config to ``ClaudeAgentOptions.mcp_servers[plugin_name]``.

This registry handles steps 2-3. Users only author step 1.
"""

from __future__ import annotations

import importlib
from typing import Any, Dict, List, Tuple

from agentflow.cas.core.config_models import PluginRef, PluginType


def resolve_plugins(
    plugins: List[PluginRef] | None,
) -> Dict[str, Any]:
    """Resolve all plugin refs into a dict of ``{name: McpSdkServerConfig}``.

    Lazy imports ``claude_agent_sdk`` so schema-only operations (dry-run,
    unit tests) don't require the SDK to be installed.
    """
    if not plugins:
        return {}

    from claude_agent_sdk import create_sdk_mcp_server  # lazy

    servers: Dict[str, Any] = {}
    for ref in plugins:
        if ref.type != PluginType.PYTHON:  # pragma: no cover - schema enforces
            raise ValueError(
                f"Plugin type {ref.type.value!r} not supported yet. "
                f"Only 'python' works in v1."
            )
        tools = _load_tools_from_module(ref.module, ref.functions)
        if not tools:
            raise ValueError(
                f"Plugin {ref.name!r}: no @tool-decorated functions found in "
                f"{ref.module!r}"
                + (f" (filter: {ref.functions})" if ref.functions else "")
            )
        servers[ref.name] = create_sdk_mcp_server(name=ref.name, tools=tools)
    return servers


def _load_tools_from_module(module_path: str, filter_names: List[str] | None) -> List[Any]:
    """Import ``module_path`` and return every ``SdkMcpTool`` found.

    Optionally restrict to a subset by name (the user's ``functions:`` field).
    """
    from claude_agent_sdk import SdkMcpTool  # lazy

    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Plugin module {module_path!r} could not be imported: {exc}. "
            f"Is it on PYTHONPATH? Is the package installed?"
        ) from exc

    found: List[Tuple[str, Any]] = [
        (attr, obj)
        for attr, obj in vars(mod).items()
        if isinstance(obj, SdkMcpTool)
    ]

    if filter_names:
        # Match either by Python attribute name or the tool's own .name
        allowed = set(filter_names)
        found = [(n, t) for n, t in found if n in allowed or t.name in allowed]

    return [tool for _, tool in found]
