"""Async orchestrator for the CAS AG-UI bridge.

Wraps the :class:`CasRunner` (Claude Agent SDK) and translates its
message stream into the dict event format the AG-UI adapter consumes.

The CAS message stream is fundamentally different from LangGraph /
Semantic Kernel:

  * **Block-structured**, not token-streamed. Each ``AssistantMessage``
    arrives with a ``content: list[TextBlock | ToolUseBlock |
    ToolResultBlock | ThinkingBlock]``. We translate blocks → events.
  * **Tool execution is in-band** in the same stream: assistant emits
    a ``ToolUseBlock``, then the SDK runs the tool, then a
    ``UserMessage`` arrives carrying the matching ``ToolResultBlock``.
    The orchestrator emits ``tool_call`` then ``tool`` events
    accordingly.
  * **client_tools surface via the in-process MCP server**. The
    ``ClientToolPause`` exception is raised inside the SDK's MCP
    worker; the SDK packages it as a ``ToolResultBlock`` whose
    ``content`` contains the exception text. We detect that pattern
    and convert it to an AG-UI Interrupt event.

The orchestrator holds per-thread conversation state in memory
(CAS doesn't expose a checkpointer). Sufficient for AG-UI client_tool
resume flows within a session.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AsyncCASAGUIRuntime:
    """Async runtime wrapping a Claude Agent SDK CasRunner."""

    def __init__(
        self,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> None:
        self._config_path = config_path
        self._build_state = build_state or {}
        self._bind_client_tools = bind_client_tools
        self._builder: Any = None
        self._runner: Any = None
        # Per-thread prompt history: appended to each turn for context
        # (CAS doesn't have a built-in conversation store).
        self._thread_history: dict[str, list[str]] = {}
        # ``_paused_threads[thread_id]`` → pending interrupt payload.
        self._paused_threads: dict[str, dict[str, Any]] = {}

    @classmethod
    async def create(
        cls,
        config_path: str,
        build_state: Optional[dict] = None,
        bind_client_tools: bool = False,
    ) -> "AsyncCASAGUIRuntime":
        """Async factory: build the runner so the first ``run`` is hot."""
        from agentflow.cas.core.builder import CasAgentBuilder

        inst = cls(
            config_path=config_path,
            build_state=build_state,
            bind_client_tools=bind_client_tools,
        )
        inst._builder = CasAgentBuilder.from_yaml(
            config_path,
            build_state=inst._build_state,
            bind_client_tools=bind_client_tools,
        )
        inst._runner = inst._builder.build()
        return inst

    async def cleanup(self) -> None:
        """No-op for CAS — the SDK has nothing to tear down."""
        return None

    async def get_state(self, thread_id: str) -> dict[str, Any]:
        """Synthesise a state snapshot from in-memory history +
        paused interrupts so the bridge's resilience checks work."""
        from types import SimpleNamespace

        tasks = ()
        pending = self._paused_threads.get(thread_id)
        if pending is not None:
            intr = SimpleNamespace(id=pending["id"], value=pending["value"])
            task = SimpleNamespace(id=f"task-{thread_id}", interrupts=(intr,))
            tasks = (task,)

        values: dict[str, Any] = {
            "history_turns": len(self._thread_history.get(thread_id, [])),
        }
        return {"values": values, "tasks": tasks, "next": ()}

    async def run(
        self,
        state: Any,
        config: dict,
        stream_tokens: bool = False,
    ):
        """Yield orchestrator events translated from CAS's message stream.

        ``state`` is either:
          * a fresh-turn dict ``{"messages": [{"role": "user", ...}]}``
          * a ``langgraph.types.Command(resume=<result>)`` from the
            router after a client_tool pause.
        """
        from langgraph.types import Command

        from agentflow.cas.agui.client_tools import (
            ClientToolPause,
            build_client_tool_result_text,
        )

        thread_id = (config.get("configurable") or {}).get("thread_id") or "default"
        history = self._thread_history.setdefault(thread_id, [])

        prompt: Optional[str] = None
        if isinstance(state, Command):
            pending = self._paused_threads.pop(thread_id, None)
            if pending is None:
                logger.warning(
                    "CAS: resume requested for thread=%s but no paused interrupt",
                    thread_id,
                )
                return
            tool_name = pending["value"].get("tool_name") or "?"
            result_text = build_client_tool_result_text(pending["id"], state.resume)
            # CAS doesn't expose a structured tool-result channel — we
            # inject the browser's result as a system-style preamble so
            # the agent picks up the loop.
            prompt = (
                f"Tool result for {tool_name}: {result_text}\n\n"
                "Continue based on this result."
            )
        elif isinstance(state, dict) and state.get("messages"):
            for msg in state["messages"]:
                if msg.get("role") == "user" and msg.get("content"):
                    prompt = msg["content"]
        if not prompt:
            return

        history.append(prompt)

        if stream_tokens:
            yield {"type": "agent_start", "name": "cas-agent", "content": ""}

        accumulated_text = ""
        tool_call_seen: dict[str, str] = {}  # tool_use_id → tool name

        try:
            async for message in self._runner.query(prompt):
                events = list(self._translate_message(
                    message,
                    tool_call_seen,
                    stream_tokens,
                ))
                for ev in events:
                    if ev.get("type") == "token":
                        accumulated_text += ev.get("content", "") or ""
                    yield ev
        except ClientToolPause as pause:
            interrupt_id = uuid.uuid4().hex[:12]
            payload = {
                "type": "agentflow:client_tool",
                "tool_name": pause.tool_name,
                "args": pause.tool_args,
            }
            self._paused_threads[thread_id] = {
                "id": interrupt_id,
                "value": payload,
            }
            yield {
                "type": "interrupt",
                "interrupts": [{
                    "id": interrupt_id,
                    "reason": "agentflow:client_tool",
                    "tool_name": pause.tool_name,
                    "metadata": {"args": pause.tool_args},
                }],
            }
            return

        if stream_tokens:
            yield {"type": "agent_end", "name": "cas-agent"}

        if accumulated_text:
            history.append(f"[assistant]: {accumulated_text}")

    # ------------------------------------------------------------------
    # Message translation
    # ------------------------------------------------------------------

    def _translate_message(
        self,
        message: Any,
        tool_call_seen: dict[str, str],
        stream_tokens: bool,
    ):
        """Map one CAS message into zero-or-more orchestrator event dicts."""
        mtype = type(message).__name__

        if mtype == "AssistantMessage":
            for block in getattr(message, "content", []) or []:
                btype = type(block).__name__
                if btype == "TextBlock":
                    text = getattr(block, "text", "") or ""
                    if text and stream_tokens:
                        yield {"type": "token", "name": "cas-agent", "content": text}
                elif btype == "ToolUseBlock":
                    use_id = getattr(block, "id", "") or ""
                    name = getattr(block, "name", "") or ""
                    raw_args = getattr(block, "input", None) or {}
                    # CAS MCP tool names land as ``mcp__<server>__<tool>``.
                    # Strip the prefix so the AG-UI wire shows the
                    # frontend-recognised tool name.
                    display = name
                    if name.startswith("mcp__"):
                        display = name.split("__")[-1]
                    tool_call_seen[use_id] = display
                    yield {
                        "type": "tool_call",
                        "name": display,
                        "args": raw_args if isinstance(raw_args, dict) else {"raw": str(raw_args)},
                    }

        elif mtype == "UserMessage":
            # Tool results live here as ToolResultBlock items.
            for block in getattr(message, "content", []) or []:
                btype = type(block).__name__
                if btype != "ToolResultBlock":
                    continue
                use_id = getattr(block, "tool_use_id", "") or ""
                content = getattr(block, "content", None)
                is_error = bool(getattr(block, "is_error", False))
                fetched_name = tool_call_seen.get(use_id, "")
                # Flatten MCP-style content lists to a single string/dict
                payload: Any = content
                if isinstance(content, list):
                    text_parts = [
                        c.get("text") for c in content
                        if isinstance(c, dict) and c.get("type") == "text"
                    ]
                    if text_parts:
                        joined = "".join(p or "" for p in text_parts)
                        # Try to parse JSON (genui adapter expects dict
                        # with ``__component__`` marker for CUSTOM events).
                        try:
                            payload = json.loads(joined)
                        except Exception:
                            payload = joined

                # Detect a ``ClientToolPause`` from inside the MCP worker
                # — the SDK wraps it as an error-flagged tool result.
                if is_error and isinstance(payload, str) and "client_tool pause:" in payload:
                    # Parse "client_tool pause: NAME({args})" if possible.
                    # Robustness: just signal via a sentinel for the
                    # caller to detect. The caller's ``except`` block
                    # above won't see this — re-raise.
                    raise _decode_client_tool_pause(payload)

                yield {
                    "type": "tool",
                    "name": fetched_name,
                    "content": payload,
                }

        elif mtype == "ResultMessage":
            # End of the SDK run. Nothing to emit — the adapter sees
            # ``agent_end`` from the orchestrator's outer wrapper.
            return


def _decode_client_tool_pause(text: str):
    """Reconstruct a ``ClientToolPause`` from the SDK's error-wrapped
    representation of the raised exception.

    The MCP worker process pickles unhandled exceptions into a string
    of the form ``"client_tool pause: NAME({...})"``. Parse out
    ``NAME`` and ``args`` and rebuild the typed exception so the
    orchestrator's ``except`` catches it.
    """
    from agentflow.cas.agui.client_tools import ClientToolPause

    name = "?"
    args: dict[str, Any] = {}
    try:
        body = text.split("client_tool pause:", 1)[1].strip()
        if "(" in body:
            name = body.split("(", 1)[0].strip()
            arg_repr = body[len(name):].strip()
            if arg_repr.startswith("(") and arg_repr.endswith(")"):
                inner = arg_repr[1:-1]
                # Try a JSON parse first; fall back to ast.literal_eval.
                try:
                    args = json.loads(inner)
                except Exception:
                    try:
                        import ast
                        parsed = ast.literal_eval(inner)
                        if isinstance(parsed, dict):
                            args = parsed
                    except Exception:
                        args = {"raw": inner}
    except Exception:
        pass
    return ClientToolPause(tool_name=name, args=args)
