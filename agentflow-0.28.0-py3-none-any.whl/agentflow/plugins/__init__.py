"""Backward-compatible shim — modules moved to agentflow.workflows.plugins."""
try:
    from agentflow.workflows.plugins import *  # noqa: F401,F403
except ImportError:
    pass
